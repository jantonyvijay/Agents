# Enterprise Agent Platform — Final Dynamic Workflow Solution (V9)

A configuration-driven enterprise Agent + Workflow platform built as one ASP.NET Core 8 Web API with a rich `wwwroot` SPA (HTML/CSS/jQuery), plus a YARP API Gateway and a reference MCP Server.

The platform is designed so a new business workflow is created from the UI and stored as configuration — not implemented as a new C# application.

## What is implemented

### Dynamic workflow designer

- Drag/drop Agents and Tools from the reusable registry.
- Add/remove workflow connection lines; click a line and press Delete/Backspace or use Remove.
- Generic node configuration inspector.
- Save/Test/Publish with workflow version and audit metadata.
- Dynamic node types:
  - Start / End
  - User Input
  - File Upload
  - Data Source
  - Data Mapper
  - Validator
  - Agent
  - Tool
  - Mail API
  - Decision
  - Parallel / Join
  - Human Approval
  - Maker / Checker

### Common Workflow Data Context

Every node can write its result into `config.outputVariable`.

Example variables:

```text
input
ftpData
uploadedFile
fcData
canonical
validation
makerChecker
mailResult
```

Later nodes can reference values without custom C# code:

```text
{{input.customerId}}
{{fcData.status}}
{{ftpData.fileName}}
{{validation.valid}}
{{makerChecker.checker}}
```

### Dynamic data channels

The Data Connection Registry supports reusable approved connector + operation definitions.

Included examples:

- `DCPFTP Production Area` (`fileArea`) — reads an approved mounted/staging folder. Set `DCPFTP_ROOT` in production.
- `FC Query Connector` (`fc-query`) — approved FC operations; demo uses mock data, production can point the same operation at an HTTP FC service.
- REST API connector.
- Browser File Upload channel — files are stored separately; workflow state carries only file metadata/reference.

The SPA contains a **Data Connections** screen where new channels can be registered without editing the workflow runtime.

### Human Task Engine

The workflow pauses and creates a durable task for:

- User Input
- File Upload
- Approval
- Maker
- Checker

The SPA contains a **Human Tasks** inbox. Completing a task calls the API and automatically resumes the paused workflow.

Maker/Checker enforces the important separation-of-duty rule: the recorded Maker user cannot be the Checker for the same request.

### Mail Sending Tool

`Enterprise Mail Sending Tool` is a reusable `mail-api` tool.

In demo mode (no URL configured), it resolves the final mail payload without sending externally. For production, set the enterprise mail API URL and secret environment-variable references.

Mail content can use workflow variables and optional reusable mail templates.

### MCP

- MCP Server Registry.
- MCP client connection/test.
- `tools/list`, `resources/list`, `prompts/list` discovery.
- Import discovered MCP tools into Tool Registry.
- MCP `tools/call` execution.
- Reference Streamable HTTP MCP server project.

### API Gateway

Separate YARP gateway project:

- reverse proxy routing
- rate limiting
- correlation IDs
- security headers
- Agent Platform routing
- MCP routing

### Enterprise controls

- Tenant context (`X-Tenant-Id`)
- Environment (`DEV` / `UAT` / `PROD`)
- User context (`X-User-Id`)
- Audit trail
- Workflow ownership/risk/version
- Approval-controlled publishing validation
- MCP trust status
- Connector trust/environment restrictions
- API-key middleware starter
- production extension points for Entra ID/RBAC, Key Vault, SQL Server, OpenTelemetry and durable distributed workers

## Solution structure

```text
EnterpriseAgentPlatform/
│
├── backend/
│   └── AgentPlatform.Api/
│       ├── Contracts/
│       ├── Data/
│       │   ├── agents.json
│       │   ├── tools.json
│       │   ├── models.json
│       │   ├── workflows.json
│       │   ├── connectors.json
│       │   ├── humantasks.json
│       │   ├── mailtemplates.json
│       │   ├── files.json
│       │   ├── executions.json
│       │   ├── audit.json
│       │   ├── mcpservers.json
│       │   └── dcpftp/
│       ├── Models/
│       ├── Services/
│       │   ├── ConnectorGateway.cs
│       │   ├── FileStorageService.cs
│       │   ├── HumanTaskService.cs
│       │   ├── TemplateResolver.cs
│       │   ├── WorkflowRuntime.cs
│       │   ├── ToolGateway.cs
│       │   ├── McpClientService.cs
│       │   └── NodeHandlers/
│       │       ├── NodeContracts.cs
│       │       ├── AgentNodeHandler.cs
│       │       ├── ToolNodeHandler.cs
│       │       ├── DataSourceNodeHandler.cs
│       │       ├── DataMapperNodeHandler.cs
│       │       ├── ValidatorNodeHandler.cs
│       │       └── HumanNodeHandlers.cs
│       └── wwwroot/
│           ├── index.html
│           ├── css/app.css
│           └── js/
│               ├── common.js
│               ├── designer.js
│               └── app.js
│
├── gateway/AgentPlatform.Gateway/
├── mcp/EnterpriseMcp.Server/
├── docs/
├── docker-compose.yml
├── run-local.cmd
└── run-local.sh
```

## Run locally

Requires .NET 8 SDK.

```bash
cd backend/AgentPlatform.Api
dotnet run --urls http://0.0.0.0:5000
```

Open:

```text
http://localhost:5000
```

No Node.js, npm, React, MVC Views or Razor frontend build is required.

## Run all services

```bash
docker compose up --build
```

Typical endpoints:

```text
Gateway            http://localhost:8080
Agent Platform     http://localhost:5000
MCP Server         http://localhost:5100/mcp
```

## Demo: Dynamic Multi-Channel FC Workflow

Open **Workflows → Dynamic Multi-Channel FC Workflow → Test**.

Use any JSON start payload, for example:

```json
{
  "source": "designer"
}
```

The workflow pauses at **Customer Input** and creates a Human Task.

Go to **Human Tasks → Open task** and enter:

```text
customerId = C12345
requestId  = REQ-10001
```

The runtime resumes and performs:

```text
User Input
   ↓
Parallel
   ├── DCPFTP Area → ftpData
   └── FC Query    → fcData
   ↓
Join
   ↓
Data Mapper → canonical
   ↓
Validator → validation
   ↓
Decision
   ↓ valid
Maker / Checker
   ↓
Mail API Tool
   ↓
End
```

Complete the Maker task from **Human Tasks**. Then change the browser User ID in Settings before completing the Checker task; the same user is intentionally blocked from checking their own Maker submission.

## Important APIs

```text
GET/POST/PUT  /api/workflows
POST          /api/workflows/{id}/execute
POST          /api/workflows/{id}/publish

GET/POST/PUT  /api/connectors
POST          /api/connectors/{id}/execute

GET           /api/tasks
POST          /api/tasks/{id}/submit
POST          /api/tasks/{id}/decision

POST          /api/files/upload
GET           /api/files/{id}

GET/POST      /api/mail/templates

GET           /api/agents
GET           /api/tools
GET           /api/models

GET           /api/mcp/servers
POST          /api/mcp/servers/{id}/test
POST          /api/mcp/servers/{id}/discover?import=true
POST          /api/mcp/tools/{toolId}/call

GET           /api/executions
GET           /api/audit
GET           /api/governance
```

## Production migration

The demo repositories use JSON intentionally so the whole platform can be demonstrated without SQL. `JsonRegistry<T>` is isolated from the workflow runtime, so the next production step is to replace it with SQL Server repositories while preserving API contracts and node handlers.

See:

- `docs/DYNAMIC-WORKFLOW-CONFIG.md`
- `docs/SQL-SERVER-SCHEMA.sql`
- `docs/PRODUCTION-EXTENSIONS.md`

## Production requirements before real banking/enterprise use

The starter demonstrates architecture and reusable execution behavior. Before production, add/complete:

1. Microsoft Entra ID/OIDC and policy-based RBAC.
2. Server-side authorization for task roles and tool/connector permissions.
3. SQL Server persistence, optimistic concurrency and immutable workflow versions.
4. Key Vault/managed secret provider.
5. Malware scanning and enterprise document storage for file uploads.
6. Real DCPFTP/SFTP ingestion service or mounted secure transfer area.
7. Durable queue-backed execution/checkpoint workers.
8. OpenTelemetry traces/metrics/logs.
9. Data classification/PII controls and retention policies.
10. DEV → UAT → PROD promotion and checker approval for published workflows.

## Validation

See `docs/VALIDATION.md`. The package has static JSON/JavaScript/HTML/C# structural validation. Run `dotnet restore` and `dotnet build -c Release` on a machine with the .NET 8 SDK before production deployment.
