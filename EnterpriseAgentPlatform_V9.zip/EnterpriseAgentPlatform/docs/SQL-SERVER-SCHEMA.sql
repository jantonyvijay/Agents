/* Production-oriented starter schema. Keep immutable published workflow definitions as JSON snapshots. */
CREATE TABLE dbo.AgentPlatformWorkflow (
    WorkflowId varchar(64) NOT NULL PRIMARY KEY,
    WorkflowName nvarchar(250) NOT NULL,
    CurrentVersion int NOT NULL,
    Status varchar(30) NOT NULL,
    OwnerName nvarchar(150) NULL,
    Environment varchar(20) NOT NULL,
    RiskLevel varchar(20) NOT NULL,
    RequiresApproval bit NOT NULL,
    UpdatedBy nvarchar(150) NULL,
    UpdatedAtUtc datetime2 NOT NULL
);
GO
CREATE TABLE dbo.AgentPlatformWorkflowVersion (
    WorkflowId varchar(64) NOT NULL,
    VersionNo int NOT NULL,
    DefinitionJson nvarchar(max) NOT NULL,
    PublishedBy nvarchar(150) NULL,
    PublishedAtUtc datetime2 NULL,
    CONSTRAINT PK_AgentPlatformWorkflowVersion PRIMARY KEY (WorkflowId, VersionNo)
);
GO
CREATE TABLE dbo.AgentPlatformExecution (
    ExecutionId varchar(64) NOT NULL PRIMARY KEY,
    WorkflowId varchar(64) NOT NULL,
    WorkflowVersion int NOT NULL,
    TenantId nvarchar(100) NOT NULL,
    Environment varchar(20) NOT NULL,
    UserId nvarchar(150) NOT NULL,
    CorrelationId varchar(64) NOT NULL,
    Status varchar(40) NOT NULL,
    CurrentNodeId varchar(64) NULL,
    StateJson nvarchar(max) NOT NULL,
    StartedAtUtc datetime2 NOT NULL,
    CompletedAtUtc datetime2 NULL
);
GO
CREATE TABLE dbo.AgentPlatformHumanTask (
    TaskId varchar(64) NOT NULL PRIMARY KEY,
    ExecutionId varchar(64) NOT NULL,
    WorkflowId varchar(64) NOT NULL,
    NodeId varchar(64) NOT NULL,
    TaskType varchar(30) NOT NULL,
    TaskStatus varchar(30) NOT NULL,
    CreatedBy nvarchar(150) NOT NULL,
    MakerUserId nvarchar(150) NULL,
    AssignedRole nvarchar(150) NULL,
    PayloadJson nvarchar(max) NULL,
    Decision varchar(30) NULL,
    Comment nvarchar(2000) NULL,
    CompletedBy nvarchar(150) NULL,
    CreatedAtUtc datetime2 NOT NULL,
    DueAtUtc datetime2 NULL,
    CompletedAtUtc datetime2 NULL
);
GO
CREATE INDEX IX_AgentPlatformHumanTask_StatusRole ON dbo.AgentPlatformHumanTask(TaskStatus, AssignedRole, CreatedAtUtc);
GO
CREATE TABLE dbo.AgentPlatformConnector (
    ConnectorId varchar(64) NOT NULL PRIMARY KEY,
    ConnectorName nvarchar(250) NOT NULL,
    ConnectorType varchar(40) NOT NULL,
    Environment varchar(20) NOT NULL,
    TrustStatus varchar(30) NOT NULL,
    Enabled bit NOT NULL,
    DefinitionJson nvarchar(max) NOT NULL,
    UpdatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE dbo.AgentPlatformAudit (
    AuditId varchar(64) NOT NULL PRIMARY KEY,
    AtUtc datetime2 NOT NULL,
    TenantId nvarchar(100) NOT NULL,
    Environment varchar(20) NOT NULL,
    UserId nvarchar(150) NOT NULL,
    ActionName nvarchar(100) NOT NULL,
    ResourceType nvarchar(100) NOT NULL,
    ResourceId nvarchar(150) NULL,
    Detail nvarchar(max) NULL,
    Outcome varchar(30) NOT NULL
);
GO
