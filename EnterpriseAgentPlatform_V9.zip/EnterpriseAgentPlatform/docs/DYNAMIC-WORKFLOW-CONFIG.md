# Dynamic Workflow Configuration Guide

The runtime resolves workflow behavior from `WorkflowNode.Type` + `WorkflowNode.Config`. Do not add business-process-specific `if (workflowName == ...)` code.

## Node configuration examples

### User Input

```json
{
  "type": "userInput",
  "config": {
    "fields": "customerId:text:required,requestId:text:required",
    "assignedRole": "OperationsMaker",
    "outputVariable": "input"
  }
}
```

### File Upload

```json
{
  "type": "fileUpload",
  "config": {
    "allowedExtensions": ".csv,.json,.xlsx,.pdf",
    "assignedRole": "OperationsMaker",
    "outputVariable": "uploadedFile"
  }
}
```

### Data Source

```json
{
  "type": "dataSource",
  "config": {
    "connectorId": "fc-prod",
    "operation": "GetCustomer",
    "param.customerId": "{{input.customerId}}",
    "outputVariable": "fcData"
  }
}
```

### Data Mapper

Each `map.<target>` property creates one output field.

```json
{
  "type": "dataMapper",
  "config": {
    "map.customerId": "{{fcData.customerId}}",
    "map.amount": "{{ftpData.content.rows.0.AMT}}",
    "outputVariable": "canonical"
  }
}
```

### Validator

```json
{
  "type": "validator",
  "config": {
    "sourceVariable": "canonical",
    "requiredFields": "customerId,amount",
    "failOnInvalid": "false",
    "outputVariable": "validation"
  }
}
```

### Decision edge

```json
{
  "source": "decision",
  "target": "approved-path",
  "condition": "{{validation.valid}} == true"
}
```

The fallback edge uses `always`.

### Maker / Checker

```json
{
  "type": "makerChecker",
  "config": {
    "makerRole": "OperationsMaker",
    "checkerRole": "OperationsChecker",
    "slaHours": "24",
    "outputVariable": "makerChecker"
  }
}
```

### Mail API Tool

```json
{
  "type": "mail",
  "config": {
    "toolId": "mail-api-tool",
    "inputTemplate": "Approved {{fcData.customerId}}",
    "outputVariable": "mailResult"
  }
}
```

## Connector principle

Workflow JSON stores only approved identifiers:

```text
connectorId
operation
parameters
```

Do not store passwords, tokens, connection strings or FTP credentials inside workflows.

### Current tool input vs workflow input

Use `{{toolInput}}` inside an HTTP/mock Tool definition when the adapter needs the value passed into that Tool node. Use normal workflow variables such as `{{input.customerId}}`, `{{fcData.status}}` and `{{canonical.amount}}` for shared workflow state.
