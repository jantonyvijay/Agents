# V9 Production Extensions

V9 now contains working YARP gateway and MCP client/server functionality. The remaining production work is primarily hardening and infrastructure integration rather than protocol placeholders.

Recommended next production layers:

1. Entra ID / OIDC authentication at the gateway and service layer.
2. Policy-based RBAC for workflow ownership, publishing, MCP onboarding and execution.
3. SQL Server repositories with optimistic concurrency and migrations.
4. Key Vault/managed secret provider.
5. OpenTelemetry tracing from gateway -> workflow -> agent/tool -> MCP server.
6. Durable queue-backed workflow workers and retry/idempotency policies.
7. Network egress allowlists and private endpoints for approved MCP/API servers.
8. MCP server trust approval with certificate/OAuth validation.
9. Agent-to-tool permission matrix and data-classification enforcement.
10. DEV/UAT/PROD promotion, signed workflow versions and change approvals.
