# Validation Notes

This package was statically validated in the generation environment:

- all JSON repository files parse successfully;
- `wwwroot/js/common.js`, `app.js`, and `designer.js` pass `node --check`;
- SPA HTML was parsed and checked for duplicate IDs and required designer/task pages;
- C# files passed a delimiter/string/comment structural sanity check;
- ZIP integrity is tested after packaging.

The generation environment does not have the .NET SDK available, so run the following on the target development machine before deployment:

```bash
dotnet restore EnterpriseAgentPlatform.sln
dotnet build EnterpriseAgentPlatform.sln -c Release
```

For production, also run integration/security tests against the real FC, DCPFTP, Mail API, MCP and gateway endpoints before promotion.
