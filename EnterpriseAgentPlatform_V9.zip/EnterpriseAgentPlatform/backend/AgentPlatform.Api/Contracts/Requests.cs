using System.Text.Json.Nodes;

namespace AgentPlatform.Api.Contracts;

public sealed record ExecuteWorkflowRequest(string Input, Dictionary<string, string>? Context = null);
public sealed record ApprovalRequest(bool Approved, string? Comment = null);
public sealed record CreateWorkflowRequest(
    string Name,
    string? Description = null,
    string Template = "blank",
    string? Owner = null,
    string? Environment = null,
    string? RiskLevel = null,
    bool RequiresApproval = false);

public sealed record TaskSubmitRequest(JsonObject? Values = null, string? Comment = null);
public sealed record TaskDecisionRequest(string Decision, string? Comment = null);
public sealed record ConnectorExecuteRequest(string OperationId, Dictionary<string, string>? Parameters = null);
