(function ($, AP) {
    "use strict";

    var state = {
        id: null, workflow: null, discovery: { agents: [], tools: [] }, connectors: [], selectedNodeId: null, selectedEdgeId: null,
        dragCatalogItem: null, draggingNode: null, connectionSource: null, zoom: 1, dirty: false, active: false
    };

    var defaults = {
        start: { label: "Start", icon: "start" }, agent: { label: "Agent", icon: "bot" }, tool: { label: "Tool", icon: "tool" },
        userInput: { label: "User Input", icon: "approval" }, fileUpload: { label: "File Upload", icon: "tool" }, dataSource: { label: "Data Source", icon: "database" },
        dataMapper: { label: "Data Mapper", icon: "workflow" }, validator: { label: "Validator", icon: "check" }, mail: { label: "Mail API", icon: "tool" },
        decision: { label: "Decision", icon: "decision" }, parallel: { label: "Parallel", icon: "workflow" }, join: { label: "Join", icon: "layout" },
        approval: { label: "Human Approval", icon: "approval" }, makerChecker: { label: "Maker / Checker", icon: "shield" }, end: { label: "End", icon: "end" }
    };

    function cssEscape(v) { return String(v).replace(/'/g, "\\'"); }
    function normalize() {
        state.workflow.nodes = state.workflow.nodes || [];
        state.workflow.edges = state.workflow.edges || [];
        state.workflow.nodes.forEach(function (n) { n.config = n.config || {}; n.x = Number(n.x || 0); n.y = Number(n.y || 0); });
    }
    function markDirty() {
        if (!state.active) return;
        state.dirty = true;
        $("#saveState").html("<i></i>Unsaved changes").addClass("dirty");
    }
    function clearDirty(text) {
        state.dirty = false;
        $("#saveState").html("<i></i>" + AP.escapeHtml(text || "Saved")).removeClass("dirty");
    }
    function iconFor(type) { return (defaults[type] || defaults.agent).icon; }
    function findCatalog(kind, id) {
        var list = kind === "agent" ? state.discovery.agents : state.discovery.tools;
        return (list || []).find(function (x) { return x.id === id; });
    }
    function findConnector(id) { return (state.connectors || []).find(function (x) { return x.id === id; }); }
    function bindingText(node) {
        if (node.type === "agent" && node.config.agentId) { var a = findCatalog("agent", node.config.agentId); return a ? a.category + " · " + (a.modelId || "model") : node.config.agentId; }
        if ((node.type === "tool" || node.type === "mail") && node.config.toolId) { var t = findCatalog("tool", node.config.toolId); return t ? (t.category || "Tool") + " · " + (t.type || "integration") : node.config.toolId; }
        if (node.type === "dataSource" && node.config.connectorId) { var c = findConnector(node.config.connectorId); return c ? c.name + " · " + (node.config.operation || "operation") : node.config.connectorId; }
        if (node.type === "makerChecker") return "Maker → Checker · separation of duties";
        if (node.type === "userInput" || node.type === "fileUpload") return "Human task · workflow pauses";
        if (node.type === "parallel") return "Fan-out branches";
        if (node.type === "join") return "Wait for incoming branches";
        return node.type === "decision" ? "Conditional routing" : node.type === "approval" ? "Human-in-the-loop" : node.type;
    }
    function nextPosition() {
        var count = state.workflow.nodes.length;
        return { x: 180 + ((count * 130) % 720), y: 110 + ((count * 115) % 520) };
    }

    function loadWorkflow() {
        $("#canvasStage").empty(); $("#edgeGroup").empty();
        $("#saveState").html("<i></i>Loading workflow…");
        return AP.ajax({ url: "/api/workflows/" + encodeURIComponent(state.id), method: "GET", dataType: "json" })
            .done(function (data) {
                state.workflow = data; normalize();
                $("#workflowName").val(state.workflow.name || "Workflow");
                $("#workflowStatus").val(state.workflow.status || "Draft");
                $("#versionBadge").text("v" + (state.workflow.version || 1));
                $("#designerEnvironment").text(state.workflow.environment || AP.context().environment || "DEV");
                var risk = state.workflow.riskLevel || "Low";
                $("#designerRisk").text(risk + " risk").removeClass("risk-low risk-medium risk-high").addClass("risk-" + String(risk).toLowerCase());
                $("#designerOwner").text(state.workflow.owner || "Agent Platform Team");
                renderAll(); clearDirty("Loaded from workflows.json"); updateGuide();
            }).fail(function (xhr) { AP.toast(xhr.responseJSON?.error || "Unable to load workflow.", "error"); });
    }

    function loadDiscovery(query) {
        return AP.ajax({ url: "/api/discovery", method: "GET", dataType: "json", data: { query: query || "", kind: "all" } })
            .done(function (data) { state.discovery = data || { agents: [], tools: [] }; renderCatalog(); if (state.selectedNodeId) renderInspector(); });
    }
    function loadConnectors() {
        return AP.ajax({ url: "/api/connectors", method: "GET", dataType: "json" }).done(function (data) { state.connectors = data || []; if (state.selectedNodeId) renderInspector(); });
    }

    function renderCatalogCard(item, kind) {
        var meta = kind === "agent" ? (item.capabilities || []).slice(0, 2).join(" · ") : (item.type || "tool") + (item.tags?.length ? " · " + item.tags[0] : "");
        return "<div class='catalog-card draggable-card' draggable='true' data-kind='" + kind + "' data-id='" + AP.escapeHtml(item.id) + "'>" +
            "<div class='catalog-card-icon'>" + AP.icon(kind === "agent" ? "bot" : "tool") + "</div>" +
            "<div class='catalog-card-main'><strong>" + AP.escapeHtml(item.name) + "</strong><div class='catalog-category'>" + AP.escapeHtml(item.category || "General") + "</div><div class='catalog-meta'>" + AP.escapeHtml(meta || "Reusable component") + "</div></div>" +
            "<div class='catalog-actions'><span class='drag-grip' title='Drag to canvas'>" + AP.icon("drag") + "</span><button class='catalog-add' type='button' title='Add to canvas'>" + AP.icon("plus") + "</button></div></div>";
    }
    function renderCatalog() {
        var agents = state.discovery.agents || [], tools = state.discovery.tools || [];
        $("#agentCount").text(agents.length); $("#toolCount").text(tools.length);
        $("#agentCatalog").html(agents.length ? agents.map(function (x) { return renderCatalogCard(x, "agent"); }).join("") : "<div class='empty-catalog'>No matching agents.</div>");
        $("#toolCatalog").html(tools.length ? tools.map(function (x) { return renderCatalogCard(x, "tool"); }).join("") : "<div class='empty-catalog'>No matching tools.</div>");
    }

    function addCommonNode(type) {
        if (!state.workflow) return;
        var p = nextPosition(), d = defaults[type] || defaults.agent;
        var n = { id: AP.newId(type), type: type, label: d.label, x: p.x, y: p.y, config: {} };
        if (type === "userInput") n.config = { fields: "customerId:text:required,requestId:text:required", assignedRole: "WorkflowUser", outputVariable: "input" };
        if (type === "fileUpload") n.config = { allowedExtensions: ".csv,.json,.xlsx,.pdf", assignedRole: "WorkflowUser", outputVariable: "uploadedFile" };
        if (type === "dataSource") { var c = (state.connectors || [])[0]; n.config = { connectorId: c ? c.id : "", operation: c && c.operations && c.operations.length ? c.operations[0].id : "read", outputVariable: "sourceData" }; }
        if (type === "dataMapper") n.config = { "map.customerId": "{{input.customerId}}", outputVariable: "mappedData" };
        if (type === "validator") n.config = { sourceVariable: "mappedData", requiredFields: "customerId", outputVariable: "validation" };
        if (type === "approval") n.config = { approverRole: "Approver", slaHours: "24", outputVariable: "approval" };
        if (type === "makerChecker") n.config = { makerRole: "Maker", checkerRole: "Checker", slaHours: "24", outputVariable: "makerChecker" };
        if (type === "mail") { var mt = (state.discovery.tools || []).find(function (x) { return x.type === "mail-api"; }); n.config = { toolId: mt ? mt.id : "mail-api-tool", inputTemplate: "Workflow completed for {{input.customerId}}", outputVariable: "mailResult" }; }
        state.workflow.nodes.push(n); state.selectedNodeId = n.id; markDirty(); renderAll(); updateGuide();
        AP.toast(d.label + " node added", "success", "Canvas updated");
    }
    function addCatalogNode(kind, item, position) {
        if (!state.workflow || !item) return;
        position = position || nextPosition();
        var n = { id: AP.newId(kind), type: kind, label: item.name, x: Math.max(20, position.x), y: Math.max(20, position.y), config: {} };
        n.config[kind === "agent" ? "agentId" : "toolId"] = item.id;
        state.workflow.nodes.push(n); state.selectedNodeId = n.id; markDirty(); renderAll(); updateGuide();
        AP.toast(item.name + " is ready on the canvas.", "success", kind === "agent" ? "Agent added" : "Tool added");
    }

    function renderNodes() {
        if (!state.workflow) return;
        var html = state.workflow.nodes.map(function (node) {
            var selected = node.id === state.selectedNodeId ? " selected" : "";
            var canIn = node.type !== "start", canOut = node.type !== "end";
            return "<div class='workflow-node node-" + AP.escapeHtml(node.type) + selected + "' data-node-id='" + AP.escapeHtml(node.id) + "' style='left:" + node.x + "px;top:" + node.y + "px'>" +
                (canIn ? "<div class='node-port port-in' title='Connect into this node'></div>" : "") +
                "<div class='node-topline'><span class='node-icon'>" + AP.icon(iconFor(node.type)) + "</span><span class='node-type'>" + AP.escapeHtml(node.type) + "</span></div>" +
                "<div class='node-title'>" + AP.escapeHtml(node.label) + "</div><div class='node-binding'>" + AP.escapeHtml(bindingText(node)) + "</div>" +
                (canOut ? "<div class='node-port port-out' title='Drag from here to connect'></div>" : "") + "</div>";
        }).join("");
        $("#canvasStage").html(html);
        $("#canvasEmpty").toggleClass("hidden", state.workflow.nodes.length > 0);
    }
    function nodeElement(id) { return $(".workflow-node[data-node-id='" + cssEscape(id) + "']")[0]; }
    function portPoint(nodeId, port) {
        var el = nodeElement(nodeId), canvas = document.getElementById("workflowCanvas"); if (!el || !canvas) return null;
        var r = el.getBoundingClientRect(), cr = canvas.getBoundingClientRect();
        return { x: (r.left - cr.left + r.width / 2 + canvas.scrollLeft) / state.zoom, y: ((port === "out" ? r.bottom : r.top) - cr.top + canvas.scrollTop) / state.zoom };
    }
    function edgePath(a, b) { var dy = Math.max(54, Math.abs(b.y - a.y) * .43); return "M " + a.x + " " + a.y + " C " + a.x + " " + (a.y + dy) + ", " + b.x + " " + (b.y - dy) + ", " + b.x + " " + b.y; }
    function renderEdges() {
        if (!state.workflow) return;
        var html = state.workflow.edges.map(function (edge) {
            var a = portPoint(edge.source, "out"), b = portPoint(edge.target, "in"); if (!a || !b) return "";
            var d = edgePath(a, b), id = AP.escapeHtml(edge.id), selected = state.selectedEdgeId === edge.id ? " selected" : "";
            return "<path class='workflow-edge-hit" + selected + "' data-edge-id='" + id + "' d='" + d + "'></path>" +
                   "<path class='workflow-edge" + selected + "' data-edge-id='" + id + "' d='" + d + "' marker-end='url(#arrowHead)'></path>";
        }).join("");
        $("#edgeGroup").html(html);
        renderEdgeQuickAction();
    }

    function renderEdgeQuickAction() {
        var edge = selectedEdge(), $action = $("#edgeQuickAction");
        if (!$action.length) {
            $("#workflowCanvas").append("<button id='edgeQuickAction' class='edge-quick-action hidden' type='button' title='Remove connection'>" + AP.icon("trash") + "<span>Remove</span></button>");
            $action = $("#edgeQuickAction");
        }
        if (!edge) { $action.addClass("hidden"); return; }
        var a = portPoint(edge.source, "out"), b = portPoint(edge.target, "in");
        if (!a || !b) { $action.addClass("hidden"); return; }
        $action.css({ left: (((a.x + b.x) / 2) * state.zoom) + "px", top: (((a.y + b.y) / 2) * state.zoom) + "px" }).removeClass("hidden");
    }
    function renderAll() { renderNodes(); requestAnimationFrame(function () { renderEdges(); renderInspector(); }); }
    function selectedNode() { return state.workflow && state.workflow.nodes.find(function (n) { return n.id === state.selectedNodeId; }); }
    function selectedEdge() { return state.workflow && state.workflow.edges.find(function (e) { return e.id === state.selectedEdgeId; }); }
    function labelOf(id) { var n = state.workflow.nodes.find(function (x) { return x.id === id; }); return n ? n.label : id; }

    function renderInspector() {
        var edge = selectedEdge();
        if (edge) {
            $("#inspectorForm").addClass("hidden");
            $("#inspectorEmpty").removeClass("hidden").html(
                "<div class='connection-inspector'>" +
                "<div class='connection-hero'><span class='connection-icon'>" + AP.icon("workflow") + "</span><div><span class='connection-kicker'>SELECTED CONNECTION</span><strong>" + AP.escapeHtml(labelOf(edge.source)) + " → " + AP.escapeHtml(labelOf(edge.target)) + "</strong><small>Click Remove, right-click the line, or press Delete / Backspace.</small></div></div>" +
                "<div class='connection-route'><div><span>FROM</span><strong>" + AP.escapeHtml(labelOf(edge.source)) + "</strong></div><span class='connection-arrow'>→</span><div><span>TO</span><strong>" + AP.escapeHtml(labelOf(edge.target)) + "</strong></div></div>" +
                "<label class='field-label connection-condition-label'>Condition</label><input id='selectedEdgeCondition' class='field-input' value='" + AP.escapeHtml(edge.condition || "always") + "' />" +
                "<button class='btn btn-danger btn-block connection-delete' data-edge-id='" + AP.escapeHtml(edge.id) + "' type='button'>" + AP.icon("trash") + "Remove connection</button>" +
                "</div>");
            return;
        }
        var node = selectedNode();
        if (!node) {
            $("#inspectorForm").addClass("hidden");
            $("#inspectorEmpty").removeClass("hidden").html("<div class='empty-icon'>" + AP.icon("info") + "</div><h3>Select a node or connection</h3><p>Click a node to configure it, or click any connector line to edit or remove it.</p><div class='tip-card'>" + AP.icon("sparkles") + "<span><strong>Tip</strong> Selected connections become red and show a Remove button on the canvas.</span></div>");
            return;
        }
        $("#inspectorEmpty").addClass("hidden"); $("#inspectorForm").removeClass("hidden");
        $("#nodeLabel").val(node.label); $("#nodeType").val(node.type);
        $("#inspectorNodeHero").html("<span class='node-mini-icon " + AP.escapeHtml(node.type) + "'>" + AP.icon(iconFor(node.type)) + "</span><div><strong>" + AP.escapeHtml(node.label) + "</strong><small>" + AP.escapeHtml(bindingText(node)) + "</small></div>");
        if (node.type === "agent" || node.type === "tool" || node.type === "mail" || node.type === "dataSource") {
            var isAgent = node.type === "agent", isConnector = node.type === "dataSource";
            var key = isAgent ? "agentId" : isConnector ? "connectorId" : "toolId";
            var items = isAgent ? state.discovery.agents : isConnector ? state.connectors : state.discovery.tools;
            var noun = isAgent ? "agent" : isConnector ? "data connection" : "tool";
            $("#bindingSection").removeClass("hidden"); $("#bindingLabel").text(isAgent ? "Agent binding" : isConnector ? "Data connection" : "Tool binding");
            $("#nodeBinding").html("<option value=''>Select " + noun + "</option>" + (items || []).map(function (x) { return "<option value='" + AP.escapeHtml(x.id) + "'>" + AP.escapeHtml(x.name) + "</option>"; }).join("")).val(node.config[key] || "");
            var bound = isConnector ? findConnector(node.config[key]) : findCatalog(isAgent ? "agent" : "tool", node.config[key]);
            $("#bindingInfo").html(bound ? "<strong>" + AP.escapeHtml(bound.category || bound.type || "General") + "</strong><br>" + AP.escapeHtml(bound.description || "Reusable enterprise component") : "Choose a registry item to bind this node.");
        } else $("#bindingSection").addClass("hidden");

        var config = Object.keys(node.config || {}).filter(function (k) { return k !== "agentId" && k !== "toolId" && k !== "connectorId"; }).map(function (k) {
            return "<div class='config-row'><input class='config-key' value='" + AP.escapeHtml(k) + "'><input class='config-value' value='" + AP.escapeHtml(node.config[k]) + "'><button class='remove-config' type='button'>" + AP.icon("x") + "</button></div>";
        }).join("");
        $("#configFields").html(config || "<div class='empty-catalog'>No custom configuration yet.</div>");
        var edges = state.workflow.edges.filter(function (e) { return e.source === node.id || e.target === node.id; });
        $("#edgeList").html(edges.length ? edges.map(function (e) {
            var dir = e.source === node.id ? "→ " + labelOf(e.target) : "← " + labelOf(e.source);
            return "<div class='edge-item'><span>" + AP.escapeHtml(dir) + "</span><button class='edge-delete' data-edge-id='" + AP.escapeHtml(e.id) + "'>" + AP.icon("x") + "</button></div>";
        }).join("") : "<div class='empty-catalog'>No connections.</div>");
    }

    function saveWorkflow(options) {
        options = options || {};
        if (!state.workflow) return $.Deferred().reject().promise();
        state.workflow.name = ($("#workflowName").val() || "").trim() || "Workflow";
        state.workflow.status = $("#workflowStatus").val() || "Draft";
        var $btn = $("#btnSaveWorkflow"); AP.setButtonLoading($btn, true, "Saving"); $("#saveState").html("<i></i>Saving to workflows.json…");
        return AP.ajax({ url: "/api/workflows/" + encodeURIComponent(state.workflow.id), method: "PUT", contentType: "application/json", dataType: "json", data: JSON.stringify(state.workflow) })
            .then(function () { return AP.ajax({ url: "/api/workflows/" + encodeURIComponent(state.workflow.id), method: "GET", dataType: "json" }); })
            .done(function (saved) { state.workflow = saved; normalize(); $("#versionBadge").text("v" + (state.workflow.version || 1)); $("#designerEnvironment").text(state.workflow.environment || "DEV"); var risk = state.workflow.riskLevel || "Low"; $("#designerRisk").text(risk + " risk").removeClass("risk-low risk-medium risk-high").addClass("risk-" + String(risk).toLowerCase()); $("#designerOwner").text(state.workflow.owner || "Agent Platform Team"); clearDirty("Saved · " + state.workflow.nodes.length + " nodes · " + state.workflow.edges.length + " connections"); renderAll(); if (!options.quiet) AP.toast("Workflow saved with enterprise audit metadata.", "success", "Saved"); })
            .fail(function (xhr) { $("#saveState").html("<i></i>Save failed").addClass("dirty"); AP.toast(xhr.responseJSON?.error || "Workflow could not be saved.", "error"); })
            .always(function () { AP.setButtonLoading($btn, false); });
    }

    function publishWorkflow() {
        if (!state.workflow) return;
        var $btn = $("#btnPublishWorkflow");
        saveWorkflow({ quiet: true }).done(function () {
            AP.setButtonLoading($btn, true, "Publishing");
            AP.ajax({ url: "/api/workflows/" + encodeURIComponent(state.workflow.id) + "/publish", method: "POST", dataType: "json" })
                .done(function (published) { state.workflow = published; normalize(); $("#workflowStatus").val("Published"); $("#versionBadge").text("v" + (published.version || 1)); clearDirty("Published · governed version " + (published.version || 1)); AP.toast("Workflow published with a new governed version and audit record.", "success", "Published"); })
                .fail(function (xhr) { var body = xhr.responseJSON || {}; var msg = body.error || "Workflow publish failed."; if (body.issues && body.issues.length) msg += " " + body.issues.join(" "); AP.toast(msg, "error", "Publish blocked"); })
                .always(function () { AP.setButtonLoading($btn, false); });
        });
    }

    function runWorkflow() {
        if (!state.workflow) return;
        var input = ($("#testWorkflowInput").val() || "").trim(); if (!input) { AP.toast("Enter a sample request first.", "warning"); return; }
        var $btn = $("#btnRunWorkflow"); AP.setButtonLoading($btn, true, "Running"); $("#testResult").addClass("hidden").empty();
        saveWorkflow({ quiet: true }).always(function () {
            AP.ajax({ url: "/api/workflows/" + encodeURIComponent(state.workflow.id) + "/execute", method: "POST", contentType: "application/json", dataType: "json", data: JSON.stringify({ input: input, context: { source: "designer-test" } }) })
                .done(function (r) {
                    var text = "Status: " + (r.status || "Unknown") + "\nExecution: " + (r.id || "") + "\n\nOutput:\n" + (r.lastOutput || "");
                    $("#testResult").removeClass("hidden").text(text); AP.toast("Execution started with status: " + r.status, "success", "Test complete");
                }).fail(function (xhr) { $("#testResult").removeClass("hidden").text(xhr.responseJSON?.error || xhr.responseText || "Execution failed."); AP.toast("Workflow test failed.", "error"); })
                .always(function () { AP.setButtonLoading($btn, false); });
        });
    }

    function deleteEdge(edgeId, options) {
        options = options || {};
        if (!state.workflow || !edgeId) return;
        var edge = state.workflow.edges.find(function (e) { return e.id === edgeId; });
        if (!edge) return;
        if (options.confirm && !window.confirm("Remove connection: " + labelOf(edge.source) + " → " + labelOf(edge.target) + "?")) return;
        state.workflow.edges = state.workflow.edges.filter(function (e) { return e.id !== edgeId; });
        if (state.selectedEdgeId === edgeId) state.selectedEdgeId = null;
        markDirty(); renderEdges(); renderInspector(); updateGuide();
        AP.toast("Connection removed. Save the workflow to persist the change.", "success", "Connection deleted");
    }

    function deleteSelected() {
        var node = selectedNode(); if (!node) return;
        if ((node.type === "start" || node.type === "end") && !window.confirm("Delete the " + node.type + " node?")) return;
        state.workflow.nodes = state.workflow.nodes.filter(function (n) { return n.id !== node.id; });
        state.workflow.edges = state.workflow.edges.filter(function (e) { return e.source !== node.id && e.target !== node.id; });
        state.selectedNodeId = null; markDirty(); renderAll(); updateGuide(); AP.toast("Node removed from the workflow.", "warning", "Node deleted");
    }
    function createEdge(sourceId, targetId) {
        if (!sourceId || !targetId || sourceId === targetId) return;
        if (state.workflow.edges.some(function (e) { return e.source === sourceId && e.target === targetId; })) { AP.toast("That connection already exists.", "warning"); return; }
        var s = state.workflow.nodes.find(function (n) { return n.id === sourceId; }), t = state.workflow.nodes.find(function (n) { return n.id === targetId; });
        if (!s || !t || s.type === "end" || t.type === "start") { AP.toast("This connection is not valid.", "warning"); return; }
        state.workflow.edges.push({ id: AP.newId("edge"), source: sourceId, target: targetId, condition: "always" }); markDirty(); renderEdges(); renderInspector(); updateGuide();
        AP.toast(s.label + " connected to " + t.label + ".", "success", "Flow connected");
    }
    function autoLayout() {
        if (!state.workflow) return;
        var indegree = {}, out = {}; state.workflow.nodes.forEach(function (n) { indegree[n.id] = 0; out[n.id] = []; });
        state.workflow.edges.forEach(function (e) { if (indegree[e.target] != null) indegree[e.target]++; if (out[e.source]) out[e.source].push(e.target); });
        var q = state.workflow.nodes.filter(function (n) { return n.type === "start" || indegree[n.id] === 0; }).map(function (n) { return { id: n.id, level: 0 }; }), levels = {}, seen = {};
        while (q.length) { var c = q.shift(); if (seen[c.id] && levels[c.id] <= c.level) continue; seen[c.id] = true; levels[c.id] = c.level; (out[c.id] || []).forEach(function (x) { q.push({ id: x, level: c.level + 1 }); }); }
        state.workflow.nodes.forEach(function (n, i) { if (levels[n.id] == null) levels[n.id] = i + 1; });
        var groups = {}; state.workflow.nodes.forEach(function (n) { (groups[levels[n.id]] = groups[levels[n.id]] || []).push(n); });
        Object.keys(groups).sort(function (a, b) { return +a - +b; }).forEach(function (k) { var arr = groups[k], center = 470; arr.forEach(function (n, i) { n.x = center - ((arr.length - 1) * 125) + i * 250; n.y = 80 + (+k) * 165; }); });
        markDirty(); renderAll(); AP.toast("Nodes arranged by execution level.", "success", "Auto layout");
    }
    function canvasCoordinates(clientX, clientY) { var canvas = document.getElementById("workflowCanvas"), r = canvas.getBoundingClientRect(); return { x: (clientX - r.left + canvas.scrollLeft) / state.zoom, y: (clientY - r.top + canvas.scrollTop) / state.zoom }; }
    function setZoom(next) { state.zoom = Math.max(.6, Math.min(1.45, next)); $("#canvasStage,#edgeSvg").css("transform", "scale(" + state.zoom + ")"); $("#zoomReset").text(Math.round(state.zoom * 100) + "%"); requestAnimationFrame(renderEdges); }
    function updateGuide() {
        if (!state.workflow) return;
        var extra = state.workflow.nodes.filter(function (n) { return n.type !== "start" && n.type !== "end"; }).length;
        var edges = state.workflow.edges.length;
        if (extra > 0 && edges > 1) $("#canvasGuideText");
    }

    function bindEvents() {
        $(document).off(".designer"); $(window).off(".designer"); $("#workflowCanvas").off(".designer");
        $(document).on("dragstart.designer", ".draggable-card", function (e) {
            var data = { kind: $(this).data("kind"), id: $(this).data("id") }; state.dragCatalogItem = data;
            e.originalEvent.dataTransfer.effectAllowed = "copy"; e.originalEvent.dataTransfer.setData("application/x-agent-platform", JSON.stringify(data));
        }).on("dragend.designer", ".draggable-card", function () { state.dragCatalogItem = null; $("#dropHint").addClass("hidden"); $("#workflowCanvas").removeClass("drag-active"); })
          .on("click.designer", ".catalog-add", function (e) { e.stopPropagation(); var $c = $(this).closest(".draggable-card"); addCatalogNode($c.data("kind"), findCatalog($c.data("kind"), $c.data("id"))); })
          .on("click.designer", ".common-node-btn", function () { addCommonNode($(this).data("node-type")); })
          .on("pointerdown.designer", ".workflow-node", function (e) {
              var id = $(this).data("node-id"); state.selectedNodeId = id; state.selectedEdgeId = null; $(".workflow-node").removeClass("selected"); $(this).addClass("selected"); renderInspector();
              if ($(e.target).hasClass("node-port")) return; var n = selectedNode(); if (!n) return; var p = canvasCoordinates(e.clientX, e.clientY); state.draggingNode = { id: id, dx: p.x - n.x, dy: p.y - n.y }; try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) { } e.preventDefault();
          }).on("pointermove.designer", function (e) {
              if (!state.active || !state.workflow) return;
              if (state.draggingNode) { var n = state.workflow.nodes.find(function (x) { return x.id === state.draggingNode.id; }); if (n) { var p = canvasCoordinates(e.clientX, e.clientY); n.x = Math.max(10, p.x - state.draggingNode.dx); n.y = Math.max(10, p.y - state.draggingNode.dy); $(".workflow-node[data-node-id='" + cssEscape(n.id) + "']").css({ left: n.x, top: n.y }); markDirty(); renderEdges(); } }
              if (state.connectionSource) { var a = portPoint(state.connectionSource, "out"), b = canvasCoordinates(e.clientX, e.clientY); if (a) $("#tempEdge").attr("d", edgePath(a, b)).removeClass("hidden"); }
          }).on("pointerup.designer pointercancel.designer", function () { state.draggingNode = null; if (state.connectionSource) { state.connectionSource = null; $("#tempEdge").addClass("hidden").attr("d", ""); } })
          .on("pointerdown.designer", ".port-out", function (e) { e.stopPropagation(); state.connectionSource = $(this).closest(".workflow-node").data("node-id"); e.preventDefault(); })
          .on("pointerup.designer", ".port-in", function (e) { e.stopPropagation(); var target = $(this).closest(".workflow-node").data("node-id"); if (state.connectionSource) createEdge(state.connectionSource, target); state.connectionSource = null; $("#tempEdge").addClass("hidden").attr("d", ""); })
          .on("click.designer", ".edge-delete,.connection-delete,#edgeQuickAction", function (e) { e.preventDefault(); e.stopPropagation(); var id = $(this).data("edge-id") || state.selectedEdgeId; deleteEdge(id); })
          .on("click.designer", ".workflow-edge-hit", function (e) { e.preventDefault(); e.stopPropagation(); state.selectedEdgeId = $(this).data("edge-id"); state.selectedNodeId = null; $(".workflow-node").removeClass("selected"); renderEdges(); renderInspector(); AP.toast("Connection selected. Use Remove or press Delete/Backspace.", "info", "Connection"); })
          .on("contextmenu.designer", ".workflow-edge-hit", function (e) { e.preventDefault(); e.stopPropagation(); state.selectedEdgeId = $(this).data("edge-id"); state.selectedNodeId = null; $(".workflow-node").removeClass("selected"); renderEdges(); renderInspector(); deleteEdge(state.selectedEdgeId, { confirm: true }); })
          .on("input.designer", "#selectedEdgeCondition", function () { var edge = selectedEdge(); if (!edge) return; edge.condition = $(this).val() || "always"; markDirty(); })
          .on("click.designer", ".remove-config", function () { $(this).closest(".config-row").remove(); syncConfig(); });

        $("#workflowCanvas").on("dragenter.designer dragover.designer", function (e) { e.preventDefault(); e.originalEvent.dataTransfer.dropEffect = "copy"; $(this).addClass("drag-active"); $("#dropHint").removeClass("hidden"); })
            .on("dragleave.designer", function (e) { if (!$.contains(this, e.relatedTarget)) { $(this).removeClass("drag-active"); $("#dropHint").addClass("hidden"); } })
            .on("drop.designer", function (e) {
                e.preventDefault(); $(this).removeClass("drag-active"); $("#dropHint").addClass("hidden"); var data = null;
                try { data = JSON.parse(e.originalEvent.dataTransfer.getData("application/x-agent-platform")); } catch (_) { data = state.dragCatalogItem; }
                data = data || state.dragCatalogItem; if (!data) return; var p = canvasCoordinates(e.originalEvent.clientX, e.originalEvent.clientY); addCatalogNode(data.kind, findCatalog(data.kind, data.id), { x: p.x - 110, y: p.y - 42 });
            }).on("click.designer", function (e) { if (e.target === this || e.target.id === "canvasStage") { state.selectedNodeId = null; state.selectedEdgeId = null; $(".workflow-node").removeClass("selected"); renderEdges(); renderInspector(); } });

        $("#nodeLabel").off(".designer").on("input.designer", function () { var n = selectedNode(); if (!n) return; n.label = $(this).val() || "Node"; markDirty(); renderNodes(); requestAnimationFrame(renderEdges); });
        $("#nodeBinding").off(".designer").on("change.designer", function () { var n = selectedNode(); if (!n) return; var key = n.type === "agent" ? "agentId" : n.type === "dataSource" ? "connectorId" : "toolId"; n.config[key] = $(this).val() || ""; var item = n.type === "dataSource" ? findConnector(n.config[key]) : findCatalog(n.type === "agent" ? "agent" : "tool", n.config[key]); if (item) n.label = item.name; if (n.type === "dataSource" && item && item.operations && item.operations.length && !n.config.operation) n.config.operation = item.operations[0].id; markDirty(); renderAll(); });
        $("#btnAddConfig").off(".designer").on("click.designer", function () { var n = selectedNode(); if (!n) return; var key = "key" + (Object.keys(n.config).length + 1); n.config[key] = ""; markDirty(); renderInspector(); });
        $(document).on("change.designer", ".config-key,.config-value", syncConfig);
        $("#btnDeleteNode").off(".designer").on("click.designer", deleteSelected);
        $("#btnSaveWorkflow").off(".designer").on("click.designer", function () { saveWorkflow(); });
        $("#btnPublishWorkflow").off(".designer").on("click.designer", publishWorkflow);
        $("#btnAutoLayout").off(".designer").on("click.designer", autoLayout);
        $("#btnTestWorkflow").off(".designer").on("click.designer", function () { $("#testResult").addClass("hidden").empty(); AP.openModal("#testWorkflowModal"); setTimeout(function () { $("#testWorkflowInput").trigger("focus"); }, 50); });
        $("#btnRunWorkflow").off(".designer").on("click.designer", runWorkflow);
        $("[data-close-test]").off(".designer").on("click.designer", function () { AP.closeModal("#testWorkflowModal"); });
        $("#workflowName,#workflowStatus").off(".designer").on("input.designer change.designer", markDirty);
        $("#discoverySearch").off(".designer").on("input.designer", AP.debounce(function () { loadDiscovery($(this).val() || ""); }, 160));
        $("#zoomIn").off(".designer").on("click.designer", function () { setZoom(state.zoom + .1); });
        $("#zoomOut").off(".designer").on("click.designer", function () { setZoom(state.zoom - .1); });
        $("#zoomReset").off(".designer").on("click.designer", function () { setZoom(1); });
        $("#dismissCanvasGuide").off(".designer").on("click.designer", function () { $(".canvas-guide").fadeOut(180); sessionStorage.setItem("designerGuideDismissed", "1"); });
        if (sessionStorage.getItem("designerGuideDismissed")) $(".canvas-guide").hide(); else $(".canvas-guide").show();
        $(document).on("keydown.designer", function (e) {
            var tag = (e.target.tagName || "").toLowerCase();
            if ((e.key === "Delete" || e.key === "Backspace") && tag !== "input" && tag !== "textarea" && state.selectedEdgeId) {
                e.preventDefault(); deleteEdge(state.selectedEdgeId);
            }
        });
        $(window).on("resize.designer", renderEdges);
    }

    function syncConfig() {
        var n = selectedNode(); if (!n) return; var next = {};
        if (n.type === "agent" && n.config.agentId) next.agentId = n.config.agentId;
        if ((n.type === "tool" || n.type === "mail") && n.config.toolId) next.toolId = n.config.toolId;
        if (n.type === "dataSource" && n.config.connectorId) next.connectorId = n.config.connectorId;
        $("#configFields .config-row").each(function () { var k = ($(this).find(".config-key").val() || "").trim(); if (k) next[k] = $(this).find(".config-value").val() || ""; }); n.config = next; markDirty();
    }

    window.AgentDesigner = {
        init: function (id) {
            state.active = true; state.id = id; state.workflow = null; state.selectedNodeId = null; state.selectedEdgeId = null; state.zoom = 1; state.dirty = false;
            $("#zoomReset").text("100%"); $("#canvasStage,#edgeSvg").css("transform", "scale(1)"); bindEvents();
            loadDiscovery(""); loadConnectors(); loadWorkflow();
        },
        destroy: function () { state.active = false; state.draggingNode = null; state.connectionSource = null; $(document).off(".designer"); $(window).off(".designer"); $("#workflowCanvas").off(".designer"); },
        isDirty: function () { return !!state.dirty; },
        save: function () { return saveWorkflow(); }
    };
})(jQuery, AgentPlatform);
