using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class TemplateResolver
{
    private static readonly Regex TokenRegex = new("\\{\\{\\s*([^{}]+?)\\s*\\}\\}", RegexOptions.Compiled);

    public string Resolve(string? template, ExecutionRecord execution)
    {
        template ??= "";
        return TokenRegex.Replace(template, match =>
        {
            var path = match.Groups[1].Value.Trim();
            if (path.Equals("input", StringComparison.OrdinalIgnoreCase)) return execution.Input;
            if (path.Equals("lastOutput", StringComparison.OrdinalIgnoreCase)) return execution.LastOutput;
            var node = GetPath(GetVariables(execution), path.Replace("variables.", "", StringComparison.OrdinalIgnoreCase));
            return NodeToString(node);
        });
    }

    public JsonNode? ResolveNode(string? expression, ExecutionRecord execution)
    {
        expression ??= "";
        var trimmed = expression.Trim();
        var m = Regex.Match(trimmed, "^\\{\\{\\s*([^{}]+?)\\s*\\}\\}$");
        if (m.Success)
        {
            var path = m.Groups[1].Value.Trim().Replace("variables.", "", StringComparison.OrdinalIgnoreCase);
            if (path.Equals("input", StringComparison.OrdinalIgnoreCase)) return ParseMaybeJson(execution.Input);
            if (path.Equals("lastOutput", StringComparison.OrdinalIgnoreCase)) return ParseMaybeJson(execution.LastOutput);
            return GetPath(GetVariables(execution), path)?.DeepClone();
        }
        return JsonValue.Create(Resolve(trimmed, execution));
    }

    public JsonObject GetVariables(ExecutionRecord execution)
    {
        if (execution.State["variables"] is JsonObject variables) return variables;
        variables = new JsonObject();
        execution.State["variables"] = variables;
        return variables;
    }

    public void SetVariable(ExecutionRecord execution, string name, JsonNode? value)
    {
        if (string.IsNullOrWhiteSpace(name)) return;
        var variables = GetVariables(execution);
        SetPath(variables, name.Trim(), value?.DeepClone());
    }

    public JsonNode? GetVariable(ExecutionRecord execution, string path) => GetPath(GetVariables(execution), path);

    public static JsonNode? ParseMaybeJson(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return JsonValue.Create(value ?? "");
        try { return JsonNode.Parse(value); }
        catch { return JsonValue.Create(value); }
    }

    public static string NodeToString(JsonNode? node)
    {
        if (node is null) return "";
        if (node is JsonValue v)
        {
            if (v.TryGetValue<string>(out var s)) return s ?? "";
            if (v.TryGetValue<bool>(out var b)) return b ? "true" : "false";
            if (v.TryGetValue<double>(out var d)) return d.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }
        return node.ToJsonString(new JsonSerializerOptions { WriteIndented = false });
    }

    public static JsonNode? GetPath(JsonNode? root, string path)
    {
        if (root is null || string.IsNullOrWhiteSpace(path)) return root;
        JsonNode? current = root;
        foreach (var raw in path.Split('.', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries))
        {
            if (current is JsonObject obj)
            {
                current = obj.FirstOrDefault(kv => kv.Key.Equals(raw, StringComparison.OrdinalIgnoreCase)).Value;
                continue;
            }
            if (current is JsonArray arr && int.TryParse(raw, out var i) && i >= 0 && i < arr.Count)
            {
                current = arr[i];
                continue;
            }
            return null;
        }
        return current;
    }

    private static void SetPath(JsonObject root, string path, JsonNode? value)
    {
        var parts = path.Split('.', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 0) return;
        JsonObject current = root;
        for (var i = 0; i < parts.Length - 1; i++)
        {
            var key = parts[i];
            if (current[key] is not JsonObject child)
            {
                child = new JsonObject();
                current[key] = child;
            }
            current = child;
        }
        current[parts[^1]] = value;
    }
}
