using System.Security.Cryptography;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class FileStorageService(IWebHostEnvironment env, RegistryService registry)
{
    public async Task<StoredFileRecord> SaveAsync(IFormFile file, string userId, CancellationToken ct)
    {
        if (file.Length <= 0) throw new InvalidOperationException("The uploaded file is empty.");
        if (file.Length > 50 * 1024 * 1024) throw new InvalidOperationException("Demo upload limit is 50 MB.");
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        var allowed = new[] { ".csv", ".json", ".txt", ".xml", ".pdf", ".xlsx" };
        if (!allowed.Contains(ext)) throw new InvalidOperationException($"File type '{ext}' is not allowed.");

        var root = Path.Combine(env.ContentRootPath, "Data", "uploads");
        Directory.CreateDirectory(root);
        var id = Guid.NewGuid().ToString("N");
        var safeName = Path.GetFileName(file.FileName);
        var path = Path.Combine(root, id + ext);
        await using (var target = File.Create(path)) await file.CopyToAsync(target, ct);
        await using var read = File.OpenRead(path);
        var hash = Convert.ToHexString(await SHA256.HashDataAsync(read, ct)).ToLowerInvariant();
        var record = new StoredFileRecord
        {
            FileId = id, FileName = safeName, ContentType = file.ContentType ?? "application/octet-stream", SizeBytes = file.Length,
            RelativePath = Path.GetRelativePath(env.ContentRootPath, path).Replace('\\', '/'), Sha256 = hash, UploadedBy = userId
        };
        await registry.Files.UpsertAsync(record);
        return record;
    }
}
