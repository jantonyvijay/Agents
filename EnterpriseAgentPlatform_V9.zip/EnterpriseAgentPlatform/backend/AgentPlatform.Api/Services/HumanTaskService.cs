using System.Text.Json.Nodes;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class HumanTaskService(RegistryService registry)
{
    public async Task<HumanTaskRecord?> FindNodeTaskAsync(string executionId, string nodeId, params string[] taskTypes)
    {
        var tasks = await registry.HumanTasks.GetAllAsync();
        return tasks.Where(t => t.ExecutionId == executionId && t.NodeId == nodeId && (taskTypes.Length == 0 || taskTypes.Contains(t.TaskType, StringComparer.OrdinalIgnoreCase)))
            .OrderByDescending(t => t.CreatedAtUtc).FirstOrDefault();
    }

    public async Task<List<HumanTaskRecord>> GetExecutionNodeTasksAsync(string executionId, string nodeId) =>
        (await registry.HumanTasks.GetAllAsync()).Where(t => t.ExecutionId == executionId && t.NodeId == nodeId).OrderBy(t => t.CreatedAtUtc).ToList();

    public Task<HumanTaskRecord> CreateAsync(ExecutionRecord execution, WorkflowNode node, string taskType, string title, string createdBy, string assignedRole, string? makerUserId = null)
    {
        var hours = 24;
        if (node.Config.TryGetValue("slaHours", out var raw) && int.TryParse(raw, out var parsed)) hours = Math.Clamp(parsed, 1, 720);
        var task = new HumanTaskRecord
        {
            ExecutionId = execution.Id, WorkflowId = execution.WorkflowId, NodeId = node.Id, TaskType = taskType, Title = title,
            CreatedBy = createdBy, AssignedRole = assignedRole, MakerUserId = makerUserId, DueAtUtc = DateTimeOffset.UtcNow.AddHours(hours),
            Config = new Dictionary<string, string>(node.Config, StringComparer.OrdinalIgnoreCase)
        };
        return registry.HumanTasks.UpsertAsync(task);
    }

    public async Task<HumanTaskRecord> SubmitAsync(string taskId, JsonObject? values, string? comment, string userId)
    {
        var task = await registry.HumanTasks.GetAsync(taskId) ?? throw new KeyNotFoundException("Task not found.");
        if (!task.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Task is not pending.");
        if (!new[] { "UserInput", "FileUpload", "Maker" }.Contains(task.TaskType, StringComparer.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Task type '{task.TaskType}' must be completed through the decision endpoint.");
        task.Payload = values?.DeepClone() as JsonObject ?? new JsonObject();
        task.Comment = comment;
        task.CompletedBy = userId;
        task.CompletedAtUtc = DateTimeOffset.UtcNow;
        task.Status = "Submitted";
        return await registry.HumanTasks.UpsertAsync(task);
    }

    public async Task<HumanTaskRecord> DecideAsync(string taskId, string decision, string? comment, string userId)
    {
        var task = await registry.HumanTasks.GetAsync(taskId) ?? throw new KeyNotFoundException("Task not found.");
        if (!task.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Task is not pending.");
        if (!new[] { "Approval", "Checker" }.Contains(task.TaskType, StringComparer.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Task type '{task.TaskType}' must be completed through the submit endpoint.");
        decision = (decision ?? "").Trim();
        if (!new[] { "Approve", "Reject", "SendBack" }.Contains(decision, StringComparer.OrdinalIgnoreCase))
            throw new InvalidOperationException("Decision must be Approve, Reject or SendBack.");
        if (task.TaskType.Equals("Checker", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(task.MakerUserId) && task.MakerUserId.Equals(userId, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Maker cannot approve/check their own request.");
        var commentRequired = !task.Config.TryGetValue("commentsRequiredOnReject", out var required) || !required.Equals("false", StringComparison.OrdinalIgnoreCase);
        if (commentRequired && (decision.Equals("Reject", StringComparison.OrdinalIgnoreCase) || decision.Equals("SendBack", StringComparison.OrdinalIgnoreCase)) && string.IsNullOrWhiteSpace(comment))
            throw new InvalidOperationException("A comment is required for Reject or Send Back.");
        task.Decision = decision;
        task.Comment = comment;
        task.CompletedBy = userId;
        task.CompletedAtUtc = DateTimeOffset.UtcNow;
        task.Status = decision.Equals("Approve", StringComparison.OrdinalIgnoreCase) ? "Approved" : decision.Equals("Reject", StringComparison.OrdinalIgnoreCase) ? "Rejected" : "SentBack";
        return await registry.HumanTasks.UpsertAsync(task);
    }
}
