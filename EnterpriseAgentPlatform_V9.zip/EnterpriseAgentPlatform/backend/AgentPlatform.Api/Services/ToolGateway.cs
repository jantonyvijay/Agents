using System.Text;
using System.Text.Json;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class ToolGateway(HttpClient http, McpClientService mcp, RegistryService registry)
{
    public async Task<string> ExecuteAsync(ToolDefinition tool, string input, string environment, ExecutionRecord execution, TemplateResolver resolver, CancellationToken ct)
    {
        if (!tool.Enabled) throw new InvalidOperationException($"Tool '{tool.Name}' is disabled.");
        if (tool.Config.TryGetValue("allowedEnvironments", out var allowed) && !string.IsNullOrWhiteSpace(allowed))
        {
            var environments = allowed.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
            if (!environments.Contains(environment, StringComparer.OrdinalIgnoreCase))
                throw new InvalidOperationException($"Tool '{tool.Name}' is not approved for environment '{environment}'.");
        }

        if (tool.Type.Equals("mock", StringComparison.OrdinalIgnoreCase))
            return ResolveToolTemplate(tool.Config.GetValueOrDefault("response", "Mock tool result for: {{toolInput}}"), input, execution, resolver);

        if (tool.Type.Equals("mcp", StringComparison.OrdinalIgnoreCase))
            return await mcp.CallAsync(tool, input, ct);

        if (tool.Type.Equals("mail-api", StringComparison.OrdinalIgnoreCase))
            return await ExecuteMailApiAsync(tool, input, execution, resolver, ct);

        if (!tool.Type.Equals("http", StringComparison.OrdinalIgnoreCase))
            throw new NotSupportedException($"Tool type '{tool.Type}' is not supported.");

        return await ExecuteHttpAsync(tool, input, execution, resolver, ct);
    }

    private async Task<string> ExecuteHttpAsync(ToolDefinition tool, string input, ExecutionRecord execution, TemplateResolver resolver, CancellationToken ct)
    {
        if (!tool.Config.TryGetValue("url", out var url) || string.IsNullOrWhiteSpace(url))
            throw new InvalidOperationException("HTTP tool requires config.url.");
        var resolvedUrl = ResolveToolTemplate(url, input, execution, resolver, urlEncodeInput: true);
        var method = tool.Config.GetValueOrDefault("method", "GET").ToUpperInvariant();
        using var req = new HttpRequestMessage(new HttpMethod(method), resolvedUrl);
        if (method is "POST" or "PUT" or "PATCH")
        {
            var bodyTemplate = tool.Config.GetValueOrDefault("body", "{\"input\":\"{{toolInput}}\"}");
            var body = ResolveToolTemplate(bodyTemplate, input, execution, resolver, jsonEncodeInput: true);
            req.Content = new StringContent(body, Encoding.UTF8, tool.Config.GetValueOrDefault("contentType", "application/json"));
        }
        AddAuthentication(tool, req);
        using var res = await http.SendAsync(req, ct);
        var result = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode) throw new InvalidOperationException($"Tool call failed ({(int)res.StatusCode}): {result}");
        return result;
    }

    private async Task<string> ExecuteMailApiAsync(ToolDefinition tool, string input, ExecutionRecord execution, TemplateResolver resolver, CancellationToken ct)
    {
        var subjectTemplate = tool.Config.GetValueOrDefault("subject", "Workflow notification");
        var bodyTemplate = tool.Config.GetValueOrDefault("body", input);
        if (tool.Config.TryGetValue("templateId", out var templateId) && !string.IsNullOrWhiteSpace(templateId))
        {
            var template = await registry.MailTemplates.GetAsync(templateId);
            if (template is not null && template.Enabled) { subjectTemplate = template.Subject; bodyTemplate = template.Body; }
        }
        var url = tool.Config.GetValueOrDefault("url");
        if (string.IsNullOrWhiteSpace(url))
        {
            // Safe demo mode: prove resolved mail payload without sending externally.
            return JsonSerializer.Serialize(new
            {
                sent = false,
                demo = true,
                to = resolver.Resolve(tool.Config.GetValueOrDefault("to", "{{input.email}}"), execution),
                subject = resolver.Resolve(subjectTemplate, execution),
                body = resolver.Resolve(bodyTemplate, execution)
            });
        }

        var payload = new
        {
            to = resolver.Resolve(tool.Config.GetValueOrDefault("to", "{{input.email}}"), execution),
            cc = resolver.Resolve(tool.Config.GetValueOrDefault("cc", ""), execution),
            subject = resolver.Resolve(subjectTemplate, execution),
            body = resolver.Resolve(bodyTemplate, execution),
            correlationId = execution.CorrelationId
        };
        using var req = new HttpRequestMessage(HttpMethod.Post, resolver.Resolve(url, execution));
        req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
        AddAuthentication(tool, req);
        using var res = await http.SendAsync(req, ct);
        var result = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode) throw new InvalidOperationException($"Mail API failed ({(int)res.StatusCode}): {result}");
        return result;
    }

    private static string ResolveToolTemplate(string template, string input, ExecutionRecord execution, TemplateResolver resolver, bool urlEncodeInput = false, bool jsonEncodeInput = false)
    {
        // Keep the current tool input separate from the workflow variable named `input`.
        // Workflow data remains addressable as {{input.customerId}}, while tool adapters use {{toolInput}}.
        const string sentinel = "__EAP_CURRENT_TOOL_INPUT_6F06E29C__";
        var prepared = (template ?? "").Replace("{{toolInput}}", sentinel, StringComparison.OrdinalIgnoreCase);
        var resolved = resolver.Resolve(prepared, execution);
        var replacement = urlEncodeInput ? Uri.EscapeDataString(input) : jsonEncodeInput ? JsonEncodedText.Encode(input).ToString() : input;
        return resolved.Replace(sentinel, replacement, StringComparison.Ordinal);
    }

    private static void AddAuthentication(ToolDefinition tool, HttpRequestMessage req)
    {
        if (tool.Config.TryGetValue("bearerTokenEnvVar", out var envName) && !string.IsNullOrWhiteSpace(envName))
        {
            var token = Environment.GetEnvironmentVariable(envName);
            if (!string.IsNullOrWhiteSpace(token)) req.Headers.Authorization = new("Bearer", token);
        }
        if (tool.Config.TryGetValue("apiKeyEnvVar", out var keyEnv) && tool.Config.TryGetValue("apiKeyHeader", out var header) && !string.IsNullOrWhiteSpace(keyEnv) && !string.IsNullOrWhiteSpace(header))
        {
            var key = Environment.GetEnvironmentVariable(keyEnv);
            if (!string.IsNullOrWhiteSpace(key)) req.Headers.TryAddWithoutValidation(header, key);
        }
    }
}
