using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using AgentPlatform.Api.Models;
using AgentPlatform.Api.Services.NodeHandlers;

namespace AgentPlatform.Api.Services;

public sealed class WorkflowRuntime(
    RegistryService registry,
    WorkflowNodeHandlerRegistry handlers,
    TemplateResolver resolver,
    HumanTaskService humanTasks,
    ILogger<WorkflowRuntime> logger)
{
    public async Task<ExecutionRecord> StartAsync(WorkflowDefinition workflow, string input, string tenantId, string environment, string userId, Dictionary<string, string>? context, CancellationToken ct)
    {
        var start = workflow.Nodes.FirstOrDefault(n => n.Type.Equals("start", StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("Workflow requires a start node.");

        var execution = new ExecutionRecord
        {
            WorkflowId = workflow.Id,
            WorkflowVersion = workflow.Version,
            TenantId = tenantId,
            Environment = environment,
            UserId = userId,
            Input = input,
            CurrentNodeId = start.Id,
            LastOutput = input,
            Status = "Running"
        };
        execution.State["variables"] = new JsonObject { ["input"] = TemplateResolver.ParseMaybeJson(input) };
        execution.State["__queue"] = new JsonArray();
        execution.State["__completed"] = new JsonArray();
        if (context is not null)
            foreach (var pair in context) resolver.SetVariable(execution, "context." + pair.Key, TemplateResolver.ParseMaybeJson(pair.Value));

        await registry.Executions.UpsertAsync(execution);
        return await RunAsync(workflow, execution, ct);
    }

    public async Task<ExecutionRecord> ResumeAsync(string executionId, CancellationToken ct)
    {
        var execution = await registry.Executions.GetAsync(executionId) ?? throw new KeyNotFoundException("Execution not found.");
        var workflow = await registry.Workflows.GetAsync(execution.WorkflowId) ?? throw new KeyNotFoundException("Workflow not found.");
        if (execution.CurrentNodeId is null) throw new InvalidOperationException("Execution has no resumable current node.");
        if (execution.Status is "Completed" or "Rejected" or "Failed" or "Cancelled") return execution;
        execution.Status = "Running";
        await registry.Executions.UpsertAsync(execution);
        return await RunAsync(workflow, execution, ct);
    }

    // Compatibility helper for the earlier execution approval endpoint.
    public async Task<ExecutionRecord> ApproveAsync(string executionId, bool approved, string? comment, string userId, CancellationToken ct)
    {
        var tasks = (await registry.HumanTasks.GetAllAsync())
            .Where(t => t.ExecutionId == executionId && t.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase) && (t.TaskType.Equals("Approval", StringComparison.OrdinalIgnoreCase) || t.TaskType.Equals("Checker", StringComparison.OrdinalIgnoreCase)))
            .OrderByDescending(t => t.CreatedAtUtc).ToList();
        var task = tasks.FirstOrDefault() ?? throw new InvalidOperationException("Execution has no pending approval/checker task.");
        await humanTasks.DecideAsync(task.Id, approved ? "Approve" : "Reject", comment, userId);
        return await ResumeAsync(executionId, ct);
    }

    private async Task<ExecutionRecord> RunAsync(WorkflowDefinition workflow, ExecutionRecord execution, CancellationToken ct)
    {
        var safetyCounter = 0;
        while (execution.CurrentNodeId is not null && safetyCounter++ < 500)
        {
            ct.ThrowIfCancellationRequested();
            var node = workflow.Nodes.FirstOrDefault(n => n.Id == execution.CurrentNodeId)
                ?? throw new InvalidOperationException($"Node '{execution.CurrentNodeId}' not found.");

            try
            {
                if (node.Type.Equals("join", StringComparison.OrdinalIgnoreCase) && !JoinReady(workflow, node, execution))
                {
                    Log(execution, node, "Join waiting for remaining incoming branches.");
                    execution.CurrentNodeId = Dequeue(execution);
                    if (execution.CurrentNodeId is null)
                        throw new InvalidOperationException($"Join '{node.Label}' cannot continue because required incoming branches are incomplete.");
                    await registry.Executions.UpsertAsync(execution);
                    continue;
                }

                Log(execution, node, $"Executing {node.Label}.");
                var handler = handlers.Get(node.Type) ?? throw new NotSupportedException($"Node type '{node.Type}' is not supported.");
                var result = await handler.ExecuteAsync(new NodeExecutionContext { Workflow = workflow, Node = node, Execution = execution, CancellationToken = ct });
                if (!string.IsNullOrWhiteSpace(result.Message)) Log(execution, node, result.Message!);

                if (result.Pause)
                {
                    execution.Status = result.PauseStatus ?? "Paused";
                    await registry.Executions.UpsertAsync(execution);
                    return execution;
                }
                if (result.Terminate)
                {
                    execution.Status = result.TerminalStatus ?? "Completed";
                    execution.CompletedAtUtc = DateTimeOffset.UtcNow;
                    execution.CurrentNodeId = null;
                    await registry.Executions.UpsertAsync(execution);
                    return execution;
                }

                if (result.Output is not null)
                {
                    execution.LastOutput = TemplateResolver.NodeToString(result.Output);
                    var outputs = execution.State["nodeOutputs"] as JsonObject ?? new JsonObject();
                    execution.State["nodeOutputs"] = outputs;
                    outputs[node.Id] = result.Output.DeepClone();
                    if (node.Config.TryGetValue("outputVariable", out var outputVariable) && !string.IsNullOrWhiteSpace(outputVariable))
                        resolver.SetVariable(execution, outputVariable, result.Output);
                }

                MarkCompleted(execution, node.Id);

                if (node.Type.Equals("end", StringComparison.OrdinalIgnoreCase))
                {
                    execution.CurrentNodeId = Dequeue(execution);
                    if (execution.CurrentNodeId is not null)
                    {
                        await registry.Executions.UpsertAsync(execution);
                        continue;
                    }
                    execution.Status = "Completed";
                    execution.CompletedAtUtc = DateTimeOffset.UtcNow;
                    Log(execution, node, "Workflow completed.");
                    await registry.Executions.UpsertAsync(execution);
                    return execution;
                }

                if (node.Type.Equals("decision", StringComparison.OrdinalIgnoreCase))
                {
                    execution.CurrentNodeId = SelectDecisionTarget(workflow, node, execution);
                }
                else if (node.Type.Equals("parallel", StringComparison.OrdinalIgnoreCase))
                {
                    var branches = workflow.Edges.Where(e => e.Source == node.Id).Select(e => e.Target).Distinct().ToList();
                    foreach (var branch in branches) Enqueue(execution, branch);
                    execution.CurrentNodeId = Dequeue(execution);
                }
                else
                {
                    execution.CurrentNodeId = SelectDefaultTarget(workflow, node.Id) ?? Dequeue(execution);
                }

                if (execution.CurrentNodeId is null)
                {
                    execution.Status = "Completed";
                    execution.CompletedAtUtc = DateTimeOffset.UtcNow;
                }
                await registry.Executions.UpsertAsync(execution);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Workflow {WorkflowId} execution {ExecutionId} failed at node {NodeId}", workflow.Id, execution.Id, node.Id);
                Log(execution, node, ex.Message, "Error");
                execution.Status = "Failed";
                execution.CompletedAtUtc = DateTimeOffset.UtcNow;
                await registry.Executions.UpsertAsync(execution);
                return execution;
            }
        }

        if (safetyCounter >= 500)
        {
            execution.Status = "Failed";
            execution.Logs.Add(new() { NodeId = execution.CurrentNodeId ?? "", NodeType = "runtime", Level = "Error", Message = "Execution stopped by cycle safety limit." });
            execution.CompletedAtUtc = DateTimeOffset.UtcNow;
            await registry.Executions.UpsertAsync(execution);
        }
        return execution;
    }

    private bool JoinReady(WorkflowDefinition workflow, WorkflowNode join, ExecutionRecord execution)
    {
        var incoming = workflow.Edges.Where(e => e.Target == join.Id).Select(e => e.Source).Distinct().ToList();
        if (incoming.Count <= 1) return true;
        var completed = Completed(execution);
        return incoming.All(completed.Contains);
    }

    private string? SelectDecisionTarget(WorkflowDefinition workflow, WorkflowNode node, ExecutionRecord execution)
    {
        var edges = workflow.Edges.Where(e => e.Source == node.Id).ToList();
        foreach (var edge in edges)
        {
            var condition = edge.Condition?.Trim() ?? "always";
            if (condition.Equals("always", StringComparison.OrdinalIgnoreCase)) continue;
            if (EvaluateCondition(condition, execution)) return edge.Target;
        }
        return edges.FirstOrDefault(e => string.IsNullOrWhiteSpace(e.Condition) || e.Condition.Equals("always", StringComparison.OrdinalIgnoreCase))?.Target;
    }

    private bool EvaluateCondition(string condition, ExecutionRecord execution)
    {
        if (condition.StartsWith("contains:", StringComparison.OrdinalIgnoreCase)) return execution.LastOutput.Contains(condition[9..], StringComparison.OrdinalIgnoreCase);
        if (condition.StartsWith("equals:", StringComparison.OrdinalIgnoreCase)) return execution.LastOutput.Equals(condition[7..], StringComparison.OrdinalIgnoreCase);
        var match = Regex.Match(condition, @"^\s*(\{\{.+?\}\})\s*(==|!=)\s*(.+?)\s*$", RegexOptions.IgnoreCase);
        if (!match.Success) return false;
        var left = TemplateResolver.NodeToString(resolver.ResolveNode(match.Groups[1].Value, execution)).Trim('"');
        var right = resolver.Resolve(match.Groups[3].Value.Trim().Trim('"', '\''), execution).Trim('"');
        var equals = left.Equals(right, StringComparison.OrdinalIgnoreCase);
        return match.Groups[2].Value == "==" ? equals : !equals;
    }

    private static string? SelectDefaultTarget(WorkflowDefinition workflow, string nodeId) =>
        workflow.Edges.FirstOrDefault(e => e.Source == nodeId && (string.IsNullOrWhiteSpace(e.Condition) || e.Condition.Equals("always", StringComparison.OrdinalIgnoreCase)))?.Target
        ?? workflow.Edges.FirstOrDefault(e => e.Source == nodeId)?.Target;

    private static JsonArray Queue(ExecutionRecord execution)
    {
        if (execution.State["__queue"] is JsonArray q) return q;
        q = new JsonArray(); execution.State["__queue"] = q; return q;
    }
    private static void Enqueue(ExecutionRecord execution, string? nodeId)
    {
        if (string.IsNullOrWhiteSpace(nodeId)) return;
        var q = Queue(execution);
        if (!q.Any(x => string.Equals(x?.GetValue<string>(), nodeId, StringComparison.Ordinal))) q.Add(nodeId);
    }
    private static string? Dequeue(ExecutionRecord execution)
    {
        var q = Queue(execution);
        if (q.Count == 0) return null;
        var id = q[0]?.GetValue<string>(); q.RemoveAt(0); return id;
    }
    private static HashSet<string> Completed(ExecutionRecord execution)
    {
        var arr = execution.State["__completed"] as JsonArray ?? new JsonArray();
        execution.State["__completed"] = arr;
        return arr.Select(x => x?.GetValue<string>()).Where(x => !string.IsNullOrWhiteSpace(x)).Cast<string>().ToHashSet(StringComparer.Ordinal);
    }
    private static void MarkCompleted(ExecutionRecord execution, string nodeId)
    {
        var arr = execution.State["__completed"] as JsonArray ?? new JsonArray();
        execution.State["__completed"] = arr;
        if (!arr.Any(x => string.Equals(x?.GetValue<string>(), nodeId, StringComparison.Ordinal))) arr.Add(nodeId);
    }

    private static void Log(ExecutionRecord execution, WorkflowNode node, string message, string level = "Information") =>
        execution.Logs.Add(new() { NodeId = node.Id, NodeType = node.Type, Level = level, Message = message });
}
