using AgentPlatform.Api.Services;
namespace AgentPlatform.Api.Services.NodeHandlers;

public sealed class DataSourceNodeHandler(RegistryService registry, ConnectorGateway gateway, TemplateResolver resolver) : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "datasource", "dataSource", "fcQuery", "dcpftp" };

    public async Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context)
    {
        var connectorId = context.Node.Config.GetValueOrDefault("connectorId") ?? throw new InvalidOperationException("Data Source node requires config.connectorId.");
        var operation = context.Node.Config.GetValueOrDefault("operation", "read");
        var connector = await registry.Connectors.GetAsync(connectorId) ?? throw new InvalidOperationException($"Connector '{connectorId}' not found.");
        var parameters = context.Node.Config.Where(x => x.Key.StartsWith("param.", StringComparison.OrdinalIgnoreCase))
            .ToDictionary(x => x.Key[6..], x => x.Value, StringComparer.OrdinalIgnoreCase);
        var output = await gateway.ExecuteAsync(connector, operation, parameters, context.Execution, resolver, context.CancellationToken);
        return NodeExecutionResult.Continue(output, $"Connector '{connector.Name}' operation '{operation}' completed.");
    }
}
