namespace AgentPlatform.Api.Services.NodeHandlers;

public sealed class NoOpNodeHandler : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "start", "decision", "parallel", "join", "end" };
    public Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context) => Task.FromResult(NodeExecutionResult.Continue(message: $"{context.Node.Type} routing node."));
}
