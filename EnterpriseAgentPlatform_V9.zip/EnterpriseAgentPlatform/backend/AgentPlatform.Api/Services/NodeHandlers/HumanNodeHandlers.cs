using AgentPlatform.Api.Services;
using System.Text.Json.Nodes;

namespace AgentPlatform.Api.Services.NodeHandlers;

public sealed class UserInputNodeHandler(HumanTaskService tasks, TemplateResolver resolver) : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "userInput", "fileUpload" };

    public async Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context)
    {
        var taskType = context.Node.Type.Equals("fileUpload", StringComparison.OrdinalIgnoreCase) ? "FileUpload" : "UserInput";
        var task = await tasks.FindNodeTaskAsync(context.Execution.Id, context.Node.Id, taskType);
        if (task is null)
        {
            var role = context.Node.Config.GetValueOrDefault("assignedRole", "WorkflowUser");
            await tasks.CreateAsync(context.Execution, context.Node, taskType, context.Node.Label, context.Execution.UserId, role);
            return NodeExecutionResult.Wait(taskType == "FileUpload" ? "WaitingForFile" : "WaitingForInput", $"Created {taskType} task.");
        }
        if (task.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase))
            return NodeExecutionResult.Wait(taskType == "FileUpload" ? "WaitingForFile" : "WaitingForInput", $"Waiting for {taskType} task {task.Id}.");
        return NodeExecutionResult.Continue(task.Payload.DeepClone(), $"{taskType} received from {task.CompletedBy}.");
    }
}

public sealed class ApprovalNodeHandler(HumanTaskService tasks) : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "approval" };

    public async Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context)
    {
        var task = await tasks.FindNodeTaskAsync(context.Execution.Id, context.Node.Id, "Approval");
        if (task is null)
        {
            var role = context.Node.Config.GetValueOrDefault("approverRole", "Approver");
            await tasks.CreateAsync(context.Execution, context.Node, "Approval", context.Node.Label, context.Execution.UserId, role);
            return NodeExecutionResult.Wait("AwaitingApproval", "Approval task created.");
        }
        if (task.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase)) return NodeExecutionResult.Wait("AwaitingApproval", "Waiting for approval.");
        if (task.Status.Equals("Rejected", StringComparison.OrdinalIgnoreCase)) return NodeExecutionResult.Stop("Rejected", task.Comment ?? "Request rejected.");
        if (task.Status.Equals("SentBack", StringComparison.OrdinalIgnoreCase)) return NodeExecutionResult.Stop("SentBack", task.Comment ?? "Request sent back.");
        var result = new JsonObject { ["decision"] = task.Decision ?? "Approve", ["comment"] = task.Comment ?? "", ["approvedBy"] = task.CompletedBy ?? "" };
        return NodeExecutionResult.Continue(result, "Approval completed.");
    }
}

public sealed class MakerCheckerNodeHandler(HumanTaskService tasks) : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "makerChecker" };

    public async Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context)
    {
        var all = await tasks.GetExecutionNodeTasksAsync(context.Execution.Id, context.Node.Id);
        var checker = all.LastOrDefault(t => t.TaskType.Equals("Checker", StringComparison.OrdinalIgnoreCase));
        var maker = all.LastOrDefault(t => t.TaskType.Equals("Maker", StringComparison.OrdinalIgnoreCase));

        if (maker is null || (checker?.Status.Equals("SentBack", StringComparison.OrdinalIgnoreCase) == true && checker.CompletedAtUtc.HasValue && maker.CreatedAtUtc < checker.CompletedAtUtc.Value))
        {
            var role = context.Node.Config.GetValueOrDefault("makerRole", "Maker");
            await tasks.CreateAsync(context.Execution, context.Node, "Maker", context.Node.Label + " · Maker", context.Execution.UserId, role);
            return NodeExecutionResult.Wait("WaitingForMaker", "Maker task created.");
        }
        if (maker.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase)) return NodeExecutionResult.Wait("WaitingForMaker", "Waiting for maker submission.");

        checker = all.LastOrDefault(t => t.TaskType.Equals("Checker", StringComparison.OrdinalIgnoreCase) && t.CreatedAtUtc >= (maker.CompletedAtUtc ?? DateTimeOffset.MinValue));
        if (checker is null)
        {
            var role = context.Node.Config.GetValueOrDefault("checkerRole", "Checker");
            await tasks.CreateAsync(context.Execution, context.Node, "Checker", context.Node.Label + " · Checker", maker.CompletedBy ?? context.Execution.UserId, role, maker.CompletedBy);
            return NodeExecutionResult.Wait("WaitingForChecker", "Checker task created.");
        }
        if (checker.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase)) return NodeExecutionResult.Wait("WaitingForChecker", "Waiting for checker decision.");
        if (checker.Status.Equals("Rejected", StringComparison.OrdinalIgnoreCase)) return NodeExecutionResult.Stop("Rejected", checker.Comment ?? "Checker rejected request.");
        if (checker.Status.Equals("SentBack", StringComparison.OrdinalIgnoreCase))
        {
            var role = context.Node.Config.GetValueOrDefault("makerRole", "Maker");
            await tasks.CreateAsync(context.Execution, context.Node, "Maker", context.Node.Label + " · Rework", checker.CompletedBy ?? "checker", role);
            return NodeExecutionResult.Wait("WaitingForMaker", "Checker sent request back to maker.");
        }
        var output = new JsonObject
        {
            ["maker"] = maker.CompletedBy ?? "", ["checker"] = checker.CompletedBy ?? "", ["decision"] = checker.Decision ?? "Approve", ["comment"] = checker.Comment ?? ""
        };
        return NodeExecutionResult.Continue(output, "Maker/checker completed.");
    }
}
