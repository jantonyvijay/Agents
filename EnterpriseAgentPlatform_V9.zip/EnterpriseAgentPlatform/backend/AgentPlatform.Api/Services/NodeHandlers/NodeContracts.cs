using System.Text.Json.Nodes;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services.NodeHandlers;

public sealed class NodeExecutionContext
{
    public required WorkflowDefinition Workflow { get; init; }
    public required WorkflowNode Node { get; init; }
    public required ExecutionRecord Execution { get; init; }
    public required CancellationToken CancellationToken { get; init; }
}

public sealed class NodeExecutionResult
{
    public JsonNode? Output { get; init; }
    public bool Pause { get; init; }
    public string? PauseStatus { get; init; }
    public bool Terminate { get; init; }
    public string? TerminalStatus { get; init; }
    public string? Message { get; init; }

    public static NodeExecutionResult Continue(JsonNode? output = null, string? message = null) => new() { Output = output, Message = message };
    public static NodeExecutionResult Wait(string status, string? message = null) => new() { Pause = true, PauseStatus = status, Message = message };
    public static NodeExecutionResult Stop(string status, string? message = null) => new() { Terminate = true, TerminalStatus = status, Message = message };
}

public interface IWorkflowNodeHandler
{
    IReadOnlyCollection<string> Types { get; }
    Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context);
}

public sealed class WorkflowNodeHandlerRegistry(IEnumerable<IWorkflowNodeHandler> handlers)
{
    private readonly Dictionary<string, IWorkflowNodeHandler> _handlers = handlers
        .SelectMany(h => h.Types.Select(t => (Type: t, Handler: h)))
        .ToDictionary(x => x.Type, x => x.Handler, StringComparer.OrdinalIgnoreCase);

    public IWorkflowNodeHandler? Get(string type) => _handlers.GetValueOrDefault(type);
}
