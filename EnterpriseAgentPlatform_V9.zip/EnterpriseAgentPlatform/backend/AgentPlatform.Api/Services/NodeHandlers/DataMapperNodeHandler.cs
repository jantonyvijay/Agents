using AgentPlatform.Api.Services;
using System.Text.Json.Nodes;

namespace AgentPlatform.Api.Services.NodeHandlers;

public sealed class DataMapperNodeHandler(TemplateResolver resolver) : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "dataMapper", "mapper", "transform" };

    public Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context)
    {
        var output = new JsonObject();
        // Dynamic mapping syntax: map.customerId={{ftpData.CUST_NO}}, map.amount={{fcData.amount}}
        foreach (var pair in context.Node.Config.Where(x => x.Key.StartsWith("map.", StringComparison.OrdinalIgnoreCase)))
        {
            var target = pair.Key[4..];
            output[target] = resolver.ResolveNode(pair.Value, context.Execution);
        }
        if (output.Count == 0 && context.Node.Config.TryGetValue("source", out var source))
        {
            var value = resolver.ResolveNode(source, context.Execution);
            return Task.FromResult(NodeExecutionResult.Continue(value, "Data mapper copied source value."));
        }
        return Task.FromResult(NodeExecutionResult.Continue(output, $"Mapped {output.Count} field(s)."));
    }
}
