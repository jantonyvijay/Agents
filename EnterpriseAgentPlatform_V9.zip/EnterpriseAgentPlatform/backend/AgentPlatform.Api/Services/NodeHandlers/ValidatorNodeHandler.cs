using AgentPlatform.Api.Services;
using System.Text.Json.Nodes;

namespace AgentPlatform.Api.Services.NodeHandlers;

public sealed class ValidatorNodeHandler(TemplateResolver resolver) : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "validator" };

    public Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context)
    {
        var sourceName = context.Node.Config.GetValueOrDefault("sourceVariable", "input");
        var source = resolver.GetVariable(context.Execution, sourceName);
        var required = context.Node.Config.GetValueOrDefault("requiredFields", "").Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        var missing = new JsonArray();
        foreach (var field in required)
        {
            var v = TemplateResolver.GetPath(source, field);
            if (v is null || string.IsNullOrWhiteSpace(TemplateResolver.NodeToString(v))) missing.Add(field);
        }
        var result = new JsonObject { ["valid"] = missing.Count == 0, ["missingFields"] = missing, ["sourceVariable"] = sourceName };
        if (missing.Count > 0 && context.Node.Config.GetValueOrDefault("failOnInvalid", "false").Equals("true", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Validation failed. Missing fields: " + string.Join(", ", missing.Select(x => x?.ToString())));
        return Task.FromResult(NodeExecutionResult.Continue(result, missing.Count == 0 ? "Validation passed." : "Validation completed with missing fields."));
    }
}
