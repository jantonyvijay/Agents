using AgentPlatform.Api.Services;
namespace AgentPlatform.Api.Services.NodeHandlers;

public sealed class ToolNodeHandler(RegistryService registry, ToolGateway gateway, TemplateResolver resolver) : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "tool", "mail" };

    public async Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context)
    {
        var toolId = context.Node.Config.GetValueOrDefault("toolId") ?? throw new InvalidOperationException($"{context.Node.Type} node requires config.toolId.");
        var tool = await registry.Tools.GetAsync(toolId) ?? throw new InvalidOperationException($"Tool '{toolId}' not found.");
        var inputTemplate = context.Node.Config.GetValueOrDefault("inputTemplate");
        var input = string.IsNullOrWhiteSpace(inputTemplate) ? context.Execution.LastOutput : resolver.Resolve(inputTemplate, context.Execution);
        var output = await gateway.ExecuteAsync(tool, input, context.Execution.Environment, context.Execution, resolver, context.CancellationToken);
        return NodeExecutionResult.Continue(TemplateResolver.ParseMaybeJson(output), $"Tool '{tool.Name}' completed.");
    }
}
