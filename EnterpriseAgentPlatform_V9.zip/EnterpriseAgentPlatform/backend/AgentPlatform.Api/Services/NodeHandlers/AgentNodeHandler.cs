using AgentPlatform.Api.Services;

namespace AgentPlatform.Api.Services.NodeHandlers;

public sealed class AgentNodeHandler(RegistryService registry, ModelGateway modelGateway, TemplateResolver resolver) : IWorkflowNodeHandler
{
    public IReadOnlyCollection<string> Types { get; } = new[] { "agent" };

    public async Task<NodeExecutionResult> ExecuteAsync(NodeExecutionContext context)
    {
        var id = context.Node.Config.GetValueOrDefault("agentId") ?? throw new InvalidOperationException("Agent node requires config.agentId.");
        var agent = await registry.Agents.GetAsync(id) ?? throw new InvalidOperationException($"Agent '{id}' not found.");
        var inputTemplate = context.Node.Config.GetValueOrDefault("inputTemplate");
        var input = string.IsNullOrWhiteSpace(inputTemplate) ? context.Execution.LastOutput : resolver.Resolve(inputTemplate, context.Execution);
        var variables = resolver.GetVariables(context.Execution).ToJsonString();
        var output = await modelGateway.GenerateAsync(agent, input, variables, context.CancellationToken);
        return NodeExecutionResult.Continue(TemplateResolver.ParseMaybeJson(output), $"Agent '{agent.Name}' completed.");
    }
}
