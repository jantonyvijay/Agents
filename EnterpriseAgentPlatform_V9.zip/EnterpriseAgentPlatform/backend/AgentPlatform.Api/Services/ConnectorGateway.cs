using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class ConnectorGateway(HttpClient http, IWebHostEnvironment env)
{
    public async Task<JsonNode?> ExecuteAsync(ConnectorDefinition connector, string operationId, Dictionary<string, string>? parameters, ExecutionRecord execution, TemplateResolver resolver, CancellationToken ct)
    {
        if (!connector.Enabled) throw new InvalidOperationException($"Connector '{connector.Name}' is disabled.");
        if (!connector.TrustStatus.Equals("Approved", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Connector '{connector.Name}' is not approved.");
        if (!connector.Environment.Equals("ALL", StringComparison.OrdinalIgnoreCase) && !connector.Environment.Equals(execution.Environment, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Connector '{connector.Name}' is not approved for {execution.Environment}.");

        var operation = connector.Operations.FirstOrDefault(x => x.Id.Equals(operationId, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException($"Operation '{operationId}' is not registered for connector '{connector.Name}'.");

        return connector.Type.ToLowerInvariant() switch
        {
            "mock" => ExecuteMock(operation, execution, resolver),
            "filearea" => await ExecuteFileAreaAsync(connector, operation, execution, resolver, ct),
            "http" or "fc-query" => await ExecuteHttpAsync(connector, operation, parameters, execution, resolver, ct),
            _ => throw new NotSupportedException($"Connector type '{connector.Type}' is not supported by the demo runtime.")
        };
    }

    private static JsonNode? ExecuteMock(ConnectorOperationDefinition operation, ExecutionRecord execution, TemplateResolver resolver)
    {
        var payload = operation.Config.GetValueOrDefault("response", "{\"ok\":true}");
        payload = resolver.Resolve(payload, execution);
        return TemplateResolver.ParseMaybeJson(payload);
    }

    private async Task<JsonNode?> ExecuteFileAreaAsync(ConnectorDefinition connector, ConnectorOperationDefinition operation, ExecutionRecord execution, TemplateResolver resolver, CancellationToken ct)
    {
        var configuredRoot = connector.Config.GetValueOrDefault("rootPath", "Data/dcpftp");
        var root = Environment.GetEnvironmentVariable(connector.Config.GetValueOrDefault("rootPathEnvVar", "DCPFTP_ROOT")) ?? configuredRoot;
        if (!Path.IsPathRooted(root)) root = Path.Combine(env.ContentRootPath, root);
        Directory.CreateDirectory(root);

        var pattern = resolver.Resolve(operation.Config.GetValueOrDefault("filePattern", "*.csv"), execution);
        var mode = operation.Config.GetValueOrDefault("mode", "latest");
        var files = Directory.EnumerateFiles(root, pattern, SearchOption.TopDirectoryOnly)
            .Select(p => new FileInfo(p)).OrderByDescending(x => x.LastWriteTimeUtc).ToList();

        if (files.Count == 0) throw new FileNotFoundException($"No file matching '{pattern}' was found in connector area '{connector.Name}'.");
        var selected = files[0];
        if (mode.Equals("list", StringComparison.OrdinalIgnoreCase))
        {
            return new JsonArray(files.Take(100).Select(f => (JsonNode?)new JsonObject
            {
                ["fileName"] = f.Name, ["sizeBytes"] = f.Length, ["lastWriteUtc"] = f.LastWriteTimeUtc
            }).ToArray());
        }

        var ext = selected.Extension.ToLowerInvariant();
        var text = await File.ReadAllTextAsync(selected.FullName, ct);
        JsonNode? content = ext == ".json" ? TemplateResolver.ParseMaybeJson(text) : new JsonObject
        {
            ["text"] = text,
            ["rows"] = ext == ".csv" ? ParseCsv(text) : null
        };
        return new JsonObject
        {
            ["fileName"] = selected.Name,
            ["sizeBytes"] = selected.Length,
            ["lastWriteUtc"] = selected.LastWriteTimeUtc,
            ["content"] = content
        };
    }

    private async Task<JsonNode?> ExecuteHttpAsync(ConnectorDefinition connector, ConnectorOperationDefinition operation, Dictionary<string, string>? parameters, ExecutionRecord execution, TemplateResolver resolver, CancellationToken ct)
    {
        var baseUrl = connector.Config.GetValueOrDefault("baseUrl", "");
        var urlTemplate = operation.Config.GetValueOrDefault("url", "");
        if (string.IsNullOrWhiteSpace(urlTemplate) && operation.Config.TryGetValue("mockResponse", out var mock))
            return TemplateResolver.ParseMaybeJson(resolver.Resolve(mock, execution));
        if (string.IsNullOrWhiteSpace(urlTemplate)) throw new InvalidOperationException("HTTP/FC connector operation requires config.url or mockResponse.");

        var url = resolver.Resolve(urlTemplate, execution);
        foreach (var pair in parameters ?? new()) url = url.Replace("{{param." + pair.Key + "}}", Uri.EscapeDataString(resolver.Resolve(pair.Value, execution)), StringComparison.OrdinalIgnoreCase);
        if (!Uri.IsWellFormedUriString(url, UriKind.Absolute)) url = baseUrl.TrimEnd('/') + "/" + url.TrimStart('/');

        var method = operation.Config.GetValueOrDefault("method", "GET").ToUpperInvariant();
        using var req = new HttpRequestMessage(new HttpMethod(method), url);
        if (method is "POST" or "PUT" or "PATCH")
        {
            var body = resolver.Resolve(operation.Config.GetValueOrDefault("body", "{}"), execution);
            foreach (var pair in parameters ?? new()) body = body.Replace("{{param." + pair.Key + "}}", resolver.Resolve(pair.Value, execution), StringComparison.OrdinalIgnoreCase);
            req.Content = new StringContent(body, Encoding.UTF8, operation.Config.GetValueOrDefault("contentType", "application/json"));
        }

        if (connector.Config.TryGetValue("bearerTokenEnvVar", out var tokenEnv) && !string.IsNullOrWhiteSpace(tokenEnv))
        {
            var token = Environment.GetEnvironmentVariable(tokenEnv);
            if (!string.IsNullOrWhiteSpace(token)) req.Headers.Authorization = new("Bearer", token);
        }
        using var response = await http.SendAsync(req, ct);
        var bodyText = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException($"Connector call failed ({(int)response.StatusCode}): {bodyText}");
        return TemplateResolver.ParseMaybeJson(bodyText);
    }

    private static JsonArray ParseCsv(string text)
    {
        var lines = text.Replace("\r", "").Split('\n', StringSplitOptions.RemoveEmptyEntries);
        var output = new JsonArray();
        if (lines.Length == 0) return output;
        var headers = SplitCsvLine(lines[0]);
        foreach (var line in lines.Skip(1).Take(5000))
        {
            var values = SplitCsvLine(line);
            var row = new JsonObject();
            for (var i = 0; i < headers.Count; i++) row[headers[i]] = i < values.Count ? values[i] : "";
            output.Add(row);
        }
        return output;
    }

    private static List<string> SplitCsvLine(string line)
    {
        var result = new List<string>();
        var sb = new StringBuilder();
        var quoted = false;
        for (var i = 0; i < line.Length; i++)
        {
            var c = line[i];
            if (c == '"')
            {
                if (quoted && i + 1 < line.Length && line[i + 1] == '"') { sb.Append('"'); i++; }
                else quoted = !quoted;
            }
            else if (c == ',' && !quoted) { result.Add(sb.ToString().Trim()); sb.Clear(); }
            else sb.Append(c);
        }
        result.Add(sb.ToString().Trim());
        return result;
    }
}
