namespace CATS.Core;

/// <summary>
/// One selectable column of the Alerts table for Alert List Configuration. The rows live in AlertListColumnMaster, which is the single source of
/// truth for which columns exist, their labels, whether they can be searched and how. <see cref="AlertListColumnSeeds"/> only supplies the initial rows.
/// </summary>
public sealed class AlertListColumnDefinition
{
    /// <summary>Stable key stored in a template's alert-list configuration; also the camelCase property name of the Alerts API row.</summary>
    public string Code { get; set; } = "";
    public string Label { get; set; } = "";
    /// <summary>Column of the Alerts table that searches use; empty when the column is shown only.</summary>
    public string? DbColumn { get; set; }
    public bool IsFilterable { get; set; }
    /// <summary>Contains or Equals.</summary>
    public string MatchMode { get; set; } = "Contains";
    public string ControlType { get; set; } = "text";
    public string OptionsJson { get; set; } = "[]";
    /// <summary>Optional display pattern such as "{0} day(s)".</summary>
    public string? ValueFormat { get; set; }
    /// <summary>Comma separated Alert Type codes that do not offer this column.</summary>
    public string? ExcludedTemplateCodes { get; set; }
    public int DisplayOrder { get; set; } = 100;
    public bool IsActive { get; set; } = true;

    public bool CanSearch => IsFilterable && !string.IsNullOrWhiteSpace(DbColumn);
}

public static class AlertListColumnSeeds
{
    private static readonly string StatusOptions = System.Text.Json.JsonSerializer.Serialize(Enum.GetNames<AlertStatus>());

    /// <summary>Rows inserted into AlertListColumnMaster when a Code is missing. Existing rows are never overwritten.</summary>
    public static IReadOnlyList<AlertListColumnDefinition> Defaults { get; } =
    [
        new() { Code = "AlertNo", Label = "Alert No", DbColumn = "AlertNo", IsFilterable = true, MatchMode = "Contains", DisplayOrder = 10 },
        new() { Code = "AlertType", Label = "Alert Type", DisplayOrder = 20 },
        new() { Code = "BranchCode", Label = "Branch", DbColumn = "BranchCode", IsFilterable = true, MatchMode = "Equals", ExcludedTemplateCodes = "ATM_ONUS,ATM_OFFUS", DisplayOrder = 30 },
        new() { Code = "CurrentStageName", Label = "Stage", DbColumn = "CurrentStageName", IsFilterable = true, MatchMode = "Contains", DisplayOrder = 40 },
        new() { Code = "Status", Label = "Status", DbColumn = "Status", IsFilterable = true, MatchMode = "Equals", ControlType = "select", OptionsJson = StatusOptions, DisplayOrder = 50 },
        new() { Code = "Priority", Label = "Priority", DbColumn = "Priority", IsFilterable = true, MatchMode = "Equals", DisplayOrder = 60 },
        new() { Code = "CustomerId", Label = "Customer ID", DisplayOrder = 70 },
        new() { Code = "AccountId", Label = "Account ID", DisplayOrder = 80 },
        new() { Code = "StageAgingDays", Label = "Stage Age (days)", ControlType = "number", ValueFormat = "{0} day(s)", DisplayOrder = 90 },
        new() { Code = "OverallAgingDays", Label = "Overall Age (days)", ControlType = "number", ValueFormat = "{0} day(s)", DisplayOrder = 100 }
    ];
}
