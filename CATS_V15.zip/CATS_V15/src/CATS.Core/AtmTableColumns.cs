namespace CATS.Core;

public enum AtmColumnKind { Text, DateTime, Int, Decimal, Bit }

/// <summary>A column of an ATM OnUs/OffUs table that an upload file can populate.</summary>
public sealed record AtmTableColumn(string Name, AtmColumnKind Kind, int MaxLength = 0);

/// <summary>
/// Catalog of the ATM table columns that can be mapped to file columns. The names, types and lengths mirror the SQL Server
/// tables; other providers only expose the subset that exists in their schemas. Column names are the only identifiers ever
/// placed in generated SQL, so this list is also the whitelist.
/// </summary>
public static class AtmTableColumns
{
    private const int Unlimited = int.MaxValue;
    private static AtmTableColumn Text(string name, int length) => new(name, AtmColumnKind.Text, length);
    private static AtmTableColumn Date(string name) => new(name, AtmColumnKind.DateTime);
    private static AtmTableColumn Whole(string name) => new(name, AtmColumnKind.Int);
    private static AtmTableColumn Amount(string name) => new(name, AtmColumnKind.Decimal);

    private static readonly AtmTableColumn[] OnUsFile =
    [
        Text("Settlement_Type", 100), Text("CRM_Proactive_No", 100), Date("Transaction_Date"), Date("Customer_Complaint_Date"),
        Date("Customer_Acc_Credit_Date"), Text("Acc_No", 20), Date("T_5_Calender_Days"), Whole("Days"), Amount("Penalty_Rs"),
        Text("ATM_ID", 100), Text("Transaction_No", 100), Amount("Transaction_Amount"), Amount("Disputed_Amount"),
        Text("EJ_Error", 100), Text("Narration", 500)
    ];

    private static readonly AtmTableColumn[] OffUsFile =
    [
        Text("Chargeback_Ref_No", 100), Date("Chargeback_Date"), Text("Acquiring_Bank", 500), Text("Issuing_Bank", 500),
        Date("Transaction_Date"), Text("Transaction_Time", 50), Text("RRN_No", 100), Text("ATM_ID", 100), Text("CARD_No", 100),
        Amount("Transaction_Amount"), Amount("Disputed_Amount"), Text("Customer_Penalty", 100), Date("Adjustment_Date"),
        Text("Adjustment_Type", 100), Text("Adjustment_Time", 50), Text("Narration", 500), Amount("Adjustment_Amount"), Text("EJError", 250)
    ];

    // Upload period and metadata columns: available in every provider's schema.
    private static readonly AtmTableColumn[] Metadata =
    [
        Text("Penalty_Month", 100), Text("Penalty_Year", 100), Text("UploadFileName", 250), Text("CreatedBy", 50), Date("CreatedDate")
    ];

    // Remaining legacy table columns (workflow status, recovery, reopen...). Present in the SQL Server tables.
    private static readonly AtmTableColumn[] LegacySqlServer =
    [
        Text("RecordStatus", 250), Text("ApprovedBy", 100), Date("ApprovedDate"), Text("Assigned_Bucket", 100), Date("Assigned_On"),
        Text("Assigned_By", 100), Text("UploadRemarks", Unlimited), Text("ATMC_Status", 10), Text("ATMC_By", 50), Date("ATMC_ActionOn"),
        Text("ATMC_Remark", Unlimited), Text("RATC_Status", 10), Text("RATC_By", 50), Date("RATC_ActionOn"), Text("RATC_Remark", Unlimited),
        Text("SH_Status", 10), Text("SH_By", 50), Date("SH_ActionOn"), Text("SH_Remark", Unlimited), Text("ProcessStatus", 50),
        Text("Recoverable_Type", 100), Text("Recoverable_VendorName", 100),
        Text("Excess_Reported", 10), Date("Excess_Date"), Date("MailDate"),
        Text("Recovery_Reason", 250), Text("ProcessBy", 100), Date("ProcessOn"), Text("RecoveryReason_Remark", Unlimited),
        new("Fourwayreconcilition", AtmColumnKind.Bit), Text("RH_By", 200), Date("RH_ActionOn"), Text("RH_Status", Unlimited),
        Text("RH_Remark", Unlimited), Text("GH_By", 200), Date("GH_ActionOn"), Text("GH_Status", Unlimited), Text("GH_Remark", Unlimited),
        Text("FileType", 100), Whole("IsReopen"), Text("ReopenBy", 200), Date("ReopenOn"), Text("ReopenReason", Unlimited),
        Text("FileData_Update_By", 200), Date("FileData_Update_On"), Text("ReAssignBy", 100), Date("ReAssignOn"), Text("ReAssignEmpId", 100),
        Date("Reopen_Sent_for_Authorisation"), Text("Reopen_Authorised_by", 200), Text("Reopen_Sent_for_Authorisation_By", 100),
        Text("Reopen_Authorised_Remark", Unlimited), Whole("IsEmailSent_ATMC"), Whole("IsEmailSent_RATC")
    ];

    /// <summary>CATS-managed columns: derived from the mapped file columns or set by the workflow, never mapped directly.</summary>
    public static readonly string[] InternalColumns =
        ["ID", "AlertId", "ATMID", "PenaltyMonth", "PenaltyAmount", "CaseCategory", "SourceBatchId", "SourceRowNumber", "ReopenedFromAlertId", "SourceDataJson"];

    public static bool IsInternal(string? column) => InternalColumns.Contains(column ?? "", StringComparer.OrdinalIgnoreCase);

    private static bool IsOnUs(string templateCode) => string.Equals(templateCode, "ATM_ONUS", StringComparison.OrdinalIgnoreCase);

    /// <summary>Columns that can be persisted by an ATM module. Provider migrations keep this contract available on all supported databases.</summary>
    public static IReadOnlyList<AtmTableColumn> For(string templateCode, string provider)
    {
        var columns = new List<AtmTableColumn>(IsOnUs(templateCode) ? OnUsFile : OffUsFile);
        columns.AddRange(Metadata);
        columns.AddRange(LegacySqlServer);
        if (IsOnUs(templateCode)) columns.Add(new("NoPenaltyApplicable", AtmColumnKind.Bit));
        return columns;
    }

    public static AtmTableColumn? Find(string templateCode, string provider, string? column) =>
        For(templateCode, provider).FirstOrDefault(x => x.Name.Equals(column, StringComparison.OrdinalIgnoreCase));
}
