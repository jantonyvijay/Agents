namespace CATS.Core;

/// <summary>Guard rails for the role-wise permission screen, so an administrator cannot lock everyone out of security management.</summary>
public static class RolePermissionRules
{
    /// <summary>Permissions that ADMIN always keeps: without them nobody could manage security or this screen again.</summary>
    public static IReadOnlyList<string> AdminLocked { get; } = ["SECURITY.MANAGE", CatsPermissions.RolePermissionsManage];

    public static bool IsLocked(string roleCode, string permissionCode) =>
        roleCode.Equals(CatsRoles.Admin, StringComparison.OrdinalIgnoreCase) &&
        AdminLocked.Contains(permissionCode, StringComparer.OrdinalIgnoreCase);

    /// <summary>Returns the permissions that must be present for the role but are missing from the request; empty means the change is allowed.</summary>
    public static IReadOnlyList<string> MissingRequired(string roleCode, string actorRoleCode, IEnumerable<string> requested)
    {
        var set = requested.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var required = AdminLocked.Where(p => IsLocked(roleCode, p)).ToList();
        // The role the caller belongs to keeps this screen, otherwise the caller would lock themselves out.
        if (roleCode.Equals(actorRoleCode, StringComparison.OrdinalIgnoreCase)) required.Add(CatsPermissions.RolePermissionsManage);
        return required.Distinct(StringComparer.OrdinalIgnoreCase).Where(p => !set.Contains(p)).ToList();
    }
}
