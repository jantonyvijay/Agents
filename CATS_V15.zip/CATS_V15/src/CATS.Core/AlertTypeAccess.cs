namespace CATS.Core;

/// <summary>
/// One row of AlertTypeAccess. An Alert Type with no rows is open to everyone; otherwise a user sees it when at least one row matches:
/// the row's role (if set) equals the user's role and the row's permission (if set) is held by the user.
/// </summary>
public sealed class AlertTypeAccessRule
{
    public string TemplateCode { get; set; } = "";
    public string? RoleCode { get; set; }
    public string? PermissionCode { get; set; }
}

public static class AlertTypeAccess
{
    /// <summary>Users who manage templates or are administrators see every Alert Type, so they can always configure them.</summary>
    public static bool SeesAll(Func<string, bool> hasPermission) =>
        hasPermission(CatsPermissions.TemplateManage) || hasPermission(CatsPermissions.Admin);

    public static bool IsVisible(IEnumerable<AlertTypeAccessRule> rules, string templateCode, string roleCode, Func<string, bool> hasPermission)
    {
        var forTemplate = rules.Where(x => x.TemplateCode.Equals(templateCode, StringComparison.OrdinalIgnoreCase)).ToList();
        if (forTemplate.Count == 0) return true;
        return forTemplate.Any(rule =>
        {
            var hasConstraint = !string.IsNullOrWhiteSpace(rule.RoleCode) || !string.IsNullOrWhiteSpace(rule.PermissionCode);
            return hasConstraint &&
                (string.IsNullOrWhiteSpace(rule.RoleCode) || rule.RoleCode.Equals(roleCode, StringComparison.OrdinalIgnoreCase)) &&
                (string.IsNullOrWhiteSpace(rule.PermissionCode) || hasPermission(rule.PermissionCode));
        });
    }

    /// <summary>Rules written once when AlertTypeAccess is empty; afterwards the database owns them.</summary>
    public static IReadOnlyList<AlertTypeAccessRule> Defaults { get; } =
    [
        new() { TemplateCode = "ATM_ONUS", PermissionCode = CatsPermissions.AtmOperations },
        new() { TemplateCode = "ATM_ONUS", PermissionCode = CatsPermissions.AlertViewAll },
        new() { TemplateCode = "ATM_OFFUS", PermissionCode = CatsPermissions.AtmOperations },
        new() { TemplateCode = "ATM_OFFUS", PermissionCode = CatsPermissions.AlertViewAll },
        new() { TemplateCode = "DT_DD_MONEY_MULE", RoleCode = CatsRoles.DtUser },
        new() { TemplateCode = "DT_DD_MONEY_MULE", RoleCode = CatsRoles.DtChecker },
        new() { TemplateCode = "DT_DD_MONEY_MULE", RoleCode = CatsRoles.DtVerifier },
        new() { TemplateCode = "DT_DD_MONEY_MULE", RoleCode = CatsRoles.Central },
        new() { TemplateCode = "DT_DD_MONEY_MULE", RoleCode = CatsRoles.Auditor },
        new() { TemplateCode = "DT_DD_MONEY_MULE", PermissionCode = CatsPermissions.AlertViewAll }
    ];
}
