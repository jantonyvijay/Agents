using System.Text;
using System.Text.RegularExpressions;

namespace CATS.Core;

/// <summary>One template field stored in a generated column.</summary>
public sealed record TemplateDataColumn(string FieldName, string ColumnName, string SqlType);

/// <summary>The data table generated for a template (Alert Type): its name and the field-to-column mapping.</summary>
public sealed class TemplateDataTableInfo
{
    public string TemplateCode { get; set; } = "";
    public string TableName { get; set; } = "";
    public List<TemplateDataColumn> Columns { get; set; } = [];
}

/// <summary>What Generate / Update would do for a template right now.</summary>
public sealed class TemplateDataTablePlan
{
    public string TemplateCode { get; set; } = "";
    public string TableName { get; set; } = "";
    public bool Generated { get; set; }
    public bool TableNameEditable { get; set; }
    public bool Supported { get; set; } = true;
    public string? UnsupportedReason { get; set; }
    public List<TemplateDataColumn> ExistingColumns { get; set; } = [];
    public List<TemplateDataColumn> ColumnsToAdd { get; set; } = [];
    public List<TemplateDataColumn> ColumnsToWiden { get; set; } = [];
    /// <summary>For each field, the types its column may take now: any type for a new column, only safe widenings for an existing one.</summary>
    public Dictionary<string, List<string>> ColumnTypeOptions { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public int AlertsToCopy { get; set; }
}

/// <summary>Naming and type rules used to turn template fields into table columns. Pure functions, no database access.</summary>
public static partial class TemplateDataTablePlanner
{
    /// <summary>Columns every generated table has; field columns may not reuse these names.</summary>
    public static readonly string[] StandardColumns = ["AlertId", "SourceBatchId", "SourceRowNumber", "SourceDataJson", "CreatedAtUtc", "UpdatedAtUtc"];

    private const int MaxIdentifierLength = 100;
    private const int DefaultTextLength = 500;
    private const int MaxFixedTextLength = 4000;

    [GeneratedRegex("[^A-Za-z0-9_]")]
    private static partial Regex Invalid();

    /// <summary>Templates that already own dedicated tables built by hand; the generator never touches them.</summary>
    public static bool UsesLegacyTables(string templateCode) =>
        AtmSourceColumns.IsAtmTemplate(templateCode);

    public static string SuggestTableName(string templateCode)
    {
        var name = Invalid().Replace(templateCode ?? "", "_").Trim('_');
        if (name.Length == 0) name = "Template";
        if (char.IsDigit(name[0])) name = "T_" + name;
        // A code that already starts with the prefix (tbl_Testing) is used as it is.
        if (name.StartsWith("tbl_", StringComparison.OrdinalIgnoreCase) && name.Length > 4)
            return name.Length > MaxIdentifierLength ? name[..MaxIdentifierLength] : name;
        return "tbl_" + (name.Length > MaxIdentifierLength - 4 ? name[..(MaxIdentifierLength - 4)] : name);
    }

    /// <summary>Column types a person can choose in Data Storage. Each is a plain SQL Server type; nothing else is ever accepted.</summary>
    public static readonly string[] SelectableTypes =
    [
        "nvarchar(50)", "nvarchar(100)", "nvarchar(250)", "nvarchar(500)", "nvarchar(1000)", "nvarchar(2000)", "nvarchar(4000)", "nvarchar(max)",
        "int", "bigint", "decimal(18,2)", "decimal(19,4)", "float", "date", "datetime2", "bit"
    ];

    [GeneratedRegex(@"^(?:(?<kind>nvarchar)\((?<n>max|[1-9]\d{0,3})\)|(?<kind>decimal)\((?<p>\d{1,2}),(?<s>\d{1,2})\)|(?<kind>int|bigint|float|date|datetime2|bit))$", RegexOptions.IgnoreCase)]
    private static partial Regex TypePattern();

    /// <summary>True for a type this feature can create: nvarchar(1..4000|max), decimal(p,s), int, bigint, float, date, datetime2 or bit.</summary>
    public static bool IsValidType(string? sqlType)
    {
        var match = TypePattern().Match(sqlType ?? "");
        if (!match.Success) return false;
        if (match.Groups["kind"].Value.Equals("nvarchar", StringComparison.OrdinalIgnoreCase))
            return match.Groups["n"].Value.Equals("max", StringComparison.OrdinalIgnoreCase) || int.Parse(match.Groups["n"].Value) <= MaxFixedTextLength;
        if (match.Groups["kind"].Value.Equals("decimal", StringComparison.OrdinalIgnoreCase))
        {
            int p = int.Parse(match.Groups["p"].Value), s = int.Parse(match.Groups["s"].Value);
            return p is >= 1 and <= 38 && s <= p;
        }
        return true;
    }

    /// <summary>
    /// Whether an existing column may be changed to <paramref name="to"/> without any chance of losing data: longer text, int to bigint,
    /// a decimal that keeps its scale and integer digits, or date to datetime2. Anything else needs a new column.
    /// </summary>
    public static bool IsWidening(string from, string to)
    {
        if (from.Equals(to, StringComparison.OrdinalIgnoreCase)) return true;
        if (!IsValidType(from) || !IsValidType(to)) return false;
        var a = TypePattern().Match(from);
        var b = TypePattern().Match(to);
        var kindA = a.Groups["kind"].Value.ToLowerInvariant();
        var kindB = b.Groups["kind"].Value.ToLowerInvariant();
        if (kindA == "nvarchar" && kindB == "nvarchar") return TextLength(to) > TextLength(from);
        if (kindA == "int" && kindB == "bigint") return true;
        if (kindA == "date" && kindB == "datetime2") return true;
        if (kindA == "decimal" && kindB == "decimal")
        {
            int p1 = int.Parse(a.Groups["p"].Value), s1 = int.Parse(a.Groups["s"].Value), p2 = int.Parse(b.Groups["p"].Value), s2 = int.Parse(b.Groups["s"].Value);
            return s2 >= s1 && p2 - s2 >= p1 - s1;
        }
        return false;
    }

    /// <summary>The types a field's column may take: any type while it does not exist yet, only safe widenings once it does.</summary>
    public static List<string> TypeOptions(string? existingType, string suggestedType)
    {
        var all = SelectableTypes.Append(suggestedType).Append(existingType ?? "").Where(x => !string.IsNullOrEmpty(x)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        return existingType is null ? all : all.Where(x => IsWidening(existingType, x)).ToList();
    }

    /// <summary>Returns null when the name is acceptable, otherwise the reason it is not.</summary>
    public static string? ValidateTableName(string? tableName)
    {
        if (string.IsNullOrWhiteSpace(tableName)) return "A table name is required.";
        if (tableName.Length > MaxIdentifierLength) return $"The table name cannot exceed {MaxIdentifierLength} characters.";
        if (!Regex.IsMatch(tableName, "^[A-Za-z][A-Za-z0-9_]*$")) return "Use letters, digits and underscores only, starting with a letter.";
        return null;
    }

    /// <summary>A valid, unique column name for a field. Names that collide with standard columns or each other get a suffix.</summary>
    public static string ColumnNameFor(string fieldName, ISet<string> used)
    {
        var name = Invalid().Replace(fieldName ?? "", "_").Trim('_');
        if (name.Length == 0) name = "Field";
        if (char.IsDigit(name[0])) name = "F_" + name;
        if (name.Length > MaxIdentifierLength) name = name[..MaxIdentifierLength];
        var candidate = name;
        for (var n = 2; used.Contains(candidate) || StandardColumns.Contains(candidate, StringComparer.OrdinalIgnoreCase); n++)
            candidate = $"{(name.Length > MaxIdentifierLength - 4 ? name[..(MaxIdentifierLength - 4)] : name)}_{n}";
        used.Add(candidate);
        return candidate;
    }

    /// <summary>SQL Server type for a field. Text sizes follow the field's maximum length; unbounded or very long text is nvarchar(max).</summary>
    public static string SqlTypeFor(TemplateField field)
    {
        switch ((field.Type ?? "text").Trim().ToLowerInvariant())
        {
            case "number": return "decimal(19,4)";
            case "date":
            case "datetime": return "datetime2";
            case "checkbox": return "bit";
            case "textarea": return "nvarchar(max)";
            default:
                if (field.MaxLength is > MaxFixedTextLength) return "nvarchar(max)";
                return $"nvarchar({Math.Clamp(field.MaxLength ?? DefaultTextLength, 1, MaxFixedTextLength)})";
        }
    }

    /// <summary>Length of an nvarchar(n) type, int.MaxValue for max, 0 for other types.</summary>
    public static int TextLength(string sqlType)
    {
        if (!sqlType.StartsWith("nvarchar(", StringComparison.OrdinalIgnoreCase)) return 0;
        var inner = sqlType["nvarchar(".Length..].TrimEnd(')');
        return inner.Equals("max", StringComparison.OrdinalIgnoreCase) ? int.MaxValue : int.TryParse(inner, out var length) ? length : 0;
    }

    /// <summary>
    /// Builds the field-to-column list for a template, keeping the names already generated and adding new fields after them.
    /// <paramref name="chosenTypes"/> (field name to SQL type) lets a person pick the type; for an existing column only a safe widening is accepted.
    /// </summary>
    public static (List<TemplateDataColumn> Columns, List<TemplateDataColumn> Added, List<TemplateDataColumn> Widened) Plan(
        IEnumerable<TemplateField> fields, IReadOnlyList<TemplateDataColumn> existing, IReadOnlyDictionary<string, string>? chosenTypes = null)
    {
        var used = new HashSet<string>(existing.Select(x => x.ColumnName), StringComparer.OrdinalIgnoreCase);
        var columns = new List<TemplateDataColumn>(existing);
        var added = new List<TemplateDataColumn>();
        var widened = new List<TemplateDataColumn>();
        var chosen = new Dictionary<string, string>(chosenTypes ?? new Dictionary<string, string>(), StringComparer.OrdinalIgnoreCase);
        foreach (var field in fields.Where(x => !string.IsNullOrWhiteSpace(x.Name)).DistinctBy(x => x.Name, StringComparer.OrdinalIgnoreCase))
        {
            var wanted = SqlTypeFor(field);
            if (chosen.TryGetValue(field.Name, out var picked) && !string.IsNullOrWhiteSpace(picked))
            {
                picked = picked.Trim().ToLowerInvariant();
                if (!IsValidType(picked)) throw new InvalidOperationException($"'{picked}' is not a supported column type for '{field.Name}'.");
                wanted = picked;
            }
            var current = columns.FirstOrDefault(x => x.FieldName.Equals(field.Name, StringComparison.OrdinalIgnoreCase));
            if (current is null)
            {
                var created = new TemplateDataColumn(field.Name, ColumnNameFor(field.Name, used), wanted);
                columns.Add(created);
                added.Add(created);
            }
            else if (!current.SqlType.Equals(wanted, StringComparison.OrdinalIgnoreCase))
            {
                var picked_ = chosen.ContainsKey(field.Name);
                if (!IsWidening(current.SqlType, wanted))
                {
                    // An automatic suggestion (a smaller max length, a changed field type) never narrows or converts a column; only an explicit choice can fail loudly.
                    if (picked_) throw new InvalidOperationException($"The column for '{field.Name}' is {current.SqlType} and cannot be changed to {wanted}; only a longer text, int to bigint, a wider decimal or date to datetime2 is allowed.");
                    continue;
                }
                var index = columns.IndexOf(current);
                columns[index] = current with { SqlType = wanted };
                widened.Add(columns[index]);
            }
        }
        return (columns, added, widened);
    }

    /// <summary>Converts a JSON/text value to the CLR type of a column, or null when it is empty or cannot be converted.</summary>
    public static object? ConvertValue(string sqlType, string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        var type = sqlType.ToLowerInvariant();
        var culture = System.Globalization.CultureInfo.InvariantCulture;
        if (type.StartsWith("decimal")) return decimal.TryParse(text, System.Globalization.NumberStyles.Any, culture, out var number) ? number : null;
        if (type == "int") return decimal.TryParse(text, System.Globalization.NumberStyles.Any, culture, out var whole) && whole == decimal.Truncate(whole) && whole is >= int.MinValue and <= int.MaxValue ? (int)whole : null;
        if (type == "bigint") return decimal.TryParse(text, System.Globalization.NumberStyles.Any, culture, out var large) && large == decimal.Truncate(large) && large is >= long.MinValue and <= long.MaxValue ? (long)large : null;
        if (type == "float") return double.TryParse(text, System.Globalization.NumberStyles.Float, culture, out var real) ? real : null;
        if (type == "date") return DateTime.TryParse(text, culture, System.Globalization.DateTimeStyles.None, out var day) ? day.Date : null;
        if (type.StartsWith("datetime")) return DateTime.TryParse(text, culture, System.Globalization.DateTimeStyles.None, out var date) ? date : null;
        if (type == "bit") return text.Equals("true", StringComparison.OrdinalIgnoreCase) || text == "1" || text.Equals("yes", StringComparison.OrdinalIgnoreCase);
        var length = TextLength(sqlType);
        return length > 0 && length != int.MaxValue && text.Length > length ? text[..length] : text;
    }
}
