namespace CATS.Core;

/// <summary>Resolves template display fields from source rows using the template's per-mode column mappings.</summary>
public static class SourceColumnMapper
{
    public const int MaxSourceColumnLength = 200;

    /// <summary>Header comparison ignores case, spaces and punctuation, e.g. "T+5 Calender Days" equals "T_5_Calender_Days".</summary>
    public static string Normalize(string? value)
    {
        var normalized = new string((value ?? "").Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());
        // Preserve the legacy ATM column spelling while accepting the correctly spelled file header.
        return normalized == "t5calendardays" ? "t5calenderdays" : normalized;
    }

    private static SourceColumnMappingConfiguration? Find(TemplateViewConfiguration view, string mode, string fieldName) =>
        view.SourceColumnMappings.FirstOrDefault(x =>
            x.Mode.Equals(mode, StringComparison.OrdinalIgnoreCase) &&
            x.Field.Equals(fieldName, StringComparison.OrdinalIgnoreCase));

    public static string SourceColumnFor(TemplateViewConfiguration view, string mode, string fieldName)
    {
        var mapped = Find(view, mode, fieldName)?.SourceColumn;
        return string.IsNullOrWhiteSpace(mapped) ? fieldName : mapped.Trim();
    }

    /// <summary>Fields in the administrator's mapping order for a mode; fields without an order follow in template field order.</summary>
    public static List<TemplateField> OrderedFields(TemplateViewConfiguration view, string mode, IEnumerable<TemplateField> fields) =>
        fields
            .Select((field, index) => (Field: field, Index: index, Order: Find(view, mode, field.Name)?.Order ?? 0))
            .OrderBy(x => x.Order > 0 ? x.Order : int.MaxValue)
            .ThenBy(x => x.Index)
            .Select(x => x.Field)
            .ToList();

    /// <summary>Source columns flagged as required that are absent from the supplied headers.</summary>
    public static List<string> MissingRequiredColumns(
        TemplateViewConfiguration view,
        string mode,
        IEnumerable<TemplateField> fields,
        IEnumerable<string> headers,
        IEnumerable<string>? alwaysRequiredFields = null)
    {
        var available = headers.Select(Normalize).ToHashSet(StringComparer.Ordinal);
        var fieldNames = fields.Select(x => x.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var required = view.SourceColumnMappings
            .Where(x => x.Mode.Equals(mode, StringComparison.OrdinalIgnoreCase) && x.Required && fieldNames.Contains(x.Field))
            .Select(x => x.Field)
            .Concat((alwaysRequiredFields ?? []).Where(fieldNames.Contains));
        return required
            .Select(field => SourceColumnFor(view, mode, field))
            .Where(column => !available.Contains(Normalize(column)))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>Builds field values (keyed by field name) from a source row. Unmapped fields read the column named like the field.</summary>
    public static Dictionary<string, string> MapRow(
        TemplateViewConfiguration view,
        string mode,
        IEnumerable<TemplateField> fields,
        IReadOnlyDictionary<string, string> sourceRow)
    {
        var lookup = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var (header, value) in sourceRow)
            lookup.TryAdd(Normalize(header), value);
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var field in fields)
            result[field.Name] = lookup.GetValueOrDefault(Normalize(SourceColumnFor(view, mode, field.Name)), "");
        return result;
    }

    /// <summary>Field-to-source-column map for a mode, suitable for storing as an ingestion task's field mapping.</summary>
    public static Dictionary<string, string> ToFieldMap(TemplateViewConfiguration view, string mode, IEnumerable<TemplateField> fields) =>
        fields.ToDictionary(x => x.Name, x => SourceColumnFor(view, mode, x.Name), StringComparer.OrdinalIgnoreCase);
}

/// <summary>Default ATM upload headers and the SQL columns they populate. Used to seed the editable template mapping and as a fallback.</summary>
public static class AtmSourceColumns
{
    public static readonly IReadOnlyList<(string Header, string Column)> OnUs =
    [
        ("Type of Settlement", "Settlement_Type"),
        ("CRM No/Proactive No", "CRM_Proactive_No"),
        ("Transaction Date", "Transaction_Date"),
        ("Date of Customer complaint", "Customer_Complaint_Date"),
        ("Date of credit to customer a/c", "Customer_Acc_Credit_Date"),
        ("Account Number", "Acc_No"),
        ("T+5 Calender Days", "T_5_Calender_Days"),
        ("Days", "Days"),
        ("Penalty (Rs.)", "Penalty_Rs"),
        ("ATM ID", "ATM_ID"),
        ("Transaction Number", "Transaction_No"),
        ("Transaction Amount", "Transaction_Amount"),
        ("Disputed Amount", "Disputed_Amount"),
        ("EJ Error", "EJ_Error"),
        ("Narration", "Narration")
    ];

    public static readonly IReadOnlyList<(string Header, string Column)> OffUs =
    [
        ("Chargeback reference no", "Chargeback_Ref_No"),
        ("Chargeback Date", "Chargeback_Date"),
        ("Acquiring Bank", "Acquiring_Bank"),
        ("Issuing Bank", "Issuing_Bank"),
        ("Transaction Date", "Transaction_Date"),
        ("Transaction Time", "Transaction_Time"),
        ("RRN no", "RRN_No"),
        ("ATM ID", "ATM_ID"),
        ("Card number", "CARD_No"),
        ("Transaction Amount", "Transaction_Amount"),
        ("Disputed Amount", "Disputed_Amount"),
        ("Customer Penalty", "Customer_Penalty"),
        ("Adjustment Date", "Adjustment_Date"),
        ("Adjustment Type", "Adjustment_Type"),
        ("Adjustment Time", "Adjustment_Time"),
        ("Narration", "Narration"),
        ("Adjustment Amount", "Adjustment_Amount")
    ];

    /// <summary>The file column that supplies the penalty amount; ATMID and PenaltyAmount are derived from ATM_ID and this column.</summary>
    public static string PenaltyField(string templateCode) =>
        string.Equals(templateCode, "ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? "Penalty_Rs" : "Customer_Penalty";

    /// <summary>
    /// The Bulk File Upload mapping an upload actually uses: the Alert Type's entries (CATS-managed columns excluded), or the defaults
    /// when it has none. ATM_ID and the penalty column are always present because case creation depends on them.
    /// </summary>
    public static List<SourceColumnMappingConfiguration> EffectiveBulkMappings(string templateCode, TemplateViewConfiguration view)
    {
        var defaults = TemplateMappings(templateCode);
        var entries = view.SourceColumnMappings
            .Where(x => x.Mode.Equals("BulkFileUpload", StringComparison.OrdinalIgnoreCase) && !AtmTableColumns.IsInternal(x.Field))
            .Select(x => new SourceColumnMappingConfiguration { Mode = "BulkFileUpload", Field = x.Field, SourceColumn = x.SourceColumn, Required = x.Required, Order = x.Order })
            .ToList();
        if (entries.Count == 0) return defaults;
        foreach (var field in new[] { "ATM_ID", PenaltyField(templateCode) })
        {
            if (entries.Any(x => x.Field.Equals(field, StringComparison.OrdinalIgnoreCase))) continue;
            var fallback = defaults.First(x => x.Field.Equals(field, StringComparison.OrdinalIgnoreCase));
            entries.Add(new() { Mode = "BulkFileUpload", Field = field, SourceColumn = fallback.SourceColumn, Required = true, Order = 0 });
        }
        return entries;
    }

    /// <summary>Fills upload metadata that the file did not supply: the file name, the uploader and the upload time.</summary>
    public static void ApplyUploadMetadata(IEnumerable<Dictionary<string, string>> rows, string fileName, string uploadedBy, DateTime uploadedAtUtc)
    {
        foreach (var row in rows)
        {
            void Default(string key, string value)
            {
                var existing = row.FirstOrDefault(x => x.Key.Equals(key, StringComparison.OrdinalIgnoreCase));
                if (existing.Key is null || string.IsNullOrWhiteSpace(existing.Value)) row[key] = value;
            }
            Default("UploadFileName", fileName);
            Default("CreatedBy", uploadedBy);
            Default("CreatedDate", uploadedAtUtc.ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture));
        }
    }

    public static bool IsAtmTemplate(string? code) =>
        string.Equals(code, "ATM_ONUS", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(code, "ATM_OFFUS", StringComparison.OrdinalIgnoreCase);

    public static IReadOnlyList<(string Header, string Column)> For(string templateCode) =>
        string.Equals(templateCode, "ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? OnUs : OffUs;

    /// <summary>
    /// Default Bulk File Upload mapping: the documented file columns in file order. The OnUs file has a fixed 15-column layout, so all
    /// are required; for OffUs only the ATM ID and penalty columns are required because its file layout is not fixed.
    /// </summary>
    public static List<SourceColumnMappingConfiguration> TemplateMappings(string templateCode)
    {
        var onUs = string.Equals(templateCode, "ATM_ONUS", StringComparison.OrdinalIgnoreCase);
        var penaltyHeader = onUs ? "Penalty (Rs.)" : "Customer Penalty";
        bool IsRequired(string header) => onUs || header == "ATM ID" || header == penaltyHeader;
        return For(templateCode)
            .Select((x, index) => new SourceColumnMappingConfiguration { Mode = "BulkFileUpload", Field = x.Column, SourceColumn = x.Header, Required = IsRequired(x.Header), Order = index + 1 })
            .ToList();
    }
}
