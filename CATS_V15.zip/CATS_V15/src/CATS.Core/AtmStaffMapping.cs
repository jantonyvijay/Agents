namespace CATS.Core;

/// <summary>
/// ATM Staff Mapping master (tbl_ATM_Txn_Mntr_MappingMaster): which staff handle each ATM. It is a standalone master, not a template, so its
/// file-to-table column mapping is configured on its own and stored in ATM_MasterSettings.
/// </summary>
public static class AtmStaffMappingColumns
{
    public const string Table = "tbl_ATM_Txn_Mntr_MappingMaster";
    public const string SettingKey = "StaffMapping";
    public const string BatchFileType = "StaffMapping";
    public const string KeyColumn = "ATM_ID";

    private static AtmTableColumn Text(string name, int length = 50) => new(name, AtmColumnKind.Text, length);
    private static AtmTableColumn Date(string name) => new(name, AtmColumnKind.DateTime);

    /// <summary>Every mappable table column (the identity column is excluded); names, types and lengths mirror the table.</summary>
    public static readonly IReadOnlyList<AtmTableColumn> All =
    [
        Text("ATM_ID", 250), Text("ATMC_EMPCode"), Text("ATMC_EMPCode_BK"), Text("RATC_EMPCode"), Text("RATC_EMPCode_BK"),
        Text("SH_EMPCode"), Text("WBO_RH_EMPCode"), Text("GH_EMPCode"), Text("RH_EMPCode"), Text("GH_EMPCode_BK"), Text("RH_EMPCode_BK"),
        Text("GH_EMPCode1"), Text("RH_EMPCode1"), Text("GH_EMPCode1_BK"), Text("RH_EMPCode1_BK"),
        Text("ATMC_EMPCode_Reassign"), Text("RATC_EMPCode_Reassign"), Text("SH_EMPCode_Reassign"),
        Text("STATE", 250), Text("Penalty_Month", 100), Text("Penalty_Year", 100),
        Text("RecordStatus", 10), Text("UploadFileName", 250), Text("CreatedBy"), Date("CreatedDate"),
        Text("ModifiedBy"), Date("ModifiedDate"), Text("ApprovedBy"), Date("ApprovedDate")
    ];

    /// <summary>Columns CATS fills itself when the file does not supply them (workflow, audit and upload metadata).</summary>
    public static readonly string[] SystemColumns =
        ["RecordStatus", "UploadFileName", "CreatedBy", "CreatedDate", "ModifiedBy", "ModifiedDate", "ApprovedBy", "ApprovedDate"];

    public static bool IsSystemColumn(string column) => SystemColumns.Contains(column, StringComparer.OrdinalIgnoreCase);

    public static AtmTableColumn? Find(string? column) =>
        All.FirstOrDefault(x => x.Name.Equals(column, StringComparison.OrdinalIgnoreCase));

    /// <summary>The documented upload header, in file order, with the table column each one fills.</summary>
    public static readonly IReadOnlyList<(string Header, string Column)> Defaults =
    [
        ("ATM ID", "ATM_ID"),
        ("ATMC Emp code", "ATMC_EMPCode"),
        ("Backup ATMC code", "ATMC_EMPCode_BK"),
        ("RATC Emp code", "RATC_EMPCode"),
        ("Backup RATC Emp code", "RATC_EMPCode_BK"),
        ("State Head Emp Code", "SH_EMPCode"),
        ("Backup State Head", "WBO_RH_EMPCode"),
        ("STATE", "STATE"),
        ("GH EmpCode", "GH_EMPCode"),
        ("RH EmpCode", "RH_EMPCode"),
        ("GH EmpCode1", "GH_EMPCode1"),
        ("Backup GH EmpCode", "GH_EMPCode_BK"),
        ("RH EmpCode1", "RH_EMPCode1"),
        ("Backup RH EmpCode", "RH_EMPCode_BK"),
        ("Backup GH EmpCode1", "GH_EMPCode1_BK"),
        ("Backup RH EmpCode1", "RH_EMPCode1_BK")
    ];

    /// <summary>Default mapping and file layout: tilde-delimited text with every documented header required.</summary>
    public static TemplateViewConfiguration DefaultConfiguration() => new()
    {
        BulkFileFormat = "Txt",
        BulkFileDelimiter = "~",
        SourceColumnMappings = Defaults
            .Select((x, index) => new SourceColumnMappingConfiguration { Mode = "BulkFileUpload", Field = x.Column, SourceColumn = x.Header, Required = true, Order = index + 1 })
            .ToList()
    };

    /// <summary>
    /// Validates and normalises an administrator-edited configuration. Returns an error message, or null when the configuration is usable.
    /// ATM_ID must stay mapped because it is the record key.
    /// </summary>
    public static string? Normalize(TemplateViewConfiguration view)
    {
        var cleaned = new List<SourceColumnMappingConfiguration>();
        foreach (var entry in view.SourceColumnMappings ?? [])
        {
            var column = Find((entry.Field ?? "").Trim());
            if (column is null) return $"'{entry.Field}' is not a column of {Table}.";
            var source = (entry.SourceColumn ?? "").Trim();
            if (source.Length == 0) source = column.Name;
            if (source.Length > SourceColumnMapper.MaxSourceColumnLength) return $"{column.Name}: file column cannot exceed {SourceColumnMapper.MaxSourceColumnLength} characters.";
            if (cleaned.Any(x => x.Field.Equals(column.Name, StringComparison.OrdinalIgnoreCase))) return $"{column.Name} is mapped more than once.";
            if (cleaned.Any(x => SourceColumnMapper.Normalize(x.SourceColumn) == SourceColumnMapper.Normalize(source)))
                return $"The file column '{source}' is mapped more than once.";
            cleaned.Add(new() { Mode = "BulkFileUpload", Field = column.Name, SourceColumn = source, Required = entry.Required || column.Name == KeyColumn, Order = Math.Clamp(entry.Order, 0, 10_000) });
        }
        if (!cleaned.Any(x => x.Field == KeyColumn)) return $"{KeyColumn} must stay in the mapping because it identifies the ATM.";
        view.SourceColumnMappings = cleaned
            .Select((x, index) => (Entry: x, Index: index))
            .OrderBy(x => x.Entry.Order > 0 ? x.Entry.Order : int.MaxValue).ThenBy(x => x.Index)
            .Select((x, index) => { x.Entry.Order = index + 1; return x.Entry; })
            .ToList();
        return null;
    }
}
