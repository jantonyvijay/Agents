namespace CATS.Core;

/// <summary>One entry of the navigation tree stored in MenuMaster: Menu → SubMenu → Child sub menu, to any depth.</summary>
public sealed class MenuNode
{
    public long Id { get; set; }
    public long? ParentId { get; set; }
    /// <summary>Only used by <see cref="MenuCatalog.Defaults"/>: the Code of the parent entry, resolved to <see cref="ParentId"/> when the menu is written to the database.</summary>
    public string? ParentCode { get; set; }
    public string Code { get; set; } = "";
    public string Label { get; set; } = "";
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string Icon { get; set; } = "dashboard";
    /// <summary>The screen this entry opens; empty for a menu or sub menu that only groups other entries.</summary>
    public string ViewKey { get; set; } = "";
    /// <summary>Permission needed to see the entry; empty means every signed-in user.</summary>
    public string PermissionCode { get; set; } = "";
    public int DisplayOrder { get; set; } = 100;
    /// <summary>When not empty, only these roles see the entry (a further restriction on top of the permission).</summary>
    public List<string> Roles { get; set; } = [];
}

/// <summary>A menu entry as returned to a signed-in user, with only the children that user may see.</summary>
public sealed class MenuItemView
{
    public string Code { get; set; } = "";
    public string Label { get; set; } = "";
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string Icon { get; set; } = "dashboard";
    public string View { get; set; } = "";
    public List<MenuItemView> Children { get; set; } = [];
}

public static class MenuCatalog
{
    private const int MaxDepth = 6;

    /// <summary>
    /// Builds the tree a user sees. An entry is visible when the user has its permission and, if roles are listed, holds one of them.
    /// A grouping entry with nothing visible below it is dropped, so a module appears only when the user can open something in it.
    /// </summary>
    public static List<MenuItemView> Build(IEnumerable<MenuNode> nodes, Func<string, bool> hasPermission, string roleCode)
    {
        var all = nodes.ToList();
        var defaultPermissions = Defaults
            .Where(node => !string.IsNullOrWhiteSpace(node.PermissionCode))
            .ToDictionary(node => node.Code, node => node.PermissionCode, StringComparer.OrdinalIgnoreCase);
        var ids = all.Select(x => x.Id).ToHashSet();
        var children = all.Where(x => x.ParentId.HasValue && ids.Contains(x.ParentId.Value))
            .ToLookup(x => x.ParentId!.Value);
        string PermissionCode(MenuNode node) =>
            defaultPermissions.TryGetValue(node.Code, out var required) ? required : node.PermissionCode;

        bool Visible(MenuNode node) =>
            // PermissionCode may list several permissions separated by ',' or '|'; holding any one of them is enough.
            (string.IsNullOrWhiteSpace(PermissionCode(node)) ||
                PermissionCode(node).Split([',', '|'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Any(hasPermission)) &&
            (node.Roles.Count == 0 || node.Roles.Contains(roleCode, StringComparer.OrdinalIgnoreCase));

        List<MenuItemView> Level(IEnumerable<MenuNode> level, int depth)
        {
            var result = new List<MenuItemView>();
            if (depth > MaxDepth) return result;
            foreach (var node in level.OrderBy(x => x.DisplayOrder).ThenBy(x => x.Label, StringComparer.OrdinalIgnoreCase))
            {
                if (!Visible(node)) continue;
                var view = new MenuItemView
                {
                    Code = node.Code, Label = node.Label, Title = node.Title, Description = node.Description,
                    Icon = string.IsNullOrWhiteSpace(node.Icon) ? "dashboard" : node.Icon, View = node.ViewKey ?? "",
                    Children = Level(children[node.Id], depth + 1)
                };
                if (view.View.Length > 0 || view.Children.Count > 0) result.Add(view);
            }
            return result;
        }
        return Level(all.Where(x => !x.ParentId.HasValue || !ids.Contains(x.ParentId.Value)), 1);
    }

    private static MenuNode Node(string code, string? parent, string label, int order, string view = "", string permission = "", string icon = "dashboard", string description = "", string title = "") =>
        new() { Code = code, ParentCode = parent, Label = label, DisplayOrder = order, ViewKey = view, PermissionCode = permission, Icon = icon, Description = description, Title = title };

    /// <summary>Entries that earlier versions seeded and that no longer exist. They are deactivated (not deleted) at startup.</summary>
    public static IReadOnlyList<string> RetiredCodes { get; } = ["operations.atm", "masters.atm.staffmaster", "operations.reports"];

    /// <summary>Anyone who works with ATM alerts may open the ATM report entries.</summary>
    private const string AtmReportPermissions = "ATM.OPERATIONS,ATM.UPLOAD,ATM.CHECK,ATM.CASE.MANAGE,ALERT.VIEWALL";

    /// <summary>The menu CATS ships with. It is written to MenuMaster once; afterwards the database owns it. ParentCode holds the parent's Code here.</summary>
    public static IReadOnlyList<MenuNode> Defaults { get; } =
    [
        Node("workspace", null, "Workspace", 10, title: "Your daily workspace", description: "Follow alerts from discovery to resolution."),
        Node("workspace.dashboard", "workspace", "Dashboard", 10, "dashboard", icon: "dashboard", description: "Overview, aging and activity"),
        Node("workspace.alerts", "workspace", "Alerts", 20, "alerts", icon: "alerts", description: "Review and track your alerts"),
        Node("workspace.newalert", "workspace", "New / Upload Alerts", 30, "newAlert", CatsPermissions.AlertUpload + "," + CatsPermissions.AtmCheck, "upload", "Create or import alerts; ATM checkers approve uploads here"),

        Node("operations", null, "Operations", 20, permission: PlatformPermissions.IngestionView + "," + PlatformPermissions.MailManage, title: "Keep work moving", description: "Manage ingestion and communications."),
        Node("operations.ingestion", "operations", "Ingestion", 20, "ingestion", PlatformPermissions.IngestionView, "upload", "Scheduled tasks and execution logs"),
        Node("operations.mail", "operations", "Mail Configuration", 40, "mail", PlatformPermissions.MailManage, "mail", "Email templates and delivery history"),

        Node("reports", null, "Reports", 25, permission: PlatformPermissions.ReportsAll, title: "Know where you stand", description: "Explore and export reports, module by module."),
        Node("reports.all", "reports", "All Alert Reports", 10, "reports", PlatformPermissions.ReportsAll, "reports", "MIS, Alert Wise and All Alert reports"),
        Node("reports.atm", "reports", "ATM", 20, icon: "reports", description: "ATM transaction monitoring reports"),
        Node("reports.atm.onus", "reports.atm", "OnUs Reports", 10, "reports:ATM_ONUS", AtmReportPermissions, "reports", "ATM Transaction Monitoring - OnUs"),
        Node("reports.atm.offus", "reports.atm", "OffUs Reports", 20, "reports:ATM_OFFUS", AtmReportPermissions, "reports", "ATM Transaction Monitoring - OffUs"),

        Node("masters", null, "Masters", 30, title: "Reference data", description: "Maintain the master data that drives case routing."),
        Node("masters.atm", "masters", "ATM", 10, icon: "upload", description: "ATM masters"),
        Node("masters.atm.staffmapping", "masters.atm", "Staff Mapping", 10, "atmStaffList", CatsPermissions.AtmMasterView, "upload", "ATM to staff mapping master"),

        Node("design", null, "Design", 40, title: "Build your workflow", description: "Shape the forms and stages that guide your team."),
        Node("design.templates", "design", "Template Designer", 10, "templates", CatsPermissions.TemplateManage, "dashboard", "Configure fields and alert forms"),
        Node("design.workflow", "design", "Workflow Designer", 20, "workflow", CatsPermissions.WorkflowManage, "workflow", "Design stages and approval paths"),

        Node("administration", null, "Admin", 50, title: "Connected and in control", description: "Manage workspace settings and connected tools."),
        Node("administration.admin", "administration", "Administration", 10, "admin", "SECURITY.MANAGE", "settings", "Manage application settings"),
        Node("administration.rolepermissions", "administration", "Role Permissions", 15, "rolePermissions", CatsPermissions.RolePermissionsManage, "settings", "Set permissions role-wise for all users"),
        Node("administration.diagnostics", "administration", "Monitoring & Troubleshooting", 18, "diagnostics", CatsPermissions.DiagnosticsView, "operations", "Find errors by Reference ID, user or module and see what to do"),
        Node("administration.mcp", "administration", "MCP Servers", 20, "mcp", "MCP.MANAGE", "workflow", "Discover and monitor connected tools")
    ];
}
