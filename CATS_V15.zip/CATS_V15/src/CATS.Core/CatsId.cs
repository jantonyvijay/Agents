namespace CATS.Core;

/// <summary>
/// Hands out BIGINT identifiers. Each process reserves blocks of <see cref="BlockSize"/> values from the
/// database sequence (dbo.seq_CatsId increments by BlockSize), so ids stay unique across the API,
/// workers and the database itself while normal calls never touch the database.
/// </summary>
public static class CatsId
{
    public const int BlockSize = 100;

    private static readonly object Gate = new();
    private static Func<long>? _reserveBlock;
    private static long _next;
    private static long _limit;

    /// <summary>Registers the function that returns the first value of a newly reserved block.</summary>
    public static void Configure(Func<long> reserveBlock)
    {
        lock (Gate)
        {
            _reserveBlock ??= reserveBlock;
        }
    }

    public static long Next()
    {
        lock (Gate)
        {
            if (_next >= _limit)
            {
                var reserve = _reserveBlock ?? throw new InvalidOperationException("CatsId has not been configured with a database sequence.");
                _next = reserve();
                _limit = _next + BlockSize;
            }
            return _next++;
        }
    }
}
