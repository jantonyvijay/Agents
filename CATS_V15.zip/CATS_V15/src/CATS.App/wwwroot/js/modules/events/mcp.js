import { observeTask } from './guard.js';
import { guardEvent } from './guard.js';
import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { toast } from '../ui/feedback.js';
import { renderMcpDiscovery } from '../features/mcp.js';

/**
 * Bind mcp discovery actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: servers, discover.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindMcpDiscoveryEvents({ servers, discover }) {
    $('.mcp-discover').on(
        'click',
        guardEvent(function () {
            const code = String($(this).data('code') || '');
            $('#mcpDiscoveryResults').empty();
            observeTask(discover(code));
        }),
    );
    $('#mcpEndpointDiscoveryForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            const button = $('#mcpEndpointDiscover');
            const request = {
                name: $('#mcpEndpointName').val().trim(),
                endpoint: $('#mcpEndpointUrl').val().trim(),
                timeoutSeconds: 30,
            };
            try {
                button.prop('disabled', true).text('Connecting...');
                const result = await api('/api/mcp/discover', { method: 'POST', body: request });
                const tools = result.tools || [];
                const toolRows = tools
                    .map(
                        (t) =>
                            `<tr><td><code>${esc(t.name)}</code></td><td>${esc(t.description || '')}</td><td><span class="badge text-bg-secondary">Session discovery only</span></td></tr>`,
                    )
                    .join('');
                $('#mcpDiscoveryResults').prepend(
                    `<div class="card mb-3 border-success"><div class="card-header bg-white d-flex justify-content-between align-items-center"><span class="fw-semibold">${esc(result.serverName || request.name || request.endpoint)} - Available tools</span><span class="badge text-bg-success">Connected / ${tools.length} tools</span></div><div class="card-body py-2 small text-secondary text-break">${esc(request.endpoint)}</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Tool</th><th>Description</th><th>Assistant access</th></tr></thead><tbody>${toolRows || '<tr><td colspan="3" class="text-secondary">Connected successfully; the server returned no tools.</td></tr>'}</tbody></table></div></div>`,
                );
                $('#mcpEndpointName,#mcpEndpointUrl').val('');
                toast(`${result.serverName || 'MCP server'} discovered`);
            } catch (x) {
                toast(x.message, 'danger');
            } finally {
                button.prop('disabled', false).text('Discover server');
            }
        }),
    );
    $('#mcpClearResults').on(
        'click',
        guardEvent(() => {
            $('#mcpDiscoveryResults').empty();
            toast('Discovery results cleared', 'secondary');
        }),
    );
    $('#mcpResetPage').on(
        'click',
        guardEvent(async () => {
            $('#mcpEndpointName,#mcpEndpointUrl').val('');
            await renderMcpDiscovery();
            toast('MCP server page reset', 'secondary');
        }),
    );
    await Promise.all(servers.filter((x) => x.enabled).map((x) => discover(String(x.code))));
}

export { bindMcpDiscoveryEvents };
