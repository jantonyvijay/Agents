import { guardEvent } from './guard.js';
import { has } from '../core/permissions.js';
import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { toast } from '../ui/feedback.js';

/**
 * Bind admin actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: users, buckets, userEditor, bucketEditor.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindAdminEvents({ users, buckets, userEditor, bucketEditor }) {
    $('#newUserBtn').on(
        'click',
        guardEvent(() => userEditor(null)),
    );
    $('.edit-user').on(
        'click',
        guardEvent(function () {
            userEditor(users.find((x) => String(x.id) === String($(this).data('id'))));
        }),
    );
    $('#newBucketBtn').on(
        'click',
        guardEvent(() => bucketEditor(null)),
    );
    $('.edit-bucket').on(
        'click',
        guardEvent(function () {
            bucketEditor(buckets.find((x) => String(x.id) === String($(this).data('id'))));
        }),
    );

    if (false && has('MCP.MANAGE')) {
        try {
            const servers = await api('/api/mcp/servers');
            const rows = servers
                .map(
                    (x) =>
                        `<tr><td>${esc(x.name || x.code)}</td><td><code>${esc(x.code)}</code></td><td class="text-break small">${esc(x.endpoint)}</td><td>${x.enabled ? '<span class="badge text-bg-success">Enabled</span>' : '<span class="badge text-bg-secondary">Disabled</span>'}</td><td>${x.approvedToolCount || 0}</td><td class="text-end"><button class="btn btn-sm btn-outline-primary mcp-discover" data-code="${esc(x.code)}">Discover</button></td></tr>`,
                )
                .join('');
            $('#viewHost').append(
                `<div class="card mt-3"><div class="card-header bg-white d-flex justify-content-between align-items-center"><div><div class="fw-semibold">MCP Server Discovery</div><div class="small text-secondary">Connections are created by the CATS API through the gateway-managed application. Discovered tools are not automatically approved.</div></div></div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Server</th><th>Code</th><th>Endpoint</th><th>Status</th><th>Approved tools</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="text-secondary text-center py-4">No MCP servers are configured in the MCP configuration section.</td></tr>'}</tbody></table></div><div id="mcpDiscoveryResult" class="card-body border-top d-none"></div></div>`,
            );
            $('.mcp-discover').on(
                'click',
                guardEvent(async function () {
                    const button = $(this),
                        code = String(button.data('code') || '');
                    const original = button.text();
                    try {
                        button.prop('disabled', true).text('Discovering…');
                        const result = await api(`/api/mcp/servers/${encodeURIComponent(code)}/discover`, {
                            method: 'POST',
                        });
                        const tools = (result.tools || [])
                            .map(
                                (t) =>
                                    `<tr><td><code>${esc(t.name)}</code></td><td>${esc(t.description || '')}</td><td>${t.approvedReadOnly ? '<span class="badge text-bg-success">Approved read-only</span>' : '<span class="badge text-bg-warning">Not approved</span>'}</td></tr>`,
                            )
                            .join('');
                        $('#mcpDiscoveryResult')
                            .removeClass('d-none')
                            .html(
                                `<div class="fw-semibold mb-2">${esc(result.serverName || code)} · Discovered tools</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Tool</th><th>Description</th><th>Assistant policy</th></tr></thead><tbody>${tools || '<tr><td colspan="3" class="text-secondary">No tools were returned.</td></tr>'}</tbody></table></div>`,
                            );
                    } catch (x) {
                        toast(x.message, 'danger');
                    } finally {
                        button.prop('disabled', false).text(original);
                    }
                }),
            );
        } catch (x) {
            $('#viewHost').append(
                `<div class="alert alert-warning mt-3"><b>MCP discovery:</b> ${esc(x.message)}</div>`,
            );
        }
    }
}

export { bindAdminEvents };
