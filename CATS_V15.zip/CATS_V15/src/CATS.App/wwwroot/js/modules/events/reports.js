import { downloadFile } from '../ui/downloads.js';
import { guardEvent } from './guard.js';
import { api } from '../api/client.js';
import { esc } from '../core/utils.js';

/**
 * Bind platform reports actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: query.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindPlatformReportsEvents({ query }) {
    $('#reportForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            const r = await api('/api/platform/reports/' + $('#reportType').val() + '?' + query());
            const rows = r.data || [];
            if (!rows.length) {
                $('#reportHost').html('<span class="text-secondary">No matching records.</span>');
                return;
            }
            const keys = Object.keys(rows[0].values).filter((k) => !/^template(name|id)?$/i.test(k));
            $('#reportHost').html(
                `<div class="mb-2">${r.totalRecords} record(s)</div><div class="table-responsive"><table class="table table-sm"><thead><tr>${keys.map((k) => `<th>${esc(k)}</th>`).join('')}</tr></thead><tbody>${rows.map((x) => `<tr>${keys.map((k) => `<td>${esc(x.values[k] ?? '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`,
            );
        }),
    );
    $('#reportCsv').on(
        'click',
        guardEvent(async () => {
            await downloadFile(
                '/api/platform/reports/' + $('#reportType').val() + '/export?' + query(),
                `CATS-${$('#reportType').val()}.csv`,
            );
        }),
    );
}

export { bindPlatformReportsEvents };
