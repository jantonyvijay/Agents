import { observeTask } from './guard.js';
import { guardEvent } from './guard.js';
import {
    renderOverviewDashboard,
    renderConfiguredTemplateDashboard,
    renderTemplateDashboardManager,
} from '../features/dashboard.js';
import { toast } from '../ui/feedback.js';

/**
 * Bind dashboard actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: .
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindDashboardEvents({}) {
    $('#dashboardMode').on(
        'change',
        guardEvent(async function () {
            const id = $(this).val();
            if (id === 'overview') await renderOverviewDashboard('#dashboardContent');
            else await renderConfiguredTemplateDashboard(id, '#dashboardContent');
        }),
    );
    $('#manageTemplateDashboards').on(
        'click',
        guardEvent(() => renderTemplateDashboardManager()),
    );
    await renderOverviewDashboard('#dashboardContent');
}

/**
 * Bind overview dashboard actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: firstAlertType, updateDashboardHeader, load.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindOverviewDashboardEvents({ firstAlertType, updateDashboardHeader, load }) {
    $('#dashAlertType').on(
        'change',
        guardEvent(async function () {
            updateDashboardHeader(this.value);
            await load();
        }),
    );
    $('#dashFilter').on(
        'submit',
        guardEvent((e) => {
            e.preventDefault();
            updateDashboardHeader($('#dashAlertType').val());
            load().catch((x) => toast(x.message, 'danger'));
        }),
    );
    if (firstAlertType) await load();
    else
        $('#dashBody').html(
            '<div class="alert alert-light border text-secondary">No published alert types are available for this dashboard.</div>',
        );
}

/**
 * Bind configured template dashboard actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: load.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindConfiguredTemplateDashboardEvents({ load }) {
    $('#tdSearch').on(
        'submit',
        guardEvent((e) => {
            e.preventDefault();
            load(1).catch((x) => toast(x.message, 'danger'));
        }),
    );
    $('#tdClear').on(
        'click',
        guardEvent(() => {
            $('.td-search').val('');
            observeTask(load(1));
        }),
    );
    await load(1);
}

/**
 * Bind template dashboard manager actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: dashboards, open, normalizeAlertTypeDashboardModal.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindTemplateDashboardManagerEvents({ dashboards, open, normalizeAlertTypeDashboardModal }) {
    $('#addTemplateDashboard').on(
        'click',
        guardEvent(() => {
            observeTask(open());
            normalizeAlertTypeDashboardModal();
        }),
    );
    $('.edit-td').on(
        'click',
        guardEvent(function () {
            const item = dashboards.find((x) => String(x.id) === String($(this).data('id'))) || {};
            observeTask(open(item));
            normalizeAlertTypeDashboardModal(item.templateId || '');
        }),
    );
}

export {
    bindDashboardEvents,
    bindOverviewDashboardEvents,
    bindConfiguredTemplateDashboardEvents,
    bindTemplateDashboardManagerEvents,
};
