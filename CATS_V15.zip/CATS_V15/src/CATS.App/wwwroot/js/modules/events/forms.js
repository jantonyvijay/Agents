import { readFieldConfiguration } from '../business/form-data.js';
import { observeTask } from './guard.js';
import { guardEvent } from './guard.js';
import { loadApiSelect } from '../api/select-options.js';

/**
 * Initialize field counters, dependent API choices, invalid-state reset, and wizard navigation.
 * @param {*} root - DOM subtree or selector containing the target controls.
 * @param {*} cssClass - Class identifying configured form controls.
 * @returns {void} Updates the relevant UI or state.
 */
function bindConfiguredFields(root, cssClass) {
    const synchronizeOnUsPenaltyFields = () => {
        const recoverable = String($(root).find(`.${cssClass}[data-name="Recoverable_Type"]`).val() || '');
        const isRecoverable = recoverable.toLowerCase() === 'recoverable';
        const noPenalty = recoverable === 'Goodfaith' || recoverable === 'Service Gesture';
        $(root)
            .find(`.${cssClass}[data-name="Recoverable_VendorName"], .${cssClass}[data-name="Recovery_Reason"], .${cssClass}[data-name="RecoveryReason_Remark"]`)
            .prop('disabled', !isRecoverable);
        $(root)
            .find(`.${cssClass}[data-name="NoPenaltyApplicable"]`)
            .prop('checked', noPenalty)
            .prop('disabled', true)
            .closest('.form-check')
            .toggleClass('d-none', !noPenalty);
    };
    $(root)
        .find(`.${cssClass}`)
        .each(function () {
            const el = $(this),
                f = readFieldConfiguration(el);
            el.data('initial-value', el.val()); /**
             * Refresh the character counter from the current control value and configured limit.
             * @returns {void} Updates the relevant UI or state.
             */
            const updateCounter = () => {
                if (f.maxLength != null)
                    $(root)
                        .find(`[data-counter-for="${f.name}"]`)
                        .text(`${String(el.val() ?? '').length}/${f.maxLength}`);
            };
            el.on(
                'input change',
                guardEvent(() => {
                    updateCounter();
                    el.removeClass('is-invalid');
                }),
            );
    $(root)
            .find(`.${cssClass}[data-name="Recoverable_Type"]`)
            .on('change', guardEvent(synchronizeOnUsPenaltyFields));
    synchronizeOnUsPenaltyFields();
            updateCounter();
        });
    $(root)
        .find('.cats-api-select')
        .each(function () {
            observeTask(loadApiSelect($(this), root, cssClass));
        });
    $(root)
        .find(`.${cssClass}`)
        .on(
            'change',
            guardEvent(function () {
                const changed = String($(this).data('name') || '');
                $(root)
                    .find('.cats-api-select')
                    .each(function () {
                        const f = readFieldConfiguration($(this));
                        if (
                            String(f.dependsOnFields || '')
                                .split(',')
                                .map((x) => x.trim().toLowerCase())
                                .includes(changed.toLowerCase())
                        )
                            observeTask(loadApiSelect($(this), root, cssClass));
                    });
            }),
        );
    $(root)
        .find('.cats-wizard')
        .each(function () {
            /**
             * Select a wizard step and synchronize the active pane and navigation buttons.
             * @param {*} i - Zero-based item or step index.
             * @returns {void} Updates the relevant UI or state.
             */
            const wizard = $(this),
                show = (i) => {
                    wizard
                        .find('.cats-wizard-pane')
                        .addClass('d-none')
                        .filter(`[data-step="${i}"]`)
                        .removeClass('d-none');
                    wizard
                        .find('.cats-wizard-step')
                        .removeClass('btn-primary')
                        .addClass('btn-outline-secondary')
                        .filter(`[data-step="${i}"]`)
                        .addClass('btn-primary')
                        .removeClass('btn-outline-secondary');
                };
            wizard.on(
                'click',
                '.cats-wizard-next',
                guardEvent(function () {
                    show(Number($(this).closest('.cats-wizard-pane').data('step')) + 1);
                }),
            );
            wizard.on(
                'click',
                '.cats-wizard-prev',
                guardEvent(function () {
                    show(Number($(this).closest('.cats-wizard-pane').data('step')) - 1);
                }),
            );
            wizard.on(
                'click',
                '.cats-wizard-step:not(:disabled)',
                guardEvent(function () {
                    show(Number($(this).data('step')));
                }),
            );
        });
}

export { bindConfiguredFields };
