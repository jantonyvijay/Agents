import { observeTask } from './guard.js';
import { guardEvent } from './guard.js';
import { api } from '../api/client.js';
import { toast } from '../ui/feedback.js';
import { renderPlatformMail } from '../features/mail.js';

/**
 * Bind platform mail actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: .
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindPlatformMailEvents({}) {
    $('#mailProviderPopupForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            await api('/api/platform/mail/configurations', {
                method: 'POST',
                body: {
                    name: $('#mcName').val(),
                    providerType: 'SMTP',
                    host: $('#mcHost').val(),
                    port: Number($('#mcPort').val()),
                    userName: $('#mcUser').val(),
                    secretEncrypted: $('#mcSecret').val(),
                    fromAddress: $('#mcFrom').val(),
                    useSsl: true,
                    isActive: true,
                },
            });
            bootstrap.Modal.getInstance(document.getElementById('mailProviderModal'))?.hide();
            toast('Mail configuration saved.', 'success');
            observeTask(renderPlatformMail());
        }),
    );
    $('#mailTemplatePopupForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            await api('/api/platform/mail/templates', {
                method: 'POST',
                body: {
                    templateId: $('#mtTemplate').val(),
                    eventCode: $('#mtEvent').val(),
                    subjectTemplate: $('#mtSubject').val(),
                    bodyTemplate: $('#mtBody').val(),
                    useMafEnrichment: false,
                    isActive: true,
                },
            });
            bootstrap.Modal.getInstance(document.getElementById('mailTemplateModal'))?.hide();
            toast('Email template saved.', 'success');
            observeTask(renderPlatformMail());
        }),
    );
}

export { bindPlatformMailEvents };
