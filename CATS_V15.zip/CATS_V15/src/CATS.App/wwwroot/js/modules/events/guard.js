import { toast } from '../ui/feedback.js';

/**
 * Wrap a jQuery handler so synchronous errors and returned promise rejections reach the user.
 * Calls the handler with the original receiver and arguments; preserves synchronous return false.
 * @param {Function} handler - Existing event callback.
 * @returns {Function} Callback with the same event arguments and safe asynchronous completion.
 */
function guardEvent(handler) {
    return function (...args) {
        try {
            const result = handler.apply(this, args);
            if (result && typeof result.then === 'function') return result.catch(reportEventError);
            return result;
        } catch (error) {
            reportEventError(error);
        }
    };
}
/**
 * Show a readable failure without changing form values or retrying a mutating request.
 * @param {unknown} error - Exception thrown by a UI action.
 * @returns {void}
 */
function reportEventError(error) {
    toast(error?.message || 'The action could not be completed. Please try again.', 'danger');
}

export { guardEvent, reportEventError };

/**
 * Observe work started by a timer or callback that cannot await its result.
 * @param {Promise<*>|*} task - Already-started operation; synchronous values are accepted.
 * @returns {Promise<void>} Settles after reporting any rejection through the common UI error handler.
 */
export async function observeTask(task) {
    try {
        await task;
    } catch (error) {
        reportEventError(error);
    }
}
