import { observeTask } from './guard.js';
import { guardEvent } from './guard.js';
import { toast } from '../ui/feedback.js';
import { uid, esc } from '../core/utils.js';
import { templateAllowsBaseDataMode } from '../business/templates.js';
import { api } from '../api/client.js';
import { renderPlatformIngestion } from '../features/ingestion.js';

/**
 * Bind platform ingestion actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: weekdayNames, ingestionSources, ingestionTemplates, showPage.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindPlatformIngestionEvents({ weekdayNames, ingestionSources, ingestionTemplates, showPage }) {
    $('#showIngestionRecords').on(
        'click',
        guardEvent(() => showPage(false)),
    );
    $('#showIngestionLogs').on(
        'click',
        guardEvent(() => showPage(true)),
    );

    const today = (() => {
        const date = new Date();
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    })();
    /**
     * Renumber ingestion trigger headings after insertion or removal.
     * @returns {void} Updates the relevant UI or state.
     */
    const renumberTriggers = () =>
        $('.ingestion-trigger').each(function (index) {
            $(this)
                .find('.ingestion-trigger-title')
                .text(`Trigger ${index + 1}`);
        });
    /**
     * Append a schedule trigger, enforce the existing twenty-trigger limit, and bind its controls.
     * @param {*} [values] - Existing trigger values or defaults for a new trigger.
     * @returns {void} Updates the relevant UI or state.
     */
    const addTrigger = (values = {}) => {
        if ($('.ingestion-trigger').length >= 20) {
            toast('A task can contain up to 20 triggers.', 'warning');
            return;
        }
        const id = values.id || uid();
        $('#icTriggers').append(
            `<div class="ingestion-trigger" data-trigger-id="${esc(id)}"><div class="d-flex justify-content-between align-items-center mb-2"><span class="ingestion-trigger-title fw-semibold"></span><button type="button" class="btn btn-sm btn-link text-danger text-decoration-none ic-remove-trigger">Remove</button></div><div class="row g-2 align-items-end"><div class="col-md-3"><label class="form-label">Repeat</label><select class="form-select ic-trigger-frequency"><option value="ONCE">One time</option><option value="DAILY">Daily</option><option value="WEEKLY">Weekly</option><option value="MONTHLY">Monthly</option></select></div><div class="col-md-3"><label class="form-label">Start date</label><input type="date" class="form-control ic-trigger-date" required></div><div class="col-md-2"><label class="form-label">Time</label><input type="time" class="form-control ic-trigger-time" required></div><div class="col-md-3 ic-trigger-extra"></div><div class="col-md-1"></div></div></div>`,
        );
        const card = $('#icTriggers .ingestion-trigger').last();
        card.find('.ic-trigger-frequency').val(values.frequency || 'DAILY');
        card.find('.ic-trigger-date').val(values.startDate || today);
        card.find('.ic-trigger-time').val(values.startTime || '09:00');
        /**
         * Render the additional weekday or month-day controls required by the selected frequency.
         * @returns {void} Updates the relevant UI or state.
         */
        const updateExtra = () => {
            const frequency = card.find('.ic-trigger-frequency').val();
            const host = card.find('.ic-trigger-extra').empty();
            if (frequency === 'WEEKLY') {
                host.html(
                    `<label class="form-label">Day of week</label><select class="form-select ic-trigger-weekday">${weekdayNames.map((name, index) => `<option value="${index}">${name}</option>`).join('')}</select>`,
                );
                host.find('select').val(values.dayOfWeek ?? 1);
            } else if (frequency === 'MONTHLY') {
                host.html(
                    '<label class="form-label">Day of month</label><input type="number" min="1" max="31" value="1" class="form-control ic-trigger-monthday" required>',
                );
                host.find('input').val(values.dayOfMonth ?? 1);
            }
        };
        card.find('.ic-trigger-frequency').on(
            'change',
            guardEvent(() => {
                values = {};
                updateExtra();
            }),
        );
        card.find('.ic-remove-trigger').on(
            'click',
            guardEvent(() => {
                if ($('.ingestion-trigger').length === 1) {
                    toast('At least one trigger is required.', 'warning');
                    return;
                }
                card.remove();
                renumberTriggers();
            }),
        );
        updateExtra();
        renumberTriggers();
    };
    $('#icAddTrigger').on(
        'click',
        guardEvent(() => addTrigger()),
    );
    addTrigger();

    /**
     * Restrict ingestion sources to modes enabled by the selected alert template.
     * @returns {void} Updates the relevant UI or state.
     */
    const updateIngestionSourceOptions = () => {
        const template = ingestionTemplates.find((item) => item.id === $('#icTemplate').val());
        const options = template
            ? ingestionSources.filter((source) => templateAllowsBaseDataMode(template, source.mode))
            : [];
        $('#icType')
            .prop('disabled', !options.length)
            .html(
                options.length
                    ? options.map((source) => `<option value="${source.value}">${source.label}</option>`).join('')
                    : '<option value="">Select alert type first</option>',
            );
        toggleSourceFields();
    };
    /**
     * Switch between SFTP connection controls and query controls for the selected source.
     * @returns {void} Updates the relevant UI or state.
     */
    const toggleSourceFields = () => {
        const sftp = $('#icType').val() === 'SFTP';
        $('#icSftpFields').toggleClass('d-none', !sftp).find('input').prop('required', sftp);
        $('#icQueryFields').toggleClass('d-none', sftp).find('textarea').prop('required', !sftp);
    };
    $('#icTemplate').on('change', guardEvent(updateIngestionSourceOptions));
    $('#icType').on('change', guardEvent(toggleSourceFields));
    updateIngestionSourceOptions();

    $('#ingestionForm').on(
        'submit',
        guardEvent(async (event) => {
            event.preventDefault();
            try {
                const triggers = $('.ingestion-trigger')
                    .map(function () {
                        const card = $(this),
                            frequency = card.find('.ic-trigger-frequency').val();
                        return {
                            id: String(card.data('trigger-id')),
                            frequency,
                            startDate: card.find('.ic-trigger-date').val(),
                            startTime: card.find('.ic-trigger-time').val(),
                            dayOfWeek: frequency === 'WEEKLY' ? Number(card.find('.ic-trigger-weekday').val()) : null,
                            dayOfMonth:
                                frequency === 'MONTHLY' ? Number(card.find('.ic-trigger-monthday').val()) : null,
                            cron: '',
                        };
                    })
                    .get();
                const sourceType = $('#icType').val();
                await api('/api/platform/ingestion/configurations', {
                    method: 'POST',
                    body: {
                        name: $('#icName').val(),
                        templateId: $('#icTemplate').val(),
                        sourceType,
                        filePath: sourceType === 'SFTP' ? $('#icFilePath').val() : '',
                        fileName: sourceType === 'SFTP' ? $('#icFileName').val() : '',
                        filePattern: sourceType === 'SFTP' ? $('#icFileName').val() : '',
                        queryText: sourceType === 'QUERY' ? $('#icQuery').val() : '',
                        scheduleTriggersJson: JSON.stringify(triggers),
                        scheduleCron: '',
                        intervalMinutes: 1,
                        fieldMappingJson: '{}',
                        duplicateKeyFields: '',
                        archivePath: '',
                        errorPath: '',
                        isActive: $('#icEnabled').is(':checked'),
                    },
                });
                bootstrap.Modal.getInstance(document.getElementById('ingestionAddModal'))?.hide();
                toast('Ingestion task saved.', 'success');
                observeTask(renderPlatformIngestion());
            } catch (error) {
                toast(error.message, 'danger');
            }
        }),
    );
}

export { bindPlatformIngestionEvents };
