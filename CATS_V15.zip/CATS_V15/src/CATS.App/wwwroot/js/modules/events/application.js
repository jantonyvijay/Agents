import { observeTask } from './guard.js';
import { sessionStore, localStore } from '../core/storage.js';
import { guardEvent } from './guard.js';
import { updateFieldLimitVisibility } from '../features/template-designer.js';
import { enableMovableModals } from '../ui/modals.js';
import { enhanceGrid } from '../ui/grid.js';
import { state } from '../core/state.js';
import { api } from '../api/client.js';
import { toast } from '../ui/feedback.js';
import { renderDetail } from '../features/alerts.js';
import {
    applyTheme,
    preferenceKey,
    applyLayout,
    toggleSidebar,
    applySectionLayout,
    themeMedia,
    handleSystemThemeChange,
    getThemePreference,
} from '../ui/appearance.js';
import { setPasswordVisibility, setLoginStatus, setLoginBusy } from '../ui/account.js';
import { showApp, signOut, logout, showLogin } from '../core/session.js';
import { loadTemplates, loadRoles } from '../api/catalogs.js';
import { navigate } from '../core/navigation.js';
import { piEye, piMaskEye, enhancePiGrids } from '../ui/privacy.js';
import { templateFieldControlHtml } from '../ui/forms.js';
import { bindConfiguredFields } from './forms.js';
import {
    appendAssistantMessage,
    drainAssistantSpeechCapture,
    startAssistantSpeechCapture,
    stopAssistantSpeechCapture,
} from '../features/assistant.js';
import {
    enhanceCommandButtons,
    removeWorkflowDefinitionJson,
    hideAssignmentRulesJson,
    enhanceDesignerActions,
    enhanceGridActions,
    enhanceGridToolbar,
} from '../ui/enhancements.js';

let assistantSpeechTimer;
let assistantSpeechQueue = Promise.resolve();

/**
 * Bind application actions using the rendered screen context, preserving filters and initial loading.
 * @returns {void} Updates the relevant UI or state.
 */
function bindApplicationEvents() {
    $('#fieldType,#fieldRequired').on('change', guardEvent(updateFieldLimitVisibility));

    enableMovableModals();

    new MutationObserver(() => $('#viewHost table').each((_, table) => enhanceGrid(table))).observe(
        document.getElementById('viewHost'),
        { childList: true, subtree: true },
    );

    $('#aiSuggestQueryBtn').on(
        'click',
        guardEvent(async () => {
            const a = state.pendingAction;
            if (!a || !a.aiQueryEnabled) return;
            const btn = $('#aiSuggestQueryBtn');
            try {
                btn.prop('disabled', true).text('Generating…');
                $('#aiQueryStatus')
                    .removeClass('text-danger text-success')
                    .addClass('text-secondary')
                    .text('Preparing a draft from the authorised alert context…');
                const result = await api(`/api/alerts/${a.id}/ai-query-suggestion`, {
                    method: 'POST',
                    body: { instruction: $('#aiQueryInstruction').val() || null },
                });
                $('#actionRemarks').val(result.queryText || '');
                $('#aiQueryStatus')
                    .removeClass('text-secondary text-danger')
                    .addClass('text-success')
                    .text(
                        `Draft generated${result.model ? ` using ${result.model}` : ''}. Review/edit before confirming.`,
                    );
            } catch (x) {
                $('#aiQueryStatus')
                    .removeClass('text-secondary text-success')
                    .addClass('text-danger')
                    .text(x.message || 'AI Query suggestion failed. You can continue typing the query manually.');
            } finally {
                btn.prop('disabled', false).text('✨ Suggest Query');
            }
        }),
    );

    $('#confirmActionBtn').on(
        'click',
        guardEvent(async () => {
            if (!state.pendingAction) return;
            const a = state.pendingAction;
            try {
                await api(`/api/alerts/${a.id}/action`, {
                    method: 'POST',
                    body: { action: a.action, remarks: $('#actionRemarks').val(), data: a.collect ? a.collect() : {} },
                });
                bootstrap.Modal.getOrCreateInstance('#actionModal').hide();
                toast(`${a.action} completed`);
                state.pendingAction = null;
                observeTask(renderDetail(a.id));
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );

    $('.theme-option[data-theme]').on(
        'click',
        guardEvent(function () {
            applyTheme($(this).data('theme'));
        }),
    );

    $('#customThemeColor')
        .on(
            'click',
            guardEvent((event) => event.stopPropagation()),
        )
        .on(
            'input change',
            guardEvent(function (event) {
                event.stopPropagation();
                const color = this.value.toUpperCase();
                try {
                    localStore.setItem(preferenceKey('theme_color'), color);
                } catch {}
                applyTheme('custom');
            }),
        );

    $('#userLayout').on(
        'change',
        guardEvent(function () {
            applyLayout(this.value);
        }),
    );

    $('#userSectionLayout').on(
        'change',
        guardEvent(function () {
            applySectionLayout(this.value);
            toast('Section layout saved. It applies when you next open an alert or create a new one.');
        }),
    );

    if (themeMedia.addEventListener) themeMedia.addEventListener('change', handleSystemThemeChange);
    else themeMedia.addListener(handleSystemThemeChange);

    applyTheme(getThemePreference(), false);

    $('#toggleLoginPassword').on(
        'click',
        guardEvent(() => setPasswordVisibility($('#loginPassword').attr('type') === 'password')),
    );

    $('#loginUser, #loginPassword').on(
        'input',
        guardEvent(() => setLoginStatus()),
    );

    $('#loginForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            setLoginStatus();
            setLoginBusy(true);
            try {
                const r = await api('/api/auth/login', {
                    method: 'POST',
                    body: { userName: $('#loginUser').val(), password: $('#loginPassword').val() },
                });
                state.token = r.token;
                state.user = r.user;
                sessionStore.setItem('cats_token', state.token);
                sessionStore.setItem('cats_user', JSON.stringify(state.user));
                $('#loginPassword').val('');
                setPasswordVisibility(false);
                showApp();
                await Promise.all([loadTemplates(true), loadRoles(true)]);
                await navigate('dashboard');
            } catch (x) {
                setLoginStatus(x.message);
                toast(x.message, 'danger');
            } finally {
                setLoginBusy(false);
            }
        }),
    );

    $('#logoutBtn').on(
        'click',
        guardEvent(() => signOut()),
    );

    $('#switchAccountBtn').on(
        'click',
        guardEvent(async () => {
            $('#loginUser, #loginPassword').val('');
            await signOut();
        }),
    );

    $('#sidebarToggle').on('click', guardEvent(toggleSidebar));

    $(document).on(
        'keydown',
        guardEvent((e) => {
            if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 's') {
                e.preventDefault();
                toggleSidebar();
            }
        }),
    );

    // Menu keys may carry an argument ("reports:ATM_ONUS"); entries that only group sub menus have no data-view.
    $('#topNavigation').on('click', '[data-view]', guardEvent(function () {
        observeTask(navigate(String($(this).attr('data-view'))));
    }));

    $('#sidebarNav').on(
        'click',
        '.nav-link[data-view]',
        guardEvent(function () {
            observeTask(navigate(String($(this).attr('data-view'))));
        }),
    );

    $(document).on('click', '.cats-flyout [data-view]', guardEvent(function () {
        observeTask(navigate(String($(this).attr('data-view'))));
    }));

    (async () => {
        if (state.token && state.user) {
            showApp();
            try {
                await Promise.all([loadTemplates(), loadRoles()]);
                await navigate('dashboard');
            } catch {
                logout(false);
            }
        } else showLogin();
    })();

    $(document).on(
        'click',
        '.pi-reveal',
        guardEvent(function (e) {
            e.preventDefault();
            e.stopPropagation();
            state.pendingPi = { alertId: String($(this).data('alert-id')), field: String($(this).data('field')) };
            $('#piPassword').val('');
            $('#piUnmaskError').addClass('d-none').text('');
            bootstrap.Modal.getOrCreateInstance('#piUnmaskModal').show();
            setTimeout(() => $('#piPassword').trigger('focus'), 200);
        }),
    );

    $(document).on(
        'click',
        '.pi-mask',
        guardEvent(function (e) {
            e.preventDefault();
            e.stopPropagation();
            const button = $(this),
                cell = button.closest('[data-pi-value]'),
                alertId = String(button.data('alert-id')),
                field = String(button.data('field'));
            button.remove();
            cell.contents()
                .filter((_, node) => node.nodeType === Node.TEXT_NODE)
                .remove();
            cell.prepend(document.createTextNode(cell.attr('data-masked-value') || ''));
            cell.append(piEye(alertId, field));
        }),
    );

    $('#piUnmaskForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            if (!state.pendingPi) return;
            const pending = state.pendingPi,
                button = $('#confirmPiUnmask');
            try {
                button.prop('disabled', true);
                const result = await api(`/api/alerts/${pending.alertId}/unmask-pi`, {
                    method: 'POST',
                    body: { field: pending.field, password: $('#piPassword').val() },
                });
                $('[data-pi-value]')
                    .filter(function () {
                        return (
                            String($(this).data('alert-id')) === pending.alertId &&
                            String($(this).data('pi-value')) === result.field
                        );
                    })
                    .each(function () {
                        const cell = $(this);
                        cell.find('.pi-edit-control').remove();
                        cell.contents()
                            .filter((_, node) => node.nodeType === Node.TEXT_NODE)
                            .remove();
                        cell.prepend(document.createTextNode(result.value));
                        cell.find('.pi-reveal,.pi-mask').remove();
                        cell.append(piMaskEye(pending.alertId, result.field));
                        const config = cell.attr('data-pi-edit');
                        if (config) {
                            const field = JSON.parse(decodeURIComponent(config));
                            cell.contents()
                                .filter((_, node) => node.nodeType === Node.TEXT_NODE)
                                .remove();
                            cell.prepend(
                                '<div class="pi-edit-control">' +
                                    templateFieldControlHtml(
                                        { ...field, sensitive: false },
                                        result.value,
                                        'detail-dynamic-field',
                                        true,
                                    ) +
                                    '</div>',
                            );
                            bindConfiguredFields(cell, 'detail-dynamic-field');
                        }
                    });
                state.pendingPi = null;
                $('#piPassword').val('');
                bootstrap.Modal.getOrCreateInstance('#piUnmaskModal').hide();
                toast('Sensitive value revealed.');
            } catch (x) {
                $('#piPassword').val('').trigger('focus');
                $('#piUnmaskError').removeClass('d-none').text(x.message);
            } finally {
                button.prop('disabled', false);
            }
        }),
    );

    $('#stageModal').on(
        'show.bs.modal',
        guardEvent(() => {
            const index = Number($('#stageEditIndex').val()),
                stage = index >= 0 ? state.workflowDraft.stages[index] : null;
            $('#stageAttachmentUploadRoles').val((stage?.attachmentUploadRoles || []).join(','));
            $('#stageAttachmentViewRoles').val((stage?.attachmentViewRoles || []).join(','));
        }),
    );

    $(document).on(
        'click',
        '#saveStageBtn',
        guardEvent(() =>
            setTimeout(() => {
                const id = $('#stageId').val().trim(),
                    stage = state.workflowDraft.stages.find((x) => x.id === id);
                if (!stage) return;
                /**
                 * Split a role input into trimmed uppercase role codes and discard empty entries.
                 * @param {*} selector - Selector identifying the target control or modal.
                 * @returns {Array} Computed value for the caller.
                 */
                const roles = (selector) =>
                    $(selector)
                        .val()
                        .split(',')
                        .map((x) => x.trim().toUpperCase())
                        .filter(Boolean);
                stage.attachmentUploadRoles = roles('#stageAttachmentUploadRoles');
                stage.attachmentViewRoles = roles('#stageAttachmentViewRoles');
            }, 0),
        ),
    );

    $('#catsAssistantLauncher').on(
        'click',
        guardEvent(() => {
            $('#catsAssistantPanel').toggleClass('d-none');
            if (!$('#catsAssistantPanel').hasClass('d-none'))
                setTimeout(() => $('#catsAssistantInput').trigger('focus'), 80);
        }),
    );

    $('#catsAssistantClose').on(
        'click',
        guardEvent(() => $('#catsAssistantPanel').addClass('d-none')),
    );

    $('#catsAssistantRecord').on(
        'click',
        guardEvent(async () => {
            const button = $('#catsAssistantRecord');
            const status = $('#catsAssistantSpeechStatus');
            let keepRecordingState = false;
            try {
                if (!button.hasClass('is-recording')) {
                    await startAssistantSpeechCapture();
                    button
                        .addClass('is-recording')
                        .removeClass('btn-outline-secondary')
                        .addClass('btn-danger')
                        .attr({ 'aria-pressed': 'true', 'aria-label': 'Stop recording', title: 'Stop recording' });
                    $('#catsAssistantRecordLabel').text('Stop');
                    status
                        .removeClass('d-none text-danger')
                        .text('Listening locally. Recognized speech will appear here as you speak.');
                    assistantSpeechTimer = window.setInterval(() => {
                        const audio = drainAssistantSpeechCapture();
                        if (audio) queueAssistantSpeechTranscription(audio, status);
                    }, 4000);
                    keepRecordingState = true;
                    return;
                }

                window.clearInterval(assistantSpeechTimer);
                assistantSpeechTimer = undefined;
                button
                    .prop('disabled', true)
                    .attr({ 'aria-label': 'Transcribing speech', title: 'Transcribing speech' });
                $('#catsAssistantRecordLabel').text('Transcribing');
                status.removeClass('d-none text-danger').text('Transcribing with the local Whisper model…');
                const audio = await stopAssistantSpeechCapture();
                if (audio) queueAssistantSpeechTranscription(audio, status);
                await assistantSpeechQueue;
                status.text('Speech transcribed. Review the text before sending.');
            } catch (x) {
                window.clearInterval(assistantSpeechTimer);
                assistantSpeechTimer = undefined;
                status.removeClass('d-none').addClass('text-danger').text(x.message || 'Speech transcription failed.');
            } finally {
                if (keepRecordingState) return;
                button
                    .removeClass('is-recording')
                    .removeClass('btn-danger')
                    .addClass('btn-outline-secondary')
                    .attr({ 'aria-pressed': 'false', 'aria-label': 'Record speech to text', title: 'Record speech to text' })
                    .prop('disabled', false);
                $('#catsAssistantRecordLabel').text('Record');
            }
        }),
    );

    $('#catsAssistantForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            const input = $('#catsAssistantInput');
            const message = String(input.val() || '').trim();
            if (!message) return;
            appendAssistantMessage(message, 'user');
            input.val('');
            const button = $('#catsAssistantSend').prop('disabled', true).text('Thinking…');
            try {
                const result = await api('/api/assistant/chat', { method: 'POST', body: { message } });
                appendAssistantMessage(result.answer || 'No answer was returned.', 'assistant');
                $('#catsAssistantModel').text(
                    `${result.provider || 'SLM/LLM'} · ${result.model || ''}${result.usedMcpTools ? ' · MCP' : ''}`,
                );
            } catch (x) {
                appendAssistantMessage(x.message || 'Assistant request failed.', 'error');
            } finally {
                button.prop('disabled', false).text('Send');
            }
        }),
    );

    enhanceCommandButtons(document);

    const piGridObserver = new MutationObserver((records) =>
        records.forEach((record) =>
            record.addedNodes.forEach((node) => {
                if (node.nodeType === Node.ELEMENT_NODE) {
                    enhancePiGrids(node);
                    removeWorkflowDefinitionJson(node);
                    hideAssignmentRulesJson(node);
                    enhanceDesignerActions(node);
                    enhanceGridActions(node);
                    enhanceGridToolbar(node);
                    enhanceCommandButtons(node);
                }
            }),
        ),
    );

    piGridObserver.observe(document.getElementById('viewHost'), { childList: true, subtree: true });
}

function queueAssistantSpeechTranscription(audio, status) {
    if (audio.size <= 44) return;
    assistantSpeechQueue = assistantSpeechQueue
        .then(async () => {
            const form = new FormData();
            form.append('audio', audio, 'speech.wav');
            const result = await api('/api/assistant/transcribe', { method: 'POST', body: form });
            const text = String(result.text || '').trim();
            if (text) {
                const input = $('#catsAssistantInput');
                input.val(`${String(input.val() || '').trim()} ${text}`.trim()).trigger('focus');
            }
        })
        .catch(async (error) => {
            window.clearInterval(assistantSpeechTimer);
            assistantSpeechTimer = undefined;
            let message = error.message || 'Speech transcription failed.';
            try {
                await stopAssistantSpeechCapture();
            } catch (cleanupError) {
                message = `${message} Microphone cleanup failed: ${cleanupError.message || 'unknown error'}.`;
            }
            $('#catsAssistantRecord')
                .removeClass('is-recording btn-danger')
                .addClass('btn-outline-secondary')
                .attr({ 'aria-pressed': 'false', 'aria-label': 'Record speech to text', title: 'Record speech to text' })
                .prop('disabled', false);
            $('#catsAssistantRecordLabel').text('Record');
            status.removeClass('d-none').addClass('text-danger').text(message);
        });
    return assistantSpeechQueue;
}

export { bindApplicationEvents };
