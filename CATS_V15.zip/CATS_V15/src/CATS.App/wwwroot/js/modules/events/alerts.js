import { observeTask } from './guard.js';
import { downloadFile } from '../ui/downloads.js';
import { guardEvent } from './guard.js';
import { state } from '../core/state.js';
import { toast } from '../ui/feedback.js';
import { navigate } from '../core/navigation.js';
import { renderAlerts, renderDetail } from '../features/alerts.js';
import { templateAllowsBaseDataMode, bulkFileAccept } from '../business/templates.js';
import { dynamicFormHtml } from '../ui/forms.js';
import { bindConfiguredFields } from './forms.js';
import { validateConfiguredFields } from '../validation/forms.js';
import { collectConfiguredData } from '../business/form-data.js';
import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { has } from '../core/permissions.js';
import { renderAtmApprovals, renderMyUploads } from '../features/atm-approvals.js';

// ATM penalty alert types are uploaded through the ATM maker-checker flow, which also needs the penalty month and year.
const ATM_UPLOAD_TYPES = { ATM_ONUS: 'OnUs', ATM_OFFUS: 'OffUs' };
const atmUploadType = (template) => ATM_UPLOAD_TYPES[String(template?.code || '').toUpperCase()] || '';

/**
 * Bind alerts actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: updateAlertsHeader, renderConfiguredFilters, load.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindAlertsEvents({ updateAlertsHeader, renderConfiguredFilters, load }) {
    // Dashboard links may carry a filter as a plain query field named like the catalog code (status, branchCode, alertNo); clear those with the filters.
    const plainName = (column) => column.code.charAt(0).toLowerCase() + column.code.slice(1);
    const clearPlainFilters = () => {
        state.alertFilter.branchCode = '';
        state.alertFilter.status = '';
        state.alertColumns.forEach((column) => (state.alertFilter[plainName(column)] = ''));
    };
    $('#afAlertType').on(
        'change',
        guardEvent(async function () {
            clearPlainFilters();
            state.alertFilter.dynamicFiltersJson = '{}';
            state.alertFilter.systemFilters = '{}';
            state.alertFilter.templateId = this.value;
            state.alertFilter.alertType = '';
            state.alertFilter.page = 1;
            updateAlertsHeader(this.value);
            renderConfiguredFilters();
            await load(1);
        }),
    );
    $('#alertFilterForm').on(
        'submit',
        guardEvent((e) => {
            e.preventDefault();
            const dynamicFilters = {};
            const systemFilters = {};
            const catalog = new Map(
                state.alertColumns.filter((column) => column.filterable).map((column) => [String(column.code).toLowerCase(), column]),
            );
            $('.alert-config-filter').each(function () {
                const field = String($(this).data('field') || ''),
                    value = String($(this).val() ?? '').trim();
                if (!value) return;
                const column = catalog.get(field.toLowerCase());
                if (column) systemFilters[column.code] = value;
                else dynamicFilters[field] = value;
            });
            clearPlainFilters();
            state.alertFilter = {
                ...state.alertFilter,
                page: 1,
                templateId: $('#afAlertType').val(),
                alertType: '',
                systemFilters: JSON.stringify(systemFilters),
                dynamicFiltersJson: JSON.stringify(dynamicFilters),
                search: $('#afSearch').val(),
            };
            updateAlertsHeader(state.alertFilter.templateId);
            load(1).catch((x) => toast(x.message, 'danger'));
        }),
    );
    $('#backToDashboard').on(
        'click',
        guardEvent(() => navigate('dashboard')),
    );
    $('#clearAging').on(
        'click',
        guardEvent(() => {
            delete state.alertFilter.agingFrom;
            delete state.alertFilter.agingTo;
            observeTask(renderAlerts(state.alertFilter));
        }),
    );
    await load();
}

/**
 * Bind new alert actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: published, available.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindNewAlertEvents({ published, available }) {
    $('#newAlertType').on(
        'change',
        guardEvent(function () {
            const t = available.find((x) => x.id === $(this).val());
            const manual = !!t && templateAllowsBaseDataMode(t, 'ManualSingle');
            const bulk = !!t && templateAllowsBaseDataMode(t, 'BulkFileUpload');
            $('#manualEntryColumn')
                .toggleClass('d-none', !manual)
                .toggleClass('col-xl-8', manual && bulk);
            $('#bulkEntryColumn')
                .toggleClass('d-none', !bulk)
                .toggleClass('col-xl-4', manual && bulk);
            $('#newAlertModeHint')
                .toggleClass('d-none', manual || bulk)
                .text(
                    t
                        ? 'This alert type has no enabled entry method.'
                        : 'Select an alert type to see its available entry methods.',
                );
            $('#newAlertForm :input').prop('disabled', !manual);
            $('#bulkUploadCard :input').prop('disabled', !bulk);
            $('#newDynamic').html(manual ? dynamicFormHtml(t) : '');
            $('#csvFile').val('').attr('accept', bulkFileAccept(t).accept);
            $('#atmPeriod').toggleClass('d-none', !(bulk && atmUploadType(t)));
            $('#csvResult').empty();
            if (manual) bindConfiguredFields('#newDynamic', 'dynamic-field');
        }),
    );
    $('#newAlertType').val(available[0].id).trigger('change');
    $('#newAlertForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            try {
                const t = published.find((x) => x.id === $('#newAlertType').val());
                if (!t) throw new Error('Select an alert type.');
                if (!templateAllowsBaseDataMode(t, 'ManualSingle'))
                    throw new Error('Manual entry is disabled for this alert type.');
                if (!validateConfiguredFields('#newDynamic', 'dynamic-field'))
                    throw new Error('Please correct the highlighted fields.');
                const data = collectConfiguredData('#newDynamic', 'dynamic-field'); /**
                 * Resolve the configured alert field value before constructing the submission payload.
                 * @param {*} name - Field or configuration name.
                 * @returns {*} Computed value for the caller.
                 */
                const configuredValue = (name) => {
                    const key = Object.keys(data).find((x) => x.toLowerCase() === name.toLowerCase());
                    return key ? data[key] : '';
                };
                const r = await api('/api/alerts', {
                    method: 'POST',
                    body: {
                        templateId: t.id,
                        alertType: t.code,
                        branchCode: configuredValue('BranchCode'),
                        customerId: configuredValue('CustomerId'),
                        accountId: configuredValue('AccountId'),
                        priority: 'Normal',
                        data,
                    },
                });
                toast(`Alert ${r.alertNo} created`);
                observeTask(navigate('detail', r.id));
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );
    $('#downloadSampleCsv').on(
        'click',
        guardEvent(async () => {
            try {
                const templateId = $('#newAlertType').val();
                if (!templateId) throw new Error('Select an Alert Type first.');
                if (
                    !templateAllowsBaseDataMode(
                        published.find((t) => t.id === templateId),
                        'BulkFileUpload',
                    )
                )
                    throw new Error('Bulk upload is disabled for this alert type.');
                const atmType = atmUploadType(published.find((t) => t.id === templateId));
                await downloadFile(atmType ? `/api/atm/samples/${atmType}` : `/api/alerts/sample-csv/${encodeURIComponent(templateId)}`);
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );
    $('#uploadCsvBtn').on(
        'click',
        guardEvent(async () => {
            try {
                const templateId = $('#newAlertType').val();
                if (!templateId) throw new Error('Select an Alert Type first.');
                const f = $('#csvFile')[0].files[0];
                if (!f) throw new Error('Select a file to upload.');
                const fd = new FormData();
                fd.append('file', f);
                const atmType = atmUploadType(published.find((t) => t.id === templateId));
                if (atmType) {
                    fd.append('fileType', atmType);
                    fd.append('penaltyMonth', String($('#atmPenaltyMonth').val() || ''));
                    fd.append('penaltyYear', String($('#atmPenaltyYear').val() || ''));
                    $('#csvResult').html('Uploading...');
                    const sent = await api('/api/atm/uploads', { method: 'POST', body: fd });
                    $('#csvResult').html(
                        `<div class="alert alert-success py-2">${sent.rowCount} row(s) from ${esc(sent.fileName)} were sent to a DBOPS Checker for approval. The cases are created once it is approved.</div>`,
                    );
                    $('#csvFile').val('');
                    if (has('ATM.UPLOAD')) await renderMyUploads('#atmMyUploads', { types: ['OnUs', 'OffUs'] });
                    if (has('ATM.CHECK')) await renderAtmApprovals('#atmApprovals', { types: ['OnUs', 'OffUs'], reopen: true });
                    return;
                }
                fd.append('templateId', templateId);
                $('#csvResult').html('Uploading...');
                const r = await api('/api/alerts/upload-csv', { method: 'POST', body: fd });
                $('#csvResult').html(
                    `<div class="alert ${r.failed ? 'alert-warning' : 'alert-success'} py-2">Success: ${r.success}, Failed: ${r.failed}</div>${r.results
                        .slice(0, 10)
                        .map(
                            (x) =>
                                `<div>Line ${x.line}: ${esc(x.status)} ${x.alertNo ? esc(x.alertNo) : esc(x.error || '')}</div>`,
                        )
                        .join('')}`,
                );
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );
}

/**
 * Bind detail actions using the rendered screen context, preserving filters and initial loading.
 * @param {object} context - Screen-local data and callbacks captured during rendering: id, d, data, split, setDetailPanelCollapsed.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function bindDetailEvents({ id, d, data, split, setDetailPanelCollapsed, detailFields }) {
    $('#detailPanelToggle').on(
        'click',
        guardEvent(() => setDetailPanelCollapsed(!split.hasClass('is-collapsed'))),
    );
    $('#backAlerts')
        .off('click')
        .on(
            'click',
            guardEvent(() => navigate('alerts', state.alertFilter)),
        );
    /**
     * Validate editable alert fields before collecting the workflow response data.
     * @returns {object} Computed value for the caller.
     */
    const collectResponse = () => {
        if (!validateConfiguredFields(detailFields, 'detail-dynamic-field'))
            throw new Error('Please correct the highlighted fields.');
        return collectConfiguredData(detailFields, 'detail-dynamic-field');
    };
    $('.workflow-action').on(
        'click',
        guardEvent(async function () {
            const action = String($(this).data('action') || '');
            const isQuery = /^(RaiseQuery|Query)$/i.test(action);
            const requiresRemarks = /^(RaiseQuery|Query|RespondQuery|Respond|Reject|Send Back)$/i.test(action);
            if (!requiresRemarks) {
                try {
                    await api(`/api/alerts/${id}/action`, {
                        method: 'POST',
                        body: { action, remarks: '', data: collectResponse() },
                    });
                    toast(`${action} completed`);
                    await renderDetail(id);
                } catch (x) {
                    toast(x.message, 'danger');
                }
                return;
            }
            state.pendingAction = {
                id,
                action,
                collect: collectResponse,
                aiQueryEnabled: isQuery && !!d.aiQueryEnabled,
            };
            $('#actionModalTitle').text(action);
            $('#actionRemarks').val('');
            $('#aiQueryInstruction').val('');
            $('#aiQueryStatus').text('');
            $('#actionRemarksLabel').text(isQuery ? 'Query text / remarks' : 'Remarks / reason');
            $('#aiQueryAssistPanel').toggleClass('d-none', !(isQuery && d.aiQueryEnabled));
            $('#aiQueryHumanNotice').toggleClass('d-none', !(isQuery && d.aiQueryEnabled));
            if (isQuery && d.aiQueryEnabled)
                $('#aiQueryModelInfo').text(
                    `Draft only · ${d.aiQueryProvider || 'Configured provider'} / ${d.aiQueryModel || 'Configured model'}`,
                );
            bootstrap.Modal.getOrCreateInstance('#actionModal').show();
        }),
    );
    $('#reassignBtn').on(
        'click',
        guardEvent(async () => {
            try {
                if (String(d.alert.alertType || '').toUpperCase().startsWith('ATM_')) {
                    const employeeId = $('#reassignUser').val().trim();
                    if (!employeeId) throw new Error('Enter an employee ID or CATS username.');
                    await api(`/api/atm/cases/${id}/reassign`, {
                        method: 'POST',
                        body: { employeeId, remarks: $('#reassignRemarks').val() },
                    });
                    toast('ATM case reassigned');
                    observeTask(renderDetail(id));
                    return;
                }
                const role = $('#reassignRole').val().trim(),
                    branch = $('#reassignBranch').val().trim(),
                    userId = $('#reassignUser').val().trim();
                if (!role && !userId) throw new Error('Enter a role code or user ID.');
                await api(`/api/alerts/${id}/reassign`, {
                    method: 'POST',
                    body: {
                        stageId: d.alert.currentStageId,
                        roleCode: role || null,
                        branchCode: branch || null,
                        userId: userId || null,
                        remarks: $('#reassignRemarks').val(),
                    },
                });
                toast('Work item reassigned');
                observeTask(renderDetail(id));
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );
    $('#atmReopenBtn').on(
        'click',
        guardEvent(async () => {
            try {
                await api(`/api/atm/cases/${id}/reopen`, {
                    method: 'POST',
                    body: { remarks: $('#atmReopenRemarks').val() || null },
                });
                toast('ATM reopen request sent to DBOPS Checker');
                observeTask(renderDetail(id));
            } catch (error) {
                toast(error.message, 'danger');
            }
        }),
    );
    $('[data-attachment]').on(
        'click',
        guardEvent(async function (e) {
            e.preventDefault();
            try {
                const aid = $(this).data('attachment');
                await downloadFile('/api/alerts/attachments/' + aid);
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );
    $('#attachmentForm').on(
        'submit',
        guardEvent(async (e) => {
            e.preventDefault();
            try {
                const f = $('#attachmentFile')[0].files[0];
                if (!f) throw new Error('Select a file.');
                const fd = new FormData();
                fd.append('stageId', d.alert.currentStageId);
                fd.append('file', f);
                await api(`/api/alerts/${id}/attachments`, { method: 'POST', body: fd });
                toast('Attachment uploaded');
                observeTask(renderDetail(id));
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );
}

export { bindAlertsEvents, bindNewAlertEvents, bindDetailEvents };
