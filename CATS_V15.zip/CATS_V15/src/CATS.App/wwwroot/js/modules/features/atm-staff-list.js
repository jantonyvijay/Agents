import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';
import { header, toast } from '../ui/feedback.js';
import { has } from '../core/permissions.js';
import { state } from '../core/state.js';

const BASE = '/api/atm/staff-mapping';

const statusBadge = (status) =>
    `<span class="badge ${{ Pending: 'text-bg-warning', Approved: 'text-bg-success', Rejected: 'text-bg-danger' }[status] || 'text-bg-secondary'}">${esc(status)}</span>`;

const when = (value) => (value ? esc(new Date(value).toLocaleString()) : '');

/**
 * Open another Staff Mapping page. Loaded lazily because the navigation module imports this one.
 * @param {string} view - Target view name.
 * @param {string} [arg] - Optional view argument.
 * @returns {Promise<void>} Resolves after navigation.
 */
async function openView(view, arg) {
    const { navigate } = await import('../core/navigation.js');
    await navigate(view, arg);
}

/**
 * Create the popup used to review the rows of an upload once; later calls reuse it.
 * @returns {object} The jQuery element and its Bootstrap modal instance.
 */
function rowsModal() {
    if (!$('#staffRowsModal').length) {
        $('body').append(`<div class="modal fade" id="staffRowsModal" tabindex="-1" aria-labelledby="staffRowsTitle" aria-hidden="true">
          <div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
            <div class="modal-header"><h2 class="modal-title h5" id="staffRowsTitle">Staff Mapping rows</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body"></div><div class="modal-footer"></div>
          </div></div></div>`);
    }
    const element = $('#staffRowsModal');
    return { element, modal: bootstrap.Modal.getOrCreateInstance(element[0]) };
}

/**
 * Masters › ATM › Staff Mapping: the landing page. Approved ATMs, uploads waiting for a DBOPS Checker (who approves or rejects here),
 * and the decision history, each as a grid; the rows of any upload open in a popup.
 * @returns {Promise<void>} Resolves after the first page is rendered.
 */
async function renderAtmStaffList() {
    header('Staff Mapping', 'Masters › ATM › Staff Mapping · approved ATM to staff mapping, pending approvals and history');
    const canAdd = has('ATM.UPLOAD');
    const canReview = has('ATM.CHECK');
    const me = String(state.user?.userName || '').toLowerCase();
    const config = await api(`${BASE}/config`);
    const columns = config.columns.map((c) => c.name);
    let batches = [];
    let checkers = [];
    let tab = 'approved';
    let page = 1;
    const pageSize = 50;

    $('#viewHost').html(`<div class="card"><div class="card-body">
      <div class="d-flex flex-wrap gap-2 justify-content-end mb-3">
        ${canAdd ? '<button id="staffAdd" class="btn btn-sm btn-primary" type="button">＋ Add / Upload</button>' : ''}
        ${config.canConfigure ? '<button id="staffConfigure" class="btn btn-sm btn-outline-secondary" type="button">⚙ Column mapping</button>' : ''}
      </div>
      <ul class="nav nav-tabs mb-3" id="staffTabs" role="tablist">
        <li class="nav-item"><button type="button" class="nav-link active" data-tab="approved">Approved ATMs</button></li>
        <li class="nav-item"><button type="button" class="nav-link" data-tab="pending">Pending approval <span id="staffPendingCount" class="badge text-bg-warning ms-1">0</span></button></li>
        <li class="nav-item"><button type="button" class="nav-link" data-tab="history">History</button></li>
      </ul>
      <div id="staffPane"></div>
    </div></div>`);

    const canDecide = (item) => item.status === 'Pending' && canReview && String(item.uploadedBy).toLowerCase() !== me;

    const loadBatches = async () => {
        batches = await api(`${BASE}/batches?page=1&pageSize=200`);
        $('#staffPendingCount').text(batches.filter((x) => x.status === 'Pending').length);
    };

    const showApproved = async () => {
        $('#staffPane').html(`<div class="row g-2 mb-3 align-items-end"><div class="col-md-5"><label class="form-label small mb-1" for="staffSearch">Search ATM ID, state or employee code</label>
          <input id="staffSearch" class="form-control form-control-sm" maxlength="100"></div>
          <div class="col-auto"><button id="staffSearchBtn" class="btn btn-sm btn-primary" type="button">Search</button></div>
          <div class="col text-end small text-secondary" id="staffTotal"></div></div>
          <div id="staffList"></div>
          <div class="d-flex justify-content-between align-items-center mt-2"><button id="staffPrev" class="btn btn-sm btn-outline-secondary" type="button">Previous</button><span id="staffPage" class="small text-secondary"></span><button id="staffNext" class="btn btn-sm btn-outline-secondary" type="button">Next</button></div>`);
        const load = async () => {
            const search = String($('#staffSearch').val() || '').trim();
            const data = await api(`${BASE}/records?page=${page}&pageSize=${pageSize}${search ? `&search=${encodeURIComponent(search)}` : ''}`);
            $('#staffTotal').text(`${data.total.toLocaleString()} ATM(s)`);
            $('#staffPage').text(`Page ${page} of ${Math.max(1, Math.ceil(data.total / pageSize))}`);
            $('#staffPrev').prop('disabled', page <= 1);
            $('#staffNext').prop('disabled', page * pageSize >= data.total);
            $('#staffList').html(data.rows.length
                ? `<div class="table-responsive" style="max-height:62vh"><table class="table table-sm table-hover align-middle small text-nowrap">
                    <thead><tr>${canAdd ? '<th></th>' : ''}${columns.map((name) => `<th>${esc(name)}</th>`).join('')}</tr></thead>
                    <tbody>${data.rows.map((row) => `<tr>${canAdd ? `<td><button class="btn btn-sm btn-outline-primary staff-edit" data-id="${esc(row.ATM_ID)}">Edit</button></td>` : ''}${columns.map((name) => `<td>${esc(row[name] || '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`
                : '<p class="text-secondary mb-0">No approved Staff Mapping entries yet. Entries appear here once a DBOPS Checker approves an upload.</p>');
        };
        $('#staffSearchBtn').on('click', guardEvent(async () => { page = 1; await load(); }));
        $('#staffSearch').on('keydown', guardEvent(async (event) => { if (event.key === 'Enter') { page = 1; await load(); } }));
        $('#staffPrev').on('click', guardEvent(async () => { page = Math.max(1, page - 1); await load(); }));
        $('#staffNext').on('click', guardEvent(async () => { page += 1; await load(); }));
        await load();
    };

    const batchTable = (items, withDecision) => (items.length
        ? `<div class="table-responsive"><table class="table table-sm align-middle">
            <thead><tr><th>Uploaded</th><th>File / entry</th><th>Maker</th>${withDecision ? '<th>Status</th><th>Checker</th><th>Decided</th><th>Remarks</th>' : ''}<th></th></tr></thead>
            <tbody>${items.map((item) => `<tr><td>${when(item.uploadedAtUtc)}</td><td>${esc(item.fileName)}</td><td>${esc(item.uploadedBy)}</td>
              ${withDecision ? `<td>${statusBadge(item.status)}</td><td>${esc(item.decidedBy || '')}</td><td>${when(item.decidedAtUtc)}</td><td>${esc(item.decisionRemarks || '')}</td>` : ''}
              <td class="text-nowrap"><button class="btn btn-sm btn-outline-secondary staff-view" data-id="${esc(item.id)}">View</button>
              ${canDecide(item) ? `<button class="btn btn-sm btn-success ms-1 staff-decision" data-id="${esc(item.id)}" data-decision="Approve">Approve</button><button class="btn btn-sm btn-outline-danger ms-1 staff-decision" data-id="${esc(item.id)}" data-decision="Reject">Reject</button>`
                : item.status === 'Pending' ? '<span class="small text-secondary ms-2">Awaiting a checker</span>' : ''}</td></tr>`).join('')}</tbody></table></div>`
        : `<p class="text-secondary mb-0">${withDecision ? 'No decided uploads yet.' : 'Nothing is waiting for approval.'}</p>`);

    const showPending = () => {
        const names = checkers.map((x) => `${esc(x.displayName || x.userName)} (${esc(x.userName)})`).join(', ');
        $('#staffPane').html(`<p class="small text-secondary">Uploads and single entries wait here for a DBOPS Checker (permission <code>ATM.CHECK</code>); the person who uploaded cannot approve their own batch.
          <br>Checkers who can approve: ${names || '<span class="text-danger">none configured - assign ATM.CHECK to a role or user in Administration</span>'}.</p>${batchTable(batches.filter((x) => x.status === 'Pending'), false)}`);
    };
    const showHistory = () => $('#staffPane').html(batchTable(batches.filter((x) => x.status !== 'Pending'), true));

    const show = async () => {
        $('#staffTabs .nav-link').removeClass('active').filter(function () { return this.dataset.tab === tab; }).addClass('active');
        if (tab === 'approved') await showApproved();
        else if (tab === 'pending') showPending();
        else showHistory();
    };

    const decide = async (id, decision) => {
        const remarks = decision === 'Reject' ? window.prompt('Rejection reason (required):') : '';
        if (decision === 'Reject' && !remarks?.trim()) return false;
        await api(`/api/atm/uploads/${encodeURIComponent(id)}/decision`, { method: 'POST', body: { decision, remarks: remarks || null } });
        toast(`Staff Mapping ${decision === 'Approve' ? 'approved' : 'rejected'}.`);
        await loadBatches();
        await show();
        return true;
    };

    const viewRows = async (id) => {
        const item = batches.find((x) => x.id === id);
        const data = await api(`${BASE}/batches/${encodeURIComponent(id)}/rows`);
        const { element, modal } = rowsModal();
        element.find('.modal-title').text(data.fileName);
        element.find('.modal-body').html(`<p class="small text-secondary mb-2">${statusBadge(data.status)} · ${data.total.toLocaleString()} row(s)${data.total > data.rows.length ? ` · first ${data.rows.length} shown` : ''}${item ? ` · uploaded by ${esc(item.uploadedBy)} on ${when(item.uploadedAtUtc)}` : ''}</p>
          <div class="table-responsive"><table class="table table-sm table-hover small text-nowrap"><thead><tr>${data.columns.map((name) => `<th>${esc(name)}</th>`).join('')}</tr></thead>
          <tbody>${data.rows.map((row) => `<tr>${data.columns.map((name) => `<td>${esc(row[name] ?? '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);
        element.find('.modal-footer').html(`${item && canDecide(item) ? '<button type="button" class="btn btn-outline-danger staff-modal-decision" data-decision="Reject">Reject</button><button type="button" class="btn btn-success staff-modal-decision" data-decision="Approve">Approve</button>' : ''}<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>`);
        element.off('click.staffModal').on('click.staffModal', '.staff-modal-decision', guardEvent(async function () {
            if (await decide(id, String($(this).data('decision')))) modal.hide();
        }));
        modal.show();
    };

    // #viewHost is reused by every page, so these delegated handlers are namespaced and cleared on each visit.
    const card = $('#viewHost').off('.staffUpload .staffConfig .staffList');
    card.on('click.staffList', '#staffTabs [data-tab]', guardEvent(async function () {
        tab = String($(this).data('tab'));
        await show();
    }));
    card.on('click.staffList', '.staff-view', guardEvent(async function () { await viewRows(String($(this).data('id'))); }));
    card.on('click.staffList', '.staff-decision', guardEvent(async function () { await decide(String($(this).data('id')), String($(this).data('decision'))); }));
    card.on('click.staffList', '.staff-edit', guardEvent(async function () { await openView('atmStaffUpload', String($(this).data('id'))); }));
    card.on('click.staffList', '#staffAdd', guardEvent(() => openView('atmStaffUpload')));
    card.on('click.staffList', '#staffConfigure', guardEvent(() => openView('atmStaffConfig')));

    [batches, checkers] = await Promise.all([api(`${BASE}/batches?page=1&pageSize=200`), api(`${BASE}/checkers`)]);
    $('#staffPendingCount').text(batches.filter((x) => x.status === 'Pending').length);
    await show();
}

export { renderAtmStaffList };
