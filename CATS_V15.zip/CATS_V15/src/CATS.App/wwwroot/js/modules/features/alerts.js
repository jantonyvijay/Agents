import { observeTask } from '../events/guard.js';
import { sessionStore } from '../core/storage.js';
import { loadTemplates, loadAlertColumns } from '../api/catalogs.js';
import { state } from '../core/state.js';
import { templateViewConfig, templateAllowsBaseDataMode } from '../business/templates.js';
import { json, esc } from '../core/utils.js';
import { dashboardFieldLabel } from '../business/dashboard.js';
import { header, loading, statusBadge } from '../ui/feedback.js';
import { alertTypeOptions } from '../ui/options.js';
import { loadApiSelect } from '../api/select-options.js';
import { api } from '../api/client.js';
import { guardEvent } from '../events/guard.js';
import { navigate } from '../core/navigation.js';
import { bindAlertsEvents, bindNewAlertEvents, bindDetailEvents } from '../events/alerts.js';
import { has } from '../core/permissions.js';
import { renderAtmApprovals, renderMyUploads } from './atm-approvals.js';
import { configuredSectionsHtml } from '../ui/forms.js';
import { bindConfiguredFields } from '../events/forms.js';
import { renderPagerHtml, wirePager } from '../ui/grid.js';

function disposeAlertDetailPopups() {
    $('.cats-template-popup[data-alert-detail-popup="true"]').each(function () {
        bootstrap.Modal.getInstance(this)?.dispose();
        $(this).remove();
    });
}

/**
 * Load and render the alerts screen, then initialize its controls and event handlers.
 * @param {*} [filter] - Alert filter values overriding the default pagination.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderAlerts(filter = {}) {
    disposeAlertDetailPopups();
    // Column names, filters and file settings are edited by other users at any time, so never rely on the login-time cache.
    await Promise.all([loadTemplates(true), loadAlertColumns()]);
    state.alertFilter = { page: 1, pageSize: 20, recordView: 'All', ...filter };
    const recordTabs = [
        ['MyActionable', 'My Actionable', 'Records currently awaiting an action from your user or role.', '<path d="M12 3v9l6 3"/><circle cx="12" cy="12" r="9"/>'],
        ['ActionedByMe', 'Actioned By Me', 'Records you have actioned. Further editing depends on the current assignment.', '<path d="m5 12 4 4L19 6"/>'],
        ['Closed', 'Closed', 'Closed records within your viewing permissions.', '<path d="M5 12.5 9.5 17 19 7"/><circle cx="12" cy="12" r="9"/>'],
        ['All', 'All', 'All records within your viewing permissions.', '<circle cx="7" cy="7" r="2.5"/><circle cx="17" cy="7" r="2.5"/><circle cx="7" cy="17" r="2.5"/><circle cx="17" cy="17" r="2.5"/>'],
    ];
    if (!recordTabs.some(([key]) => key === state.alertFilter.recordView)) state.alertFilter.recordView = 'All';
    const accessibleAlertTypes = state.templates.filter((template) => template.status === 'Published');
    // Callers (dashboard buttons via jQuery .data(), search, summary cards) may pass the id as a number or only the Alert Type code.
    if (state.alertFilter.templateId !== undefined && state.alertFilter.templateId !== null)
        state.alertFilter.templateId = String(state.alertFilter.templateId);
    if (!state.alertFilter.templateId && state.alertFilter.alertType) {
        const byCode = accessibleAlertTypes.find(
            (template) => String(template.code).toLowerCase() === String(state.alertFilter.alertType).toLowerCase(),
        );
        if (byCode) state.alertFilter.templateId = byCode.id;
    }
    if (!accessibleAlertTypes.some((template) => template.id === state.alertFilter.templateId))
        state.alertFilter.templateId = accessibleAlertTypes[0]?.id || '';
    /**
     * Resolve the selected template list-column configuration and apply existing fallbacks.
     * @param {*} templateId - Selected alert template identifier.
     * @returns {Array} Computed value for the caller.
     */
    const listConfiguration = (templateId) => {
        const template = state.templates.find((item) => item.id === templateId);
        const configuration = template ? templateViewConfig(template) : {};
        return (configuration.alertListFields || []).filter((field) => field && field.field);
    };
    /**
     * Convert nulls to empty text and objects to JSON for display.
     * @param {*} row - Source data record.
     * @param {*} field - Field name or definition.
     * @returns {string} Computed value for the caller.
     */
    const fieldValue = (row, field) => {
        const key = String(field || '').toLowerCase();
        // Alerts-table columns come from the catalog: the code is the property name of the row and the format is configurable.
        const system = state.alertColumns.find((column) => String(column.code).toLowerCase() === key);
        if (system) {
            const property = Object.keys(row).find((name) => name.toLowerCase() === key);
            const value = property === undefined ? '' : (row[property] ?? '');
            return system.valueFormat && value !== '' ? String(system.valueFormat).replace('{0}', value) : value;
        }
        const dynamicKey = Object.keys(row.dynamicFields || {}).find((name) => name.toLowerCase() === key);
        return row.dynamicFields?.[dynamicKey] ?? '';
    };
    /**
     * Resolve a configured alert list column label for the selected alert type.
     * @param {*} field - Field name or definition.
     * @returns {string} Computed value for the caller.
     */
    const fieldLabel = (field) =>
        listConfiguration($('#afAlertType').val()).find(
            (item) => String(item.field).toLowerCase() === String(field).toLowerCase(),
        )?.label || dashboardFieldLabel(field);
    /**
     * Update the alert screen heading to match the selected alert template.
     * @param {*} templateId - Selected alert template identifier.
     * @returns {void} Updates the relevant UI or state.
     */
    const updateAlertsHeader = (templateId) => {
        const template = state.templates.find((item) => item.id === templateId);
        header('Alerts', template ? `Alert Type: ${template.name || template.code}` : 'All alert types');
    };
    updateAlertsHeader(state.alertFilter.templateId);
    const dashboardGroups = state.alertFilter.dashboardId
        ? json(state.alertFilter.dashboardGroupFiltersJson || '{}', {})
        : {};
    const dashboardCriteria = Object.entries(dashboardGroups)
        .map(([key, value]) => `${dashboardFieldLabel(key)}: ${value}`)
        .concat(state.alertFilter.dashboardMetricTitle ? [`Metric: ${state.alertFilter.dashboardMetricTitle}`] : []);
    const drillDownBanner = state.alertFilter.dashboardId
        ? `<div class="alert alert-info d-flex flex-wrap justify-content-between align-items-center gap-2"><span><strong>Dashboard drill-down</strong>${dashboardCriteria.length ? ' · ' + esc(dashboardCriteria.join(' · ')) : ''}</span><button id="backToDashboard" type="button" class="btn btn-sm btn-outline-primary">Back to Dashboard</button></div>`
        : '';
    $('#viewHost')
        .html(`${drillDownBanner}<div class="card mb-3"><div class="card-body"><form id="alertFilterForm" class="row g-2 align-items-end">
  <div class="col-lg-3"><label class="form-label">Alert Type</label><select id="afAlertType" class="form-select">${alertTypeOptions(state.alertFilter.templateId || '', false, false)}</select></div>
        <div id="alertConfiguredFilters" class="col-lg-7"></div>
        <div class="col-lg-2"><label class="form-label">Search</label><div class="input-group"><input id="afSearch" value="${esc(state.alertFilter.search || '')}" class="form-control" placeholder="Search alerts" /><button class="btn btn-primary">Search</button></div></div>
  <div class="col-12 small text-secondary">Aging filter: ${state.alertFilter.agingFrom ?? 'Any'} to ${state.alertFilter.agingTo ?? 'Any'} days <button id="clearAging" type="button" class="btn btn-link btn-sm">clear</button></div>
</form></div></div><div class="card mb-3 alert-record-views"><div class="card-body"><nav class="alert-record-tabs" aria-label="Alert record views">${recordTabs.map(([key, label, , icon]) => `<button type="button" class="alert-record-tab ${state.alertFilter.recordView === key ? 'active' : ''}" data-record-view="${key}" aria-pressed="${state.alertFilter.recordView === key}" aria-controls="alertGrid"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icon}</svg><span>${label}</span></button>`).join('')}</nav><div id="alertRecordViewHint" class="alert-record-view-hint">${recordTabs.find(([key]) => key === state.alertFilter.recordView)[2]}</div></div></div><div id="alertGrid" aria-live="polite"></div>`);
    $('.alert-record-tab').on('click', guardEvent(async function () {
        state.alertFilter.recordView = String($(this).data('record-view'));
        $('.alert-record-tab').removeClass('active').attr('aria-pressed', 'false');
        $(this).addClass('active').attr('aria-pressed', 'true');
        $('#alertRecordViewHint').text(recordTabs.find(([key]) => key === state.alertFilter.recordView)[2]);
        await load(1);
    }));
    /**
     * Render the selected template search controls and initialize API-backed filter options.
     * @returns {void} Updates the relevant UI or state.
     */
    const renderConfiguredFilters = () => {
        const templateId = $('#afAlertType').val(),
            template = state.templates.find((item) => item.id === templateId),
            templateFields = template ? json(template.fieldsJson, []) : [];
        const dynamicValues = json(state.alertFilter.dynamicFiltersJson || '{}', {});
        const filters = listConfiguration(templateId)
            .filter((field) => field.showAsFilter)
            .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
        const html = filters
            .map((field) => {
                const definition =
                    templateFields.find(
                        (item) => String(item.name ?? item.Name).toLowerCase() === String(field.field).toLowerCase(),
                    ) || {};
                const system = state.alertColumns.find(
                    (column) => column.filterable && String(column.code).toLowerCase() === String(field.field).toLowerCase(),
                );
                const control = String(
                    (system && system.controlType) || field.controlType || definition.type || definition.Type || 'text',
                ).toLowerCase();
                // The catalog owns the options of an Alerts-table column, so a stale option list saved in a template cannot hide real values.
                const opts = system
                    ? json(system.optionsJson || '[]', [])
                    : json(field.optionsJson || definition.optionsJson || definition.OptionsJson || '[]', []);
                const key = String(field.field).toLowerCase(),
                    systemValues = json(state.alertFilter.systemFilters || '{}', {}),
                    // Dashboard drill-downs pass the same filter as a plain query field named like the code (status, branchCode, alertNo).
                    plainName = system ? system.code.charAt(0).toLowerCase() + system.code.slice(1) : '',
                    current = system
                        ? (systemValues[system.code] ?? state.alertFilter[plainName] ?? '')
                        : (dynamicValues[field.field] ??
                          dynamicValues[Object.keys(dynamicValues).find((x) => x.toLowerCase() === key)] ??
                          '');
                const isChoice = ['select', 'dropdownlist', 'radio', 'checkboxlist', 'multiselect'].includes(control),
                    apiChoice =
                        isChoice &&
                        String(definition.dataSourceMode || definition.DataSourceMode || 'Static').toLowerCase() ===
                            'api';
                const apiConfig = encodeURIComponent(JSON.stringify(definition));
                const editor = apiChoice
                    ? `<select class="form-select alert-config-filter alert-filter-api-select cats-api-select" data-field="${esc(field.field)}" data-name="${esc(field.field)}" data-field-config="${apiConfig}" data-current-value="${esc(current)}"><option value="">Loading…</option></select>`
                    : isChoice
                      ? `<select class="form-select alert-config-filter" data-field="${esc(field.field)}"><option value="">All</option>${opts.map((o) => `<option value="${esc(o)}" ${String(current) === String(o) ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`
                      : `<input class="form-control alert-config-filter" data-field="${esc(field.field)}" value="${esc(current)}" />`;
                return `<div class="col-md-4 col-xl-3"><label class="form-label">${esc(field.label || dashboardFieldLabel(field.field))}</label>${editor}</div>`;
            })
            .join('');
        $('#alertConfiguredFilters').html(`<div class="row g-2">${html}</div>`);
        $('#alertConfiguredFilters .alert-filter-api-select').each(function () {
            observeTask(loadApiSelect($(this), '#alertConfiguredFilters', 'alert-config-filter'));
        });
    };
    renderConfiguredFilters();
    /**
     * Fetch the current screen data using its filters and pagination, then render the results and their actions.
     * @param {*} [page] - One-based result page.
     * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
     */
    let loadSequence = 0;
    async function load(page = state.alertFilter.page || 1) {
        const sequence = ++loadSequence;
        state.alertFilter.page = page;
        const q = new URLSearchParams();
        Object.entries(state.alertFilter).forEach(([k, v]) => {
            if (v !== null && v !== undefined && v !== '') q.set(k, v);
        });
        $('#alertGrid').html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>');
        const d = await api('/api/alerts?' + q.toString());
        if (sequence !== loadSequence) return;
        const columns = listConfiguration($('#afAlertType').val())
            .filter((field) => field.showInGrid)
            .sort((a, b) => a.order - b.order);
        let h = `<div class="card"><div class="card-header bg-white d-flex justify-content-between"><span class="fw-semibold">Records</span><span class="text-secondary small">${d.totalRecords.toLocaleString()} record(s)</span></div><div class="table-responsive"><table class="table table-hover align-middle mb-0" data-grid-select="multiple" data-grid-export="true"><thead><tr><th>View</th>${columns.map((column) => `<th>${esc(fieldLabel(column.field))}</th>`).join('')}</tr></thead><tbody>`;
        for (const r of d.data)
            h += `<tr class="pointer alert-row" data-id="${r.id}"><td><button class="btn btn-sm btn-outline-primary">View</button></td>${columns.map((column) => `<td>${esc(fieldValue(r, column.field))}</td>`).join('')}</tr>`;
        if (!d.data.length)
            h += `<tr><td colspan="${columns.length + 1}" class="text-center text-secondary py-5">No records found.</td></tr>`;
        h +=
            '</tbody></table></div><div class="card-footer bg-white">' +
            renderPagerHtml({
                page: d.page,
                pageSize: state.alertFilter.pageSize,
                totalRecords: d.totalRecords,
                totalPages: d.totalPages,
            }) +
            '</div></div>';
        $('#alertGrid').html(h);
        $('.alert-row').on(
            'click',
            guardEvent(function (event) {
                if ($(event.target).is('.cats-select-row, .cats-select-all')) return;
                observeTask(navigate('detail', $(this).data('id')));
            }),
        );
        wirePager(
            $('#alertGrid'),
            { page: d.page, pageSize: state.alertFilter.pageSize, totalRecords: d.totalRecords, totalPages: d.totalPages },
            {
                onPageChange: (page) => observeTask(load(page)),
                onPageSizeChange: (pageSize) => {
                    state.alertFilter.pageSize = pageSize;
                    observeTask(load(1));
                },
            },
        );
    }
    return bindAlertsEvents({ updateAlertsHeader, renderConfiguredFilters, load });
}

/**
 * Load and render the new alert screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderNewAlert() {
    disposeAlertDetailPopups();
    const canEnter = has('ALERT.UPLOAD');
    const canApprove = has('ATM.CHECK');
    if (!canEnter && !canApprove) throw new Error('Alert upload permission is required.');
    if (!canEnter) {
        // Approvers review other people's uploads; they do not enter data, so the Alert Type selects what to review and no entry or upload controls are shown.
        header('New / Upload Alerts', 'Approve ATM uploads and reopen requests');
        await loadTemplates(true);
        const approverTypes = state.templates.filter((t) => t.status === 'Published');
        const approvalTypes = { ATM_ONUS: ['OnUs'], ATM_OFFUS: ['OffUs'] };
        $('#viewHost').html(
            '<div class="card mb-3"><div class="card-body"><label for="newAlertType" class="form-label">Alert Type</label><select id="newAlertType" class="form-select"><option value="">All alert types</option>' +
                approverTypes.map((t) => '<option value="' + esc(t.code) + '">' + esc(t.name || t.code) + '</option>').join('') +
                '</select><div class="form-text">Your role approves uploads; it does not create or upload alerts. Choose an alert type to see what is waiting for your approval.</div></div></div><div id="atmApprovals"></div>',
        );
        const showApprovals = () => {
            const code = String($('#newAlertType').val() || '').toUpperCase();
            const types = code ? approvalTypes[code] || [] : ['OnUs', 'OffUs'];
            return renderAtmApprovals('#atmApprovals', { types, reopen: !code || code in approvalTypes });
        };
        $('#newAlertType').on('change', () => observeTask(showApprovals()));
        await showApprovals();
        return;
    }
    // Template settings (file format, separator, column mapping) are edited by other users at any time; never trust the login-time cache here.
    await loadTemplates(true);
    header('New / Upload Alerts', 'Create a single alert or upload a CSV file');
    // ATM penalty files are sent for approval by the DBOPS Maker only.
    const isAtmType = (template) => /^ATM_(ONUS|OFFUS)$/i.test(String(template.code || ''));
    const published = state.templates.filter((t) => t.status === 'Published' && (!isAtmType(t) || has('ATM.UPLOAD')));
    const available = published.filter(
        (template) =>
            templateAllowsBaseDataMode(template, 'ManualSingle') ||
            templateAllowsBaseDataMode(template, 'BulkFileUpload'),
    );
    if (!available.length) {
        $('#viewHost').html(
            '<div class="alert alert-light border" role="status">No published alert types are enabled for Manual Single Entry or Bulk File Upload.</div>',
        );
        return;
    }
    const periodHtml =
        '<div id="atmPeriod" class="row g-2 mb-3 d-none"><div class="col-6"><label class="form-label" for="atmPenaltyMonth">Penalty month</label><select id="atmPenaltyMonth" class="form-select">' +
        Array.from({ length: 12 }, (_, index) => {
            const value = String(index + 1).padStart(2, '0');
            return `<option value="${value}" ${index === new Date().getMonth() ? 'selected' : ''}>${new Date(2000, index).toLocaleString(undefined, { month: 'long' })}</option>`;
        }).join('') +
        `</select></div><div class="col-6"><label class="form-label" for="atmPenaltyYear">Penalty year</label><input id="atmPenaltyYear" class="form-control" type="number" min="2000" max="2100" value="${new Date().getFullYear()}"></div><div class="col-12 form-text">ATM penalty files are sent to a DBOPS Checker for approval before the cases are created.</div></div>`;
    $('#viewHost').html(
        '<div class="card mb-3"><div class="card-body"><label for="newAlertType" class="form-label">Alert Type <span class="text-danger">*</span></label><select id="newAlertType" class="form-select" required><option value="">Select alert type</option>' +
            available.map((t) => '<option value="' + esc(t.id) + '">' + esc(t.name || t.code) + '</option>').join('') +
            '</select></div></div>' +
            '<div id="newAlertModeHint" class="alert alert-light border" role="status">Select an alert type to see its available entry methods.</div>' +
            '<div class="row g-3"><div id="manualEntryColumn" class="col-12 d-none"><div id="newAlertCard" class="card"><div class="card-header fw-semibold">Create Alert</div><div class="card-body"><form id="newAlertForm" novalidate><div id="newDynamic"></div><div class="text-end"><button type="submit" class="btn btn-primary px-4">Submit Alert</button></div></form></div></div></div>' +
            '<div id="bulkEntryColumn" class="col-12 d-none"><div id="bulkUploadCard" class="card"><div class="card-header fw-semibold">Bulk File Upload</div><div class="card-body"><p class="small text-secondary">Upload records using the file format, separator and source column mapping defined by the selected alert configuration.</p><button id="downloadSampleCsv" type="button" class="btn btn-sm btn-link px-0 mb-2">Download sample file for selected Alert Type</button>' +
            periodHtml +
            '<input id="csvFile" type="file" accept=".csv,.txt,text/csv,text/plain" class="form-control mb-3" aria-label="Upload file"/><button id="uploadCsvBtn" type="button" class="btn btn-outline-primary w-100">Upload file</button><div id="csvResult" class="small mt-3"></div></div></div></div></div>' +
            '<div id="atmMyUploads"></div><div id="atmApprovals"></div>',
    );
    await bindNewAlertEvents({ published, available });
    if (has('ATM.UPLOAD')) await renderMyUploads('#atmMyUploads', { types: ['OnUs', 'OffUs'] });
    if (has('ATM.CHECK')) await renderAtmApprovals('#atmApprovals', { types: ['OnUs', 'OffUs'], reopen: true });
}

/**
 * Load and render the detail screen, then initialize its controls and event handlers.
 * @param {*} id - Entity identifier.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderDetail(id) {
    disposeAlertDetailPopups();
    header('Alert Detail', '', '<button id="backAlerts" class="btn btn-sm btn-outline-secondary">← Back</button>');
    loading();
    let d;
    try {
        d = await api('/api/alerts/' + id);
    } catch (error) {
        if (/not authori[sz]ed|access denied/i.test(error.message || ''))
            document.dispatchEvent(new CustomEvent('cats:alert-access-denied', { detail: { id } }));
        throw error;
    }
    document.dispatchEvent(new CustomEvent('cats:alert-opened', { detail: d.alert }));
    header(
        'Alert Detail',
        `Alert Type: ${d.alert.alertType}`,
        '<button id="backAlerts" class="btn btn-sm btn-outline-secondary">← Back</button>',
    );
    const data = d.dynamicData || {};
    const editable = new Set((d.editableFields || []).map((x) => String(x).toLowerCase()));
    const detailViewConfig = templateViewConfig({ viewConfiguration: d.viewConfiguration });
    state.detail = d;
    const sections = configuredSectionsHtml(
        d.sections,
        d.fields,
        data,
        editable,
        'detail-dynamic-field',
        detailViewConfig,
        'detail-layout',
    );
    const actions = (d.allowedActions || [])
        .map(
            (a) =>
                `<button class="btn ${/reject/i.test(a) ? 'btn-outline-danger' : /query|return/i.test(a) ? 'btn-outline-warning' : 'btn-primary'} workflow-action" data-action="${esc(a)}">${esc(a)}</button>`,
        )
        .join('');
    const isAtmCase = String(d.alert.alertType || '').toUpperCase().startsWith('ATM_');
    const canManageAtmCase = has('ATM.CASE.MANAGE');
    const reassign = isAtmCase
        ? canManageAtmCase && d.alert.status !== 'Closed' && has('ALERT.REASSIGN')
            ? `<div class="card mb-3"><div class="card-header bg-white fw-semibold">Reassign ATM Case</div><div class="card-body"><label class="form-label small" for="reassignUser">Employee ID or CATS username</label><input id="reassignUser" class="form-control form-control-sm mb-2" placeholder="Employee ID or username"><input id="reassignRemarks" class="form-control form-control-sm mb-2" placeholder="Reason / remarks"><button id="reassignBtn" class="btn btn-sm btn-outline-primary w-100">Validate and reassign</button></div></div>`
            : ''
        : has('ALERT.REASSIGN')
        ? `<div class="card mb-3"><div class="card-header bg-white fw-semibold">Reassign Current Stage</div><div class="card-body"><div class="row g-2"><div class="col-md-4"><input id="reassignRole" class="form-control form-control-sm" placeholder="Role code" list="roleOptions"></div><div class="col-md-4"><input id="reassignBranch" class="form-control form-control-sm" placeholder="Branch (optional)"></div><div class="col-md-4"><input id="reassignUser" class="form-control form-control-sm" placeholder="User ID (optional)"></div><div class="col-12"><input id="reassignRemarks" class="form-control form-control-sm" placeholder="Reason / remarks"></div><div class="col-12 d-grid"><button id="reassignBtn" class="btn btn-sm btn-outline-primary">Reassign</button></div></div></div></div>`
        : '';
    const reopen = isAtmCase && canManageAtmCase && d.alert.status === 'Closed'
        ? '<div class="card mb-3"><div class="card-header bg-white fw-semibold">Reopen ATM Case</div><div class="card-body"><input id="atmReopenRemarks" class="form-control form-control-sm mb-2" placeholder="Reason / remarks"><button id="atmReopenBtn" class="btn btn-sm btn-outline-primary w-100">Send to DBOPS Checker</button></div></div>'
        : '';
    let h = `<div class="row g-3"><div class="col-xl-8"><div class="card mb-3"><div class="card-body"><div class="d-flex flex-wrap justify-content-between gap-2"><div><div class="text-secondary small">Alert Number</div><h4 class="text-primary">${esc(d.alert.alertNo)}</h4><div class="small text-secondary">Alert Type</div><div class="fw-semibold">${esc(d.alert.alertType)}</div></div><div>${statusBadge(d.alert.status)}</div></div></div></div>${editable.size ? '<div class="alert alert-info py-2 small">Fields shown as inputs can be updated by your role at the current workflow stage. Values are saved when you perform a workflow action.</div>' : ''}${sections}<div class="card"><div class="card-header bg-white fw-semibold">Attachments</div><div class="card-body"><form id="attachmentForm" class="row g-2"><div class="col-md-8"><input id="attachmentFile" class="form-control" type="file" /></div><div class="col-md-4 d-grid"><button class="btn btn-outline-primary">Upload to Current Stage</button></div></form><div class="mt-3">${d.attachments.length ? d.attachments.map((a) => `<a class="d-block mb-1" target="_blank" href="#" data-attachment="${a.id}">📎 ${esc(a.fileName)} v${a.version} <span class="text-secondary small">${Math.ceil(a.fileSize / 1024)} KB</span></a>`).join('') : '<span class="text-secondary small">No attachments.</span>'}</div></div></div></div><div class="col-xl-4"><div class="card mb-3"><div class="card-header bg-white fw-semibold">Current Workflow</div><div class="card-body"><div class="mb-2"><span class="small text-secondary">Stage</span><div class="fw-semibold">${esc(d.alert.currentStageName)}</div></div><div class="d-flex flex-wrap gap-2">${actions || '<span class="text-secondary small">No action assigned to your role.</span>'}</div></div></div>${reassign}${reopen}<div class="card mb-3"><div class="card-header bg-white fw-semibold">Queries</div><div class="card-body">${d.queries.length ? d.queries.map((q) => `<div class="mb-3"><div class="small text-secondary">${esc(q.raisedBy)} · ${new Date(q.raisedAtUtc).toLocaleString()}</div><div>${esc(q.queryText)}</div>${q.responseText ? `<div class="mt-1 ps-2 border-start text-secondary">${esc(q.responseText)}</div>` : ''}<span class="badge text-bg-light">${esc(q.status)}</span></div>`).join('') : '<span class="text-secondary small">No queries.</span>'}</div></div><div class="card"><div class="card-header bg-white fw-semibold">Audit Trail</div><div class="card-body cats-audit">${
        d.audit.length
            ? d.audit
                  .slice(0, 30)
                  .map(
                      (a) =>
                          `<div class="audit-line"><div class="fw-medium">${esc(a.action)}</div><div class="small text-secondary">${esc(a.userName)} · ${esc(a.roleCode)} · ${new Date(a.createdAtUtc).toLocaleString()}</div>${a.remarks ? `<div class="small">${esc(a.remarks)}</div>` : ''}</div>`,
                  )
                  .join('')
            : '<span class="text-secondary small">Audit trail not available for your role.</span>'
    }</div></div></div></div>`;
    $('#viewHost').html(d.workflowNotice
        ? `<div class="alert alert-warning" role="alert">${esc(d.workflowNotice)}</div>${h}`
        : (d.allowedActions || []).length ? h :
        '<div class="alert alert-secondary py-2 small">View only: no workflow action is assigned to you at the current stage. Field values cannot be edited.</div>' + h);
    const detailPopups = $('#viewHost .cats-template-popup')
        .attr('data-alert-detail-popup', 'true')
        .appendTo(document.body);
    const detailFields = $('#viewHost').add(detailPopups);
    bindConfiguredFields(detailFields, 'detail-dynamic-field');
    if (!d.canUploadAttachments)
        $('#attachmentForm').replaceWith(
            '<div class="alert alert-light border py-2 small mb-0">Your role can view permitted attachments but cannot upload at the current stage.</div>',
        );
    const split = $('#viewHost > .row').first().addClass('detail-split-view');
    const panes = split.children('[class*="col-xl-"]');
    panes.first().addClass('detail-main-pane');
    panes.last().addClass('detail-side-pane').attr('id', 'alertDetailSidePane');
    /**
     * Convert a detail sidebar card into a labeled collapsible section with its initial expanded state.
     * @param {*} title - Heading or section label.
     * @param {*} key - Property or preference identifier.
     * @param {*} defaultOpen - Whether the section initially expands.
     * @param {*} [count] - Optional count displayed alongside the section title.
     * @returns {void} Updates the relevant UI or state.
     */
    const makeSideCardCollapsible = (title, key, defaultOpen, count = null) => {
        const header = panes
            .last()
            .find('.card-header')
            .filter((_, element) => $(element).text().trim() === title)
            .first();
        if (!header.length) return;
        const body = header.next('.card-body');
        if (!body.length) return;
        const storageKey = `cats_detail_section_${key}_open`;
        const savedState = sessionStore.getItem(storageKey);
        const isOpen = savedState === null ? defaultOpen : savedState === 'true';
        const collapseId = `detail-${key}-collapse`;
        const toggleId = `detail-${key}-toggle`;
        const countBadge =
            count === null
                ? ''
                : `<span class="badge rounded-pill text-bg-light ms-2">${Number(count).toLocaleString()}</span>`;
        const collapse = $(
            `<div id="${collapseId}" class="collapse${isOpen ? ' show' : ''}" data-detail-section="${key}" role="region" aria-labelledby="${toggleId}"></div>`,
        );
        body.wrap(collapse);
        header
            .addClass('p-0')
            .html(
                `<button id="${toggleId}" class="detail-card-toggle${isOpen ? '' : ' collapsed'}" type="button" data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="${isOpen}" aria-controls="${collapseId}"><span class="d-inline-flex align-items-center">${esc(title)}${countBadge}</span><span class="detail-card-chevron" aria-hidden="true"></span></button>`,
            );
        header.closest('.card').addClass('detail-collapsible-card');
        $(`#${collapseId}`).on(
            'shown.bs.collapse hidden.bs.collapse',
            guardEvent(function () {
                sessionStore.setItem(storageKey, String($(this).hasClass('show')));
            }),
        );
    };
    makeSideCardCollapsible('Reassign Current Stage', 'reassign', false);
    makeSideCardCollapsible('Queries', 'queries', d.queries.length > 0, d.queries.length);
    makeSideCardCollapsible('Audit Trail', 'audit', false, d.audit.length);
    split.append(
        '<button id="detailPanelToggle" class="detail-panel-toggle" type="button" aria-controls="alertDetailSidePane"><span aria-hidden="true"></span></button>',
    );
    /**
     * Apply the detail sidebar collapse state and persist the session preference.
     * @param {*} collapsed - Whether the detail sidebar should be collapsed.
     * @returns {void} Updates the relevant UI or state.
     */
    const setDetailPanelCollapsed = (collapsed) => {
        split.toggleClass('is-collapsed', collapsed);
        $('#detailPanelToggle')
            .attr({
                'aria-expanded': String(!collapsed),
                'aria-label': collapsed ? 'Expand details' : 'Collapse details',
                title: collapsed ? 'Expand details' : 'Collapse details',
            })
            .find('span')
            .text(collapsed ? '‹' : '›');
        sessionStore.setItem('cats_detail_panel_collapsed', String(collapsed));
    };
    setDetailPanelCollapsed(sessionStore.getItem('cats_detail_panel_collapsed') === 'true');
    return bindDetailEvents({ id, d, data, split, setDetailPanelCollapsed, detailFields });
}

export { renderAlerts, renderNewAlert, renderDetail };
