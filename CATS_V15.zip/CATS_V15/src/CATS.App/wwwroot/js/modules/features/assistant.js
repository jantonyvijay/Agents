import { state } from '../core/state.js';
import { has } from '../core/permissions.js';
import { api } from '../api/client.js';
import { esc } from '../core/utils.js';

let recording;

/**
 * Check assistant permission and server availability before displaying the launcher and model.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function refreshAssistantStatus() {
    if (!state.user || !has('ASSISTANT.USE')) {
        $('#catsAssistantLauncher,#catsAssistantPanel').addClass('d-none');
        return;
    }
    const status = await api('/api/assistant/status');
    $('#catsAssistantModel').text(
        status.enabled ? `${status.provider || 'SLM/LLM'} · ${status.model || ''}` : 'Disabled',
    );
    $('#catsAssistantRecord').toggleClass('d-none', !status.enabled || !status.speechToTextEnabled);
    $('#catsAssistantLauncher').toggleClass('d-none', !status.enabled);
    if (!status.enabled) $('#catsAssistantPanel').addClass('d-none');
}

/**
 * Append an escaped user, assistant, or error message and scroll the conversation to the latest entry.
 * @param {*} text - Message text to display.
 * @param {*} type - Display type or notification severity.
 * @returns {void} Updates the relevant UI or state.
 */
function appendAssistantMessage(text, type) {
    const cls = type === 'user' ? 'user' : type === 'error' ? 'error' : 'assistant';
    $('#catsAssistantMessages').append(`<div class="cats-chat-message ${cls}">${esc(text)}</div>`);
    const host = document.getElementById('catsAssistantMessages');
    host.scrollTop = host.scrollHeight;
}

async function startAssistantSpeechCapture() {
    if (!navigator.mediaDevices?.getUserMedia || !window.AudioContext) {
        throw new Error('This browser does not support microphone recording.');
    }

    const stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true },
    });
    const context = new AudioContext();
    const source = context.createMediaStreamSource(stream);
    const processor = context.createScriptProcessor(4096, 1, 1);
    const chunks = [];
    processor.onaudioprocess = (event) => chunks.push(new Float32Array(event.inputBuffer.getChannelData(0)));
    await context.resume();
    source.connect(processor);
    processor.connect(context.destination);
    recording = { context, stream, source, processor, chunks };
}

async function stopAssistantSpeechCapture() {
    if (!recording) throw new Error('No speech recording is active.');
    const activeRecording = recording;
    recording = undefined;
    activeRecording.source.disconnect();
    activeRecording.processor.disconnect();
    activeRecording.stream.getTracks().forEach((track) => track.stop());
    await activeRecording.context.close();
    return createWaveBlob(activeRecording.chunks, activeRecording.context.sampleRate);
}

function drainAssistantSpeechCapture() {
    if (!recording) throw new Error('No speech recording is active.');
    if (recording.chunks.length === 0) return null;
    const chunks = recording.chunks.splice(0);
    return createWaveBlob(chunks, recording.context.sampleRate);
}

function createWaveBlob(chunks, sampleRate) {
    const samples = resampleTo16Khz(flattenAudio(chunks), sampleRate);
    return new Blob([encodeWave(samples)], { type: 'audio/wav' });
}

function flattenAudio(chunks) {
    const length = chunks.reduce((total, chunk) => total + chunk.length, 0);
    const samples = new Float32Array(length);
    let offset = 0;
    chunks.forEach((chunk) => {
        samples.set(chunk, offset);
        offset += chunk.length;
    });
    return samples;
}

function resampleTo16Khz(samples, sourceRate) {
    if (sourceRate === 16000) return samples;
    const output = new Float32Array(Math.round(samples.length * 16000 / sourceRate));
    const sampleRatio = sourceRate / 16000;
    for (let index = 0; index < output.length; index += 1) {
        const position = index * sampleRatio;
        const before = Math.floor(position);
        const after = Math.min(before + 1, samples.length - 1);
        output[index] = samples[before] + (samples[after] - samples[before]) * (position - before);
    }
    return output;
}

function encodeWave(samples) {
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);
    const writeString = (offset, value) =>
        [...value].forEach((character, index) => view.setUint8(offset + index, character.charCodeAt(0)));
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + samples.length * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, 16000, true);
    view.setUint32(28, 32000, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, samples.length * 2, true);
    samples.forEach((sample, index) =>
        view.setInt16(44 + index * 2, Math.max(-1, Math.min(1, sample)) * 0x7fff, true));
    return buffer;
}

export {
    refreshAssistantStatus,
    appendAssistantMessage,
    startAssistantSpeechCapture,
    stopAssistantSpeechCapture,
    drainAssistantSpeechCapture,
};
