import { has } from '../core/permissions.js';
import { header, loading } from '../ui/feedback.js';
import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { bindMcpDiscoveryEvents } from '../events/mcp.js';

/**
 * Load and render the mcp discovery screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderMcpDiscovery() {
    if (!has('MCP.MANAGE')) throw new Error('MCP management permission is required.');
    header('MCP Server Connections', 'Monitor configured MCP servers and available tools');
    loading();
    const servers = await api('/api/mcp/servers');
    const rows = servers
        .map(
            (x) =>
                `<tr data-mcp-code="${esc(x.code)}"><td><div class="fw-semibold">${esc(x.name || x.code)}</div><code>${esc(x.code)}</code></td><td class="text-break small">${esc(x.endpoint)}</td><td class="mcp-status">${x.enabled ? '<span class="badge text-bg-info">Waiting</span>' : '<span class="badge text-bg-secondary">Disabled</span>'}</td><td class="mcp-tool-count">${x.approvedToolCount || 0} approved</td><td class="text-end"><button class="btn btn-sm btn-outline-primary mcp-discover" data-code="${esc(x.code)}" ${x.enabled ? '' : 'disabled'}>Reconnect</button></td></tr>`,
        )
        .join('');
    $('#viewHost').html(
        `<div class="alert alert-light border small"><strong>Automatic connection:</strong> Enabled servers connect when this page opens. Only approved read-only tools are available to the CATS Assistant.</div><div class="card mb-3"><div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2"><span class="fw-semibold">Discover another MCP server</span><div><button id="mcpClearResults" type="button" class="btn btn-sm btn-outline-secondary me-1">Clear results</button><button id="mcpResetPage" type="button" class="btn btn-sm btn-outline-danger">Reset page</button></div></div><div class="card-body"><form id="mcpEndpointDiscoveryForm" class="row g-2 align-items-end"><div class="col-md-3"><label class="form-label">Server name</label><input id="mcpEndpointName" class="form-control" maxlength="120" placeholder="Example: Finance MCP"></div><div class="col-md-7"><label class="form-label">MCP endpoint</label><input id="mcpEndpointUrl" class="form-control" type="url" required placeholder="https://server.example.com/mcp"></div><div class="col-md-2 d-grid"><button id="mcpEndpointDiscover" class="btn btn-primary">Discover server</button></div><div class="col-12 form-text">Temporary discovery only. You can inspect multiple servers during this session; their tools are not automatically approved or saved.</div></form></div></div><div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Server</th><th>Endpoint</th><th>Connection</th><th>Tools</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="text-secondary text-center py-4">No MCP servers are configured.</td></tr>'}</tbody></table></div></div><div id="mcpDiscoveryResults" class="mt-3"></div>`,
    );

    /**
     * Request MCP tool discovery for a server and update its status and tool list.
     * @param {*} code - Configured MCP server code.
     * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
     */
    async function discover(code) {
        const row = $(`tr[data-mcp-code="${CSS.escape(code)}"]`),
            button = row.find('.mcp-discover');
        row.find('.mcp-status').html('<span class="badge text-bg-info">Connecting...</span>');
        button.prop('disabled', true).text('Connecting...');
        try {
            const result = await api(`/api/mcp/servers/${encodeURIComponent(code)}/discover`, { method: 'POST' });
            const tools = result.tools || [];
            row.find('.mcp-status').html('<span class="badge text-bg-success">Connected</span>');
            row.find('.mcp-tool-count').text(
                `${tools.length} discovered / ${tools.filter((x) => x.approvedReadOnly).length} approved`,
            );
            const toolRows = tools
                .map(
                    (t) =>
                        `<tr><td><code>${esc(t.name)}</code></td><td>${esc(t.description || '')}</td><td>${t.approvedReadOnly ? '<span class="badge text-bg-success">Approved read-only</span>' : '<span class="badge text-bg-warning">Not approved</span>'}</td></tr>`,
                )
                .join('');
            $('#mcpDiscoveryResults').append(
                `<div class="card mb-3"><div class="card-header bg-white fw-semibold">${esc(result.serverName || code)} - Available tools</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Tool</th><th>Description</th><th>Assistant access</th></tr></thead><tbody>${toolRows || '<tr><td colspan="3" class="text-secondary">Connected successfully; the server returned no tools.</td></tr>'}</tbody></table></div></div>`,
            );
        } catch (x) {
            row.find('.mcp-status').html('<span class="badge text-bg-danger">Connection failed</span>');
            row.find('.mcp-tool-count').html(`<span class="text-danger small">${esc(x.message)}</span>`);
        } finally {
            button.prop('disabled', false).text('Reconnect');
        }
    }

    return bindMcpDiscoveryEvents({ servers, discover });
}

export { renderMcpDiscovery };
