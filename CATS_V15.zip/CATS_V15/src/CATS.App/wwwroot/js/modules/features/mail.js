import { api } from '../api/client.js';
import { header } from '../ui/feedback.js';
import { state } from '../core/state.js';
import { esc } from '../core/utils.js';
import { bindPlatformMailEvents } from '../events/mail.js';

/**
 * Load and render the platform mail screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderPlatformMail() {
    const [providers, templates, logs] = await Promise.all([
        api('/api/platform/mail/configurations'),
        api('/api/platform/mail/templates'),
        api('/api/platform/mail/logs?take=50'),
    ]);
    $('#mailProviderModal,#mailTemplateModal').remove();
    $('.modal-backdrop').remove();
    $('body').removeClass('modal-open').css('padding-right', '');
    header(
        'Email Templates & Logs',
        'Configure alert-based email templates here; sending is executed by your external mail system or job worker',
    );
    const alertTemplates = state.templates.map((x) => `<option value="${esc(x.id)}">${esc(x.name || x.code)}</option>`).join('');
    $('#viewHost').html(
        `<div class="alert alert-info"><b>Configuration only:</b> This portal stores mail settings, template content and delivery logs. The external mail service reads active configuration and performs delivery.</div><div class="d-flex gap-2 mb-3"><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#mailProviderModal">+ Add Mail Configuration</button><button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#mailTemplateModal">+ Add Email Template</button></div><div class="card mb-3"><div class="card-header">Mail Configurations</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Name</th><th>Provider</th><th>Server</th><th>From address</th><th>Status</th></tr></thead><tbody>${providers.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.providerType)}</td><td>${esc(x.host)}:${x.port}</td><td>${esc(x.fromAddress)}</td><td>${x.isActive ? 'Active' : 'Disabled'}</td></tr>`).join('')}</tbody></table></div></div><div class="card mb-3"><div class="card-header">Email Templates</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Alert Template</th><th>Event</th><th>Subject</th><th>Status</th></tr></thead><tbody>${templates.map((x) => `<tr><td>${esc(state.templates.find((t) => t.id === x.templateId)?.name || 'All templates')}</td><td>${esc(x.eventCode)}</td><td>${esc(x.subjectTemplate)}</td><td>${x.isActive ? 'Active' : 'Disabled'}</td></tr>`).join('')}</tbody></table></div></div><div class="card"><div class="card-header">External Delivery Logs</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Created</th><th>Event</th><th>Recipient</th><th>Status</th><th>Attempts</th><th>Error</th></tr></thead><tbody>${logs.map((x) => `<tr><td>${esc(x.createdAtUtc)}</td><td>${esc(x.eventCode)}</td><td>${esc(x.toAddress)}</td><td>${esc(x.status)}</td><td>${x.attempts}</td><td>${esc(x.errorMessage || '')}</td></tr>`).join('')}</tbody></table></div></div><div class="modal fade" id="mailProviderModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Add Mail Configuration</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="mailProviderPopupForm"><div class="modal-body"><div class="mb-3"><label class="form-label">Configuration name</label><input id="mcName" class="form-control" placeholder="Example: Corporate SMTP" required></div><div class="row g-3"><div class="col-8"><label class="form-label">Mail server</label><input id="mcHost" class="form-control" placeholder="smtp.example.com" required></div><div class="col-4"><label class="form-label">Port</label><input id="mcPort" type="number" value="587" class="form-control"></div><div class="col-12"><label class="form-label">From address</label><input id="mcFrom" type="email" class="form-control" placeholder="cats@example.com" required></div><div class="col-6"><label class="form-label">User name</label><input id="mcUser" class="form-control"></div><div class="col-6"><label class="form-label">Password / secret</label><input id="mcSecret" type="password" class="form-control"></div></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Configuration</button></div></form></div></div></div><div class="modal fade" id="mailTemplateModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Add Email Template</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="mailTemplatePopupForm"><div class="modal-body"><div class="row g-3"><div class="col-md-6"><label class="form-label">Alert template</label><select id="mtTemplate" class="form-select" required><option value="">Select alert template</option>${alertTemplates}</select></div><div class="col-md-6"><label class="form-label">When should this email be used?</label><select id="mtEvent" class="form-select"><option>ALERT_CREATED</option><option>STAGE_ASSIGNED</option><option>QUERY_RAISED</option><option>ALERT_CLOSED</option></select></div><div class="col-12"><label class="form-label">Email subject</label><input id="mtSubject" class="form-control" value="CATS alert {{AlertNo}} update" required></div><div class="col-12"><label class="form-label">Email body</label><textarea id="mtBody" rows="7" class="form-control"><p>Hello {{DisplayName}},</p><p>Alert {{AlertNo}} has status {{Status}}.</p></textarea><div class="form-text">Available values: {{AlertNo}}, {{DisplayName}}, {{Status}}, {{StageName}}, {{BranchCode}}</div></div></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Email Template</button></div></form></div></div></div>`,
    );
    const emailTemplateCard = $('.card-header')
        .filter(function () {
            return $(this).text().trim() === 'Email Templates';
        })
        .closest('.card');
    emailTemplateCard.find('th:first').text('Alert Type');
    templates.forEach((x, index) =>
        emailTemplateCard
            .find('tbody tr')
            .eq(index)
            .find('td:first')
            .text(state.templates.find((t) => t.id === x.templateId)?.code || ''),
    );
    $('#mailTemplatePopupForm label')
        .filter(function () {
            return $(this).text().trim() === 'Alert template';
        })
        .text('Alert Type');
    $('#mtTemplate option:first').text('Select alert type');
    $('#viewHost .alert-info').html(
        '<b>Template management only:</b> This portal stores email templates and delivery logs. Your external mail service performs delivery.',
    );
    $('[data-bs-target="#mailProviderModal"]').remove();
    $('.card-header')
        .filter(function () {
            return $(this).text().trim() === 'Mail Configurations';
        })
        .closest('.card')
        .remove();
    $('#mailProviderModal').remove();
    $('#mailTemplateModal').appendTo(document.body);
    return bindPlatformMailEvents({});
}

export { renderPlatformMail };
