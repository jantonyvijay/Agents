import { api } from '../api/client.js';
import { loadRoles, loadTemplates } from '../api/catalogs.js';
import { state } from '../core/state.js';
import { esc } from '../core/utils.js';
import { toast } from '../ui/feedback.js';
import { guardEvent } from '../events/guard.js';
import { moduleCodeFromName, CHOICE_TYPES } from '../business/template-logic.js';
import { presetWorkflow } from '../business/workflow-logic.js';
import { FLOW_SLOTS, buildModule, validateWizardStep } from '../business/module-wizard-logic.js';

const STEPS = ['What is it?', 'What to record', 'Who approves', 'Who can use it'];
const FLOWS = [
    ['maker_checker', 'Maker → Checker', 'One person enters it, another approves or returns it.'],
    ['maker_checker_verifier', 'Maker → Checker → Verifier', 'Entered, approved, then verified by a third role.'],
    ['single', 'Single approval', 'One person reviews and decides (approve or reject).'],
];

let wz;
let step;
let onDone;

const freshAnswers = () => ({
    name: '',
    code: '',
    codeEdited: false,
    sectionName: 'Details',
    questions: [{ label: '', type: 'text', required: false, choices: '' }],
    flow: 'maker_checker',
    roles: {},
    everyone: true,
    accessRoles: [],
});

/** Create the wizard dialog once. */
function ensureModal() {
    if ($('#moduleWizardModal').length) return;
    $('body').append(
        `<div class="modal fade" id="moduleWizardModal" tabindex="-1" aria-labelledby="moduleWizardTitle" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h5 id="moduleWizardTitle" class="modal-title">New Module</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div id="mwSteps" class="d-flex flex-wrap gap-2 mb-3"></div><div id="mwBody"></div><div id="mwError" class="text-danger small mt-2 d-none" role="alert"></div></div><div class="modal-footer"><button type="button" id="mwBack" class="btn btn-outline-secondary">← Back</button><button type="button" id="mwNext" class="btn btn-primary">Next →</button><button type="button" id="mwCreate" class="btn btn-success d-none">Create module</button></div></div></div></div>`,
    );
    const body = $('#mwBody');
    body.on('input change', '[data-mw]', function () {
        const key = String($(this).data('mw'));
        const value = $(this).is(':checkbox') ? this.checked : $(this).val();
        if (key === 'name') {
            wz.name = value;
            if (!wz.codeEdited) {
                wz.code = moduleCodeFromName(value);
                $('#mwCode').val(wz.code);
            }
        } else if (key === 'code') {
            wz.code = String(value).toUpperCase().replace(/[^A-Z0-9_]/g, '');
            wz.codeEdited = true;
            $(this).val(wz.code);
        } else if (key === 'section') wz.sectionName = value;
        else if (key === 'flow') {
            wz.flow = value;
            wz.roles = {};
            render();
        } else if (key.startsWith('role:')) wz.roles[key.slice(5)] = value;
        else if (key === 'everyone') {
            wz.everyone = value === 'yes';
            render();
        }
    });
    body.on('input change', '[data-q]', function () {
        const row = $(this).closest('[data-i]');
        const q = wz.questions[Number(row.data('i'))];
        const field = String($(this).data('q'));
        q[field] = $(this).is(':checkbox') ? this.checked : $(this).val();
        if (field === 'type') render();
    });
    body.on('click', '#mwAddQuestion', () => {
        wz.questions.push({ label: '', type: 'text', required: false, choices: '' });
        render();
        $('#mwBody [data-q="label"]').last().trigger('focus');
    });
    body.on('click', '.mw-remove', function () {
        wz.questions.splice(Number($(this).closest('[data-i]').data('i')), 1);
        if (!wz.questions.length) wz.questions.push({ label: '', type: 'text', required: false, choices: '' });
        render();
    });
    body.on('keydown', '[data-q="label"]', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        $('#mwAddQuestion').trigger('click');
    });
    body.on('change', '.mw-access-role', () => {
        wz.accessRoles = $('.mw-access-role:checked').map((_, el) => el.value).get();
    });
    $('#mwBack').on('click', () => go(step - 1));
    $('#mwNext').on('click', guardEvent(() => go(step + 1)));
    $('#mwCreate').on('click', guardEvent(create));
}

/**
 * Move to another page, checking the current page when going forward.
 * @param {number} target - Page number to show.
 * @returns {void} Updates the relevant UI or state.
 */
function go(target) {
    if (target > step) {
        const problem = validateWizardStep(wz, step);
        if (problem) return showError(problem);
    }
    showError('');
    step = Math.min(STEPS.length, Math.max(1, target));
    render();
}

function showError(text) {
    $('#mwError').toggleClass('d-none', !text).text(text || '');
}

function render() {
    const roles = state.roles || [];
    const typeOptions = $('#fieldType').html() || '<option value="text">Textbox</option>';
    $('#mwSteps').html(
        STEPS.map(
            (name, i) =>
                `<span class="badge ${i + 1 === step ? 'text-bg-primary' : i + 1 < step ? 'text-bg-success' : 'text-bg-light border'}">${i + 1} · ${name}</span>`,
        ).join(''),
    );
    let html = '';
    if (step === 1)
        html = `<p class="text-secondary">A module is one kind of alert your team works on, with its own questions and approval steps. This guide creates everything in one go.</p><div class="mb-3"><label class="form-label" for="mwName">Name of the module</label><input id="mwName" data-mw="name" class="form-control" maxlength="150" placeholder="e.g. Cheque Return Review" value="${esc(wz.name)}"></div><div class="mb-3"><label class="form-label" for="mwCode">Short code</label><input id="mwCode" data-mw="code" class="form-control" maxlength="80" value="${esc(wz.code)}"><div class="form-text">Made from the name. Letters, numbers and underscores only.</div></div><div><label class="form-label" for="mwSection">Heading for the group of questions</label><input id="mwSection" data-mw="section" class="form-control" maxlength="200" value="${esc(wz.sectionName)}"></div>`;
    if (step === 2)
        html = `<p class="text-secondary">What should people fill in? Type each question and choose the kind of answer. You can add more later in Template Designer.</p>${wz.questions
            .map(
                (q, i) =>
                    `<div class="row g-2 align-items-center mb-2" data-i="${i}"><div class="col-md-5"><input class="form-control form-control-sm" data-q="label" placeholder="e.g. Account number" aria-label="Question" value="${esc(q.label)}"></div><div class="col-md-3"><select class="form-select form-select-sm" data-q="type" aria-label="Kind of answer">${typeOptions}</select></div><div class="col-md-2"><div class="form-check"><input class="form-check-input" type="checkbox" data-q="required" id="mwReq${i}" ${q.required ? 'checked' : ''}><label class="form-check-label small" for="mwReq${i}">Must fill</label></div></div><div class="col-md-2 text-end"><button type="button" class="btn btn-sm btn-outline-danger mw-remove" aria-label="Remove question">×</button></div>${CHOICE_TYPES.includes(q.type) ? `<div class="col-12"><input class="form-control form-control-sm" data-q="choices" placeholder="Choices, separated by commas (e.g. High, Medium, Low)" aria-label="Choices" value="${esc(q.choices)}"></div>` : ''}</div>`,
            )
            .join('')}<button type="button" class="btn btn-sm btn-outline-primary" id="mwAddQuestion">Add another question</button>`;
    if (step === 3) {
        const guess = Object.fromEntries(presetWorkflow(wz.flow, roles).stages.map((s) => [s.id, s.roleCode]));
        for (const [id] of FLOW_SLOTS[wz.flow]) if (wz.roles[id] === undefined) wz.roles[id] = guess[id] || '';
        html = `<p class="text-secondary">Choose how an alert is approved.</p><div class="mb-3">${FLOWS.map(
            ([value, title, help]) =>
                `<div class="form-check border rounded p-3 mb-2"><input class="form-check-input ms-0 me-2" type="radio" name="mwFlow" id="mwFlow_${value}" data-mw="flow" value="${value}" ${wz.flow === value ? 'checked' : ''}><label class="form-check-label fw-semibold" for="mwFlow_${value}">${title}</label><div class="small text-secondary">${help}</div></div>`,
        ).join('')}</div>${FLOW_SLOTS[wz.flow]
            .map(
                ([id, question]) =>
                    `<div class="mb-2"><label class="form-label" for="mwRole_${id}">${question}</label><select class="form-select" id="mwRole_${id}" data-mw="role:${id}"><option value="">Choose a role…</option>${roles.map((r) => `<option value="${esc(r)}" ${wz.roles[id] === r ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select></div>`,
            )
            .join('')}`;
    }
    if (step === 4) {
        const used = [...new Set(Object.values(wz.roles).filter(Boolean))];
        if (!wz.accessInit) {
            wz.accessRoles = used.slice();
            wz.accessInit = true;
        }
        html = `<p class="text-secondary">Who can open this module and raise alerts in it?</p><div class="form-check mb-1"><input class="form-check-input" type="radio" name="mwWho" id="mwWhoAll" data-mw="everyone" value="yes" ${wz.everyone ? 'checked' : ''}><label class="form-check-label" for="mwWhoAll">Everyone who can sign in</label></div><div class="form-check mb-3"><input class="form-check-input" type="radio" name="mwWho" id="mwWhoSome" data-mw="everyone" value="no" ${wz.everyone ? '' : 'checked'}><label class="form-check-label" for="mwWhoSome">Only the roles I tick</label></div>${
            wz.everyone
                ? ''
                : `<div class="mb-3">${roles.map((r, i) => `<div class="form-check form-check-inline"><input class="form-check-input mw-access-role" type="checkbox" id="mwAcc${i}" value="${esc(r)}" ${wz.accessRoles.includes(r) ? 'checked' : ''}><label class="form-check-label" for="mwAcc${i}">${esc(r)}</label></div>`).join('')}<div class="form-text">Include the roles in the approval flow, or they will not see their work. Central reviewers always keep access.</div></div>`
        }<div class="border rounded p-3 bg-light small"><div class="fw-semibold mb-1">Summary</div><div>Module: <b>${esc(wz.name)}</b> (${esc(wz.code)})</div><div>Questions: ${wz.questions.filter((q) => String(q.label).trim()).map((q) => esc(q.label)).join(', ')}</div><div>Approval: ${esc(FLOWS.find((f) => f[0] === wz.flow)[1])} (${FLOW_SLOTS[wz.flow].map(([id]) => esc(wz.roles[id] || '?')).join(' → ')})</div></div>`;
    }
    $('#mwBody').html(html);
    $('#mwBody [data-q="type"]').each(function () {
        $(this).val(wz.questions[Number($(this).closest('[data-i]').data('i'))].type);
    });
    $('#mwBack').prop('disabled', step === 1);
    $('#mwNext').toggleClass('d-none', step === STEPS.length);
    $('#mwCreate').toggleClass('d-none', step !== STEPS.length);
}

/**
 * Create the template, publish its workflow and set who may use it. Each stage reports its own failure so nothing is lost silently.
 * @returns {Promise<void>} Resolves when finished.
 */
async function create() {
    const problem = validateWizardStep(wz, 4);
    if (problem) return showError(problem);
    showError('');
    const made = buildModule(wz, state.roles || []);
    $('#mwCreate,#mwBack').prop('disabled', true);
    let template;
    try {
        template = await api('/api/templates', { method: 'POST', body: made.template });
    } catch (error) {
        $('#mwCreate,#mwBack').prop('disabled', false);
        return showError(`The module could not be created: ${error.message}`);
    }
    const notes = [];
    try {
        await api('/api/templates/workflow', {
            method: 'POST',
            body: { templateId: template.id, name: made.workflow.name, definition: made.workflow.definition, publish: true },
        });
    } catch (error) {
        notes.push(`The approval flow was not saved (${error.message}). Open Workflow Designer to finish it.`);
    }
    try {
        await api(`/api/templates/${template.id}/access`, { method: 'PUT', body: made.access });
    } catch (error) {
        notes.push(`Who can use it was not saved (${error.message}). Open Template Designer to set it.`);
    }
    await loadTemplates(true);
    bootstrap.Modal.getOrCreateInstance('#moduleWizardModal').hide();
    toast(notes.length ? `Module created, but: ${notes.join(' ')}` : `Module "${template.name}" is ready to use.`, notes.length ? 'warning' : 'success');
    $('#mwCreate,#mwBack').prop('disabled', false);
    onDone?.();
}

/**
 * Open the guided New Module wizard.
 * @param {{onDone?: Function}} [options] - Called after a module has been created.
 * @returns {Promise<void>} Resolves once the dialog is shown.
 */
async function openModuleWizard(options = {}) {
    ensureModal();
    onDone = options.onDone;
    await loadRoles().catch(() => []);
    wz = freshAnswers();
    step = 1;
    showError('');
    render();
    bootstrap.Modal.getOrCreateInstance('#moduleWizardModal').show();
}

export { openModuleWizard };
