import { api } from '../api/client.js';
import { has } from '../core/permissions.js';
import { esc } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';
import { header, loading, toast } from '../ui/feedback.js';

const SEVERITY = {
    Error: ['System error', 'danger'],
    Warning: ['User / rule issue', 'warning'],
    Slow: ['Slow response', 'info'],
};
const HEALTH_BADGE = { OK: 'success', Warning: 'warning', Down: 'danger' };
const PAGE_SIZE = 25;

const ui = {
    tab: 'overview',
    hours: 24,
    search: { page: 1 },
    audit: { page: 1 },
};

/**
 * Format a UTC timestamp from the API in the viewer's local time.
 * @param {string} value - ISO timestamp.
 * @returns {string} Local date and time, or an empty string.
 */
const when = (value) => (value ? new Date(value).toLocaleString() : '');

/**
 * Render a severity as a plain-language coloured badge.
 * @param {string} severity - Error, Warning or Slow.
 * @returns {string} Badge markup.
 */
const severityBadge = (severity) => {
    const [label, color] = SEVERITY[severity] || [severity, 'secondary'];
    return `<span class="badge text-bg-${color}">${esc(label)}</span>`;
};

/**
 * Build the ISO value for a datetime-local control.
 * @param {string} value - Control value in the browser's local time.
 * @returns {string|undefined} UTC ISO text, or undefined when empty.
 */
const toIso = (value) => (value ? new Date(value).toISOString() : undefined);

/**
 * Build a query string from the non-empty entries of an object.
 * @param {object} filters - Filter names and values.
 * @returns {string} URL-encoded query string without the leading question mark.
 */
const query = (filters) =>
    Object.entries(filters)
        .filter(([, v]) => v !== undefined && v !== null && String(v).trim() !== '')
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v).trim())}`)
        .join('&');

/**
 * Create or reuse the detail dialog.
 * @returns {{element: object, modal: object}} The jQuery element and its Bootstrap modal.
 */
function detailModal() {
    if (!$('#diagDetailModal').length) {
        $('body').append(`<div class="modal fade" id="diagDetailModal" tabindex="-1" aria-labelledby="diagDetailTitle" aria-hidden="true">
          <div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
            <div class="modal-header"><h2 class="modal-title h5" id="diagDetailTitle">Problem details</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body"></div><div class="modal-footer"></div>
          </div></div></div>`);
    }
    const element = $('#diagDetailModal');
    return { element, modal: bootstrap.Modal.getOrCreateInstance(element[0]) };
}

/**
 * Summarise one problem as text that can be pasted into an email or ticket.
 * @param {object} e - Problem record from the API.
 * @returns {string} Plain-text summary.
 */
function shareText(e) {
    return [
        `CATS Reference ID: ${e.requestId}`,
        `When: ${when(e.occurredAtUtc)}`,
        `User: ${e.userName || 'not signed in'}${e.roleCode ? ` (${e.roleCode})` : ''}`,
        `Module: ${e.moduleLabel}`,
        `Request: ${e.method} ${e.path} -> ${e.statusCode} in ${e.durationMs} ms`,
        `Problem: ${e.category} - ${e.whatHappened}`,
        e.message ? `Message: ${e.message}` : '',
        `Release: ${e.releaseVersion || ''}`,
    ]
        .filter(Boolean)
        .join('\n');
}

/**
 * Open the plain-language explanation for a Reference ID.
 * @param {string} requestId - Reference ID quoted by the user.
 * @returns {Promise<void>} Resolves when the dialog is shown.
 */
async function openDetail(requestId) {
    const items = await api(`/api/diagnostics/events/${encodeURIComponent(requestId)}`);
    const e = items[0];
    const { element, modal } = detailModal();
    element.find('.modal-title').text(`Reference ID ${e.requestId}`);
    element.find('.modal-body').html(`<div class="d-flex flex-wrap gap-2 align-items-center mb-3">${severityBadge(e.severity)}<span class="badge text-bg-light border">${esc(e.category)}</span><span class="text-secondary small">${esc(when(e.occurredAtUtc))} · ${esc(e.moduleLabel)}</span></div>
        <div class="row g-3 mb-3">
          <div class="col-md-6"><div class="card h-100"><div class="card-body"><div class="small text-uppercase text-secondary fw-semibold">What happened</div><p class="mb-0">${esc(e.whatHappened)}</p>${e.message ? `<p class="mt-2 mb-0 small"><span class="text-secondary">System message:</span> ${esc(e.message)}</p>` : ''}</div></div></div>
          <div class="col-md-6"><div class="card h-100"><div class="card-body"><div class="small text-uppercase text-secondary fw-semibold">Most likely cause</div><p class="mb-0">${esc(e.likelyCause)}</p></div></div></div>
          <div class="col-12"><div class="card border-primary"><div class="card-body"><div class="small text-uppercase text-primary fw-semibold">What to do · ${esc(e.owner)}</div><p class="mb-0">${esc(e.whatToDo)}</p></div></div></div>
        </div>
        <dl class="row small mb-2">
          <dt class="col-sm-3">User</dt><dd class="col-sm-9">${esc(e.userName || 'Not signed in')}${e.roleCode ? ` <span class="text-secondary">(${esc(e.roleCode)})</span>` : ''}</dd>
          <dt class="col-sm-3">Request</dt><dd class="col-sm-9"><code>${esc(e.method)} ${esc(e.path)}</code> → <strong>${e.statusCode}</strong> in ${e.durationMs} ms</dd>
          <dt class="col-sm-3">From address</dt><dd class="col-sm-9">${esc(e.ipAddress || '')}</dd>
          <dt class="col-sm-3">Release</dt><dd class="col-sm-9">${esc(e.releaseVersion || '')}</dd>
          ${e.exceptionType ? `<dt class="col-sm-3">Technical type</dt><dd class="col-sm-9"><code>${esc(e.exceptionType)}</code></dd>` : ''}
        </dl>
        ${e.stackTrace ? `<details class="mt-2"><summary class="small fw-semibold">Technical detail for IT / Developer</summary><pre class="small bg-light border rounded p-2 mt-2 diag-stack">${esc(e.stackTrace)}</pre></details>` : ''}`);
    element.find('.modal-footer').html(
        `<button type="button" class="btn btn-outline-primary diag-copy">Copy summary</button>${e.userName ? '<button type="button" class="btn btn-outline-primary diag-user-activity">Show this user\'s activity</button>' : ''}<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>`,
    );
    element.off('click.diag');
    element.on('click.diag', '.diag-copy', guardEvent(async () => {
        await navigator.clipboard.writeText(shareText(e));
        toast('Summary copied');
    }));
    element.on('click.diag', '.diag-user-activity', guardEvent(async () => {
        modal.hide();
        ui.audit = { page: 1, user: e.userName };
        await showTab('audit');
    }));
    modal.show();
}

/**
 * Show a bar for each time bucket, stacked by severity.
 * @param {object[]} trend - Counts per time bucket.
 * @param {number} hours - Selected period.
 * @returns {string} Chart markup.
 */
function trendChart(trend, hours) {
    const max = Math.max(1, ...trend.map((t) => t.errors + t.warnings + t.slow));
    const bars = trend
        .map((t) => {
            const part = (n, color) => (n ? `<div class="bg-${color}" style="height:${(n / max) * 100}%"></div>` : '');
            const label = hours <= 48 ? new Date(t.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : new Date(t.at).toLocaleDateString();
            return `<div class="flex-fill d-flex flex-column justify-content-end" style="min-width:6px;height:100%" title="${esc(label)}: ${t.errors} system errors, ${t.warnings} user/rule issues, ${t.slow} slow">${part(t.slow, 'info')}${part(t.warnings, 'warning')}${part(t.errors, 'danger')}</div>`;
        })
        .join('');
    return `<div class="d-flex align-items-end gap-1 border-bottom" style="height:90px" role="img" aria-label="Problems over time">${bars}</div><div class="small text-secondary mt-1"><span class="text-danger">■</span> System error <span class="text-warning ms-2">■</span> User / rule issue <span class="text-info ms-2">■</span> Slow</div>`;
}

/**
 * Render the overview: health, headline counts, repeated issues and per-module behaviour.
 * @returns {Promise<void>} Resolves when the tab is drawn.
 */
async function renderOverview() {
    const s = await api(`/api/diagnostics/summary?hours=${ui.hours}`);
    const t = s.totals || { total: 0, errors: 0, warnings: 0, slow: 0, usersAffected: 0 };
    const card = (label, value, hint, color) =>
        `<div class="col-6 col-lg-3"><div class="card h-100 border-${color}"><div class="card-body"><div class="small text-secondary">${label}</div><div class="display-6 fw-semibold text-${color}">${value}</div><div class="small text-secondary">${hint}</div></div></div></div>`;
    const status = t.errors > 0 ? ['Attention needed', 'danger'] : t.warnings + t.slow > 0 ? ['Working, with minor issues', 'warning'] : ['All clear', 'success'];
    const health = s.health
        .map(
            (h) =>
                `<div class="col-6 col-lg-3"><div class="card h-100"><div class="card-body py-2"><div class="d-flex justify-content-between align-items-center"><span class="fw-semibold">${esc(h.name)}</span><span class="badge text-bg-${HEALTH_BADGE[h.status] || 'secondary'}">${esc(h.status)}</span></div><div class="small">${esc(h.detail)}</div><div class="small text-secondary">${esc(h.help)}</div></div></div></div>`,
        )
        .join('');
    const issues = s.topIssues
        .map(
            (i) =>
                `<tr><td><div class="fw-semibold">${esc(i.category)}</div><div class="small text-secondary">${esc(i.moduleLabel)} · HTTP ${i.statusCode}</div></td><td class="small">${esc(i.whatToDo)}</td><td>${esc(i.owner)}</td><td class="text-end">${i.occurrences}</td><td class="text-end">${i.users}</td><td class="small">${esc(when(i.lastSeen))}</td><td class="text-end"><button type="button" class="btn btn-sm btn-outline-primary diag-open" data-request="${esc(i.sampleRequestId)}">Example</button></td></tr>`,
        )
        .join('');
    const modules = s.byModule
        .map((m) => {
            const live = s.live.find((l) => l.module === m.module);
            return `<tr><td>${esc(m.label)}</td><td class="text-end">${m.errors}</td><td class="text-end">${m.warnings}</td><td class="text-end">${m.slow}</td><td class="text-end">${live ? `${live.requests}` : '-'}</td><td class="text-end">${live ? `${live.p95Ms} ms` : '-'}</td><td class="text-end"><button type="button" class="btn btn-sm btn-outline-secondary diag-module" data-module="${esc(m.module)}">View</button></td></tr>`;
        })
        .join('');
    const r = s.release;
    $('#diagBody').html(`
      <div class="d-flex flex-wrap align-items-center gap-2 mb-3"><span class="badge text-bg-${status[1]} fs-6">${status[0]}</span>
        <label class="ms-auto small text-secondary" for="diagHours">Period</label>
        <select id="diagHours" class="form-select form-select-sm w-auto">${[[1, 'Last hour'], [24, 'Last 24 hours'], [168, 'Last 7 days'], [720, 'Last 30 days']].map(([v, l]) => `<option value="${v}" ${Number(ui.hours) === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <button type="button" class="btn btn-sm btn-outline-secondary" id="diagRefresh">Refresh</button></div>
      <div class="row g-3 mb-3">
        ${card('System errors', t.errors, 'Something broke; IT needs to look', t.errors ? 'danger' : 'success')}
        ${card('User / rule issues', t.warnings, 'Access denied, invalid input, record not found', t.warnings ? 'warning' : 'success')}
        ${card('Slow responses', t.slow, `Took over ${r.slowThresholdMs / 1000} seconds`, t.slow ? 'info' : 'success')}
        ${card('Users affected', t.usersAffected, 'Different people who saw a problem', 'secondary')}
      </div>
      <div class="card mb-3"><div class="card-header bg-white fw-semibold">Problems over time</div><div class="card-body">${trendChart(s.trend, s.hours)}</div></div>
      <h2 class="h6 text-uppercase text-secondary">System health</h2><div class="row g-3 mb-3">${health}</div>
      <div class="card mb-3"><div class="card-header bg-white fw-semibold">Most repeated problems</div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Problem</th><th>What to do</th><th>Who acts</th><th class="text-end">Times</th><th class="text-end">Users</th><th>Last seen</th><th></th></tr></thead><tbody>${issues || '<tr><td colspan="7" class="text-center text-secondary py-4">No problems recorded in this period.</td></tr>'}</tbody></table></div></div>
      <div class="card mb-3"><div class="card-header bg-white fw-semibold">By module</div><div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Module</th><th class="text-end">System errors</th><th class="text-end">User / rule issues</th><th class="text-end">Slow</th><th class="text-end" title="Since the API last started">Requests (live)</th><th class="text-end" title="95% of requests were faster than this (since the API last started)">Speed p95 (live)</th><th></th></tr></thead><tbody>${modules || '<tr><td colspan="7" class="text-center text-secondary py-4">Nothing to show.</td></tr>'}</tbody></table></div></div>
      <div class="card"><div class="card-header bg-white fw-semibold">Release and environment</div><div class="card-body small"><div class="row g-2"><div class="col-md-3"><span class="text-secondary">Version</span><br><strong>${esc(r.version)}</strong></div><div class="col-md-3"><span class="text-secondary">Built</span><br>${esc(when(r.builtAtUtc))}</div><div class="col-md-3"><span class="text-secondary">API running since</span><br>${esc(when(r.startedAtUtc))}</div><div class="col-md-3"><span class="text-secondary">Environment</span><br>${esc(r.environment)} · ${esc(r.database)} · ${esc(r.machine)}</div></div><div class="text-secondary mt-2">Live request counts and speeds reset when the API restarts; recorded problems are kept for 90 days.</div></div></div>`);
}

/**
 * Draw the search form and results for recorded problems.
 * @returns {Promise<void>} Resolves when the tab is drawn.
 */
async function renderSearch() {
    const f = ui.search;
    const filters = await api('/api/diagnostics/filters');
    $('#diagBody').html(`
      <form id="diagSearchForm" class="card card-body mb-3"><div class="row g-2 align-items-end">
        <div class="col-md-3"><label class="form-label small mb-1" for="dsRequest">Reference ID</label><input id="dsRequest" class="form-control form-control-sm" value="${esc(f.requestId || '')}" placeholder="From the error message"></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="dsUser">User</label><input id="dsUser" class="form-control form-control-sm" value="${esc(f.user || '')}" placeholder="User name contains"></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="dsModule">Module</label><select id="dsModule" class="form-select form-select-sm"><option value="">All modules</option>${filters.modules.map((m) => `<option value="${esc(m.value)}" ${f.module === m.value ? 'selected' : ''}>${esc(m.label)}</option>`).join('')}</select></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="dsSeverity">Type</label><select id="dsSeverity" class="form-select form-select-sm"><option value="">All types</option>${Object.entries(SEVERITY).map(([k, [label]]) => `<option value="${k}" ${f.severity === k ? 'selected' : ''}>${label}</option>`).join('')}</select></div>
        <div class="col-md-2"><label class="form-label small mb-1" for="dsStatus">HTTP status</label><input id="dsStatus" type="number" class="form-control form-control-sm" value="${esc(f.status || '')}" placeholder="e.g. 500"></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="dsFrom">From</label><input id="dsFrom" type="datetime-local" class="form-control form-control-sm" value="${esc(f.fromLocal || '')}"></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="dsTo">To</label><input id="dsTo" type="datetime-local" class="form-control form-control-sm" value="${esc(f.toLocal || '')}"></div>
        <div class="col-md-4 d-flex gap-2"><button class="btn btn-primary btn-sm">Search</button><button type="button" class="btn btn-outline-secondary btn-sm" id="diagSearchClear">Clear</button></div>
      </div></form><div id="diagResults"></div>`);
    await loadSearch();
}

/**
 * Query recorded problems with the current filters and draw the results table.
 * @returns {Promise<void>} Resolves when results are drawn.
 */
async function loadSearch() {
    const f = ui.search;
    const data = await api(
        `/api/diagnostics/events?${query({ requestId: f.requestId, user: f.user, module: f.module, severity: f.severity, status: f.status, from: toIso(f.fromLocal), to: toIso(f.toLocal), page: f.page, pageSize: PAGE_SIZE })}`,
    );
    const rows = data.items
        .map(
            (e) =>
                `<tr><td class="small text-nowrap">${esc(when(e.occurredAtUtc))}</td><td><code class="small">${esc(e.requestId)}</code></td><td>${esc(e.userName || '-')}</td><td>${esc(e.moduleLabel)}</td><td>${severityBadge(e.severity)}<div class="small">${esc(e.category)}</div></td><td>${e.statusCode}</td><td class="text-end">${e.durationMs} ms</td><td class="text-end"><button type="button" class="btn btn-sm btn-outline-primary diag-open" data-request="${esc(e.requestId)}">Explain</button></td></tr>`,
        )
        .join('');
    $('#diagResults').html(`<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>When</th><th>Reference ID</th><th>User</th><th>Module</th><th>Problem</th><th>Status</th><th class="text-end">Time</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="8" class="text-center text-secondary py-4">No problems match these filters.</td></tr>'}</tbody></table></div>${pager(data, 'search')}</div>`);
}

/**
 * Render previous/next controls.
 * @param {{total: number, page: number, pageSize: number}} data - Paged result.
 * @param {string} target - Which list the buttons page.
 * @returns {string} Pager markup.
 */
function pager(data, target) {
    const pages = Math.max(1, Math.ceil(data.total / data.pageSize));
    return `<div class="card-footer bg-white d-flex justify-content-between align-items-center small"><span>${data.total.toLocaleString()} result(s) · page ${data.page} of ${pages}</span><span><button type="button" class="btn btn-sm btn-outline-secondary diag-page" data-target="${target}" data-page="${data.page - 1}" ${data.page <= 1 ? 'disabled' : ''}>Previous</button> <button type="button" class="btn btn-sm btn-outline-secondary diag-page" data-target="${target}" data-page="${data.page + 1}" ${data.page >= pages ? 'disabled' : ''}>Next</button></span></div>`;
}

/**
 * Draw the data-change history (who did what to which record).
 * @returns {Promise<void>} Resolves when the tab is drawn.
 */
async function renderAudit() {
    const f = ui.audit;
    const filters = await api('/api/diagnostics/filters');
    $('#diagBody').html(`
      <div class="alert alert-light border small">Who did what, and when. Use it to understand how a record reached its current state. Customer data values are not shown here.</div>
      <form id="diagAuditForm" class="card card-body mb-3"><div class="row g-2 align-items-end">
        <div class="col-md-3"><label class="form-label small mb-1" for="daUser">User</label><input id="daUser" class="form-control form-control-sm" value="${esc(f.user || '')}"></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="daAction">Action</label><input id="daAction" class="form-control form-control-sm" value="${esc(f.action || '')}" placeholder="e.g. LOGIN_FAILED"></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="daEntity">Record type</label><select id="daEntity" class="form-select form-select-sm"><option value="">All</option>${filters.entityTypes.map((x) => `<option ${f.entityType === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="daAlert">Alert id</label><input id="daAlert" class="form-control form-control-sm" inputmode="numeric" value="${esc(f.alertId || '')}"></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="daFrom">From</label><input id="daFrom" type="datetime-local" class="form-control form-control-sm" value="${esc(f.fromLocal || '')}"></div>
        <div class="col-md-3"><label class="form-label small mb-1" for="daTo">To</label><input id="daTo" type="datetime-local" class="form-control form-control-sm" value="${esc(f.toLocal || '')}"></div>
        <div class="col-md-4 d-flex gap-2"><button class="btn btn-primary btn-sm">Search</button><button type="button" class="btn btn-outline-secondary btn-sm" id="diagAuditClear">Clear</button></div>
      </div></form><div id="diagResults"></div>`);
    await loadAudit();
}

/**
 * Query the audit history with the current filters and draw the table.
 * @returns {Promise<void>} Resolves when results are drawn.
 */
async function loadAudit() {
    const f = ui.audit;
    const data = await api(
        `/api/diagnostics/audit?${query({ user: f.user, action: f.action, entityType: f.entityType, alertId: f.alertId, from: toIso(f.fromLocal), to: toIso(f.toLocal), page: f.page, pageSize: PAGE_SIZE })}`,
    );
    const rows = data.items
        .map(
            (a) =>
                `<tr><td class="small text-nowrap">${esc(when(a.createdAtUtc))}</td><td>${esc(a.userName)}<div class="small text-secondary">${esc(a.roleCode)}</div></td><td><code class="small">${esc(a.action)}</code></td><td>${esc(a.entityType)}${a.alertId ? `<div class="small text-secondary">Alert ${esc(a.alertId)}</div>` : ''}</td><td class="small">${esc(a.remarks || '')}</td><td class="small">${esc(a.ipAddress || '')}</td></tr>`,
        )
        .join('');
    $('#diagResults').html(`<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>When</th><th>User</th><th>Action</th><th>Record</th><th>Remarks</th><th>From address</th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="text-center text-secondary py-4">No history matches these filters.</td></tr>'}</tbody></table></div>${pager(data, 'audit')}</div>`);
}

/** @returns {void} Draws the how-to guide. */
function renderGuide() {
    const row = (badge, what, who, todo) => `<tr><td>${badge}</td><td>${what}</td><td>${who}</td><td>${todo}</td></tr>`;
    $('#diagBody').html(`
      <div class="card mb-3"><div class="card-body"><h2 class="h6">How to use this screen</h2><ol class="mb-0">
        <li>When something goes wrong, the screen shows a message ending with <strong>(Reference ID: …)</strong>. Ask the user to send you that ID.</li>
        <li>Paste it in <em>Find a Reference ID</em> at the top. You see what happened, the likely cause and what to do, in plain words.</li>
        <li>No ID? Use <em>Search problems</em> by user, module or time, or <em>Data audit</em> to see who changed a record.</li>
        <li>Press <em>Copy summary</em> to send the facts to IT/Developer; Admin users also see the technical detail.</li>
      </ol></div></div>
      <div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Type</th><th>Meaning</th><th>Who usually acts</th><th>Typical action</th></tr></thead><tbody>
        ${row(severityBadge('Error'), 'The system failed unexpectedly (HTTP 5xx).', 'IT / Developer', 'Send the Reference ID; check database and release.')}
        ${row(severityBadge('Warning'), 'The system refused a request: not allowed, invalid data, record not found or wrong state (HTTP 4xx).', 'Center / Admin / the user', 'Read the explanation; fix permissions or data.')}
        ${row(severityBadge('Slow'), `The request worked but took more than ${3} seconds.`, 'IT / Support', 'Only act if it repeats for the same module.')}
      </tbody></table></div></div>`);
}

/**
 * Switch tab and draw it.
 * @param {string} tab - overview, search, audit or guide.
 * @returns {Promise<void>} Resolves when the tab is drawn.
 */
async function showTab(tab) {
    ui.tab = tab;
    $('#diagTabs .nav-link').removeClass('active').filter(`[data-tab="${tab}"]`).addClass('active');
    $('#diagBody').html('<div class="text-center text-secondary py-5">Loading…</div>');
    if (tab === 'overview') await renderOverview();
    else if (tab === 'search') await renderSearch();
    else if (tab === 'audit') await renderAudit();
    else renderGuide();
}

/**
 * Read the search form into the stored filter state.
 * @returns {void}
 */
function readSearchForm() {
    ui.search = {
        page: 1,
        requestId: $('#dsRequest').val(),
        user: $('#dsUser').val(),
        module: $('#dsModule').val(),
        severity: $('#dsSeverity').val(),
        status: $('#dsStatus').val(),
        fromLocal: $('#dsFrom').val(),
        toLocal: $('#dsTo').val(),
    };
}

/**
 * Read the audit form into the stored filter state.
 * @returns {void}
 */
function readAuditForm() {
    ui.audit = {
        page: 1,
        user: $('#daUser').val(),
        action: $('#daAction').val(),
        entityType: $('#daEntity').val(),
        alertId: $('#daAlert').val(),
        fromLocal: $('#daFrom').val(),
        toLocal: $('#daTo').val(),
    };
}

/**
 * Attach the screen's delegated handlers once per render.
 * @returns {void}
 */
function bind() {
    const host = $('#viewHost');
    host.off('.diag');
    host.on('click.diag', '#diagTabs .nav-link', guardEvent(async function () {
        await showTab(String($(this).data('tab')));
    }));
    host.on('submit.diag', '#diagFinder', guardEvent(async (event) => {
        event.preventDefault();
        const id = String($('#diagFinderInput').val() || '').trim();
        if (id) await openDetail(id);
    }));
    host.on('click.diag', '.diag-open', guardEvent(async function () {
        await openDetail(String($(this).data('request')));
    }));
    host.on('click.diag', '.diag-module', guardEvent(async function () {
        ui.search = { page: 1, module: String($(this).data('module')) };
        await showTab('search');
    }));
    host.on('change.diag', '#diagHours', guardEvent(async function () {
        ui.hours = Number($(this).val());
        await renderOverview();
    }));
    host.on('click.diag', '#diagRefresh', guardEvent(() => showTab(ui.tab)));
    host.on('submit.diag', '#diagSearchForm', guardEvent(async (event) => {
        event.preventDefault();
        readSearchForm();
        await loadSearch();
    }));
    host.on('click.diag', '#diagSearchClear', guardEvent(async () => {
        ui.search = { page: 1 };
        await renderSearch();
    }));
    host.on('submit.diag', '#diagAuditForm', guardEvent(async (event) => {
        event.preventDefault();
        readAuditForm();
        await loadAudit();
    }));
    host.on('click.diag', '#diagAuditClear', guardEvent(async () => {
        ui.audit = { page: 1 };
        await renderAudit();
    }));
    host.on('click.diag', '.diag-page', guardEvent(async function () {
        const page = Number($(this).data('page'));
        if ($(this).data('target') === 'audit') {
            ui.audit.page = page;
            await loadAudit();
        } else {
            ui.search.page = page;
            await loadSearch();
        }
    }));
}

/**
 * Render the monitoring and troubleshooting screen for Center and Admin users.
 * @returns {Promise<void>} Resolves after the first tab is drawn; failures propagate to the caller.
 */
export async function renderDiagnostics() {
    if (!has('DIAGNOSTICS.VIEW')) throw new Error('Monitoring permission is required.');
    header('Monitoring & Troubleshooting', 'See what went wrong, for whom, why and what to do next');
    loading();
    $('#viewHost').html(`
      <form id="diagFinder" class="input-group mb-3" role="search"><span class="input-group-text">Find a Reference ID</span><input id="diagFinderInput" class="form-control" placeholder="Paste the Reference ID from the user's error message" aria-label="Reference ID"><button class="btn btn-primary">Explain</button></form>
      <ul class="nav nav-tabs mb-3" id="diagTabs">
        ${[['overview', 'Overview'], ['search', 'Search problems'], ['audit', 'Data audit'], ['guide', 'How to read this']].map(([k, l]) => `<li class="nav-item"><button type="button" class="nav-link ${ui.tab === k ? 'active' : ''}" data-tab="${k}">${l}</button></li>`).join('')}
      </ul><div id="diagBody"></div>`);
    bind();
    await showTab(ui.tab);
}
