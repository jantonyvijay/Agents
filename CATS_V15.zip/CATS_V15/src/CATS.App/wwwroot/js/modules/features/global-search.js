import { api } from '../api/client.js';
import { loadTemplates } from '../api/catalogs.js';
import { navigate } from '../core/navigation.js';
import { state } from '../core/state.js';
import { localStore } from '../core/storage.js';
import { accessibleNavigationItems } from '../ui/top-navigation.js';
import { esc, json } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';

const recentKey = 'cats_global_search_recent';
const maxRecent = 15;

function scopedRecentKey() {
    const user = state.user || {};
    const identity = user.id || user.userName || 'anonymous';
    const role = user.roleCode || 'no-role';
    return `${recentKey}:${encodeURIComponent(`${identity}:${role}`)}`;
}

function recentAlerts() {
    localStore.removeItem(recentKey);
    return json(localStore.getItem(scopedRecentKey()) || '[]', []).filter((item) => item?.id && item?.alertNo);
}

function clearRecentAlerts() {
    localStore.removeItem(scopedRecentKey());
}

function forgetAlert(alertId) {
    localStore.setItem(
        scopedRecentKey(),
        JSON.stringify(recentAlerts().filter((item) => item.id !== alertId)),
    );
}

function rememberAlert(alert) {
    const item = {
        id: alert.id,
        alertNo: alert.alertNo,
        title: alert.templateName || alert.alertType || 'Alert',
        alertType: alert.alertType || '',
        status: alert.status || '',
        viewedAt: Date.now(),
    };
    localStore.setItem(
        scopedRecentKey(),
        JSON.stringify([item, ...recentAlerts().filter((entry) => entry.id !== item.id)].slice(0, maxRecent)),
    );
}

function initializeGlobalSearch() {
    const input = $('#globalSearchInput');
    const panel = $('#globalSearchPanel');
    if (!input.length || !panel.length || input.data('global-search-bound')) return;
    input.data('global-search-bound', true);
    let activeIndex = -1;
    let results = [];
    let requestId = 0;

    const close = () => {
        panel.addClass('d-none').empty();
        input.attr('aria-expanded', 'false');
        activeIndex = -1;
        results = [];
    };
    const openResult = (result) => {
        close();
        if (result.kind === 'alert') {
            rememberAlert(result);
            navigate('detail', result.id);
        } else if (result.kind === 'project') {
            state.alertFilter = { page: 1, pageSize: 20, templateId: result.id };
            navigate('alerts', state.alertFilter);
        } else navigate(result.view);
    };
    const render = (query, alerts = []) => {
        const q = String(query || '').trim().toLowerCase();
        const projects = state.templates
            .filter((template) => template.status === 'Published' && (!q || `${template.code} ${template.name}`.toLowerCase().includes(q)))
            .map((template) => ({ kind: 'project', id: template.id, title: template.name, subtitle: `Alert type · ${template.code}` }));
        const modules = accessibleNavigationItems()
            .filter((item) => !q || `${item.label} ${item.category} ${item.description}`.toLowerCase().includes(q))
            .map((item) => ({
                kind: 'module',
                view: item.view,
                title: item.label,
                subtitle: [item.category, item.description].filter(Boolean).join(' · ') || 'Application module',
            }));
        const recent = recentAlerts().map((alert) => ({
            kind: 'alert',
            ...alert,
            subtitle: `${alert.title} · ${alert.status}`,
        }));
        results = q
            ? [
                  ...alerts.map((alert) => ({
                      kind: 'alert',
                      ...alert,
                      title: alert.alertNo,
                      subtitle: `${alert.templateName} · ${alert.status}`,
                  })),
                  ...projects,
                  ...modules,
              ]
            : [...recent, ...modules];
        activeIndex = results.length ? 0 : -1;
        const rows = results
            .map((result, index) => `<button type="button" class="cats-global-result ${index === activeIndex ? 'is-active' : ''}" data-index="${index}">
                <span class="cats-global-result-icon">${result.kind === 'alert' ? '!' : result.kind === 'project' ? '#' : '›'}</span>
                <span><strong>${esc(result.title)}</strong><small>${esc(result.subtitle || '')}</small></span></button>`)
            .join('');
        const clearRecent = !q && recent.length
            ? '<button type="button" id="globalSearchClearRecent" class="btn btn-link btn-sm p-0">Clear recent</button>'
            : '';
        panel.html(`<div class="cats-global-search-tabs"><span class="active">${q ? 'Results' : 'Recently viewed and available modules'}</span><span>${results.filter((result) => result.kind === 'alert').length} alerts · ${results.filter((result) => result.kind === 'module').length} modules ${clearRecent}</span></div>
            <div class="cats-global-results">${rows || '<div class="text-secondary small p-3">No matching records you can access.</div>'}</div>
            <button type="button" id="globalSearchViewAll" class="btn btn-link btn-sm w-100 text-start">View all alert results</button>`);
        panel.removeClass('d-none');
        input.attr('aria-expanded', 'true');
    };
    const search = async () => {
        await loadTemplates();
        const query = String(input.val() || '').trim();
        const currentRequest = ++requestId;
        if (!query) {
            render('', []);
            return;
        }
        const responses = await Promise.all([
            api(`/api/alerts?${new URLSearchParams({ search: query, page: '1', pageSize: '20' })}`),
        ]);
        if (currentRequest !== requestId) return;
        const seen = new Set();
        const alerts = responses.flatMap((response) => response.data || []).filter((alert) => !seen.has(alert.id) && seen.add(alert.id));
        render(query, alerts);
    };
    let timer;
    input.on('focus', guardEvent(() => search().catch(() => close())));
    input.on('input', guardEvent(() => {
        clearTimeout(timer);
        timer = setTimeout(() => search().catch(() => close()), 200);
    }));
    input.on('keydown', guardEvent((event) => {
        if (event.key === 'Escape') {
            close();
            input.trigger('blur');
            return;
        }
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            if (!results.length) return;
            activeIndex = (activeIndex + (event.key === 'ArrowDown' ? 1 : results.length - 1)) % results.length;
            panel.find('.cats-global-result').removeClass('is-active').eq(activeIndex).addClass('is-active');
        }
        if (event.key === 'Enter' && activeIndex >= 0) {
            event.preventDefault();
            openResult(results[activeIndex]);
        }
    }));
    panel.on('click', '.cats-global-result', guardEvent(function () { openResult(results[Number($(this).data('index'))]); }));
    panel.on('click', '#globalSearchClearRecent', guardEvent(() => {
        clearRecentAlerts();
        render('', []);
    }));
    panel.on('click', '#globalSearchViewAll', guardEvent(() => {
        state.alertFilter = { page: 1, pageSize: 20, search: String(input.val() || '') };
        close();
        navigate('alerts', state.alertFilter);
    }));
    $(document).on('pointerdown', (event) => { if (!$(event.target).closest('#globalSearch').length) close(); });
    $(document).on('show.bs.modal', close);
    document.addEventListener('cats:alert-opened', (event) => rememberAlert(event.detail));
    document.addEventListener('cats:alert-access-denied', (event) => forgetAlert(event.detail.id));
}

export { initializeGlobalSearch };
