import { fresh, fromRecord, normalizeField } from '../business/template-drafts.js';
import { has } from '../core/permissions.js';
import { loadTemplates, loadAlertColumns, loadRoles } from '../api/catalogs.js';
import { header, toast } from '../ui/feedback.js';
import { state } from '../core/state.js';
import { esc, uid, json } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';
import { hideAssignmentRulesJson, enhanceDesignerActions } from '../ui/enhancements.js';
import { api } from '../api/client.js';
import { showTemplateAudit } from '../ui/template-audit.js';
import { showTemplatePreview } from '../ui/template-preview.js';
import { showTemplateChildModal } from '../ui/modals.js';
import { organizeTemplateEditor, resetTemplateTabs } from '../ui/template-wizard.js';
import { CHOICE_TYPES, fieldCodeFromLabel } from '../business/template-logic.js';
import { openModuleWizard } from './module-wizard.js';

/**
 * Show only the length, numeric, choice, and validation settings applicable to the field type.
 * @returns {void} Updates the relevant UI or state.
 */
function updateFieldLimitVisibility() {
    const type = String($('#fieldType').val() || 'text').toLowerCase();
    const text = type === 'text' || type === 'textarea' || type === 'email' || type === 'tel';
    const number = type === 'number' || type === 'amount';
    const choice = ['select', 'multiselect', 'checkboxlist', 'radio'].includes(type);
    const required = $('#fieldRequired').is(':checked');
    $('#fieldMinLength,#fieldMaxLength')
        .prop('disabled', !text)
        .parent()
        .toggleClass('d-none', !text)
        .prop('hidden', !text);
    $('#fieldMinValue,#fieldMaxValue')
        .prop('disabled', !number)
        .parent()
        .toggleClass('d-none', !number)
        .prop('hidden', !number);
    $('#fieldChoiceOptionsGroup').toggleClass('d-none', !choice).prop('hidden', !choice);
    $('#fieldRequiredValidationOptions').toggleClass('d-none', !required).prop('hidden', !required);
    $('#fieldValidationPattern,#fieldCustomError').prop('disabled', !required);
}

/**
 * Load and render the template designer screen, then initialize its controls and event handlers.
 * @param {*} [preserveDraft] - Whether to keep the current draft when refreshing the designer.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderTemplateDesigner(preserveDraft = false) {
    if (!has('TEMPLATE.MANAGE')) throw new Error('Template management permission is required.');
    await loadTemplates(true);
    await loadAlertColumns();
    await loadRoles().catch(() => []);
    header('Template Designer', '');
    const templateRows = state.templates
        .map(
            (t) =>
                `<tr class="td-list-row" data-search="${esc(`${t.name} ${t.code}`)}" data-status="${esc(t.status)}"><td><div class="fw-semibold">${esc(t.name)}</div><div class="small text-secondary">${esc(t.code)}</div></td><td><span class="badge text-bg-${t.status === 'Published' ? 'success' : t.status === 'Retired' ? 'secondary' : 'warning'}">${esc(t.status)}</span></td><td class="text-end"><button class="btn btn-sm btn-outline-primary td-edit" data-id="${esc(t.id)}" title="Edit template" aria-label="Edit ${esc(t.name)}">&#9998;</button> <button type="button" class="btn btn-sm btn-outline-secondary td-audit" data-id="${esc(t.id)}" title="View audit log" aria-label="View audit log for ${esc(t.name)}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 11a9 9 0 1 1 2.5 7M3 4v7h7"/><path d="M12 7v5l3 2"/></svg></button></td></tr>`,
        )
        .join('');
    $('#viewHost').html(
        `<div class="card mb-3"><div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2"><span class="fw-semibold">Templates</span><div class="d-flex gap-2">${has('WORKFLOW.MANAGE') ? '<button id="tdModuleWizard" class="btn btn-sm btn-outline-primary" title="Create a template, its approval flow and access in one guided flow">New Module (guided)</button>' : ''}<button id="tdNew" class="btn btn-sm btn-primary">+ Add Template</button></div></div><div class="card-body border-bottom"><div class="row g-2"><div class="col-md-8"><label class="visually-hidden" for="tdListSearch">Search templates</label><input id="tdListSearch" class="form-control" placeholder="Search template name or code" /></div><div class="col-md-4"><label class="visually-hidden" for="tdListStatus">Template status</label><select id="tdListStatus" class="form-select"><option value="">All statuses</option><option>Draft</option><option>Published</option><option>Retired</option></select></div></div></div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Template</th><th>Status</th><th class="text-end">Actions</th></tr></thead><tbody>${templateRows || '<tr><td colspan="3" class="text-center text-secondary py-4">No templates found.</td></tr>'}</tbody></table></div></div><div id="tdControls" class="d-none"><select id="tdSelect"><option value=""></option>${state.templates.map((t) => `<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select><button id="tdLoad" type="button"></button></div><div id="tdEditor"></div>`,
    );
    /**
     * Filter template rows by the current text and status selections.
     * @returns {void} Updates the relevant UI or state.
     */
    $('.td-audit').on('click', guardEvent(function () {
        const template = state.templates.find((t) => t.id === String($(this).data('id')));
        if (template) showTemplateAudit(template);
    }));
    const filterTemplates = () => {
        const search = String($('#tdListSearch').val() || '').toLowerCase(),
            status = $('#tdListStatus').val();
        $('.td-list-row').each(function () {
            const row = $(this);
            row.toggle(
                String(row.data('search')).toLowerCase().includes(search) && (!status || row.data('status') === status),
            );
        });
    };
    $('#tdListSearch,#tdListStatus').on('input change', guardEvent(filterTemplates));
    $('#templateDesignerModal .modal-body').empty().append($('#tdEditor'));
    $('#templateDesignerModal')
        .off('show.bs.modal.hideRawJson')
        .on(
            'show.bs.modal.hideRawJson',
            guardEvent(function () {
                hideAssignmentRulesJson(this);
            }),
        );
    $('#tdModuleWizard').on(
        'click',
        guardEvent(() => openModuleWizard({ onDone: () => renderTemplateDesigner() })),
    );
    $('#tdNew').on(
        'click',
        guardEvent(() => {
            state.templateDraft = fresh();
            resetTemplateTabs();
            $('#templateDesignerModalTitle').text('Add Template');
            draw();
            bootstrap.Modal.getOrCreateInstance('#templateDesignerModal').show();
        }),
    );
    $('#templateCreateForm')
        .off('submit')
        .on(
            'submit',
            guardEvent((event) => {
                event.preventDefault();
                const editing = $('#templateCreateModal').data('template-id');
                if (!editing) state.templateDraft = fresh();
                state.templateDraft.code = $('#newTemplateCode').val().trim();
                state.templateDraft.name = $('#newTemplateName').val().trim();
                state.templateDraft.executionMode = $('#newTemplateMode').val();
                bootstrap.Modal.getOrCreateInstance('#templateCreateModal').hide();
                $('#tdEditor').removeClass('d-none');
                draw();
            }),
        );
    $('.td-edit').on(
        'click',
        guardEvent(async function () {
            try {
                const t = await api('/api/templates/' + $(this).data('id'));
                state.templateDraft = fromRecord(t);
                resetTemplateTabs();
                $('#templateDesignerModalTitle').text(`Edit Template: ${state.templateDraft.name}`);
                draw();
                bootstrap.Modal.getOrCreateInstance('#templateDesignerModal').show();
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );

    /**
     * Render the current designer draft and reconnect its editor controls.
     * @returns {void} Updates the relevant UI or state.
     */
    function draw() {
        const d = state.templateDraft;
        $('#tdEditor').html(
            `<div class="card"><div class="card-body"><div class="alert alert-info small"><div class="fw-semibold mb-1">How to build an Alert Type (template) in 3 steps</div><ol class="mb-1 ps-3"><li><b>Name it</b> – give it a name people will recognise and a short code.</li><li><b>Add sections</b> – a section is a group of related questions, for example "Customer details".</li><li><b>Add fields</b> – a field is one question or box inside a section, for example "Account number". Press <b>Save Template</b> when done.</li></ol>Next, open <b>Workflow Designer</b> to set who reviews and approves it.</div><div class="row g-3"><div class="col-md-3"><label class="form-label">Short code</label><input id="tdCode" class="form-control" placeholder="e.g. ATM_CASH" value="${esc(d.code)}" /><div class="form-text">Letters, numbers and underscore. No spaces.</div></div><div class="col-md-5"><label class="form-label">Name shown to users</label><input id="tdName" class="form-control" placeholder="e.g. ATM Cash Dispute" value="${esc(d.name)}" /><div class="form-text">This is what appears in dropdowns and on screens.</div></div><div class="col-md-4"><label class="form-label">How are alerts handled?</label><select id="tdMode" class="form-select">${[['Deterministic', 'Fixed rules (recommended)'], ['Hybrid', 'Fixed rules + AI suggestions'], ['Agentic', 'AI-assisted decisions']].map(([x, label]) => `<option value="${x}" ${d.executionMode === x ? 'selected' : ''}>${label}</option>`).join('')}</select><div class="form-text">If unsure, keep the recommended option.</div></div></div><div class="card bg-light border-0 mt-3"><div class="card-body"><div class="fw-semibold mb-2">View / Layout Configuration</div><div class="row g-3"><div class="col-md-4"><label class="form-label">Alert Detail Layout</label><select id="tdLayoutMode" class="form-select">${['Single', 'Tab', 'Popup', 'Accordion', 'Wizard'].map((x) => `<option ${d.viewConfiguration?.layoutMode === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div class="col-md-2"><label class="form-label">Popup Size</label><select id="tdPopupSize" class="form-select">${['sm', 'lg', 'xl'].map((x) => `<option ${d.viewConfiguration?.popupSize === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div class="col-md-2 form-check mt-5 ms-2"><input id="tdRememberSection" class="form-check-input" type="checkbox" ${d.viewConfiguration?.rememberLastSection !== false ? 'checked' : ''}><label class="form-check-label">Remember section</label></div><div class="col-md-2 form-check mt-5"><input id="tdShowSectionNumbers" class="form-check-input" type="checkbox" ${d.viewConfiguration?.showSectionNumbers !== false ? 'checked' : ''}><label class="form-check-label">Show section numbers</label></div><div class="col-md-2 form-check mt-5"><input id="tdWizardStepClick" class="form-check-input" type="checkbox" ${d.viewConfiguration?.allowWizardStepClick ? 'checked' : ''}><label class="form-check-label">Wizard step click</label></div></div><div class="form-text mt-2">Single, Tab, Popup, Accordion and Wizard layouts use the same configured sections and fields. No code change is required per template.</div></div></div><hr/><div class="d-flex justify-content-between mb-2"><div><h6 class="mb-0">Sections</h6><div class="small text-secondary">Groups of related questions, shown as tabs, steps or blocks.</div></div><div><button id="previewSections" type="button" class="btn btn-sm btn-outline-primary me-2">Preview</button><button id="addSection" class="btn btn-sm btn-outline-primary">Add Section</button></div></div><div class="table-responsive"><table class="table table-sm"><thead><tr><th>#</th><th>Name</th><th></th></tr></thead><tbody>${d.sections.map((s, i) => `<tr class="td-section-row" draggable="true" data-i="${i}"><td><span class="td-drag-handle" title="Drag to reorder">⋮⋮</span> ${i + 1}</td><td>${esc(s.name)}</td><td class="text-end"><button type="button" class="btn btn-sm btn-outline-primary preview-section me-2" data-i="${i}">Preview</button><button class="btn btn-sm btn-outline-danger del-section" data-i="${i}">Delete</button></td></tr>`).join('') || '<tr><td colspan="3" class="text-secondary">No sections yet. Click <b>Add Section</b> to create your first group of questions.</td></tr>'}</tbody></table></div><div class="d-flex justify-content-between mb-2 mt-4"><div><h6 class="mb-0">Fields</h6><div class="small text-secondary">The questions or boxes people fill in. Add sections first, then fields.</div></div><button id="addField" class="btn btn-sm btn-outline-primary">Add Field</button></div><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Section</th><th>Field</th><th>Type</th><th>Must be filled</th><th>Sensitive</th><th></th></tr></thead><tbody>${d.fields.map((f, i) => `<tr><td>${esc(d.sections.find((s) => s.id === f.sectionId)?.name || '')}</td><td>${esc(f.label)}</td><td>${esc($(`#fieldType option[value="${f.type}"]`).text() || f.type)}</td><td>${f.required ? 'Yes' : 'No'}</td><td>${f.sensitive ? 'Yes' : 'No'}</td><td class="text-end"><button class="btn btn-sm btn-outline-secondary edit-field" data-i="${i}">Edit</button> <button class="btn btn-sm btn-outline-danger del-field" data-i="${i}">Delete</button></td></tr>`).join('') || '<tr><td colspan="6" class="text-secondary">No fields yet. Click <b>Add Field</b> to add the first question.</td></tr>'}</tbody></table></div><div class="mt-4"><label class="form-label">Assignment Rules JSON</label><textarea id="tdRules" class="form-control font-monospace" rows="6">${esc(JSON.stringify(d.assignmentRules, null, 2))}</textarea><div class="form-text">Example: [{"field":"riskCategory","operator":"eq","value":"High","stageId":"input","targetRoleCode":"DT_USER","targetBranchCode":"B001","stop":true}]</div></div><div class="text-end mt-3"><button id="previewTemplate" type="button" class="btn btn-outline-primary px-4 me-2">Preview</button><button id="saveTemplate" class="btn btn-primary px-4">Save Template</button></div></div></div>`,
        );
        bind();
    }
    /**
     * Connect designer controls to draft editing, ordering, and save operations.
     * @returns {void} Updates the relevant UI or state.
     */
    function bind() {
        const d = state.templateDraft,
            sectionTable = $('#tdEditor table').first();
        sectionTable.find('thead th').eq(1).after('<th>Field Column Width</th><th>Data View</th>');
        d.sections.forEach((s, i) => {
            const row = sectionTable.find('tbody tr').eq(i);
            row.find('td')
                .eq(1)
                .after(`<td>${s.columnSpan} / 12</td><td>${esc(s.dataViewMode || 'Grid')}</td>`);
            row.find('td:last').prepend(
                `<button class="btn btn-sm btn-outline-secondary edit-section me-1" data-i="${i}">Edit</button>`,
            );
        });
        let sectionDragIndex = null;
        sectionTable
            .find('.td-section-row')
            .on(
                'dragstart',
                guardEvent(function (e) {
                    sectionDragIndex = Number($(this).data('i'));
                    this.classList.add('td-row-dragging');
                    e.originalEvent.dataTransfer.effectAllowed = 'move';
                }),
            )
            .on(
                'dragend',
                guardEvent(function () {
                    this.classList.remove('td-row-dragging');
                    sectionDragIndex = null;
                }),
            )
            .on(
                'dragover',
                guardEvent(function (e) {
                    e.preventDefault();
                    e.originalEvent.dataTransfer.dropEffect = 'move';
                }),
            )
            .on(
                'drop',
                guardEvent(function (e) {
                    e.preventDefault();
                    const target = Number($(this).data('i'));
                    if (sectionDragIndex === null || target === sectionDragIndex) return;
                    const [moved] = d.sections.splice(sectionDragIndex, 1);
                    d.sections.splice(target, 0, moved);
                    d.sections.forEach((section, index) => (section.order = index + 1));
                    draw();
                }),
            );
        $('#tdCode').on(
            'input',
            guardEvent(function () {
                d.code = $(this).val();
            }),
        );
        $('#tdName').on(
            'input',
            guardEvent(function () {
                d.name = $(this).val();
            }),
        );
        $('#tdMode').on(
            'change',
            guardEvent(function () {
                d.executionMode = $(this).val();
            }),
        );
        $('#tdLayoutMode').on(
            'change',
            guardEvent(function () {
                d.viewConfiguration.layoutMode = $(this).val();
            }),
        );
        $('#tdPopupSize').on(
            'change',
            guardEvent(function () {
                d.viewConfiguration.popupSize = $(this).val();
            }),
        );
        $('#tdRememberSection').on(
            'change',
            guardEvent(function () {
                d.viewConfiguration.rememberLastSection = this.checked;
            }),
        );
        $('#tdShowSectionNumbers').on(
            'change',
            guardEvent(function () {
                d.viewConfiguration.showSectionNumbers = this.checked;
            }),
        );
        $('#tdWizardStepClick').on(
            'change',
            guardEvent(function () {
                d.viewConfiguration.allowWizardStepClick = this.checked;
            }),
        );
        $('#tdRules').on(
            'input',
            guardEvent(function () {
                const rules = json($(this).val(), null);
                if (rules) d.assignmentRules = rules;
            }),
        );
        $('#addSection').on(
            'click',
            guardEvent(() => openSection(-1)),
        );
        $('.edit-section').on(
            'click',
            guardEvent(function () {
                openSection(+$(this).data('i'));
            }),
        );
        $('.del-section').on(
            'click',
            guardEvent(function () {
                const i = +$(this).data('i'),
                    id = state.templateDraft.sections[i].id;
                state.templateDraft.sections.splice(i, 1);
                state.templateDraft.fields = state.templateDraft.fields.filter((f) => f.sectionId !== id);
                draw();
            }),
        );
        $('#addField').on(
            'click',
            guardEvent(() => openField(-1)),
        );
        $('.edit-field').on(
            'click',
            guardEvent(function () {
                openField(+$(this).data('i'));
            }),
        );
        $('.del-field').on(
            'click',
            guardEvent(function () {
                state.templateDraft.fields.splice(+$(this).data('i'), 1);
                draw();
            }),
        );
        $('#saveTemplate').on('click', guardEvent(save));
        $('#previewTemplate').on('click', guardEvent(() => showTemplatePreview(state.templateDraft)));
        $('#previewSections').on('click', guardEvent(() => showTemplatePreview(state.templateDraft)));
        $('.preview-section').on('click', guardEvent(function () {
            const section = state.templateDraft.sections[Number($(this).data('i'))];
            showTemplatePreview({ ...state.templateDraft, name: section.name, sections: [section],
                fields: state.templateDraft.fields.filter((field) => field.sectionId === section.id) });
        }));
    }
    let activeSourceMappingMode = 'BulkFileUpload';
    // Table columns an ATM Bulk File Upload mapping can use (loaded once per template code from the API).
    let atmCatalog = null;
    let atmCatalogCode = '';
    /**
     * Render additional template settings and synchronize them with the editable draft.
     * @returns {void} Updates the relevant UI or state.
     */
    function decorateTemplateConfiguration() {
        const d = state.templateDraft;
        if (!Array.isArray(d.viewConfiguration.sourceColumnMappings)) d.viewConfiguration.sourceColumnMappings = [];
        const configuredModes = Array.isArray(d.viewConfiguration?.baseDataModes)
            ? d.viewConfiguration.baseDataModes
            : ['ManualSingle', 'BulkFileUpload', 'Sftp', 'FcQuery'];
        const baseDataOptions = [
            { value: 'ManualSingle', label: 'Manual Single Entry', help: 'Create one alert from the configured form.' },
            { value: 'BulkFileUpload', label: 'Bulk File Upload', help: 'Upload multiple alert records from CSV.' },
            { value: 'Sftp', label: 'SFTP Location', help: 'Allow a scheduled SFTP ingestion task.' },
            { value: 'FcQuery', label: 'FC Query', help: 'Allow a scheduled query ingestion task.' },
        ];
        const viewCard = $('#tdLayoutMode').closest('.card-body');
        viewCard.prepend(
            `<div class="fw-semibold mb-2">Base Data Configuration</div><div id="tdBaseDataModes" class="row g-2 mb-3">${baseDataOptions.map((option) => `<div class="col-md-6 col-xl-3"><div class="form-check border rounded bg-white p-3 h-100"><input class="form-check-input td-base-data-mode ms-0 me-2" type="checkbox" value="${option.value}" id="tdBaseData-${option.value}" ${configuredModes.some((value) => String(value).toLowerCase() === option.value.toLowerCase()) ? 'checked' : ''}><label class="form-check-label fw-semibold" for="tdBaseData-${option.value}">${option.label}</label><div class="small text-secondary mt-1">${option.help}</div></div></div>`).join('')}</div><hr class="my-3">`,
        );
        viewCard
            .find('.fw-semibold')
            .filter(function () {
                return $(this).text().trim() === 'View / Layout Configuration';
            })
            .text('View / Layout Configuration');
        const layouts = [
            { value: 'Auto', label: 'Automatic (tabs for multiple sections)' },
            { value: 'Single', label: 'Single View (all sections)' },
            { value: 'Tab', label: 'Tabbed View (one section per tab)' },
            { value: 'Popup', label: 'Popup View' },
            { value: 'Accordion', label: 'Accordion View' },
            { value: 'Wizard', label: 'Wizard / Step View' },
        ];
        $('#tdLayoutMode').html(
            layouts
                .map(
                    (option) =>
                        `<option value="${option.value}" ${String(d.viewConfiguration?.layoutMode || 'Single').toLowerCase() === option.value.toLowerCase() ? 'selected' : ''}>${option.label}</option>`,
                )
                .join(''),
        );
        viewCard
            .find('.form-text')
            .first()
            .text(
                'Automatic uses Single View for one section and Tabbed View for multiple sections. You can also explicitly choose either layout.',
            );
        const configuredListFields = d.viewConfiguration?.alertListFields || [];
            // Columns of the Alerts table come from the catalog (AlertListColumnMaster); displayOnly ones can be shown but not searched.
            const excludedFor = (column) =>
                String(column.excludedTemplateCodes || '')
                    .split(',')
                    .map((code) => code.trim().toUpperCase())
                    .filter(Boolean)
                    .includes(String(d.code || '').toUpperCase());
            const systemFields = (state.alertColumns || [])
                .filter((column) => !excludedFor(column))
                .map((column) => ({
                    name: column.code,
                    label: column.label,
                    type: column.controlType || 'text',
                    optionsJson: column.optionsJson || '[]',
                    displayOnly: !column.filterable,
                }));
        // A field the template defines itself always wins over an Alerts-table column of the same name, so nothing added under Sections is hidden.
        const templateFieldNames = new Set(d.fields.map((field) => String(field.name).toLowerCase()));
        const availableListFields = [
            ...systemFields.filter((field) => !templateFieldNames.has(String(field.name).toLowerCase())),
            ...d.fields.map((field) => ({
                name: field.name,
                label: field.label,
                type: field.type || 'text',
                optionsJson: field.optionsJson || '[]',
                sectionName: d.sections.find((section) => section.id === field.sectionId)?.name || '',
            })),
        ];
        const listFields = (configuredListFields.length
            ? configuredListFields
                  .map((configured) => {
                      const definition = availableListFields.find(
                          (field) => String(field.name).toLowerCase() === String(configured.field).toLowerCase(),
                      );
                      return definition ? { ...definition, current: configured, order: Number(configured.order ?? 0) } : null;
                  })
                  .filter(Boolean)
            : availableListFields.map((field, index) => ({ ...field, current: {}, order: index })))
            .map((field, index) => {
                const current =
                    field.current ||
                    configuredListFields.find((item) => String(item.field).toLowerCase() === field.name.toLowerCase()) ||
                    {};
                return { ...field, current, order: Number(current.order ?? index) };
            })
            .sort((a, b) => a.order - b.order);
        const alertListRowHtml = (field, index) =>
            `<tr class="td-alert-list-row" draggable="true" data-field="${esc(field.name)}" data-label="${esc(field.label)}" data-control-type="${esc(field.type || 'text')}" data-options-json="${esc(field.optionsJson || '[]')}"><td><span class="td-drag-handle" title="Drag to reorder">⋮⋮</span></td><td>${esc(field.label)}<div class="small text-secondary">${esc(field.name)}</div></td><td><input type="text" maxlength="100" class="form-control form-control-sm td-alert-list-label" value="${esc(field.current.label || field.label)}" placeholder="${esc(field.label)}" aria-label="Display name for ${esc(field.label)}"></td><td><input type="number" min="1" class="form-control form-control-sm td-alert-list-order" value="${index + 1}" aria-label="Order ${esc(field.label)}"></td><td><span class="badge text-bg-light border">${['select', 'multiselect', 'radio', 'checkboxlist'].includes(String(field.type || '').toLowerCase()) ? 'Dropdown' : esc(field.type || 'Text')}</span></td><td class="text-center"><input class="form-check-input td-alert-list-grid" type="checkbox" ${field.current.showInGrid ? 'checked' : ''}></td><td class="text-center"><input class="form-check-input td-alert-list-filter" type="checkbox" ${field.current.showAsFilter && !field.displayOnly ? 'checked' : ''} ${field.displayOnly ? 'disabled title="This column can be shown but not searched"' : ''}></td><td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger td-alert-list-delete" title="Remove this column">Delete</button></td></tr>`;
        viewCard.append(
            `<hr class="my-3"><div class="fw-semibold mb-2">Alert List Configuration</div><div class="small text-secondary mb-2">Add only the columns needed in the alert grid or filters. Set a Display Name to rename a column in the Alerts grid and filters. Drag rows or change Order to control display order. Choice fields automatically render as dropdown filters.</div><div class="d-flex flex-wrap gap-2 align-items-center mb-2"><select id="tdAlertListAddColumn" class="form-select form-select-sm" style="max-width:320px" aria-label="Field to add to alert list"><option value="">Add column…</option></select><button type="button" id="tdAlertListAddButton" class="btn btn-sm btn-outline-primary">Add column</button></div><div class="table-responsive"><table id="tdAlertListConfiguration" class="table table-sm align-middle mb-0"><thead><tr><th style="width:44px"></th><th>Field</th><th style="min-width:200px">Display Name</th><th style="width:90px">Order</th><th>Filter Control</th><th class="text-center">Grid</th><th class="text-center">Filter</th><th class="text-center">Remove</th></tr></thead><tbody>${listFields.map(alertListRowHtml).join('') || '<tr><td colspan="8" class="text-secondary">No alert-list columns configured. Add a column to display it in the grid or filters.</td></tr>'}</tbody></table></div>`,
        );
        $('.td-base-data-mode').on(
            'change',
            guardEvent(function () {
                const selected = $('.td-base-data-mode:checked')
                    .map((_, element) => element.value)
                    .get();
                if (!selected.length) {
                    this.checked = true;
                    toast('Select at least one Base Data option.', 'warning');
                    return;
                }
                d.viewConfiguration.baseDataModes = $('.td-base-data-mode:checked')
                    .map((_, element) => element.value)
                    .get();
                renderSourceColumnMapping();
            }),
        );
        viewCard.append(
            '<hr class="my-3"><div class="fw-semibold mb-1">Source Column Mapping</div><div class="small text-secondary mb-2">Map the columns of each data source to the display fields listed under Fields. A blank source column uses the field name. Drag rows or change Order to set the column order, which is also used for the downloadable sample file. Only the Base Data options selected above can be mapped.</div><ul id="tdSourceMappingTabs" class="nav nav-pills mb-2" role="tablist"></ul><div id="tdSourceMappingPanel"></div>',
        );
        /**
         * Render the Source Column Mapping tabs and the table for the active ingestion mode.
         * @returns {void} Updates the relevant UI or state.
         */
        function renderSourceColumnMapping() {
            const sourceModes = [
                {
                    value: 'ManualSingle',
                    label: 'Manual Single Entry',
                    mapped: false,
                    help: 'Values are typed into the configured entry form, so each display field is filled directly and needs no source column.',
                },
                {
                    value: 'BulkFileUpload',
                    label: 'Bulk File Upload',
                    mapped: true,
                    help: 'Enter the column header used in the uploaded CSV or delimited file for each display field.',
                },
                {
                    value: 'Sftp',
                    label: 'SFTP Location',
                    mapped: true,
                    help: 'Enter the column header used in the file picked up by the scheduled SFTP task.',
                },
                {
                    value: 'FcQuery',
                    label: 'FC Query',
                    mapped: true,
                    help: 'Enter the result column name returned by the scheduled FC query.',
                },
            ];
            const enabled = d.viewConfiguration.baseDataModes || [];
            const isEnabled = (mode) => enabled.some((value) => String(value).toLowerCase() === mode.toLowerCase());
            if (!isEnabled(activeSourceMappingMode))
                activeSourceMappingMode = sourceModes.find((mode) => isEnabled(mode.value))?.value || 'BulkFileUpload';
            const active = sourceModes.find((mode) => mode.value === activeSourceMappingMode);
            const mappingFor = (mode, field) =>
                d.viewConfiguration.sourceColumnMappings.find(
                    (item) =>
                        String(item.mode).toLowerCase() === mode.toLowerCase() &&
                        String(item.field).toLowerCase() === String(field).toLowerCase(),
                );
            $('#tdSourceMappingTabs').html(
                sourceModes
                    .map(
                        (mode) =>
                            `<li class="nav-item" role="presentation"><button type="button" class="nav-link td-source-mode ${mode.value === active.value ? 'active' : ''}" data-mode="${mode.value}" ${isEnabled(mode.value) ? '' : 'disabled title="Enable this option in Base Data Configuration to map its source columns."'}>${mode.label}</button></li>`,
                    )
                    .join(''),
            );
            // ATM Bulk File Upload lists mapping entries (table column to file column) that the admin can add, delete and reorder.
            const isAtm = /^ATM_(ONUS|OFFUS)$/i.test(String(d.code || ''));
            const entryMode = isAtm && active.value === 'BulkFileUpload';
            if (entryMode && atmCatalogCode !== String(d.code).toUpperCase()) {
                atmCatalogCode = String(d.code).toUpperCase();
                atmCatalog = null;
                const requestedCode = atmCatalogCode;
                api('/api/templates/source-columns/' + encodeURIComponent(requestedCode))
                    .then((catalog) => {
                        if (requestedCode !== atmCatalogCode) return;
                        atmCatalog = catalog;
                        renderSourceColumnMapping();
                    })
                    .catch(() => {
                        atmCatalog = { columns: [], defaults: [], requiredFields: [] };
                        renderSourceColumnMapping();
                    });
            }
            const labelFor = (name) => d.fields.find((field) => String(field.name).toLowerCase() === String(name).toLowerCase())?.label || name;
            const requiredAtmFields = (atmCatalog?.requiredFields || []).map((name) => String(name).toLowerCase());
            // Mapped sources can be reordered; fields without a saved order follow in template field order.
            const orderedFields = entryMode
                ? d.viewConfiguration.sourceColumnMappings
                      .filter((item) => String(item.mode).toLowerCase() === 'bulkfileupload')
                      .map((item, index) => ({ field: { name: item.field, label: labelFor(item.field) }, index, order: Number(item.order) || 0 }))
                      .sort((a, b) => (a.order || 1e9) - (b.order || 1e9) || a.index - b.index)
                      .map((item) => item.field)
                : active.mapped
                  ? d.fields
                        .map((field, index) => ({ field, index, order: Number(mappingFor(active.value, field.name)?.order) || 0 }))
                        .sort((a, b) => (a.order || 1e9) - (b.order || 1e9) || a.index - b.index)
                        .map((item) => item.field)
                  : d.fields;
            const rows = orderedFields
                .map((field, position) => {
                    const mapping = mappingFor(active.value, field.name);
                    const input = active.mapped
                        ? `<input class="form-control form-control-sm td-source-column" data-field="${esc(field.name)}" maxlength="200" placeholder="${esc(field.name)}" value="${esc(mapping?.sourceColumn || '')}" aria-label="Source column for ${esc(field.label)}">`
                        : `<input class="form-control form-control-sm" value="${esc(field.name)}" aria-label="Entry form input for ${esc(field.label)}" disabled>`;
                    const required = active.mapped
                        ? `<td class="text-center"><input class="form-check-input td-source-required" type="checkbox" data-field="${esc(field.name)}" ${mapping?.required ? 'checked' : ''} aria-label="${esc(field.label)} column is required in the file"></td>`
                        : '';
                    const ordering = active.mapped
                        ? `<td><span class="td-drag-handle" title="Drag to reorder">⋮⋮</span></td><td><input type="number" min="1" class="form-control form-control-sm td-source-order" value="${position + 1}" aria-label="Order ${esc(field.label)}"></td>`
                        : '<td></td><td></td>';
                    const remove = entryMode
                        ? `<td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger td-source-delete" data-field="${esc(field.name)}" ${requiredAtmFields.includes(String(field.name).toLowerCase()) ? 'disabled title="Needed to create ATM cases"' : 'title="Remove this mapping"'} aria-label="Delete mapping for ${esc(field.label)}">Delete</button></td>`
                        : '';
                    return `<tr class="${active.mapped ? 'td-source-row' : ''}" ${active.mapped ? `draggable="true" data-field="${esc(field.name)}"` : ''}>${ordering}<td>${esc(field.label)}${!entryMode && field.required ? ' <span class="text-danger" title="Required">*</span>' : ''}</td><td class="small text-secondary">${esc(field.name)}</td><td>${input}</td>${required}${remove}</tr>`;
                })
                .join('');
            const mappedNames = new Set(orderedFields.map((field) => String(field.name).toLowerCase()));
            const pickerOptions = entryMode
                ? [
                      ...(atmCatalog?.columns || []).map((column) => column.name),
                      ...d.fields
                          .map((field) => field.name)
                          .filter((name) => !['atmid', 'penaltymonth', 'penaltyamount', 'casecategory'].includes(String(name).toLowerCase())),
                  ]
                      .filter((name, index, all) => all.findIndex((other) => String(other).toLowerCase() === String(name).toLowerCase()) === index)
                      .filter((name) => !mappedNames.has(String(name).toLowerCase()))
                : [];
            const adder = entryMode
                ? `<div class="d-flex flex-wrap gap-2 align-items-center mb-2"><select id="tdSourceAddColumn" class="form-select form-select-sm" style="max-width:320px" aria-label="Table column to add"><option value="">${atmCatalog ? 'Add table column…' : 'Loading table columns…'}</option>${pickerOptions.map((name) => `<option value="${esc(name)}">${esc(name)}</option>`).join('')}</select><button type="button" id="tdSourceAddButton" class="btn btn-sm btn-outline-primary">Add column</button><button type="button" id="tdSourceMappingDefault" class="btn btn-sm btn-outline-secondary">Reset to default mapping</button></div>`
                : '';
            const reset =
                active.mapped && !entryMode && d.fields.length
                    ? '<button type="button" id="tdSourceMappingReset" class="btn btn-sm btn-outline-secondary">Clear all mappings for this source</button>'
                    : '';
            const bulkSettings =
                active.value === 'BulkFileUpload'
                    ? `<div class="row g-2 mb-3 align-items-end"><div class="col-md-4"><label class="form-label small mb-1" for="tdBulkFileFormat">File format</label><select id="tdBulkFileFormat" class="form-select form-select-sm"><option value="">Auto (CSV or TXT)</option><option value="Csv">CSV (.csv)</option><option value="Txt">TXT (.txt)</option><option value="Excel">Excel (.xlsx)</option></select></div><div class="col-md-4" id="tdBulkDelimiterGroup"><label class="form-label small mb-1" for="tdBulkFileDelimiter">Column separator</label><select id="tdBulkFileDelimiter" class="form-select form-select-sm"><option value="">Auto-detect (comma or tilde)</option><option value=",">Comma ( , )</option><option value="~">Tilde ( ~ )</option><option value="|">Pipe ( | )</option><option value=";">Semicolon ( ; )</option><option value="&#9;">Tab</option><option value="custom">Other character…</option></select></div><div class="col-md-2 d-none" id="tdBulkDelimiterCustomGroup"><label class="form-label small mb-1" for="tdBulkFileDelimiterCustom">Character</label><input id="tdBulkFileDelimiterCustom" class="form-control form-control-sm" maxlength="1"></div></div>`
                    : '';
            $('#tdSourceMappingPanel').html(
                `<div class="small text-secondary mb-2">${active.help}</div>${bulkSettings}${adder}<div class="table-responsive" style="max-height:420px;overflow:auto"><table class="table table-sm align-middle mb-2"><thead><tr><th style="width:44px"></th><th style="width:90px">Order</th><th>${entryMode ? 'Column Label' : 'Display Field'}</th><th>Table Column (Field Key)</th><th>${active.mapped ? 'Source (File) Column' : 'Entry Form Input'}</th>${active.mapped ? '<th class="text-center" title="Reject files that do not contain this column">Required in file</th>' : ''}${entryMode ? '<th class="text-center">Remove</th>' : ''}</tr></thead><tbody>${rows || `<tr><td colspan="7" class="text-secondary">${entryMode ? 'No columns mapped. Add a table column or reset to the default mapping.' : 'Add fields to map source columns.'}</td></tr>`}</tbody></table></div>${reset}`,
            );
            if (active.value === 'BulkFileUpload') {
                const knownSeparators = ['', ',', '~', '|', ';', '\t'];
                const separator = String(d.viewConfiguration.bulkFileDelimiter || '');
                const known = knownSeparators.includes(separator);
                $('#tdBulkFileFormat').val(d.viewConfiguration.bulkFileFormat || '');
                $('#tdBulkFileDelimiter').val(known ? separator : 'custom');
                $('#tdBulkFileDelimiterCustom').val(known ? '' : separator);
                updateBulkSeparatorVisibility();
            }
        }
        /**
         * Show the separator controls only for delimited text formats.
         * @returns {void} Updates the relevant UI or state.
         */
        function updateBulkSeparatorVisibility() {
            const excel = $('#tdBulkFileFormat').val() === 'Excel';
            $('#tdBulkDelimiterGroup').toggleClass('d-none', excel);
            $('#tdBulkDelimiterCustomGroup').toggleClass('d-none', excel || $('#tdBulkFileDelimiter').val() !== 'custom');
        }
        /**
         * Copy the Bulk File Upload format and separator controls into the draft view configuration.
         * @returns {void} Updates the relevant UI or state.
         */
        function syncBulkFileSettings() {
            const format = String($('#tdBulkFileFormat').val() || '');
            const selected = String($('#tdBulkFileDelimiter').val() || '');
            d.viewConfiguration.bulkFileFormat = format;
            d.viewConfiguration.bulkFileDelimiter =
                format === 'Excel' ? '' : selected === 'custom' ? String($('#tdBulkFileDelimiterCustom').val() || '') : selected;
            updateBulkSeparatorVisibility();
        }
        const upsertSourceMapping = (field, change) => {
            const list = d.viewConfiguration.sourceColumnMappings;
            const match = (item) =>
                String(item.mode).toLowerCase() === activeSourceMappingMode.toLowerCase() &&
                String(item.field).toLowerCase() === field.toLowerCase();
            const entry = list.find(match) || { mode: activeSourceMappingMode, field, sourceColumn: '', required: false, order: 0 };
            Object.assign(entry, change);
            d.viewConfiguration.sourceColumnMappings = list.filter((item) => !match(item));
            if (entry.sourceColumn || entry.required || entry.order > 0) d.viewConfiguration.sourceColumnMappings.push(entry);
        };
        /**
         * Stamp the on-screen row order of the active source onto every field so it is saved with the template.
         * @returns {void} Updates the relevant UI or state.
         */
        const syncSourceOrder = () => {
            $('#tdSourceMappingPanel .td-source-row').each(function (index) {
                $(this).find('.td-source-order').val(index + 1);
                upsertSourceMapping(String($(this).data('field')), { order: index + 1 });
            });
        };
        let sourceRowDrag = null;
        $('#tdSourceMappingTabs').on(
            'click',
            '.td-source-mode',
            guardEvent(function () {
                activeSourceMappingMode = String($(this).data('mode'));
                renderSourceColumnMapping();
            }),
        );
        $('#tdSourceMappingPanel')
            .on(
                'input',
                '.td-source-column',
                guardEvent(function () {
                    upsertSourceMapping(String($(this).data('field')), { sourceColumn: String($(this).val() || '').trim() });
                    syncSourceOrder();
                }),
            )
            .on(
                'change',
                '.td-source-required',
                guardEvent(function () {
                    upsertSourceMapping(String($(this).data('field')), { required: $(this).is(':checked') });
                    syncSourceOrder();
                }),
            )
            .on(
                'change',
                '.td-source-order',
                guardEvent(() => {
                    const rows = $('#tdSourceMappingPanel .td-source-row')
                        .get()
                        .sort(
                            (a, b) =>
                                (Number($(a).find('.td-source-order').val()) || 9999) -
                                (Number($(b).find('.td-source-order').val()) || 9999),
                        );
                    const systemAnchor = $('#tdSourceMappingPanel tbody tr.table-light').first();
                    if (systemAnchor.length) systemAnchor.before(rows);
                    else $('#tdSourceMappingPanel tbody').append(rows);
                    syncSourceOrder();
                }),
            )
            .on(
                'dragstart',
                '.td-source-row',
                guardEvent(function (e) {
                    sourceRowDrag = this;
                    this.classList.add('td-row-dragging');
                    e.originalEvent.dataTransfer.effectAllowed = 'move';
                }),
            )
            .on(
                'dragend',
                '.td-source-row',
                guardEvent(function () {
                    this.classList.remove('td-row-dragging');
                    sourceRowDrag = null;
                }),
            )
            .on(
                'dragover',
                '.td-source-row',
                guardEvent(function (e) {
                    e.preventDefault();
                }),
            )
            .on(
                'drop',
                '.td-source-row',
                guardEvent(function (e) {
                    e.preventDefault();
                    if (!sourceRowDrag || sourceRowDrag === this) return;
                    const rect = this.getBoundingClientRect(),
                        before = e.originalEvent.clientY < rect.top + rect.height / 2;
                    before ? this.before(sourceRowDrag) : this.after(sourceRowDrag);
                    syncSourceOrder();
                }),
            )
            .on('change input', '#tdBulkFileFormat,#tdBulkFileDelimiter,#tdBulkFileDelimiterCustom', guardEvent(syncBulkFileSettings))
            .on(
                'click',
                '.td-source-delete',
                guardEvent(function () {
                    const field = String($(this).data('field')).toLowerCase();
                    d.viewConfiguration.sourceColumnMappings = d.viewConfiguration.sourceColumnMappings.filter(
                        (item) =>
                            !(
                                String(item.mode).toLowerCase() === 'bulkfileupload' &&
                                String(item.field).toLowerCase() === field
                            ),
                    );
                    renderSourceColumnMapping();
                }),
            )
            .on(
                'click',
                '#tdSourceAddButton',
                guardEvent(() => {
                    const name = String($('#tdSourceAddColumn').val() || '');
                    if (!name) {
                        toast('Choose a table column to add.', 'warning');
                        return;
                    }
                    const uploadNames = { CreatedBy: 'UploadBy', CreatedDate: 'UploadDate' };
                    const count = d.viewConfiguration.sourceColumnMappings.filter(
                        (item) => String(item.mode).toLowerCase() === 'bulkfileupload',
                    ).length;
                    d.viewConfiguration.sourceColumnMappings.push({
                        mode: 'BulkFileUpload',
                        field: name,
                        sourceColumn: uploadNames[name] || name,
                        required: false,
                        order: count + 1,
                    });
                    renderSourceColumnMapping();
                }),
            )
            .on(
                'click',
                '#tdSourceMappingDefault',
                guardEvent(() => {
                    d.viewConfiguration.sourceColumnMappings = [
                        ...d.viewConfiguration.sourceColumnMappings.filter(
                            (item) => String(item.mode).toLowerCase() !== 'bulkfileupload',
                        ),
                        ...(atmCatalog?.defaults || []).map((item) => ({ ...item })),
                    ];
                    renderSourceColumnMapping();
                }),
            )
            .on(
                'click',
                '#tdSourceMappingReset',
                guardEvent(() => {
                    d.viewConfiguration.sourceColumnMappings = d.viewConfiguration.sourceColumnMappings.filter(
                        (item) => String(item.mode).toLowerCase() !== activeSourceMappingMode.toLowerCase(),
                    );
                    renderSourceColumnMapping();
                }),
            );
        renderSourceColumnMapping();
        // Data Storage: the table CATS generates from this template's fields (created on publish, or here with Generate / Update).
        viewCard.append(
            '<hr class="my-3"><div class="fw-semibold mb-1">Data Storage</div><div class="small text-secondary mb-2">The answers for this Alert Type can be saved in their own database table, with one column for each field. This happens automatically when you publish; use the button below to do it earlier. Existing data is never deleted: columns are only added or made larger.</div><div id="tdDataStorage"></div>',
        );
        const renderDataStorage = async () => {
            const host = $('#tdDataStorage');
            if (!d.id) {
                host.html('<div class="text-secondary small">Save the template first. Its data table is created when you publish, or with Generate here.</div>');
                return;
            }
            host.html('<div class="text-secondary small">Loading…</div>');
            const plan = await api(`/api/templates/${encodeURIComponent(d.id)}/data-table`);
            if (!plan.supported) {
                host.html(`<div class="alert alert-light border small mb-0">${esc(plan.unsupportedReason || 'Not available for this Alert Type.')}</div>`);
                return;
            }
            const typeLabel = (sql) => {
                const text = /^nvarchar\((\d+)\)$/i.exec(sql),
                    number = /^decimal\((\d+),(\d+)\)$/i.exec(sql);
                const friendly = text
                    ? `Text (${text[1]})`
                    : /^nvarchar\(max\)$/i.test(sql)
                      ? 'Long text'
                      : number
                        ? `Number (${number[1]},${number[2]})`
                        : { int: 'Whole number', bigint: 'Large whole number', float: 'Decimal number', date: 'Date', datetime2: 'Date and time', bit: 'Yes / No' }[String(sql).toLowerCase()];
                return friendly ? `${friendly} - ${sql}` : sql;
            };
            // Any type can be chosen until the column exists; afterwards only a safe widening (the server sends exactly those options).
            const typeSelect = (c) => {
                const options = (plan.columnTypeOptions || {})[c.fieldName] || [c.sqlType];
                return `<select class="form-select form-select-sm td-col-type" data-field="${esc(c.fieldName)}" data-original="${esc(c.sqlType)}" aria-label="Column type for ${esc(c.fieldName)}" ${options.length <= 1 ? 'disabled title="Existing columns can only be widened"' : ''}>${options
                    .map((o) => `<option value="${esc(o)}" ${String(o).toLowerCase() === String(c.sqlType).toLowerCase() ? 'selected' : ''}>${esc(typeLabel(o))}</option>`)
                    .join('')}</select>`;
            };
            const columnRows = (plan.existingColumns || [])
                .map((c) => `<tr><td>${esc(c.fieldName)}</td><td><code>${esc(c.columnName)}</code></td><td>${typeSelect(c)}</td><td><span class="badge text-bg-success">In table</span></td></tr>`)
                .concat((plan.columnsToAdd || []).map((c) => `<tr class="table-warning"><td>${esc(c.fieldName)}</td><td><code>${esc(c.columnName)}</code></td><td>${typeSelect(c)}</td><td><span class="badge text-bg-warning">Will be added</span></td></tr>`))
                .concat((plan.columnsToWiden || []).map((c) => `<tr class="table-warning"><td>${esc(c.fieldName)}</td><td><code>${esc(c.columnName)}</code></td><td>${typeSelect(c)}</td><td><span class="badge text-bg-warning">Will be widened</span></td></tr>`))
                .join('');
            const pending = (plan.columnsToAdd || []).length + (plan.columnsToWiden || []).length;
            const status = plan.generated
                ? `<span class="badge text-bg-success">Generated</span> <code>${esc(plan.tableName)}</code>${pending ? ` · ${pending} change(s) waiting` : ' · up to date'}`
                : `<span class="badge text-bg-secondary">Not generated</span> Data is stored as JSON${plan.alertsToCopy ? `; ${plan.alertsToCopy} existing alert(s) will be copied into the table` : ''}.`;
            host.html(`<div class="d-flex flex-wrap align-items-end gap-2 mb-2"><div class="me-2">${status}</div>
                ${plan.tableNameEditable ? `<div><label class="form-label small mb-0" for="tdDataTableName">Table name</label><input id="tdDataTableName" class="form-control form-control-sm" maxlength="100" value="${esc(plan.tableName)}"></div>` : ''}
                <button type="button" id="tdDataTableGenerate" class="btn btn-sm btn-outline-primary">${plan.generated ? 'Update table' : 'Generate table'}</button></div>
                ${columnRows ? `<div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Field</th><th>Column</th><th>Type</th><th></th></tr></thead><tbody>${columnRows}</tbody></table></div>` : ''}`);
        };
        $('#tdDataStorage').on(
            'click',
            '#tdDataTableGenerate',
            guardEvent(async () => {
                const name = String($('#tdDataTableName').val() || '').trim();
                const columnTypes = {};
                $('#tdDataStorage .td-col-type:not(:disabled)').each(function () {
                    const value = String($(this).val() || '');
                    if (value && value !== String($(this).data('original'))) columnTypes[String($(this).data('field'))] = value;
                });
                await api(`/api/templates/${encodeURIComponent(d.id)}/data-table`, { method: 'POST', body: { tableName: name || null, columnTypes } });
                toast('Data table is up to date');
                await renderDataStorage();
            }),
        );
        renderDataStorage().catch((x) => $('#tdDataStorage').html(`<div class="alert alert-danger small mb-0">${esc(x.message)}</div>`));
        /**
         * Read configured alert-list columns from the editor into the template view configuration.
         * @returns {void} Updates the relevant UI or state.
         */
        const syncAlertListConfiguration = () => {
            const fields = [];
            $('#tdAlertListConfiguration tbody .td-alert-list-row').each(function (index) {
                const row = $(this),
                    order = Math.max(1, Number(row.find('.td-alert-list-order').val()) || index + 1);
                fields.push({
                    field: String(row.data('field')),
                    label: String(row.find('.td-alert-list-label').val() || '').trim() || String(row.data('label')),
                    showInGrid: row.find('.td-alert-list-grid').is(':checked'),
                    showAsFilter: row.find('.td-alert-list-filter').is(':checked'),
                    order: order - 1,
                    controlType: String(row.data('control-type') || 'text'),
                    optionsJson: String(row.attr('data-options-json') || '[]'),
                });
            });
            fields.sort((a, b) => a.order - b.order).forEach((item, index) => (item.order = index));
            d.viewConfiguration.alertListFields = fields;
        };
        const refreshAlertListPicker = () => {
            const selected = new Set(
                $('#tdAlertListConfiguration tbody .td-alert-list-row')
                    .map((_, row) => String($(row).data('field')).toLowerCase())
                    .get(),
            );
            // Alert columns first, then every template field grouped under the Section it was added to.
            const remaining = availableListFields.filter((field) => !selected.has(String(field.name).toLowerCase()));
            const option = (field) => `<option value="${esc(field.name)}">${esc(field.label)} (${esc(field.name)})</option>`;
            const groups = [];
            const alertColumns = remaining.filter((field) => field.sectionName === undefined);
            if (alertColumns.length) groups.push(`<optgroup label="Alert columns">${alertColumns.map(option).join('')}</optgroup>`);
            const sectionNames = [...new Set(remaining.filter((field) => field.sectionName !== undefined).map((field) => field.sectionName))];
            sectionNames.forEach((sectionName) =>
                groups.push(
                    `<optgroup label="${esc(sectionName ? `Section: ${sectionName}` : 'Fields without a section')}">${remaining
                        .filter((field) => field.sectionName === sectionName)
                        .map(option)
                        .join('')}</optgroup>`,
                ),
            );
            $('#tdAlertListAddColumn').html(`<option value="">Add column…</option>${groups.join('')}`);
        };
        const renumberAlertListRows = () =>
            $('#tdAlertListConfiguration tbody .td-alert-list-order').each((index, input) => (input.value = index + 1));
        refreshAlertListPicker();
        $('#tdAlertListAddButton').on(
            'click',
            guardEvent(() => {
                const name = String($('#tdAlertListAddColumn').val() || '');
                const field = availableListFields.find((item) => item.name === name);
                if (!field) {
                    toast('Choose a column to add.', 'warning');
                    return;
                }
                const body = $('#tdAlertListConfiguration tbody');
                body.children(':not(.td-alert-list-row)').remove();
                body.append(alertListRowHtml({ ...field, current: {} }, body.find('.td-alert-list-row').length));
                renumberAlertListRows();
                syncAlertListConfiguration();
                refreshAlertListPicker();
            }),
        );
        $('#tdAlertListConfiguration').on(
            'click',
            '.td-alert-list-delete',
            guardEvent(function () {
                $(this).closest('.td-alert-list-row').remove();
                const body = $('#tdAlertListConfiguration tbody');
                if (!body.children().length)
                    body.html('<tr><td colspan="8" class="text-secondary">No alert-list columns configured. Add a column to display it in the grid or filters.</td></tr>');
                renumberAlertListRows();
                syncAlertListConfiguration();
                refreshAlertListPicker();
            }),
        );
        $('.td-alert-list-grid,.td-alert-list-filter,.td-alert-list-label').on('change', guardEvent(syncAlertListConfiguration));
        $('.td-alert-list-order').on(
            'change',
            guardEvent(function () {
                const rows = $('#tdAlertListConfiguration tbody .td-alert-list-row')
                    .get()
                    .sort(
                        (a, b) =>
                            (Number($(a).find('.td-alert-list-order').val()) || 999) -
                            (Number($(b).find('.td-alert-list-order').val()) || 999),
                    );
                $('#tdAlertListConfiguration tbody').append(rows);
                $('#tdAlertListConfiguration tbody .td-alert-list-order').each((i, x) => (x.value = i + 1));
                syncAlertListConfiguration();
            }),
        );
        let alertListDrag = null;
        $('#tdAlertListConfiguration')
            .on(
                'dragstart',
                '.td-alert-list-row',
                guardEvent(function (e) {
                    alertListDrag = this;
                    this.classList.add('td-row-dragging');
                    e.originalEvent.dataTransfer.effectAllowed = 'move';
                }),
            )
            .on(
                'dragend',
                '.td-alert-list-row',
                guardEvent(function () {
                    this.classList.remove('td-row-dragging');
                    alertListDrag = null;
                }),
            )
            .on(
                'dragover',
                '.td-alert-list-row',
                guardEvent(function (e) {
                    e.preventDefault();
                }),
            )
            .on(
                'drop',
                '.td-alert-list-row',
                guardEvent(function (e) {
                    e.preventDefault();
                    if (!alertListDrag || alertListDrag === this) return;
                    const rect = this.getBoundingClientRect(),
                        before = e.originalEvent.clientY < rect.top + rect.height / 2;
                    before ? this.before(alertListDrag) : this.after(alertListDrag);
                    $('#tdAlertListConfiguration tbody .td-alert-list-order').each((i, x) => (x.value = i + 1));
                    syncAlertListConfiguration();
                }),
            );
        enhanceTemplateConfigurationGrids();
    }
    /**
     * Add sorting and display preferences to the template configuration grids.
     * @returns {void} Updates the relevant UI or state.
     */
    function enhanceTemplateConfigurationGrids() {
        const grids = [
            { selector: '#tdAlertListConfiguration', key: 'alert-list', placeholder: 'Filter fields' },
            { selector: '#tdEditor table', key: 'sections', placeholder: 'Filter sections', heading: 'Name' },
            { selector: '#tdEditor table', key: 'fields', placeholder: 'Filter fields', heading: 'Type' },
        ];
        const used = new Set();
        grids.forEach((config) => {
            const table = $(config.selector)
                .filter(function () {
                    if (used.has(this)) return false;
                    return (
                        !config.heading ||
                        $(this)
                            .find('thead th')
                            .filter((_, header) => $(header).text().trim() === config.heading).length > 0
                    );
                })
                .first();
            if (!table.length || table.data('template-grid-paging')) return;
            used.add(table[0]);
            table.data('template-grid-paging', true);
            const rows = table.find('tbody tr').filter(function () {
                return $(this).children('td').length > 1;
            });
            const pageSize = 10,
                controlId = `template-grid-${config.key}`;
            table
                .closest('.table-responsive')
                .before(
                    `<div class="template-grid-filter mb-2"><label class="visually-hidden" for="${controlId}">${config.placeholder}</label><input id="${controlId}" class="form-control form-control-sm" placeholder="${config.placeholder}" /></div>`,
                )
                .after(
                    `<div class="template-grid-pagination d-flex justify-content-between align-items-center mt-2 small text-secondary"><span></span><div><button type="button" class="btn btn-sm btn-outline-secondary template-grid-prev" title="Previous page" aria-label="Previous page">&#8592;</button><button type="button" class="btn btn-sm btn-outline-secondary template-grid-next ms-1" title="Next page" aria-label="Next page">&#8594;</button></div></div>`,
                );
            let page = 1;
            const pager = table.closest('.table-responsive').next('.template-grid-pagination');
            /**
             * Rebuild the configuration grid using its current column and row selections.
             * @returns {void} Updates the relevant UI or state.
             */
            const render = () => {
                const search = String($(`#${controlId}`).val() || '').toLowerCase();
                const matching = rows.filter(function () {
                    return $(this).text().toLowerCase().includes(search);
                });
                const pages = Math.max(1, Math.ceil(matching.length / pageSize));
                page = Math.min(page, pages);
                rows.hide();
                matching.slice((page - 1) * pageSize, page * pageSize).show();
                pager.find('span').text(matching.length ? `Page ${page} of ${pages}` : 'No matching records');
                pager.find('.template-grid-prev').prop('disabled', page === 1);
                pager.find('.template-grid-next').prop('disabled', page === pages);
            };
            $(`#${controlId}`).on(
                'input',
                guardEvent(() => {
                    page = 1;
                    render();
                }),
            );
            pager.find('.template-grid-prev').on(
                'click',
                guardEvent(() => {
                    page--;
                    render();
                }),
            );
            pager.find('.template-grid-next').on(
                'click',
                guardEvent(() => {
                    page++;
                    render();
                }),
            );
            render();
        });
    }
    const drawTemplateEditor = draw;
    draw = function () {
        drawTemplateEditor();
        decorateTemplateConfiguration();
        enhanceDesignerActions($('#tdEditor'));
        const organized = organizeTemplateEditor(state.templateDraft);
        if (organized) {
            addQuickField(organized.fieldsPane);
            addAccessPicker(organized.reviewPane);
        }
    };
    /**
     * Add "who can use this Alert Type" to the last tab: everyone, or only the ticked roles.
     * @param {*} pane - The Options & save tab.
     * @returns {Promise<void>} Resolves when the saved setting has been shown.
     */
    async function addAccessPicker(pane) {
        const d = state.templateDraft;
        const box = $(
            '<div id="tdAccess" class="border rounded p-3 mb-3"><div class="fw-semibold mb-1">Who can use this Alert Type</div><div id="tdAccessBody" class="small text-secondary">Loading…</div></div>',
        );
        pane.children().first().after(box);
        const host = $('#tdAccessBody');
        if (!d.id) {
            host.text('Save the template first, then choose who can use it.');
            return;
        }
        let current;
        try {
            current = await api(`/api/templates/${d.id}/access`);
        } catch {
            host.text('This setting could not be loaded.');
            return;
        }
        const roles = state.roles || [];
        const chosen = new Set(current.roles || []);
        const render = () => {
            host.removeClass('text-secondary').html(
                `<div class="form-check"><input class="form-check-input" type="radio" name="tdAccessMode" id="tdAccessAll" value="all" ${current.everyone ? 'checked' : ''}><label class="form-check-label" for="tdAccessAll">Everyone who can sign in</label></div><div class="form-check mb-2"><input class="form-check-input" type="radio" name="tdAccessMode" id="tdAccessSome" value="some" ${current.everyone ? '' : 'checked'}><label class="form-check-label" for="tdAccessSome">Only the roles I tick</label></div>${
                    current.everyone
                        ? ''
                        : `<div class="mb-2">${[...new Set([...roles, ...chosen])].map((r, i) => `<div class="form-check form-check-inline"><input class="form-check-input td-access-role" type="checkbox" id="tdAccessRole${i}" value="${esc(r)}" ${chosen.has(r) ? 'checked' : ''}><label class="form-check-label" for="tdAccessRole${i}">${esc(r)}</label></div>`).join('')}</div>`
                }<button type="button" class="btn btn-sm btn-outline-primary" id="tdAccessSave">Save access</button>`,
            );
        };
        host.on('change', 'input[name="tdAccessMode"]', function () {
            current.everyone = this.value === 'all';
            render();
        });
        host.on('change', '.td-access-role', function () {
            this.checked ? chosen.add(this.value) : chosen.delete(this.value);
        });
        host.on(
            'click',
            '#tdAccessSave',
            guardEvent(async () => {
                try {
                    await api(`/api/templates/${d.id}/access`, { method: 'PUT', body: { everyone: current.everyone, roles: [...chosen] } });
                    toast('Access saved.');
                } catch (x) {
                    toast(x.message, 'danger');
                }
            }),
        );
        render();
    }
    let quickFieldSectionId = '';
    /**
     * Add a one-line "quick add" form to the Fields tab: type the question, pick the kind of answer and press Add.
     * @param {*} pane - The Fields tab.
     * @returns {void} Updates the relevant UI or state.
     */
    function addQuickField(pane) {
        const d = state.templateDraft;
        const hasSections = d.sections.length > 0;
        const sectionId = d.sections.some((s) => s.id === quickFieldSectionId) ? quickFieldSectionId : d.sections[0]?.id;
        const box = $(
            `<div id="tdQuickField" class="border rounded p-3 mb-3 bg-light"><div class="fw-semibold mb-2">Quick add a field</div>${
                hasSections
                    ? `<div class="row g-2 align-items-end"><div class="col-md-3"><label class="form-label small mb-1" for="qfSection">Section</label><select id="qfSection" class="form-select form-select-sm">${d.sections.map((s) => `<option value="${esc(s.id)}" ${s.id === sectionId ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select></div><div class="col-md-4"><label class="form-label small mb-1" for="qfLabel">Question shown to users</label><input id="qfLabel" class="form-control form-control-sm" maxlength="150" placeholder="e.g. Account number" /></div><div class="col-md-3"><label class="form-label small mb-1" for="qfType">Kind of answer</label><select id="qfType" class="form-select form-select-sm">${$('#fieldType').html()}</select></div><div class="col-md-1"><div class="form-check"><input id="qfRequired" class="form-check-input" type="checkbox"><label class="form-check-label small" for="qfRequired">Must fill</label></div></div><div class="col-md-1"><button type="button" id="qfAdd" class="btn btn-sm btn-primary w-100">Add</button></div></div><div class="form-text">The field code is made for you. Press Enter or Add. Use the pencil on a field for more settings.</div>`
                    : '<div class="text-secondary">Add a section first (tab 2), then you can add fields here.</div>'
            }</div>`,
        );
        pane.children().first().after(box);
        const add = () => {
            const label = String($('#qfLabel').val() || '').trim();
            if (!label) {
                toast('Type the question first.', 'warning');
                $('#qfLabel').trigger('focus');
                return;
            }
            const type = $('#qfType').val() || 'text';
            quickFieldSectionId = $('#qfSection').val();
            const field = normalizeField(
                {
                    sectionId: quickFieldSectionId,
                    name: fieldCodeFromLabel(label, d.fields.map((f) => f.name)),
                    label,
                    type,
                    required: $('#qfRequired').is(':checked'),
                },
                d.fields.length,
            );
            d.fields.push(field);
            draw();
            if (CHOICE_TYPES.includes(type)) {
                toast('Now type the choices for this list.', 'secondary');
                openField(d.fields.length - 1);
            } else $('#qfLabel').trigger('focus');
        };
        $('#qfAdd').on('click', guardEvent(add));
        $('#qfLabel').on(
            'keydown',
            guardEvent((e) => {
                if (e.key !== 'Enter') return;
                e.preventDefault();
                add();
            }),
        );
    }
    /**
     * Populate the section editor from the selected draft section or new-section defaults.
     * @param {*} i - Zero-based item or step index.
     * @returns {void} Updates the relevant UI or state.
     */
    function openSection(i) {
        const s =
            i >= 0 ? state.templateDraft.sections[i] : { name: '', columnSpan: 6, pageNumber: 1, dataViewMode: 'Grid' };
        $('#sectionEditIndex').val(i);
        $('#sectionName').val(s.name);
        $('#sectionPageNumber').val(s.pageNumber || 1);
        $('#sectionColumnSpan').val(s.columnSpan || 6);
        $('#sectionDataViewMode').val(s.dataViewMode || 'Grid');
        showTemplateChildModal('#sectionModal');
    }
    $('#saveSectionBtn')
        .off('click')
        .on(
            'click',
            guardEvent(() => {
                const i = +$('#sectionEditIndex').val(),
                    name = $('#sectionName').val().trim(),
                    columnSpan = Number($('#sectionColumnSpan').val()),
                    pageNumber = Number($('#sectionPageNumber').val());
                if (!name) {
                    toast('Section name is required', 'warning');
                    return;
                }
                if (!Number.isInteger(pageNumber) || pageNumber < 1) {
                    toast('Section page must be 1 or greater', 'warning');
                    return;
                }
                const s = {
                    id: i >= 0 ? state.templateDraft.sections[i].id : uid(),
                    name,
                    order: i >= 0 ? state.templateDraft.sections[i].order : state.templateDraft.sections.length + 1,
                    columnSpan,
                    pageNumber,
                    dataViewMode: $('#sectionDataViewMode').val() || 'Grid',
                };
                if (i >= 0) state.templateDraft.sections[i] = s;
                else state.templateDraft.sections.push(s);
                state.templateDraft.sections.sort((a, b) => a.pageNumber - b.pageNumber || a.order - b.order);
                bootstrap.Modal.getOrCreateInstance('#sectionModal').hide();
                draw();
            }),
        );
    /**
     * Require a section, then populate the field editor and its validation and data-source controls.
     * @param {*} i - Zero-based item or step index.
     * @returns {void} Updates the relevant UI or state.
     */
    function openField(i) {
        if (!state.templateDraft.sections.length) {
            toast('Add a section first', 'warning');
            return;
        }
        const f =
            i >= 0
                ? state.templateDraft.fields[i]
                : normalizeField({ sectionId: state.templateDraft.sections[0].id }, state.templateDraft.fields.length);
        $('#fieldEditIndex').val(i);
        $('#fieldSection').html(
            state.templateDraft.sections.map(
                (s) => `<option value="${s.id}" ${s.id === f.sectionId ? 'selected' : ''}>${esc(s.name)}</option>`,
            ),
        );
        $('#fieldName').val(f.name).data('manual', i >= 0 && !!f.name);
        $('#fieldLabel').val(f.label);
        $('#fieldType').val(f.type);
        $('#fieldRequired').prop('checked', !!f.required);
        $('#fieldSensitive').prop('checked', !!f.sensitive);
        $('#fieldAllowUnmask').prop('checked', f.allowUnmask !== false);
        $('#fieldReadOnly').prop('checked', !!f.readOnly);
        $('#fieldOptions').val(json(f.optionsJson, []).join(','));
        $('#fieldPlaceholder').val(f.placeholder || '');
        $('#fieldHelpText').val(f.helpText || '');
        $('#fieldMinLength').val(f.minLength ?? '');
        $('#fieldMaxLength').val(f.maxLength ?? '');
        $('#fieldMinValue').val(f.minValue ?? '');
        $('#fieldMaxValue').val(f.maxValue ?? '');
        $('#fieldValidationPattern').val(f.validationPattern || '');
        $('#fieldCustomError').val(f.customErrorMessage || '');
        $('#fieldDefaultValue').val(f.defaultValue || '');
        $('#fieldDataSourceMode').val(f.dataSourceMode || 'Static');
        $('#fieldApiUrl').val(f.apiUrl || '');
        $('#fieldApiValueField').val(f.apiValueField || 'value');
        $('#fieldApiTextField').val(f.apiTextField || 'text');
        $('#fieldDependsOnFields').val(f.dependsOnFields || '');
        $('#fieldDependencyJson').val(JSON.stringify(json(f.dependencyValidationsJson, []), null, 2));
        updateFieldLimitVisibility();
        showTemplateChildModal('#fieldModal');
    }
    // The field code follows the question text until the user types a code of their own.
    $('#fieldName')
        .off('input.manualCode')
        .on('input.manualCode', function () {
            $(this).data('manual', true);
        });
    $('#fieldLabel')
        .off('input.autoCode')
        .on('input.autoCode', function () {
            if ($('#fieldName').data('manual')) return;
            const editing = Number($('#fieldEditIndex').val());
            const others = state.templateDraft.fields.filter((_, index) => index !== editing).map((f) => f.name);
            $('#fieldName').val(fieldCodeFromLabel($(this).val(), others));
        });
    $('#saveFieldBtn')
        .off('click')
        .on(
            'click',
            guardEvent(() => {
                try {
                    const i = +$('#fieldEditIndex').val();
                    const dependency = json($('#fieldDependencyJson').val() || '[]', null);
                    if (!dependency) throw new Error('Dependent Validation JSON is invalid.');
                    /**
                     * Read an optional numeric input, preserving null for an empty setting.
                     * @param {*} id - Entity identifier.
                     * @returns {number|null} Computed value for the caller.
                     */
                    const nullableNumber = (id) =>
                        $(id).prop('disabled') || $(id).val() === '' ? null : Number($(id).val());
                    const f = {
                        id: i >= 0 ? state.templateDraft.fields[i].id : uid(),
                        sectionId: $('#fieldSection').val(),
                        name: $('#fieldName').val().trim(),
                        label: $('#fieldLabel').val().trim(),
                        type: $('#fieldType').val(),
                        required: $('#fieldRequired').prop('checked'),
                        sensitive: $('#fieldSensitive').prop('checked'),
                        allowUnmask: $('#fieldAllowUnmask').prop('checked'),
                        readOnly: $('#fieldReadOnly').prop('checked'),
                        order: i >= 0 ? state.templateDraft.fields[i].order : state.templateDraft.fields.length + 1,
                        optionsJson: JSON.stringify(
                            $('#fieldOptions')
                                .val()
                                .split(',')
                                .map((x) => x.trim())
                                .filter(Boolean),
                        ),
                        placeholder: $('#fieldPlaceholder').val().trim(),
                        helpText: $('#fieldHelpText').val().trim(),
                        minLength: nullableNumber('#fieldMinLength'),
                        maxLength: nullableNumber('#fieldMaxLength'),
                        minValue: nullableNumber('#fieldMinValue'),
                        maxValue: nullableNumber('#fieldMaxValue'),
                        validationPattern: $('#fieldRequired').is(':checked')
                            ? $('#fieldValidationPattern').val().trim()
                            : '',
                        customErrorMessage: $('#fieldRequired').is(':checked')
                            ? $('#fieldCustomError').val().trim()
                            : '',
                        defaultValue: $('#fieldDefaultValue').val(),
                        dataSourceMode: $('#fieldDataSourceMode').val() || 'Static',
                        apiUrl: $('#fieldApiUrl').val().trim(),
                        apiValueField: $('#fieldApiValueField').val().trim() || 'value',
                        apiTextField: $('#fieldApiTextField').val().trim() || 'text',
                        dependsOnFields: $('#fieldDependsOnFields').val().trim(),
                        dependencyValidationsJson: JSON.stringify(dependency),
                    };
                    if (!f.name || !f.label) throw new Error('Field name and label are required.');
                    if (f.minLength !== null && f.maxLength !== null && f.minLength > f.maxLength)
                        throw new Error('Min length cannot exceed Max length.');
                    if (f.minValue !== null && f.maxValue !== null && f.minValue > f.maxValue)
                        throw new Error('Min value cannot exceed Max value.');
                    if (
                        ['select', 'multiselect'].includes(f.type) &&
                        f.dataSourceMode === 'Api' &&
                        !f.apiUrl.toLowerCase().startsWith('/api/')
                    )
                        throw new Error(
                            'API dropdown URL must start with /api/ so it is routed through the CATS Gateway.',
                        );
                    if (i >= 0) state.templateDraft.fields[i] = f;
                    else state.templateDraft.fields.push(f);
                    bootstrap.Modal.getOrCreateInstance('#fieldModal').hide();
                    draw();
                } catch (x) {
                    toast(x.message, 'danger');
                }
            }),
        );
    /**
     * Validate the current designer values, persist the draft through the API, and refresh the editor.
     * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
     */
    async function save() {
        try {
            state.templateDraft.code = $('#tdCode').val().trim();
            state.templateDraft.name = $('#tdName').val().trim();
            state.templateDraft.executionMode = $('#tdMode').val();
            const alertListFields = [];
            $('#tdAlertListConfiguration tbody .td-alert-list-row').each(function (index) {
                const row = $(this);
                alertListFields.push({
                    field: String(row.data('field')),
                    label: String(row.find('.td-alert-list-label').val() || '').trim() || String(row.data('label')),
                    showInGrid: row.find('.td-alert-list-grid').is(':checked'),
                    showAsFilter: row.find('.td-alert-list-filter').is(':checked'),
                    order: index,
                    controlType: String(row.data('control-type') || 'text'),
                    optionsJson: String(row.attr('data-options-json') || '[]'),
                });
            });
            state.templateDraft.viewConfiguration = {
                layoutMode: $('#tdLayoutMode').val() || 'Single',
                popupSize: $('#tdPopupSize').val() || 'xl',
                rememberLastSection: $('#tdRememberSection').is(':checked'),
                showSectionNumbers: $('#tdShowSectionNumbers').is(':checked'),
                allowWizardStepClick: $('#tdWizardStepClick').is(':checked'),
                baseDataModes: state.templateDraft.viewConfiguration.baseDataModes,
                sourceColumnMappings: state.templateDraft.viewConfiguration.sourceColumnMappings || [],
                bulkFileFormat: state.templateDraft.viewConfiguration.bulkFileFormat || '',
                bulkFileDelimiter: state.templateDraft.viewConfiguration.bulkFileDelimiter || '',
                alertListFields: alertListFields,
            };
            state.templateDraft.assignmentRules = json($('#tdRules').val(), null);
            if (!state.templateDraft.code || !state.templateDraft.name) throw new Error('Code and name are required.');
            if (!state.templateDraft.sections.length) throw new Error('Add at least one section.');
            if (state.templateDraft.id && !state.templateDraft.fields.length)
                throw new Error(
                    'This existing template has no fields loaded. Reload it after the database recovery before saving.',
                );
            if (!state.templateDraft.assignmentRules) throw new Error('Assignment Rules JSON is invalid.');
            const r = await api('/api/templates', {
                method: 'POST',
                body: {
                    id: state.templateDraft.id,
                    code: state.templateDraft.code,
                    name: state.templateDraft.name,
                    executionMode: state.templateDraft.executionMode,
                    sections: state.templateDraft.sections,
                    fields: state.templateDraft.fields,
                    assignmentRules: state.templateDraft.assignmentRules,
                    viewConfiguration: state.templateDraft.viewConfiguration,
                },
            });
            state.templateDraft = fromRecord(r);
            await loadTemplates(true);
            toast(`Template ${r.name} v${r.version} saved`);
            await renderTemplateDesigner(true);
            $('#tdSelect').val(r.id);
        } catch (x) {
            toast(x.message, 'danger');
        }
    }
    $('#tdLoad').on(
        'click',
        guardEvent(async () => {
            try {
                const id = $('#tdSelect').val();
                if (!id) {
                    state.templateDraft = fresh();
                    draw();
                    return;
                }
                const t = await api('/api/templates/' + id);
                state.templateDraft = fromRecord(t);
                draw();
            } catch (x) {
                toast(x.message, 'danger');
            }
        }),
    );
    if (!preserveDraft) state.templateDraft = fresh();
    draw();
}

export { updateFieldLimitVisibility, renderTemplateDesigner };
