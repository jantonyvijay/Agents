import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';
import { header, toast } from '../ui/feedback.js';

const BASE = '/api/admin/role-permissions';

/**
 * Render the role-wise permission screen: pick a role, tick the permissions it carries, save.
 * Changes reach each user of the role at their next sign-in.
 * @returns {Promise<void>} Resolves after the screen is rendered.
 */
export async function renderRolePermissions() {
    header('Role Permissions', 'Set what each role can do, for all of its users');
    const data = await api(BASE);
    const grants = {};
    Object.entries(data.grants || {}).forEach(([role, list]) => (grants[role.toUpperCase()] = new Set(list)));
    const locked = new Set((data.locked || []).map((x) => `${x.role.toUpperCase()}|${x.permission.toUpperCase()}`));
    const categories = [...new Set(data.permissions.map((p) => p.category))];
    let role = (data.roles[0] || {}).code || '';
    let dirty = false;

    const current = () => (grants[role.toUpperCase()] ||= new Set());
    const isLocked = (permission) => locked.has(`${role.toUpperCase()}|${permission.toUpperCase()}`);

    const roleList = () => {
        const term = String($('#rpRoleSearch').val() || '').trim().toLowerCase();
        const roles = data.roles.filter((item) => !term || `${item.name} ${item.code}`.toLowerCase().includes(term));
        return roles
            .map(
                (r) =>
                    `<button type="button" class="list-group-item list-group-item-action rp-role${r.code === role ? ' active' : ''}" data-role="${esc(r.code)}"><span class="rp-role-copy"><strong>${esc(r.name)}</strong><small>${esc(r.code)}</small></span><span class="rp-user-count" title="Active users"><span aria-hidden="true">●</span> ${r.users || 0}</span></button>`,
            )
            .join('') || '<div class="rp-empty">No roles match your search.</div>';
    };

    const permissionList = () => {
        const term = String($('#rpSearch').val() || '').trim().toLowerCase();
        const granted = current();
        return categories
            .map((category) => {
                const items = data.permissions.filter(
                    (p) => p.category === category && (!term || `${p.code} ${p.name}`.toLowerCase().includes(term)),
                );
                if (!items.length) return '';
                const all = items.every((p) => granted.has(p.code));
                const selected = items.filter((p) => granted.has(p.code)).length;
                return `<section class="rp-category"><div class="rp-category-header"><div><h3>${esc(category)}</h3><span>${selected} of ${items.length} enabled</span></div><label class="form-check-label rp-select-all"><input type="checkbox" class="form-check-input rp-all" data-category="${esc(category)}" ${all ? 'checked' : ''}> Select all</label></div><div class="row g-2">${items
                    .map(
                        (p) =>
                            `<div class="col-md-6"><label class="rp-permission${isLocked(p.code) ? ' is-locked' : ''}"><input type="checkbox" class="form-check-input rp-perm" value="${esc(p.code)}" ${granted.has(p.code) ? 'checked' : ''} ${isLocked(p.code) ? 'disabled title="Always kept for this role"' : ''}><span><strong>${esc(p.name)}</strong><small>${esc(p.code)}${isLocked(p.code) ? ' · Required' : ''}</small></span></label></div>`,
                    )
                    .join('')}</div></section>`;
            })
            .join('') || '<div class="rp-empty">No permissions match this search.</div>';
    };

    const refresh = () => {
        $('#rpRoles').html(roleList());
        $('#rpPerms').html(permissionList());
        const name = (data.roles.find((r) => r.code === role) || {}).name || role;
        $('#rpTitle').text(name);
        $('#rpSummary').text(`${role} · ${current().size} permission${current().size === 1 ? '' : 's'} enabled`);
        $('#rpSave').prop('disabled', !dirty);
        const menuAccess = (data.menus || []).filter((menu) =>
            String(menu.permission || '').split(',').some((permission) => current().has(permission.trim())),
        );
        $('#rpMenuAccess').html(
            menuAccess.length
                ? menuAccess.map((menu) => `<span class="badge text-bg-light border">${esc(menu.label)} <small>${esc(menu.permission)}</small></span>`).join('')
                : '<span class="text-secondary small">No restricted application menus are enabled for this role.</span>',
        );
    };

    $('#viewHost').html(
        `<div class="row g-4 rp-workspace"><aside class="col-lg-4 col-xl-3"><div class="card rp-roles-panel"><div class="rp-roles-header"><div><span class="rp-eyebrow">Access management</span><h2>Roles</h2><p>${data.roles.length} roles available</p></div><input id="rpRoleSearch" class="form-control form-control-sm" placeholder="Find a role" aria-label="Find a role"></div><div id="rpRoles" class="list-group list-group-flush"></div></div></aside>
        <section class="col-lg-8 col-xl-9"><div class="card rp-permissions-panel"><div class="rp-toolbar"><div><span class="rp-eyebrow">Selected role</span><h2 id="rpTitle"></h2><p id="rpSummary"></p></div><div class="rp-toolbar-actions"><input id="rpSearch" class="form-control form-control-sm" placeholder="Search permissions" aria-label="Search permissions"><button id="rpReset" type="button" class="btn btn-sm btn-outline-secondary">Reset changes</button><button id="rpSave" type="button" class="btn btn-sm btn-primary" disabled>Save changes</button></div></div>
        <div class="card-body rp-permissions-body"><div class="rp-notice"><strong>Role-wide access</strong><span>Changes apply when users next sign in. Individual permissions configured in Administration are preserved.</span></div><div class="rp-menu-access"><strong>Menus unlocked by this role</strong><div id="rpMenuAccess" class="d-flex flex-wrap gap-2 mt-2"></div></div><div id="rpPerms"></div></div></div></section></div>`,
    );
    refresh();

    const original = {};
    Object.entries(grants).forEach(([key, set]) => (original[key] = [...set]));
    const restore = () => (grants[role.toUpperCase()] = new Set(original[role.toUpperCase()] || []));

    const host = $('#viewHost').off('.rolePerms');
    host.on('click.rolePerms', '.rp-role', guardEvent(function () {
        if (this.dataset.role === role) return;
        if (dirty && !window.confirm('Discard the unsaved changes to this role?')) return;
        if (dirty) restore();
        dirty = false;
        role = this.dataset.role;
        refresh();
    }));
    host.on('change.rolePerms', '.rp-perm', guardEvent(function () {
        if (this.checked) current().add(this.value);
        else current().delete(this.value);
        dirty = true;
        refresh();
    }));
    host.on('change.rolePerms', '.rp-all', guardEvent(function () {
        data.permissions
            .filter((p) => p.category === this.dataset.category && !isLocked(p.code))
            .forEach((p) => (this.checked ? current().add(p.code) : current().delete(p.code)));
        dirty = true;
        refresh();
    }));
    host.on('input.rolePerms', '#rpSearch', guardEvent(() => $('#rpPerms').html(permissionList())));
    host.on('input.rolePerms', '#rpRoleSearch', guardEvent(() => $('#rpRoles').html(roleList())));
    host.on('click.rolePerms', '#rpReset', guardEvent(() => {
        restore();
        dirty = false;
        refresh();
    }));
    host.on('click.rolePerms', '#rpSave', guardEvent(async () => {
        const saved = await api(`${BASE}/${encodeURIComponent(role)}`, { method: 'PUT', body: { permissions: [...current()] } });
        original[role.toUpperCase()] = [...saved.permissions];
        grants[role.toUpperCase()] = new Set(saved.permissions);
        dirty = false;
        refresh();
        toast('Role permissions saved. Users get them at their next sign-in.');
    }));
}
