import { loadTemplates } from '../api/catalogs.js';
import { header } from '../ui/feedback.js';
import { state } from '../core/state.js';
import { esc } from '../core/utils.js';
import { bindPlatformReportsEvents } from '../events/reports.js';

/**
 * Load and render the platform reports screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderPlatformReports(alertType) {
    await loadTemplates();
    header(alertType ? `Reports - ${alertType}` : 'Reports', 'MIS, Alert Wise and All Alert reports');
    $('#viewHost').html(
        `<div class="card"><div class="card-body"><form id="reportForm" class="row g-2 mb-3"><div class="col-md-2"><select id="reportType" class="form-select"><option>MIS</option><option>ALERTWISE</option><option>ALL</option></select></div><div class="col-md-2"><select id="rfType" class="form-select">${state.templates
            .filter((t) => t.status === 'Published')
            .map((t) => `<option value="${esc(t.code)}">${esc(t.name || t.code)}</option>`)
            .join(
                '',
            )}</select></div><div class="col-md-2"><input id="rfStatus" class="form-control" placeholder="Status"></div><div class="col-md-2"><input id="rfFrom" type="date" class="form-control"></div><div class="col-md-2"><input id="rfTo" type="date" class="form-control"></div><div class="col-md-2"><button class="btn btn-primary">Apply</button> <button id="reportCsv" type="button" class="btn btn-success">CSV</button></div></form><div id="reportHost"></div></div></div>`,
    );
    if (alertType) $('#rfType').val(alertType);
    /**
     * Build report query parameters from the current filter controls.
     * @returns {string} Computed value for the caller.
     */
    const query = () =>
        new URLSearchParams({
            page: 1,
            pageSize: 200,
            alertType: $('#rfType').val(),
            status: $('#rfStatus').val(),
            fromDate: $('#rfFrom').val(),
            toDate: $('#rfTo').val(),
        }).toString();
    return bindPlatformReportsEvents({ query });
}

export { renderPlatformReports };
