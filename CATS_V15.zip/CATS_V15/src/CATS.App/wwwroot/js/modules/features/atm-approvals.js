import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';
import { toast } from '../ui/feedback.js';
import { state } from '../core/state.js';

const when = (value) => (value ? esc(new Date(value).toLocaleString()) : '');
const TYPE_LABELS = { OnUs: 'OnUs penalties', OffUs: 'OffUs penalties', StaffMaster: 'ATM Staff Master' };

/**
 * Create the popup used to review the rows of an upload once; later calls reuse it.
 * @returns {object} The jQuery element and its Bootstrap modal instance.
 */
function rowsModal() {
    if (!$('#atmApprovalRowsModal').length) {
        $('body').append(`<div class="modal fade" id="atmApprovalRowsModal" tabindex="-1" aria-labelledby="atmApprovalRowsTitle" aria-hidden="true">
          <div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
            <div class="modal-header"><h2 class="modal-title h5" id="atmApprovalRowsTitle">Upload rows</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body"></div><div class="modal-footer"></div>
          </div></div></div>`);
    }
    const element = $('#atmApprovalRowsModal');
    return { element, modal: bootstrap.Modal.getOrCreateInstance(element[0]) };
}

/**
 * Checker panel: ATM uploads (and, for penalty files, reopen requests) waiting for approval. Rows open in a popup grid.
 * The uploader can never decide their own upload; the server enforces the same rule.
 * @param {string} host - Selector of the element to render into.
 * @param {object} options - types: the upload types to list (OnUs, OffUs, StaffMaster); reopen: also list reopen requests.
 * @returns {Promise<void>} Resolves after the first load.
 */
async function renderAtmApprovals(host, { types, reopen = false }) {
    const me = String(state.user?.userName || '').toLowerCase();
    const namespace = `.atmApprovals${host.replace(/\W/g, '')}`;
    const root = $(host).off(namespace).html(`<div class="card mt-3"><div class="card-header fw-semibold d-flex justify-content-between align-items-center">
        <span>Pending ATM approvals <span class="small fw-normal text-secondary">(DBOPS Checker)</span></span>
        <button type="button" class="btn btn-sm btn-outline-secondary atm-approval-refresh">Refresh</button></div>
        <div class="card-body"><div class="atm-approval-uploads"></div>${reopen ? '<h3 class="h6 mt-3">Reopen requests</h3><div class="atm-approval-reopen"></div>' : ''}</div></div>`);
    let uploads = [];

    const load = async () => {
        const [batches, requests] = await Promise.all([
            api('/api/atm/uploads?page=1&pageSize=100'),
            reopen ? api('/api/atm/reopen-requests') : Promise.resolve([]),
        ]);
        uploads = batches.filter((x) => x.status === 'Pending' && types.includes(x.fileType));
        root.find('.atm-approval-uploads').html(uploads.length
            ? `<div class="table-responsive"><table class="table table-sm align-middle"><thead><tr><th>Uploaded</th><th>Type</th><th>File</th><th>Maker</th><th></th></tr></thead>
               <tbody>${uploads.map((item) => `<tr><td>${when(item.uploadedAtUtc)}</td><td>${esc(TYPE_LABELS[item.fileType] || item.fileType)}</td><td>${esc(item.fileName)}</td><td>${esc(item.uploadedBy)}</td>
                 <td class="text-nowrap"><button class="btn btn-sm btn-outline-secondary atm-approval-view" data-id="${esc(item.id)}">View</button>
                 ${String(item.uploadedBy).toLowerCase() !== me ? `<button class="btn btn-sm btn-success ms-1 atm-approval-decision" data-kind="upload" data-id="${esc(item.id)}" data-decision="Approve">Approve</button><button class="btn btn-sm btn-outline-danger ms-1 atm-approval-decision" data-kind="upload" data-id="${esc(item.id)}" data-decision="Reject">Reject</button>` : '<span class="small text-secondary ms-2">Awaiting another checker</span>'}</td></tr>`).join('')}</tbody></table></div>`
            : '<p class="text-secondary mb-0">No uploads are waiting for approval.</p>');
        if (reopen) {
            const pending = requests.filter((x) => x.status === 'Pending');
            root.find('.atm-approval-reopen').html(pending.length
                ? `<div class="table-responsive"><table class="table table-sm align-middle"><thead><tr><th>Original alert</th><th>Requested by</th><th>Requested</th><th></th></tr></thead>
                   <tbody>${pending.map((item) => `<tr><td>${esc(item.originalAlertId)}</td><td>${esc(item.requestedBy)}</td><td>${when(item.requestedAtUtc)}</td><td class="text-nowrap">
                     ${String(item.requestedBy).toLowerCase() !== me ? `<button class="btn btn-sm btn-success atm-approval-decision" data-kind="reopen" data-id="${esc(item.id)}" data-decision="Approve">Approve</button><button class="btn btn-sm btn-outline-danger ms-1 atm-approval-decision" data-kind="reopen" data-id="${esc(item.id)}" data-decision="Reject">Reject</button>` : '<span class="small text-secondary">Awaiting another checker</span>'}</td></tr>`).join('')}</tbody></table></div>`
                : '<p class="text-secondary mb-0">No reopen requests are waiting.</p>');
        }
    };

    const decide = async (kind, id, decision) => {
        const remarks = decision === 'Reject' ? window.prompt('Rejection reason (required):') : '';
        if (decision === 'Reject' && !remarks?.trim()) return false;
        const url = kind === 'reopen' ? `/api/atm/reopen-requests/${encodeURIComponent(id)}/decision` : `/api/atm/uploads/${encodeURIComponent(id)}/decision`;
        await api(url, { method: 'POST', body: { decision, remarks: remarks || null } });
        toast(`${kind === 'reopen' ? 'Reopen request' : 'ATM upload'} ${decision === 'Approve' ? 'approved' : 'rejected'}.`);
        await load();
        return true;
    };

    root.on(`click${namespace}`, '.atm-approval-refresh', guardEvent(load));
    root.on(`click${namespace}`, '.atm-approval-decision', guardEvent(async function () {
        await decide(String($(this).data('kind')), String($(this).data('id')), String($(this).data('decision')));
    }));
    root.on(`click${namespace}`, '.atm-approval-view', guardEvent(async function () {
        const id = String($(this).data('id'));
        const item = uploads.find((x) => x.id === id);
        const data = await api(`/api/atm/uploads/${encodeURIComponent(id)}/rows`);
        const { element, modal } = rowsModal();
        element.find('.modal-title').text(data.fileName);
        element.find('.modal-body').html(`<p class="small text-secondary mb-2">${esc(TYPE_LABELS[data.fileType] || data.fileType)} · ${data.total.toLocaleString()} row(s)${data.total > data.rows.length ? ` · first ${data.rows.length} shown` : ''}${item ? ` · uploaded by ${esc(item.uploadedBy)}` : ''}</p>
          <div class="table-responsive"><table class="table table-sm table-hover small text-nowrap"><thead><tr>${data.columns.map((name) => `<th>${esc(name)}</th>`).join('')}</tr></thead>
          <tbody>${data.rows.map((row) => `<tr>${data.columns.map((name) => `<td>${esc(row[name] ?? '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);
        const canDecide = item && String(item.uploadedBy).toLowerCase() !== me;
        element.find('.modal-footer').html(`${canDecide ? '<button type="button" class="btn btn-outline-danger atm-modal-decision" data-decision="Reject">Reject</button><button type="button" class="btn btn-success atm-modal-decision" data-decision="Approve">Approve</button>' : ''}<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>`);
        element.off('click.atmModal').on('click.atmModal', '.atm-modal-decision', guardEvent(async function () {
            if (await decide('upload', id, String($(this).data('decision')))) modal.hide();
        }));
        modal.show();
    }));
    await load();
}

const STATUS_BADGES = { Pending: 'text-bg-warning', Processing: 'text-bg-info', Approved: 'text-bg-success', Rejected: 'text-bg-danger' };

/**
 * Maker checklist: the signed-in user's own ATM uploads with their approval status, so a maker can see at a glance what is
 * still pending, what the checker approved, and why a file was rejected. Rows open in the same popup grid as the checker panel.
 * @param {string} host - Selector of the element to render into.
 * @param {object} options - types: the upload types to list (OnUs, OffUs, StaffMaster).
 * @returns {Promise<void>} Resolves after the first load.
 */
async function renderMyUploads(host, { types }) {
    const namespace = `.atmMyUploads${host.replace(/\W/g, '')}`;
    const root = $(host).off(namespace).html(`<div class="card mt-3"><div class="card-header fw-semibold d-flex justify-content-between align-items-center">
        <span>My uploads <span class="small fw-normal text-secondary">(approval status)</span></span>
        <button type="button" class="btn btn-sm btn-outline-secondary my-upload-refresh">Refresh</button></div>
        <div class="card-body"><div class="my-upload-summary mb-2"></div><div class="my-upload-list"></div></div></div>`);
    let uploads = [];

    const load = async () => {
        const batches = await api('/api/atm/uploads?page=1&pageSize=100&mine=true');
        uploads = batches.filter((x) => types.includes(x.fileType));
        const count = (status) => uploads.filter((x) => x.status === status || (status === 'Pending' && x.status === 'Processing')).length;
        root.find('.my-upload-summary').html(uploads.length
            ? ['Pending', 'Approved', 'Rejected'].map((status) => `<span class="badge ${STATUS_BADGES[status]} me-2">${status}: ${count(status)}</span>`).join('')
            : '');
        root.find('.my-upload-list').html(uploads.length
            ? `<div class="table-responsive"><table class="table table-sm align-middle"><thead><tr><th>Uploaded</th><th>Type</th><th>File</th><th>Status</th><th>Decided by</th><th>Decided on</th><th>Remarks</th><th></th></tr></thead>
               <tbody>${uploads.map((item) => `<tr><td>${when(item.uploadedAtUtc)}</td><td>${esc(TYPE_LABELS[item.fileType] || item.fileType)}</td><td>${esc(item.fileName)}</td>
                 <td><span class="badge ${STATUS_BADGES[item.status] || 'text-bg-secondary'}">${esc(item.status === 'Processing' ? 'Pending' : item.status)}</span></td>
                 <td>${esc(item.decidedBy || '')}</td><td>${when(item.decidedAtUtc)}</td><td class="small">${esc(item.decisionRemarks || '')}</td>
                 <td class="text-nowrap"><button class="btn btn-sm btn-outline-secondary my-upload-view" data-id="${esc(item.id)}">View</button></td></tr>`).join('')}</tbody></table></div>`
            : '<p class="text-secondary mb-0">You have not uploaded any files yet.</p>');
    };

    root.on(`click${namespace}`, '.my-upload-refresh', guardEvent(load));
    root.on(`click${namespace}`, '.my-upload-view', guardEvent(async function () {
        const id = String($(this).data('id'));
        const data = await api(`/api/atm/uploads/${encodeURIComponent(id)}/rows`);
        const { element, modal } = rowsModal();
        element.find('.modal-title').text(data.fileName);
        element.find('.modal-body').html(`<p class="small text-secondary mb-2">${esc(TYPE_LABELS[data.fileType] || data.fileType)} · ${data.total.toLocaleString()} row(s)${data.total > data.rows.length ? ` · first ${data.rows.length} shown` : ''}</p>
          <div class="table-responsive"><table class="table table-sm table-hover small text-nowrap"><thead><tr>${data.columns.map((name) => `<th>${esc(name)}</th>`).join('')}</tr></thead>
          <tbody>${data.rows.map((row) => `<tr>${data.columns.map((name) => `<td>${esc(row[name] ?? '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);
        element.find('.modal-footer').html('<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>');
        element.off('click.atmModal');
        modal.show();
    }));
    await load();
}

export { renderAtmApprovals, renderMyUploads };
