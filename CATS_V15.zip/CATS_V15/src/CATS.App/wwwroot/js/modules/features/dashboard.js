import { observeTask } from '../events/guard.js';
import { header, loading, toast } from '../ui/feedback.js';
import { loadTemplates, loadRoles } from '../api/catalogs.js';
import { has } from '../core/permissions.js';
import { api } from '../api/client.js';
import { state } from '../core/state.js';
import { esc, parseJsonArray, dictionaryValue } from '../core/utils.js';
import {
    bindDashboardEvents,
    bindOverviewDashboardEvents,
    bindConfiguredTemplateDashboardEvents,
    bindTemplateDashboardManagerEvents,
} from '../events/dashboard.js';
import { alertTypeOptions, templateOptions } from '../ui/options.js';
import { guardEvent } from '../events/guard.js';
import { navigate } from '../core/navigation.js';
import { dashboardFieldLabel } from '../business/dashboard.js';

/**
 * Load and render the dashboard screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderDashboard() {
    header('Dashboard', '');
    loading();
    await loadTemplates();
    let templateDashboards = [];
    try {
        templateDashboards = has('DASHBOARD.VIEW') ? await api('/api/platform/dashboard/templates') : [];
    } catch {
        templateDashboards = [];
    }
    const role = String(state.user?.roleCode || '').toUpperCase();
    const dedicatedCode =
        role === 'DT_USER' ? 'DT_DD_MONEY_MULE_DT_USER' : role === 'DT_VERIFIER' ? 'DT_DD_MONEY_MULE_DT_VERIFIER' : '';
    const dedicatedDashboard = dedicatedCode
        ? templateDashboards.find((x) => String(x.code).toUpperCase() === dedicatedCode)
        : null;
    if (dedicatedCode) {
        if (!dedicatedDashboard) {
            $('#viewHost').html(
                '<div class="alert alert-warning">The role-specific Desktop Due Diligence Money Mule dashboard is not configured.</div>',
            );
            return;
        }
        $('#viewHost').html('<div id="dashboardContent"></div>');
        await renderConfiguredTemplateDashboard(dedicatedDashboard.id, '#dashboardContent');
        return;
    }
    const selector = templateDashboards
        .map((x) => `<option value="${esc(x.id)}">${esc(x.title || x.name)}</option>`)
        .join('');
    $('#viewHost').html(`<div class="card mb-3"><div class="card-body"><div class="row g-2 align-items-end">
      <div class="col-lg-5"><label class="form-label">Dashboard</label><select id="dashboardMode" class="form-select"><option value="overview">Overview / Aging Matrix</option>${selector}</select></div>
      <div class="col-lg-7 d-flex justify-content-lg-end gap-2"><button id="manageTemplateDashboards" class="btn btn-outline-primary ${has('DASHBOARD.CONFIGURE') ? '' : 'd-none'}">⚙ Manage Alert Type Dashboards</button></div>
    </div></div></div><div id="dashboardContent"></div>`);
    return bindDashboardEvents({});
}

/**
 * Load and render the overview dashboard screen, then initialize its controls and event handlers.
 * @param {*} host - Selector or element receiving the rendered content.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderOverviewDashboard(host) {
    const firstAlertType = state.templates.find((template) => template.status === 'Published');
    /**
     * Set the overview heading from the chosen published alert template.
     * @param {*} templateId - Selected alert template identifier.
     * @returns {void} Updates the relevant UI or state.
     */
    const updateDashboardHeader = (templateId) => {
        const template = state.templates.find((item) => item.id === templateId);
        header('Dashboard', template ? `Alert Type: ${template.name || template.code}` : 'No published alert types');
    };
    updateDashboardHeader(firstAlertType?.id);
    $(host).html(`<div class="card mb-3"><div class="card-body"><form id="dashFilter" class="row g-2 align-items-end">
                <div class="col-lg-4"><label class="form-label">Alert Type <span class="text-danger">*</span></label><select id="dashAlertType" class="form-select" required>${alertTypeOptions(firstAlertType?.id || '', true)}</select></div>
      <div class="col-lg-2"><label class="form-label">Branch</label><input id="dashBranch" class="form-control" /></div>
      <div class="col-lg-2"><label class="form-label">Status</label><select id="dashStatus" class="form-select"><option value="">Active statuses</option><option>Pending</option><option>InProgress</option><option>Query</option></select></div>
      <div class="col-lg-2"><label class="form-label">View</label><select id="dashView" class="form-select"><option value="aging">Aging Matrix</option><option value="type">Alert Type Summary</option></select></div>
      <div class="col-12 d-grid d-lg-flex justify-content-lg-end"><button class="btn btn-primary px-4">Apply Filters</button></div>
    </form></div></div><div id="dashBody"></div>`);
    /**
     * Fetch the current screen data using its filters and pagination, then render the results and their actions.
     * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
     */
    async function load() {
        $('#dashBody').html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>');
        const q = new URLSearchParams({
            templateId: $('#dashAlertType').val() || '',
            branchCode: $('#dashBranch').val() || '',
            status: $('#dashStatus').val() || '',
        });
        const d = await api('/api/dashboard/aging?' + q.toString());
        let html = '';
        if ($('#dashView').val() === 'type') {
            const types = Object.values(
                d.rows.reduce((all, row) => {
                    const name = row.alertType || 'Unspecified';
                    all[name] ||= { name, total: 0, breached: 0, rows: [] };
                    all[name].total += row.total;
                    all[name].breached += row.counts['31+ Days'] || 0;
                    all[name].rows.push(row);
                    return all;
                }, {}),
            ).sort((a, b) => b.total - a.total);
            html += `<div class="row g-3 mb-3">${types.map((x) => `<div class="col-md-6 col-xl-4"><button class="card alert-type-card w-100 text-start" data-type="${esc(x.name)}"><div class="card-body"><div class="d-flex justify-content-between"><span class="fw-semibold">${esc(x.name)}</span><span class="badge text-bg-primary">${x.total}</span></div><div class="small text-secondary mt-2">${x.rows.length} template(s) · ${x.breached} aged 31+ days</div></div></button></div>`).join('')}</div>`;
            $('#dashBody').html(html);
            $('.alert-type-card').on(
                'click',
                guardEvent(function () {
                    observeTask(navigate('alerts', { page: 1, pageSize: 20, alertType: $(this).data('type'), scopeToMe: true }));
                }),
            );
            return;
        }
        html += `<div class="card"><div class="card-header bg-white fw-semibold">Alert Aging</div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Alert Type</th>${d.buckets.map((b) => `<th class="text-center">${esc(b.name)}</th>`).join('')}<th class="text-center">Total</th></tr></thead><tbody>`;
        for (const r of d.rows) {
            html += `<tr><td>${esc(r.alertType)}</td>`;
            for (const b of d.buckets) {
                const c = r.counts[b.name] || 0;
                html += `<td class="text-center"><button class="btn btn-sm ${c ? 'btn-outline-primary' : 'btn-light'} click-count" data-template="${r.templateId}" data-type="${esc(r.alertType)}" data-from="${b.fromDays}" data-to="${b.toDays ?? ''}" ${c ? '' : 'disabled'}>${c}</button></td>`;
            }
            html += `<td class="text-center"><button class="btn btn-sm btn-primary click-total" data-template="${r.templateId}" data-type="${esc(r.alertType)}">${r.total}</button></td></tr>`;
        }
        html += '</tbody></table></div></div>';
        $('#dashBody').html(html);
        $('.click-count').on(
            'click',
            guardEvent(function () {
                observeTask(
                    navigate('alerts', {
                        page: 1,
                        pageSize: 20,
                        templateId: $(this).data('template'),
                        alertType: $(this).data('type'),
                        agingFrom: $(this).data('from'),
                        agingTo: $(this).data('to') || null,
                        scopeToMe: true,
                    }),
                );
            }),
        );
        $('.click-total').on(
            'click',
            guardEvent(function () {
                observeTask(
                    navigate('alerts', {
                        page: 1,
                        pageSize: 20,
                        templateId: $(this).data('template'),
                        alertType: $(this).data('type'),
                        scopeToMe: true,
                    }),
                );
            }),
        );
    }
    return bindOverviewDashboardEvents({ firstAlertType, updateDashboardHeader, load });
}

/**
 * Load and render the configured template dashboard screen, then initialize its controls and event handlers.
 * @param {*} id - Entity identifier.
 * @param {*} host - Selector or element receiving the rendered content.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderConfiguredTemplateDashboard(id, host) {
    $(host).html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>');
    const config = await api(`/api/platform/dashboard/templates/${encodeURIComponent(id)}`);
    const searchFields = parseJsonArray(config.searchFieldsJson, ['AlertNo', 'AccountId', 'CustomerId']);
    $(host).html(
        `<div class="card mb-3 border-0 shadow-sm"><div class="card-header text-white template-dashboard-title"><div class="fw-semibold fs-5">${esc(config.title)}</div><div class="small opacity-75">${esc(config.description || '')}</div></div><div class="card-body ${searchFields.length ? '' : 'd-none'}"><form id="tdSearch" class="row g-2 align-items-end">${searchFields.map((f) => `<div class="col-md-3"><label class="form-label">${esc(dashboardFieldLabel(f))}</label><input class="form-control td-search" data-field="${esc(f)}"></div>`).join('')}<div class="col-md-3 d-flex gap-2"><button class="btn btn-primary flex-fill">Search</button><button type="button" id="tdClear" class="btn btn-outline-secondary">Clear</button></div></form></div></div><div id="tdResults"></div>`,
    );
    /**
     * Fetch the current screen data using its filters and pagination, then render the results and their actions.
     * @param {*} [page] - One-based result page.
     * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
     */
    async function load(page = 1) {
        $('#tdResults').html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>');
        const q = new URLSearchParams({ page, pageSize: config.pageSize || 20 });
        $('.td-search').each(function () {
            const field = $(this).data('field'),
                value = $(this).val();
            if (value) {
                if (String(field).toLowerCase() === 'alertno') q.set('alertNo', value);
                else if (String(field).toLowerCase() === 'accountid') q.set('accountId', value);
                else if (String(field).toLowerCase() === 'customerid') q.set('customerId', value);
                else q.set('search', value);
            }
        });
        const d = await api(`/api/platform/dashboard/templates/${encodeURIComponent(id)}/data?${q}`),
            groups = parseJsonArray(d.dashboard.groupByFieldsJson, ['BranchCode']),
            metrics = parseJsonArray(d.dashboard.metricsJson, []),
            columns = parseJsonArray(d.dashboard.gridColumnsJson, [
                'AlertNo',
                'AlertType',
                'BranchCode',
                'Status',
                'CurrentStageName',
            ]);
        const metricTitles = metrics.length ? metrics.map((x) => x.title) : ['Total Record', 'Pending'];
        const showSerial = String(d.dashboard.code || '').toUpperCase() === 'DT_DD_MONEY_MULE_DT_VERIFIER';
        const summaryOnly = ['DT_DD_MONEY_MULE_DT_USER', 'DT_DD_MONEY_MULE_DT_VERIFIER'].includes(
            String(d.dashboard.code || '').toUpperCase(),
        );
        /**
         * Format a dashboard metric using its configured drill-down destination.
         * @param {*} value - Value to validate or apply.
         * @param {*} mi - Value used by this operation.
         * @param {*} rowIndex - Value used by this operation.
         * @returns {string} Computed value for the caller.
         */
        const metricCell = (value, mi, rowIndex) => {
            const count = Number(value || 0),
                text = count.toLocaleString();
            const metric = metrics[mi];
            const canDrill = !!metric?.code && (!summaryOnly || String(metric.code).toUpperCase() === 'PENDING');
            return canDrill && count > 0
                ? `<button class="btn btn-link p-0 fw-semibold ${rowIndex === null ? 'td-total-count' : 'td-summary-count'}" ${rowIndex === null ? '' : `data-index="${rowIndex}"`} data-metric-index="${mi}">${text}</button>`
                : `<span class="fw-semibold">${text}</span>`;
        };
        const summaryRows = d.summaryRows
            .map(
                (r, ri) =>
                    `<tr>${showSerial ? `<td>${ri + 1}</td>` : ''}${groups.map((x) => `<td>${esc(dictionaryValue(r, x))}</td>`).join('')}${metricTitles.map((x, mi) => `<td class="text-center">${metricCell(dictionaryValue(r, x), mi, ri)}</td>`).join('')}</tr>`,
            )
            .join('');
        const totalRow =
            showSerial && d.summaryRows.length
                ? `<tr class="fw-semibold table-light"><td colspan="${groups.length + 1}" class="text-end">Total</td>${metricTitles
                      .map(
                          (x, mi) =>
                              `<td class="text-center">${metricCell(
                                  d.summaryRows.reduce((sum, row) => sum + Number(dictionaryValue(row, x) || 0), 0),
                                  mi,
                                  null,
                              )}</td>`,
                      )
                      .join('')}</tr>`
                : '';
        let h = `<div class="card mb-3"><div class="table-responsive"><table class="table table-sm table-bordered align-middle mb-0 template-summary-table"><thead><tr>${showSerial ? '<th>Sr No.</th>' : ''}${groups.map((x) => `<th>${esc(dashboardFieldLabel(x))}</th>`).join('')}${metricTitles.map((x) => `<th class="text-center">${esc(x)}</th>`).join('')}</tr></thead><tbody>${summaryRows || `<tr><td colspan="${groups.length + metricTitles.length + (showSerial ? 1 : 0)}" class="text-center text-secondary py-4">No records</td></tr>`}${totalRow}</tbody></table></div></div>`;
        if (!summaryOnly)
            h += `<div class="card"><div class="card-header bg-white d-flex justify-content-between"><span class="fw-semibold">Alert Records</span><span class="text-secondary small">${d.totalRecords.toLocaleString()} records</span></div><div class="table-responsive"><table class="table table-sm table-hover table-bordered align-middle mb-0 template-detail-grid"><thead><tr>${columns.map((x) => `<th>${esc(dashboardFieldLabel(x))}</th>`).join('')}</tr></thead><tbody>${d.rows.map((r) => `<tr class="td-alert-row" data-id="${esc(dictionaryValue(r, 'Id'))}">${columns.map((x) => `<td>${esc(dictionaryValue(r, x) ?? '')}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${columns.length}" class="text-center text-secondary py-4">No matching alerts</td></tr>`}</tbody></table></div><div class="card-footer bg-white d-flex justify-content-between"><span>Page ${d.page}</span><div><button class="btn btn-sm btn-outline-primary td-prev" ${d.page <= 1 ? 'disabled' : ''}>Previous</button> <button class="btn btn-sm btn-outline-primary td-next" ${d.page * d.pageSize >= d.totalRecords ? 'disabled' : ''}>Next</button></div></div></div>`;
        else if (!d.totalRecords)
            h +=
                '<div class="alert alert-info">No Desktop Due Diligence Money Mule alerts are currently available for this role. Create or upload alerts using the DT_DD_MONEY_MULE alert type.</div>';
        $('#tdResults').html(h);
        $('.td-alert-row').on(
            'click',
            guardEvent(function () {
                observeTask(navigate('detail', $(this).data('id')));
            }),
        );
        $('.td-prev').on(
            'click',
            guardEvent(() => load(d.page - 1)),
        );
        $('.td-next').on(
            'click',
            guardEvent(() => load(d.page + 1)),
        );
        /**
         * Translate dashboard metrics and group values into the existing alert-list filter payload.
         * @param {*} row - Source data record.
         * @param {*} metricIndex - Value used by this operation.
         * @returns {void} Updates the relevant UI or state.
         */
        function drillDown(row, metricIndex) {
            const groupFilters = {};
            if (row) groups.forEach((group) => (groupFilters[group] = String(dictionaryValue(row, group) ?? '')));
            const metric = metrics[metricIndex];
            if (!metric?.code) return;
            const filters = {
                page: 1,
                pageSize: config.pageSize || 20,
                templateId: d.dashboard.templateId,
                alertType: d.dashboard.alertType || '',
                dashboardId: id,
                dashboardGroupFiltersJson: JSON.stringify(groupFilters),
                dashboardMetricCode: metric?.code || '',
                dashboardMetricTitle: metric?.title || 'Total',
            };
            if (groupFilters.BranchCode) filters.branchCode = groupFilters.BranchCode;
            if (String(metric?.type || '').toUpperCase() === 'STATUSCOUNT') filters.status = metric.value || '';
            $('.td-search').each(function () {
                const field = String($(this).data('field') || ''),
                    value = $(this).val();
                if (value) {
                    if (field.toLowerCase() === 'alertno') filters.alertNo = value;
                    else if (field.toLowerCase() === 'accountid') filters.accountId = value;
                    else if (field.toLowerCase() === 'customerid') filters.customerId = value;
                    else filters.search = value;
                }
            });
            observeTask(navigate('alerts', filters));
        }
        $('.td-summary-count').on(
            'click',
            guardEvent(function () {
                drillDown(d.summaryRows[Number($(this).data('index'))], Number($(this).data('metric-index')));
            }),
        );
        $('.td-total-count').on(
            'click',
            guardEvent(function () {
                drillDown(null, Number($(this).data('metric-index')));
            }),
        );
    }
    return bindConfiguredTemplateDashboardEvents({ load });
}

/**
 * Load and render the template dashboard manager screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderTemplateDashboardManager() {
    header('Alert Type Dashboard Configuration', 'Central Team / Admin permission controlled configuration');
    await loadTemplates();
    const dashboards = await api('/api/platform/dashboard/templates?includeInactive=true');
    $('#viewHost').html(
        `<div class="d-flex justify-content-end mb-3"><button id="addTemplateDashboard" class="btn btn-primary">+ New Dashboard</button></div><div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Name</th><th>Alert Type</th><th>Filter</th><th>Roles</th><th>Status</th><th></th></tr></thead><tbody>${dashboards.map((x) => `<tr><td><b>${esc(x.title)}</b><div class="small text-secondary">${esc(x.name)}</div></td><td>${esc(state.templates.find((t) => t.id === x.templateId)?.code || '')}</td><td>${esc(x.alertType || 'All')}</td><td>${esc((x.roleCodes || []).join(', '))}</td><td>${x.isActive ? 'Active' : 'Inactive'}</td><td><button class="btn btn-sm btn-outline-primary edit-td" data-id="${x.id}">Edit</button></td></tr>`).join('')}</tbody></table></div></div>`,
    );
    /**
     * Load roles, populate the dashboard configuration modal, and bind its save workflow.
     * @param {*} [item] - Existing configuration record or defaults for creation.
     * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
     */
    async function open(item = {}) {
        await loadRoles();
        const metrics = parseJsonArray(item.metricsJson, [
            { code: 'TOTAL', title: 'Total Record', type: 'Count' },
            { code: 'PENDING', title: 'Pending', type: 'StatusCount', value: 'Pending' },
        ]);
        const modal = $(
            `<div class="modal fade" id="templateDashboardModal"><div class="modal-dialog modal-xl"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Template Dashboard</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="templateDashboardForm"><div class="modal-body"><div class="row g-3"><div class="col-md-4"><label class="form-label">Name</label><input id="tdmName" class="form-control" value="${esc(item.name || '')}" required></div><div class="col-md-4"><label class="form-label">Dashboard Title</label><input id="tdmTitle" class="form-control" value="${esc(item.title || '')}" required></div><div class="col-md-4"><label class="form-label">Template</label><select id="tdmTemplate" class="form-select" required>${templateOptions(item.templateId || '')}</select></div><div class="col-md-4"><label class="form-label">Alert Type (blank = all)</label><input id="tdmAlertType" class="form-control" value="${esc(item.alertType || '')}"></div><div class="col-md-8"><label class="form-label">Description</label><input id="tdmDescription" class="form-control" value="${esc(item.description || '')}"></div><div class="col-md-6"><label class="form-label">Group By fields (comma)</label><input id="tdmGroups" class="form-control" value="${esc(parseJsonArray(item.groupByFieldsJson, ['BranchCode']).join(','))}"><div class="form-text">Example: BranchCode, AnalystName</div></div><div class="col-md-6"><label class="form-label">Search fields (comma)</label><input id="tdmSearch" class="form-control" value="${esc(parseJsonArray(item.searchFieldsJson, ['AlertNo', 'AccountId', 'CustomerId']).join(','))}"></div><div class="col-12"><label class="form-label">Grid columns (comma)</label><input id="tdmColumns" class="form-control" value="${esc(parseJsonArray(item.gridColumnsJson, ['AlertNo', 'AccountId', 'CustomerId', 'AlertType', 'BranchCode', 'Status']).join(','))}"></div><div class="col-12 d-none" hidden><label class="form-label">Metrics JSON</label><textarea id="tdmMetrics" class="form-control font-monospace" rows="6">${esc(JSON.stringify(metrics, null, 2))}</textarea><div class="form-text">Types: Count, StatusCount, FieldEquals, FieldNotEmpty.</div></div><div class="col-md-8"><label class="form-label">Visible Roles</label><div class="border rounded p-2" style="max-height:150px;overflow:auto">${state.roles.map((r) => `<label class="form-check"><input class="form-check-input tdm-role" type="checkbox" value="${esc(r)}" ${(item.roleCodes || []).includes(r) ? 'checked' : ''}><span class="form-check-label">${esc(r)}</span></label>`).join('')}</div></div><div class="col-md-2"><label class="form-label">Page Size</label><input id="tdmPageSize" type="number" class="form-control" value="${item.pageSize || 20}"></div><div class="col-md-2"><label class="form-label">Order</label><input id="tdmOrder" type="number" class="form-control" value="${item.displayOrder || 1}"></div><div class="col-6 form-check ms-2"><input id="tdmDefault" class="form-check-input" type="checkbox" ${item.isDefault ? 'checked' : ''}><label class="form-check-label">Default for role</label></div><div class="col-5 form-check"><input id="tdmActive" class="form-check-input" type="checkbox" ${item.isActive === false ? '' : 'checked'}><label class="form-check-label">Active</label></div></div></div><div class="modal-footer"><button class="btn btn-light" type="button" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Dashboard</button></div></form></div></div></div>`,
        ).appendTo(document.body);
        new bootstrap.Modal(modal[0]).show();
        modal.on(
            'hidden.bs.modal',
            guardEvent(() => modal.remove()),
        );
        $('#templateDashboardForm').on(
            'submit',
            guardEvent(async (e) => {
                e.preventDefault();
                let metricsJson;
                try {
                    metricsJson = JSON.stringify(JSON.parse($('#tdmMetrics').val()));
                } catch {
                    return toast('Metrics JSON is invalid.', 'danger');
                } /**
                 * Split comma-separated configuration text into trimmed nonempty values.
                 * @param {*} id - Entity identifier.
                 * @returns {Array} Computed value for the caller.
                 */
                const split = (id) =>
                    $(id)
                        .val()
                        .split(',')
                        .map((x) => x.trim())
                        .filter(Boolean);
                await api('/api/platform/dashboard/templates', {
                    method: 'POST',
                    body: {
                        id: item.id || '',
                        code: item.code || '',
                        name: $('#tdmName').val(),
                        title: $('#tdmTitle').val(),
                        description: $('#tdmDescription').val(),
                        templateId: $('#tdmTemplate').val(),
                        alertType: $('#tdmAlertType').val(),
                        groupByFieldsJson: JSON.stringify(split('#tdmGroups')),
                        searchFieldsJson: JSON.stringify(split('#tdmSearch')),
                        gridColumnsJson: JSON.stringify(split('#tdmColumns')),
                        metricsJson,
                        pageSize: Number($('#tdmPageSize').val()),
                        displayOrder: Number($('#tdmOrder').val()),
                        isDefault: $('#tdmDefault').is(':checked'),
                        isActive: $('#tdmActive').is(':checked'),
                        roleCodes: $('.tdm-role:checked')
                            .map((_, x) => x.value)
                            .get(),
                    },
                });
                bootstrap.Modal.getInstance(modal[0]).hide();
                toast('Template dashboard saved.', 'success');
                observeTask(renderTemplateDashboardManager());
            }),
        );
    }
    /**
     * Adjust dashboard configuration labels and restore the selected alert type after the modal renders.
     * @param {*} [selected] - Currently selected option value.
     * @returns {void} Updates the relevant UI or state.
     */
    const normalizeAlertTypeDashboardModal = (selected = '') =>
        setTimeout(() => {
            const modal = $('#templateDashboardModal');
            modal.find('.modal-title').text('Alert Type Dashboard');
            modal
                .find('label')
                .filter(function () {
                    return $(this).text().trim() === 'Template';
                })
                .text('Alert Type');
            $('#tdmTemplate').html(alertTypeOptions(selected, true));
        }, 0);
    return bindTemplateDashboardManagerEvents({ dashboards, open, normalizeAlertTypeDashboardModal });
}

export { renderDashboard, renderOverviewDashboard, renderConfiguredTemplateDashboard, renderTemplateDashboardManager };
