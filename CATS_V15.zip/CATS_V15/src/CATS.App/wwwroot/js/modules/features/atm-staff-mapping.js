import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';
import { header, toast } from '../ui/feedback.js';
import { has } from '../core/permissions.js';
import { downloadFile } from '../ui/downloads.js';

const BASE = '/api/atm/staff-mapping';
const SEPARATORS = [
    ['', 'Auto-detect (comma or tilde)'],
    [',', 'Comma ( , )'],
    ['~', 'Tilde ( ~ )'],
    ['|', 'Pipe ( | )'],
    [';', 'Semicolon ( ; )'],
    ['\t', 'Tab'],
];
const separatorNames = { ',': 'comma', '~': 'tilde', '|': 'pipe', ';': 'semicolon', '\t': 'tab' };

/**
 * Accepted file extensions for the configured upload format.
 * @param {string} format - Configured format: '', Csv, Txt or Excel.
 * @returns {{accept: string, label: string}} Value for the file input and a readable description.
 */
function fileKind(format) {
    if (format === 'Excel') return { accept: '.xlsx', label: 'an Excel (.xlsx) workbook' };
    if (format === 'Csv') return { accept: '.csv,text/csv', label: 'a .csv file' };
    if (format === 'Txt') return { accept: '.txt,text/plain', label: 'a .txt file' };
    return { accept: '.csv,.txt,text/csv,text/plain', label: 'a .csv or .txt file' };
}

const orderedMappings = (config) =>
    [...config.mappings].sort((a, b) => (a.order || 1e9) - (b.order || 1e9));

/**
 * Masters › ATM › Staff Mapping: bulk upload and single entry.
 * @param {string} [atmId] - ATM to load into the single-entry form, e.g. from the list page.
 * @returns {Promise<void>} Resolves after the page is rendered.
 */
async function renderAtmStaffUpload(atmId) {
    header('Staff Mapping - Upload & Entry', 'Masters › ATM › Staff Mapping · DBOPS Maker uploads or enters; DBOPS Checker approves');
    const canUpload = has('ATM.UPLOAD');
    let config = await api(`${BASE}/config`);
    const entryFields = () => orderedMappings(config).filter((item) => !config.columns.find((c) => c.name === item.field)?.system);
    const columnInfo = (name) => config.columns.find((c) => c.name.toLowerCase() === String(name).toLowerCase());

    const render = () => {
        const kind = fileKind(config.format);
        const separator = separatorNames[config.delimiter];
        $('#viewHost').html(`
          <div class="row g-3">
            <div class="col-12 d-flex justify-content-between align-items-center"><span class="small text-secondary">DBOPS Maker uploads or enters; a DBOPS Checker approves before the master changes.</span><button type="button" class="btn btn-sm btn-outline-secondary staff-back">← Back to list</button></div>
            <div class="col-xl-5"><div class="card h-100"><div class="card-header fw-semibold">Bulk upload</div><div class="card-body">
              <p class="small text-secondary">Upload ${esc(kind.label)}${separator ? ` separated by ${esc(separator)}` : ''}. Use <em>Download sample file</em> for the exact layout.</p>
              ${canUpload ? `<form id="staffUploadForm">
                <input id="staffFile" class="form-control mb-2" type="file" accept="${esc(kind.accept)}" required />
                <div class="d-flex gap-2"><button class="btn btn-primary" type="submit">Upload for approval</button>
                <button id="staffSample" class="btn btn-outline-secondary" type="button">Download sample file</button></div>
                <div class="form-text mt-2">Existing ATMs are updated and new ATMs are added once a DBOPS Checker approves the upload.</div>
              </form>` : '<div class="alert alert-info mb-0">You do not have the DBOPS Maker (ATM upload) permission.</div>'}
            </div></div></div>
            <div class="col-xl-7"><div class="card h-100"><div class="card-header fw-semibold">Single entry</div><div class="card-body">
              ${canUpload ? `<form id="staffEntryForm">
                <div class="row g-2">${entryFields().map((item) => {
                    const info = columnInfo(item.field);
                    const required = item.field === 'ATM_ID';
                    const type = info?.kind === 'DateTime' ? 'date' : 'text';
                    return `<div class="col-md-${item.field === 'ATM_ID' || item.field === 'STATE' ? 6 : 4}"><label class="form-label small mb-1" for="staff_${esc(item.field)}">${esc(item.sourceColumn)}${required ? ' <span class="text-danger">*</span>' : ''}</label>
                      <div class="${required ? 'input-group' : ''}"><input id="staff_${esc(item.field)}" data-field="${esc(item.field)}" class="form-control form-control-sm staff-entry-input" type="${type}" ${info?.maxLength ? `maxlength="${info.maxLength}"` : ''} ${required ? 'required' : ''}>
                      ${required ? '<button id="staffLoad" class="btn btn-sm btn-outline-secondary" type="button" title="Load the existing mapping for this ATM">Load</button>' : ''}</div></div>`;
                }).join('')}</div>
                <div class="mt-3 d-flex gap-2"><button class="btn btn-primary" type="submit">Send for approval</button><button class="btn btn-outline-secondary" type="reset">Clear</button></div>
                <div class="form-text mt-2">Leave a field blank to clear it for the ATM. Entries are approved by a DBOPS Checker like a file.</div>
              </form>` : '<p class="text-secondary mb-0">Single entry needs the DBOPS Maker permission.</p>'}
            </div></div></div>
          </div>`);
    };

    render();
    // #viewHost is reused by every page, so these delegated handlers are namespaced and cleared on each visit.
    const host = $('#viewHost').off('.staffUpload .staffConfig .staffList');
    host.on('click.staffUpload', '#staffSample', guardEvent(() => downloadFile(`${BASE}/sample`)));
    host.on('submit.staffUpload', '#staffUploadForm', guardEvent(async (event) => {
        event.preventDefault();
        const file = $('#staffFile')[0].files[0];
        if (!file) return;
        const form = new FormData();
        form.append('file', file);
        const result = await api(`${BASE}/uploads`, { method: 'POST', body: form });
        toast(`${result.rowCount} row(s) uploaded for checker approval.`);
        event.currentTarget.reset();
    }));
    const loadExisting = async (id) => {
        const record = await api(`${BASE}/records/${encodeURIComponent(id)}`);
        $('.staff-entry-input').each(function () {
            const value = record[$(this).data('field')] || '';
            $(this).val($(this).attr('type') === 'date' ? String(value).slice(0, 10) : value);
        });
    };
    host.on('click.staffUpload', '#staffLoad', guardEvent(async () => {
        const id = String($('#staff_ATM_ID').val() || '').trim();
        if (!id) return toast('Enter an ATM ID first.', 'warning');
        try {
            await loadExisting(id);
        } catch (error) {
            toast(error.message, 'warning');
        }
    }));
    host.on('submit.staffUpload', '#staffEntryForm', guardEvent(async (event) => {
        event.preventDefault();
        const values = {};
        $('.staff-entry-input').each(function () {
            values[$(this).data('field')] = String($(this).val() || '').trim();
        });
        const result = await api(`${BASE}/entries`, { method: 'POST', body: { values } });
        toast(`${result.fileName} sent for checker approval.`);
        event.currentTarget.reset();
    }));
    host.on('click.staffUpload', '.staff-back', guardEvent(() => openView('atmStaffList')));
    if (atmId) {
        try {
            await loadExisting(atmId);
        } catch (error) {
            toast(error.message, 'warning');
        }
    }
}

/**
 * Open another Staff Mapping page. Loaded lazily because the navigation module imports this one.
 * @param {string} view - Target view name.
 * @param {string} [arg] - Optional view argument.
 * @returns {Promise<void>} Resolves after navigation.
 */
async function openView(view, arg) {
    const { navigate } = await import('../core/navigation.js');
    await navigate(view, arg);
}

/**
 * Masters › ATM › Staff Mapping › Column mapping: the file layout and file-to-table mapping, for administrators and the central team.
 * @returns {Promise<void>} Resolves after the page is rendered.
 */
async function renderAtmStaffConfig() {
    header('Staff Mapping - Column Mapping', 'Masters › ATM › Staff Mapping · file layout and column mapping');
    let config = await api(`${BASE}/config`);
    if (!config.canConfigure) throw new Error('The ATM master configuration permission is required.');
    let draft = null;
    const render = () => {
        $('#viewHost').html(`<div class="mb-2"><button type="button" class="btn btn-sm btn-outline-secondary staff-back">← Back to list</button></div>
          <div class="card"><div class="card-header fw-semibold">Column mapping &amp; file layout</div><div class="card-body" id="staffConfig"></div></div>`);
        renderConfig();
    };
    const renderConfig = () => {
        draft ||= { format: config.format, delimiter: config.delimiter, mappings: config.mappings.map((m) => ({ ...m })) };
        const mapped = new Set(draft.mappings.map((m) => m.field.toLowerCase()));
        const rows = [...draft.mappings].sort((a, b) => (a.order || 1e9) - (b.order || 1e9));
        const known = SEPARATORS.some(([value]) => value === draft.delimiter);
        $('#staffConfig').html(`
          <div class="row g-2 mb-3 align-items-end">
            <div class="col-md-3"><label class="form-label small mb-1" for="staffFormat">File format</label>
              <select id="staffFormat" class="form-select form-select-sm">${[['', 'Auto (CSV or TXT)'], ['Csv', 'CSV (.csv)'], ['Txt', 'TXT (.txt)'], ['Excel', 'Excel (.xlsx)']].map(([v, l]) => `<option value="${v}" ${draft.format === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
            <div class="col-md-3 ${draft.format === 'Excel' ? 'd-none' : ''}"><label class="form-label small mb-1" for="staffDelimiter">Column separator</label>
              <select id="staffDelimiter" class="form-select form-select-sm">${SEPARATORS.map(([v, l]) => `<option value="${esc(v)}" ${known && draft.delimiter === v ? 'selected' : ''}>${l}</option>`).join('')}<option value="custom" ${known ? '' : 'selected'}>Other character…</option></select></div>
            <div class="col-md-2 ${known || draft.format === 'Excel' ? 'd-none' : ''}"><label class="form-label small mb-1" for="staffDelimiterCustom">Character</label>
              <input id="staffDelimiterCustom" class="form-control form-control-sm" maxlength="1" value="${esc(known ? '' : draft.delimiter)}"></div>
          </div>
          <div class="d-flex flex-wrap gap-2 align-items-center mb-2">
            <select id="staffAddColumn" class="form-select form-select-sm" style="max-width:300px" aria-label="Table column to add"><option value="">Add table column…</option>${config.columns.filter((c) => !mapped.has(c.name.toLowerCase())).map((c) => `<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('')}</select>
            <button id="staffAddButton" type="button" class="btn btn-sm btn-outline-primary">Add column</button>
            <button id="staffResetMapping" type="button" class="btn btn-sm btn-outline-secondary">Reset to default mapping</button>
          </div>
          <div class="table-responsive" style="max-height:420px;overflow:auto"><table class="table table-sm align-middle mb-2">
            <thead><tr><th style="width:90px">Order</th><th>File column</th><th>Table column</th><th class="text-center">Required in file</th><th class="text-center">Remove</th></tr></thead>
            <tbody>${rows.map((m, index) => `<tr data-field="${esc(m.field)}">
              <td><input type="number" min="1" class="form-control form-control-sm staff-order" value="${index + 1}" aria-label="Order for ${esc(m.field)}"></td>
              <td><input class="form-control form-control-sm staff-source" maxlength="200" value="${esc(m.sourceColumn)}" aria-label="File column for ${esc(m.field)}"></td>
              <td><code>${esc(m.field)}</code></td>
              <td class="text-center"><input type="checkbox" class="form-check-input staff-required" ${m.required || m.field === 'ATM_ID' ? 'checked' : ''} ${m.field === 'ATM_ID' ? 'disabled' : ''}></td>
              <td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger staff-delete" ${m.field === 'ATM_ID' ? 'disabled title="The ATM ID identifies the record"' : ''}>Delete</button></td></tr>`).join('')}</tbody></table></div>
          <button id="staffSaveConfig" type="button" class="btn btn-primary btn-sm">Save mapping</button>
          <span class="small text-secondary ms-2">Applies to the next upload, the sample file and the single-entry form.</span>`);
    };

    const readRows = () => {
        draft.mappings = $('#staffConfig tbody tr').map(function () {
            const row = $(this);
            return {
                mode: 'BulkFileUpload',
                field: String(row.data('field')),
                sourceColumn: String(row.find('.staff-source').val() || '').trim(),
                required: row.find('.staff-required').is(':checked'),
                order: Number(row.find('.staff-order').val()) || 0,
            };
        }).get();
    };
    const readLayout = () => {
        draft.format = String($('#staffFormat').val() || '');
        const selected = String($('#staffDelimiter').val() || '');
        draft.delimiter = draft.format === 'Excel' ? '' : selected === 'custom' ? String($('#staffDelimiterCustom').val() || '') : selected;
    };

    render();
    const host = $('#viewHost').off('.staffUpload .staffConfig .staffList');
    host.on('click.staffConfig', '.staff-back', guardEvent(() => openView('atmStaffList')));
    host.on('change.staffConfig', '#staffFormat,#staffDelimiter', guardEvent(() => {
        readRows();
        readLayout();
        renderConfig();
    }));
    host.on('click.staffConfig', '.staff-delete', guardEvent(function () {
        readRows();
        readLayout();
        const field = String($(this).closest('tr').data('field'));
        draft.mappings = draft.mappings.filter((m) => m.field !== field);
        renderConfig();
    }));
    host.on('click.staffConfig', '#staffAddButton', guardEvent(() => {
        const name = String($('#staffAddColumn').val() || '');
        if (!name) return toast('Choose a table column to add.', 'warning');
        readRows();
        readLayout();
        draft.mappings.push({ mode: 'BulkFileUpload', field: name, sourceColumn: name, required: false, order: draft.mappings.length + 1 });
        renderConfig();
    }));
    host.on('click.staffConfig', '#staffResetMapping', guardEvent(() => {
        draft = { format: config.defaultFormat, delimiter: config.defaultDelimiter, mappings: config.defaults.map((m) => ({ ...m })) };
        renderConfig();
    }));
    host.on('click.staffConfig', '#staffSaveConfig', guardEvent(async () => {
        readRows();
        readLayout();
        config = await api(`${BASE}/config`, { method: 'PUT', body: { format: draft.format, delimiter: draft.delimiter, mappings: draft.mappings } });
        draft = null;
        toast('Staff Mapping column mapping saved.');
        render();
    }));
}

export { renderAtmStaffUpload, renderAtmStaffConfig };
