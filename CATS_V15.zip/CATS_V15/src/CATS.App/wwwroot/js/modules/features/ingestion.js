import { api } from '../api/client.js';
import { header } from '../ui/feedback.js';
import { json, esc } from '../core/utils.js';
import { state } from '../core/state.js';
import { templateAllowsBaseDataMode } from '../business/templates.js';
import { bindPlatformIngestionEvents } from '../events/ingestion.js';

/**
 * Load and render the platform ingestion screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderPlatformIngestion() {
    const [dashboard, configs] = await Promise.all([
        api('/api/platform/ingestion/dashboard'),
        api('/api/platform/ingestion/configurations'),
    ]);
    $('#ingestionAddModal').remove();
    $('.modal-backdrop').remove();
    $('body').removeClass('modal-open').css('padding-right', '');
    header('Ingestion Tasks & Logs', 'Create one task with one or more simple schedule triggers');

    /**
     * Translate ingestion source codes into the existing user-facing descriptions.
     * @param {*} sourceType - Value used by this operation.
     * @returns {string} Computed value for the caller.
     */
    const sourceLabel = (sourceType) =>
        sourceType === 'SFTP'
            ? 'File Download from SFTP'
            : sourceType === 'QUERY' || sourceType === 'FC_QUERY'
              ? 'Records returned by Query'
              : sourceType;
    /**
     * Parse configured schedule triggers, accepting only array values.
     * @param {*} config - Configuration record.
     * @returns {Array} Computed value for the caller.
     */
    const triggerList = (config) => {
        const parsed = json(config.scheduleTriggersJson, []);
        return Array.isArray(parsed) ? parsed : [];
    };
    const weekdayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    /**
     * Describe the trigger frequency, start time, and applicable weekday or month day.
     * @param {*} trigger - Schedule trigger definition.
     * @returns {string} Computed value for the caller.
     */
    const triggerSummary = (trigger) => {
        const frequency = String(trigger.frequency || '').toUpperCase();
        const time = trigger.startTime || '';
        if (frequency === 'ONCE') return `Once on ${trigger.startDate || ''} at ${time}`;
        if (frequency === 'WEEKLY')
            return `Weekly on ${weekdayNames[Number(trigger.dayOfWeek)] || 'selected day'} at ${time}`;
        if (frequency === 'MONTHLY') return `Monthly on day ${trigger.dayOfMonth || 1} at ${time}`;
        return `Daily at ${time}`;
    };
    const records = configs
        .map((config) => {
            const triggers = triggerList(config);
            const schedules = triggers.length
                ? triggers.map((trigger) => `<div class="small">${esc(triggerSummary(trigger))}</div>`).join('')
                : `<div class="small">${esc(config.scheduleCron || 'No trigger')}</div>`;
            const detail =
                config.sourceType === 'SFTP'
                    ? `<div class="small text-secondary">${esc(config.filePath || '')}${config.filePath && config.fileName ? ' / ' : ''}${esc(config.fileName || config.filePattern || '')}</div>`
                    : `<div class="small text-secondary text-truncate" style="max-width:320px" title="${esc(config.queryText || '')}">${esc(config.queryText || '')}</div>`;
            return `<tr><td><div class="fw-semibold">${esc(config.name)}</div></td><td>${esc(sourceLabel(config.sourceType))}${detail}</td><td>${esc(state.templates.find((template) => template.id === config.templateId)?.code || '')}</td><td><span class="badge text-bg-light mb-1">${triggers.length || 1} trigger${(triggers.length || 1) === 1 ? '' : 's'}</span>${schedules}</td><td>${config.isActive ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Disabled</span>'}</td></tr>`;
        })
        .join('');
    const logs = (dashboard.recentRuns || [])
        .map(
            (run) =>
                `<tr><td>${esc(run.sourceReference)}</td><td>${esc(run.startedAtUtc)}</td><td>${run.rowsRead}</td><td>${run.rowsInserted}</td><td>${run.rowsDuplicate}</td><td>${run.rowsFailed}</td><td>${esc(run.status)}</td></tr>`,
        )
        .join('');
    const ingestionSources = [
        { value: 'SFTP', mode: 'Sftp', label: 'File Download from SFTP' },
        { value: 'QUERY', mode: 'FcQuery', label: 'Records returned by Query' },
    ].filter((source) =>
        state.templates.some(
            (template) => template.status === 'Published' && templateAllowsBaseDataMode(template, source.mode),
        ),
    );
    const ingestionTemplates = state.templates.filter(
        (template) =>
            template.status === 'Published' &&
            (templateAllowsBaseDataMode(template, 'Sftp') || templateAllowsBaseDataMode(template, 'FcQuery')),
    );
    /**
     * Select published alert templates that support the requested ingestion mode.
     * @param {*} source - Template or view configuration to normalize.
     * @returns {Array} Computed value for the caller.
     */
    const templatesForSource = (source) =>
        ingestionTemplates
            .filter((template) => templateAllowsBaseDataMode(template, source === 'SFTP' ? 'Sftp' : 'FcQuery'))
            .map((template) => `<option value="${esc(template.id)}">${esc(template.name || template.code)}</option>`)
            .join('');
    const sourceOptions = ingestionSources
        .map((source) => `<option value="${source.value}">${source.label}</option>`)
        .join('');
    const addIngestionAction = ingestionSources.length
        ? '<button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ingestionAddModal">+ Add Ingestion Option</button>'
        : '';

    $('#viewHost').html(`
        <div class="row g-3 mb-3">
          <div class="col-md-3"><div class="card p-3"><small>Active Tasks</small><h3>${dashboard.activeConfigurations}</h3></div></div>
          <div class="col-md-3"><div class="card p-3"><small>Runs Today</small><h3>${dashboard.runsToday}</h3></div></div>
          <div class="col-md-3"><div class="card p-3"><small>Successful</small><h3>${dashboard.successfulToday}</h3></div></div>
          <div class="col-md-3"><div class="card p-3"><small>Failed</small><h3>${dashboard.failedToday}</h3></div></div>
        </div>
        <div class="d-flex justify-content-between mb-3">
          <div class="btn-group"><button id="showIngestionRecords" class="btn btn-primary">Tasks</button><button id="showIngestionLogs" class="btn btn-outline-primary">Execution Logs</button></div>
          ${addIngestionAction}
        </div>
        <div id="ingestionRecordsPage" class="card"><div class="card-header bg-white fw-semibold">Task Scheduler</div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Task</th><th>Data Source</th><th>Alert Type</th><th>Triggers</th><th>Status</th></tr></thead><tbody>${records || '<tr><td colspan="5" class="text-center text-secondary py-4">No ingestion tasks configured.</td></tr>'}</tbody></table></div></div>
        <div id="ingestionLogsPage" class="card d-none"><div class="card-header bg-white fw-semibold">Execution Logs</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Source</th><th>Started</th><th>Read</th><th>Inserted</th><th>Duplicate</th><th>Failed</th><th>Status</th></tr></thead><tbody>${logs || '<tr><td colspan="7" class="text-center text-secondary py-4">No execution logs.</td></tr>'}</tbody></table></div></div>
        <div class="modal fade" id="ingestionAddModal" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-centered"><div class="modal-content">
          <div class="modal-header"><div><h5 class="modal-title">Add Ingestion Option</h5><div class="small text-secondary">Configure the source and add multiple triggers to this task.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
          <form id="ingestionForm"><div class="modal-body"><div class="row g-3">
            <div class="col-md-4"><label class="form-label" for="icName">Task name</label><input id="icName" class="form-control" maxlength="150" placeholder="Example: Daily branch alerts" required></div>
            <div class="col-md-4"><label class="form-label" for="icTemplate">Alert Type</label><select id="icTemplate" class="form-select" required><option value="">Select alert type</option>${ingestionTemplates.map((template) => `<option value="${esc(template.id)}">${esc(template.name || template.code)}</option>`).join('')}</select></div>
            <div class="col-md-4"><label class="form-label" for="icType">Where does the data come from?</label><select id="icType" class="form-select" disabled><option value="">Select alert type first</option></select></div>
            <div class="col-12"><div class="ingestion-source-panel">
              <div id="icSftpFields" class="row g-3"><div class="col-md-7"><label class="form-label" for="icFilePath">File Path</label><input id="icFilePath" class="form-control" maxlength="500" placeholder="/incoming/alerts" required></div><div class="col-md-5"><label class="form-label" for="icFileName">File Name</label><input id="icFileName" class="form-control" maxlength="260" placeholder="alerts.csv" required></div></div>
              <div id="icQueryFields" class="d-none"><label class="form-label" for="icQuery">Query</label><textarea id="icQuery" class="form-control font-monospace" rows="5" placeholder="SELECT ..."></textarea></div>
            </div></div>
            <div class="col-12"><div class="ingestion-scheduler-panel">
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><div><div class="fw-semibold">Task Scheduler</div><div class="small text-secondary">All triggers below belong to this one ingestion task.</div></div><button id="icAddTrigger" type="button" class="btn btn-sm btn-outline-primary">+ Add Trigger</button></div>
              <div id="icTriggers" class="d-grid gap-2"></div>
            </div></div>
            <div class="col-12"><div class="form-check form-switch"><input id="icEnabled" class="form-check-input" type="checkbox" checked><label class="form-check-label" for="icEnabled">Enabled and ready to run</label></div></div>
          </div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Task</button></div></form>
        </div></div></div>`);
    $('#ingestionAddModal').appendTo(document.body);

    /**
     * Switch ingestion records and run logs while synchronizing the navigation buttons.
     * @param {*} showLogs - Whether to show ingestion execution logs.
     * @returns {void} Updates the relevant UI or state.
     */
    const showPage = (showLogs) => {
        $('#ingestionRecordsPage').toggleClass('d-none', showLogs);
        $('#ingestionLogsPage').toggleClass('d-none', !showLogs);
        $('#showIngestionRecords').toggleClass('btn-primary', !showLogs).toggleClass('btn-outline-primary', showLogs);
        $('#showIngestionLogs').toggleClass('btn-primary', showLogs).toggleClass('btn-outline-primary', !showLogs);
    };
    return bindPlatformIngestionEvents({ weekdayNames, ingestionSources, ingestionTemplates, showPage });
}

export { renderPlatformIngestion };
