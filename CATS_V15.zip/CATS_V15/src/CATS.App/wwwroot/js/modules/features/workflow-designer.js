import { has } from '../core/permissions.js';
import { loadTemplates, loadRoles } from '../api/catalogs.js';
import { header, toast } from '../ui/feedback.js';
import { state } from '../core/state.js';
import { esc, json } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';
import { removeWorkflowDefinitionJson } from '../ui/enhancements.js';
import { showChildModal } from '../ui/modals.js';
import { api } from '../api/client.js';
import { showTemplateAudit } from '../ui/template-audit.js';
import { presetWorkflow, slugify, stageLabel, validateWorkflow, workflowSummary } from '../business/workflow-logic.js';
import {
    applyStageTypeVisibility,
    mountButtonsBuilder,
    mountEditableFieldsPicker,
    mountEndStatus,
    mountRolePicker,
    mountRoleSelect,
    mountRulesBuilder,
} from '../ui/workflow-builder.js';

const fieldCache = new Map();

/**
 * Fields of an alert type, used to pick editable fields and routing rules without typing names.
 * @param {*} templateId - Alert type id.
 * @returns {Promise<Array<{name:string,label:string}>>} Field names and labels; empty when unavailable.
 */
async function templateFields(templateId) {
    if (!templateId) return [];
    if (!fieldCache.has(templateId)) {
        try {
            const record = await api(`/api/templates/${templateId}`);
            fieldCache.set(
                templateId,
                json(record.fieldsJson, []).map((f) => ({ name: f.name ?? f.Name, label: f.label ?? f.Label })),
            );
        } catch {
            return [];
        }
    }
    return fieldCache.get(templateId);
}

const STAGE_TYPE_LABELS = {
    Human: 'One person acts',
    ParallelApproval: 'Several approve',
    Condition: 'Automatic route',
    Agent: 'AI assistant',
    End: 'Finish',
};

/**
 * Load and render the workflow designer screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderWorkflowDesigner() {
    if (!has('WORKFLOW.MANAGE')) throw new Error('Workflow management permission is required.');
    await loadTemplates(true);
    await loadRoles().catch(() => []);
    fieldCache.clear();
    header('Workflow Designer', '');
    const workflowRows = state.templates
        .map(
            (t) =>
                `<tr class="wf-list-row" data-search="${esc(`${t.name} ${t.code}`)}" data-status="${esc(t.status)}"><td><div class="fw-semibold">${esc(t.name)}</div><div class="small text-secondary">${esc(t.code)}</div></td><td><span class="badge text-bg-${t.status === 'Published' ? 'success' : t.status === 'Retired' ? 'secondary' : 'warning'}">${esc(t.status)}</span></td><td class="text-end"><button class="btn btn-sm btn-outline-primary wf-edit" data-id="${esc(t.id)}" title="Edit workflow" aria-label="Edit workflow for ${esc(t.name)}">&#9998;</button> <button type="button" class="btn btn-sm btn-outline-secondary wf-audit" data-id="${esc(t.id)}" title="View audit log" aria-label="View audit log for ${esc(t.name)}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 11a9 9 0 1 1 2.5 7M3 4v7h7"/><path d="M12 7v5l3 2"/></svg></button></td></tr>`,
        )
        .join('');
    $('#viewHost').html(
        `<div class="card mb-3"><div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2"><span class="fw-semibold">Workflows</span><button id="wfNew" class="btn btn-sm btn-primary">+ Add Workflow</button></div><div class="card-body border-bottom"><div class="row g-2"><div class="col-md-8"><label class="visually-hidden" for="wfListSearch">Search workflows</label><input id="wfListSearch" class="form-control" placeholder="Search alert type or template code" /></div><div class="col-md-4"><label class="visually-hidden" for="wfListStatus">Template status</label><select id="wfListStatus" class="form-select"><option value="">All statuses</option><option>Draft</option><option>Published</option><option>Retired</option></select></div></div></div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Alert Type</th><th>Template Status</th><th></th></tr></thead><tbody>${workflowRows || '<tr><td colspan="3" class="text-center text-secondary py-4">No alert types found. Create a template first.</td></tr>'}</tbody></table></div></div><div id="wfControls" class="d-none"><div class="card mb-3"><div class="card-body"><div class="row g-2 align-items-end"><div class="col-md-6"><label class="form-label">Alert Type</label><select id="wfTemplate" class="form-select"><option value="">Select alert type</option>${state.templates.map((t) => `<option value="${t.id}">${esc(t.name || t.code)}</option>`).join('')}</select></div><div class="col-md-6"><label class="form-label">Workflow Name</label><input id="wfName" class="form-control" value="Dynamic Workflow" /></div></div><button id="wfLoad" type="button" class="d-none"></button></div></div></div><div id="wfEditor"></div>`,
    );
    /**
     * Filter workflow rows by the current search text and selected status.
     * @returns {void} Updates the relevant UI or state.
     */
    const filterWorkflows = () => {
        const search = String($('#wfListSearch').val() || '').toLowerCase(),
            status = $('#wfListStatus').val();
        $('.wf-list-row').each(function () {
            const row = $(this);
            row.toggle(
                String(row.data('search')).toLowerCase().includes(search) && (!status || row.data('status') === status),
            );
        });
    };
    $('#wfListSearch,#wfListStatus').on('input change', guardEvent(filterWorkflows));
    $('.wf-audit').on('click', guardEvent(function () {
        const template = state.templates.find((item) => item.id === String($(this).data('id')));
        if (template) showTemplateAudit(template);
    }));
    $('#workflowDesignerModal .modal-body').empty().append($('#wfControls,#wfEditor'));
    $('#workflowDesignerModal')
        .off('show.bs.modal.hideRawJson')
        .on(
            'show.bs.modal.hideRawJson',
            guardEvent(function () {
                removeWorkflowDefinitionJson(this);
            }),
        );
    $('#wfNew').on(
        'click',
        guardEvent(() => {
            $('#wfControls,#wfEditor').removeClass('d-none');
            state.workflowDraft = blank();
            $('#workflowDesignerModalTitle').text('Add Workflow');
            draw();
            bootstrap.Modal.getOrCreateInstance('#workflowDesignerModal').show();
        }),
    );
    $('#workflowCreateForm')
        .off('submit')
        .on(
            'submit',
            guardEvent((event) => {
                event.preventDefault();
                const templateId = $('#newWorkflowTemplate').val();
                if (!templateId) return;
                $('#wfTemplate').val(templateId);
                $('#wfName').val($('#newWorkflowName').val().trim() || 'Dynamic Workflow');
                $('#wfControls,#wfEditor').removeClass('d-none');
                if (!$('#workflowCreateModal').data('workflow-loaded')) state.workflowDraft = blank();
                else state.workflowDraft.name = $('#wfName').val();
                bootstrap.Modal.getOrCreateInstance('#workflowCreateModal').hide();
                draw();
            }),
        );
    $('.wf-edit').on(
        'click',
        guardEvent(async function () {
            try {
                const templateId = $(this).data('id');
                const x = await api(`/api/templates/${templateId}/workflow`);
                state.workflowDraft = {
                    templateId,
                    name: x.record.name,
                    startStageId: x.definition.startStageId,
                    stages: x.definition.stages || [],
                };
                $('#wfTemplate').val(templateId);
                $('#wfName').val(state.workflowDraft.name);
                $('#wfControls,#wfEditor').removeClass('d-none');
                $('#workflowDesignerModalTitle').text(`Edit Workflow: ${state.workflowDraft.name}${x.record.isPublished ? '' : ' (draft, not published)'}`);
                draw();
                bootstrap.Modal.getOrCreateInstance('#workflowDesignerModal').show();
            } catch (x) {
                // Nothing saved for this Alert Type yet: open an empty workflow for it instead of only showing an error.
                const templateId = $(this).data('id');
                $('#wfTemplate').val(templateId);
                $('#wfControls,#wfEditor').removeClass('d-none');
                state.workflowDraft = blank();
                $('#workflowDesignerModalTitle').text('Add Workflow');
                draw();
                bootstrap.Modal.getOrCreateInstance('#workflowDesignerModal').show();
                toast(String(x.message || 'No workflow has been saved for this Alert Type yet.').replace(/\s*\(Reference ID:[^)]*\)\s*$/, ''), 'secondary');
            }
        }),
    );
    /**
     * Create an empty workflow draft using the currently selected template and workflow name.
     * @returns {object} Computed value for the caller.
     */
    const blank = () => ({
        templateId: $('#wfTemplate').val() || '',
        name: $('#wfName').val() || 'Dynamic Workflow',
        startStageId: '',
        stages: [],
    });
    /**
     * Render the current designer draft and reconnect its editor controls.
     * @returns {void} Updates the relevant UI or state.
     */
    function draw() {
        const d = state.workflowDraft;
        let cards = '';
        const stageName = (id) => stageLabel(d.stages, id);
        d.stages.forEach((s, i) => {
            const isStart = d.startStageId === s.id;
            const buttons = (s.transitions || [])
                .map((t) => `<div><span class="fw-semibold">${esc(t.action)}</span> → ${esc(stageName(t.toStageId))}</div>`)
                .join('');
            cards += `<div class="d-flex"><div class="workflow-card ${isStart ? 'start' : ''}" draggable="true" data-i="${i}"><div class="d-flex justify-content-between align-items-center"><span class="badge badge-soft stage-type">${esc(STAGE_TYPE_LABELS[s.type] || s.type)}</span>${isStart ? '<span class="badge text-bg-success">START</span>' : ''}</div><div class="fw-semibold mt-2"><span class="text-secondary">${i + 1}.</span> ${esc(s.name)}</div><div class="small text-secondary mt-1">${esc(s.type === 'ParallelApproval' ? (s.approvers || []).map((a) => a.roleCode).join(' + ') : s.roleCode || (s.type === 'End' ? '' : 'Automatic'))}</div><div class="small mt-2">${buttons || (s.type === 'End' ? `Finishes as ${esc(s.endStatus || 'Closed')}` : '')}</div><div class="mt-3 d-flex gap-1"><button class="btn btn-sm btn-outline-primary set-start" data-i="${i}" ${isStart ? 'disabled' : ''}>Start here</button><button class="btn btn-sm btn-outline-secondary edit-stage" data-i="${i}">Edit</button><button class="btn btn-sm btn-outline-danger del-stage" data-i="${i}">×</button></div></div>${i < d.stages.length - 1 ? '<div class="workflow-arrow">→</div>' : ''}</div>`;
        });
        const problems = validateWorkflow(d, state.roles || []);
        const summary = workflowSummary(d);
        const presetButtons = `<div class="py-3"><div class="mb-2">No steps yet. Start from a ready-made flow, or click <b>Add Step</b> to build your own.</div><div class="d-flex flex-wrap gap-2"><button type="button" class="btn btn-outline-primary wf-preset" data-kind="maker_checker">Maker → Checker</button><button type="button" class="btn btn-outline-primary wf-preset" data-kind="maker_checker_verifier">Maker → Checker → Verifier</button><button type="button" class="btn btn-outline-primary wf-preset" data-kind="single">Single approval</button></div><div class="form-text mt-2">You can change everything afterwards. Maker, Checker and Verifier are just roles you choose, not fixed steps.</div></div>`;
        const checklist = problems.length
            ? `<ul class="list-unstyled mb-0">${problems.map((p) => `<li class="${p.level === 'error' ? 'text-danger' : 'text-warning-emphasis'}">${p.level === 'error' ? '✖' : '⚠'} ${esc(p.text)}</li>`).join('')}</ul>`
            : '<div class="text-success">✔ Everything looks ready.</div>';
        const flow = summary.length
            ? `<ol class="mb-0 ps-3">${summary.map((x) => `<li class="mb-1"><span class="fw-semibold">${esc(x.name)}</span>${x.start ? ' <span class="badge text-bg-success">START</span>' : ''}${x.role ? ` <span class="text-secondary">(${esc(x.role)})</span>` : ''} – ${esc(x.text)}</li>`).join('')}</ol>`
            : '<div class="text-secondary">The flow will be described here as you add steps.</div>';
        $('#wfEditor').html(
            `<div class="card"><div class="card-header bg-white d-flex flex-wrap justify-content-between gap-2"><span class="fw-semibold">Approval steps</span><div><button id="addStage" class="btn btn-sm btn-outline-primary">Add Step</button> <button id="newWorkflow" class="btn btn-sm btn-outline-secondary">Start over</button></div></div><div class="card-body"><div class="alert alert-info small"><div class="fw-semibold mb-1">How to set up the approval flow</div><ol class="mb-0 ps-3"><li>Add a step for each stop the alert makes, for example Maker, Checker.</li><li>For each step choose who handles it and where each button sends the alert.</li><li>Mark where alerts <b>start</b>, check the list below, then tick <b>Make it live</b> and press <b>Save Workflow</b>.</li></ol></div><div class="workflow-lane" id="workflowLane">${cards || presetButtons}</div><div class="row g-3 mt-1"><div class="col-lg-7"><div class="border rounded p-3 h-100"><div class="fw-semibold mb-2">How an alert moves</div>${flow}</div></div><div class="col-lg-5"><div class="border rounded p-3 h-100"><div class="fw-semibold mb-2">Before you save</div>${checklist}</div></div></div><div class="d-flex justify-content-end align-items-center gap-2"><div class="form-check me-2"><input id="wfPublish" class="form-check-input" type="checkbox" checked><label class="form-check-label">Make it live</label></div><button id="saveWorkflow" class="btn btn-primary px-4">Save Workflow</button></div></div></div>`,
        );
        bind();
    }
    /**
     * Connect designer controls to draft editing, ordering, and save operations.
     * @returns {void} Updates the relevant UI or state.
     */
    function bind() {
        $('#addStage').on(
            'click',
            guardEvent(() => openStage(-1)),
        );
        $('#newWorkflow').on(
            'click',
            guardEvent(() => {
                state.workflowDraft = blank();
                draw();
            }),
        );
        $('.edit-stage').on(
            'click',
            guardEvent(function () {
                openStage(+$(this).data('i'));
            }),
        );
        $('.del-stage').on(
            'click',
            guardEvent(function () {
                const i = +$(this).data('i'),
                    id = state.workflowDraft.stages[i].id;
                state.workflowDraft.stages.splice(i, 1);
                if (state.workflowDraft.startStageId === id)
                    state.workflowDraft.startStageId = state.workflowDraft.stages[0]?.id || '';
                draw();
            }),
        );
        $('.set-start').on(
            'click',
            guardEvent(function () {
                state.workflowDraft.startStageId = state.workflowDraft.stages[+$(this).data('i')].id;
                draw();
            }),
        );
        $('#saveWorkflow').on('click', guardEvent(save));
        $('.wf-preset').on(
            'click',
            guardEvent(function () {
                Object.assign(state.workflowDraft, presetWorkflow(String($(this).data('kind')), state.roles || []));
                draw();
                toast('Steps added. Check the role of each step, then save.', 'secondary');
            }),
        );
        $('.workflow-card')
            .on(
                'dragstart',
                guardEvent(function (e) {
                    e.originalEvent.dataTransfer.setData('text/plain', $(this).data('i'));
                }),
            )
            .on(
                'dragover',
                guardEvent((e) => e.preventDefault()),
            )
            .on(
                'drop',
                guardEvent(function (e) {
                    e.preventDefault();
                    const from = +e.originalEvent.dataTransfer.getData('text/plain'),
                        to = +$(this).data('i');
                    const [item] = state.workflowDraft.stages.splice(from, 1);
                    state.workflowDraft.stages.splice(to, 0, item);
                    draw();
                }),
            );
    }
    /**
     * Populate the stage modal using the selected stage or new-stage defaults.
     * @param {*} i - Zero-based item or step index.
     * @returns {void} Updates the relevant UI or state.
     */
    function openStage(i) {
        const s =
            i >= 0
                ? state.workflowDraft.stages[i]
                : {
                      id: '',
                      name: '',
                      type: 'Human',
                      roleCode: '',
                      allowedActions: ['Submit'],
                      editableFields: ['*'],
                      transitions: [],
                      approvalRule: 'Single',
                      minimumApprovals: 1,
                      approvers: [],
                      slaHours: 24,
                      conditions: [],
                      defaultNextStageId: null,
                      agentInstructions: null,
                      agentPromptTemplate: null,
                      agentFallbackAction: null,
                      endStatus: null,
                  };
        $('#stageEditIndex').val(i);
        $('#stageId').val(s.id);
        $('#stageName').val(s.name);
        $('#stageType').val(s.type);
        mountRoleSelect('#stageRole', state.roles || [], s.roleCode || '');
        $('#stageActions').val((s.allowedActions || []).join(','));
        $('#stageEditableFields').val((s.editableFields || []).join(','));
        $('#stageSla').val(s.slaHours || 24);
        $('#stageTransitions').val((s.transitions || []).map((t) => `${t.action}:${t.toStageId || 'END'}`).join('\n'));
        $('#stageApprovers').val((s.approvers || []).map((a) => a.roleCode).join(','));
        $('#stageApprovalRule').val(s.approvalRule || 'All');
        $('#stageMin').val(s.minimumApprovals || 1);
        $('#stageConditions').val(JSON.stringify(s.conditions || [], null, 2));
        $('#stageDefaultNext').attr('data-selected', s.defaultNextStageId || '');
        mountEndStatus(s.endStatus || '');
        $('#stageAgentPrompt').val(s.agentPromptTemplate || s.agentInstructions || '');
        $('#stageAgentFallback').val(s.agentFallbackAction || '');
        showChildModal('#workflowDesignerModal', '#stageModal');
    }
    $('#stageType')
        .off('change.builders')
        .on('change.builders', guardEvent(applyStageTypeVisibility));
    // Built after the modal is visible, because the attachment role inputs are filled when it opens.
    $('#stageModal')
        .off('shown.bs.modal.builders')
        .on(
            'shown.bs.modal.builders',
            guardEvent(async () => {
                applyStageTypeVisibility();
                const roles = state.roles || [];
                ['stageApprovers', 'stageAttachmentUploadRoles', 'stageAttachmentViewRoles'].forEach((id) =>
                    mountRolePicker(id, roles),
                );
                const stages = state.workflowDraft.stages;
                const currentId = $('#stageId').val();
                mountButtonsBuilder({ stages, currentId });
                mountEditableFieldsPicker([]);
                mountRulesBuilder({ stages, currentId, fields: [] });
                const fields = await templateFields($('#wfTemplate').val() || state.workflowDraft.templateId);
                if (!fields.length) return;
                mountEditableFieldsPicker(fields);
                mountRulesBuilder({ stages, currentId, fields });
            }),
        );
    $('#saveStageBtn')
        .off('click')
        .on(
            'click',
            guardEvent(() => {
                try {
                    const i = +$('#stageEditIndex').val(),
                        old = i >= 0 ? state.workflowDraft.stages[i] : null;
                    const transitions = $('#stageTransitions')
                        .val()
                        .split(/\r?\n/)
                        .map((x) => x.trim())
                        .filter(Boolean)
                        .map((x) => {
                            const p = x.split(':');
                            return {
                                action: p[0].trim(),
                                toStageId:
                                    p.slice(1).join(':').trim().toUpperCase() === 'END' || !p.slice(1).join(':').trim()
                                        ? null
                                        : p.slice(1).join(':').trim(),
                                resultStatus: null,
                            };
                        });
                    const conditions = json($('#stageConditions').val() || '[]', null);
                    if (!conditions) throw new Error('The automatic routing rules are not valid. Clear that box if you do not need it.');
                    const s = {
                        id: $('#stageId').val().trim() || slugify($('#stageName').val()),
                        name: $('#stageName').val().trim(),
                        type: $('#stageType').val(),
                        roleCode: $('#stageRole').val(),
                        allowedActions: $('#stageActions')
                            .val()
                            .split(',')
                            .map((x) => x.trim())
                            .filter(Boolean),
                        editableFields: $('#stageEditableFields')
                            .val()
                            .split(',')
                            .map((x) => x.trim())
                            .filter(Boolean),
                        transitions,
                        approvalRule: $('#stageApprovalRule').val(),
                        minimumApprovals: +$('#stageMin').val() || 1,
                        approvers: $('#stageApprovers')
                            .val()
                            .split(',')
                            .map((x) => x.trim())
                            .filter(Boolean)
                            .map((x) => ({ roleCode: x, label: x })),
                        slaHours: +$('#stageSla').val() || 24,
                        conditions,
                        defaultNextStageId: ($('#stageDefaultNext').val() || '').trim() || null,
                        agentInstructions: $('#stageAgentPrompt').val().trim() || null,
                        agentPromptTemplate: $('#stageAgentPrompt').val().trim() || null,
                        agentFallbackAction: $('#stageAgentFallback').val().trim() || null,
                        endStatus: $('#stageType').val() === 'End' ? $('#stageEndStatus').val() || 'Closed' : null,
                    };
                    if (!s.id || !s.name) throw new Error('Please enter a step name.');
                    $('#stageId').val(s.id);
                    if (state.workflowDraft.stages.some((x, j) => j !== i && x.id.toLowerCase() === s.id.toLowerCase()))
                        throw new Error('Another step already uses this step code. Change the code or the step name.');
                    if (i >= 0) state.workflowDraft.stages[i] = s;
                    else state.workflowDraft.stages.push(s);
                    if (!state.workflowDraft.startStageId || state.workflowDraft.startStageId === old?.id)
                        state.workflowDraft.startStageId = s.id;
                    bootstrap.Modal.getOrCreateInstance('#stageModal').hide();
                    draw();
                } catch (x) {
                    toast(x.message, 'danger');
                }
            }),
        );
    /**
     * Validate the current designer values, persist the draft through the API, and refresh the editor.
     * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
     */
    async function save() {
        try {
            state.workflowDraft.templateId = $('#wfTemplate').val() || state.workflowDraft.templateId;
            state.workflowDraft.name = $('#wfName').val() || state.workflowDraft.name;
            if (!state.workflowDraft.templateId) throw new Error('Select a template.');
            if (!state.workflowDraft.startStageId) throw new Error('Choose the step alerts start at (use "Start here" on a step).');
            const publish = $('#wfPublish').prop('checked');
            if (publish && validateWorkflow(state.workflowDraft, state.roles || []).some((p) => p.level === 'error'))
                throw new Error('Please fix the items marked ✖ in "Before you save", or untick "Make it live" to save a draft.');
            const req = {
                templateId: state.workflowDraft.templateId,
                name: state.workflowDraft.name,
                definition: { startStageId: state.workflowDraft.startStageId, stages: state.workflowDraft.stages },
                publish,
            };
            const r = await api('/api/templates/workflow', { method: 'POST', body: req });
            toast(`Workflow v${r.version} saved${r.isPublished ? ' and published' : ''}; ${r.migratedActiveInstances || 0} active case(s) updated`);
            await loadTemplates(true);
        } catch (x) {
            toast(x.message, 'danger');
        }
    }
    $('#wfLoad').on(
        'click',
        guardEvent(async () => {
            const tid = $('#wfTemplate').val();
            if (!tid) {
                toast('Select a template', 'warning');
                return;
            }
            try {
                const x = await api(`/api/templates/${tid}/workflow`);
                state.workflowDraft = {
                    templateId: tid,
                    name: x.record.name,
                    startStageId: x.definition.startStageId,
                    stages: x.definition.stages || [],
                };
                $('#wfName').val(state.workflowDraft.name);
                draw();
            } catch (e) {
                state.workflowDraft = blank();
                state.workflowDraft.templateId = tid;
                draw();
                toast('No published workflow found. Start a new one.', 'secondary');
            }
        }),
    );
    state.workflowDraft = blank();
    draw();
}

export { renderWorkflowDesigner };
