import { observeTask } from '../events/guard.js';
import { has } from '../core/permissions.js';
import { header, loading, toast } from '../ui/feedback.js';
import { api } from '../api/client.js';
import { esc } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';
import { state } from '../core/state.js';
import { loadRoles } from '../api/catalogs.js';
import { bindAdminEvents } from '../events/admin.js';

/**
 * Load and render the admin screen, then initialize its controls and event handlers.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function renderAdmin() {
    if (!has('SECURITY.MANAGE')) throw new Error('Security management permission is required.');
    await loadRoles();
    header('Administration', 'Manage aging bucket configuration');
    loading();
    const [users, permissions, buckets] = await Promise.all([
        api('/api/admin/users'),
        api('/api/admin/permissions'),
        api('/api/admin/aging-buckets'),
    ]);
    let userRows = users
        .map(
            (u) =>
                `<tr><td>${esc(u.userName)}</td><td>${esc(u.displayName)}</td><td><span class="badge text-bg-light">${esc(u.roleCode)}</span></td><td>${esc(u.departmentCode)}</td><td>${esc(u.branchCode)}</td><td>${u.isActive ? 'Active' : 'Inactive'}</td><td class="text-end"><button class="btn btn-sm btn-outline-primary edit-user" data-id="${u.id}">Edit</button></td></tr>`,
        )
        .join('');
    let bucketRows = buckets
        .map(
            (b) =>
                `<tr><td>${esc(b.name)}</td><td>${b.fromDays}</td><td>${b.toDays ?? '∞'}</td><td>${b.displayOrder}</td><td class="text-end"><button class="btn btn-sm btn-outline-primary edit-bucket" data-id="${b.id}">Edit</button></td></tr>`,
        )
        .join('');
    $('#viewHost').html(
        `<div class="card"><div class="card-header bg-white d-flex justify-content-between align-items-center"><span class="fw-semibold">Aging Buckets</span><button id="newBucketBtn" class="btn btn-sm btn-outline-primary">+ Add</button></div><div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Name</th><th>From</th><th>To</th><th>Order</th><th></th></tr></thead><tbody>${bucketRows}</tbody></table></div></div><div id="adminEditor" class="mt-3"></div>`,
    );

    /**
     * Populate the user editor and bind its validated save request.
     * @param {*} u - Existing user record or null for creation.
     * @returns {void} Updates the relevant UI or state.
     */
    function userEditor(u) {
        u = u || {
            id: null,
            userName: '',
            displayName: '',
            roleCode: '',
            departmentCode: '',
            branchCode: '',
            permissions: [],
            isActive: true,
        };
        const checks = permissions
            .map(
                (p) =>
                    `<label class="form-check form-check-inline"><input class="form-check-input admin-perm" type="checkbox" value="${esc(p)}" ${(u.permissions || []).includes(p) ? 'checked' : ''}><span class="form-check-label small">${esc(p)}</span></label>`,
            )
            .join('');
        $('#adminEditor').html(
            `<div class="card"><div class="card-header bg-white fw-semibold">${u.id ? 'Edit' : 'Create'} User</div><div class="card-body"><form id="adminUserForm" class="row g-3"><input id="auId" type="hidden" value="${esc(u.id || '')}"><div class="col-md-3"><label class="form-label">User Name</label><input id="auUser" class="form-control" value="${esc(u.userName)}" required></div><div class="col-md-3"><label class="form-label">Display Name</label><input id="auDisplay" class="form-control" value="${esc(u.displayName)}" required></div><div class="col-md-2"><label class="form-label">Role Code</label><input id="auRole" class="form-control" list="roleOptions" value="${esc(u.roleCode)}" required><datalist id="roleOptions">${state.roles.map(role => `<option value="${esc(role)}"></option>`).join('')}</datalist></div><div class="col-md-2"><label class="form-label">Department</label><input id="auDept" class="form-control" value="${esc(u.departmentCode)}"></div><div class="col-md-2"><label class="form-label">Branch</label><input id="auBranch" class="form-control" value="${esc(u.branchCode)}"></div><div class="col-md-4"><label class="form-label">Password ${u.id ? '<span class="text-secondary">(leave blank to keep)</span>' : ''}</label><input id="auPassword" type="password" class="form-control" ${u.id ? '' : 'required'}></div><div class="col-md-2 d-flex align-items-end"><div class="form-check mb-2"><input id="auActive" class="form-check-input" type="checkbox" ${u.isActive ? 'checked' : ''}><label class="form-check-label">Active</label></div></div><div class="col-12"><label class="form-label">Permissions</label><div>${checks}</div></div><div class="col-12 text-end"><button type="button" id="cancelAdminEdit" class="btn btn-light me-2">Cancel</button><button class="btn btn-primary">Save User</button></div></form></div></div>`,
        );
        $('#cancelAdminEdit').on(
            'click',
            guardEvent(() => $('#adminEditor').empty()),
        );
        $('#adminUserForm').on(
            'submit',
            guardEvent(async (e) => {
                e.preventDefault();
                try {
                    const body = {
                        id: $('#auId').val() || null,
                        userName: $('#auUser').val(),
                        displayName: $('#auDisplay').val(),
                        password: $('#auPassword').val() || null,
                        roleCode: $('#auRole').val(),
                        departmentCode: $('#auDept').val(),
                        branchCode: $('#auBranch').val(),
                        permissions: $('.admin-perm:checked')
                            .map((_, x) => x.value)
                            .get(),
                        isActive: $('#auActive').prop('checked'),
                    };
                    await api('/api/admin/users', { method: 'POST', body });
                    toast('User saved');
                    state.roles = [];
                    await loadRoles(true);
                    observeTask(renderAdmin());
                } catch (x) {
                    toast(x.message, 'danger');
                }
            }),
        );
    }
    /**
     * Populate an aging bucket editor and bind its save request.
     * @param {*} b - Existing aging bucket or null for creation.
     * @returns {void} Updates the relevant UI or state.
     */
    function bucketEditor(b) {
        b = b || { id: null, name: '', fromDays: 0, toDays: null, displayOrder: buckets.length + 1, isActive: true };
        $('#adminEditor').html(
            `<div class="card"><div class="card-header bg-white fw-semibold">${b.id ? 'Edit' : 'Add'} Aging Bucket</div><div class="card-body"><form id="bucketForm" class="row g-3"><input id="abId" type="hidden" value="${esc(b.id || '')}"><div class="col-md-4"><label class="form-label">Name</label><input id="abName" class="form-control" value="${esc(b.name)}" required></div><div class="col-md-2"><label class="form-label">From Days</label><input id="abFrom" type="number" min="0" class="form-control" value="${b.fromDays}" required></div><div class="col-md-2"><label class="form-label">To Days</label><input id="abTo" type="number" min="0" class="form-control" value="${b.toDays ?? ''}" placeholder="No max"></div><div class="col-md-2"><label class="form-label">Order</label><input id="abOrder" type="number" min="1" class="form-control" value="${b.displayOrder}" required></div><div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100">Save</button></div></form></div></div>`,
        );
        $('#bucketForm').on(
            'submit',
            guardEvent(async (e) => {
                e.preventDefault();
                try {
                    await api('/api/admin/aging-buckets', {
                        method: 'POST',
                        body: {
                            id: $('#abId').val() || null,
                            name: $('#abName').val(),
                            fromDays: +$('#abFrom').val(),
                            toDays: $('#abTo').val() === '' ? null : +$('#abTo').val(),
                            displayOrder: +$('#abOrder').val(),
                            isActive: true,
                        },
                    });
                    toast('Aging bucket saved');
                    observeTask(renderAdmin());
                } catch (x) {
                    toast(x.message, 'danger');
                }
            }),
        );
    }
    return bindAdminEvents({ users, buckets, userEditor, bucketEditor });
}

export { renderAdmin };
