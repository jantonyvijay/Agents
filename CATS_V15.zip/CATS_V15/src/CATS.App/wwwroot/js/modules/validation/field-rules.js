import { json } from '../core/utils.js';

/**
 * Evaluate configured field dependencies using case-insensitive operators and supplied field values.
 * @param {*} rule - Configured dependency conditions.
 * @param {*} getValue - Callback returning another configured field value by name.
 * @returns {boolean} Whether the requested condition is satisfied.
 */
export function matchesDependencyRule(rule, getValue) {
    const conditions = rule?.conditions || rule?.Conditions || [];
    return (
        conditions.length > 0 &&
        conditions.every((c) => {
            const actual = getValue(c.field ?? c.Field),
                expected = String(c.value ?? c.Value ?? ''),
                op = String(c.operator ?? c.Operator ?? 'eq').toLowerCase();
            if (op === 'neq' || op === 'ne') return actual.toLowerCase() !== expected.toLowerCase();
            if (op === 'contains') return actual.toLowerCase().includes(expected.toLowerCase());
            if (op === 'empty') return !actual.trim();
            if (op === 'notempty') return !!actual.trim();
            return actual.toLowerCase() === expected.toLowerCase();
        })
    );
}

/**
 * Apply required, length, pattern, numeric, and dependency rules in the existing precedence order.
 * @param {*} f - Configured field definition.
 * @param {*} value - Value to validate or apply.
 * @param {*} getValue - Callback returning another configured field value by name.
 * @returns {string} Computed value for the caller.
 */
export function validateFieldValue(f, value, getValue) {
    let message = '';
    if (f.required && !String(value).trim()) message = f.customErrorMessage || `${f.label} is required.`;
    if (!message && f.minLength != null && value.length < Number(f.minLength))
        message = f.customErrorMessage || `${f.label} must contain at least ${f.minLength} characters.`;
    if (!message && f.maxLength != null && value.length > Number(f.maxLength))
        message = f.customErrorMessage || `${f.label} cannot exceed ${f.maxLength} characters.`;
    if (!message && f.required && f.validationPattern && value) {
        try {
            if (!new RegExp(f.validationPattern).test(value))
                message = f.customErrorMessage || `${f.label} has an invalid format.`;
        } catch {
            message = `${f.label} has an invalid validation pattern.`;
        }
    }
    if (!message && ['number', 'amount'].includes(String(f.type || '').toLowerCase()) && value) {
        const n = Number(value);
        if (Number.isNaN(n)) message = `${f.label} must be a number.`;
        else if (f.minValue != null && n < Number(f.minValue))
            message = f.customErrorMessage || `${f.label} must be at least ${f.minValue}.`;
        else if (f.maxValue != null && n > Number(f.maxValue))
            message = f.customErrorMessage || `${f.label} cannot exceed ${f.maxValue}.`;
    }
    const rules = json(f.dependencyValidationsJson || '[]', []);
    for (const r of rules) {
        if (!matchesDependencyRule(r, getValue)) continue;
        if ((r.required ?? r.Required) && !value.trim())
            message = r.errorMessage ?? r.ErrorMessage ?? `${f.label} is required for the selected values.`;
        const match = r.mustEqualField ?? r.MustEqualField;
        if (!message && match && value !== getValue(match))
            message = r.errorMessage ?? r.ErrorMessage ?? `${f.label} must match ${match}.`;
    }

    return message;
}
