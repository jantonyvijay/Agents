/**
 * Accept only six-digit hexadecimal accent colors.
 * @param {*} value - Value to validate or apply.
 * @returns {boolean} Whether the requested condition is satisfied.
 */
function validThemeColor(value) {
    return /^#[0-9a-f]{6}$/i.test(value || '');
}

export { validThemeColor };
