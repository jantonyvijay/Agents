import { readFieldConfiguration } from '../business/form-data.js';
import { getConfiguredFieldValue } from '../business/form-data.js';
import { validateFieldValue } from './field-rules.js';
import { revealAndFocusConfiguredField } from '../ui/forms.js';

/**
 * Validate each logical field once, update feedback for grouped controls, and reveal the first invalid field.
 * @param {*} root - DOM subtree or selector containing the target controls.
 * @param {*} cssClass - Class identifying configured form controls.
 * @returns {boolean} Whether the requested condition is satisfied.
 */
function validateConfiguredFields(root, cssClass) {
    let first = null,
        valid = true;
    const seen = new Set();
    $(root)
        .find(`.${cssClass}`)
        .each(function () {
            const el = $(this),
                name = String(el.data('name') || '').toLowerCase();
            if (name && seen.has(name)) return;
            if (name) seen.add(name);
            const f = readFieldConfiguration(el),
                value = getConfiguredFieldValue(root, f.name || el.data('name'), cssClass);
            const message = validateFieldValue(f, value, (name) => getConfiguredFieldValue(root, name, cssClass));
            const group = $(root)
                .find(`.${cssClass}`)
                .filter(function () {
                    return String($(this).data('name')).toLowerCase() === name;
                });
            group.toggleClass('is-invalid', !!message);
            const feedback = el.closest('.cats-choice-list').length
                ? el.closest('.cats-choice-list').siblings('.cats-field-error')
                : el.siblings('.cats-field-error');
            feedback.text(message || f.customErrorMessage || 'Please enter a valid value.');
            if (message) {
                valid = false;
                first = first || el;
            }
        });
    if (first?.length) revealAndFocusConfiguredField(first);
    return valid;
}

export { validateConfiguredFields };
