import { bindConfiguredFields } from '../events/forms.js';
import { templateChecklist } from '../business/template-logic.js';
import { templatePreviewHtml } from './template-preview.js';
import { esc } from '../core/utils.js';

const TABS = ['basics', 'sections', 'fields', 'review'];
let activeTab = 'basics';
let previewOn = false;

/**
 * Forget the selected tab and preview setting when a different template is opened.
 * @returns {void} Updates the relevant UI or state.
 */
function resetTemplateTabs() {
    activeTab = 'basics';
    previewOn = false;
}

/**
 * Show the "problems to fix" list for the template.
 * @param {*} draft - Template draft.
 * @returns {string} Markup for the checklist box.
 */
function checklistHtml(draft) {
    const problems = templateChecklist(draft);
    const body = problems.length
        ? `<ul class="list-unstyled mb-0">${problems.map((p) => `<li class="${p.level === 'error' ? 'text-danger' : 'text-warning-emphasis'}">${p.level === 'error' ? '✖' : '⚠'} ${esc(p.text)}</li>`).join('')}</ul>`
        : '<div class="text-success">✔ Everything looks ready to save.</div>';
    return `<div class="border rounded p-3 mb-3"><div class="fw-semibold mb-2">Before you save</div>${body}</div>`;
}

/**
 * Rebuild the live preview of the form next to the editor.
 * @param {*} draft - Template draft.
 * @returns {void} Updates the relevant UI or state.
 */
function renderLivePreview(draft) {
    const host = $('#tdLivePreviewBody');
    if (!host.length || !previewOn) return;
    try {
        host.html(
            templatePreviewHtml({ ...draft, viewConfiguration: { ...draft.viewConfiguration, layoutMode: 'Single' } }) ||
                '<div class="text-secondary">Add a section and a field to see the form here.</div>',
        );
        bindConfiguredFields(host, 'preview-dynamic-field');
    } catch {
        host.html('<div class="text-secondary">The preview will appear when the form has a section and a field.</div>');
    }
}

/**
 * Rearrange the long designer page into four tabs (Basics, Sections, Fields, Options & save) with an optional live preview.
 * Existing controls are moved, not recreated, so their handlers keep working. Nothing changes if a control is missing.
 * @param {*} draft - Template draft.
 * @returns {{fieldsPane: object}|null} The Fields pane, so more controls can be added to it; null when the page could not be organised.
 */
function organizeTemplateEditor(draft) {
    const body = $('#tdEditor > .card > .card-body').first();
    if (!body.length || body.data('td-organized')) return null;
    const guide = body.children('.alert-info').first();
    const basics = $('#tdCode').closest('.row');
    const viewCard = $('#tdLayoutMode').closest('.card.bg-light');
    const sectionsHead = $('#addSection').closest('.d-flex.justify-content-between');
    const fieldsHead = $('#addField').closest('.d-flex.justify-content-between');
    const rules = $('#tdRules').closest('.mt-4');
    const actions = $('#saveTemplate').closest('div.text-end');
    if ([guide, basics, viewCard, sectionsHead, fieldsHead, rules, actions].some((x) => !x.length)) return null;
    body.data('td-organized', true);

    const sectionNodes = sectionsHead.nextUntil(fieldsHead).addBack();
    const fieldNodes = fieldsHead.nextUntil(rules).addBack();

    const groups = [[]];
    viewCard.children().each(function () {
        if (this.tagName === 'HR') groups.push([]);
        else groups[groups.length - 1].push(this);
    });
    const group = (title) => groups.find((g) => g.length && $(g[0]).text().trim().startsWith(title)) || [];
    const advanced = $(
        '<details class="mt-3"><summary class="pointer fw-semibold">Advanced options (alert list columns, file column mapping, data storage)</summary><div class="pt-3"></div></details>',
    );
    const advancedBody = advanced.children('div');
    ['Alert List Configuration', 'Source Column Mapping', 'Data Storage'].forEach((title, i) => {
        if (i) advancedBody.append('<hr class="my-3">');
        advancedBody.append(group(title));
    });
    viewCard.children('hr').slice(1).remove();
    viewCard.append(advanced);

    guide.html(
        '<div class="fw-semibold mb-1">Build the Alert Type in four short steps</div>Use the tabs above. <b>Basics</b>: name it. <b>Sections</b>: add groups of questions. <b>Fields</b>: add the questions. <b>Options &amp; save</b>: check, then save. Then open <b>Workflow Designer</b> to set who approves it.',
    );

    const marker = (bad) => (bad ? ' <span class="text-danger" title="Needs attention">●</span>' : '');
    const names = {
        basics: `1 · Basics${marker(!String(draft.name || '').trim() || !String(draft.code || '').trim())}`,
        sections: `2 · Sections (${draft.sections.length})${marker(!draft.sections.length)}`,
        fields: `3 · Fields (${draft.fields.length})${marker(!draft.fields.length)}`,
        review: `4 · Options &amp; save${marker(templateChecklist(draft).some((p) => p.level === 'error'))}`,
    };
    const nav = $(
        `<div class="d-flex flex-wrap gap-2 align-items-center mb-3" role="tablist">${TABS.map((t) => `<button type="button" class="btn btn-sm td-tab" role="tab" data-pane="${t}">${names[t]}</button>`).join('')}<div class="ms-auto form-check form-switch mb-0"><input id="tdLivePreviewToggle" class="form-check-input" type="checkbox" ${previewOn ? 'checked' : ''}><label class="form-check-label small" for="tdLivePreviewToggle">Show live preview</label></div></div>`,
    );
    const pane = (name) => $(`<div class="td-pane" data-pane="${name}" role="tabpanel"></div>`);
    const panes = { basics: pane('basics'), sections: pane('sections'), fields: pane('fields'), review: pane('review') };
    panes.basics.append(guide, basics);
    panes.sections.append(sectionNodes);
    panes.fields.append(fieldNodes);
    panes.review.append(checklistHtml(draft), viewCard);
    const footer = $(
        '<div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top"><button type="button" class="btn btn-outline-secondary" id="tdTabBack">← Back</button><button type="button" class="btn btn-outline-secondary" id="tdTabNext">Next →</button></div>',
    );
    const main = $('<div class="td-main col-12"></div>').append(nav, panes.basics, panes.sections, panes.fields, panes.review, footer, actions);
    const preview = $(
        '<div class="td-preview col-lg-5 d-none"><div class="border rounded p-3 bg-white" style="position:sticky;top:0;max-height:80vh;overflow:auto"><div class="fw-semibold mb-2">Live preview</div><div class="small text-secondary mb-2">This is how the form will look to users. Changes appear as you add sections and fields.</div><div id="tdLivePreviewBody"></div></div></div>',
    );
    rules.detach();
    body.empty().append($('<div class="row g-3"></div>').append(main, preview));
    rules.addClass('d-none').attr('aria-hidden', 'true');
    body.append(rules);

    const setTab = (name) => {
        activeTab = TABS.includes(name) ? name : 'basics';
        const index = TABS.indexOf(activeTab);
        Object.entries(panes).forEach(([key, el]) => el.toggleClass('d-none', key !== activeTab));
        nav.find('.td-tab').each(function () {
            const on = $(this).data('pane') === activeTab;
            $(this).toggleClass('btn-primary', on).toggleClass('btn-outline-secondary', !on).attr('aria-selected', on);
        });
        $('#tdTabBack').prop('disabled', index === 0);
        $('#tdTabNext').prop('disabled', index === TABS.length - 1);
    };
    const applyPreview = () => {
        preview.toggleClass('d-none', !previewOn);
        main.toggleClass('col-lg-7', previewOn);
        renderLivePreview(draft);
    };
    nav.on('click', '.td-tab', function () {
        setTab(String($(this).data('pane')));
    });
    $('#tdTabBack').on('click', () => setTab(TABS[Math.max(0, TABS.indexOf(activeTab) - 1)]));
    $('#tdTabNext').on('click', () => setTab(TABS[Math.min(TABS.length - 1, TABS.indexOf(activeTab) + 1)]));
    $('#tdLivePreviewToggle').on('change', function () {
        previewOn = this.checked;
        applyPreview();
    });
    setTab(activeTab);
    applyPreview();
    return { fieldsPane: panes.fields, reviewPane: panes.review, setTab };
}

export { organizeTemplateEditor, resetTemplateTabs };
