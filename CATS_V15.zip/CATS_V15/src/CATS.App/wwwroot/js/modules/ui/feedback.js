import { esc, uid } from '../core/utils.js';

/**
 * Render an escaped status with the established success, danger, warning, or primary color.
 * @param {*} s - Text or JSON input to interpret.
 * @returns {string} Computed value for the caller.
 */
const statusBadge = (s) =>
    `<span class="badge rounded-pill text-bg-${/closed|approved/i.test(s) ? 'success' : /reject|cancel/i.test(s) ? 'danger' : /query/i.test(s) ? 'warning' : 'primary'}">${esc(s)}</span>`;

let pendingRequests = 0;

let requestLoaderDelay;

/**
 * Read the shared loading indicator template from the page.
 * @returns {string} Computed value for the caller.
 */
function loaderMarkup() {
    return document.getElementById('hdfcLoaderTemplate').innerHTML;
}

/**
 * Count active requests and reveal the shared loader only after the short delay.
 * @returns {void} Updates the relevant UI or state.
 */
function beginRequestLoading() {
    if (pendingRequests++ !== 0) return;
    requestLoaderDelay = setTimeout(() => {
        $('#requestLoader').html(loaderMarkup()).prop('hidden', false);
    }, 250);
}

/**
 * Decrement the active request count and hide the loader after the last request completes.
 * @returns {void} Updates the relevant UI or state.
 */
function endRequestLoading() {
    if (--pendingRequests !== 0) return;
    clearTimeout(requestLoaderDelay);
    $('#requestLoader').prop('hidden', true).empty();
}

/**
 * Append an escaped notification, display it, and remove it when Bootstrap dismisses it.
 * @param {*} message - User-facing status or notification text.
 * @param {*} [type] - Display type or notification severity.
 * @returns {void} Updates the relevant UI or state.
 */
function toast(message, type = 'success') {
    const id = uid();
    $('#toastHost').append(
        `<div id="${id}" class="toast align-items-center text-bg-${type} border-0" role="alert"><div class="d-flex"><div class="toast-body">${esc(message)}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div>`,
    );
    const el = document.getElementById(id);
    const t = new bootstrap.Toast(el, { delay: 3500 });
    el.addEventListener('hidden.bs.toast', () => el.remove());
    t.show();
}

/**
 * Replace the current view with the shared loading indicator.
 * @returns {void} Updates the relevant UI or state.
 */
function loading() {
    $('#viewHost').html(`<div class="spinner-overlay">${loaderMarkup()}</div>`);
}

/**
 * Render an escaped page heading and subtitle alongside supplied action markup.
 * @param {*} title - Heading or section label.
 * @param {*} [sub] - Optional secondary heading text.
 * @param {*} [actions] - Trusted application-generated action markup.
 * @returns {void} Updates the relevant UI or state.
 */
function header(title, sub = '', actions = '') {
    $('#pageHeader').html(
        `<div><h1 class="h4 mb-0">${esc(title)}</h1><div class="small text-secondary">${esc(sub)}</div></div><div>${actions}</div>`,
    );
}

export {
    statusBadge,
    pendingRequests,
    requestLoaderDelay,
    loaderMarkup,
    beginRequestLoading,
    endRequestLoading,
    toast,
    loading,
    header,
};
