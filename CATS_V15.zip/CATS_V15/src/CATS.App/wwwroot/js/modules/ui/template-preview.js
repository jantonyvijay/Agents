import { configuredSectionsHtml } from './forms.js';
import { bindConfiguredFields } from '../events/forms.js';
import { templateViewConfig } from '../business/templates.js';
import { esc } from '../core/utils.js';
import { showChildModal } from './modals.js';

export function templatePreviewHtml(draft) {
    const fields = structuredClone(draft.fields || []);
    // Preview uses local placeholders for remote choices and never loads production data.
    for (const field of fields) {
        if (String(field.dataSourceMode).toLowerCase() === 'api') {
            field.dataSourceMode = 'Static';
            field.optionsJson = '["Preview option"]';
            field.defaultValue = '';
        }
        if (field.sensitive) field.defaultValue = '';
    }
    return configuredSectionsHtml(draft.sections, fields, {}, null, 'preview-dynamic-field',
        templateViewConfig({ viewConfiguration: draft.viewConfiguration }), 'template-preview-layout', false);
}

export function showTemplatePreview(draft) {
    const editor = $('#tdEditor');
    if ($('#templatePreviewPane').length) return;
    const opener = document.activeElement;
    const scrollHost = editor.closest('.modal-body');
    const scrollTop = scrollHost.scrollTop();
    const existing = editor.children();
    existing.hide();
    const pane = $(`<div id="templatePreviewPane"><div class="d-flex justify-content-between align-items-center mb-3"><h4 class="mb-0">${esc(draft.name || 'Template preview')}</h4><button type="button" class="btn btn-outline-primary" id="closeTemplatePreview">Back to editing</button></div><div class="alert alert-info small">Preview of your current draft. You can try the controls; entered values are discarded. Actual edit permissions depend on the workflow stage. Remote dropdowns use a preview option.</div>${templatePreviewHtml(draft)}</div>`);
    editor.append(pane);
    // Section popups must live outside the designer while its modal is hidden.
    const popups = pane.find('.cats-template-popup').appendTo(document.body);
    bindConfiguredFields(pane.add(popups), 'preview-dynamic-field');
    let openingPopup = false;
    pane.find('[data-bs-toggle="modal"]').each(function () {
        const button = $(this), target = button.attr('data-bs-target');
        button.removeAttr('data-bs-toggle data-bs-target').on('click', () => {
            openingPopup = true;
            showChildModal('#templateDesignerModal', target);
        });
    });
    const designer = $('#templateDesignerModal');
    function close() {
        popups.each(function () { bootstrap.Modal.getInstance(this)?.dispose(); });
        popups.remove();
        pane.remove();
        existing.show();
        scrollHost.scrollTop(scrollTop);
        designer.off('hidden.bs.modal.templatePreview');
        if (opener?.isConnected && designer.hasClass('show')) opener.focus();
    }
    function onHidden(event) {
        // A section popup temporarily hides the designer; preserve the preview in that case.
        if (event.target === designer[0] && !popups.filter('.show').length) close();
    }
    // showChildModal's hidden handler opens the child after this handler; mark that transition explicitly.
    designer.on('hidden.bs.modal.templatePreview', (event) => {
        if (openingPopup) { openingPopup = false; return; }
        onHidden(event);
    });
    $('#closeTemplatePreview').on('click', close);
    scrollHost.scrollTop(0);
    $('#closeTemplatePreview').trigger('focus');
}
