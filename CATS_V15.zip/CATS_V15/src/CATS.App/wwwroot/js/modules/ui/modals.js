import { guardEvent } from '../events/guard.js';

/**
 * Hide a parent designer before showing its child, then restore the parent and focus on close.
 * @param {string} parentSelector - Selector identifying the parent modal.
 * @param {string} childSelector - Selector identifying the child modal.
 * @returns {void} Updates the relevant UI or state.
 */
function showChildModal(parentSelector, childSelector) {
    const parent = document.querySelector(parentSelector);
    const child = document.querySelector(childSelector);
    if (!child) return;
    const childModal = bootstrap.Modal.getOrCreateInstance(child);
    if (!parent?.classList.contains('show')) {
        childModal.show();
        return;
    }
    const parentModal = bootstrap.Modal.getOrCreateInstance(parent);
    const opener = document.activeElement;
    child.addEventListener(
        'hidden.bs.modal',
        () => {
            parent.addEventListener(
                'shown.bs.modal',
                () => {
                    const target = opener?.isConnected
                        ? opener
                        : parent.querySelector(childSelector === '#sectionModal' ? '#addSection' : '#addField');
                    target?.focus();
                },
                { once: true },
            );
            parentModal.show();
        },
        { once: true },
    );
    parent.addEventListener('hidden.bs.modal', () => childModal.show(), { once: true });
    parentModal.hide();
}

function showTemplateChildModal(selector) {
    showChildModal('#templateDesignerModal', selector);
}

/**
 * Bind constrained pointer dragging to modal headers and reset positions when modals close.
 * @returns {void} Updates the relevant UI or state.
 */
function enableMovableModals() {
    let drag = null;
    $(document).on(
        'pointerdown',
        '.modal.show .modal-header',
        guardEvent(function (event) {
            const pointer = event.originalEvent;
            if (pointer.button !== 0 || $(event.target).closest('button,a,input,select,textarea,label').length) return;
            const dialog = $(this).closest('.modal-dialog')[0];
            if (!dialog) return;
            const rect = dialog.getBoundingClientRect();
            drag = {
                dialog,
                pointerId: pointer.pointerId,
                startX: pointer.clientX,
                startY: pointer.clientY,
                originX: Number(dialog.dataset.dragX || 0),
                originY: Number(dialog.dataset.dragY || 0),
                rect,
            };
            dialog.classList.add('is-dragging');
            this.setPointerCapture?.(pointer.pointerId);
            event.preventDefault();
        }),
    );
    $(document).on(
        'pointermove',
        guardEvent(function (event) {
            const pointer = event.originalEvent;
            if (!drag || pointer.pointerId !== drag.pointerId) return;
            const rawX = pointer.clientX - drag.startX;
            const rawY = pointer.clientY - drag.startY;
            const deltaX = Math.max(-drag.rect.left, Math.min(window.innerWidth - drag.rect.right, rawX));
            const deltaY = Math.max(-drag.rect.top, Math.min(window.innerHeight - drag.rect.bottom, rawY));
            const x = drag.originX + deltaX;
            const y = drag.originY + deltaY;
            drag.dialog.dataset.dragX = String(x);
            drag.dialog.dataset.dragY = String(y);
            drag.dialog.style.transform = `translate(${x}px, ${y}px)`;
        }),
    );
    $(document).on(
        'pointerup pointercancel',
        guardEvent(function (event) {
            if (!drag || event.originalEvent.pointerId !== drag.pointerId) return;
            drag.dialog.classList.remove('is-dragging');
            drag = null;
        }),
    );
    $(document).on(
        'hidden.bs.modal',
        '.modal',
        guardEvent(function () {
            const dialog = this.querySelector('.modal-dialog');
            if (!dialog) return;
            dialog.classList.remove('is-dragging');
            dialog.style.removeProperty('transform');
            delete dialog.dataset.dragX;
            delete dialog.dataset.dragY;
            if (drag?.dialog === dialog) drag = null;
        }),
    );
}

export { showChildModal, showTemplateChildModal, enableMovableModals };
