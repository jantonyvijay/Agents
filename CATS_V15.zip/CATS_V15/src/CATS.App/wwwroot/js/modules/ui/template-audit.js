import { api } from '../api/client.js';
import { esc } from '../core/utils.js';

export function auditDetailsHtml(details) {
    if (!details) return '<div class="small text-secondary">The API did not return audit details. Restart CATS with the latest build, then reopen this log.</div>';
    if (!details.available) return '<div class="small text-secondary">The saved audit snapshot could not be read.</div>';
    const note = !details.hasPrevious ? '<p class="small text-secondary">No previous snapshot was recorded. Showing the saved configuration.</p>' : '';
    if (!details.totalChanges) return '<div class="small text-secondary">No configuration differences recorded.</div>';
    return `<button type="button" class="btn btn-link btn-sm px-0 mt-1" data-audit-details="${esc(encodeURIComponent(JSON.stringify(details)))}">View changes (${Number(details.totalChanges)})</button>`;
}

function showAuditChanges(details) {
    const element = document.createElement('div');
    element.className = 'modal fade';
    element.tabIndex = -1;
    element.setAttribute('aria-labelledby', 'auditChangesTitle');
    const note = !details.hasPrevious ? '<p class="small text-secondary">No previous snapshot was recorded. Showing the saved configuration.</p>' : '';
    const rows = details.changes.map((change) => `<tr><td class="text-break">${esc(change.property)}</td><td class="text-break" style="white-space:pre-wrap">${change.before == null ? '<span class="text-secondary">Not present</span>' : esc(change.before)}</td><td class="text-break" style="white-space:pre-wrap">${change.after == null ? '<span class="text-secondary">Not present</span>' : esc(change.after)}</td></tr>`).join('');
    element.innerHTML = `<div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><h5 class="modal-title" id="auditChangesTitle">Configuration changes</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
        <div class="modal-body">${note}<div class="table-responsive"><table class="table table-sm table-bordered align-middle"><thead><tr><th>Setting</th><th>Before</th><th>After</th></tr></thead><tbody>${rows}</tbody></table></div>${details.totalChanges > details.changes.length ? '<p class="small text-secondary mb-0">Showing the first 500 changes.</p>' : ''}</div>
        <div class="modal-footer"><button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button></div>
        </div></div>`;
    document.body.appendChild(element);
    const modal = bootstrap.Modal.getOrCreateInstance(element);
    element.addEventListener('hidden.bs.modal', () => {
        modal.dispose();
        element.remove();
    }, { once: true });
    modal.show();
}

export function showTemplateAudit(template) {
    if (document.getElementById('templateAuditModal')) return;
    const opener = document.activeElement;
    const element = document.createElement('div');
    element.id = 'templateAuditModal';
    element.className = 'modal fade';
    element.tabIndex = -1;
    element.setAttribute('aria-labelledby', 'templateAuditTitle');
    element.innerHTML = `<div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><h5 class="modal-title" id="templateAuditTitle">Audit log — ${esc(template.name)}</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
        <div class="modal-body"><p class="text-secondary small">${esc(template.code)} · Template and workflow history, newest first. Times are shown in your local timezone.</p><div data-audit-content aria-live="polite"></div></div>
        <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-audit-prev>Previous</button><span data-audit-page class="small mx-2"></span><button type="button" class="btn btn-outline-secondary" data-audit-next>Next</button><button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button></div>
        </div></div>`;
    document.body.appendChild(element);
    const modal = bootstrap.Modal.getOrCreateInstance(element);
    const content = element.querySelector('[data-audit-content]');
    const previous = element.querySelector('[data-audit-prev]');
    const next = element.querySelector('[data-audit-next]');
    const pageLabel = element.querySelector('[data-audit-page]');
    let page = 1;
    let closed = false;
    async function load(target) {
        previous.disabled = next.disabled = true;
        content.innerHTML = '<div class="py-4 text-center text-secondary" role="status">Loading audit history…</div>';
        try {
            const result = await api(`/api/templates/${encodeURIComponent(template.id)}/audit?page=${target}`);
            if (closed) return;
            page = target;
            pageLabel.textContent = `Page ${page}`;
            content.innerHTML = result.items.length ? `<div class="table-responsive"><table class="table table-striped align-middle"><thead><tr><th>Date / time</th><th>Action</th><th>User</th><th>Role</th><th>Details</th></tr></thead><tbody>${result.items.map((item) => `<tr><td class="text-nowrap">${esc(new Date(item.createdAtUtc).toLocaleString())}</td><td>${esc(String(item.action).replaceAll('_', ' '))}</td><td>${esc(item.userName)}</td><td>${esc(item.roleCode)}</td><td class="text-break">${esc(item.remarks || (item.entityType === 'WorkflowDefinition' ? 'Workflow configuration saved.' : 'Template configuration saved.'))}${auditDetailsHtml(item.details)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="py-4 text-center text-secondary">No audit entries on this page.</div>';
            content.querySelectorAll('[data-audit-details]').forEach((button) => {
                button.addEventListener('click', () => showAuditChanges(JSON.parse(decodeURIComponent(button.dataset.auditDetails))));
            });
            previous.disabled = page === 1;
            next.disabled = !result.hasMore;
        } catch (error) {
            if (closed) return;
            content.innerHTML = `<div class="alert alert-danger" role="alert">${esc(error.message || 'Unable to load audit history.')}</div><button type="button" class="btn btn-outline-primary" data-audit-retry>Retry</button>`;
            content.querySelector('[data-audit-retry]').onclick = () => load(target);
        }
    }
    previous.onclick = () => load(page - 1);
    next.onclick = () => load(page + 1);
    element.addEventListener('hidden.bs.modal', () => {
        closed = true;
        modal.dispose();
        element.remove();
        if (opener?.isConnected) opener.focus();
    }, { once: true });
    modal.show();
    void load(1);
}
