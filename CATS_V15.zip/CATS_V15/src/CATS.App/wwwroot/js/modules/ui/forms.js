import { esc, fieldValue, json } from '../core/utils.js';
import { state } from '../core/state.js';
import { piEye } from './privacy.js';

import { getSectionLayout } from './appearance.js';
import { templateViewConfig } from '../business/templates.js';

/**
 * Render a configured field control with existing type, default, readonly, and PI-masking rules.
 * @param {*} f - Configured field definition.
 * @param {*} val - Current field value.
 * @param {*} cssClass - Class identifying configured form controls.
 * @param {*} [editable] - Whether the field can be edited.
 * @returns {string} Computed value for the caller.
 */
function templateFieldControlHtml(f, val, cssClass, editable = true) {
    if (cssClass === 'detail-dynamic-field' && f.sensitive) {
        const masked = String(val ?? '');
        return `<div class="cats-field-readonly" data-pi-value="${esc(f.name)}" data-pi-edit="${editable && !f.readOnly ? encodeURIComponent(JSON.stringify(f)) : ''}" data-alert-id="${esc(state.detail?.alert?.id || '')}" data-masked-value="${esc(masked)}">${esc(masked)}${f.allowUnmask !== false ? piEye(state.detail?.alert?.id || '', f.name) : ''}</div>`;
    }
    const value = val ?? f.defaultValue ?? '';
    const disabled = !editable || f.readOnly;
    if (disabled)
        return `<div class="fw-medium cats-field-readonly">${esc(fieldValue(value)) || '<span class="text-secondary">—</span>'}</div>`;
    const req = f.required ? 'aria-required="true"' : '';
    const placeholder = f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : '';
    const minLen = f.minLength != null ? ` minlength="${Number(f.minLength)}"` : '';
    const maxLen = f.maxLength != null ? ` maxlength="${Number(f.maxLength)}"` : '';
    const min = f.minValue != null ? ` min="${Number(f.minValue)}"` : '';
    const max = f.maxValue != null ? ` max="${Number(f.maxValue)}"` : '';
    const pattern = f.required && f.validationPattern ? ` pattern="${esc(f.validationPattern)}"` : '';
    const meta = `data-field-config="${encodeURIComponent(JSON.stringify(f))}" data-name="${esc(f.name)}"`;
    let html = '';
    const type =
        String(f.type || 'text').toLowerCase() === 'dropdownlist' ? 'select' : String(f.type || 'text').toLowerCase();
    const options = json(f.optionsJson, []);
    if (type === 'select' || type === 'multiselect') {
        const multiple = type === 'multiselect' ? ' multiple' : '';
        if (String(f.dataSourceMode || 'Static').toLowerCase() === 'api')
            html = `<select class="form-select ${cssClass} cats-api-select" ${meta} data-current-value="${esc(value)}" ${req}${multiple}><option value="">Loading…</option></select>`;
        else {
            const selectedValues =
                type === 'multiselect'
                    ? Array.isArray(value)
                        ? value
                        : String(value || '')
                              .split(',')
                              .map((x) => x.trim())
                    : [String(value)];
            html = `<select class="form-select ${cssClass}" ${meta} ${req}${multiple}>${type === 'select' ? '<option value="">Select</option>' : ''}${options.map((o) => `<option value="${esc(o)}" ${selectedValues.includes(String(o)) ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
        }
    } else if (type === 'radio' || type === 'checkboxlist') {
        const inputType = type === 'radio' ? 'radio' : 'checkbox';
        const currentValues =
            type === 'checkboxlist'
                ? Array.isArray(value)
                    ? value
                    : String(value || '')
                          .split(',')
                          .map((x) => x.trim())
                : [String(value)];
        html = `<div class="cats-choice-list" ${meta}>${options.map((o, i) => `<label class="form-check form-check-inline me-3"><input class="form-check-input ${cssClass}" data-field-config="${encodeURIComponent(JSON.stringify(f))}" data-name="${esc(f.name)}" type="${inputType}" name="${esc(f.name)}" value="${esc(o)}" ${currentValues.includes(String(o)) ? 'checked' : ''} ${req}><span class="form-check-label">${esc(o)}</span></label>`).join('')}</div>`;
    } else if (type === 'textarea')
        html = `<textarea class="form-control ${cssClass}" ${meta} rows="3" ${req}${placeholder}${minLen}${maxLen}${pattern}>${esc(value)}</textarea>`;
    else if (type === 'checkbox')
        html = `<div class="form-check"><input class="form-check-input ${cssClass}" ${meta} type="checkbox" ${value === true || value === 'true' ? 'checked' : ''} ${req}></div>`;
    else if (type === 'file') html = `<input class="form-control ${cssClass}" ${meta} type="file" ${req}/>`;
    else {
        const htmlType =
            type === 'number' || type === 'amount'
                ? 'number'
                : type === 'date'
                  ? 'date'
                  : type === 'datetime'
                    ? 'datetime-local'
                    : type === 'time'
                      ? 'time'
                      : type === 'email'
                        ? 'email'
                        : type === 'tel'
                          ? 'tel'
                          : 'text';
        const step = type === 'amount' ? ' step="0.01"' : '';
        html = `<input class="form-control ${cssClass}" ${meta} type="${htmlType}"${step} value="${esc(value)}" ${req}${placeholder}${minLen}${maxLen}${min}${max}${pattern}/>`;
    }
    const counter =
        ['text', 'textarea', 'email', 'tel'].includes(String(f.type || '').toLowerCase()) && f.maxLength != null
            ? `<div class="form-text text-end cats-field-counter" data-counter-for="${esc(f.name)}">0/${Number(f.maxLength)}</div>`
            : '';
    const help = f.helpText ? `<div class="form-text">${esc(f.helpText)}</div>` : '';
    return (
        html +
        counter +
        help +
        `<div class="invalid-feedback cats-field-error">${esc(f.customErrorMessage || 'Please enter a valid value.')}</div>`
    );
}

/**
 * Render fields belonging to a section in configured order and layout.
 * @param {*} section - Section definition to render.
 * @param {*} fields - Configured field definitions.
 * @param {*} data - Current form values keyed by field name.
 * @param {*} editableSet - Set of field names permitted for editing, or null for unrestricted creation.
 * @param {*} cssClass - Class identifying configured form controls.
 * @returns {string} Computed value for the caller.
 */
function sectionContentHtml(section, fields, data, editableSet, cssClass) {
    const listMode = String(section.dataViewMode || 'Grid').toLowerCase() === 'list';
    const span = listMode ? 12 : Math.min(12, Math.max(2, Number(section.columnSpan ?? 6) || 6));
    return `<div class="row g-3 ${listMode ? 'cats-section-list' : ''}">${fields
        .filter((x) => x.sectionId === section.id)
        .sort((a, b) => a.order - b.order)
        .map((f) => {
            const editable = editableSet === null ? !f.readOnly : editableSet.has(String(f.name).toLowerCase());
            const label = `${esc(f.label)}${f.required ? ' <span class="text-danger">*</span>' : ''}`;
            const control = templateFieldControlHtml(f, data[f.name], cssClass, editable);
            return listMode
                ? `<div class="col-12"><div class="row align-items-start"><div class="col-md-4"><label class="small text-secondary mb-1">${label}</label></div><div class="col-md-8">${control}</div></div></div>`
                : `<div class="col-12 col-md-${span}"><label class="small text-secondary mb-1">${label}</label>${control}</div>`;
        })
        .join('')}</div>`;
}

/**
 * Render ordered sections using template settings and the per-user layout override.
 * @param {*} sections - Configured section definitions.
 * @param {*} fields - Configured field definitions.
 * @param {*} data - Current form values keyed by field name.
 * @param {*} editableSet - Set of field names permitted for editing, or null for unrestricted creation.
 * @param {*} cssClass - Class identifying configured form controls.
 * @param {*} cfg - Resolved section layout configuration.
 * @param {*} [prefix] - Unique prefix used for section and navigation IDs.
 * @returns {string} Computed value for the caller.
 */
function configuredSectionsHtml(sections, fields, data, editableSet, cssClass, cfg, prefix = 'cats-layout', usePersonalLayout = true) {
    const ordered = [...(sections || [])].sort(
        (a, b) => Number(a.pageNumber || 1) - Number(b.pageNumber || 1) || Number(a.order || 0) - Number(b.order || 0),
    );
    if (!ordered.length) return '<div class="text-secondary">This template has no dynamic sections.</div>';
    /**
     * Format the section title with optional numbering and escaped text.
     * @param {*} s - Text or JSON input to interpret.
     * @param {*} i - Zero-based item or step index.
     * @returns {string} Computed value for the caller.
     */
    const title = (s, i) => `${cfg.showSectionNumbers ? `${i + 1}. ` : ''}${esc(s.name)}`;
    /**
     * Render a section body using the configured fields and editable-field permissions.
     * @param {*} s - Text or JSON input to interpret.
     * @returns {string} Computed value for the caller.
     */
    const body = (s) => sectionContentHtml(s, fields, data, editableSet, cssClass);
    const personalLayout = usePersonalLayout ? getSectionLayout() : 'template';
    const configuredMode =
        personalLayout === 'template' ? String(cfg.layoutMode || 'Single').toLowerCase() : personalLayout;
    const mode = configuredMode === 'auto' ? (ordered.length > 1 ? 'tab' : 'single') : configuredMode;
    if (mode === 'tab')
        return `<ul class="nav nav-tabs mb-3" role="tablist">${ordered.map((x, i) => `<li class="nav-item"><button class="nav-link ${i === 0 ? 'active' : ''}" data-bs-toggle="tab" data-bs-target="#${prefix}-tab-${i}" type="button">${title(x, i)}</button></li>`).join('')}</ul><div class="tab-content">${ordered.map((x, i) => `<div class="tab-pane fade ${i === 0 ? 'show active' : ''}" id="${prefix}-tab-${i}"><div class="section-box">${body(x)}</div></div>`).join('')}</div>`;
    if (mode === 'accordion')
        return `<div class="accordion mb-3" id="${prefix}-accordion">${ordered.map((x, i) => `<div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button ${i ? 'collapsed' : ''}" type="button" data-bs-toggle="collapse" data-bs-target="#${prefix}-acc-${i}">${title(x, i)}</button></h2><div id="${prefix}-acc-${i}" class="accordion-collapse collapse ${i === 0 ? 'show' : ''}" data-bs-parent="#${prefix}-accordion"><div class="accordion-body">${body(x)}</div></div></div>`).join('')}</div>`;
    if (mode === 'popup')
        return `<div class="row g-3 mb-3">${ordered.map((x, i) => `<div class="col-md-6 col-xl-4"><button type="button" class="btn btn-outline-primary w-100 text-start p-3" data-bs-toggle="modal" data-bs-target="#${prefix}-popup-${i}"><span class="fw-semibold">${title(x, i)}</span><span class="d-block small text-secondary">Open section</span></button></div>`).join('')}</div>${ordered.map((x, i) => `<div class="modal fade cats-template-popup" id="${prefix}-popup-${i}" tabindex="-1"><div class="modal-dialog modal-${esc(cfg.popupSize || 'xl')} modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${title(x, i)}</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">${body(x)}</div><div class="modal-footer"><button class="btn btn-primary" data-bs-dismiss="modal">Done</button></div></div></div></div>`).join('')}`;
    if (mode === 'wizard')
        return `<div class="cats-wizard" data-wizard-prefix="${prefix}"><div class="d-flex flex-wrap gap-2 mb-3">${ordered.map((x, i) => `<button type="button" class="btn btn-sm ${i === 0 ? 'btn-primary' : 'btn-outline-secondary'} cats-wizard-step" data-step="${i}" ${cfg.allowWizardStepClick ? '' : 'disabled'}>${title(x, i)}</button>`).join('')}</div>${ordered.map((x, i) => `<div class="section-box cats-wizard-pane ${i === 0 ? '' : 'd-none'}" data-step="${i}">${body(x)}<div class="d-flex justify-content-between mt-4"><button type="button" class="btn btn-outline-secondary cats-wizard-prev" ${i === 0 ? 'disabled' : ''}>Previous</button><button type="button" class="btn btn-primary cats-wizard-next" ${i === ordered.length - 1 ? 'disabled' : ''}>Next</button></div></div>`).join('')}</div>`;
    return ordered
        .map(
            (x, i) =>
                `<div class="section-box" data-section-page="${x.pageNumber || 1}"><h6>${title(x, i)}</h6>${body(x)}</div>`,
        )
        .join('');
}

/**
 * Reveal the invalid field through modal, tab, accordion, or wizard containers before focusing it.
 * @param {*} el - jQuery field control to reveal.
 * @returns {void} Updates the relevant UI or state.
 */
function revealAndFocusConfiguredField(el) {
    if (!el?.length) return;
    const modal = el.closest('.modal');
    if (modal.length && !modal.hasClass('show')) bootstrap.Modal.getOrCreateInstance(modal[0]).show();
    const tabPane = el.closest('.tab-pane');
    if (tabPane.length && !tabPane.hasClass('active')) {
        const id = tabPane.attr('id');
        const trigger = $(`[data-bs-target="#${CSS.escape(id)}"]`).first();
        if (trigger.length) bootstrap.Tab.getOrCreateInstance(trigger[0]).show();
    }
    const collapse = el.closest('.accordion-collapse');
    if (collapse.length && !collapse.hasClass('show'))
        bootstrap.Collapse.getOrCreateInstance(collapse[0], { toggle: false }).show();
    const wizardPane = el.closest('.cats-wizard-pane');
    if (wizardPane.length && wizardPane.hasClass('d-none')) {
        const wizard = wizardPane.closest('.cats-wizard'),
            step = Number(wizardPane.data('step'));
        wizard.find('.cats-wizard-pane').addClass('d-none').filter(`[data-step="${step}"]`).removeClass('d-none');
        wizard
            .find('.cats-wizard-step')
            .removeClass('btn-primary')
            .addClass('btn-outline-secondary')
            .filter(`[data-step="${step}"]`)
            .addClass('btn-primary')
            .removeClass('btn-outline-secondary');
    }
    setTimeout(() => {
        try {
            el[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
        } catch {}
        el.trigger('focus');
    }, 180);
}

/**
 * Parse the template schema and render its configured new-alert form.
 * @param {*} template - Alert template record.
 * @param {*} [data] - Current form values keyed by field name.
 * @returns {string} Computed value for the caller.
 */
function dynamicFormHtml(template, data = {}) {
    const sections = json(template.sectionsJson, []),
        fields = json(template.fieldsJson, []),
        cfg = templateViewConfig(template);
    return configuredSectionsHtml(sections, fields, data, null, 'dynamic-field', cfg, 'new-alert-layout');
}

export {
    templateFieldControlHtml,
    sectionContentHtml,
    configuredSectionsHtml,
    revealAndFocusConfiguredField,
    dynamicFormHtml,
};
