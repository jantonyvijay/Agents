import { state } from '../core/state.js';
import { esc } from '../core/utils.js';

/**
 * Render escaped template choices with version and publication status.
 * @param {*} [selected] - Currently selected option value.
 * @returns {string} Computed value for the caller.
 */
const templateOptions = (selected = '') =>
    `<option value="">All / Select template</option>` +
    state.templates
        .map(
            (t) =>
                `<option value="${esc(t.id)}" ${t.id === selected ? 'selected' : ''}>${esc(t.name)} v${t.version} (${esc(t.status)})</option>`,
        )
        .join('');

/**
 * Render published alert-type choices with the requested selection placeholder.
 * @param {*} [selected] - Currently selected option value.
 * @param {*} [requireSelection] - Whether to render an explicit selection placeholder.
 * @param {*} [includeAll] - Whether to render an all-alert-types option when a selection is optional.
 * @returns {string} Computed value for the caller.
 */
const alertTypeOptions = (selected = '', requireSelection = false, includeAll = true) =>
    `${requireSelection ? '<option value="">Select alert type</option>' : includeAll ? '<option value="">All alert types</option>' : ''}` +
    state.templates
        .filter((t) => t.status === 'Published')
        .map((t) => `<option value="${esc(t.id)}" ${t.id === selected ? 'selected' : ''}>${esc(t.name || t.code)}</option>`)
        .join('');

export { templateOptions, alertTypeOptions };
