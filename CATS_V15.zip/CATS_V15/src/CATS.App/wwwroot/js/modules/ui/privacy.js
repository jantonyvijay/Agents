import { has } from '../core/permissions.js';
import { esc } from '../core/utils.js';

/**
 * Render a reveal button only when the current user has PI unmask permission.
 * @param {*} alertId - Alert identifier associated with the sensitive value.
 * @param {*} field - Field name or definition.
 * @returns {string} Computed value for the caller.
 */
const piEye = (alertId, field) =>
    has('PI.UNMASK')
        ? `<button type="button" class="btn btn-sm btn-link pi-reveal p-0 ms-1" data-alert-id="${esc(alertId)}" data-field="${esc(field)}" aria-label="Reveal ${field === 'customerId' ? 'Customer ID' : field === 'accountId' ? 'Account ID' : esc(field)}" title="Reveal after password verification"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg></button>`
        : '';

/**
 * Render a labeled button that restores a previously revealed sensitive value to its mask.
 * @param {*} alertId - Alert identifier associated with the sensitive value.
 * @param {*} field - Field name or definition.
 * @returns {string} Computed value for the caller.
 */
const piMaskEye = (alertId, field) =>
    `<button type="button" class="btn btn-sm btn-link pi-mask p-0 ms-1" data-alert-id="${esc(alertId)}" data-field="${esc(field)}" aria-label="Mask ${field === 'customerId' ? 'Customer ID' : field === 'accountId' ? 'Account ID' : esc(field)}" title="Mask this value"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m3 3 18 18"/><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 4.2A10.8 10.8 0 0 1 12 4c6.5 0 10 8 10 8a18.5 18.5 0 0 1-2.1 3.2M6.6 6.6C3.5 8.5 2 12 2 12s3.5 8 10 8a10.5 10.5 0 0 0 4.1-.8"/></svg></button>`;

/**
 * Preserve a cell mask and attach a reveal action only once when permission allows it.
 * @param {*} cell - jQuery cell receiving the sensitive-value control.
 * @param {*} alertId - Alert identifier associated with the sensitive value.
 * @param {*} field - Field name or definition.
 * @returns {void} Updates the relevant UI or state.
 */
const makePiCell = (cell, alertId, field) => {
    if (!has('PI.UNMASK') || !cell.length || cell.find('.pi-reveal,.pi-mask').length) return;
    const masked = cell.text();
    cell.attr('data-pi-value', field)
        .attr('data-alert-id', alertId)
        .attr('data-masked-value', masked)
        .addClass('text-nowrap')
        .append(piEye(alertId, field));
};

/**
 * Locate customer and account columns and attach permission-controlled reveal actions to alert rows.
 * @param {*} [root] - DOM subtree or selector containing the target controls.
 * @returns {void} Updates the relevant UI or state.
 */
function enhancePiGrids(root = document) {
    if (!has('PI.UNMASK')) return;
    $(root)
        .find('table')
        .addBack('table')
        .each(function () {
            const table = $(this),
                fields = [];
            table.find('thead th').each(function (index) {
                const heading = $(this).text().replace(/\s/g, '').toLowerCase();
                if (heading === 'customer' || heading === 'customerid') fields.push([index, 'customerId']);
                if (heading === 'account' || heading === 'accountid') fields.push([index, 'accountId']);
            });
            if (!fields.length) return;
            table.find('tbody tr[data-id]').each(function () {
                const row = $(this),
                    alertId = String(row.data('id'));
                fields.forEach(([index, field]) => makePiCell(row.children('td').eq(index), alertId, field));
            });
        });
}

export { piEye, piMaskEye, makePiCell, enhancePiGrids };
