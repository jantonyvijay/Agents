import { esc } from '../core/utils.js';

/**
 * Remove generated raw workflow definition panels from the supplied DOM subtree.
 * @param {*} [root] - DOM subtree or selector containing the target controls.
 * @returns {void} Updates the relevant UI or state.
 */
function removeWorkflowDefinitionJson(root = document) {
    $(root)
        .find('details')
        .addBack('details')
        .filter(function () {
            return $(this).children('summary').first().text().trim() === 'Definition JSON';
        })
        .remove();
}

/**
 * Hide raw assignment-rule JSON controls in the supplied DOM subtree.
 * @param {*} [root] - DOM subtree or selector containing the target controls.
 * @returns {void} Updates the relevant UI or state.
 */
function hideAssignmentRulesJson(root = document) {
    $(root)
        .find('label')
        .addBack('label')
        .filter(function () {
            return $(this).text().trim() === 'Assignment Rules JSON';
        })
        .closest('.mt-4')
        .addClass('d-none')
        .attr('aria-hidden', 'true');
}

/**
 * Add consistent icons and accessible labels to designer action buttons once.
 * @param {*} [root] - DOM subtree or selector containing the target controls.
 * @returns {void} Updates the relevant UI or state.
 */
function enhanceDesignerActions(root = document) {
    const iconActions = [
        ['.edit-section,.edit-field,.edit-stage', '&#9998;', 'Edit'],
        ['.del-section,.del-field,.del-stage', '&#128465;', 'Delete'],
    ];
    iconActions.forEach(([selector, icon, label]) =>
        $(root)
            .find(selector)
            .addBack(selector)
            .each(function () {
                const button = $(this);
                if (button.data('icon-action')) return;
                button
                    .data('icon-action', true)
                    .addClass('icon-action')
                    .html(icon)
                    .attr({ title: label, 'aria-label': label });
            }),
    );
    const commandIcons = {
        '#addSection': '＋',
        '#addField': '＋',
        '#saveTemplate': '✓',
        '#addStage': '＋',
        '#newWorkflow': '＋',
        '#saveWorkflow': '✓',
        '.set-start': '◆',
    };
    Object.entries(commandIcons).forEach(([selector, icon]) =>
        $(root)
            .find(selector)
            .addBack(selector)
            .each(function () {
                const button = $(this);
                if (button.data('command-icon')) return;
                button
                    .data('command-icon', true)
                    .prepend(`<span class="button-icon" aria-hidden="true">${icon}</span>`);
            }),
    );
}

/**
 * Replace grid row and pagination actions with labeled icon buttons once.
 * @param {*} [root] - DOM subtree or selector containing the target controls.
 * @returns {void} Updates the relevant UI or state.
 */
function enhanceGridActions(root = document) {
    const actions = { Open: ['&#128065;', 'Open'], Edit: ['&#9998;', 'Edit'], Delete: ['&#128465;', 'Delete'] };
    $(root)
        .find('table tbody button')
        .each(function () {
            const button = $(this),
                label = button.text().trim();
            const action = actions[label];
            if (!action || button.data('grid-icon-action')) return;
            button
                .data('grid-icon-action', true)
                .addClass('icon-action')
                .html(action[0])
                .attr({ title: action[1], 'aria-label': action[1] });
        });
    const pagination = {
        '#prevPage': ['&#8592;', 'Previous page'],
        '#nextPage': ['&#8594;', 'Next page'],
        '.td-prev': ['&#8592;', 'Previous page'],
        '.td-next': ['&#8594;', 'Next page'],
    };
    Object.entries(pagination).forEach(([selector, action]) =>
        $(root)
            .find(selector)
            .addBack(selector)
            .each(function () {
                const button = $(this);
                if (button.data('grid-icon-action')) return;
                button
                    .data('grid-icon-action', true)
                    .addClass('icon-action')
                    .html(action[0])
                    .attr({ title: action[1], 'aria-label': action[1] });
            }),
    );
}

/**
 * Apply consistent icons and labels to grid toolbar controls.
 * @param {*} [root] - DOM subtree or selector containing the target controls.
 * @returns {void} Updates the relevant UI or state.
 */
function enhanceGridToolbar(root = document) {
    const controls = {
        '.dropdown-toggle': ['&#9881;', 'Choose columns'],
        '.cats-compact': ['&#8645;', 'Toggle compact rows'],
        '.cats-wrap': ['&#8617;', 'Toggle text wrapping'],
        '.cats-reset': ['&#8635;', 'Reset grid options'],
    };
    $(root)
        .find('.cats-grid-toolbar')
        .addBack('.cats-grid-toolbar')
        .each(function () {
            const toolbar = $(this);
            Object.entries(controls).forEach(([selector, action]) =>
                toolbar.find(selector).each(function () {
                    const button = $(this);
                    button.addClass('icon-action').html(action[0]).attr({ title: action[1], 'aria-label': action[1] });
                }),
            );
        });
}

/**
 * Add command icons to matching buttons while preserving their labels and handlers.
 * @param {*} [root] - DOM subtree or selector containing the target controls.
 * @returns {void} Updates the relevant UI or state.
 */
function enhanceCommandButtons(root = document) {
    /**
     * Choose a command icon based on the existing button label.
     * @param {*} label - Value used by this operation.
     * @returns {string} Computed value for the caller.
     */
    const iconFor = (label) => {
        const text = label.replace(/^[+＋]\s*/, '').toLowerCase();
        if (/^(add|new|create)/.test(text)) return '＋';
        if (/^(save|submit|apply|confirm|continue|reveal)/.test(text)) return '✓';
        if (/^(search|filter|discover|load|reconnect)/.test(text)) return '⌕';
        if (/^(upload|download|import|export|csv)/.test(text)) return '⇧';
        if (/^(back|previous)/.test(text)) return '←';
        if (/^(next|forward)/.test(text)) return '→';
        if (/^(cancel|clear|reset|remove|retire)/.test(text)) return '×';
        if (/^(open|view)/.test(text)) return '◉';
        return '';
    };
    $(root)
        .find('button.btn')
        .addBack('button.btn')
        .each(function () {
            const button = $(this);
            if (
                button.is(
                    '.btn-close,.icon-action,.nav-link,.dropdown-toggle,.cats-compact,.cats-wrap,.cats-reset,.click-count,.click-total',
                ) ||
                button.find('.button-icon').length
            )
                return;
            const label = button.text().trim(),
                icon = iconFor(label);
            if (!icon) return;
            button.html(
                `<span class="button-icon" aria-hidden="true">${icon}</span>${esc(label.replace(/^[+＋]\s*/, ''))}`,
            );
        });
}

export {
    removeWorkflowDefinitionJson,
    hideAssignmentRulesJson,
    enhanceDesignerActions,
    enhanceGridActions,
    enhanceGridToolbar,
    enhanceCommandButtons,
};
