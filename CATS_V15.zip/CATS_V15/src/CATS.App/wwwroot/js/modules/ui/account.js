import { state } from '../core/state.js';
import { sessionStore } from '../core/storage.js';
import { api } from '../api/client.js';
import { userInitials } from '../core/utils.js';

let sessionCountdownInterval = null;
const SESSION_EXTEND_AFTER_MS = 15_000;
let lastSessionExtendAt = Date.now();
let sessionExtendInFlight = false;

/**
 * Ask the API for a fresh token while the user is active, so the session counts idle time rather than time since sign-in.
 * Runs at most every 15 seconds and quietly; the server stops extending at the maximum session length.
 * @returns {Promise<void>} Resolves when the attempt finishes; failures are logged, never shown (an expired token signs the user out on the next request).
 */
async function extendSession() {
    if (!state.token || sessionExtendInFlight || Date.now() - lastSessionExtendAt < SESSION_EXTEND_AFTER_MS) return;
    sessionExtendInFlight = true;
    // Counted from the attempt, so a failing call is not repeated on every click.
    lastSessionExtendAt = Date.now();
    try {
        const result = await api('/api/auth/refresh', { method: 'POST', quiet: true });
        if (result?.token && state.token) {
            state.token = result.token;
            sessionStore.setItem('cats_token', result.token);
            startSessionCountdown();
        }
    } catch (error) {
        console.warn('CATS: the session could not be extended automatically.', error?.message || error);
    } finally {
        sessionExtendInFlight = false;
    }
}

/**
 * Decode the token expiry and refresh the visible countdown until expiry or logout.
 * @returns {void} Updates the relevant UI or state.
 */
function startSessionCountdown() {
    clearInterval(sessionCountdownInterval);
    $('#sessionCountdown').addClass('d-none').removeClass('is-expiring');
    // Real user input (not timers) counts as activity.
    // Capture phase so handlers that stop propagation (modals, dropdowns) cannot hide the activity.
    for (const type of ['mousedown', 'keydown', 'touchstart', 'click']) {
        document.removeEventListener(type, extendSession, true);
        document.addEventListener(type, extendSession, true);
    }
    let expiresAt;
    try {
        const payload = state.token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
        expiresAt = JSON.parse(atob(payload)).exp * 1000;
    } catch {
        return;
    }
    if (!Number.isFinite(expiresAt)) return;
    /**
     * Refresh remaining session time and stop the timer after expiration or logout.
     * @returns {void} Updates the relevant UI or state.
     */
    const update = () => {
        if (!state.token) {
            clearInterval(sessionCountdownInterval);
            $('#sessionCountdown').addClass('d-none');
            return;
        }
        const seconds = Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000));
        $('#sessionCountdown')
            .removeClass('d-none')
            .toggleClass('is-expiring', seconds <= 300);
        $('#sessionCountdownValue').text(
            `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`,
        );
        $('#sessionCountdown').attr(
            'title',
            seconds > 0
                ? 'Time remaining before your session expires. It is extended while you are active.'
                : 'Your session has expired. Please sign in again.',
        );
        if (seconds === 0) clearInterval(sessionCountdownInterval);
    };
    sessionCountdownInterval = setInterval(update, 1000);
    update();
}

/**
 * Populate account names, initials, role, and organizational context from the current user.
 * @returns {void} Updates the relevant UI or state.
 */
function renderAccountDetails() {
    const user = state.user || {};
    const displayName = (user.displayName || user.userName || 'User').trim();
    const userName = (user.userName || '').trim();
    const role = (user.roleCode || 'USER').trim();
    const context = [];
    if (user.departmentCode) context.push(`Department: ${user.departmentCode}`);
    if (user.branchCode) context.push(`Branch: ${user.branchCode}`);
    $('#headerAvatar, #accountAvatar').text(userInitials(user));
    $('#headerUserName, #accountDisplayName').text(displayName);
    // The header shows the display name and, beneath it, the sign-in name and role.
    const signIn = userName && userName.toLowerCase() !== displayName.toLowerCase() ? `${userName} · ${role}` : role;
    $('#headerRole').text(signIn).attr('title', `${displayName} (${userName || role}) · ${role}`);
    $('#accountRole').text(role);
    $('#accountUserName').text(userName || 'Signed-in user');
    $('#accountContext').text(context.join(' · ') || 'Authenticated session');
    $('#accountMenuButton').attr('aria-label', `Open account menu for ${displayName}`);
}

/**
 * Switch password masking and synchronize the toggle label and accessibility state.
 * @param {*} visible - Whether the control or value should be visible.
 * @returns {void} Updates the relevant UI or state.
 */
function setPasswordVisibility(visible) {
    $('#loginPassword').attr('type', visible ? 'text' : 'password');
    $('#toggleLoginPassword')
        .toggleClass('is-visible', visible)
        .attr({ 'aria-pressed': String(visible), 'aria-label': visible ? 'Hide password' : 'Show password' });
    $('#passwordToggleText').text(visible ? 'Hide password' : 'Show password');
}

/**
 * Disable sign-in submission and synchronize its spinner and busy indicators.
 * @param {*} busy - Whether sign-in is in progress.
 * @returns {void} Updates the relevant UI or state.
 */
function setLoginBusy(busy) {
    $('#loginForm').attr('aria-busy', String(busy));
    $('#loginSubmitBtn').prop('disabled', busy);
    $('.login-submit-spinner').toggleClass('d-none', !busy);
    $('.login-submit-arrow').toggleClass('d-none', busy);
    $('.login-submit-label').text(busy ? 'Signing in…' : 'Sign in securely');
}

/**
 * Show or hide the sign-in status text using the supplied message.
 * @param {*} [message] - User-facing status or notification text.
 * @returns {void} Updates the relevant UI or state.
 */
function setLoginStatus(message = '') {
    $('#loginStatus').text(message).toggleClass('d-none', !message);
}

export {
    sessionCountdownInterval,
    startSessionCountdown,
    renderAccountDetails,
    setPasswordVisibility,
    setLoginBusy,
    setLoginStatus,
};
