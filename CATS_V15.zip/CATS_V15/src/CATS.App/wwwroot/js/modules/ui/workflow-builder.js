import { esc } from '../core/utils.js';
import {
    COMMON_BUTTONS,
    CONDITION_OPERATORS,
    FINISH,
    parseTransitions,
    splitList,
    transitionsToText,
} from '../business/workflow-logic.js';

const TYPE_HELP = {
    Human: 'One person picks a button and the alert moves on. Most steps are like this.',
    ParallelApproval: 'Several roles each approve the alert; you choose how many must agree.',
    Condition: 'The system decides the next step by itself, using rules about the alert data.',
    Agent: 'An AI assistant suggests the decision. If it cannot decide, a fallback button is pressed.',
    End: 'The alert is finished here. Nothing else happens after this step.',
};

/**
 * Show only the parts of the step form that matter for the chosen kind of step.
 * @returns {void} Updates the relevant UI or state.
 */
function applyStageTypeVisibility() {
    const type = $('#stageType').val();
    $('#stageModal [data-stage-types]').each(function () {
        $(this).toggleClass('d-none', !String($(this).data('stage-types')).split(',').includes(type));
    });
    $('#stageTypeHelp').text(TYPE_HELP[type] || '');
}

/**
 * Turn a comma separated hidden input into a list of tick boxes for the known roles.
 * @param {string} inputId - Hidden input holding the comma separated role codes.
 * @param {Array<string>} roles - Known role codes.
 * @returns {void} Updates the relevant UI or state.
 */
function mountRolePicker(inputId, roles) {
    const input = $(`#${inputId}`);
    const selected = splitList(input.val()).map((x) => x.toUpperCase());
    const all = [...new Set([...roles, ...selected])];
    const host = $(`#${inputId}Picker`);
    host.html(
        all.length
            ? all
                  .map(
                      (role, i) =>
                          `<div class="form-check form-check-inline"><input class="form-check-input role-pick" type="checkbox" id="${inputId}_${i}" value="${esc(role)}" ${selected.includes(String(role).toUpperCase()) ? 'checked' : ''}><label class="form-check-label" for="${inputId}_${i}">${esc(role)}</label></div>`,
                  )
                  .join('')
            : '<span class="text-secondary small">No roles found.</span>',
    );
    host.off('change.rolePicker').on('change.rolePicker', '.role-pick', () => {
        input.val(
            host
                .find('.role-pick:checked')
                .map((_, el) => el.value)
                .get()
                .join(','),
        );
    });
}

/**
 * Fill a role drop-down, keeping a role that is no longer in the list so existing steps are not changed silently.
 * @param {string} selector - Select element.
 * @param {Array<string>} roles - Known role codes.
 * @param {string} current - Role currently saved on the step.
 * @returns {void} Updates the relevant UI or state.
 */
function mountRoleSelect(selector, roles, current) {
    const all = current && !roles.includes(current) ? [...roles, current] : roles;
    $(selector).html(
        `<option value="">Choose a role…</option>${all.map((r) => `<option value="${esc(r)}">${esc(r)}</option>`).join('')}`,
    );
    $(selector).val(current || '');
}

/**
 * Options for a "go to which step" drop-down.
 * @param {Array} stages - Workflow stages.
 * @param {string} excludeId - Step being edited; it cannot send alerts to itself.
 * @param {string|null} selected - Currently chosen target.
 * @param {boolean} allowFinish - Whether "finish the alert" is offered.
 * @returns {string} Option markup.
 */
function targetOptions(stages, excludeId, selected, allowFinish = true) {
    const known = stages.filter((s) => s.id !== excludeId);
    const missing = selected && selected !== FINISH && !known.some((s) => s.id === selected);
    return [
        '<option value="">Choose next step…</option>',
        allowFinish ? `<option value="${FINISH}" ${selected === FINISH ? 'selected' : ''}>Finish – close the alert</option>` : '',
        ...known.map((s) => `<option value="${esc(s.id)}" ${selected === s.id ? 'selected' : ''}>${esc(s.name)}</option>`),
        missing ? `<option value="${esc(selected)}" selected>(missing step: ${esc(selected)})</option>` : '',
    ].join('');
}

/**
 * Build the buttons list: tick the buttons the step offers, then pick where each one sends the alert.
 * Keeps the hidden #stageActions and #stageTransitions fields in the format the workflow saves.
 * @param {{stages:Array,currentId:string}} options - Draft stages and the step being edited.
 * @returns {void} Updates the relevant UI or state.
 */
function mountButtonsBuilder({ stages, currentId }) {
    const host = $('#stageButtonsBuilder');
    let buttons = splitList($('#stageActions').val());
    const targets = new Map(parseTransitions($('#stageTransitions').val()).map((t) => [t.action.toLowerCase(), t.toStageId || FINISH]));
    const sync = () => {
        $('#stageActions').val(buttons.join(','));
        $('#stageTransitions').val(
            transitionsToText(
                buttons
                    .filter((b) => targets.get(b.toLowerCase()))
                    .map((b) => ({ action: b, toStageId: targets.get(b.toLowerCase()) === FINISH ? null : targets.get(b.toLowerCase()) })),
            ),
        );
    };
    const render = () => {
        const choices = [...new Set([...COMMON_BUTTONS, ...buttons])];
        host.html(
            `<div class="d-flex flex-wrap gap-2 mb-2">${choices
                .map(
                    (b) =>
                        `<button type="button" class="btn btn-sm ${buttons.includes(b) ? 'btn-primary' : 'btn-outline-secondary'} step-button-toggle" data-button="${esc(b)}" aria-pressed="${buttons.includes(b)}">${esc(b)}</button>`,
                )
                .join('')}<div class="input-group input-group-sm" style="max-width:260px"><input class="form-control" id="stageCustomButton" placeholder="Another button name" maxlength="40"><button type="button" class="btn btn-outline-primary" id="stageCustomButtonAdd">Add</button></div></div>${
                buttons.length
                    ? buttons
                          .map(
                              (b) =>
                                  `<div class="row g-2 align-items-center mb-1"><div class="col-sm-3"><span class="fw-semibold">${esc(b)}</span> <span class="text-secondary">sends the alert to</span></div><div class="col-sm-6"><select class="form-select form-select-sm step-button-target" data-button="${esc(b)}" aria-label="Where ${esc(b)} sends the alert">${targetOptions(stages, currentId, targets.get(b.toLowerCase()))}</select></div></div>`,
                          )
                          .join('')
                    : '<div class="text-secondary small">Tick at least one button. Each button can then be connected to the next step.</div>'
            }<div class="form-text">Tip: add all your steps first, then come back here to connect the buttons.</div>`,
        );
    };
    host.off('.buttonsBuilder')
        .on('click.buttonsBuilder', '.step-button-toggle', function () {
            const name = String($(this).data('button'));
            buttons = buttons.includes(name) ? buttons.filter((b) => b !== name) : [...buttons, name];
            sync();
            render();
        })
        .on('click.buttonsBuilder', '#stageCustomButtonAdd', () => {
            const name = String($('#stageCustomButton').val() || '').trim();
            if (name && !buttons.some((b) => b.toLowerCase() === name.toLowerCase())) buttons.push(name);
            sync();
            render();
        })
        .on('keydown.buttonsBuilder', '#stageCustomButton', (e) => {
            if (e.key !== 'Enter') return;
            e.preventDefault();
            $('#stageCustomButtonAdd').trigger('click');
        })
        .on('change.buttonsBuilder', '.step-button-target', function () {
            targets.set(String($(this).data('button')).toLowerCase(), $(this).val());
            sync();
        });
    sync();
    render();
}

/**
 * Choose which template fields the person at this step may change.
 * Writes * (all), a comma separated list, or nothing (view only) to the hidden #stageEditableFields.
 * @param {Array<{name:string,label:string}>} fields - Fields of the alert type.
 * @returns {void} Updates the relevant UI or state.
 */
function mountEditableFieldsPicker(fields) {
    const host = $('#stageEditableBuilder');
    const input = $('#stageEditableFields');
    const current = splitList(input.val());
    let mode = current.includes('*') ? 'all' : current.length ? 'some' : 'none';
    const chosen = new Set(current.filter((x) => x !== '*'));
    const sync = () => input.val(mode === 'all' ? '*' : mode === 'some' ? [...chosen].join(',') : '');
    const render = () => {
        const list = fields.length
            ? fields
                  .map(
                      (f, i) =>
                          `<div class="form-check form-check-inline"><input class="form-check-input editable-pick" type="checkbox" id="stageEditable_${i}" value="${esc(f.name)}" ${chosen.has(f.name) ? 'checked' : ''}><label class="form-check-label" for="stageEditable_${i}">${esc(f.label || f.name)}</label></div>`,
                  )
                  .join('')
            : '<span class="text-secondary small">Save the template with fields first to pick individual fields.</span>';
        host.html(
            `<div class="btn-group btn-group-sm mb-2" role="group" aria-label="Fields this step may change">${[
                ['all', 'All fields'],
                ['some', 'Only some fields'],
                ['none', 'None (view only)'],
            ]
                .map(
                    ([value, label]) =>
                        `<button type="button" class="btn ${mode === value ? 'btn-primary' : 'btn-outline-secondary'} editable-mode" data-mode="${value}">${label}</button>`,
                )
                .join('')}</div>${mode === 'some' ? `<div>${list}</div>` : ''}<div class="form-text">Sensitive fields still need the unmask permission.</div>`,
        );
    };
    host.off('.editableBuilder')
        .on('click.editableBuilder', '.editable-mode', function () {
            mode = String($(this).data('mode'));
            sync();
            render();
        })
        .on('change.editableBuilder', '.editable-pick', function () {
            this.checked ? chosen.add(this.value) : chosen.delete(this.value);
            sync();
        });
    sync();
    render();
}

/**
 * Build the automatic routing rules: field, comparison, value and the step to go to.
 * Keeps the hidden #stageConditions JSON and the #stageDefaultNext choice in step.
 * @param {{stages:Array,currentId:string,fields:Array<{name:string,label:string}>}} options - Draft stages, edited step and fields.
 * @returns {void} Updates the relevant UI or state.
 */
function mountRulesBuilder({ stages, currentId, fields }) {
    const host = $('#stageRulesBuilder');
    let rules = [];
    try {
        rules = JSON.parse($('#stageConditions').val() || '[]');
    } catch {
        rules = [];
    }
    if (!Array.isArray(rules)) rules = [];
    $('#stageDefaultNext').html(targetOptions(stages, currentId, $('#stageDefaultNext').val() || $('#stageDefaultNext').attr('data-selected') || '', false));
    const sync = () => $('#stageConditions').val(JSON.stringify(rules));
    const fieldOptions = (selected) => {
        const known = fields.some((f) => f.name === selected) || !selected;
        return [
            '<option value="">Field…</option>',
            ...fields.map((f) => `<option value="${esc(f.name)}" ${f.name === selected ? 'selected' : ''}>${esc(f.label || f.name)}</option>`),
            known ? '' : `<option value="${esc(selected)}" selected>${esc(selected)}</option>`,
        ].join('');
    };
    const render = () => {
        host.html(
            `${rules
                .map(
                    (rule, i) =>
                        `<div class="row g-2 align-items-center mb-2" data-i="${i}"><div class="col-sm-3"><select class="form-select form-select-sm rule-field" aria-label="Field">${fieldOptions(rule.field)}</select></div><div class="col-sm-2"><select class="form-select form-select-sm rule-operator" aria-label="Comparison">${CONDITION_OPERATORS.map(([code, label]) => `<option value="${code}" ${rule.operator === code ? 'selected' : ''}>${label}</option>`).join('')}</select></div><div class="col-sm-2"><input class="form-control form-control-sm rule-value" value="${esc(rule.value ?? '')}" placeholder="Value" aria-label="Value"></div><div class="col-sm-4"><select class="form-select form-select-sm rule-target" aria-label="Go to">${targetOptions(stages, currentId, rule.toStageId, false)}</select></div><div class="col-sm-1"><button type="button" class="btn btn-sm btn-outline-danger rule-remove" aria-label="Remove rule">×</button></div></div>`,
                )
                .join('') || '<div class="text-secondary small mb-2">No rules yet.</div>'}<button type="button" class="btn btn-sm btn-outline-primary" id="stageRuleAdd">Add a rule</button>`,
        );
    };
    host.off('.rulesBuilder')
        .on('click.rulesBuilder', '#stageRuleAdd', () => {
            rules.push({ field: '', operator: 'eq', value: '', toStageId: '' });
            sync();
            render();
        })
        .on('click.rulesBuilder', '.rule-remove', function () {
            rules.splice(Number($(this).closest('[data-i]').data('i')), 1);
            sync();
            render();
        })
        .on('change.rulesBuilder input.rulesBuilder', 'select,input', function () {
            const row = $(this).closest('[data-i]');
            const rule = rules[Number(row.data('i'))];
            if (!rule) return;
            rule.field = row.find('.rule-field').val();
            rule.operator = row.find('.rule-operator').val();
            rule.value = row.find('.rule-value').val();
            rule.toStageId = row.find('.rule-target').val();
            sync();
        });
    sync();
    render();
}

/**
 * Fill the final-status choice, keeping an unusual saved value.
 * @param {string} current - Status saved on the step.
 * @returns {void} Updates the relevant UI or state.
 */
function mountEndStatus(current) {
    const options = [...new Set(['Closed', 'Rejected', current].filter(Boolean))];
    $('#stageEndStatus').html(options.map((o) => `<option value="${esc(o)}">${esc(o)}</option>`).join(''));
    $('#stageEndStatus').val(current || 'Closed');
}

export {
    applyStageTypeVisibility,
    mountButtonsBuilder,
    mountEditableFieldsPicker,
    mountEndStatus,
    mountRolePicker,
    mountRoleSelect,
    mountRulesBuilder,
};
