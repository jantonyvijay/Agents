﻿import { apiDownload } from '../api/client.js';

/**
 * Save a file and release its temporary URL after the browser starts downloading it.
 * Explicit names take precedence; attachments use the Content-Disposition filename.
 * @param {string} url - Authenticated download route.
 * @param {string} [filename] - Optional name supplied by the workflow.
 * @returns {Promise<void>} Resolves once the browser download has been triggered.
 */
export async function downloadFile(url, filename) {
    const { blob, disposition } = await apiDownload(url);
    const encodedName = (disposition.match(/filename\*=UTF-8''([^;]+)/i) ||
        disposition.match(/filename="?([^";]+)"?/i))?.[1];
    let serverName = encodedName || 'attachment';
    try {
        serverName = decodeURIComponent(serverName);
    } catch {
        /* Keep malformed server names usable. */
    }
    const link = document.createElement('a');
    const objectUrl = URL.createObjectURL(blob);
    try {
        link.href = objectUrl;
        link.download = filename || serverName;
        link.click();
    } finally {
        setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    }
}
