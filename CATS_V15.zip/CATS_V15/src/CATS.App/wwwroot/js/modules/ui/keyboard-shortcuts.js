const controls = 'button,a[href],a[data-view],input:not([type="hidden"]),select,textarea,summary,[role="button"],[role="tab"],[tabindex="0"]';

export function assignKeyTips(elements) {
    const used = new Set();
    const width = Math.max(2, String(elements.length).length);
    let number = 1;
    return elements.map((element) => {
        const name = (element.getAttribute('aria-label') || element.getAttribute('title') || element.textContent || element.placeholder || '').trim();
        const preferred = /^save\b/i.test(name) ? 'S' : /^preview\b/i.test(name) ? 'P'
            : /^(add|new)\b/i.test(name.replace(/^\+\s*/, '')) ? 'N' : /^(search|filter)\b/i.test(name) ? 'F'
            : /^back\b/i.test(name) ? 'B' : /^(close|cancel)\b/i.test(name) ? 'C' : null;
        const key = preferred && !used.has(preferred) ? preferred : String(number++).padStart(width, '0');
        used.add(key);
        return { element, key, name };
    });
}

export function enableKeyboardShortcuts() {
    let soloAlt = false, layer = null, entries = [], prefix = '';
    const visible = (element) => {
        if (!element.isConnected || element.matches(':disabled') || element.closest('[hidden],[inert],[aria-hidden="true"],[aria-disabled="true"]')) return false;
        const style = window.getComputedStyle(element), rect = element.getBoundingClientRect();
        return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0
            && rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth;
    };
    const scope = () => [...document.querySelectorAll('.modal.show,dialog[open]')].filter(visible).at(-1) || document;
    function hide() {
        layer?.remove();
        layer = null;
        entries = [];
        prefix = '';
    }
    function show() {
        entries = assignKeyTips([...scope().querySelectorAll(controls)].filter(visible));
        if (!entries.length) return;
        layer = document.createElement('div');
        layer.className = 'cats-keytips';
        const help = document.createElement('div');
        help.className = 'cats-keytips-help';
        help.setAttribute('role', 'status');
        help.textContent = 'Keyboard shortcuts: type a highlighted key • Esc or Alt to close';
        layer.appendChild(help);
        entries.forEach((entry) => {
            const rect = entry.element.getBoundingClientRect();
            const badge = document.createElement('span');
            badge.className = 'cats-keytip';
            badge.textContent = entry.key;
            badge.title = entry.name;
            badge.setAttribute('aria-hidden', 'true');
            badge.style.left = `${Math.max(2, Math.min(rect.left + 8, window.innerWidth - 45))}px`;
            badge.style.top = `${Math.max(2, Math.min(rect.top - 7, window.innerHeight - 24))}px`;
            entry.badge = badge;
            layer.appendChild(badge);
        });
        document.body.appendChild(layer);
    }
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Alt') {
            if (!event.repeat) soloAlt = !event.ctrlKey && !event.metaKey && !event.shiftKey;
            return;
        }
        soloAlt = false;
        if (!layer) return;
        if (event.ctrlKey || event.metaKey || event.altKey || event.isComposing || event.getModifierState?.('AltGraph')) { hide(); return; }
        if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); hide(); return; }
        if (event.key === 'Tab') { hide(); return; }
        if (event.repeat || !/^[a-z0-9]$/i.test(event.key)) { hide(); return; }
        event.preventDefault();
        event.stopImmediatePropagation();
        prefix += event.key.toUpperCase();
        const candidates = entries.filter((entry) => entry.key.startsWith(prefix));
        if (!candidates.length) { hide(); return; }
        entries.forEach((entry) => { entry.badge.hidden = !entry.key.startsWith(prefix); });
        const match = candidates.find((entry) => entry.key === prefix);
        if (!match) return;
        const element = match.element;
        const allowed = visible(element) && scope().contains(element);
        hide();
        if (!allowed) return;
        element.focus();
        if (!element.matches('textarea,select,input:not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="checkbox"]):not([type="radio"]):not([type="file"])')) element.click();
    }, true);
    document.addEventListener('keyup', (event) => {
        if (event.key !== 'Alt') return;
        if (soloAlt) {
            event.preventDefault();
            if (layer) hide(); else show();
        }
        soloAlt = false;
    }, true);
    document.addEventListener('pointerdown', hide, true);
    document.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    window.addEventListener('blur', () => { soloAlt = false; hide(); });
}
