import { closeTopNavigation } from './top-navigation.js';
import { localStore } from '../core/storage.js';
import { validThemeColor } from '../validation/theme.js';
import { state } from '../core/state.js';

const themeMedia = window.matchMedia('(prefers-color-scheme: dark)');

const themeLabels = {
    light: 'Light',
    dark: 'Dark',
    system: 'Match browser',
    ocean: 'Ocean',
    forest: 'Forest',
    violet: 'Violet',
    white: 'White',
    blue: 'Blue',
    custom: 'Custom colour',
};

/**
 * Interpolate RGB channels toward a target color and return a padded hexadecimal color.
 * @param {*} hex - Six-digit hexadecimal source color.
 * @param {*} target - Target RGB channel values.
 * @param {*} amount - Interpolation fraction toward the target color.
 * @returns {string} Computed value for the caller.
 */
function mixColor(hex, target, amount) {
    const source = hex
        .slice(1)
        .match(/.{2}/g)
        .map((part) => parseInt(part, 16));
    const mixed = source.map((value, index) => Math.round(value + (target[index] - value) * amount));
    return `#${mixed.map((value) => value.toString(16).padStart(2, '0')).join('')}`;
}

/**
 * Read the per-user custom accent, validate it, and fall back to the default blue.
 * @returns {string} Computed value for the caller.
 */
function getCustomThemeColor() {
    try {
        const value = localStore.getItem(preferenceKey('theme_color'));
        return validThemeColor(value) ? value.toUpperCase() : '#0B3D91';
    } catch {
        return '#0B3D91';
    }
}

/**
 * Relative luminance (WCAG) of a six-digit hexadecimal color.
 * @param {string} hex - Source color.
 * @returns {number} Luminance from 0 (black) to 1 (white).
 */
function luminance(hex) {
    const [r, g, b] = hex
        .slice(1)
        .match(/.{2}/g)
        .map((part) => {
            const channel = parseInt(part, 16) / 255;
            return channel <= 0.03928 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
        });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/**
 * WCAG contrast ratio between two colors.
 * @param {string} a - First color.
 * @param {string} b - Second color.
 * @returns {number} Contrast ratio from 1 to 21.
 */
function contrast(a, b) {
    const [high, low] = [luminance(a), luminance(b)].sort((x, y) => y - x);
    return (high + 0.05) / (low + 0.05);
}

/**
 * Darken a color until it is readable on a background, so text stays legible whatever accent was picked.
 * @param {string} color - Preferred text color.
 * @param {string} background - Background the text sits on.
 * @param {number} [minimum] - Required contrast ratio.
 * @returns {string} Adjusted six-digit hexadecimal color.
 */
function readableOn(color, background, minimum = 4.5) {
    let adjusted = color;
    for (let step = 0; step < 20 && contrast(adjusted, background) < minimum; step++) adjusted = mixColor(adjusted, [0, 0, 0], 0.15);
    return contrast(adjusted, background) >= minimum ? adjusted : '#111827';
}

const DARK_ON_LIGHT = '#111827';
const customThemeProperties = [];

/**
 * Choose light or dark text for the navigation chrome, whichever reads best on every chrome surface.
 * @param {string[]} surfaces - Background colors the text will sit on.
 * @returns {boolean} True when light text is the better choice.
 */
function prefersLightText(surfaces) {
    const worst = (text) => Math.min(...surfaces.map((surface) => contrast(text, surface)));
    return worst('#ffffff') >= worst(DARK_ON_LIGHT);
}

/**
 * Derive contrast and surface colors from the chosen accent and update CSS variables.
 * Light accents get dark text and dark accents get light text, on the navigation, dialogs, tabs and buttons.
 * @param {*} color - Requested custom accent color.
 * @returns {void} Updates the relevant UI or state.
 */
function applyCustomThemeColor(color) {
    const selected = validThemeColor(color) ? color.toUpperCase() : '#0B3D91';
    const lightAccent = contrast(DARK_ON_LIGHT, selected) > contrast('#ffffff', selected);
    // Dark accents get darker navigation surfaces with light text; light accents stay light with dark text.
    const shade = (amount) => (lightAccent ? mixColor(selected, [255, 255, 255], amount) : mixColor(selected, [0, 0, 0], amount));
    const darker = shade(0.42);
    const sidebar = shade(lightAccent ? 0.25 : 0.3);
    const popup = shade(lightAccent ? 0.12 : 0.2);
    const gradient = [shade(lightAccent ? 0.35 : 0.4), selected, shade(lightAccent ? 0.2 : 0.2)];
    const headingBg = mixColor(selected, [255, 255, 255], 0.84);
    const appBg = mixColor(selected, [255, 255, 255], 0.94);
    const text = readableOn(mixColor(selected, [0, 0, 0], 0.68), appBg, 7);
    const headingText = readableOn(text, headingBg, 7);
    const lightChromeText = prefersLightText([selected, sidebar, popup, ...gradient]);
    const chromeText = lightChromeText ? '#ffffff' : DARK_ON_LIGHT;
    const chromeMuted = lightChromeText ? '#d6e1ee' : '#2b3647';
    const accentText = contrast('#ffffff', selected) >= contrast(DARK_ON_LIGHT, selected) ? '#ffffff' : DARK_ON_LIGHT;
    const linkColor = readableOn(selected, '#ffffff', 4.5);
    const root = document.documentElement.style;
    const set = (name, value) => {
        root.setProperty(name, value);
        if (!customThemeProperties.includes(name)) customThemeProperties.push(name);
    };
    set('--cats-app-bg', appBg);
    set('--cats-surface-muted', mixColor(selected, [255, 255, 255], 0.9));
    set('--cats-surface-hover', mixColor(selected, [255, 255, 255], 0.84));
    set('--cats-border', mixColor(selected, [255, 255, 255], 0.72));
    set('--cats-border-strong', mixColor(selected, [255, 255, 255], 0.58));
    set('--cats-text', text);
    set('--cats-muted', readableOn(mixColor(text, [255, 255, 255], 0.35), appBg, 4.5));
    set('--cats-primary-soft', headingBg);
    set('--cats-primary-soft-text', headingText);
    set('--cats-accent', selected);
    set('--cats-on-accent', accentText);
    set('--bs-primary', linkColor);
    set(
        '--bs-primary-rgb',
        linkColor
            .slice(1)
            .match(/.{2}/g)
            .map((part) => parseInt(part, 16))
            .join(','),
    );
    set('--bs-link-color', linkColor);
    set('--cats-topbar-bg', selected);
    set('--cats-sidebar-bg', sidebar);
    set('--cats-card-heading-bg', headingBg);
    set('--cats-card-heading-text', headingText);
    set('--cats-form-bg', appBg);
    set('--cats-popup-heading-bg', popup);
    set('--cats-sidebar-image-tint', `${darker}dd`);
    set('--cats-nav-gradient-start', gradient[0]);
    set('--cats-nav-gradient-mid', gradient[1]);
    set('--cats-nav-gradient-end', gradient[2]);
    set('--cats-nav-text', chromeText);
    set('--cats-nav-muted', chromeMuted);
    set('--cats-on-chrome', chromeText);
    // Table and grid headings follow the picked colour too, with light or dark text and matching dividers.
    const gridStart = lightAccent ? mixColor(selected, [255, 255, 255], 0.2) : mixColor(selected, [0, 0, 0], 0.1);
    const gridEnd = lightAccent ? mixColor(selected, [255, 255, 255], 0.05) : mixColor(selected, [0, 0, 0], 0.35);
    const lightGridText = prefersLightText([gridStart, gridEnd]);
    set('--cats-grid-heading-start', gridStart);
    set('--cats-grid-heading-end', gridEnd);
    set('--cats-grid-heading-text', lightGridText ? '#ffffff' : DARK_ON_LIGHT);
    set('--cats-grid-overlay', lightGridText ? '255,255,255' : '0,0,0');
    set('--cats-chrome-overlay', lightChromeText ? '255,255,255' : '0,0,0');
    set('--cats-chrome-close-filter', lightChromeText ? 'brightness(0) invert(1)' : 'none');
    $('#customThemeColor').val(selected);
}

/**
 * Remove the inline custom-colour variables so a preset theme is not overridden by an earlier custom pick.
 * @returns {void} Updates the relevant UI or state.
 */
function clearCustomThemeColor() {
    const root = document.documentElement.style;
    customThemeProperties.splice(0).forEach((name) => root.removeProperty(name));
    root.removeProperty('--cats-accent');
}

/**
 * Read a supported per-user theme preference, defaulting to the browser theme.
 * @returns {string} Computed value for the caller.
 */
function getThemePreference() {
    try {
        const value = localStore.getItem(preferenceKey('theme'));
        return Object.hasOwn(themeLabels, value) ? value : 'system';
    } catch {
        return 'system';
    }
}

/**
 * Synchronize theme labels, selection indicators, and accessible checked states.
 * @param {*} preference - Requested theme preference.
 * @returns {void} Updates the relevant UI or state.
 */
function updateThemeControls(preference) {
    const selected = Object.hasOwn(themeLabels, preference) ? preference : 'system';
    $('#themeCurrentLabel').text(themeLabels[selected]);
    $('.theme-option').each(function () {
        const active = $(this).data('theme') === selected;
        $(this).toggleClass('is-active', active).attr('aria-checked', String(active));
        $(this).find('.theme-option-check').toggleClass('is-visible', active);
    });
}

/**
 * Resolve browser-dependent appearance, apply theme attributes, and optionally persist the selection.
 * @param {*} preference - Requested theme preference.
 * @param {*} [persist] - Whether to save this choice for the active user.
 * @returns {void} Updates the relevant UI or state.
 */
function applyTheme(preference, persist = true) {
    const selected = Object.hasOwn(themeLabels, preference) ? preference : 'system';
    const resolved =
        selected === 'system' ? (themeMedia.matches ? 'dark' : 'light') : selected === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-bs-theme', resolved);
    document.documentElement.setAttribute('data-cats-theme', selected);
    document.documentElement.style.colorScheme = resolved;
    if (selected === 'custom') applyCustomThemeColor(getCustomThemeColor());
    else {
        clearCustomThemeColor();
        document.querySelector?.('.topbar')?.style.removeProperty('background');
    }
    if (persist) {
        try {
            localStore.setItem(preferenceKey('theme'), selected);
        } catch {}
    }
    updateThemeControls(selected);
}

/**
 * Namespace a preference key by the signed-in user, with a guest fallback.
 * @param {*} kind - Preference category.
 * @returns {string} Computed value for the caller.
 */
function preferenceKey(kind) {
    return 'cats_' + kind + '_' + encodeURIComponent(state.user?.id || state.user?.userName || 'guest');
}

/**
 * Apply a supported page density and sidebar layout, optionally saving it per user.
 * @param {*} value - Value to validate or apply.
 * @param {*} [persist] - Whether to save this choice for the active user.
 * @returns {void} Updates the relevant UI or state.
 */
function applyLayout(value, persist = true) {
    const selected = ['standard', 'compact', 'wide', 'minimal', 'top-menu'].includes(value) ? value : 'standard';
    closeTopNavigation();
    document.documentElement.dataset.catsLayout = selected;
    setSidebarCollapsed(selected === 'wide');
    $('#userLayout').val(selected);
    if (persist) {
        try {
            localStore.setItem(preferenceKey('layout'), selected);
        } catch {}
    }
}

/**
 * Synchronize the sidebar button with the visible desktop or mobile navigation state.
 * @returns {void} Updates the button label, tooltip, and icon state.
 */
function updateSidebarToggle() {
    const open = window.innerWidth < 768
        ? $('#sidebar').hasClass('mobile-open')
        : !$('body').hasClass('sidebar-collapsed');
    $('#sidebarToggle').attr({
        title: `${open ? 'Close sidebar' : 'Open sidebar'} (Ctrl+Shift+S)`,
        'aria-label': open ? 'Close sidebar' : 'Open sidebar',
        'data-sidebar-state': open ? 'open' : 'closed',
    });
}

/**
 * Collapse or expand desktop navigation without changing the workspace appearance preference.
 * @param {boolean} collapsed - Whether the desktop sidebar should show only icons.
 * @returns {void} Updates sidebar width and its toggle button.
 */
function setSidebarCollapsed(collapsed) {
    $('body').toggleClass('sidebar-collapsed', collapsed);
    updateSidebarToggle();
}

/**
 * Toggle navigation for the current viewport, retaining the selected layout and theme.
 * Used by both the sidebar button and its keyboard shortcut.
 * @returns {void} Opens or closes navigation without overwriting saved appearance settings.
 */
function toggleSidebar() {
    if (document.documentElement.dataset.catsLayout === 'top-menu') return;
    if (window.innerWidth < 768) {
        $('#sidebar').toggleClass('mobile-open');
        updateSidebarToggle();
    } else {
        setSidebarCollapsed(!$('body').hasClass('sidebar-collapsed'));
    }
}

const sectionLayoutOptions = ['template', 'single', 'tab', 'accordion', 'popup', 'wizard'];

/**
 * Read a supported per-user section layout or defer to the template.
 * @returns {string} Computed value for the caller.
 */
function getSectionLayout() {
    try {
        const value = localStore.getItem(preferenceKey('section_layout'));
        return sectionLayoutOptions.includes(value) ? value : 'template';
    } catch {
        return 'template';
    }
}

/**
 * Persist a supported section layout and synchronize its selector.
 * @param {*} value - Value to validate or apply.
 * @returns {void} Updates the relevant UI or state.
 */
function applySectionLayout(value) {
    const selected = sectionLayoutOptions.includes(value) ? value : 'template';
    try {
        localStore.setItem(preferenceKey('section_layout'), selected);
    } catch {}
    $('#userSectionLayout').val(selected);
}

/**
 * Restore theme, page layout, and section layout for the active account.
 * @returns {void} Updates the relevant UI or state.
 */
function restoreAppearance() {
    applyTheme(getThemePreference(), false);
    let layout = 'standard';
    try {
        layout = localStore.getItem(preferenceKey('layout'));
    } catch {}
    applyLayout(layout, false);
    $('#userSectionLayout').val(getSectionLayout());
}

/**
 * Reapply browser appearance only when the user selected the system theme.
 * @returns {void} Updates the relevant UI or state.
 */
const handleSystemThemeChange = () => {
    if (getThemePreference() === 'system') applyTheme('system', false);
};

export {
    themeMedia,
    themeLabels,
    mixColor,
    getCustomThemeColor,
    applyCustomThemeColor,
    getThemePreference,
    updateThemeControls,
    applyTheme,
    preferenceKey,
    applyLayout,
    toggleSidebar,
    sectionLayoutOptions,
    getSectionLayout,
    applySectionLayout,
    restoreAppearance,
    handleSystemThemeChange,
};
