import { api } from '../api/client.js';
import { esc } from '../core/utils.js';

/** Menu tree for the signed-in user, from GET api/menus (Menu → SubMenu → Child, filtered by role and permission on the server). */
let tree = [];
const byCode = new Map();
let activeKey = 'dashboard';
let activeCodes = new Set();
let bound = false;

/** Screens opened from another screen keep their parent menu entry highlighted. */
const parentViews = { detail: 'alerts', atmStaffUpload: 'atmStaffList', atmStaffConfig: 'atmStaffList' };

const iconPaths = {
    dashboard: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    alerts: '<path d="M12 3 2 20h20L12 3Z"/><path d="M12 9v5m0 3v1"/>',
    upload: '<path d="M12 16V3m-5 5 5-5 5 5M4 15v6h16v-6"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3 7 9 6 9-6"/>',
    workflow: '<rect x="3" y="3" width="6" height="6" rx="2"/><rect x="15" y="15" width="6" height="6" rx="2"/><path d="M6 9v9h9M9 6h9v9"/>',
    settings: '<circle cx="12" cy="12" r="4"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/>',
    reports: '<path d="M4 20V4m0 16h16"/><rect x="7" y="12" width="3" height="5" rx="1"/><rect x="12" y="8" width="3" height="9" rx="1"/><rect x="17" y="5" width="3" height="12" rx="1"/>',
    masters: '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    design: '<path d="m4 20 4-1 11-11-3-3L5 16l-1 4Z"/><path d="m14 7 3 3"/>',
    operations: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
};

/** Top-level menus created before icons were configured keep the default icon in the database; pick one by code instead. */
const groupIcons = { workspace: 'dashboard', operations: 'operations', reports: 'reports', masters: 'masters', design: 'design', administration: 'settings' };

const hasChildren = (node) => Array.isArray(node.children) && node.children.length > 0;
const iconKey = (node) => (node.icon && node.icon !== 'dashboard' ? node.icon : (!node.parent && groupIcons[node.code]) || node.icon || 'dashboard');
const tip = (node) => (node.description ? `${node.label} - ${node.description}` : node.label);

/**
 * Render a small decorative navigation icon without external image dependencies.
 * @param {string} name - Icon key of the menu entry.
 * @returns {string} Inline SVG markup hidden from assistive technology.
 */
function navigationIcon(node) {
    const name = typeof node === 'string' ? node : iconKey(node);
    return `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths.dashboard}</svg>`;
}

function index(nodes, parent) {
    nodes.forEach((node) => {
        node.parent = parent;
        byCode.set(node.code, node);
        index(node.children || [], node);
    });
}

function findByView(nodes, key) {
    for (const node of nodes) {
        if (!hasChildren(node) && node.view === key) return node;
        const hit = findByView(node.children || [], key);
        if (hit) return hit;
    }
    return null;
}

/** Work out which entries are on the path to the current screen so their menu and sub menus can be highlighted. */
function computeActive(view, arg) {
    const keys = [arg ? `${view}:${arg}` : '', view, parentViews[view] || ''].filter(Boolean);
    activeKey = view;
    activeCodes = new Set();
    for (const key of keys) {
        const hit = findByView(tree, key);
        if (!hit) continue;
        for (let n = hit; n; n = n.parent) activeCodes.add(n.code);
        return;
    }
}

/**
 * Load the menu for the signed-in user and render the sidebar. Role and permission filtering is done by the server.
 * @returns {Promise<void>} Resolves after the sidebar is rendered.
 */
export async function loadNavigation() {
    tree = (await api('/api/menus')) || [];
    byCode.clear();
    index(tree, null);
    bindOnce();
    closeTopNavigation();
    computeActive(activeKey, '');
    $('#sidebarNav').html(sidebarHtml());
}

/**
 * Return leaf navigation entries already authorized for the signed-in user.
 * @returns {Array<{code: string, view: string, label: string, description: string, category: string}>} Accessible screens.
 */
function accessibleNavigationItems() {
    const items = [];
    const visit = (nodes, category = '') => {
        nodes.forEach((node) => {
            const nextCategory = category || node.label;
            if (hasChildren(node)) {
                visit(node.children, nextCategory);
                return;
            }
            if (node.view)
                items.push({
                    code: node.code,
                    view: node.view,
                    label: node.label,
                    description: node.description || '',
                    category,
                });
        });
    };
    visit(tree);
    return items;
}

function sidebarHtml() {
    return tree
        .map((node) => {
            const active = activeCodes.has(node.code) ? ' active' : '';
            if (hasChildren(node))
                return `<button type="button" class="nav-link text-start cats-side-top cats-menu-group${active}" data-menu-code="${esc(node.code)}" aria-haspopup="true" aria-expanded="false" title="${esc(tip(node))}"><span class="cats-side-icon" aria-hidden="true">${navigationIcon(node)}</span><span class="cats-side-label">${esc(node.label)}</span><span class="cats-side-chevron" aria-hidden="true">›</span></button>`;
            return `<button type="button" class="nav-link text-start cats-side-top${active}" data-view="${esc(node.view)}" title="${esc(tip(node))}"><span class="cats-side-icon" aria-hidden="true">${navigationIcon(node)}</span><span class="cats-side-label">${esc(node.label)}</span></button>`;
        })
        .join('');
}

/**
 * Render the horizontal menu: one trigger per top-level menu; sub menus open as cascading panels.
 * @returns {void} Rebuilds the trigger buttons.
 */
export function renderTopNavigation() {
    closeTopNavigation();
    $('#topNavigation').html(
        tree
            .map((node) => {
                const active = activeCodes.has(node.code) ? ' is-active' : '';
                if (hasChildren(node))
                    return `<button type="button" class="cats-top-trigger cats-menu-group${active}" data-menu-code="${esc(node.code)}" aria-haspopup="true" aria-expanded="false">${esc(node.label)}<span class="cats-top-caret" aria-hidden="true"></span></button>`;
                return `<button type="button" class="cats-top-trigger${active}" data-view="${esc(node.view)}">${esc(node.label)}</button>`;
            })
            .join(''),
    );
}

/**
 * Highlight the entries on the path to the active screen in the sidebar and the top menu.
 * @param {string} view - Application route name.
 * @param {string} [arg] - Optional route argument; a menu entry may use the key "view:arg".
 * @returns {void} Updates active styles.
 */
export function syncTopNavigation(view, arg) {
    computeActive(view, arg);
    $('#sidebarNav .cats-side-top').each(function () {
        const node = byCode.get(this.dataset.menuCode) || findByView(tree, this.dataset.view);
        const on = !!node && activeCodes.has(node.code);
        $(this).toggleClass('active', on);
        if (on) this.setAttribute('aria-current', 'page');
        else this.removeAttribute('aria-current');
    });
    $('#topNavigation .cats-top-trigger').each(function () {
        const node = byCode.get(this.dataset.menuCode) || findByView(tree, this.dataset.view);
        $(this).toggleClass('is-active', !!node && activeCodes.has(node.code));
    });
}

function flyoutHost() {
    let host = document.getElementById('catsFlyouts');
    if (!host) {
        host = document.createElement('div');
        host.id = 'catsFlyouts';
        document.body.appendChild(host);
    }
    return host;
}

function panelHtml(nodes, level) {
    return `<div class="cats-flyout" role="menu" data-level="${level}">${nodes
        .map((node) => {
            const active = activeCodes.has(node.code) ? ' active' : '';
            const copy = `<span class="cats-flyout-glyph" aria-hidden="true">${navigationIcon(node)}</span><span class="cats-flyout-copy"><strong>${esc(node.label)}</strong>${node.description ? `<small>${esc(node.description)}</small>` : ''}</span>`;
            if (hasChildren(node))
                return `<button type="button" role="menuitem" class="cats-flyout-item cats-menu-group${active}" data-menu-code="${esc(node.code)}" aria-haspopup="true" aria-expanded="false">${copy}<span class="cats-flyout-chevron" aria-hidden="true">›</span></button>`;
            return `<button type="button" role="menuitem" class="cats-flyout-item${active}" data-view="${esc(node.view)}">${copy}</button>`;
        })
        .join('')}</div>`;
}

function closeFrom(level) {
    $('#catsFlyouts .cats-flyout').each(function () {
        if (Number(this.dataset.level) >= level) $(this).remove();
    });
    $('.cats-menu-group[aria-expanded="true"]').each(function () {
        const owner = $(this).closest('.cats-flyout');
        const ownLevel = owner.length ? Number(owner[0].dataset.level) + 1 : 0;
        if (ownLevel >= level) this.setAttribute('aria-expanded', 'false');
    });
}

/** Open the panel for a menu entry: below a top-menu trigger, to the right of the sidebar, or to the right of the parent panel. */
function openPanel(anchor, node) {
    const owner = $(anchor).closest('.cats-flyout');
    const level = owner.length ? Number(owner[0].dataset.level) + 1 : 0;
    closeFrom(level);
    anchor.setAttribute('aria-expanded', 'true');
    const panel = $(panelHtml(node.children, level)).appendTo(flyoutHost())[0];
    const rect = anchor.getBoundingClientRect();
    const size = panel.getBoundingClientRect();
    let left;
    let top;
    if (owner.length) {
        const parent = owner[0].getBoundingClientRect();
        left = parent.right - 4;
        top = rect.top - 8;
        if (left + size.width > window.innerWidth - 8) left = Math.max(8, parent.left - size.width + 4);
    } else if ($(anchor).closest('#topNavigation').length) {
        left = rect.left;
        top = rect.bottom + 6;
    } else {
        const sidebar = document.getElementById('sidebar')?.getBoundingClientRect();
        left = (sidebar ? sidebar.right : rect.right) + 4;
        top = rect.top - 8;
    }
    left = Math.max(8, Math.min(left, window.innerWidth - size.width - 8));
    top = Math.max(8, Math.min(top, window.innerHeight - size.height - 8));
    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
}

/**
 * Close every open cascading panel before navigation or a layout change.
 * @returns {void} Removes the panels and resets aria-expanded.
 */
export function closeTopNavigation() {
    closeFrom(0);
}

export { accessibleNavigationItems };

function bindOnce() {
    if (bound) return;
    bound = true;
    $(document).on('click', '.cats-menu-group', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const node = byCode.get(this.dataset.menuCode);
        if (!node) return;
        if (this.getAttribute('aria-expanded') === 'true') {
            // Inside a panel the hover already opened the sub menu, so a click keeps it open.
            if ($(this).closest('.cats-flyout').length) return;
            closeFrom(0);
            return;
        }
        openPanel(this, node);
    });
    // Moving over a sub menu opens it, as in a desktop cascading menu.
    $(document).on('mouseenter', '.cats-flyout .cats-menu-group', function () {
        const node = byCode.get(this.dataset.menuCode);
        if (node && this.getAttribute('aria-expanded') !== 'true') openPanel(this, node);
    });
    $(document).on('mouseenter', '.cats-flyout .cats-flyout-item:not(.cats-menu-group)', function () {
        const owner = $(this).closest('.cats-flyout');
        closeFrom(Number(owner[0].dataset.level) + 1);
    });
    $(document).on('click', (e) => {
        if (!$(e.target).closest('.cats-flyout,.cats-menu-group').length) closeTopNavigation();
    });
    $(document).on('keydown', (e) => {
        if (e.key === 'Escape') closeTopNavigation();
    });
    $(window).on('resize', closeTopNavigation);
    $('#sidebar').on('scroll', closeTopNavigation);
}
