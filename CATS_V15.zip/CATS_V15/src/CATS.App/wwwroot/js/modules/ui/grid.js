import { observeTask } from '../events/guard.js';
import { localStore } from '../core/storage.js';
import { json, esc } from '../core/utils.js';
import { guardEvent } from '../events/guard.js';

/** Small inline SVG icons for the per-column menu sections/buttons (match the Kendo reference icons). */
const MENU_ICONS = {
    sortAsc: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13V3M4 3 1.5 5.5M4 3l2.5 2.5"/><line x1="8.5" y1="5" x2="14.5" y2="5"/><line x1="8.5" y1="8" x2="13" y2="8"/><line x1="8.5" y1="11" x2="11.5" y2="11"/></svg>',
    sortDesc: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><path d="M4 3v10M4 13 1.5 10.5M4 13l2.5-2.5"/><line x1="8.5" y1="5" x2="11.5" y2="5"/><line x1="8.5" y1="8" x2="13" y2="8"/><line x1="8.5" y1="11" x2="14.5" y2="11"/></svg>',
    columns: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="1.5" y="2.5" width="13" height="11" rx="1.5"/><line x1="8" y1="2.5" x2="8" y2="13.5"/></svg>',
    filter: '<svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor"><path d="M1.5 2h13l-4.75 5.7v4.1l-3.5 1.7V7.7z"/></svg>',
    group: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3" stroke-dasharray="2 1.6"><rect x="2" y="2" width="12" height="12" rx="1.5"/></svg>',
    move: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"><line x1="2" y1="4" x2="14" y2="4"/><line x1="2" y1="8" x2="14" y2="8"/><line x1="2" y1="12" x2="14" y2="12"/></svg>',
    search: '<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="6.8" cy="6.8" r="4.3"/><line x1="10.1" y1="10.1" x2="14" y2="14"/></svg>',
    clear: '<svg viewBox="0 0 16 16" width="10" height="10" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="2" y1="2" x2="14" y2="14"/><line x1="14" y1="2" x2="2" y2="14"/></svg>',
};

/** Operator choices offered by the per-column Kendo-style filter builder. */
const FILTER_OPERATORS = [
    ['contains', 'Contains'],
    ['doesnotcontain', 'Does not contain'],
    ['eq', 'Is equal to'],
    ['neq', 'Is not equal to'],
    ['startswith', 'Starts with'],
    ['endswith', 'Ends with'],
    ['gt', 'Is greater than'],
    ['lt', 'Is less than'],
    ['isempty', 'Is empty'],
    ['isnotempty', 'Is not empty'],
];

/**
 * Evaluate a single filter operator/value pair against a cell's text content.
 * @param {*} cellText - Raw text content of the cell being tested.
 * @param {*} op - Operator key from FILTER_OPERATORS.
 * @param {*} value - Comparison value supplied by the user.
 * @returns {boolean} Whether the cell matches the condition.
 */
function matchFilterOperator(cellText, op, value) {
    const cell = cellText.toLowerCase();
    const v = String(value ?? '').toLowerCase();
    const cellNum = Number(cellText.replace(/[^0-9.-]/g, ''));
    const valNum = Number(String(value ?? '').replace(/[^0-9.-]/g, ''));
    switch (op) {
        case 'contains':
            return cell.includes(v);
        case 'doesnotcontain':
            return !cell.includes(v);
        case 'eq':
            return cell === v;
        case 'neq':
            return cell !== v;
        case 'startswith':
            return cell.startsWith(v);
        case 'endswith':
            return cell.endsWith(v);
        case 'gt':
            return !Number.isNaN(cellNum) && !Number.isNaN(valNum) && cellNum > valNum;
        case 'lt':
            return !Number.isNaN(cellNum) && !Number.isNaN(valNum) && cellNum < valNum;
        case 'isempty':
            return cellText.trim() === '';
        case 'isnotempty':
            return cellText.trim() !== '';
        default:
            return true;
    }
}

/**
 * Evaluate a column filter descriptor (one or two combined conditions) against a cell's text.
 * @param {*} cellText - Raw text content of the cell being tested.
 * @param {*} filter - Filter descriptor with op1/val1 and optional op2/val2/combinator.
 * @returns {boolean} Whether the cell matches the filter.
 */
function matchFilter(cellText, filter) {
    const r1 = matchFilterOperator(cellText, filter.op1, filter.val1);
    if (!filter.op2) return r1;
    const r2 = matchFilterOperator(cellText, filter.op2, filter.val2);
    return filter.combinator === 'or' ? r1 || r2 : r1 && r2;
}

/**
 * Initialize sortable columns, the per-column Kendo-style options menu (sort, columns, filter,
 * grouping, locking, and reordering), and persisted visibility/density/wrapping controls once per
 * table.
 * @param {*} table - Table element to enhance.
 * @returns {void} Updates the relevant UI or state.
 */
function enhanceGrid(table) {
    const $table = $(table);
    if ($table.data('catsGrid') || !$table.find('thead th').length) return;
    $table.data('catsGrid', true).addClass('cats-grid');
    enhanceGridSelection($table);
    const headings = $table
        .find('thead th')
        .map((i, th) => $(th).text().trim() || `Column ${i + 1}`)
        .get();
    const key =
        'cats_grid_' +
        headings
            .join('|')
            .toLowerCase()
            .replace(/[^a-z0-9|]+/g, '_');
    let prefs = json(localStore.getItem(key), { hidden: [] });
    const $wrap = $table.closest('.table-responsive').addClass('cats-grid-scroll');
    const $toolbar = $(
        `<div class="cats-grid-toolbar"><span class="cats-group-badge badge rounded-pill text-bg-primary-subtle text-primary d-none"></span><span class="cats-filter-count small text-secondary d-none"></span><button type="button" class="btn btn-sm btn-link p-0 cats-filter-clear-all d-none">Clear all filters</button></div>`,
    );
    $wrap.before($toolbar);
    /**
     * Persist the current grid visibility, density, and wrapping preferences.
     * @returns {void} Updates the relevant UI or state.
     */
    const save = () => {
        try {
            localStore.setItem(key, JSON.stringify(prefs));
        } catch {}
    };
    /**
     * Toggle the selected column consistently across header and body rows.
     * @param {*} index - Zero-based item or column index.
     * @param {*} visible - Whether the control or value should be visible.
     * @returns {void} Updates the relevant UI or state.
     */
    const setColumn = (index, visible) =>
        $table.find('tr').each((_, row) => $(row).children().eq(index).toggle(visible));
    /**
     * Render the shared "Columns" checklist markup used inside every per-column options menu.
     * @returns {string} HTML for the checklist.
     */
    const columnsListHtml = () =>
        headings
            .map(
                (name, index) =>
                    `<label class="cats-menu-check"><input class="form-check-input me-2 cats-column" type="checkbox" data-index="${index}" ${prefs.hidden.includes(index) ? '' : 'checked'}>${esc(name)}</label>`,
            )
            .join('');
    headings.forEach((_, index) => setColumn(index, !prefs.hidden.includes(index)));

    /**
     * Resolve a header cell's current position among its siblings (survives reordering).
     * @param {*} $th - jQuery-wrapped header cell.
     * @returns {number} Zero-based column index.
     */
    const columnIndexOf = ($th) => $th.parent().children().index($th);

    /**
     * Sort data rows by the given header's column, using numeric comparison when applicable.
     * @param {*} $th - Header cell to sort by.
     * @param {*} [direction] - Force 'asc' or 'desc'; omit to toggle the current direction.
     * @returns {void} Updates the relevant UI or state.
     */
    const sortBy = ($th, direction) => {
        if ($table.data('catsGroupTh')) return; // grouping owns row order while active
        const index = columnIndexOf($th);
        const ascending = direction === 'asc' ? true : direction === 'desc' ? false : $th.attr('aria-sort') !== 'ascending';
        $table.find('thead tr').first().children().attr('aria-sort', 'none');
        $th.attr('aria-sort', ascending ? 'ascending' : 'descending');
        const rows = $table
            .find('tbody tr')
            .get()
            .filter((row) => $(row).children().length > 1);
        rows.sort((a, b) => {
            const av = $(a).children().eq(index).text().trim(),
                bv = $(b).children().eq(index).text().trim();
            const an = Number(av.replace(/[^0-9.-]/g, '')),
                bn = Number(bv.replace(/[^0-9.-]/g, ''));
            const result =
                av && bv && !Number.isNaN(an) && !Number.isNaN(bn)
                    ? an - bn
                    : av.localeCompare(bv, undefined, { numeric: true, sensitivity: 'base' });
            return ascending ? result : -result;
        });
        $table.children('tbody').append(rows);
    };

    /**
     * Recompute sticky-left offsets for every locked column so they stay visible while scrolling.
     * @returns {void} Updates the relevant UI or state.
     */
    const updateLockedPositions = () => {
        $table.find('tr > *').removeClass('cats-col-locked').css({ position: '', left: '', 'z-index': '' });
        let left = 0;
        $table
            .find('thead tr')
            .first()
            .children()
            .each(function () {
                const $th = $(this);
                if (!$th.data('locked') || !$th.is(':visible')) return;
                const index = columnIndexOf($th);
                $table.find('tr').each((_, row) => {
                    const $cell = $(row).children().eq(index);
                    if ($cell.length)
                        $cell.addClass('cats-col-locked').css({ position: 'sticky', left: `${left}px`, 'z-index': 2 });
                });
                left += $th.outerWidth() || 0;
            });
    };

    /**
     * Swap a column with its previous or next sibling across every row in the table.
     * @param {*} $th - Header cell to move.
     * @param {*} direction - 'prev' or 'next'.
     * @returns {void} Updates the relevant UI or state.
     */
    const moveColumn = ($th, direction) => {
        const index = columnIndexOf($th);
        const targetIndex = direction === 'prev' ? index - 1 : index + 1;
        if (targetIndex < 0 || targetIndex >= $th.parent().children().length) return;
        $table.find('tr').each(function () {
            const cells = $(this).children();
            const $a = cells.eq(index),
                $b = cells.eq(targetIndex);
            if (!$a.length || !$b.length) return;
            if (direction === 'prev') $a.insertBefore($b);
            else $a.insertAfter($b);
        });
        updateLockedPositions();
    };

    /**
     * Re-evaluate every column's active filter and show only the rows that match all of them.
     * Regroups the active group (if any) so group counts stay accurate.
     * @returns {void} Updates the relevant UI or state.
     */
    const applyAllFilters = () => {
        const $headerCells = $table.find('thead tr').first().children();
        const filters = $headerCells
            .map((index, th) => ({ index, filter: $(th).data('catsFilter') }))
            .get()
            .filter((f) => f.filter);
        const columnCount = $headerCells.length;
        const $rows = ($table.data('catsOriginalRows') || $table.find('tbody tr').get()).filter(
            (row) => $(row).children().length === columnCount,
        );
        let visible = 0;
        $rows.forEach((row) => {
            const $row = $(row);
            const match = filters.every((f) => matchFilter($row.children().eq(f.index).text().trim(), f.filter));
            $row.toggle(match);
            if (match) visible++;
        });
        $table.find('tbody .cats-group-row').toggle(false);
        const $toolbarCount = $toolbar.find('.cats-filter-count');
        $toolbarCount.toggleClass('d-none', filters.length === 0).text(`Showing ${visible} of ${$rows.length}`);
        $toolbar.find('.cats-filter-clear-all').toggleClass('d-none', filters.length === 0);
        $table.trigger('cats-grid:filtered', [{ visible, total: $rows.length }]);
        const $groupTh = $table.data('catsGroupTh');
        if ($groupTh) groupByColumn($($groupTh));
    };

    /**
     * Remove any existing grouping and restore rows to their original relative order.
     * @returns {void} Updates the relevant UI or state.
     */
    const clearGrouping = () => {
        $table.find('tbody .cats-group-row').remove();
        const original = $table.data('catsOriginalRows');
        if (original) $table.children('tbody').append(original.filter((row) => document.contains(row) || true));
        $table.data('catsGroupTh', null);
        $toolbar.find('.cats-group-badge').addClass('d-none').empty();
        $table.find('tbody tr').show();
        applyAllFilters();
    };

    /**
     * Group currently-visible rows by the given column's text value, inserting collapsible
     * group header rows and preserving the pre-grouping row order within each group.
     * @param {*} $th - Header cell to group by.
     * @returns {void} Updates the relevant UI or state.
     */
    function groupByColumn($th) {
        if (!$table.data('catsOriginalRows'))
            $table.data(
                'catsOriginalRows',
                $table
                    .find('tbody tr')
                    .get()
                    .filter((row) => $(row).children().length > 1),
            );
        $table.find('tbody .cats-group-row').remove();
        const index = columnIndexOf($th);
        const columnCount = $th.closest('tr').children().length;
        const label = $th.clone().find('.cats-col-menu-wrap').remove().end().text().trim();
        const rows = $table.data('catsOriginalRows').filter((row) => $(row).css('display') !== 'none');
        const groups = new Map();
        rows.forEach((row) => {
            const value = $(row).children().eq(index).text().trim() || '(blank)';
            if (!groups.has(value)) groups.set(value, []);
            groups.get(value).push(row);
        });
        const $tbody = $table.children('tbody');
        [...groups.keys()]
            .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }))
            .forEach((value) => {
                const members = groups.get(value);
                const $groupRow = $(
                    `<tr class="cats-group-row"><td colspan="${columnCount}"><button type="button" class="btn btn-sm btn-link p-0 cats-group-toggle-rows text-decoration-none"><span class="cats-group-caret">&#9660;</span> <strong>${esc(label)}:</strong> ${esc(value)} <span class="text-secondary">(${members.length})</span></button></td></tr>`,
                );
                $tbody.append($groupRow);
                members.forEach((row) => $tbody.append(row));
            });
        $table.data('catsGroupTh', $th[0]);
        $toolbar
            .find('.cats-group-badge')
            .removeClass('d-none')
            .html(`Grouped by ${esc(label)} <button type="button" class="btn-close btn-close-white btn-sm cats-group-clear" style="font-size:.55rem" aria-label="Clear grouping"></button>`);
    }

    headings.forEach((name, index) => {
        const $th = $table.find('thead th').eq(index);
        if (!name || !$th.text().trim()) return; // skip blank/action columns (e.g. selection, buttons)
        const groupName = `cats-comb-${Math.random().toString(36).slice(2)}`;
        const opOptions = (withBlank) =>
            (withBlank ? ['<option value="">(none)</option>'] : []).concat(
                FILTER_OPERATORS.map(([v, l]) => `<option value="${v}">${esc(l)}</option>`),
            ).join('');
        $th.addClass('cats-sortable').attr({ tabindex: 0, role: 'button', 'aria-sort': 'none', title: 'Sort column' });
        $th.append(
            `<div class="dropdown cats-col-menu-wrap"><button type="button" class="btn btn-sm btn-link cats-col-menu-btn" data-bs-toggle="dropdown" data-bs-auto-close="outside" title="Column options" aria-label="Column options for ${esc(name)}">&#8942;</button><div class="dropdown-menu cats-col-menu p-0">` +
                `<button type="button" class="cats-menu-flat cats-sort-asc"><span class="cats-menu-label">${MENU_ICONS.sortAsc}Sort Ascending</span></button>` +
                `<button type="button" class="cats-menu-flat cats-sort-desc"><span class="cats-menu-label">${MENU_ICONS.sortDesc}Sort Descending</span></button>` +
                `<details class="cats-menu-section"><summary><span class="cats-menu-label">${MENU_ICONS.columns}Columns</span></summary>` +
                `<div class="cats-col-menu-columns">${columnsListHtml()}</div>` +
                `</details>` +
                `<details class="cats-menu-section"><summary><span class="cats-menu-label">${MENU_ICONS.filter}Filter</span></summary>` +
                `<div class="cats-col-menu-filter">` +
                `<select class="form-select form-select-sm mb-2 cats-f-op1">${opOptions(false)}</select>` +
                `<input type="text" class="form-control form-control-sm mb-2 cats-f-val1" placeholder="Value" />` +
                `<div class="cats-f-combo mb-2 small"><label class="cats-f-combo-opt"><input type="radio" class="cats-f-comb" name="${groupName}" value="and" checked><span>And</span></label><label class="cats-f-combo-opt"><input type="radio" class="cats-f-comb" name="${groupName}" value="or"><span>Or</span></label></div>` +
                `<select class="form-select form-select-sm mb-2 cats-f-op2">${opOptions(true)}</select>` +
                `<input type="text" class="form-control form-control-sm mb-2 cats-f-val2" placeholder="Value" />` +
                `<div class="d-flex justify-content-between"><button type="button" class="btn btn-sm btn-link p-0 cats-f-clear">${MENU_ICONS.clear}Clear</button><button type="button" class="btn btn-sm btn-primary cats-f-apply">${MENU_ICONS.search}Filter</button></div>` +
                `</div></details>` +
                `<details class="cats-menu-section"><summary><span class="cats-menu-label">${MENU_ICONS.group}Group</span></summary>` +
                `<button type="button" class="cats-menu-flat cats-group-toggle">Group by this column</button>` +
                `</details>` +
                `<details class="cats-menu-section"><summary><span class="cats-menu-label">${MENU_ICONS.move}Set column position</span></summary>` +
                `<button type="button" class="cats-menu-flat cats-lock-toggle">Lock</button>` +
                `<button type="button" class="cats-menu-flat cats-move-prev">Move Previous</button>` +
                `<button type="button" class="cats-menu-flat cats-move-next">Move Next</button>` +
                `</details>` +
                `</div></div>`,
        );
        // Use Popper's "fixed" positioning strategy so the menu overlays on top of the grid instead
        // of being clipped (or inflating the scroll width) by the horizontally-scrolling wrapper.
        const toggleEl = $th.find('.cats-col-menu-btn').get(0);
        const menuEl = $th.find('.cats-col-menu').get(0);
        if (toggleEl && window.bootstrap?.Dropdown) {
            window.bootstrap.Dropdown.getOrCreateInstance(toggleEl, {
                // "fixed" keeps the menu from being clipped/inflating the scroll width of the
                // horizontally-scrolling wrapper; "bottom-end" anchors its right edge under the
                // "⋮" button so it opens back over its own column instead of spilling rightward
                // across the next (unrelated) column's header/cells.
                popperConfig: (defaultConfig) => ({ ...defaultConfig, strategy: 'fixed', placement: 'bottom-end' }),
            });
        }
        // Constrain the menu's height to whatever viewport space is actually available (whichever
        // of above/below the toggle button has more room), so it can never be visually cut off by
        // the edge of the screen - it scrolls internally (via the existing overflow-y: auto)
        // instead. Computed and applied *before* Popper positions the menu (on "show.bs.dropdown",
        // which fires ahead of Popper's own measurement) so Popper's flip/placement logic sees the
        // already-constrained size rather than the full, unconstrained one.
        const MENU_MARGIN = 12;
        /**
         * Recompute and apply the open menu's max-height from the live position of its toggle
         * button relative to the viewport.
         * @returns {void} Updates the relevant UI or state.
         */
        const fitMenuToViewport = () => {
            if (!menuEl || !toggleEl) return;
            const toggleRect = toggleEl.getBoundingClientRect();
            const belowSpace = window.innerHeight - toggleRect.bottom - MENU_MARGIN;
            const aboveSpace = toggleRect.top - MENU_MARGIN;
            const available = Math.max(belowSpace, aboveSpace);
            menuEl.style.maxHeight = `${Math.max(160, Math.min(available, 416))}px`;
        };
        /**
         * Close the menu in response to the grid being scrolled - a fixed-position menu can no
         * longer track its toggle button's moving position, so hide it instead of leaving it
         * floating over the wrong spot.
         * @returns {void} Updates the relevant UI or state.
         */
        const closeOnScroll = () => window.bootstrap?.Dropdown?.getInstance(toggleEl)?.hide();
        if (toggleEl) {
            toggleEl.addEventListener('show.bs.dropdown', () => {
                fitMenuToViewport();
                window.addEventListener('resize', fitMenuToViewport);
                $wrap.on('scroll.catsColMenu', closeOnScroll);
            });
            toggleEl.addEventListener('hidden.bs.dropdown', () => {
                window.removeEventListener('resize', fitMenuToViewport);
                $wrap.off('scroll.catsColMenu', closeOnScroll);
            });
        }
        $th.on(
            'click',
            guardEvent((e) => {
                if ($(e.target).closest('.cats-col-menu-wrap').length) return;
                sortBy($th);
            }),
        ).on(
            'keydown',
            guardEvent((e) => {
                if ((e.key === 'Enter' || e.key === ' ') && !$(e.target).closest('.cats-col-menu-wrap').length) {
                    e.preventDefault();
                    sortBy($th);
                }
            }),
        );
    });

    // Keep every column menu's "Columns" checklist copy and the shared hidden-column state in sync.
    $table.on(
        'change',
        '.cats-column',
        guardEvent(function () {
            const index = +this.dataset.index;
            setColumn(index, this.checked);
            $table.find(`.cats-column[data-index="${index}"]`).prop('checked', this.checked);
            prefs.hidden = headings
                .map((_, i) => i)
                .filter((i) => !$table.find(`.cats-column[data-index="${i}"]`).first().prop('checked'));
            updateLockedPositions();
            observeTask(save());
        }),
    );
    $table.on(
        'click',
        '.cats-sort-asc',
        guardEvent(function () {
            sortBy($(this).closest('th'), 'asc');
        }),
    );
    $table.on(
        'click',
        '.cats-sort-desc',
        guardEvent(function () {
            sortBy($(this).closest('th'), 'desc');
        }),
    );
    $table.on(
        'click',
        '.cats-group-toggle',
        guardEvent(function () {
            const $th = $(this).closest('th');
            if ($table.data('catsGroupTh') === $th[0]) clearGrouping();
            else groupByColumn($th);
        }),
    );
    $toolbar.on('click', '.cats-group-clear, .cats-group-badge .btn-close', guardEvent(clearGrouping));
    $table.on(
        'click',
        '.cats-group-toggle-rows',
        guardEvent(function () {
            const $caret = $(this).find('.cats-group-caret');
            const collapsed = $caret.html() === '&#9654;';
            $caret.html(collapsed ? '&#9660;' : '&#9654;');
            let $row = $(this).closest('tr').next();
            while ($row.length && !$row.hasClass('cats-group-row')) {
                $row.toggle(collapsed);
                $row = $row.next();
            }
        }),
    );
    $table.on(
        'click',
        '.cats-lock-toggle',
        guardEvent(function () {
            const $th = $(this).closest('th');
            $th.data('locked', !$th.data('locked'));
            updateLockedPositions();
        }),
    );
    $table.on(
        'click',
        '.cats-move-prev',
        guardEvent(function () {
            moveColumn($(this).closest('th'), 'prev');
        }),
    );
    $table.on(
        'click',
        '.cats-move-next',
        guardEvent(function () {
            moveColumn($(this).closest('th'), 'next');
        }),
    );
    $table.on(
        'click',
        '.cats-f-clear',
        guardEvent(function () {
            const $th = $(this).closest('th');
            $th.removeData('catsFilter');
            const $menu = $(this).closest('.cats-col-menu');
            $menu.find('.cats-f-op1').val('contains');
            $menu.find('.cats-f-val1').val('');
            $menu.find('.cats-f-op2').val('');
            $menu.find('.cats-f-val2').val('');
            $menu.find('.cats-f-comb[value="and"]').prop('checked', true);
            applyAllFilters();
        }),
    );
    /**
     * Read the filter builder controls inside a column menu and apply (or clear) that column's filter.
     * @param {*} $menu - jQuery-wrapped `.cats-col-menu` panel containing the filter controls.
     * @returns {void} Updates the relevant UI or state.
     */
    const applyFilterFromMenu = ($menu) => {
        const $th = $menu.closest('th');
        const filter = {
            op1: $menu.find('.cats-f-op1').val() || 'contains',
            val1: $menu.find('.cats-f-val1').val().trim(),
            combinator: $menu.find('.cats-f-comb:checked').val() || 'and',
            op2: $menu.find('.cats-f-op2').val(),
            val2: $menu.find('.cats-f-val2').val().trim(),
        };
        if (!filter.op2) delete filter.op2;
        const hasCondition =
            ['isempty', 'isnotempty'].includes(filter.op1) || filter.val1 !== '' || (filter.op2 && (filter.val2 !== '' || ['isempty', 'isnotempty'].includes(filter.op2)));
        if (hasCondition) $th.data('catsFilter', filter);
        else $th.removeData('catsFilter');
        applyAllFilters();
    };
    $table.on(
        'click',
        '.cats-f-apply',
        guardEvent(function () {
            applyFilterFromMenu($(this).closest('.cats-col-menu'));
        }),
    );
    // Smoother filtering: Enter applies immediately, and operators that need no value (Is
    // empty / Is not empty) apply as soon as they're picked instead of requiring an extra click.
    $table.on(
        'keydown',
        '.cats-f-val1, .cats-f-val2',
        guardEvent(function (e) {
            if (e.key !== 'Enter') return;
            e.preventDefault();
            applyFilterFromMenu($(this).closest('.cats-col-menu'));
        }),
    );
    $table.on(
        'change',
        '.cats-f-op1, .cats-f-op2',
        guardEvent(function () {
            if (['isempty', 'isnotempty'].includes(this.value)) applyFilterFromMenu($(this).closest('.cats-col-menu'));
        }),
    );
    $table.on('click', '.cats-f-op1, .cats-f-val1, .cats-f-op2, .cats-f-val2, summary', (e) => e.stopPropagation());
    $table.on('show.bs.dropdown', '.cats-col-menu-wrap', function () {
        const $wrap = $(this);
        const $th = $wrap.closest('th');
        const index = columnIndexOf($th);
        const lastIndex = $th.parent().children().length - 1;
        $wrap.find('.cats-move-prev').prop('disabled', index <= 0);
        $wrap.find('.cats-move-next').prop('disabled', index >= lastIndex);
        $wrap.find('.cats-lock-toggle').text($th.data('locked') ? 'Unlock' : 'Lock');
        $wrap.find('.cats-group-toggle').text($table.data('catsGroupTh') === $th[0] ? 'Clear grouping' : 'Group by this column');
        const filter = $th.data('catsFilter') || {};
        $wrap.find('.cats-f-op1').val(filter.op1 || 'contains');
        $wrap.find('.cats-f-val1').val(filter.val1 || '');
        $wrap.find('.cats-f-op2').val(filter.op2 || '');
        $wrap.find('.cats-f-val2').val(filter.val2 || '');
        $wrap.find(`.cats-f-comb[value="${filter.combinator === 'or' ? 'or' : 'and'}"]`).prop('checked', true);
    });
    $toolbar.on(
        'click',
        '.cats-filter-clear-all',
        guardEvent(() => {
            $table.find('thead th').removeData('catsFilter');
            applyAllFilters();
        }),
    );
    enhanceGridExport($table, $toolbar);
}

/**
 * Insert a leading selection column and wire select-all/row-selection behaviour.
 * Opt in with data-grid-select="multiple" (checkboxes, default) or data-grid-select="single" (radios).
 * Emits a `cats-grid:selectionchange` event on the table with the currently checked row ids,
 * read from each row's `data-id` attribute (falling back to its row index).
 * @param {*} $table - jQuery-wrapped table element.
 * @returns {void} Updates the relevant UI or state.
 */
function enhanceGridSelection($table) {
    if ($table.attr('data-grid-select') === undefined) return;
    const multiple = $table.attr('data-grid-select') !== 'single';
    const inputType = multiple ? 'checkbox' : 'radio';
    const groupName = `cats-select-${Math.random().toString(36).slice(2)}`;
    $table
        .find('thead tr')
        .first()
        .prepend(
            `<th class="cats-select-col">${multiple ? '<input type="checkbox" class="form-check-input cats-select-all" aria-label="Select all rows" />' : ''}</th>`,
        );
    $table.find('tbody tr').each(function (index) {
        const $row = $(this);
        const $onlyCell = $row.children().length === 1 ? $row.children().first() : null;
        if ($onlyCell && $onlyCell.attr('colspan')) {
            $onlyCell.attr('colspan', (+$onlyCell.attr('colspan') || 1) + 1);
            return;
        }
        const id = $row.attr('data-id') ?? String(index);
        $row.prepend(
            `<td class="cats-select-col"><input type="${inputType}" class="form-check-input cats-select-row" name="${groupName}" value="${esc(id)}" aria-label="Select row" /></td>`,
        );
    });
    /**
     * Report the currently checked row ids to interested listeners.
     * @returns {void} Updates the relevant UI or state.
     */
    const notify = () => {
        const ids = $table
            .find('tbody .cats-select-row:checked')
            .map((_, input) => input.value)
            .get();
        $table.trigger('cats-grid:selectionchange', [{ ids }]);
    };
    /**
     * Keep the header checkbox in sync with the visible row selection state.
     * @returns {void} Updates the relevant UI or state.
     */
    const refreshHeader = () => {
        const $visible = $table.find('tbody .cats-select-row:visible');
        const checkedCount = $visible.filter(':checked').length;
        $table
            .find('thead .cats-select-all')
            .prop('checked', checkedCount > 0 && checkedCount === $visible.length)
            .prop('indeterminate', checkedCount > 0 && checkedCount < $visible.length);
    };
    $table.on(
        'change',
        '.cats-select-row',
        guardEvent(() => {
            refreshHeader();
            notify();
        }),
    );
    $table.on(
        'change',
        '.cats-select-all',
        guardEvent(function () {
            $table.find('tbody .cats-select-row:visible').prop('checked', this.checked);
            refreshHeader();
            notify();
        }),
    );
}

/**
 * Quote a value for safe inclusion in a CSV cell.
 * @param {*} value - Source data record.
 * @returns {string} Computed value for the caller.
 */
const csvCell = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;

/**
 * Render collected grid data as CSV text.
 * @param {*} data - Headers and row values collected from the grid.
 * @returns {string} Computed value for the caller.
 */
const toCsv = ({ header, rows }) => [header, ...rows].map((row) => row.map(csvCell).join(',')).join('\r\n');

/**
 * Render collected grid data as an Excel-compatible HTML document.
 * @param {*} data - Headers and row values collected from the grid.
 * @returns {string} Computed value for the caller.
 */
const toExcelHtml = ({ header, rows }) =>
    `<html><head><meta charset="UTF-8"></head><body><table><thead><tr>${header.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((cell) => `<td>${esc(cell)}</td>`).join('')}</tr>`).join('')}</tbody></table></body></html>`;

/**
 * Trigger a browser download for the supplied file content.
 * @param {*} content - Encoded file content to download.
 * @param {*} mime - MIME type describing the file content.
 * @param {*} filename - Suggested name for the downloaded file.
 * @returns {void} Updates the relevant UI or state.
 */
const downloadFile = (content, mime, filename) => {
    const url = URL.createObjectURL(new Blob([content], { type: mime }));
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
};

/**
 * Open a print-friendly window containing the collected grid data.
 * @param {*} data - Headers and row values collected from the grid.
 * @returns {void} Updates the relevant UI or state.
 */
const printGrid = ({ header, rows }) => {
    const win = window.open('', '_blank', 'width=1000,height=700');
    if (!win) return;
    const bootstrapHref = document.querySelector('link[href*="bootstrap"]')?.href || '';
    win.document.write(
        `<html><head><title>Print</title>${bootstrapHref ? `<link rel="stylesheet" href="${bootstrapHref}" />` : ''}</head><body class="p-3"><table class="table table-bordered table-sm"><thead><tr>${header.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((cell) => `<td>${esc(cell)}</td>`).join('')}</tr>`).join('')}</tbody></table></body></html>`,
    );
    win.document.close();
    win.focus();
    win.print();
};

/**
 * Add CSV, Excel, and print export buttons to the toolbar. Exports the checked rows when any are
 * selected, otherwise every row currently visible after filtering; only visible, labelled columns
 * are included. Opt in with data-grid-export="true".
 * @param {*} $table - jQuery-wrapped table element.
 * @param {*} $toolbar - jQuery-wrapped toolbar element to receive the export buttons.
 * @returns {void} Updates the relevant UI or state.
 */
function enhanceGridExport($table, $toolbar) {
    if ($table.attr('data-grid-export') === undefined) return;
    /**
     * Collect the exportable header labels and row values currently shown in the grid.
     * @returns {{header: string[], rows: string[][]}} Computed value for the caller.
     */
    const collect = () => {
        const $headerRow = $table.find('thead tr').first();
        const columnCount = $headerRow.children().length;
        const columns = $headerRow
            .children()
            .map((index, th) => ({
                index,
                label: $(th).clone().find('.cats-col-menu-wrap').remove().end().text().trim(),
                visible: $(th).is(':visible'),
            }))
            .get()
            .filter((column) => column.label && column.visible);
        const $checked = $table.find('tbody .cats-select-row:checked');
        const $rows = ($checked.length ? $checked.closest('tr') : $table.find('tbody tr:visible')).filter(
            (_, row) => $(row).children().length === columnCount,
        );
        const rows = $rows
            .get()
            .map((row) => columns.map((column) => $(row).children().eq(column.index).text().trim()));
        return { header: columns.map((column) => column.label), rows };
    };
    $toolbar.append(
        `<div class="btn-group btn-group-sm cats-grid-export" role="group" aria-label="Export grid"><button type="button" class="btn btn-outline-secondary" data-export="csv">CSV</button><button type="button" class="btn btn-outline-secondary" data-export="excel">Excel</button><button type="button" class="btn btn-outline-secondary" data-export="print">Print</button></div>`,
    );
    $toolbar.find('.cats-grid-export button').on(
        'click',
        guardEvent(function () {
            const data = collect();
            if (this.dataset.export === 'csv') downloadFile(toCsv(data), 'text/csv;charset=utf-8;', 'grid-export.csv');
            else if (this.dataset.export === 'excel')
                downloadFile(toExcelHtml(data), 'application/vnd.ms-excel', 'grid-export.xls');
            else printGrid(data);
        }),
    );
}

/**
 * Build the centered, reusable pagination bar markup: a page-size selector, a Kendo-style numbered
 * pager (First/Previous/…/Next/Last), and a result-range summary. Wire it up with wirePager().
 * @param {*} state - Pagination state: { page, pageSize, totalRecords, totalPages, pageSizeOptions }.
 * @returns {string} HTML for the pager bar.
 */
function renderPagerHtml({ page, pageSize, totalRecords, totalPages, pageSizeOptions = [10, 20, 50, 100] }) {
    const pages = Math.max(1, totalPages || Math.ceil((totalRecords || 0) / (pageSize || 1)) || 1);
    const current = Math.min(Math.max(1, page || 1), pages);
    const first = Math.max(1, current - 2);
    const last = Math.min(pages, current + 2);
    let numbered = '';
    if (first > 1) numbered += `<li class="page-item"><button type="button" class="page-link" data-page="1">1</button></li>`;
    if (first > 2) numbered += `<li class="page-item disabled"><span class="page-link">…</span></li>`;
    for (let p = first; p <= last; p++)
        numbered += `<li class="page-item ${p === current ? 'active' : ''}"><button type="button" class="page-link" data-page="${p}" ${p === current ? 'aria-current="page"' : ''}>${p}</button></li>`;
    if (last < pages - 1) numbered += `<li class="page-item disabled"><span class="page-link">…</span></li>`;
    if (last < pages) numbered += `<li class="page-item"><button type="button" class="page-link" data-page="${pages}">${pages}</button></li>`;
    const from = totalRecords ? (current - 1) * pageSize + 1 : 0;
    const to = Math.min(totalRecords || 0, current * pageSize);
    const options = pageSizeOptions
        .map((size) => `<option value="${size}" ${size === pageSize ? 'selected' : ''}>${size}</option>`)
        .join('');
    return (
        `<div class="cats-pager-bar">` +
        `<div class="cats-pager-sizer small text-secondary d-flex align-items-center gap-2"><label class="mb-0" for="cats-page-size">Page size</label><select id="cats-page-size" class="form-select form-select-sm cats-page-size" style="width:auto">${options}</select></div>` +
        `<nav aria-label="Pagination"><ul class="pagination pagination-sm mb-0 cats-pager">` +
        `<li class="page-item ${current <= 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-page="first" aria-label="First page">&laquo;</button></li>` +
        `<li class="page-item ${current <= 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-page="prev" aria-label="Previous page">&lsaquo;</button></li>` +
        numbered +
        `<li class="page-item ${current >= pages ? 'disabled' : ''}"><button type="button" class="page-link" data-page="next" aria-label="Next page">&rsaquo;</button></li>` +
        `<li class="page-item ${current >= pages ? 'disabled' : ''}"><button type="button" class="page-link" data-page="last" aria-label="Last page">&raquo;</button></li>` +
        `</ul></nav>` +
        `<span class="cats-pager-summary small text-secondary">${totalRecords ? `Showing ${from.toLocaleString()}–${to.toLocaleString()} of ${totalRecords.toLocaleString()}` : 'No records'}</span>` +
        `</div>`
    );
}

/**
 * Wire click/change handlers for a pager bar previously rendered with renderPagerHtml() into the
 * given container. Calls onPageChange(page) when a page control is used, and onPageSizeChange(size)
 * when the page-size selector changes.
 * @param {*} $container - jQuery-wrapped element containing the pager bar.
 * @param {*} state - Current pagination state (used to resolve first/prev/next/last targets).
 * @param {*} handlers - { onPageChange, onPageSizeChange } callbacks.
 * @returns {void} Updates the relevant UI or state.
 */
function wirePager($container, state, { onPageChange, onPageSizeChange } = {}) {
    const pages = Math.max(1, state.totalPages || Math.ceil((state.totalRecords || 0) / (state.pageSize || 1)) || 1);
    const current = Math.min(Math.max(1, state.page || 1), pages);
    $container.find('.cats-pager [data-page]').on(
        'click',
        guardEvent(function () {
            if ($(this).closest('.page-item').hasClass('disabled')) return;
            const target = this.dataset.page;
            const page =
                target === 'first' ? 1 : target === 'prev' ? current - 1 : target === 'next' ? current + 1 : target === 'last' ? pages : +target;
            if (page >= 1 && page <= pages && page !== current) onPageChange?.(page);
        }),
    );
    $container.find('.cats-page-size').on(
        'change',
        guardEvent(function () {
            onPageSizeChange?.(+this.value);
        }),
    );
}

export { enhanceGrid, renderPagerHtml, wirePager };
