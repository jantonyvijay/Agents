import { state } from '../core/state.js';
import { api } from './client.js';
import { esc } from '../core/utils.js';

/**
 * Return cached alert templates, refreshing them from the API when requested.
 * @param {*} [force] - Whether to bypass the cached catalog.
 * @returns {Promise<Array>} Resolves after the operation completes; failures propagate to the caller.
 */
async function loadTemplates(force = false) {
    if (state.templates.length && !force) return state.templates;
    state.templates = await api('/api/templates');
    return state.templates;
}

/**
 * Return the configurable catalog of Alerts-table columns (labels, searchability, options, display format).
 * It is refreshed each time because an administrator can change it at any time.
 * @returns {Promise<Array>} Catalog rows from AlertListColumnMaster.
 */
async function loadAlertColumns() {
    state.alertColumns = await api('/api/templates/alert-columns');
    return state.alertColumns;
}

/**
 * Load and cache role codes, then populate the shared role suggestions.
 * @param {*} [force] - Whether to bypass the cached catalog.
 * @returns {Promise<Array>} Resolves after the operation completes; failures propagate to the caller.
 */
async function loadRoles(force = false) {
    if (state.roles.length && !force) return state.roles;
    state.roles = await api('/api/meta/roles');
    $('#roleOptions').html(state.roles.map((r) => `<option value="${esc(r)}"></option>`).join(''));
    return state.roles;
}

export { loadTemplates, loadRoles, loadAlertColumns };
