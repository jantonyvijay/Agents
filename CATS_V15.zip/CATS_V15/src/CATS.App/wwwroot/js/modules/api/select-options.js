import { readFieldConfiguration } from '../business/form-data.js';
import { api } from './client.js';
import { getConfiguredFieldValue } from '../business/form-data.js';
import { esc } from '../core/utils.js';

/**
 * Resolve dependent field placeholders, fetch allowed API options, and restore the current selection.
 * @param {*} select - jQuery API-backed select control.
 * @param {*} root - DOM subtree or selector containing the target controls.
 * @param {*} cssClass - Class identifying configured form controls.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function loadApiSelect(select, root, cssClass) {
    try {
        const f = readFieldConfiguration(select);
        let url = String(f.apiUrl || '');
        String(f.dependsOnFields || '')
            .split(',')
            .map((x) => x.trim())
            .filter(Boolean)
            .forEach((name) => {
                url = url.replaceAll(`{${name}}`, encodeURIComponent(getConfiguredFieldValue(root, name, cssClass)));
            });
        if (!url.toLowerCase().startsWith('/api/')) {
            select.html('<option value="">Invalid API configuration</option>');
            return;
        }
        const current = String(select.attr('data-current-value') ?? select.data('initial-value') ?? select.val() ?? '');
        const result = await api(url),
            rows = Array.isArray(result)
                ? result
                : Array.isArray(result?.data)
                  ? result.data
                  : Array.isArray(result?.items)
                    ? result.items
                    : Array.isArray(result?.results)
                      ? result.results
                      : [];
        const valueField = f.apiValueField || 'value',
            textField = f.apiTextField || 'text';
        select.html(
            '<option value="">Select</option>' +
                rows
                    .map((x) => {
                        const v = typeof x === 'object' ? (x[valueField] ?? x.Value ?? x.id ?? x.Id) : x;
                        const t = typeof x === 'object' ? (x[textField] ?? x.Text ?? x.name ?? x.Name ?? v) : x;
                        return `<option value="${esc(v)}" ${String(v) === current ? 'selected' : ''}>${esc(t)}</option>`;
                    })
                    .join(''),
        );
    } catch (e) {
        select
            .html(`<option value="">Unable to load options</option>`)
            .attr('title', e?.message || 'Please retry loading this field.');
    }
}

export { loadApiSelect };
