﻿import { beginRequestLoading, endRequestLoading } from '../ui/feedback.js';
import { state } from '../core/state.js';

const apiBaseUrl = (document.querySelector('meta[name="cats-api-base-url"]')?.content || '').replace(/\/$/, '');
let unauthorizedHandler = () => {};

/**
 * Resolve a route against the gateway configured by the server-rendered page.
 * @param {string} path - API route, with or without a leading slash.
 * @returns {string} URL retaining the configured gateway prefix.
 */
export function apiUrl(path) {
    return `${apiBaseUrl}/${path.replace(/^\//, '')}`;
}

/**
 * Register session cleanup without coupling transport to screen rendering.
 * @param {Function} handler - Synchronous callback invoked on HTTP 401.
 * @returns {void}
 */
export function setUnauthorizedHandler(handler) {
    unauthorizedHandler = handler;
}

/**
 * Entity ids are 64-bit integers in the API. The UI keeps them as opaque text so they compare equal to values read from
 * the page (input values, data attributes) and never lose precision; the API accepts them back as text.
 * @param {string} key - Property name being revived.
 * @param {*} value - Parsed JSON value.
 * @returns {*} The value, or its decimal text when it is an integer id property.
 */
function idsAsText(key, value) {
    return typeof value === 'number' && Number.isInteger(value) && /^(id|\w*Id)$/.test(key) ? String(value) : value;
}

/**
 * Authenticate requests, encode object bodies, decode responses, and balance the loader.
 * Never retry automatically: a failed response may follow a successful server mutation.
 * @param {string} url - API route relative to the configured gateway.
 * @param {RequestInit} [options={}] - Fetch options; object bodies are encoded as JSON.
 * @param {'data'|'download'} [responseType='data'] - Decode data or preserve binary contents.
 * @returns {Promise<*>} Decoded data or a blob with Content-Disposition metadata.
 * @throws {Error} Session expiration, server validation, network, or response-read failure.
 */
async function request(url, options = {}, responseType = 'data') {
    // A quiet request (background session refresh) must not show the page loader.
    const quiet = options.quiet === true;
    if (!quiet) beginRequestLoading();
    try {
        const headers = new Headers(options.headers || {});
        const { quiet: _quiet, ...fetchOptions } = options;
        const opt = { method: 'GET', ...fetchOptions, headers };
        if (state.token) headers.set('Authorization', `Bearer ${state.token}`);
        if (opt.body && !(opt.body instanceof FormData) && typeof opt.body !== 'string') {
            headers.set('Content-Type', 'application/json');
            opt.body = JSON.stringify(opt.body);
        }
        let response;
        try {
            response = await fetch(apiUrl(url), opt);
        } catch (error) {
            if (error?.name === 'AbortError') throw error;
            throw new Error('Unable to reach the server. Check your connection and try again.', { cause: error });
        }
        if (response.status === 401) {
            unauthorizedHandler();
            throw new Error('Your session has expired. Please sign in again.');
        }
        if (response.ok && responseType === 'download') {
            return { blob: await response.blob(), disposition: response.headers.get('content-disposition') || '' };
        }
        const text = await response.text();
        let data;
        try {
            data = text ? JSON.parse(text, idsAsText) : null;
        } catch {
            data = text;
        }
        if (!response.ok) {
            const errors =
                data?.errors && typeof data.errors === 'object'
                    ? Object.values(data.errors)
                          .flat()
                          .filter((value) => typeof value === 'string')
                          .join(' ')
                    : '';
            const message =
                data?.detail ||
                data?.message ||
                errors ||
                data?.title ||
                `Request failed (${response.status}). Please try again.`;
            // Center/Admin find the problem in Monitoring & Troubleshooting by this Reference ID; validation messages stay short.
            const reference = data?.traceId || response.headers?.get('x-request-id');
            throw new Error(reference && ![400, 422].includes(response.status) && !url.includes('/api/diagnostics') ? `${message} (Reference ID: ${reference})` : message);
        }
        return data;
    } finally {
        if (!quiet) endRequestLoading();
    }
}

/**
 * Request JSON or text through the common authenticated transport.
 * @param {string} url - API route.
 * @param {RequestInit} [options={}] - Method, body, headers, and optional abort signal.
 * @returns {Promise<*>} Parsed JSON, plain text, or null for an empty response.
 */
export function api(url, options = {}) {
    return request(url, options);
}

/**
 * Fetch binary contents using the same authentication and errors as JSON requests.
 * @param {string} url - Download route.
 * @returns {Promise<{blob: Blob, disposition: string}>} File contents and naming metadata.
 */
export function apiDownload(url) {
    return request(url, {}, 'download');
}
