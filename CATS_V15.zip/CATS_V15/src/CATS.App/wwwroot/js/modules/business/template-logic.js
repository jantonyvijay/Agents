const CHOICE_TYPES = ['select', 'multiselect', 'radio', 'checkboxlist'];

/**
 * Make a field code such as "AccountNo" from a label such as "Account no", unique among the existing codes.
 * @param {*} label - Question text typed by the user.
 * @param {*} existing - Codes already used in the template.
 * @returns {string} Code made of letters and digits, never starting with a digit.
 */
function fieldCodeFromLabel(label, existing = []) {
    let code = String(label || '')
        .split(/[^A-Za-z0-9]+/)
        .filter(Boolean)
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join('');
    if (!code) return '';
    if (/^\d/.test(code)) code = `Field${code}`;
    const used = new Set(existing.map((x) => String(x).toLowerCase()));
    let candidate = code;
    for (let n = 2; used.has(candidate.toLowerCase()); n++) candidate = `${code}${n}`;
    return candidate;
}

/**
 * Check a template before it is saved, in plain language.
 * @param {*} draft - Template draft with code, name, sections and fields.
 * @returns {Array<{level:'error'|'warn',text:string}>} Problems found; empty when the template is ready.
 */
function templateChecklist(draft) {
    const problems = [];
    const error = (text) => problems.push({ level: 'error', text });
    const warn = (text) => problems.push({ level: 'warn', text });
    const sections = draft.sections || [];
    const fields = draft.fields || [];
    if (!String(draft.name || '').trim()) error('Give the Alert Type a name.');
    if (!String(draft.code || '').trim()) error('Give the Alert Type a short code.');
    else if (!/^[A-Za-z0-9_]+$/.test(String(draft.code).trim())) warn('The short code should use only letters, numbers and underscores.');
    if (!sections.length) error('Add at least one section.');
    if (!fields.length) error('Add at least one field.');
    const names = fields.map((f) => String(f.name || '').toLowerCase());
    names.forEach((name, i) => {
        if (name && names.indexOf(name) !== i) error(`Two fields share the code "${fields[i].name}". Each field needs its own code.`);
    });
    for (const f of fields) {
        const label = f.label || f.name || 'A field';
        if (!sections.some((s) => s.id === f.sectionId)) error(`"${label}" is not in any section.`);
        if (CHOICE_TYPES.includes(String(f.type).toLowerCase())) {
            const isApi = String(f.dataSourceMode || '').toLowerCase() === 'api';
            let options = [];
            try {
                options = JSON.parse(f.optionsJson || '[]');
            } catch {
                options = [];
            }
            if (isApi && !f.apiUrl) error(`"${label}" loads its choices from another system but has no address.`);
            if (!isApi && !options.length) error(`"${label}" is a list but has no choices yet. Edit it and type the choices.`);
        }
    }
    for (const s of sections) {
        if (!fields.some((f) => f.sectionId === s.id)) warn(`Section "${s.name}" has no fields yet.`);
    }
    return problems;
}

/**
 * Suggest a short code (letters, digits, underscores, upper case) from a module name.
 * @param {*} name - Name typed by the user.
 * @returns {string} Code such as ATM_CASH_DISPUTE.
 */
function moduleCodeFromName(name) {
    return String(name || '')
        .toUpperCase()
        .replace(/[^A-Z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');
}

export { CHOICE_TYPES, fieldCodeFromLabel, moduleCodeFromName, templateChecklist };
