/**
 * Read a field group using its control type, including radio, checkbox, and multi-select values.
 * @param {*} root - DOM subtree or selector containing the target controls.
 * @param {*} name - Field or configuration name.
 * @param {*} cssClass - Class identifying configured form controls.
 * @returns {string} Computed value for the caller.
 */
function getConfiguredFieldValue(root, name, cssClass) {
    const controls = $(root)
        .find(`.${cssClass}`)
        .filter(function () {
            return String($(this).data('name')).toLowerCase() === String(name).toLowerCase();
        });
    if (!controls.length) return '';
    const first = controls.first(),
        f = JSON.parse(decodeURIComponent(first.attr('data-field-config') || '%7B%7D'));
    const type = String(f.type || first.attr('type') || 'text').toLowerCase();
    if (type === 'checkboxlist')
        return controls
            .filter(':checked')
            .map((_, x) => x.value)
            .get()
            .join(',');
    if (type === 'radio') return String(controls.filter(':checked').val() ?? '');
    if (type === 'checkbox') return String(first.prop('checked'));
    if (type === 'multiselect') return (first.val() || []).join(',');
    return String(first.val() ?? '');
}

/**
 * Collect one value per case-insensitive field name without duplicating grouped controls.
 * @param {*} root - DOM subtree or selector containing the target controls.
 * @param {*} cssClass - Class identifying configured form controls.
 * @returns {object} Computed value for the caller.
 */
function collectConfiguredData(root, cssClass) {
    const result = {},
        seen = new Set();
    $(root)
        .find(`.${cssClass}`)
        .each(function () {
            const name = String($(this).data('name') || '');
            if (!name || seen.has(name.toLowerCase())) return;
            seen.add(name.toLowerCase());
            result[name] = getConfiguredFieldValue(root, name, cssClass);
        });
    return result;
}

export { getConfiguredFieldValue, collectConfiguredData };

/**
 * Decode the field metadata attached to a control and identify malformed configurations.
 * @param {object} control - jQuery control containing data-field-config.
 * @returns {object} Parsed field configuration, or an empty definition when metadata is absent.
 * @throws {Error} When encoded configuration is malformed.
 */
export function readFieldConfiguration(control) {
    try {
        return JSON.parse(decodeURIComponent(control.attr('data-field-config') || '%7B%7D'));
    } catch (error) {
        throw new Error('This field has an invalid configuration. Ask an administrator to review the alert template.', {
            cause: error,
        });
    }
}
