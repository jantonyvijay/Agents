/**
 * Map configured dashboard keys to their established display labels, with a readable fallback.
 * @param {*} field - Field name or definition.
 * @returns {string} Computed value for the caller.
 */
function dashboardFieldLabel(field) {
    const labels = {
        AlertNo: 'Alert ID',
        AccountId: 'Account No',
        CustomerId: 'Customer ID',
        BranchCode: 'Location',
        AnalystName: 'Analyst Name',
        RuleId: 'Rule Id',
        ProductName: 'Product Name',
        TotalLiveLoanAmount: 'Total Live Loan Amount',
        CustomerPermanentState: 'Customer Permanent State',
        CustomerDateOfBirth: 'Customer Date of Birth',
        CustomerCountry: 'Customer Country',
        CurrentStageName: 'Current Stage',
    };
    return (
        labels[field] ||
        String(field)
            .replace(/([A-Z])/g, ' $1')
            .trim()
    );
}

export { dashboardFieldLabel };
