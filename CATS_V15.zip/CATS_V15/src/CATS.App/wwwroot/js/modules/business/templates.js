import { json } from '../core/utils.js';

/**
 * Merge stored view settings with the existing layout and ingestion defaults.
 * @param {*} source - Template or view configuration to normalize.
 * @returns {object} Computed value for the caller.
 */
function templateViewConfig(source) {
    const cfg = source?.viewConfiguration || json(source?.viewConfigurationJson || '{}', {});
    return Object.assign(
        {
            layoutMode: 'Single',
            baseDataModes: ['ManualSingle', 'BulkFileUpload', 'Sftp', 'FcQuery'],
            rememberLastSection: true,
            showSectionNumbers: true,
            allowWizardStepClick: false,
            popupSize: 'xl',
            sourceColumnMappings: [],
            bulkFileFormat: '',
            bulkFileDelimiter: '',
        },
        cfg || {},
    );
}

/**
 * Check enabled ingestion modes case-insensitively using the template configuration.
 * @param {*} template - Alert template record.
 * @param {*} mode - Ingestion mode to check.
 * @returns {boolean} Whether the requested condition is satisfied.
 */
function templateAllowsBaseDataMode(template, mode) {
    const modes = templateViewConfig(template).baseDataModes;
    return Array.isArray(modes) && modes.some((value) => String(value).toLowerCase() === String(mode).toLowerCase());
}

/**
 * Describe the file type a template accepts for Bulk File Upload, matching the server-side format check.
 * @param {*} template - Alert template record.
 * @returns {{accept: string, label: string}} File picker filter and a short description for messages.
 */
function bulkFileAccept(template) {
    const format = String(templateViewConfig(template).bulkFileFormat || '').toLowerCase();
    if (format === 'excel') return { accept: '.xlsx', label: 'an Excel (.xlsx) workbook' };
    if (format === 'txt') return { accept: '.txt,text/plain', label: 'a .txt file' };
    if (format === 'csv') return { accept: '.csv,text/csv', label: 'a .csv file' };
    return { accept: '.csv,.txt,text/csv,text/plain', label: 'a .csv or .txt file' };
}

export { templateViewConfig, templateAllowsBaseDataMode, bulkFileAccept };
