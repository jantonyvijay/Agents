import { fresh, normalizeField, normalizeSection } from './template-drafts.js';
import { CHOICE_TYPES, fieldCodeFromLabel, moduleCodeFromName } from './template-logic.js';
import { presetWorkflow } from './workflow-logic.js';

/** The people each approval flow needs, as [stage id, question shown to the user]. */
const FLOW_SLOTS = {
    single: [['review', 'Who reviews and decides?']],
    maker_checker: [
        ['maker', 'Who enters it? (maker)'],
        ['checker', 'Who approves it? (checker)'],
    ],
    maker_checker_verifier: [
        ['maker', 'Who enters it? (maker)'],
        ['checker', 'Who approves it? (checker)'],
        ['verifier', 'Who verifies it? (verifier)'],
    ],
};

/**
 * Check one page of the New Module wizard.
 * @param {*} wz - Wizard answers.
 * @param {*} step - Page number, starting at 1.
 * @returns {string|null} A plain-language problem, or null when the page is complete.
 */
function validateWizardStep(wz, step) {
    if (step === 1) {
        if (!String(wz.name || '').trim()) return 'Type a name for the module.';
        if (!/^[A-Za-z0-9_]+$/.test(String(wz.code || '').trim())) return 'The short code may use only letters, numbers and underscores.';
    }
    if (step === 2) {
        const filled = (wz.questions || []).filter((q) => String(q.label || '').trim());
        if (!filled.length) return 'Add at least one question.';
        const bad = filled.find((q) => CHOICE_TYPES.includes(q.type) && !String(q.choices || '').split(',').some((c) => c.trim()));
        if (bad) return `Type the choices for "${bad.label}" (separate them with commas).`;
    }
    if (step === 3) {
        const missing = (FLOW_SLOTS[wz.flow] || []).find(([id]) => !wz.roles?.[id]);
        if (missing) return `Choose a role for: ${missing[1]}`;
    }
    if (step === 4 && !wz.everyone && !(wz.accessRoles || []).length) return 'Tick at least one role, or choose "Everyone".';
    return null;
}

/**
 * Turn the wizard answers into the three requests that create a module: the template, its approval flow and who may use it.
 * @param {*} wz - Wizard answers.
 * @param {*} knownRoles - Role codes, used to pre-fill the flow before the chosen roles are applied.
 * @returns {{template:object,workflow:object,access:object}} Request bodies for the API.
 */
function buildModule(wz, knownRoles = []) {
    const base = fresh();
    const section = normalizeSection({ name: String(wz.sectionName || 'Details').trim() || 'Details' }, 0);
    const fields = [];
    for (const q of (wz.questions || []).filter((x) => String(x.label || '').trim())) {
        const type = q.type || 'text';
        fields.push(
            normalizeField(
                {
                    sectionId: section.id,
                    name: fieldCodeFromLabel(q.label, fields.map((f) => f.name)),
                    label: String(q.label).trim(),
                    type,
                    required: !!q.required,
                    optionsJson: CHOICE_TYPES.includes(type)
                        ? JSON.stringify(String(q.choices || '').split(',').map((c) => c.trim()).filter(Boolean))
                        : '[]',
                },
                fields.length,
            ),
        );
    }
    const code = String(wz.code || moduleCodeFromName(wz.name)).trim();
    const flow = presetWorkflow(wz.flow, knownRoles);
    for (const stage of flow.stages) if (wz.roles?.[stage.id]) stage.roleCode = wz.roles[stage.id];
    return {
        template: {
            id: null,
            code,
            name: String(wz.name).trim(),
            executionMode: 'Deterministic',
            sections: [section],
            fields,
            assignmentRules: [],
            viewConfiguration: base.viewConfiguration,
        },
        workflow: { name: `${String(wz.name).trim()} workflow`, definition: flow },
        access: { everyone: !!wz.everyone, roles: wz.everyone ? [] : [...(wz.accessRoles || [])] },
    };
}

export { FLOW_SLOTS, buildModule, validateWizardStep };
