const COMMON_BUTTONS = ['Submit', 'Approve', 'Reject', 'Return', 'Close', 'Escalate'];
const FINISH = 'END';
const CONDITION_OPERATORS = [
    ['eq', 'is'],
    ['neq', 'is not'],
    ['contains', 'contains'],
    ['gt', 'is greater than'],
    ['gte', 'is at least'],
    ['lt', 'is less than'],
    ['lte', 'is at most'],
];

/**
 * Build a short lowercase code from free text so people never have to invent one.
 * @param {*} text - Text to convert, usually a step name.
 * @returns {string} Letters, digits and underscores only.
 */
function slugify(text) {
    return String(text || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');
}

/**
 * Split a comma separated list into trimmed, non-empty values.
 * @param {*} text - Comma separated text.
 * @returns {Array<string>} Cleaned values.
 */
function splitList(text) {
    return String(text || '')
        .split(',')
        .map((x) => x.trim())
        .filter(Boolean);
}

/**
 * Read "Action:target" lines into transition objects; END or a blank target finishes the alert.
 * @param {*} text - One transition per line.
 * @returns {Array<{action:string,toStageId:string|null}>} Parsed transitions.
 */
function parseTransitions(text) {
    return String(text || '')
        .split(/\r?\n/)
        .map((x) => x.trim())
        .filter(Boolean)
        .map((line) => {
            const [action, ...rest] = line.split(':');
            const target = rest.join(':').trim();
            return { action: action.trim(), toStageId: !target || target.toUpperCase() === FINISH ? null : target };
        });
}

/**
 * Write transitions back into the "Action:target" line format used by the stage form.
 * @param {*} transitions - Transition objects.
 * @returns {string} One line per transition.
 */
function transitionsToText(transitions) {
    return (transitions || []).map((t) => `${t.action}:${t.toStageId || FINISH}`).join('\n');
}

/**
 * Name to show people for a stage id.
 * @param {*} stages - Workflow stages.
 * @param {*} id - Stage id; null or END means the alert finishes.
 * @returns {string} Readable name.
 */
function stageLabel(stages, id) {
    if (!id) return 'Finish (closed)';
    return (stages || []).find((s) => s.id === id)?.name || `missing step "${id}"`;
}

/**
 * Order stages the way an alert travels, starting at the start step; unreachable steps follow.
 * @param {*} def - Workflow definition with startStageId and stages.
 * @returns {Array} Stages in travel order.
 */
function orderedStages(def) {
    const stages = def.stages || [];
    const seen = new Set();
    const order = [];
    const queue = [];
    const start = stages.find((s) => s.id === def.startStageId);
    if (start) queue.push(start);
    while (queue.length) {
        const stage = queue.shift();
        if (seen.has(stage.id)) continue;
        seen.add(stage.id);
        order.push(stage);
        for (const id of nextStageIds(stage)) {
            const next = stages.find((s) => s.id === id);
            if (next && !seen.has(next.id)) queue.push(next);
        }
    }
    return order.concat(stages.filter((s) => !seen.has(s.id)));
}

/**
 * Every stage id a stage can send an alert to.
 * @param {*} stage - Workflow stage.
 * @returns {Array<string>} Target stage ids.
 */
function nextStageIds(stage) {
    return [
        ...(stage.transitions || []).map((t) => t.toStageId),
        ...(stage.conditions || []).map((c) => c.toStageId),
        stage.defaultNextStageId,
    ].filter(Boolean);
}

/**
 * Plain-English description of how an alert moves through the workflow.
 * @param {*} def - Workflow definition.
 * @returns {Array<{name:string,role:string,text:string,start:boolean}>} One entry per step in travel order.
 */
function workflowSummary(def) {
    const stages = def.stages || [];
    return orderedStages(def).map((s) => {
        let text;
        if (s.type === 'End') text = `The alert is finished as "${s.endStatus || 'Closed'}".`;
        else if (s.type === 'Condition') {
            const rules = (s.conditions || []).map(
                (c) => `if ${c.field} ${operatorLabel(c.operator)} "${c.value}" go to ${stageLabel(stages, c.toStageId)}`,
            );
            const fallback = s.defaultNextStageId ? `otherwise go to ${stageLabel(stages, s.defaultNextStageId)}` : '';
            text = `Routes automatically: ${[...rules, fallback].filter(Boolean).join('; ') || 'no rules yet'}.`;
        } else {
            const buttons = (s.transitions || []).map((t) => `${t.action} sends it to ${stageLabel(stages, t.toStageId)}`);
            text = buttons.length ? `${buttons.join('; ')}.` : 'No buttons lead anywhere yet.';
        }
        const roles =
            s.type === 'ParallelApproval'
                ? (s.approvers || []).map((a) => a.roleCode).join(' + ')
                : s.roleCode || (s.type === 'End' ? '' : 'automatic');
        return { name: s.name, role: roles, text, start: s.id === def.startStageId };
    });
}

/**
 * Friendly wording of a condition operator.
 * @param {*} operator - Operator code such as eq.
 * @returns {string} Readable operator.
 */
function operatorLabel(operator) {
    return CONDITION_OPERATORS.find(([code]) => code === operator)?.[1] || operator;
}

/**
 * Check a workflow before it is saved or made live, in plain language.
 * @param {*} def - Workflow definition.
 * @param {*} [roles] - Known role codes; unknown roles are reported as warnings.
 * @returns {Array<{level:'error'|'warn',text:string}>} Problems found; empty when the flow is ready.
 */
function validateWorkflow(def, roles = []) {
    const problems = [];
    const error = (text) => problems.push({ level: 'error', text });
    const warn = (text) => problems.push({ level: 'warn', text });
    const stages = def.stages || [];
    const known = new Set(roles.map((r) => String(r).toUpperCase()));
    if (!stages.length) {
        error('Add at least one step.');
        return problems;
    }
    if (!stages.some((s) => s.id === def.startStageId)) error('Choose which step alerts start at (use the Start button on a step).');
    const ids = stages.map((s) => String(s.id).toLowerCase());
    ids.forEach((id, i) => {
        if (ids.indexOf(id) !== i) error(`Two steps share the code "${id}".`);
    });
    const checkRole = (stage, role) => {
        if (role && known.size && !known.has(String(role).toUpperCase()))
            warn(`Step "${stage.name}" uses the role "${role}", which is not in the role list.`);
    };
    for (const s of stages) {
        const missingTarget = (id) => id && !stages.some((x) => x.id === id);
        if (s.type === 'Human') {
            if (!s.roleCode) warn(`Step "${s.name}" has nobody assigned. Choose a role, unless the template's assignment rules decide who handles it.`);
            checkRole(s, s.roleCode);
        }
        if (s.type === 'ParallelApproval') {
            if (!(s.approvers || []).length) error(`Step "${s.name}" needs at least one approver role.`);
            (s.approvers || []).forEach((a) => checkRole(s, a.roleCode));
        }
        if (s.type === 'Human' || s.type === 'ParallelApproval') {
            if (!(s.allowedActions || []).length) error(`Step "${s.name}" has no buttons, so nobody can move the alert on.`);
            for (const action of s.allowedActions || []) {
                if (!(s.transitions || []).some((t) => String(t.action).toLowerCase() === action.toLowerCase()))
                    error(`The "${action}" button on "${s.name}" does not lead anywhere yet.`);
            }
        }
        for (const t of s.transitions || []) {
            if (missingTarget(t.toStageId)) error(`"${t.action}" on "${s.name}" goes to a step that no longer exists.`);
        }
        if (s.type === 'Condition') {
            if (!(s.conditions || []).length && !s.defaultNextStageId) error(`Automatic step "${s.name}" has no rules and no default step.`);
            else if (!s.defaultNextStageId) warn(`Automatic step "${s.name}" has no "if nothing matches" step; alerts that match no rule will get stuck.`);
            for (const c of s.conditions || []) {
                if (!c.field || !c.toStageId) error(`A rule on "${s.name}" is incomplete. Choose a field and a step to go to.`);
                else if (missingTarget(c.toStageId)) error(`A rule on "${s.name}" goes to a step that no longer exists.`);
            }
            if (missingTarget(s.defaultNextStageId)) error(`"${s.name}" has a default step that no longer exists.`);
        }
        if (s.type === 'Agent' && !s.agentFallbackAction) warn(`AI step "${s.name}" has no fallback button for when the AI cannot decide.`);
    }
    const reachable = new Set(stages.filter((s) => isReachable(def, s.id)).map((s) => s.id));
    for (const s of stages) {
        if (!reachable.has(s.id)) warn(`Step "${s.name}" can never be reached from the start step.`);
    }
    const finishes = stages.some(
        (s) => s.type === 'End' || (s.transitions || []).some((t) => !t.toStageId),
    );
    if (!finishes) warn('No step finishes the alert, so alerts would never be closed.');
    return problems;
}

/**
 * Whether a stage can be reached by following routes from the start step.
 * @param {*} def - Workflow definition.
 * @param {*} id - Stage id to look for.
 * @returns {boolean} True when some route leads to the stage.
 */
function isReachable(def, id) {
    const stages = def.stages || [];
    const seen = new Set();
    const queue = [def.startStageId];
    while (queue.length) {
        const current = queue.shift();
        if (!current || seen.has(current)) continue;
        seen.add(current);
        if (current === id) return true;
        const stage = stages.find((s) => s.id === current);
        if (stage) queue.push(...nextStageIds(stage));
    }
    return false;
}

const baseStage = (patch) => ({
    id: '',
    name: '',
    type: 'Human',
    roleCode: '',
    allowedActions: [],
    editableFields: [],
    attachmentUploadRoles: [],
    attachmentViewRoles: [],
    transitions: [],
    approvalRule: 'Single',
    minimumApprovals: 1,
    approvers: [],
    slaHours: 24,
    conditions: [],
    defaultNextStageId: null,
    agentInstructions: null,
    agentPromptTemplate: null,
    agentFallbackAction: null,
    endStatus: null,
    ...patch,
});

/**
 * Ready-made approval flows. Role codes are guessed from the role list; anything not found stays blank and is flagged by the checklist.
 * @param {*} kind - single, maker_checker or maker_checker_verifier.
 * @param {*} [roles] - Known role codes.
 * @returns {{startStageId:string,stages:Array}} Workflow definition.
 */
function presetWorkflow(kind, roles = []) {
    const find = (pattern, avoid = []) =>
        roles.find((r) => pattern.test(r) && !avoid.some((a) => a.test(r))) || '';
    const maker = find(/MAKER|_USER$|^USER$|INPUT/i, [/CHECK/i, /VERIF/i]);
    const checker = find(/CHECKER|APPROV/i);
    const verifier = find(/VERIF/i);
    const end = [
        baseStage({ id: 'closed', name: 'Closed', type: 'End', endStatus: 'Closed', slaHours: 1 }),
        baseStage({ id: 'rejected', name: 'Rejected', type: 'End', endStatus: 'Rejected', slaHours: 1 }),
    ];
    const human = (id, name, roleCode, buttons) =>
        baseStage({
            id,
            name,
            roleCode,
            allowedActions: buttons.map(([action]) => action),
            editableFields: id === 'maker' ? ['*'] : [],
            transitions: buttons.map(([action, toStageId]) => ({ action, toStageId, resultStatus: null })),
        });
    if (kind === 'single')
        return {
            startStageId: 'review',
            stages: [human('review', 'Review', checker || maker, [['Approve', 'closed'], ['Reject', 'rejected']]), ...end],
        };
    if (kind === 'maker_checker_verifier')
        return {
            startStageId: 'maker',
            stages: [
                human('maker', 'Maker entry', maker, [['Submit', 'checker']]),
                human('checker', 'Checker review', checker, [['Approve', 'verifier'], ['Return', 'maker'], ['Reject', 'rejected']]),
                human('verifier', 'Verifier review', verifier, [['Approve', 'closed'], ['Return', 'checker'], ['Reject', 'rejected']]),
                ...end,
            ],
        };
    return {
        startStageId: 'maker',
        stages: [
            human('maker', 'Maker entry', maker, [['Submit', 'checker']]),
            human('checker', 'Checker review', checker, [['Approve', 'closed'], ['Return', 'maker'], ['Reject', 'rejected']]),
            ...end,
        ],
    };
}

export {
    COMMON_BUTTONS,
    CONDITION_OPERATORS,
    FINISH,
    operatorLabel,
    orderedStages,
    parseTransitions,
    presetWorkflow,
    slugify,
    splitList,
    stageLabel,
    transitionsToText,
    validateWorkflow,
    workflowSummary,
};
