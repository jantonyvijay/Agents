import { uid, json } from '../core/utils.js';
import { templateViewConfig } from './templates.js';

/**
 * Create an independent empty template draft with the existing default view settings.
 * @returns {object} Computed value for the caller.
 */
const fresh = () => ({
    id: null,
    code: '',
    name: '',
    version: 0,
    status: 'Draft',
    executionMode: 'Deterministic',
    viewConfiguration: templateViewConfig(),
    sections: [],
    fields: [],
    assignmentRules: [],
});

/**
 * Accept camel-case or Pascal-case section data and normalize ordering, span, and page defaults.
 * @param {*} x - Stored record to normalize.
 * @param {*} i - Zero-based item or step index.
 * @returns {object} Computed value for the caller.
 */
const normalizeSection = (x, i) => ({
    id: x.id ?? x.Id ?? uid(),
    name: x.name ?? x.Name ?? '',
    order: x.order ?? x.Order ?? i + 1,
    columnSpan: Math.min(12, Math.max(2, Number(x.columnSpan ?? x.ColumnSpan ?? 6) || 6)),
    pageNumber: Math.max(1, Number(x.pageNumber ?? x.PageNumber ?? 1) || 1),
    dataViewMode: x.dataViewMode ?? x.DataViewMode ?? 'Grid',
});

/**
 * Normalize stored field casing and defaults while preserving validation, API, and sensitive-data settings.
 * @param {*} x - Stored record to normalize.
 * @param {*} i - Zero-based item or step index.
 * @returns {object} Computed value for the caller.
 */
const normalizeField = (x, i) => ({
    id: x.id ?? x.Id ?? uid(),
    sectionId: x.sectionId ?? x.SectionId ?? '',
    name: x.name ?? x.Name ?? '',
    label: x.label ?? x.Label ?? '',
    type:
        String(x.type ?? x.Type ?? 'text').toLowerCase() === 'dropdownlist'
            ? 'select'
            : String(x.type ?? x.Type ?? 'text').toLowerCase(),
    required: x.required ?? x.Required ?? false,
    sensitive: x.sensitive ?? x.Sensitive ?? false,
    allowUnmask: x.allowUnmask ?? x.AllowUnmask ?? true,
    order: x.order ?? x.Order ?? i + 1,
    optionsJson: x.optionsJson ?? x.OptionsJson ?? '[]',
    placeholder: x.placeholder ?? x.Placeholder ?? '',
    helpText: x.helpText ?? x.HelpText ?? '',
    minLength: x.minLength ?? x.MinLength ?? null,
    maxLength: x.maxLength ?? x.MaxLength ?? null,
    minValue: x.minValue ?? x.MinValue ?? null,
    maxValue: x.maxValue ?? x.MaxValue ?? null,
    validationPattern: x.validationPattern ?? x.ValidationPattern ?? '',
    customErrorMessage: x.customErrorMessage ?? x.CustomErrorMessage ?? '',
    dataSourceMode: x.dataSourceMode ?? x.DataSourceMode ?? 'Static',
    apiUrl: x.apiUrl ?? x.ApiUrl ?? '',
    apiValueField: x.apiValueField ?? x.ApiValueField ?? 'value',
    apiTextField: x.apiTextField ?? x.ApiTextField ?? 'text',
    dependsOnFields: x.dependsOnFields ?? x.DependsOnFields ?? '',
    dependencyValidationsJson: x.dependencyValidationsJson ?? x.DependencyValidationsJson ?? '[]',
    readOnly: x.readOnly ?? x.ReadOnly ?? false,
    defaultValue: x.defaultValue ?? x.DefaultValue ?? '',
});

/**
 * Convert a persisted template record into an editable draft using shared normalizers.
 * @param {*} t - Persisted template record.
 * @returns {object} Computed value for the caller.
 */
const fromRecord = (t) => ({
    id: t.id,
    code: t.code,
    name: t.name,
    version: t.version,
    status: t.status,
    executionMode: t.executionMode,
    viewConfiguration: templateViewConfig(t),
    sections: json(t.sectionsJson, []).map(normalizeSection),
    fields: json(t.fieldsJson, []).map(normalizeField),
    assignmentRules: json(t.assignmentRulesJson, []),
});

export { fresh, normalizeSection, normalizeField, fromRecord };
