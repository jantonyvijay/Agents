import { state } from './state.js';

/**
 * Check the signed-in user permissions without case sensitivity.
 * @param {*} p - Permission code to check.
 * @returns {boolean} Whether the requested condition is satisfied.
 */
const has = (p) => (state.user?.permissions || []).some((x) => x.toLowerCase() === p.toLowerCase());

export { has };
