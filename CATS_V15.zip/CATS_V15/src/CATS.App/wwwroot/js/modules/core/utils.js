/**
 * Derive an avatar label from the display name or username, falling back to U.
 * @param {*} user - Account record used for display.
 * @returns {string} Computed value for the caller.
 */
function userInitials(user) {
    const source = (user?.displayName || user?.userName || '').trim();
    if (!source) return 'U';
    const words = source.split(/\s+/).filter(Boolean);
    return (words.length > 1 ? words[0][0] + words[words.length - 1][0] : words[0].slice(0, 2)).toUpperCase();
}

/**
 * Escape a value as HTML text before inserting it into generated markup.
 * @param {*} v - Value to format.
 * @returns {string} Computed value for the caller.
 */
const esc = (v) =>
    $('<div>')
        .text(v ?? '')
        .html();

/**
 * Generate a short client-side identifier for temporary controls and draft entities.
 * @returns {string} Computed value for the caller.
 */
const uid = () => 'x' + Math.random().toString(36).slice(2, 10);

/**
 * Parse stored JSON and return the supplied fallback when the input is empty or malformed.
 * @param {*} s - Text or JSON input to interpret.
 * @param {*} fallback - Value returned when parsing or type validation fails.
 * @returns {*} Computed value for the caller.
 */
const json = (s, fallback) => {
    try {
        return JSON.parse(s || '');
    } catch {
        return fallback;
    }
};

/**
 * Parse JSON and reject non-array values in favor of the supplied fallback.
 * @param {*} value - Value to validate or apply.
 * @param {*} [fallback] - Value returned when parsing or type validation fails.
 * @returns {Array} Computed value for the caller.
 */
function parseJsonArray(value, fallback = []) {
    const parsed = json(value || '[]', fallback);
    return Array.isArray(parsed) ? parsed : fallback;
}

/**
 * Read a dictionary property by case-insensitive name, returning an empty value when absent.
 * @param {*} row - Source data record.
 * @param {*} key - Property or preference identifier.
 * @returns {*} Computed value for the caller.
 */
function dictionaryValue(row, key) {
    if (!row) return '';
    const actual = Object.keys(row).find((x) => x.toLowerCase() === String(key).toLowerCase());
    return actual ? row[actual] : '';
}

/**
 * Convert nulls to empty text and objects to JSON for display.
 * @param {*} v - Value to format.
 * @returns {string} Computed value for the caller.
 */
function fieldValue(v) {
    if (v === null || v === undefined) return '';
    if (typeof v === 'object') return JSON.stringify(v);
    return String(v);
}

export { userInitials, esc, uid, json, parseJsonArray, dictionaryValue, fieldValue };
