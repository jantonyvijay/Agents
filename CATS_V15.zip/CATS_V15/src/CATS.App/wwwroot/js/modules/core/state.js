import { sessionStore } from './storage.js';
import { json } from './utils.js';

const state = {
    token: sessionStore.getItem('cats_token') || '',
    user: json(sessionStore.getItem('cats_user'), null),
    templates: [],
    alertColumns: [],
    roles: [],
    alertFilter: { page: 1, pageSize: 20 },
    templateDraft: {
        id: null,
        code: '',
        name: '',
        executionMode: 'Deterministic',
        viewConfiguration: {
            layoutMode: 'Single',
            rememberLastSection: true,
            showSectionNumbers: true,
            allowWizardStepClick: false,
            popupSize: 'xl',
        },
        sections: [],
        fields: [],
        assignmentRules: [],
    },
    workflowDraft: { templateId: '', name: 'Dynamic Workflow', startStageId: '', stages: [] },
    pendingAction: null,
};

export { state };
