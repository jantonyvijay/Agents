﻿/**
 * Wrap optional browser storage so denied access never prevents UI startup or logout.
 * @param {'localStorage'|'sessionStorage'} kind - Browser storage area to access lazily.
 * @returns {object} Storage-compatible read/write/remove methods with safe fallbacks.
 */
function createStorage(kind) {
    return {
        /** Read a stored string; unavailable storage behaves like a missing key.
         * @param {string} key - Persisted preference or session key.
         * @returns {string|null} Stored value, or null when absent/unavailable.
         */
        getItem(key) {
            try {
                return globalThis[kind].getItem(key);
            } catch {
                return null;
            }
        },
        /** Store a string when browser policy permits persistence.
         * @param {string} key - Preference or session key.
         * @param {string} value - Value to persist.
         * @returns {void}
         */
        setItem(key, value) {
            try {
                globalThis[kind].setItem(key, value);
            } catch {
                /* In-memory state remains authoritative. */
            }
        },
        /** Remove a persisted value when the storage area is available.
         * @param {string} key - Key to remove during reset or logout.
         * @returns {void}
         */
        removeItem(key) {
            try {
                globalThis[kind].removeItem(key);
            } catch {
                /* Restricted storage has no usable persisted state. */
            }
        },
    };
}
export const sessionStore = createStorage('sessionStorage');
export const localStore = createStorage('localStorage');
