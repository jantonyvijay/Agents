import { syncTopNavigation, closeTopNavigation } from '../ui/top-navigation.js';
import { renderDashboard } from '../features/dashboard.js';
import { renderAlerts, renderNewAlert, renderDetail } from '../features/alerts.js';
import { state } from './state.js';
import { renderTemplateDesigner } from '../features/template-designer.js';
import { renderWorkflowDesigner } from '../features/workflow-designer.js';
import { renderMcpDiscovery } from '../features/mcp.js';
import { renderAdmin } from '../features/admin.js';
import { renderRolePermissions } from '../features/role-permissions.js';
import { renderDiagnostics } from '../features/diagnostics.js';
import { renderPlatformIngestion } from '../features/ingestion.js';
import { renderPlatformReports } from '../features/reports.js';
import { renderPlatformMail } from '../features/mail.js';
import { renderAtmStaffUpload, renderAtmStaffConfig } from '../features/atm-staff-mapping.js';
import { renderAtmStaffList } from '../features/atm-staff-list.js';
import { header } from '../ui/feedback.js';
import { esc } from './utils.js';

/**
 * Select a navigation item, render its screen, and show escaped failures in the content area.
 * @param {*} view - Requested navigation view.
 * @param {*} arg - Optional identifier or filter passed to the view.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function navigate(view, arg) {
    // A menu key may carry the argument after a colon, e.g. "reports:ATM_ONUS".
    if (typeof view === 'string' && view.includes(':')) {
        const at = view.indexOf(':');
        arg = view.slice(at + 1);
        view = view.slice(0, at);
    }
    closeTopNavigation();
    syncTopNavigation(view, arg);
    if (window.innerWidth < 768) $('#sidebar').removeClass('mobile-open');
    try {
        if (view === 'dashboard') await renderDashboard();
        if (view === 'alerts') await renderAlerts(arg || state.alertFilter);
        if (view === 'newAlert') await renderNewAlert();
        if (view === 'templates') await renderTemplateDesigner();
        if (view === 'workflow') await renderWorkflowDesigner();
        if (view === 'mcp') await renderMcpDiscovery();
        if (view === 'admin') await renderAdmin();
        if (view === 'rolePermissions') await renderRolePermissions();
        if (view === 'diagnostics') await renderDiagnostics();
        if (view === 'ingestion') await renderPlatformIngestion();
        if (view === 'reports') await renderPlatformReports(arg);
        if (view === 'mail') await renderPlatformMail();
        if (view === 'atmStaffUpload') await renderAtmStaffUpload(arg);
        if (view === 'atmStaffList') await renderAtmStaffList();
        if (view === 'atmStaffConfig') await renderAtmStaffConfig();
        if (view === 'detail') await renderDetail(arg);
    } catch (e) {
        header('Error');
        $('#viewHost').html(`<div class="alert alert-danger">${esc(e.message)}</div>`);
    }
}

export { navigate };
