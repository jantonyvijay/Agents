import { renderTopNavigation, closeTopNavigation, loadNavigation } from '../ui/top-navigation.js';
import { sessionStore } from './storage.js';
import {
    renderAccountDetails,
    startSessionCountdown,
    setLoginBusy,
    setPasswordVisibility,
    setLoginStatus,
} from '../ui/account.js';
import { restoreAppearance } from '../ui/appearance.js';
import { refreshAssistantStatus } from '../features/assistant.js';
import { state } from './state.js';
import { toast } from '../ui/feedback.js';
import { api } from '../api/client.js';

/**
 * Load the database menu for the signed-in user (role and permission filtered on the server) and render both navigation menus.
 * @returns {Promise<void>} Resolves after the menus are rendered.
 */
async function applyPermissions() {
    await loadNavigation();
    renderTopNavigation();
}

/**
 * Display the authenticated shell and restore account details, appearance, session time, and assistant availability.
 * @returns {void} Updates the relevant UI or state.
 */
function showApp() {
    $('body').addClass('app-authenticated');
    $('#loginPage').addClass('d-none');
    $('#appShell').removeClass('d-none');
    renderAccountDetails();
    restoreAppearance();
    applyPermissions();
    startSessionCountdown();
    refreshAssistantStatus().catch(() => {
        $('#catsAssistantLauncher,#catsAssistantPanel').addClass('d-none');
    });
}

/**
 * Reset the login busy state, display the sign-in form, and focus the username.
 * @returns {void} Updates the relevant UI or state.
 */
function showLogin() {
    setLoginBusy(false);
    $('body').removeClass('app-authenticated');
    $('#appShell').addClass('d-none');
    $('#loginPage').removeClass('d-none');
    setTimeout(() => $('#loginUser').trigger('focus'), 100);
}

/**
 * Clear session data and cached catalogs, reset sensitive controls, and return to sign-in.
 * @param {*} [show] - Whether to show the sign-out notification.
 * @returns {void} Updates the relevant UI or state.
 */
function logout(show = true) {
    closeTopNavigation();
    $('#catsAssistantLauncher,#catsAssistantPanel').addClass('d-none');
    const menuButton = document.getElementById('accountMenuButton');
    if (menuButton) bootstrap.Dropdown.getInstance(menuButton)?.hide();
    state.token = '';
    state.user = null;
    state.templates = [];
    state.alertColumns = [];
    state.roles = [];
    sessionStore.removeItem('cats_token');
    sessionStore.removeItem('cats_user');
    $('#loginPassword').val('');
    setPasswordVisibility(false);
    setLoginStatus();
    if (show) toast('Signed out', 'secondary');
    showLogin();
}

/**
 * Attempt server logout and always clear the local session, even if the request fails.
 * @returns {Promise<void>} Resolves after the operation completes; failures propagate to the caller.
 */
async function signOut() {
    try {
        if (state.token) await api('/api/auth/logout', { method: 'POST' });
    } catch {
    } finally {
        logout(true);
    }
}

export { applyPermissions, showApp, showLogin, logout, signOut };
