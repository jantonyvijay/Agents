import { bindApplicationEvents } from './modules/events/application.js';
import { setUnauthorizedHandler } from './modules/api/client.js';
import { logout } from './modules/core/session.js';
import { enableKeyboardShortcuts } from './modules/ui/keyboard-shortcuts.js';
import { initializeGlobalSearch } from './modules/features/global-search.js';

// All modules are loaded before observers, event handlers, and session restoration run.
setUnauthorizedHandler(() => logout(false));
bindApplicationEvents();
enableKeyboardShortcuts();
initializeGlobalSearch();
