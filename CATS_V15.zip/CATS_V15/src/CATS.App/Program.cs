using Microsoft.AspNetCore.HttpOverrides;

var builder = WebApplication.CreateBuilder(args);

// This host serves the browser application. API authentication and data access live in CATS.Api.
builder.Services.AddControllersWithViews();
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    options.KnownNetworks.Clear();
    options.KnownProxies.Clear();
});

var app = builder.Build();
app.UseForwardedHeaders();
if (!app.Environment.IsDevelopment()) app.UseHsts();
app.UseStaticFiles(new StaticFileOptions
{
    OnPrepareResponse = context =>
    {
        // ES module imports have stable filenames: revalidate them after deployments.
        context.Context.Response.Headers["Cache-Control"] =
            context.File.Name.EndsWith(".js", StringComparison.OrdinalIgnoreCase)
                ? "public,max-age=0,must-revalidate"
                : "public,max-age=3600";
    }
});
app.UseRouting();
app.MapGet("/health/live", () => Results.Ok(new { service = "CATS.App", status = "Healthy" }));
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
app.Run();
