using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using CATS.Core;
using Microsoft.IdentityModel.Tokens;

namespace CATS.Api;

public sealed class JwtTokenService(JwtOptions options)
{
    private const string AuthTimeClaim = "auth_time";

    private TimeSpan IdleLifetime => TimeSpan.FromMinutes(Math.Clamp(options.ExpiryMinutes, 5, 1440));
    private TimeSpan MaxLifetime => TimeSpan.FromMinutes(Math.Max(options.MaxSessionMinutes, Math.Clamp(options.ExpiryMinutes, 5, 1440)));

    /// <summary>When the person actually signed in, carried unchanged through every refresh. Tokens without it count as signed in now.</summary>
    public DateTime SignInTimeOf(ClaimsPrincipal principal) =>
        long.TryParse(principal.FindFirstValue(AuthTimeClaim), System.Globalization.NumberStyles.None, System.Globalization.CultureInfo.InvariantCulture, out var seconds)
            ? DateTimeOffset.FromUnixTimeSeconds(seconds).UtcDateTime : DateTime.UtcNow;

    /// <summary>Whether a session that started at <paramref name="signedInAtUtc"/> may still be extended.</summary>
    public bool CanExtend(DateTime signedInAtUtc) => signedInAtUtc.Add(MaxLifetime) > DateTime.UtcNow.AddMinutes(1);

    public LoginResponse Create(UserRecord user, DateTime? signedInAtUtc = null)
    {
        var signedIn=signedInAtUtc ?? DateTime.UtcNow;
        var expiry=new[]{DateTime.UtcNow.Add(IdleLifetime),signedIn.Add(MaxLifetime)}.Min();
        var claims=new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub,user.Id.ToString(System.Globalization.CultureInfo.InvariantCulture)),
            new(JwtRegisteredClaimNames.UniqueName,user.UserName),
            new(ClaimTypes.NameIdentifier,user.Id.ToString(System.Globalization.CultureInfo.InvariantCulture)),
            new(ClaimTypes.Name,user.UserName),
            new(ClaimTypes.Role,user.RoleCode),
            new("displayName",user.DisplayName),
            new("department",user.DepartmentCode),
            new("branch",user.BranchCode),
            new(AuthTimeClaim,new DateTimeOffset(signedIn).ToUnixTimeSeconds().ToString(System.Globalization.CultureInfo.InvariantCulture))
        };
        foreach(var p in user.Permissions()) claims.Add(new("permission",p));
        var key=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(options.SigningKey));
        var token=new JwtSecurityToken(options.Issuer,options.Audience,claims,expires:expiry,signingCredentials:new SigningCredentials(key,SecurityAlgorithms.HmacSha256));
        return new LoginResponse
        {
            Token=new JwtSecurityTokenHandler().WriteToken(token),ExpiresAtUtc=expiry,
            User=new CurrentUser{Id=user.Id,UserName=user.UserName,DisplayName=user.DisplayName,RoleCode=user.RoleCode,DepartmentCode=user.DepartmentCode,BranchCode=user.BranchCode,Permissions=user.Permissions()}
        };
    }
}

public static class PrincipalExtensions
{
    public static CurrentUser ToCurrentUser(this ClaimsPrincipal p)
    {
        if(p.Identity?.IsAuthenticated!=true) throw new UnauthorizedAccessException("Authentication required.");
        // Tokens issued before ids became numeric carry a GUID subject; they are rejected so the user signs in again.
        if(!long.TryParse(p.FindFirstValue(ClaimTypes.NameIdentifier),System.Globalization.NumberStyles.None,System.Globalization.CultureInfo.InvariantCulture,out var userId))
            throw new UnauthorizedAccessException("Your session is no longer valid. Please sign in again.");
        return new CurrentUser
        {
            Id=userId,
            UserName=p.FindFirstValue(ClaimTypes.Name) ?? "",
            DisplayName=p.FindFirstValue("displayName") ?? p.Identity.Name ?? "",
            RoleCode=p.FindFirstValue(ClaimTypes.Role) ?? "",
            DepartmentCode=p.FindFirstValue("department") ?? "",
            BranchCode=p.FindFirstValue("branch") ?? "",
            Permissions=p.FindAll("permission").Select(x=>x.Value).ToList()
        };
    }
}
