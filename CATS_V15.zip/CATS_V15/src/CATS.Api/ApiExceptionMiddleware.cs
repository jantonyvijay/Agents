using System.Net;
using System.Text.Json;

namespace CATS.Api;

public sealed class ApiExceptionMiddleware(RequestDelegate next,ILogger<ApiExceptionMiddleware> log)
{
    public async Task Invoke(HttpContext ctx)
    {
        try{await next(ctx);}
        catch(Exception ex) when(ctx.Request.Path.StartsWithSegments("/api"))
        {
            log.LogError(ex,"CATS API failure on {Path} (reference {RequestId})",ctx.Request.Path,ctx.TraceIdentifier);
            ctx.Items[RequestDiagnosticsMiddleware.ExceptionItemKey]=ex;
            ctx.Response.ContentType="application/problem+json";
            ctx.Response.StatusCode=ex switch{UnauthorizedAccessException=>StatusCodes.Status403Forbidden,KeyNotFoundException=>StatusCodes.Status404NotFound,InvalidOperationException=>StatusCodes.Status409Conflict,_=>StatusCodes.Status500InternalServerError};
            await ctx.Response.WriteAsync(JsonSerializer.Serialize(new{type="about:blank",title=ex.GetType().Name,status=ctx.Response.StatusCode,detail=ctx.Response.StatusCode==500?"Unexpected server error. Quote the Reference ID to IT support.":ex.Message,traceId=ctx.TraceIdentifier}));
        }
    }
}
