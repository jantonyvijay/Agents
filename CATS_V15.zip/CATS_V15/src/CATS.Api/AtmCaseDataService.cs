using System.Text.Json;
using System.Text.Json.Nodes;
using System.Globalization;
using CATS.Core;
using CATS.Infrastructure;

namespace CATS.Api;

public sealed class AtmCaseDataService(ICatsRepository repo, AdoHelper db)
{
    public async Task SynchronizeAlertDataAsync(long alertId, CurrentUser? actionUser, CancellationToken ct)
    {
        var alert = await repo.GetAlertAsync(alertId, ct) ?? throw new KeyNotFoundException("Alert not found.");
        var table = alert.AlertType.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase)
            ? "tbl_ATM_Txn_Mntr_OnUs"
            : alert.AlertType.Equals("ATM_OFFUS", StringComparison.OrdinalIgnoreCase)
                ? "tbl_ATM_Txn_Mntr_OFFUs"
                : null;
        if (table is null) return;

        var dynamicDataJson = string.IsNullOrWhiteSpace(alert.DynamicDataJson) ? "{}" : alert.DynamicDataJson;
        if (alert.AlertType.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) && actionUser is not null &&
            ActionedStatusField(actionUser.RoleCode) is { } statusField)
        {
            var dataNode = JsonNode.Parse(dynamicDataJson) as JsonObject ?? new JsonObject();
            dataNode[statusField] = "Completed";
            foreach (var notApplicable in NotApplicableStatusFields(actionUser.RoleCode, alert.CurrentStageId, alert.Status))
                dataNode[notApplicable] = "NA";
            dynamicDataJson = dataNode.ToJsonString();
            await repo.UpdateAlertDynamicDataAsync(alertId, dynamicDataJson, ct);
        }

        using var data = JsonDocument.Parse(dynamicDataJson);
        if (!alert.AlertType.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase))
        {
            var category = data.RootElement.TryGetProperty("CaseCategory", out var value) && value.ValueKind != JsonValueKind.Null
                ? value.ToString()
                : null;
            await db.ExecuteAsync(
                $"UPDATE {table} SET CaseCategory={db.Dialect.P("Category")} WHERE AlertId={db.Dialect.P("Alert")}",
                [new("Category", string.IsNullOrWhiteSpace(category) ? null : category), new("Alert", alertId)], ct);
            return;
        }

        var updates = new List<string>();
        var args = new List<DbArg>();
        foreach (var column in new[]
        {
            "Recoverable_Type", "Recoverable_VendorName", "Excess_Reported", "Excess_Date", "MailDate", "EJ_Error",
            "Recovery_Reason", "RecoveryReason_Remark", "Fourwayreconcilition", "ATMC_Remark", "ATMC_Status",
            "RATC_Remark", "RATC_Status", "SH_Remark", "SH_Status", "RH_Remark", "RH_Status", "GH_Remark", "GH_Status"
        })
        {
            if (!data.RootElement.TryGetProperty(column, out var value)) continue;
            updates.Add($"{column}={db.Dialect.P($"v{args.Count}")}");
            args.Add(new($"v{args.Count}", ToColumnValue(column, value.ToString())));
        }

        if (data.RootElement.TryGetProperty("Recoverable_Type", out var type))
        {
            var noPenalty = type.ToString() is "Goodfaith" or "Service Gesture";
            updates.Add($"NoPenaltyApplicable={db.Dialect.P($"v{args.Count}")}");
            args.Add(new($"v{args.Count}", noPenalty));
        }
        if (updates.Count == 0) return;
        args.Add(new("Alert", alertId));
        await db.ExecuteAsync(
            $"UPDATE {table} SET {string.Join(",", updates)} WHERE AlertId={db.Dialect.P("Alert")}", args, ct);
    }

    private static string? ActionedStatusField(string roleCode) => roleCode.ToUpperInvariant() switch
    {
        "ATMC" => "ATMC_Status",
        "RATC" => "RATC_Status",
        "SH" => "SH_Status",
        "RH" => "RH_Status",
        "GH" => "GH_Status",
        _ => null
    };

    private static IEnumerable<string> NotApplicableStatusFields(string roleCode, string currentStageId, AlertStatus status)
    {
        switch (roleCode.ToUpperInvariant())
        {
            case "SH" when currentStageId.Equals("rh", StringComparison.OrdinalIgnoreCase):
                yield return "GH_Status";
                break;
            case "SH" when currentStageId.Equals("gh", StringComparison.OrdinalIgnoreCase):
                yield return "RH_Status";
                break;
            case "SH" when status is AlertStatus.Closed or AlertStatus.Rejected:
                yield return "RH_Status";
                yield return "GH_Status";
                break;
            case "RH":
                yield return "GH_Status";
                break;
            case "GH":
                yield return "RH_Status";
                break;
        }
    }

    private static object? ToColumnValue(string column, string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        if (column is "Excess_Date" or "MailDate")
            return DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.None, out var date) ? date : value;
        if (column == "Fourwayreconcilition") return value.Equals("Yes", StringComparison.OrdinalIgnoreCase);
        return value;
    }
}
