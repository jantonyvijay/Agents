using System.Collections.Concurrent;
using System.Diagnostics;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Channels;
using CATS.Core;
using CATS.Infrastructure;

namespace CATS.Api;

public sealed record DiagnosticEvent(string RequestId, DateTime OccurredAtUtc, long? UserId, string? UserName, string? RoleCode, string Module,
    string Method, string Path, int StatusCode, int DurationMs, string Severity, string? ExceptionType, string? Message, string? StackTrace, string? IpAddress);

public sealed record ModuleMetric(string Module, string Label, long Requests, long ServerErrors, long ClientErrors, double AverageMs, int P95Ms, int MaxMs);

/// <summary>
/// Central collector for operational problems. Failed (4xx/5xx) and slow API requests are queued and written to DiagnosticEvents without
/// slowing the request; per-module request counts and response times are also kept in memory for the live health view.
/// </summary>
public sealed class DiagnosticsService(AdoHelper db, ILogger<DiagnosticsService> log) : BackgroundService
{
    public const int SlowRequestMs = 3000;
    private const int RetentionDays = 90;
    private const int SamplesPerModule = 500;

    public static readonly string ReleaseVersion = typeof(DiagnosticsService).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion?.Split('+')[0]
        ?? typeof(DiagnosticsService).Assembly.GetName().Version?.ToString() ?? "unknown";
    public static readonly DateTime BuiltAtUtc = File.GetLastWriteTimeUtc(typeof(DiagnosticsService).Assembly.Location);
    public DateTime StartedAtUtc { get; } = DateTime.UtcNow;

    private readonly Channel<DiagnosticEvent> queue = Channel.CreateBounded<DiagnosticEvent>(new BoundedChannelOptions(2000) { FullMode = BoundedChannelFullMode.DropOldest, SingleReader = true });
    private readonly ConcurrentDictionary<string, ModuleStats> stats = new(StringComparer.OrdinalIgnoreCase);

    private sealed class ModuleStats
    {
        public readonly object Gate = new();
        public long Requests, ServerErrors, ClientErrors, TotalMs;
        public int MaxMs;
        public readonly int[] Samples = new int[SamplesPerModule];
        public int Next, Filled;
    }

    public void Observe(string module, int statusCode, int durationMs)
    {
        var s = stats.GetOrAdd(module, _ => new ModuleStats());
        lock (s.Gate)
        {
            s.Requests++;
            s.TotalMs += durationMs;
            if (durationMs > s.MaxMs) s.MaxMs = durationMs;
            if (statusCode >= 500) s.ServerErrors++;
            else if (statusCode >= 400) s.ClientErrors++;
            s.Samples[s.Next] = durationMs;
            s.Next = (s.Next + 1) % SamplesPerModule;
            if (s.Filled < SamplesPerModule) s.Filled++;
        }
    }

    public void Record(DiagnosticEvent item) => queue.Writer.TryWrite(item);

    public IReadOnlyList<ModuleMetric> Snapshot() => stats
        .Select(x =>
        {
            lock (x.Value.Gate)
            {
                var sorted = x.Value.Samples.Take(x.Value.Filled).OrderBy(v => v).ToArray();
                var p95 = sorted.Length == 0 ? 0 : sorted[Math.Min(sorted.Length - 1, (int)Math.Ceiling(sorted.Length * 0.95) - 1)];
                return new ModuleMetric(x.Key, DiagnosticsAdvisor.ModuleLabel(x.Key), x.Value.Requests, x.Value.ServerErrors, x.Value.ClientErrors,
                    x.Value.Requests == 0 ? 0 : Math.Round((double)x.Value.TotalMs / x.Value.Requests, 1), p95, x.Value.MaxMs);
            }
        })
        .OrderByDescending(x => x.Requests)
        .ToList();

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var purge = PurgeLoopAsync(stoppingToken);
        try
        {
            await foreach (var e in queue.Reader.ReadAllAsync(stoppingToken))
            {
                try { await WriteAsync(e, stoppingToken); }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex) { log.LogWarning(ex, "Diagnostic event {RequestId} could not be stored", e.RequestId); }
            }
        }
        catch (OperationCanceledException) { }
        await purge;
    }

    private Task WriteAsync(DiagnosticEvent e, CancellationToken ct)
    {
        var p = db.Dialect.P;
        return db.ExecuteAsync(
            $"INSERT INTO DiagnosticEvents(Id,RequestId,OccurredAtUtc,UserId,UserName,RoleCode,Module,HttpMethod,Path,StatusCode,DurationMs,Severity,ExceptionType,Message,StackTrace,IpAddress,ReleaseVersion) " +
            $"VALUES({p("Id")},{p("Req")},{p("At")},{p("UserId")},{p("User")},{p("Role")},{p("Module")},{p("Method")},{p("Path")},{p("Status")},{p("Ms")},{p("Sev")},{p("ExType")},{p("Msg")},{p("Stack")},{p("Ip")},{p("Rel")})",
            [new("Id", CatsId.Next()), new("Req", e.RequestId), new("At", e.OccurredAtUtc), new("UserId", e.UserId), new("User", e.UserName), new("Role", e.RoleCode),
             new("Module", e.Module), new("Method", e.Method), new("Path", Trim(e.Path, 500)), new("Status", e.StatusCode), new("Ms", e.DurationMs), new("Sev", e.Severity),
             new("ExType", Trim(e.ExceptionType, 200)), new("Msg", Trim(e.Message, 1000)), new("Stack", Trim(e.StackTrace, 4000)), new("Ip", Trim(e.IpAddress, 100)),
             new("Rel", ReleaseVersion)], ct);
    }

    private async Task PurgeLoopAsync(CancellationToken ct)
    {
        try
        {
            using var timer = new PeriodicTimer(TimeSpan.FromHours(6));
            do
            {
                try
                {
                    await db.ExecuteAsync($"DELETE FROM DiagnosticEvents WHERE OccurredAtUtc<{db.Dialect.P("Cut")}", [new("Cut", DateTime.UtcNow.AddDays(-RetentionDays))], ct);
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex) { log.LogWarning(ex, "Diagnostic event clean-up failed"); }
            } while (await timer.WaitForNextTickAsync(ct));
        }
        catch (OperationCanceledException) { }
    }

    internal static string? Trim(string? value, int max) => value is null ? null : value.Length <= max ? value : value[..max];
}

/// <summary>Turns a technical failure into a plain-language explanation for Center and Admin users.</summary>
public static class DiagnosticsAdvisor
{
    public sealed record Advice(string Category, string WhatHappened, string LikelyCause, string WhatToDo, string Owner);

    private static readonly Dictionary<string, string> Labels = new(StringComparer.OrdinalIgnoreCase)
    {
        ["atm"] = "ATM Operations", ["atm/staff-mapping"] = "ATM Staff Mapping", ["alerts"] = "Alerts", ["auth"] = "Login & Session",
        ["templates"] = "Templates", ["menus"] = "Menus", ["mcp"] = "MCP Tools", ["assistant"] = "CATS Assistant", ["dashboard"] = "Dashboard",
        ["meta"] = "Reference Data", ["admin"] = "User Administration", ["admin/role-permissions"] = "Role Permissions",
        ["platform"] = "Platform", ["platform/ingestion"] = "Data Ingestion", ["platform/mail"] = "Mail", ["platform/reports"] = "Reports",
        ["platform/dashboard"] = "Dashboards", ["diagnostics"] = "Monitoring"
    };

    public static string ModuleLabel(string module) => Labels.TryGetValue(module, out var label) ? label : module;

    public static string ModuleOf(PathString path)
    {
        var parts = (path.Value ?? "").Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length < 2) return "other";
        var first = parts[1].ToLowerInvariant();
        var second = parts.Length > 2 ? parts[2].ToLowerInvariant() : "";
        var twoPart = first is "platform" or "admin" || (first == "atm" && second == "staff-mapping");
        return twoPart && second.Length > 0 && !long.TryParse(second, out _) ? $"{first}/{second}" : first;
    }

    public static Advice Explain(int status, string? exceptionType, string? message, int durationMs, string module = "")
    {
        var ex = exceptionType ?? "";
        var text = message ?? "";
        if (status == 401 && module == "auth")
            return new("Sign-in failed", "A sign-in attempt was refused.",
                "The user name or password was wrong, or the account is disabled.",
                "Ask the user to retype the password carefully. If it keeps failing, reset the password in User Administration. Repeated failures for many different users in a short time can be a guessing attack: tell IT. See Data audit for LOGIN_FAILED.", "Admin");
        if (status == 401)
            return new("Login / session", "The request arrived without a valid login session.",
                "The user's session expired, they were signed out, or their session predates a system upgrade or restart.",
                "Ask the user to sign in again. If many users report it at the same time, check that the API was not restarted with a different security key.", "Business user");
        if (status == 403 && ex.Contains("UnauthorizedAccess"))
            return new("Access denied", "The user tried an action their role is not allowed to do.",
                "The role does not have the permission named in the message.",
                "Open Role Permissions and grant the permission if the access is appropriate. The user must sign out and sign in again to pick it up.", "Admin");
        if (status == 403)
            return new("Access denied", "The request was blocked before the action ran.",
                "The gateway access key is missing or wrong, or the user's session has no access to this feature.",
                "Make sure the screen is opened through the CATS gateway/app and not by calling the API directly. If it persists, ask IT to check the gateway key.", "IT / Support");
        if (status == 404 && ex.Contains("KeyNotFound"))
            return new("Record not found", "The record the screen asked for could not be found.",
                "The record was removed, belongs to a different environment, or the user is looking at an old list.",
                "Ask the user to refresh the list and open the record again. If the record should exist, search its Reference ID in Data audit.", "Business user");
        if (status == 404)
            return new("Screen / API mismatch", "The screen asked for a service address that does not exist.",
                "The browser still holds an older version of the screen after an upgrade, or the API was not upgraded together with the app.",
                "Ask the user to hard-refresh (Ctrl+F5). If it continues, confirm the API and App are the same release (see Release on the Overview).", "IT / Support");
        if (status == 409)
            return new("Not allowed in current state", "The action was refused because of the record's current state or a business rule.",
                "Another user already acted on the record, the record is in a different stage, or required data is missing. The message gives the exact rule.",
                "Refresh the record and read the message. If the record looks stuck, check its stage and assignment in Alerts.", "Business user");
        if (status is 400 or 422)
            return new("Invalid input", "The data sent by the user did not pass validation.",
                "A required value is missing or in the wrong format (for example in an uploaded file).",
                "Read the message, correct the data (or the file) and submit again.", "Business user");
        if (status >= 500 && (ex.Contains("Sql") || ex.Contains("Db") || ex.Contains("Oracle") || ex.Contains("Npgsql")))
            return new("Database problem", "The system could not read or save data in the database.",
                text.Contains("timeout", StringComparison.OrdinalIgnoreCase) ? "The database took too long to respond (load or a blocked query)." : "The database is unreachable, rejected the data, or its structure is older than the application.",
                "Check that the database is up and that the latest upgrade scripts were applied (restarting the API applies them). Give IT the Reference ID.", "IT / Developer");
        if (status >= 500 && (ex.Contains("Timeout") || ex.Contains("TaskCanceled") || ex.Contains("OperationCanceled")))
            return new("Timeout", "The request took too long and was stopped.", "A very large request or a slow dependency (database, mail, MCP tool).",
                "Retry with a smaller request. If it repeats, give IT the Reference ID.", "IT / Developer");
        if (status >= 500 && (ex.Contains("Json") || ex.Contains("Format") || ex.Contains("BadHttpRequest")))
            return new("Bad data format", "The system could not read the data it received.", "The file or request contains a value in an unexpected format.",
                "Check the uploaded file against the template and upload again.", "Business user");
        if (status >= 500)
            return new("System error", "The system hit an unexpected problem while processing the request.", "A defect or an unexpected data condition.",
                "Note the Reference ID and send it to IT/Developer; the technical detail (Admin only) shows where it failed.", "IT / Developer");
        if (durationMs >= DiagnosticsService.SlowRequestMs)
            return new("Slow response", $"The request worked but took {durationMs / 1000.0:0.0} seconds.", "A large amount of data, or the database was busy at that time.",
                "Occasional slowness can be ignored. If the same module is slow repeatedly, inform IT with the Reference IDs.", "IT / Support");
        return new("Other", "The request did not complete normally.", "Not classified.", "Give the Reference ID to IT/Developer.", "IT / Developer");
    }
}

/// <summary>Outermost API middleware: stamps every response with a Reference ID (X-Request-Id) and records failures and slow calls.</summary>
public sealed class RequestDiagnosticsMiddleware(RequestDelegate next, DiagnosticsService diagnostics)
{
    public const string ExceptionItemKey = "cats.exception";

    public async Task Invoke(HttpContext ctx)
    {
        if (!ctx.Request.Path.StartsWithSegments("/api") || HttpMethods.IsOptions(ctx.Request.Method))
        {
            await next(ctx);
            return;
        }
        var requestId = ctx.TraceIdentifier;
        ctx.Response.OnStarting(() =>
        {
            ctx.Response.Headers["X-Request-Id"] = requestId;
            return Task.CompletedTask;
        });
        var clock = Stopwatch.StartNew();
        try { await next(ctx); }
        finally
        {
            clock.Stop();
            Capture(ctx, requestId, (int)clock.ElapsedMilliseconds);
        }
    }

    private void Capture(HttpContext ctx, string requestId, int elapsedMs)
    {
        try
        {
            var module = DiagnosticsAdvisor.ModuleOf(ctx.Request.Path);
            if (module == "diagnostics") return;
            var status = ctx.Response.StatusCode;
            diagnostics.Observe(module, status, elapsedMs);
            var slow = elapsedMs >= DiagnosticsService.SlowRequestMs;
            if (status < 400 && !slow) return;
            var ex = ctx.Items[ExceptionItemKey] as Exception;
            long? userId = long.TryParse(ctx.User.FindFirstValue(ClaimTypes.NameIdentifier), out var uid) ? uid : null;
            diagnostics.Record(new DiagnosticEvent(requestId, DateTime.UtcNow, userId, ctx.User.FindFirstValue(ClaimTypes.Name), ctx.User.FindFirstValue(ClaimTypes.Role),
                module, ctx.Request.Method, ctx.Request.Path.Value ?? "", status, elapsedMs, status >= 500 ? "Error" : status >= 400 ? "Warning" : "Slow",
                ex?.GetType().Name, ex?.Message, ex?.ToString(), ctx.Connection.RemoteIpAddress?.ToString()));
        }
        catch
        {
            // Diagnostics must never break the request that is being observed.
        }
    }
}
