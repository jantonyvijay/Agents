using System.Text.Json;

namespace CATS.Api;

public static class ConfigurationAuditDetails
{
    public sealed record Change(string Property,string? Before,string? After);
    public sealed record Result(bool HasPrevious,bool HasCurrent,bool Available,int TotalChanges,IReadOnlyList<Change> Changes);

    public static Result Compare(string? previous,string? current)
    {
        var before=new Dictionary<string,string>();
        var after=new Dictionary<string,string>();
        try
        {
            if(!string.IsNullOrWhiteSpace(previous)) { using var doc=JsonDocument.Parse(previous); Flatten(doc.RootElement,"",before); }
            if(!string.IsNullOrWhiteSpace(current)) { using var doc=JsonDocument.Parse(current); Flatten(doc.RootElement,"",after); }
        }
        catch(JsonException) { return new(previous!=null,current!=null,false,0,[]); }
        var keys=before.Keys.Union(after.Keys).Where(key=>before.GetValueOrDefault(key)!=after.GetValueOrDefault(key)).ToList();
        return new(previous!=null,current!=null,true,keys.Count,keys.Take(500).Select(key=>
            new Change(key,Display(key,before.GetValueOrDefault(key)),Display(key,after.GetValueOrDefault(key)))).ToList());
    }

    private static string? Display(string path,string? value)
    {
        if(value==null)return null;
        var lower=path.ToLowerInvariant();
        if(new[]{"defaultvalue","password","secret","token","connectionstring","apiurl","headers","agentinstructions","agentprompt"}.Any(lower.Contains))
            return "[Hidden]";
        return value.Length>2000?value[..2000]+"… [truncated]":value;
    }

    private static void Flatten(JsonElement node,string path,Dictionary<string,string> values)
    {
        if(node.ValueKind==JsonValueKind.Object)
        {
            foreach(var property in node.EnumerateObject())
            {
                var key=property.Name.ToLowerInvariant();
                var child=string.IsNullOrEmpty(path)?key:path+"."+key;
                if(key.EndsWith("json") && property.Value.ValueKind==JsonValueKind.String)
                {
                    var text=property.Value.GetString()??"";
                    JsonDocument nested;
                    try { nested=JsonDocument.Parse(text); }
                    catch(JsonException)
                    {
                        // Older configuration may contain blank or plain-text option lists.
                        // Compare that value as text; it must not hide all other changes.
                        values[child]=text;
                        continue;
                    }
                    using(nested) Flatten(nested.RootElement,child[..^4],values);
                }
                else Flatten(property.Value,child,values);
            }
            if(!node.EnumerateObject().Any()) values[path]="{}";
        }
        else if(node.ValueKind==JsonValueKind.Array)
        {
            var index=0;
            foreach(var item in node.EnumerateArray())
            {
                var identity=item.ValueKind==JsonValueKind.Object
                    ? item.EnumerateObject().FirstOrDefault(p=>p.Name.Equals("id",StringComparison.OrdinalIgnoreCase)).Value
                    : default;
                var label=identity.ValueKind==JsonValueKind.String?identity.GetString():index.ToString();
                Flatten(item,$"{path}[{label}]",values);
                index++;
            }
            if(index==0)values[path]="[]";
        }
        else values[path]=node.ValueKind==JsonValueKind.String?node.GetString()??"":node.GetRawText();
    }
}
