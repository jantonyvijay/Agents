using System.Text;
using Whisper.net;

namespace CATS.Api;

public interface IOfflineSpeechToTextService
{
    bool IsAvailable { get; }
    long MaxAudioBytes { get; }
    Task<string> TranscribeAsync(Stream audio, CancellationToken cancellationToken);
}

public sealed class OfflineSpeechToTextService(
    SpeechToTextOptions options,
    IWebHostEnvironment environment,
    ILogger<OfflineSpeechToTextService> logger) : IOfflineSpeechToTextService, IDisposable
{
    private readonly SemaphoreSlim transcriptionLock = new(1, 1);
    private readonly Lazy<WhisperFactory> factory = new(
        () => WhisperFactory.FromPath(ResolveModelPath(options.ModelPath, environment.ContentRootPath)));

    public bool IsAvailable => options.Enabled && File.Exists(ResolveModelPath(options.ModelPath, environment.ContentRootPath));
    public long MaxAudioBytes => options.MaxAudioBytes;

    public async Task<string> TranscribeAsync(Stream audio, CancellationToken cancellationToken)
    {
        if (!IsAvailable)
            throw new InvalidOperationException("Offline speech-to-text is not configured. Ask an administrator to enable it and provision the local Whisper model.");

        await ValidateWaveAudioAsync(audio, cancellationToken);
        await transcriptionLock.WaitAsync(cancellationToken);
        try
        {
            using var processor = factory.Value.CreateBuilder()
                .WithLanguage(options.Language)
                .Build();

            var transcript = new StringBuilder();
            await foreach (var segment in processor.ProcessAsync(audio, cancellationToken))
                transcript.Append(segment.Text);

            var text = transcript.ToString().Trim();
            if (text.Length == 0)
                throw new InvalidOperationException("No speech was detected in the recording.");

            return text;
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            logger.LogError(exception, "Offline speech-to-text transcription failed.");
            throw;
        }
        finally
        {
            transcriptionLock.Release();
        }
    }

    public void Dispose()
    {
        if (factory.IsValueCreated)
            factory.Value.Dispose();
        transcriptionLock.Dispose();
    }

    private static async Task ValidateWaveAudioAsync(Stream audio, CancellationToken cancellationToken)
    {
        if (!audio.CanSeek)
            throw new InvalidOperationException("The audio stream must support seeking.");

        var header = new byte[12];
        var bytesRead = await audio.ReadAsync(header, cancellationToken);
        audio.Position = 0;
        if (bytesRead != header.Length ||
            !header.AsSpan(0, 4).SequenceEqual("RIFF"u8) ||
            !header.AsSpan(8, 4).SequenceEqual("WAVE"u8))
            throw new InvalidOperationException("Only WAV audio recorded by CATS is supported.");
    }

    private static string ResolveModelPath(string configuredPath, string contentRootPath) =>
        Path.IsPathRooted(configuredPath) ? configuredPath : Path.Combine(contentRootPath, configuredPath);
}
