using CATS.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace CATS.Api.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(ICatsRepository repo,IPlatformRepository platform,IPasswordHasher hasher,JwtTokenService tokens) : ControllerBase
{
    [HttpPost("login")]
    public async Task<ActionResult<LoginResponse>> Login(LoginRequest request,CancellationToken ct)
    {
        var user=await repo.GetUserByUserNameAsync(request.UserName.Trim(),ct);
        if(user==null || !user.IsActive || !hasher.Verify(request.Password,user.PasswordHash))
        {
            await repo.InsertAuditAsync(new AuditRecord{Id=CatsId.Next(),UserId=user?.Id??0,UserName=request.UserName,RoleCode=user?.RoleCode??"",Action="LOGIN_FAILED",EntityType="Authentication",Remarks="Invalid credentials",IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow},ct);
            return Unauthorized(new{message="Invalid user name or password."});
        }
        user.PermissionsJson=System.Text.Json.JsonSerializer.Serialize(await platform.GetEffectivePermissionsAsync(user.Id,ct));
        await repo.InsertAuditAsync(new AuditRecord{Id=CatsId.Next(),UserId=user.Id,UserName=user.UserName,RoleCode=user.RoleCode,Action="LOGIN",EntityType="Authentication",Remarks="Login successful",IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow},ct);
        return Ok(tokens.Create(user));
    }
    /// <summary>
    /// Sliding session: the browser calls this while the user is active and receives a fresh token. The account must still be active, permissions are
    /// re-read, and the session can never exceed Jwt:MaxSessionMinutes from the original sign-in.
    /// </summary>
    [Authorize]
    [HttpPost("refresh")]
    public async Task<ActionResult<LoginResponse>> Refresh(CancellationToken ct)
    {
        var current=User.ToCurrentUser();
        var user=await repo.GetUserByIdAsync(current.Id,ct);
        if(user==null || !user.IsActive) return Unauthorized(new{message="Your account is no longer active. Please sign in again."});
        var signedIn=tokens.SignInTimeOf(User);
        if(!tokens.CanExtend(signedIn)) return Unauthorized(new{message="Your session has reached its maximum length. Please sign in again."});
        user.PermissionsJson=System.Text.Json.JsonSerializer.Serialize(await platform.GetEffectivePermissionsAsync(user.Id,ct));
        return Ok(tokens.Create(user,signedIn));
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout(CancellationToken ct)
    {
        var current=User.ToCurrentUser();
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id=CatsId.Next(),UserId=current.Id,UserName=current.UserName,RoleCode=current.RoleCode,
            Action="LOGOUT",EntityType="Authentication",Remarks="User signed out",
            IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow
        },ct);
        return NoContent();
    }

}
