using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

/// <summary>The navigation menu, stored in MenuMaster (with optional MenuRoleMapping) and filtered by the caller's role and permissions.</summary>
[Authorize]
[ApiController]
[Route("api/menus")]
public sealed class MenusController(AdoHelper db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Mine(CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        var nodes = await db.QueryAsync(
            "SELECT Id,ParentId,Code,Label,Title,Description,Icon,ViewKey,PermissionCode,DisplayOrder FROM MenuMaster WHERE IsActive=1",
            r => new MenuNode
            {
                Id = r.Lng("Id"), ParentId = r.NLng("ParentId"), Code = r.Str("Code"), Label = r.Str("Label"), Title = r.Str("Title"),
                Description = r.Str("Description"), Icon = r.Str("Icon"), ViewKey = r.Str("ViewKey"), PermissionCode = r.Str("PermissionCode"),
                DisplayOrder = r.Int("DisplayOrder")
            }, ct: ct);
        var roles = (await db.QueryAsync("SELECT MenuId,RoleCode FROM MenuRoleMapping", r => (MenuId: r.Lng("MenuId"), Role: r.Str("RoleCode")), ct: ct))
            .ToLookup(x => x.MenuId, x => x.Role);
        foreach (var node in nodes) node.Roles = roles[node.Id].ToList();
        return Ok(MenuCatalog.Build(nodes, user.HasPermission, user.RoleCode));
    }
}
