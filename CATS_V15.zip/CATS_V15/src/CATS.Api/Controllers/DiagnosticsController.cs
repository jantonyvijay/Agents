using System.Diagnostics;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

/// <summary>Monitoring and troubleshooting for Center and Admin users: what failed, for whom, why, and what to do about it.</summary>
[Authorize, ApiController, Route("api/diagnostics")]
public sealed class DiagnosticsController(AdoHelper db, DiagnosticsService diagnostics, DatabaseOptions dbOptions, IWebHostEnvironment env) : ControllerBase
{
    private const int MaxPageSize = 100;

    private CurrentUser Require()
    {
        var u = User.ToCurrentUser();
        if (!u.HasPermission(CatsPermissions.DiagnosticsView)) throw new UnauthorizedAccessException($"Permission {CatsPermissions.DiagnosticsView} is required.");
        return u;
    }

    private string P(string name) => db.Dialect.P(name);

    private static object Describe(DiagnosticRow r, bool includeStack)
    {
        var advice = DiagnosticsAdvisor.Explain(r.StatusCode, r.ExceptionType, r.Message, r.DurationMs, r.Module);
        return new
        {
            r.Id, r.RequestId, r.OccurredAtUtc, r.UserId, r.UserName, r.RoleCode, r.Module, moduleLabel = DiagnosticsAdvisor.ModuleLabel(r.Module),
            r.Method, r.Path, r.StatusCode, r.DurationMs, r.Severity, r.ExceptionType, r.Message, r.IpAddress, r.ReleaseVersion,
            category = advice.Category, whatHappened = advice.WhatHappened, likelyCause = advice.LikelyCause, whatToDo = advice.WhatToDo, owner = advice.Owner,
            stackTrace = includeStack ? r.StackTrace : null
        };
    }

    private sealed record DiagnosticRow(long Id, string RequestId, DateTime OccurredAtUtc, long? UserId, string? UserName, string? RoleCode, string Module, string Method,
        string Path, int StatusCode, int DurationMs, string Severity, string? ExceptionType, string? Message, string? StackTrace, string? IpAddress, string? ReleaseVersion);

    private const string EventColumns = "Id,RequestId,OccurredAtUtc,UserId,UserName,RoleCode,Module,HttpMethod,Path,StatusCode,DurationMs,Severity,ExceptionType,Message,StackTrace,IpAddress,ReleaseVersion";

    private static DiagnosticRow MapEvent(System.Data.Common.DbDataReader r) => new(r.Lng("Id"), r.Str("RequestId"), r.Dt("OccurredAtUtc"), r.NLng("UserId"), r.NStr("UserName"),
        r.NStr("RoleCode"), r.Str("Module"), r.Str("HttpMethod"), r.Str("Path"), r.Int("StatusCode"), r.Int("DurationMs"), r.Str("Severity"), r.NStr("ExceptionType"),
        r.NStr("Message"), r.NStr("StackTrace"), r.NStr("IpAddress"), r.NStr("ReleaseVersion"));

    [HttpGet("summary")]
    public async Task<IActionResult> Summary([FromQuery] int hours = 24, CancellationToken ct = default)
    {
        Require();
        hours = Math.Clamp(hours, 1, 24 * 30);
        var since = DateTime.UtcNow.AddHours(-hours);
        var args = new[] { new DbArg("Since", since) };
        var where = $"WHERE OccurredAtUtc>={P("Since")}";

        var totals = await db.QuerySingleAsync(
            $"SELECT COUNT(1) Total,COALESCE(SUM(CASE WHEN Severity='Error' THEN 1 ELSE 0 END),0) Errors,COALESCE(SUM(CASE WHEN Severity='Warning' THEN 1 ELSE 0 END),0) Warnings," +
            $"COALESCE(SUM(CASE WHEN Severity='Slow' THEN 1 ELSE 0 END),0) Slow,COUNT(DISTINCT UserName) Users FROM DiagnosticEvents {where}",
            r => new { total = r.Int("Total"), errors = r.Int("Errors"), warnings = r.Int("Warnings"), slow = r.Int("Slow"), usersAffected = r.Int("Users") }, args, ct);

        var byModule = await db.QueryAsync(
            db.Dialect.ApplyPagination($"SELECT Module,COUNT(1) Total,COALESCE(SUM(CASE WHEN Severity='Error' THEN 1 ELSE 0 END),0) Errors,COALESCE(SUM(CASE WHEN Severity='Warning' THEN 1 ELSE 0 END),0) Warnings," +
                $"COALESCE(SUM(CASE WHEN Severity='Slow' THEN 1 ELSE 0 END),0) Slow FROM DiagnosticEvents {where} GROUP BY Module ORDER BY COUNT(1) DESC", 1, 12),
            r => new { module = r.Str("Module"), label = DiagnosticsAdvisor.ModuleLabel(r.Str("Module")), total = r.Int("Total"), errors = r.Int("Errors"), warnings = r.Int("Warnings"), slow = r.Int("Slow") },
            args, ct);

        var topIssues = await db.QueryAsync(
            db.Dialect.ApplyPagination($"SELECT Module,StatusCode,ExceptionType,COUNT(1) Occurrences,COUNT(DISTINCT UserName) Users,MAX(OccurredAtUtc) LastSeen,MAX(RequestId) SampleRequestId " +
                $"FROM DiagnosticEvents {where} GROUP BY Module,StatusCode,ExceptionType ORDER BY COUNT(1) DESC", 1, 10),
            r =>
            {
                var advice = DiagnosticsAdvisor.Explain(r.Int("StatusCode"), r.NStr("ExceptionType"), null, 0, r.Str("Module"));
                return new
                {
                    module = r.Str("Module"), moduleLabel = DiagnosticsAdvisor.ModuleLabel(r.Str("Module")), statusCode = r.Int("StatusCode"), exceptionType = r.NStr("ExceptionType"),
                    occurrences = r.Int("Occurrences"), users = r.Int("Users"), lastSeen = r.Dt("LastSeen"), sampleRequestId = r.Str("SampleRequestId"),
                    category = advice.Category, whatToDo = advice.WhatToDo, owner = advice.Owner
                };
            }, args, ct);

        // Portable hourly trend: bucket in memory (capped) rather than with provider-specific date functions.
        var stamps = await db.QueryAsync(
            db.Dialect.ApplyPagination($"SELECT OccurredAtUtc,Severity FROM DiagnosticEvents {where} ORDER BY OccurredAtUtc DESC", 1, 20000),
            r => (At: r.Dt("OccurredAtUtc"), Severity: r.Str("Severity")), args, ct);
        var bucketHours = hours <= 48 ? 1 : 24;
        var firstBucket = new DateTime(since.Year, since.Month, since.Day, bucketHours == 1 ? since.Hour : 0, 0, 0, DateTimeKind.Utc);
        var trend = new List<object>();
        for (var t = firstBucket; t <= DateTime.UtcNow; t = t.AddHours(bucketHours))
        {
            var items = stamps.Where(s => s.At >= t && s.At < t.AddHours(bucketHours)).ToList();
            trend.Add(new { at = t, errors = items.Count(s => s.Severity == "Error"), warnings = items.Count(s => s.Severity == "Warning"), slow = items.Count(s => s.Severity == "Slow") });
        }

        return Ok(new
        {
            hours,
            totals,
            trend,
            byModule,
            topIssues,
            live = diagnostics.Snapshot().Select(m => new { m.Module, m.Label, m.Requests, m.ServerErrors, m.ClientErrors, m.AverageMs, m.P95Ms, m.MaxMs }),
            health = await HealthAsync(since, ct),
            release = new
            {
                version = DiagnosticsService.ReleaseVersion, builtAtUtc = DiagnosticsService.BuiltAtUtc, startedAtUtc = diagnostics.StartedAtUtc,
                environment = env.EnvironmentName, database = dbOptions.Provider, machine = Environment.MachineName, slowThresholdMs = DiagnosticsService.SlowRequestMs
            }
        });
    }

    private async Task<object[]> HealthAsync(DateTime since, CancellationToken ct)
    {
        var checks = new List<object>();
        var sinceArg = new[] { new DbArg("Since", since) };

        async Task Check(string name, string help, Func<Task<(string Status, string Detail)>> probe)
        {
            try
            {
                var (status, detail) = await probe();
                checks.Add(new { name, status, detail, help });
            }
            catch (Exception ex)
            {
                checks.Add(new { name, status = "Down", detail = ex.GetType().Name + ": " + ex.Message, help });
            }
        }

        await Check("Database", "Round-trip time to the CATS database.", async () =>
        {
            var clock = Stopwatch.StartNew();
            await db.ScalarAsync<int>("SELECT 1", null, ct);
            clock.Stop();
            return (clock.ElapsedMilliseconds > 1000 ? "Warning" : "OK", $"Responded in {clock.ElapsedMilliseconds} ms");
        });
        await Check("Mail delivery", "Mails that could not be sent in the selected period.", async () =>
        {
            var failed = await db.ScalarAsync<int>($"SELECT COUNT(1) FROM MailQueue WHERE Status='Failed' AND CreatedAtUtc>={P("Since")}", sinceArg, ct);
            var pending = await db.ScalarAsync<int>("SELECT COUNT(1) FROM MailQueue WHERE Status='Pending'", null, ct);
            return (failed > 0 ? "Warning" : "OK", $"{failed} failed, {pending} waiting to be sent");
        });
        await Check("Data ingestion", "Ingestion runs that failed in the selected period.", async () =>
        {
            var failed = await db.ScalarAsync<int>($"SELECT COUNT(1) FROM IngestionRun WHERE Status='Failed' AND StartedAtUtc>={P("Since")}", sinceArg, ct);
            return (failed > 0 ? "Warning" : "OK", $"{failed} failed run(s)");
        });
        await Check("ATM approvals", "Uploads waiting for a checker; a long queue means approvals are delayed.", async () =>
        {
            var pending = await db.ScalarAsync<int>("SELECT COUNT(1) FROM ATM_UploadBatches WHERE Status IN ('Pending','Processing')", null, ct);
            var oldest = await db.ScalarAsync<DateTime?>("SELECT MIN(UploadedAtUtc) FROM ATM_UploadBatches WHERE Status='Pending'", null, ct);
            var waiting = oldest.HasValue ? (int)(DateTime.UtcNow - DateTime.SpecifyKind(oldest.Value, DateTimeKind.Utc)).TotalHours : 0;
            return (waiting >= 24 ? "Warning" : "OK", pending == 0 ? "No uploads waiting" : $"{pending} waiting, oldest {waiting} h");
        });
        return [.. checks];
    }

    [HttpGet("events")]
    public async Task<IActionResult> Events([FromQuery] string? requestId, [FromQuery] string? user, [FromQuery] string? module, [FromQuery] string? severity,
        [FromQuery] int? status, [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        Require();
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, MaxPageSize);
        var clauses = new List<string>();
        var args = new List<DbArg>();
        if (!string.IsNullOrWhiteSpace(requestId)) { clauses.Add($"RequestId={P("Req")}");         args.Add(new("Req", requestId.Trim())); }
        if (!string.IsNullOrWhiteSpace(user)) { clauses.Add($"UserName LIKE {P("User")}"); args.Add(new("User", "%" + user.Trim() + "%")); }
        if (!string.IsNullOrWhiteSpace(module)) { clauses.Add($"Module={P("Module")}"); args.Add(new("Module", module.Trim())); }
        if (!string.IsNullOrWhiteSpace(severity)) { clauses.Add($"Severity={P("Sev")}"); args.Add(new("Sev", severity.Trim())); }
        if (status.HasValue) { clauses.Add($"StatusCode={P("Status")}"); args.Add(new("Status", status.Value)); }
        if (from.HasValue) { clauses.Add($"OccurredAtUtc>={P("From")}"); args.Add(new("From", from.Value.ToUniversalTime())); }
        if (to.HasValue) { clauses.Add($"OccurredAtUtc<={P("To")}"); args.Add(new("To", to.Value.ToUniversalTime())); }
        var where = clauses.Count == 0 ? "" : "WHERE " + string.Join(" AND ", clauses);

        var total = await db.ScalarAsync<int>($"SELECT COUNT(1) FROM DiagnosticEvents {where}", args, ct);
        var rows = await db.QueryAsync(db.Dialect.ApplyPagination($"SELECT {EventColumns} FROM DiagnosticEvents {where} ORDER BY OccurredAtUtc DESC,Id DESC", page, pageSize), MapEvent, args, ct);
        return Ok(new { total, page, pageSize, items = rows.Select(r => Describe(r, false)) });
    }

    [HttpGet("events/{requestId}")]
    public async Task<IActionResult> Event(string requestId, CancellationToken ct)
    {
        var current = Require();
        var rows = await db.QueryAsync(db.Dialect.ApplyPagination($"SELECT {EventColumns} FROM DiagnosticEvents WHERE RequestId={P("Req")} ORDER BY OccurredAtUtc DESC", 1, 20),
            MapEvent, [new("Req", requestId.Trim())], ct);
        if (rows.Count == 0) return NotFound(new { message = "No problem was recorded for this Reference ID. Successful requests are not stored." });
        var showStack = string.Equals(current.RoleCode, CatsRoles.Admin, StringComparison.OrdinalIgnoreCase);
        return Ok(rows.Select(r => Describe(r, showStack)));
    }

    [HttpGet("audit")]
    public async Task<IActionResult> Audit([FromQuery] string? user, [FromQuery] string? action, [FromQuery] string? entityType, [FromQuery] long? alertId,
        [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        Require();
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, MaxPageSize);
        var clauses = new List<string>();
        var args = new List<DbArg>();
        if (!string.IsNullOrWhiteSpace(user)) { clauses.Add($"UserName LIKE {P("User")}"); args.Add(new("User", "%" + user.Trim() + "%")); }
        if (!string.IsNullOrWhiteSpace(action)) { clauses.Add($"Action LIKE {P("Action")}"); args.Add(new("Action", "%" + action.Trim() + "%")); }
        if (!string.IsNullOrWhiteSpace(entityType)) { clauses.Add($"EntityType={P("Entity")}"); args.Add(new("Entity", entityType.Trim())); }
        if (alertId.HasValue) { clauses.Add($"AlertId={P("Alert")}"); args.Add(new("Alert", alertId.Value)); }
        if (from.HasValue) { clauses.Add($"CreatedAtUtc>={P("From")}"); args.Add(new("From", from.Value.ToUniversalTime())); }
        if (to.HasValue) { clauses.Add($"CreatedAtUtc<={P("To")}"); args.Add(new("To", to.Value.ToUniversalTime())); }
        var where = clauses.Count == 0 ? "" : "WHERE " + string.Join(" AND ", clauses);
        var total = await db.ScalarAsync<int>($"SELECT COUNT(1) FROM AuditLog {where}", args, ct);
        var rows = await db.QueryAsync(
            db.Dialect.ApplyPagination($"SELECT Id,AlertId,UserName,RoleCode,Action,EntityType,EntityId,Remarks,IpAddress,CreatedAtUtc FROM AuditLog {where} ORDER BY CreatedAtUtc DESC,Id DESC", page, pageSize),
            r => new
            {
                id = r.Lng("Id"), alertId = r.NLng("AlertId"), userName = r.Str("UserName"), roleCode = r.Str("RoleCode"), action = r.Str("Action"), entityType = r.Str("EntityType"),
                entityId = r.NStr("EntityId"), remarks = r.NStr("Remarks"), ipAddress = r.NStr("IpAddress"), createdAtUtc = r.Dt("CreatedAtUtc")
            }, args, ct);
        return Ok(new { total, page, pageSize, items = rows });
    }

    [HttpGet("filters")]
    public async Task<IActionResult> Filters(CancellationToken ct)
    {
        Require();
        var modules = await db.QueryAsync("SELECT DISTINCT Module FROM DiagnosticEvents", r => r.Str("Module"), null, ct);
        var entities = await db.QueryAsync("SELECT DISTINCT EntityType FROM AuditLog", r => r.Str("EntityType"), null, ct);
        return Ok(new
        {
            modules = modules.OrderBy(x => x).Select(x => new { value = x, label = DiagnosticsAdvisor.ModuleLabel(x) }),
            entityTypes = entities.OrderBy(x => x)
        });
    }
}
