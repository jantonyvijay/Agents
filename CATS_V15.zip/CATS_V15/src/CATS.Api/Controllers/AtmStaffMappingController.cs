using System.Globalization;
using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

/// <summary>
/// Masters › ATM › Staff Mapping. A DBOPS Maker uploads a file or enters one ATM; the batch waits in ATM_UploadBatches for a DBOPS Checker, whose
/// approval (POST api/atm/uploads/{id}/decision) writes it to tbl_ATM_Txn_Mntr_MappingMaster.
/// </summary>
[Authorize]
[ApiController]
[Route("api/atm/staff-mapping")]
public sealed class AtmStaffMappingController(AdoHelper db, ICatsRepository repo, IDataProtectorService protector) : ControllerBase
{
    private const int PreviewRows = 500;

    [HttpGet("config")]
    public async Task<IActionResult> GetConfiguration(CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        Require(user, CatsPermissions.AtmMasterView, "ATM master view permission is required.");
        var view = await AtmStaffMappingStore.LoadConfigurationAsync(db, ct);
        return Ok(ConfigurationResponse(view, user.HasPermission(CatsPermissions.AtmMasterConfigure)));
    }

    /// <summary>Administrators and the central team (ATM.MASTER.CONFIGURE) change the file layout and the file-to-table column mapping here.</summary>
    [HttpPut("config")]
    public async Task<IActionResult> SaveConfiguration(StaffMappingConfigurationRequest request, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        Require(user, CatsPermissions.AtmMasterConfigure, "The ATM master configuration permission is required to change the Staff Mapping column mapping.");
        var view = new TemplateViewConfiguration
        {
            BulkFileFormat = request.Format ?? "", BulkFileDelimiter = request.Delimiter ?? "",
            SourceColumnMappings = (request.Mappings ?? []).Select(x => new SourceColumnMappingConfiguration
                { Mode = "BulkFileUpload", Field = x.Field, SourceColumn = x.SourceColumn, Required = x.Required, Order = x.Order }).ToList()
        };
        if (!TabularFileReader.IsValidFormat(view.BulkFileFormat)) return BadRequest(new { message = "File format must be Auto, CSV, TXT or Excel." });
        view.BulkFileFormat = TabularFileReader.Normalize(view.BulkFileFormat);
        if (!TabularFileReader.IsValidDelimiter(view.BulkFileDelimiter))
            return BadRequest(new { message = "The file separator must be a single punctuation character such as , ~ | ; or a tab." });
        if (view.BulkFileFormat == "Excel") view.BulkFileDelimiter = "";
        if (AtmStaffMappingColumns.Normalize(view) is { } error) return BadRequest(new { message = error });
        await AtmStaffMappingStore.SaveConfigurationAsync(db, view, user.UserName, ct);
        await AuditAsync(user, "ATM_STAFFMAP_CONFIG", "ATMStaffMappingConfig", AtmStaffMappingColumns.SettingKey, "Staff Mapping column mapping updated.", ct);
        return Ok(ConfigurationResponse(view, true));
    }

    private static object ConfigurationResponse(TemplateViewConfiguration view, bool canConfigure) => new
    {
        format = view.BulkFileFormat, delimiter = view.BulkFileDelimiter, mappings = view.SourceColumnMappings, canConfigure,
        columns = AtmStaffMappingColumns.All.Select(x => new
            { name = x.Name, kind = x.Kind.ToString(), maxLength = x.MaxLength == int.MaxValue ? 0 : x.MaxLength, system = AtmStaffMappingColumns.IsSystemColumn(x.Name) }),
        defaults = AtmStaffMappingColumns.DefaultConfiguration().SourceColumnMappings,
        defaultFormat = AtmStaffMappingColumns.DefaultConfiguration().BulkFileFormat,
        defaultDelimiter = AtmStaffMappingColumns.DefaultConfiguration().BulkFileDelimiter
    };

    [HttpGet("sample")]
    public async Task<IActionResult> Sample(CancellationToken ct)
    {
        Require(User.ToCurrentUser(), CatsPermissions.AtmUpload, "ATM upload permission is required.");
        var view = await AtmStaffMappingStore.LoadConfigurationAsync(db, ct);
        var entries = view.SourceColumnMappings.OrderBy(x => x.Order > 0 ? x.Order : int.MaxValue).ToList();
        var sample = TabularFileReader.BuildSample(view,
            entries.Select(x => string.IsNullOrWhiteSpace(x.SourceColumn) ? x.Field : x.SourceColumn).ToList(),
            entries.Select(x => SampleValue(x.Field)).ToList());
        return File(sample.Content, sample.ContentType, $"ATM_Staff_Mapping_sample{sample.Extension}");
    }

    private static string SampleValue(string field)
    {
        var column = AtmStaffMappingColumns.Find(field);
        if (field == AtmStaffMappingColumns.KeyColumn) return "ATM0001";
        if (field.Contains("EMPCode", StringComparison.OrdinalIgnoreCase)) return "E1001";
        if (field == "STATE") return "Maharashtra";
        if (field == "Penalty_Month") return "01";
        if (field == "Penalty_Year") return DateTime.UtcNow.Year.ToString(CultureInfo.InvariantCulture);
        return column?.Kind == AtmColumnKind.DateTime ? DateTime.UtcNow.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : "Sample"[..Math.Min(6, column?.MaxLength ?? 6)];
    }

    [HttpPost("uploads")]
    [RequestSizeLimit(30_000_000)]
    public async Task<IActionResult> Upload([FromForm] IFormFile file, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        Require(user, CatsPermissions.AtmUpload, "ATM upload permission is required.");
        if (file is null || file.Length is <= 0 or > 30_000_000) return BadRequest(new { message = "File size must be between 1 byte and 30 MB." });
        var fileName = Path.GetFileName(file.FileName);
        if (fileName.Length > 250) return BadRequest(new { message = "File names cannot exceed 250 characters." });
        var view = await AtmStaffMappingStore.LoadConfigurationAsync(db, ct);
        List<Dictionary<string, string>> rows;
        try
        {
            rows = TabularFileReader.Read(file.OpenReadStream(), fileName, view);
            if (rows.Count is 0 or > AtmStaffMappingStore.MaxRows)
                return BadRequest(new { message = $"The file must contain between 1 and {AtmStaffMappingStore.MaxRows:N0} data rows." });
            rows = AtmStaffMappingStore.NormalizeRows(rows, view);
            AtmStaffMappingStore.ValidateRows(rows);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
        var id = await CreateBatchAsync(user, fileName, rows, ct);
        return Ok(new { id, fileName, rowCount = rows.Count, status = "Pending" });
    }

    /// <summary>Single entry: one ATM's staff mapping, sent for the same checker approval as a file.</summary>
    [HttpPost("entries")]
    public async Task<IActionResult> Entry(StaffMappingEntryRequest request, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        Require(user, CatsPermissions.AtmUpload, "ATM upload permission is required.");
        var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var (key, value) in request.Values ?? [])
        {
            var column = AtmStaffMappingColumns.Find(key);
            if (column is null || AtmStaffMappingColumns.IsSystemColumn(column.Name))
                return BadRequest(new { message = $"'{key}' cannot be entered here." });
            row[column.Name] = (value ?? "").Trim();
        }
        try
        {
            AtmStaffMappingStore.ValidateRows([row]);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message.Replace(" (row 2)", "") });
        }
        var name = $"Single entry - {row[AtmStaffMappingColumns.KeyColumn]}";
        var id = await CreateBatchAsync(user, name[..Math.Min(name.Length, 250)], [row], ct);
        return Ok(new { id, fileName = name, rowCount = 1, status = "Pending" });
    }

    [HttpGet("records")]
    public async Task<IActionResult> Records([FromQuery] string? search, [FromQuery] int page = 1, [FromQuery] int pageSize = 50, CancellationToken ct = default)
    {
        Require(User.ToCurrentUser(), CatsPermissions.AtmMasterView, "ATM master view permission is required.");
        page = Math.Clamp(page, 1, 100_000);
        pageSize = Math.Clamp(pageSize, 1, 200);
        var searchable = AtmStaffMappingColumns.All
            .Where(x => x.Name is "ATM_ID" or "STATE" || x.Name.Contains("EMPCode", StringComparison.OrdinalIgnoreCase)).Select(x => x.Name).ToList();
        var args = new List<DbArg>();
        var where = "";
        if (!string.IsNullOrWhiteSpace(search))
        {
            args.Add(new("Search", "%" + search.Trim().ToUpperInvariant() + "%"));
            where = " WHERE " + string.Join(" OR ", searchable.Select(x => $"UPPER({x}) LIKE {db.Dialect.P("Search")}"));
        }
        var total = await db.ScalarAsync<int>($"SELECT COUNT(1) FROM {AtmStaffMappingColumns.Table}{where}", args, ct);
        var columns = string.Join(",", AtmStaffMappingColumns.All.Select(x => x.Name));
        var sql = db.Dialect.ApplyPagination($"SELECT {columns} FROM {AtmStaffMappingColumns.Table}{where} ORDER BY {AtmStaffMappingColumns.KeyColumn}", page, pageSize);
        var rows = await db.QueryAsync(sql, ReadRecord, args, ct);
        return Ok(new { total, page, pageSize, rows });
    }

    [HttpGet("records/{atmId}")]
    public async Task<IActionResult> Record(string atmId, CancellationToken ct)
    {
        Require(User.ToCurrentUser(), CatsPermissions.AtmMasterView, "ATM master view permission is required.");
        var columns = string.Join(",", AtmStaffMappingColumns.All.Select(x => x.Name));
        var row = await db.QuerySingleAsync(
            $"SELECT {columns} FROM {AtmStaffMappingColumns.Table} WHERE {AtmStaffMappingColumns.KeyColumn}={db.Dialect.P("Id")}", ReadRecord, [new("Id", atmId.Trim())], ct);
        return row is null ? NotFound(new { message = $"No Staff Mapping exists for ATM '{atmId}'." }) : Ok(row);
    }

    private static Dictionary<string, string> ReadRecord(System.Data.Common.DbDataReader r) =>
        AtmStaffMappingColumns.All.ToDictionary(
            x => x.Name,
            x => r[x.Name] is DBNull ? "" : r[x.Name] is DateTime date ? date.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) : Convert.ToString(r[x.Name], CultureInfo.InvariantCulture) ?? "");

    /// <summary>
    /// The people who can approve or reject Staff Mapping: active users holding ATM.CHECK through their role or a direct user permission.
    /// Shown to makers and checkers so the checker assignment can be confirmed.
    /// </summary>
    [HttpGet("checkers")]
    public async Task<IActionResult> Checkers(CancellationToken ct)
    {
        Require(User.ToCurrentUser(), CatsPermissions.AtmMasterView, "ATM master view permission is required.");
        var checkers = await db.QueryAsync(
            $@"SELECT u.UserName,u.DisplayName,u.RoleCode FROM CatsUsers u WHERE u.IsActive=1 AND (
                 EXISTS(SELECT 1 FROM RolePermissionMapping r WHERE r.RoleCode=u.RoleCode AND r.PermissionCode={db.Dialect.P("Permission")} AND r.IsActive=1)
                 OR EXISTS(SELECT 1 FROM UserPermissionMapping m WHERE m.UserId=u.Id AND m.PermissionCode={db.Dialect.P("UserPermission")} AND m.IsActive=1))
               ORDER BY u.UserName",
            r => new { userName = r.Str("UserName"), displayName = r.Str("DisplayName"), roleCode = r.Str("RoleCode") },
            [new("Permission", CatsPermissions.AtmCheck), new("UserPermission", CatsPermissions.AtmCheck)], ct);
        return Ok(checkers);
    }

    /// <summary>Upload logs: every Staff Mapping batch with its maker, checker, decision and remarks.</summary>
    [HttpGet("batches")]
    public async Task<IActionResult> Batches([FromQuery] int page = 1, [FromQuery] int pageSize = 50, CancellationToken ct = default)
    {
        Require(User.ToCurrentUser(), CatsPermissions.AtmMasterView, "ATM master view permission is required.");
        page = Math.Clamp(page, 1, 100_000);
        pageSize = Math.Clamp(pageSize, 1, 200);
        var sql = db.Dialect.ApplyPagination(
            $"SELECT Id,FileName,Status,UploadedBy,UploadedAtUtc,DecidedBy,DecidedAtUtc,DecisionRemarks FROM ATM_UploadBatches WHERE FileType={db.Dialect.P("Type")} ORDER BY UploadedAtUtc DESC", page, pageSize);
        var rows = await db.QueryAsync(sql, r => new
        {
            id = r.Lng("Id"), fileName = r.Str("FileName"), status = r.Str("Status"), uploadedBy = r.Str("UploadedBy"),
            uploadedAtUtc = r.Dt("UploadedAtUtc"), decidedBy = r.NStr("DecidedBy"), decidedAtUtc = r.NDt("DecidedAtUtc"), decisionRemarks = r.NStr("DecisionRemarks")
        }, [new("Type", AtmStaffMappingColumns.BatchFileType)], ct);
        return Ok(rows);
    }

    /// <summary>The rows of one batch, so the checker can review what they are approving.</summary>
    [HttpGet("batches/{id:long}/rows")]
    public async Task<IActionResult> BatchRows(long id, CancellationToken ct)
    {
        Require(User.ToCurrentUser(), CatsPermissions.AtmMasterView, "ATM master view permission is required.");
        var batch = await db.QuerySingleAsync(
            $"SELECT FileName,RowsJson,Status FROM ATM_UploadBatches WHERE Id={db.Dialect.P("Id")} AND FileType={db.Dialect.P("Type")}",
            r => new { fileName = r.Str("FileName"), rowsJson = r.Str("RowsJson"), status = r.Str("Status") },
            [new("Id", id), new("Type", AtmStaffMappingColumns.BatchFileType)], ct);
        if (batch is null) return NotFound(new { message = "Staff Mapping batch was not found." });
        var rows = JsonSerializer.Deserialize<List<Dictionary<string, string>>>(protector.Unprotect(batch.rowsJson), JsonDefaults.Options) ?? [];
        var columns = rows.SelectMany(x => x.Keys).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        return Ok(new { batch.fileName, batch.status, total = rows.Count, columns, rows = rows.Take(PreviewRows) });
    }

    private async Task<long> CreateBatchAsync(CurrentUser user, string fileName, List<Dictionary<string, string>> rows, CancellationToken ct)
    {
        var id = CatsId.Next();
        await db.ExecuteAsync(
            $"INSERT INTO ATM_UploadBatches(Id,FileType,FileName,RowsJson,Status,UploadedBy,UploadedAtUtc) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Type")},{db.Dialect.P("Name")},{db.Dialect.P("Rows")},'Pending',{db.Dialect.P("User")},{db.Dialect.P("Now")})",
            [new("Id", id), new("Type", AtmStaffMappingColumns.BatchFileType), new("Name", fileName),
             new("Rows", protector.Protect(JsonSerializer.Serialize(rows, JsonDefaults.Options))), new("User", user.UserName), new("Now", DateTime.UtcNow)], ct);
        await AuditAsync(user, "ATM_FILE_UPLOAD", "ATMUploadBatch", id.ToString(), $"Staff Mapping uploaded for checker approval ({rows.Count} row(s)).", ct);
        return id;
    }

    private Task AuditAsync(CurrentUser user, string action, string entityType, string entityId, string remarks, CancellationToken ct) =>
        repo.InsertAuditAsync(new AuditRecord
        {
            Id = CatsId.Next(), UserId = user.Id, UserName = user.UserName, RoleCode = user.RoleCode,
            Action = action, EntityType = entityType, EntityId = entityId,
            NewValueJson = JsonSerializer.Serialize(new { fileType = AtmStaffMappingColumns.BatchFileType, remarks }, JsonDefaults.Options),
            Remarks = remarks, IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), CreatedAtUtc = DateTime.UtcNow
        }, ct);

    private static void Require(CurrentUser user, string permission, string message)
    {
        if (!user.HasPermission(permission)) throw new UnauthorizedAccessException(message);
    }
}

public sealed class StaffMappingConfigurationRequest
{
    public string? Format { get; set; }
    public string? Delimiter { get; set; }
    public List<StaffMappingColumnRequest>? Mappings { get; set; }
}

public sealed class StaffMappingColumnRequest
{
    public string Field { get; set; } = "";
    public string SourceColumn { get; set; } = "";
    public bool Required { get; set; }
    public int Order { get; set; }
}

public sealed class StaffMappingEntryRequest
{
    public Dictionary<string, string?>? Values { get; set; }
}
