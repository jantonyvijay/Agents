using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;
using CATS.Workflow;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

[Authorize]
[ApiController]
[Route("api/templates")]
public sealed class TemplatesController(ICatsRepository repo,MafWorkflowGraphService maf,AdoHelper? db=null,AlertTypeAccessService? access=null,AlertListColumnService? listColumns=null,TemplateDataTableService? dataTables=null) : ControllerBase
{
    // The mappable ATM table columns depend on the database provider; tests construct the controller without a database.
    private string atmProvider=>db?.Dialect.Name??"SqlServer";

    /// <summary>Alert Types the signed-in user may pick: restricted by role and permission (AlertTypeAccess); template managers see all.</summary>
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        var templates=await repo.GetTemplatesAsync(ct);
        return Ok(access==null?templates:await access.FilterAsync(templates,User.ToCurrentUser(),ct));
    }

    /// <summary>Alerts-table columns that Alert List Configuration (and the Alerts grid) can use; maintained in AlertListColumnMaster.</summary>
    [HttpGet("alert-columns")]
    public async Task<IActionResult> AlertColumns(CancellationToken ct)
    {
        var columns=listColumns is null?[]:await listColumns.GetActiveAsync(ct);
        return Ok(columns.Select(x=>new{code=x.Code,label=x.Label,filterable=x.CanSearch,controlType=x.ControlType,optionsJson=x.OptionsJson,
            valueFormat=x.ValueFormat,excludedTemplateCodes=x.ExcludedTemplateCodes}));
    }

    /// <summary>Table columns an ATM Bulk File Upload mapping can use, with the default mapping, for Template Designer's column picker.</summary>
    [HttpGet("source-columns/{code}")]
    public IActionResult SourceColumns(string code)
    {
        Require(User.ToCurrentUser(),CatsPermissions.TemplateManage);
        if(!AtmSourceColumns.IsAtmTemplate(code))return Ok(new{columns=Array.Empty<object>(),defaults=Array.Empty<object>()});
        var columns=AtmTableColumns.For(code,atmProvider).Select(x=>new{name=x.Name,kind=x.Kind.ToString(),maxLength=x.MaxLength==int.MaxValue?0:x.MaxLength});
        return Ok(new{columns,defaults=AtmSourceColumns.TemplateMappings(code),requiredFields=new[]{"ATM_ID",AtmSourceColumns.PenaltyField(code)}});
    }

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id,CancellationToken ct)
    {
        var t=await repo.GetTemplateAsync(id,ct); return t==null?NotFound():Ok(t);
    }

    /// <summary>The data table that Generate / Update would create or change for this template, and what it already contains.</summary>
    [HttpGet("{id:long}/data-table")]
    public async Task<IActionResult> DataTableStatus(long id,CancellationToken ct)
    {
        Require(User.ToCurrentUser(),CatsPermissions.TemplateManage);
        if(dataTables is null)return NotFound();
        var template=await repo.GetTemplateAsync(id,ct);
        return template is null?NotFound():Ok(await dataTables.PlanAsync(template,ct));
    }

    public sealed record GenerateDataTableRequest(string? TableName,Dictionary<string,string>? ColumnTypes);

    /// <summary>Creates the template's data table on first use, or adds the columns for new fields later. Existing columns are never dropped.</summary>
    [HttpPost("{id:long}/data-table")]
    public async Task<IActionResult> GenerateDataTable(long id,GenerateDataTableRequest? request,CancellationToken ct)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.TemplateManage);
        if(dataTables is null)return NotFound();
        var template=await repo.GetTemplateAsync(id,ct);
        if(template is null)return NotFound();
        if(template.Status==TemplateStatus.Retired)return Conflict("Retired templates cannot be modified.");
        var plan=await dataTables.EnsureAsync(template,request?.TableName,u.UserName,request?.ColumnTypes,ct);
        await repo.InsertAuditAsync(Audit(u,"TEMPLATE_DATATABLE_UPDATE","Template",id,null,JsonSerializer.Serialize(new{plan.TableName,plan.ExistingColumns.Count,plan.AlertsToCopy})),ct);
        return Ok(plan);
    }

    [HttpGet("{id:long}/audit")]
    public async Task<IActionResult> AuditHistory(long id,[FromQuery]int page=1,CancellationToken ct=default)
    {
        var user=User.ToCurrentUser();
        if(!user.HasPermission(CatsPermissions.TemplateManage) && !user.HasPermission(CatsPermissions.WorkflowManage))
            throw new UnauthorizedAccessException("Template or workflow management permission is required.");
        if(await repo.GetTemplateAsync(id,ct)==null)return NotFound();
        if(page<1 || page>100000)return BadRequest("Invalid audit page.");
        var records=await repo.GetTemplateAuditAsync(id,page,25,ct);
        return Ok(new{page,hasMore=records.Count==25,items=records.Select(a=>new{
            a.Id,a.Action,a.EntityType,a.UserName,a.RoleCode,a.CreatedAtUtc,a.Remarks,
            details=ConfigurationAuditDetails.Compare(a.PreviousValueJson,a.NewValueJson)
        })});
    }

    [HttpPost]
    public async Task<IActionResult> Save(SaveTemplateRequest request,CancellationToken ct)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.TemplateManage);
        if(request.Id==0) request.Id=null;
        request.Code=request.Code.Trim(); request.Name=request.Name.Trim();
        if(string.IsNullOrWhiteSpace(request.Code)||string.IsNullOrWhiteSpace(request.Name))return BadRequest("Template code and name are required.");
        if(request.Sections.Any(x=>string.IsNullOrWhiteSpace(x.Id)||string.IsNullOrWhiteSpace(x.Name)))return BadRequest("Every section requires an ID and name.");
        if(request.Sections.Any(x=>x.ColumnSpan<2||x.ColumnSpan>12))return BadRequest("Section columns must be between 2 and 12.");
        if(request.Sections.Any(x=>x.PageNumber<1))return BadRequest("Section page must be 1 or greater.");
        if(request.Sections.Select(x=>x.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=request.Sections.Count)return BadRequest("Section IDs must be unique.");
        if(request.Fields.Any(x=>string.IsNullOrWhiteSpace(x.Id)||string.IsNullOrWhiteSpace(x.Name)||string.IsNullOrWhiteSpace(x.Label)))return BadRequest("Every field requires an ID, name and label.");
        if(request.Fields.Select(x=>x.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=request.Fields.Count)return BadRequest("Field names must be unique.");
        var sectionIds=request.Sections.Select(x=>x.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if(request.Fields.Any(x=>!sectionIds.Contains(x.SectionId)))return BadRequest("Every field must belong to an existing section.");
        request.ViewConfiguration ??= new TemplateViewConfiguration();
        var layout=(request.ViewConfiguration.LayoutMode??"Single").Trim();
        if(!new[]{"Auto","Single","Tab","Popup","Accordion","Wizard"}.Contains(layout,StringComparer.OrdinalIgnoreCase))return BadRequest("Layout mode must be Auto, Single, Tab, Popup, Accordion or Wizard.");
        request.ViewConfiguration.LayoutMode=layout;
        var requestedBaseDataModes=request.ViewConfiguration.BaseDataModes??[];
        if(requestedBaseDataModes.Count==0)return BadRequest("Select at least one Base Data option.");
        if(requestedBaseDataModes.Any(x=>!TemplateConfigurationSupport.AllBaseDataModes.Contains(x,StringComparer.OrdinalIgnoreCase)))return BadRequest("Base Data options must be Manual Single Entry, Bulk File Upload, SFTP Location or FC Query.");
        request.ViewConfiguration.BaseDataModes=TemplateConfigurationSupport.AllBaseDataModes.Where(x=>requestedBaseDataModes.Contains(x,StringComparer.OrdinalIgnoreCase)).ToList();
        if(request.Sections.Any(x=>!new[]{"Grid","List"}.Contains(x.DataViewMode??"Grid",StringComparer.OrdinalIgnoreCase)))return BadRequest("Section data view must be Grid or List.");
        foreach(var field in request.Fields)
        {
            if(field.MinLength.HasValue && field.MinLength<0)return BadRequest($"{field.Label}: Min length cannot be negative.");
            if(field.MaxLength.HasValue && field.MaxLength<0)return BadRequest($"{field.Label}: Max length cannot be negative.");
            if(field.MinLength.HasValue && field.MaxLength.HasValue && field.MinLength>field.MaxLength)return BadRequest($"{field.Label}: Min length cannot exceed Max length.");
            if(field.MinValue.HasValue && field.MaxValue.HasValue && field.MinValue>field.MaxValue)return BadRequest($"{field.Label}: Min value cannot exceed Max value.");
            if(string.Equals(field.DataSourceMode,"Api",StringComparison.OrdinalIgnoreCase) && (string.IsNullOrWhiteSpace(field.ApiUrl) || !field.ApiUrl.Trim().StartsWith("/api/",StringComparison.OrdinalIgnoreCase)))return BadRequest($"{field.Label}: API dropdown URL must be a relative /api/... Gateway route.");
            if(!string.IsNullOrWhiteSpace(field.ValidationPattern)){try{_=new System.Text.RegularExpressions.Regex(field.ValidationPattern);}catch{return BadRequest($"{field.Label}: Validation pattern is invalid.");}}
            try{_=JsonSerializer.Deserialize<List<FieldDependencyValidation>>(field.DependencyValidationsJson,JsonDefaults.Options)??[];}catch{return BadRequest($"{field.Label}: Dependency validation JSON is invalid.");}
        }
        TemplateRecord? previous=null;
        if(request.Id.HasValue)
        {
            previous=await repo.GetTemplateAsync(request.Id.Value,ct);
            if(previous==null)return NotFound("The template to update was not found.");
            if(previous.Status==TemplateStatus.Retired)return Conflict("Retired templates cannot be modified.");
            var previousFields=JsonSerializer.Deserialize<List<TemplateField>>(previous.FieldsJson,JsonDefaults.Options)??[];
            if(request.Fields.Count==0 && previousFields.Count>0)
                request.Fields=previousFields;
        }
        var currentFieldNames=request.Fields.Select(field=>field.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var catalogColumns=listColumns is null?[]:await listColumns.GetActiveAsync(ct);
        request.ViewConfiguration.AlertListFields=request.ViewConfiguration.AlertListFields
            .Where(field=>catalogColumns.Any(x=>x.Code.Equals(field.Field,StringComparison.OrdinalIgnoreCase))
                ||currentFieldNames.Contains(field.Field))
            .ToList();
        foreach(var listField in request.ViewConfiguration.AlertListFields)
        {
            // Columns the catalog marks as not searchable (encrypted or derived values) can be shown but never used as a filter.
            if(catalogColumns.FirstOrDefault(x=>x.Code.Equals(listField.Field,StringComparison.OrdinalIgnoreCase)) is {CanSearch:false})
                listField.ShowAsFilter=false;
            var label=(listField.Label??"").Trim();
            listField.Label=label.Length==0?listField.Field:label.Length>100?label[..100]:label;
        }
        var fieldNamesByKey=request.Fields.ToDictionary(field=>field.Name,field=>field.Name,StringComparer.OrdinalIgnoreCase);
        var isAtm=AtmSourceColumns.IsAtmTemplate(request.Code);
        var atmColumns=isAtm?AtmTableColumns.For(request.Code,atmProvider).ToDictionary(x=>x.Name,x=>x.Name,StringComparer.OrdinalIgnoreCase):[];
        var cleanedMappings=new List<SourceColumnMappingConfiguration>();
        foreach(var mapping in request.ViewConfiguration.SourceColumnMappings??[])
        {
            var mode=TemplateConfigurationSupport.AllBaseDataModes.FirstOrDefault(x=>x.Equals((mapping.Mode??"").Trim(),StringComparison.OrdinalIgnoreCase));
            if(mode is null)return BadRequest("Source column mappings must use Manual Single Entry, Bulk File Upload, SFTP Location or FC Query.");
            var column=(mapping.SourceColumn??"").Trim();
            var requestedField=(mapping.Field??"").Trim();
            // ATM Bulk File Upload maps file columns to table columns, so every entry is kept (a mapping row exists only while it is listed)
            // and CATS-managed columns such as ATMID, which are derived from the mapped ones, are dropped.
            var atmBulk=isAtm&&mode=="BulkFileUpload";
            if(atmBulk&&AtmTableColumns.IsInternal(requestedField))continue;
            var resolved=false;
            string fieldName="";
            if(atmBulk)resolved=atmColumns.TryGetValue(requestedField,out fieldName)||fieldNamesByKey.TryGetValue(requestedField,out fieldName);
            else resolved=fieldNamesByKey.TryGetValue(requestedField,out fieldName);
            // Mappings for removed fields are pruned like stale Alert List settings; a blank, optional, unordered mapping means "use the field name".
            var order=Math.Clamp(mapping.Order,0,10_000);
            if(!resolved||(!atmBulk&&column.Length==0&&!mapping.Required&&order==0))continue;
            if(column.Length>SourceColumnMapper.MaxSourceColumnLength)return BadRequest($"{fieldName}: Source column cannot exceed {SourceColumnMapper.MaxSourceColumnLength} characters.");
            // Manual Single Entry reads values from the entry form itself, so it has no separate source column.
            if(mode.Equals("ManualSingle",StringComparison.OrdinalIgnoreCase))continue;
            if(cleanedMappings.Any(x=>x.Mode==mode&&x.Field.Equals(fieldName,StringComparison.OrdinalIgnoreCase)))return BadRequest($"{fieldName} is mapped more than once for {mode}.");
            cleanedMappings.Add(new SourceColumnMappingConfiguration{Mode=mode,Field=fieldName,SourceColumn=column,Required=mapping.Required,Order=order});
        }
        if(isAtm&&request.ViewConfiguration.BaseDataModes.Contains("BulkFileUpload",StringComparer.OrdinalIgnoreCase))
        {
            // Case creation and workflow routing read the ATM ID and the penalty amount from every upload.
            foreach(var essential in new[]{"ATM_ID",AtmSourceColumns.PenaltyField(request.Code)})
                if(!cleanedMappings.Any(x=>x.Mode=="BulkFileUpload"&&x.Field.Equals(essential,StringComparison.OrdinalIgnoreCase)))
                    return BadRequest($"{essential} must stay in the Bulk File Upload Source Column Mapping because ATM cases are created from it.");
        }
        var fieldOrder=request.Fields.Select((field,index)=>(field.Name,index)).ToDictionary(x=>x.Name,x=>x.index,StringComparer.OrdinalIgnoreCase);
        request.ViewConfiguration.SourceColumnMappings=cleanedMappings
            .OrderBy(x=>Array.IndexOf(TemplateConfigurationSupport.AllBaseDataModes,x.Mode))
            .ThenBy(x=>x.Order>0?x.Order:int.MaxValue)
            .ThenBy(x=>fieldOrder.GetValueOrDefault(x.Field,int.MaxValue))
            .ToList();
        if(!TabularFileReader.IsValidFormat(request.ViewConfiguration.BulkFileFormat))return BadRequest("Bulk file format must be Auto, CSV, TXT or Excel.");
        request.ViewConfiguration.BulkFileFormat=TabularFileReader.Normalize(request.ViewConfiguration.BulkFileFormat);
        request.ViewConfiguration.BulkFileDelimiter??="";
        if(!TabularFileReader.IsValidDelimiter(request.ViewConfiguration.BulkFileDelimiter))return BadRequest("The file separator must be a single punctuation character such as , ~ | ; or a tab.");
        if(request.ViewConfiguration.BulkFileFormat=="Excel")request.ViewConfiguration.BulkFileDelimiter="";
        var t=await repo.SaveTemplateAsync(request,u,ct);

        // Never report a successful template save when the database silently dropped
        // a large Fields/ViewConfiguration payload. This was possible when SQL Server
        // JSON_VALUE encountered an escaped JSON string larger than 4,000 characters.
        // The repository now sends nested JSON and the SQL hotfix accepts both formats;
        // this verification is a final safety net for databases that have not yet been upgraded.
        var persistedFields=JsonSerializer.Deserialize<List<TemplateField>>(t.FieldsJson,JsonDefaults.Options)??[];
        if(persistedFields.Count!=request.Fields.Count)
            throw new InvalidOperationException($"Template save verification failed: requested {request.Fields.Count} fields but the database returned {persistedFields.Count}. Apply CATS_V11_TemplateLargeJsonFix_Upgrade.sql and retry.");

        var persistedView=JsonSerializer.Deserialize<TemplateViewConfiguration>(t.ViewConfigurationJson,JsonDefaults.Options)??new();
        if(!string.Equals(persistedView.LayoutMode,request.ViewConfiguration.LayoutMode,StringComparison.OrdinalIgnoreCase)
           || persistedView.BaseDataModes.Count!=request.ViewConfiguration.BaseDataModes.Count)
            throw new InvalidOperationException("Template save verification failed: the View Configuration was not persisted correctly. Apply CATS_V11_TemplateLargeJsonFix_Upgrade.sql and retry.");

        await repo.InsertAuditAsync(Audit(u,previous==null?"TEMPLATE_CREATE":"TEMPLATE_UPDATE","Template",t.Id,previous==null?null:JsonSerializer.Serialize(previous),JsonSerializer.Serialize(t)),ct);
        return Ok(t);
    }

    public sealed record AlertTypeAccessRequest(bool Everyone,List<string>? Roles);

    /// <summary>Which roles may use this Alert Type (open to everyone when none are set).</summary>
    [HttpGet("{id:long}/access")]
    public async Task<IActionResult> GetAccess(long id,CancellationToken ct)
    {
        Require(User.ToCurrentUser(),CatsPermissions.TemplateManage);
        var template=await repo.GetTemplateAsync(id,ct);
        if(template is null)return NotFound();
        if(access is null)return Ok(new{everyone=true,roles=Array.Empty<string>()});
        var current=await access.GetRolesAsync(template.Code,ct);
        return Ok(new{everyone=current.Everyone,roles=current.Roles});
    }

    /// <summary>Limit this Alert Type to the given roles, or open it to everyone.</summary>
    [HttpPut("{id:long}/access")]
    public async Task<IActionResult> SetAccess(long id,AlertTypeAccessRequest request,CancellationToken ct)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.TemplateManage);
        if(access is null)return NotFound();
        var template=await repo.GetTemplateAsync(id,ct);
        if(template is null)return NotFound();
        var roles=(request.Roles??[]).Where(x=>!string.IsNullOrWhiteSpace(x)).Select(x=>x.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if(!request.Everyone && roles.Count==0)return BadRequest("Choose at least one role, or open the Alert Type to everyone.");
        var previous=await access.GetRolesAsync(template.Code,ct);
        await access.SetRolesAsync(template.Code,request.Everyone,roles,ct);
        await repo.InsertAuditAsync(Audit(u,"TEMPLATE_ACCESS_UPDATE","Template",id,
            JsonSerializer.Serialize(new{everyone=previous.Everyone,roles=previous.Roles}),JsonSerializer.Serialize(new{everyone=request.Everyone,roles})),ct);
        return Ok(new{everyone=request.Everyone,roles});
    }

    [HttpPost("{id:long}/retire")]
    public async Task<IActionResult> Retire(long id,CancellationToken ct)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.TemplateManage);
        var previous=await repo.GetTemplateAsync(id,ct);
        if(previous==null)return NotFound();
        if(previous.Status==TemplateStatus.Retired)return Ok(previous);
        await repo.RetireTemplateAsync(id,ct);
        var retired=await repo.GetTemplateAsync(id,ct) ?? throw new InvalidOperationException("The retired template could not be reloaded.");
        await repo.InsertAuditAsync(Audit(u,"TEMPLATE_RETIRE","Template",id,JsonSerializer.Serialize(previous),JsonSerializer.Serialize(retired)),ct);
        return Ok(retired);
    }

    [HttpGet("{templateId:long}/workflow")]
    public async Task<IActionResult> GetWorkflow(long templateId,CancellationToken ct)
    {
        // Open the latest saved version (a draft saved after publishing included), falling back to the published one.
        var w=await LatestWorkflowAsync(templateId,ct) ?? await repo.GetPublishedWorkflowForTemplateAsync(templateId,ct);
        if(w==null)return NotFound(new{message="No workflow has been saved for this Alert Type yet. Add a workflow and save it."});
        return Ok(new{record=w,definition=JsonSerializer.Deserialize<WorkflowDefinitionModel>(w.DefinitionJson, JsonDefaults.Options)});
    }

    private async Task<WorkflowDefinitionRecord?> LatestWorkflowAsync(long templateId,CancellationToken ct)
    {
        if(db is null)return null;
        return await db.QuerySingleAsync(
            db.Dialect.ApplyPagination($"SELECT Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy FROM WorkflowDefinitions WHERE TemplateId={db.Dialect.P("T")} ORDER BY Version DESC",1,1),
            r=>new WorkflowDefinitionRecord{Id=r.Lng("Id"),TemplateId=r.Lng("TemplateId"),Version=r.Int("Version"),Name=r.Str("Name"),DefinitionJson=r.Str("DefinitionJson"),
                IsPublished=r.Bool("IsPublished"),CreatedAtUtc=r.Dt("CreatedAtUtc"),CreatedBy=r.Str("CreatedBy")},
            [new("T",templateId)],ct);
    }

    [HttpPost("workflow")]
    public async Task<IActionResult> SaveWorkflow(SaveWorkflowRequest request,CancellationToken ct)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.WorkflowManage);
        _=maf.BuildGraph(request.Definition);
        var previous=await repo.GetPublishedWorkflowForTemplateAsync(request.TemplateId,ct);
        var w=await repo.SaveWorkflowAsync(request,u,ct);
        var migrated=await repo.MigrateRunningWorkflowInstancesAsync(request.TemplateId,w,request.Definition,ct);
        string Snapshot(WorkflowDefinitionRecord record)=>JsonSerializer.Serialize(new {
            record.Name,Definition=JsonSerializer.Deserialize<JsonElement>(record.DefinitionJson)
        });
        await repo.InsertAuditAsync(Audit(u,request.Publish?"WORKFLOW_PUBLISH":"WORKFLOW_SAVE","WorkflowDefinition",w.Id,
            previous==null?null:Snapshot(previous),Snapshot(w)),ct);
        foreach(var alertId in migrated)
            await repo.InsertAuditAsync(new AuditRecord
            {
                Id=CatsId.Next(),AlertId=alertId,UserId=u.Id,UserName=u.UserName,RoleCode=u.RoleCode,
                Action="WORKFLOW_CONFIGURATION_UPDATED",EntityType="Alert",EntityId=alertId.ToString(),
                NewValueJson=w.DefinitionJson,Remarks=$"Workflow v{w.Version} configuration applied to the active alert.",
                CreatedAtUtc=DateTime.UtcNow
            },ct);
        // Publishing creates or updates the template's own data table, so a new Alert Type needs no manual database work.
        // A problem here must not undo the publish; it is reported next to the result instead.
        object? dataTable=null;
        if(request.Publish && dataTables is not null)
        {
            try
            {
                var published=await repo.GetTemplateAsync(request.TemplateId,ct);
                if(published is not null && (await dataTables.PlanAsync(published,ct)).Supported)
                {
                    var plan=await dataTables.EnsureAsync(published,null,u.UserName,null,ct);
                    await repo.InsertAuditAsync(Audit(u,"TEMPLATE_DATATABLE_UPDATE","Template",published.Id,null,JsonSerializer.Serialize(new{plan.TableName,plan.ExistingColumns.Count})),ct);
                    dataTable=new{status="Ready",table=plan.TableName,columns=plan.ExistingColumns.Count};
                }
            }
            catch(Exception ex){dataTable=new{status="Failed",warning=ex.Message};}
        }
        return Ok(new{id=w.Id,templateId=w.TemplateId,version=w.Version,name=w.Name,definitionJson=w.DefinitionJson,isPublished=w.IsPublished,
            createdAtUtc=w.CreatedAtUtc,createdBy=w.CreatedBy,migratedActiveInstances=migrated.Count,dataTable});
    }

    [HttpPost("workflow/preview")]
    public IActionResult Preview(WorkflowDefinitionModel definition)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.WorkflowManage);
        return Ok(new{mermaid=maf.ToMermaid(definition)});
    }

    private static void Require(CurrentUser u,string p){if(!u.HasPermission(p))throw new UnauthorizedAccessException($"Permission {p} is required.");}
    private static AuditRecord Audit(CurrentUser u,string action,string type,long id,string? previous,string? current)=>new(){Id=CatsId.Next(),UserId=u.Id,UserName=u.UserName,RoleCode=u.RoleCode,Action=action,EntityType=type,EntityId=id.ToString(),PreviousValueJson=previous,NewValueJson=current,CreatedAtUtc=DateTime.UtcNow};
}
