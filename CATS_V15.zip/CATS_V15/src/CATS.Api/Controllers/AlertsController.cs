using System.Text;
using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

[Authorize]
[ApiController]
[Route("api/alerts")]
public sealed class AlertsController(ICatsRepository repo,IPlatformRepository platform,AlertApplicationService service,AtmCaseDataService atmCaseData,IDataProtectorService protector,IPasswordHasher hasher,AlertTypeAccessService? access=null,AlertListColumnService? listColumns=null) : ControllerBase
{
    private Task EnsureAlertTypeAccess(string templateCode,CancellationToken ct)=>access==null?Task.CompletedTask:access.EnsureAsync(templateCode,User.ToCurrentUser(),ct);
    [HttpGet]
    public async Task<IActionResult> List([FromQuery]AlertListFilter filter,CancellationToken ct)
    {
        var recordView=new[]{"MyActionable","ActionedByMe","Closed","All"}
            .FirstOrDefault(value=>value.Equals(filter.RecordView,StringComparison.OrdinalIgnoreCase));
        if(recordView==null)return BadRequest("Invalid records tab.");
        filter.RecordView=recordView;
        // Never trust a client-supplied resolved form; rebuild it from the catalog.
        try{filter.ResolvedSystemFiltersJson=listColumns is null?null:await listColumns.ResolveFiltersAsync(filter.SystemFilters,ct);}
        catch(InvalidOperationException ex){return BadRequest(ex.Message);}
        var user=User.ToCurrentUser();
        if(filter.DashboardId is null)
        {
            var result=await repo.GetAlertsAsync(filter,user,protector.Unprotect,value=>protector.Mask(value),ct);
            var templates=(await repo.GetTemplatesAsync(ct)).ToDictionary(template=>template.Id);
            foreach(var alert in result.Data)
            {
                if(!templates.TryGetValue(alert.TemplateId,out var template)) continue;
                var configuration=JsonSerializer.Deserialize<TemplateViewConfiguration>(template.ViewConfigurationJson,JsonDefaults.Options)??new();
                var fields=JsonSerializer.Deserialize<List<TemplateField>>(template.FieldsJson,JsonDefaults.Options)??[];
                var configured=configuration.AlertListFields.Where(field=>field.ShowInGrid||field.ShowAsFilter).Select(field=>field.Field).ToHashSet(StringComparer.OrdinalIgnoreCase);
                if(configured.Count==0) continue;
                using var dynamicDataDocument=JsonDocument.Parse(string.IsNullOrWhiteSpace(alert.DynamicDataJson)?"{}":alert.DynamicDataJson);
                foreach(var property in dynamicDataDocument.RootElement.EnumerateObject())
                {
                    if(!configured.Contains(property.Name)) continue;
                    var field=fields.FirstOrDefault(item=>string.Equals(item.Name,property.Name,StringComparison.OrdinalIgnoreCase));
                    var value=property.Value.ToString();
                    alert.DynamicFields[property.Name]=field?.Sensitive==true?protector.Mask(value):value;
                }
            }
            return Ok(result);
        }

        if(string.IsNullOrWhiteSpace(filter.DashboardMetricCode))
            return BadRequest("Select a dashboard count before opening the alert list.");

        Dictionary<string,string> groupFilters;
        try{groupFilters=JsonSerializer.Deserialize<Dictionary<string,string>>(filter.DashboardGroupFiltersJson??"{}",JsonDefaults.Options)??new(StringComparer.OrdinalIgnoreCase);}
        catch(JsonException){return BadRequest("Dashboard drill-down filters are invalid.");}
        if(!string.IsNullOrWhiteSpace(filter.BranchCode))groupFilters["BranchCode"]=filter.BranchCode;
        if(!string.IsNullOrWhiteSpace(filter.Status))groupFilters["Status"]=filter.Status;
        var data=await platform.GetTemplateDashboardDataAsync(filter.DashboardId.Value,new TemplateDashboardQuery
        {
            RecordView=filter.RecordView,
            Search=filter.Search??"",
            AlertNo=filter.AlertNo??"",
            AccountId=filter.AccountId??"",
            CustomerId=filter.CustomerId??"",
            GroupFiltersJson=JsonSerializer.Serialize(groupFilters,JsonDefaults.Options),
            MetricCode=filter.DashboardMetricCode??"",
            Page=filter.Page,
            PageSize=filter.PageSize
        },user,protector.Unprotect,value=>protector.Mask(value),ct);
        var templateName=await repo.GetTemplateNameAsync(data.Dashboard.TemplateId,ct);
        var drillDownTemplate=await repo.GetTemplateAsync(data.Dashboard.TemplateId,ct);
        var listConfiguration=drillDownTemplate is null?new TemplateViewConfiguration():
            JsonSerializer.Deserialize<TemplateViewConfiguration>(drillDownTemplate.ViewConfigurationJson,JsonDefaults.Options)??new();
        var configuredFields=listConfiguration.AlertListFields
            .Where(field=>field.ShowInGrid||field.ShowAsFilter)
            .Select(field=>field.Field).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var now=DateTime.UtcNow;
        string Text(Dictionary<string,object?> row,string key)=>Convert.ToString(row.GetValueOrDefault(key))??"";
        int Age(Dictionary<string,object?> row,string key)=>row.GetValueOrDefault(key) is DateTime date?Math.Max(0,(int)(now-date).TotalDays):0;
        return Ok(new PagedResult<AlertListItem>
        {
            Page=data.Page,
            PageSize=data.PageSize,
            TotalRecords=data.TotalRecords,
            Data=data.Rows.Select(row=>new AlertListItem
            {
                Id=Convert.ToInt64(row.GetValueOrDefault("Id")),AlertNo=Text(row,"AlertNo"),TemplateName=templateName,AlertType=Text(row,"AlertType"),
                BranchCode=Text(row,"BranchCode"),CustomerId=Text(row,"CustomerId"),AccountId=Text(row,"AccountId"),
                CurrentStageName=Text(row,"CurrentStageName"),Status=Text(row,"Status"),Priority=Text(row,"Priority"),
                OverallAgingDays=Age(row,"CreatedAtUtc"),StageAgingDays=Age(row,"StageEnteredAtUtc"),
                // Dashboard rows already contain masked dynamic values. Preserve only configured fields.
                DynamicFields=row.Where(item=>configuredFields.Contains(item.Key)&&!item.Key.StartsWith("__",StringComparison.Ordinal))
                    .ToDictionary(item=>item.Key,item=>Convert.ToString(item.Value)??"",StringComparer.OrdinalIgnoreCase)
            }).ToList()
        });
    }

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Detail(long id,CancellationToken ct) => Ok(await service.DetailAsync(id,User.ToCurrentUser(),Ip(),ct));

    [HttpPost("{id:long}/unmask-pi")]
    public async Task<IActionResult> UnmaskPi(long id,UnmaskPiRequest request,CancellationToken ct)
    {
        var current=User.ToCurrentUser();
        if(!current.HasPermission(CatsPermissions.PiUnmask))
            throw new UnauthorizedAccessException("PI unmask permission is required.");
        var field=request.Field.Trim();
        var user=await repo.GetUserByUserNameAsync(current.UserName,ct);
        if(user==null || !user.IsActive || string.IsNullOrEmpty(request.Password) || !hasher.Verify(request.Password,user.PasswordHash))
            return BadRequest(new{message="Password verification failed."});
        var alert=await repo.GetAlertAsync(id,ct) ?? throw new KeyNotFoundException("Alert not found.");
        await service.EnsureViewAsync(alert,current,ct);
        string value;
        if(field.Equals("customerId",StringComparison.OrdinalIgnoreCase)) { field="customerId"; value=protector.Unprotect(alert.CustomerIdEncrypted); }
        else if(field.Equals("accountId",StringComparison.OrdinalIgnoreCase)) { field="accountId"; value=protector.Unprotect(alert.AccountIdEncrypted); }
        else
        {
            var template=await repo.GetTemplateAsync(alert.TemplateId,ct) ?? throw new KeyNotFoundException("Template not found.");
            var fields=JsonSerializer.Deserialize<List<TemplateField>>(template.FieldsJson,JsonDefaults.Options) ?? [];
            var configured=fields.FirstOrDefault(f=>f.Name.Equals(field,StringComparison.OrdinalIgnoreCase));
            if(configured==null || !configured.Sensitive || !configured.AllowUnmask)
                return BadRequest(new{message="PI reveal is not allowed for this field."});
            field=configured.Name;
            using var data=JsonDocument.Parse(string.IsNullOrWhiteSpace(alert.DynamicDataJson)?"{}":alert.DynamicDataJson);
            value=data.RootElement.TryGetProperty(field,out var property)?property.ToString():"";
        }
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id=CatsId.Next(),AlertId=alert.Id,UserId=current.Id,UserName=current.UserName,RoleCode=current.RoleCode,
            Action="PI_UNMASK_VIEW",EntityType="Alert",EntityId=alert.Id.ToString(),StageId=alert.CurrentStageId,
            Remarks=$"{field} revealed after password verification",
            IpAddress=Ip(),CreatedAtUtc=DateTime.UtcNow
        },ct);
        return Ok(new{field,value});
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateAlertRequest request,CancellationToken ct)
    {
        if(request.TemplateId<=0||string.IsNullOrWhiteSpace(request.AlertType))return BadRequest(new{message="Template and Alert Type are required."});
        var template=await repo.GetTemplateAsync(request.TemplateId,ct);
        if(template==null)return BadRequest(new{message="Selected Alert Type was not found."});
        await EnsureAlertTypeAccess(template.Code,ct);
        if(!template.AllowsBaseDataMode("ManualSingle"))return BadRequest(new{message="Manual Single Entry is disabled for this Alert Type."});
        return Ok(await service.CreateAsync(request,User.ToCurrentUser(),Ip(),ct));
    }

    [HttpPost("{id:long}/ai-query-suggestion")]
    public async Task<IActionResult> AiQuerySuggestion(long id,AiQuerySuggestionRequest request,CancellationToken ct)
        => Ok(await service.SuggestQueryAsync(id,request,User.ToCurrentUser(),Ip(),ct));

    [HttpPost("{id:long}/action")]
    public async Task<IActionResult> Action(long id,WorkflowActionRequest request,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(request.Action))return BadRequest(new{message="Action is required."});
        var current=User.ToCurrentUser();
        await service.ApplyActionAsync(id,request,current,Ip(),ct);
        await atmCaseData.SynchronizeAlertDataAsync(id,current,ct);
        return Ok(await service.DetailAsync(id,current,Ip(),ct));
    }

    [HttpPost("upload-csv")]
    [RequestSizeLimit(30_000_000)]
    public async Task<IActionResult> UploadCsv(IFormFile file,[FromForm]long? templateId,CancellationToken ct)
    {
        if(file==null||file.Length==0)return BadRequest(new{message="A file is required."});
        TemplateRecord? selectedTemplate=null; List<TemplateField> selectedFields=[];
        if(templateId.HasValue)
        {
            selectedTemplate=await repo.GetTemplateAsync(templateId.Value,ct);
            if(selectedTemplate==null)return BadRequest(new{message="Selected Alert Type was not found."});
            await EnsureAlertTypeAccess(selectedTemplate.Code,ct);
            if(selectedTemplate.Code.StartsWith("ATM_",StringComparison.OrdinalIgnoreCase))
                return BadRequest(new{message="ATM penalty files are uploaded from New / Upload Alerts with the penalty month and year, and wait for DBOPS Checker approval; this endpoint does not accept them."});
            if(selectedTemplate.Status!=TemplateStatus.Published)return BadRequest(new{message="Selected Alert Type is not published."});
            if(!selectedTemplate.AllowsBaseDataMode("BulkFileUpload"))return BadRequest(new{message="Bulk File Upload is disabled for this Alert Type."});
            selectedFields=JsonSerializer.Deserialize<List<TemplateField>>(selectedTemplate.FieldsJson,JsonDefaults.Options)??[];
        }
        var viewConfiguration=selectedTemplate?.GetViewConfiguration()??new TemplateViewConfiguration();
        List<Dictionary<string,string>> rows;
        try{rows=TabularFileReader.Read(file.OpenReadStream(),file.FileName,viewConfiguration);}
        catch(InvalidOperationException ex){return BadRequest(new{message=ex.Message});}
        var results=new List<object>(); var success=0; var failed=0; var line=1;
        if(selectedTemplate!=null&&rows.Count>0)
        {
            var missingColumns=SourceColumnMapper.MissingRequiredColumns(viewConfiguration,"BulkFileUpload",selectedFields,rows[0].Keys);
            if(missingColumns.Count>0)return BadRequest(new{message=$"The file is missing required column(s): {string.Join(", ",missingColumns)}. Check the Source Column Mapping of the Alert Type or correct the file headers."});
        }
        foreach(var row in rows)
        {
            line++;
            try
            {
                JsonElement data;
                var mappedValues=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
                if(selectedTemplate!=null)
                {
                    mappedValues=SourceColumnMapper.MapRow(viewConfiguration,"BulkFileUpload",selectedFields,row);
                    data=JsonSerializer.SerializeToElement(mappedValues,JsonDefaults.Options);
                }
                else
                {
                    var dj=row.GetValueOrDefault("DataJson","{}"); using var doc=JsonDocument.Parse(string.IsNullOrWhiteSpace(dj)?"{}":dj); data=doc.RootElement.Clone();
                }
                string ConfiguredValue(string name)=>selectedFields.Any(x=>x.Name.Equals(name,StringComparison.OrdinalIgnoreCase))?mappedValues.GetValueOrDefault(name,"")!:row.GetValueOrDefault(name,"")!;
                var req=new CreateAlertRequest{TemplateId=selectedTemplate?.Id??(long.TryParse(row.GetValueOrDefault("TemplateId",""),out var rowTemplateId)?rowTemplateId:0),AlertType=selectedTemplate?.Code??row.GetValueOrDefault("AlertType","")!,BranchCode=ConfiguredValue("BranchCode"),CustomerId=ConfiguredValue("CustomerId"),AccountId=ConfiguredValue("AccountId"),Priority=row.GetValueOrDefault("Priority","Normal")!,Data=data};
                var effectiveTemplate=selectedTemplate??await repo.GetTemplateAsync(req.TemplateId,ct);
                if(effectiveTemplate==null)throw new InvalidOperationException("Selected Alert Type was not found.");
                await EnsureAlertTypeAccess(effectiveTemplate.Code,ct);
                if(effectiveTemplate.Code.StartsWith("ATM_",StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("ATM penalty files are uploaded from New / Upload Alerts with the penalty month and year, and wait for DBOPS Checker approval.");
                if(!effectiveTemplate.AllowsBaseDataMode("BulkFileUpload"))throw new InvalidOperationException("Bulk File Upload is disabled for this Alert Type.");
                var a=await service.CreateAsync(req,User.ToCurrentUser(),Ip(),ct); success++; results.Add(new{line,status="Success",alertNo=a.AlertNo});
            }
            catch(Exception ex){failed++;results.Add(new{line,status="Failed",error=ex.Message});}
        }
        return Ok(new{success,failed,results});
    }

    [HttpGet("sample-csv/{templateId:long}")]
    public async Task<IActionResult> DownloadSampleCsv(long templateId,CancellationToken ct)
    {
        var user=User.ToCurrentUser();
        if(!user.HasPermission(CatsPermissions.AlertUpload))throw new UnauthorizedAccessException("Alert upload permission is required.");
        var template=await repo.GetTemplateAsync(templateId,ct);
        if(template==null)return NotFound(new{message="Alert Type was not found."});
        await EnsureAlertTypeAccess(template.Code,ct);
        if(template.Status!=TemplateStatus.Published)return BadRequest(new{message="Only published Alert Types have upload samples."});
        if(!template.AllowsBaseDataMode("BulkFileUpload"))return BadRequest(new{message="Bulk File Upload is disabled for this Alert Type."});
        var fields=JsonSerializer.Deserialize<List<TemplateField>>(template.FieldsJson,JsonDefaults.Options)??[];
        var view=template.GetViewConfiguration();
        // One column per distinct source header: several display fields may be fed by the same source column.
        var columns=SourceColumnMapper.OrderedFields(view,"BulkFileUpload",fields)
            .Select(field=>(Field:field,Column:SourceColumnMapper.SourceColumnFor(view,"BulkFileUpload",field.Name)))
            .DistinctBy(x=>SourceColumnMapper.Normalize(x.Column)).ToList();
        var headers=columns.Select(x=>x.Column).ToList();
        string Example(TemplateField field)
        {
            if(field.Type.Equals("select",StringComparison.OrdinalIgnoreCase))return (JsonSerializer.Deserialize<List<string>>(field.OptionsJson,JsonDefaults.Options)??[]).FirstOrDefault()??"";
            if(field.Type.Equals("number",StringComparison.OrdinalIgnoreCase))return "0";
            if(field.Type.Equals("date",StringComparison.OrdinalIgnoreCase))return DateTime.UtcNow.ToString("yyyy-MM-dd");
            if(field.Type.Equals("checkbox",StringComparison.OrdinalIgnoreCase))return "false";
            return field.Required?$"Sample {field.Label}":"";
        }
        var examples=columns.Select(x=>Example(x.Field)).ToList();
        var sample=TabularFileReader.BuildSample(view,headers,examples);
        var safeCode=string.Concat(template.Code.Select(c=>char.IsLetterOrDigit(c)||c is '-' or '_'?c:'_'));
        return File(sample.Content,sample.ContentType,$"{safeCode}-sample{sample.Extension}");
    }


    [HttpPost("{id:long}/reassign")]
    public async Task<IActionResult> Reassign(long id,ReassignWorkItemRequest request,CancellationToken ct)
    {
        await service.ReassignAsync(id,request,User.ToCurrentUser(),Ip(),ct);
        return Ok(await service.DetailAsync(id,User.ToCurrentUser(),Ip(),ct));
    }

    [HttpPost("{id:long}/attachments")]
    [RequestSizeLimit(25_000_000)]
    public async Task<IActionResult> UploadAttachment(long id,[FromForm]string stageId,[FromForm]IFormFile file,CancellationToken ct)
        => Ok(await service.UploadAttachmentAsync(id,stageId,file,User.ToCurrentUser(),Ip(),ct));

    [HttpGet("attachments/{attachmentId:long}")]
    public async Task<IActionResult> DownloadAttachment(long attachmentId,CancellationToken ct)
    {
        var x=await service.GetAttachmentForDownloadAsync(attachmentId,User.ToCurrentUser(),Ip(),ct);
        return PhysicalFile(x.Path,x.Record.ContentType,x.Record.FileName,enableRangeProcessing:true);
    }

    private string? Ip()=>HttpContext.Connection.RemoteIpAddress?.ToString();
}
