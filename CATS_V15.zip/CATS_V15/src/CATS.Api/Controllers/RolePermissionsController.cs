using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

/// <summary>Role-wise permission settings for all users. Open to ADMIN and CENTRAL by default (permission SECURITY.ROLEPERMISSIONS), and configurable like any other permission.</summary>
[Authorize]
[ApiController]
[Route("api/admin/role-permissions")]
public sealed class RolePermissionsController(ICatsRepository repo, AdoHelper db) : ControllerBase
{
    public sealed class SaveRolePermissionsRequest
    {
        public List<string> Permissions { get; set; } = [];
    }

    [HttpGet]
    public async Task<IActionResult> Matrix(CancellationToken ct)
    {
        Require();
        var roles = await db.QueryAsync("SELECT Code,Name FROM RoleMaster WHERE IsActive=1 ORDER BY Name",
            r => new { code = r.Str("Code"), name = r.Str("Name") }, ct: ct);
        var permissions = await db.QueryAsync("SELECT Code,Name,Category FROM PermissionMaster WHERE IsActive=1 ORDER BY Category,Code",
            r => new { code = r.Str("Code"), name = r.Str("Name"), category = r.Str("Category") }, ct: ct);
        var grants = (await db.QueryAsync("SELECT RoleCode,PermissionCode FROM RolePermissionMapping WHERE IsActive=1",
                r => (Role: r.Str("RoleCode"), Permission: r.Str("PermissionCode")), ct: ct))
            .GroupBy(x => x.Role, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Select(x => x.Permission).OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList(), StringComparer.OrdinalIgnoreCase);
        var userCounts = (await db.QueryAsync("SELECT RoleCode,COUNT(1) AS Total FROM CatsUsers WHERE IsActive=1 GROUP BY RoleCode",
                r => (Role: r.Str("RoleCode"), Total: r.Int("Total")), ct: ct))
            .ToDictionary(x => x.Role, x => x.Total, StringComparer.OrdinalIgnoreCase);
        return Ok(new
        {
            roles = roles.Select(r => new { r.code, r.name, users = userCounts.GetValueOrDefault(r.code) }),
            menus = MenuCatalog.Defaults.Where(menu => !string.IsNullOrWhiteSpace(menu.ViewKey))
                .Select(menu => new { label = menu.Label, permission = menu.PermissionCode, description = menu.Description }),
            permissions,
            grants,
            locked = RolePermissionRules.AdminLocked.Select(p => new { role = CatsRoles.Admin, permission = p })
        });
    }

    [HttpPut("{roleCode}")]
    public async Task<IActionResult> Save(string roleCode, SaveRolePermissionsRequest request, CancellationToken ct)
    {
        var actor = Require();
        roleCode = roleCode.Trim();
        var roles = await db.QueryAsync("SELECT Code FROM RoleMaster WHERE IsActive=1", r => r.Str("Code"), ct: ct);
        var role = roles.FirstOrDefault(x => x.Equals(roleCode, StringComparison.OrdinalIgnoreCase));
        if (role == null) return NotFound(new { message = "Select an active role from RoleMaster." });

        var requested = request.Permissions.Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var active = await db.QueryAsync("SELECT Code FROM PermissionMaster WHERE IsActive=1", r => r.Str("Code"), ct: ct);
        if (requested.Except(active, StringComparer.OrdinalIgnoreCase).Any())
            return BadRequest(new { message = "Only active permissions from PermissionMaster can be assigned." });
        var missing = RolePermissionRules.MissingRequired(role, actor.RoleCode, requested);
        if (missing.Count > 0)
            return BadRequest(new { message = $"This change would lock you out. Keep: {string.Join(", ", missing)}." });

        var before = await db.QueryAsync($"SELECT PermissionCode FROM RolePermissionMapping WHERE RoleCode={db.Dialect.P("Role")} AND IsActive=1 ORDER BY PermissionCode",
            r => r.Str("PermissionCode"), [new("Role", role)], ct);
        // Rows are switched off rather than deleted, so the startup seed does not give back a permission an administrator took away.
        await db.InTransactionAsync(async tx =>
        {
            await tx.ExecuteAsync($"UPDATE RolePermissionMapping SET IsActive=0 WHERE RoleCode={tx.Dialect.P("Role")}", [new("Role", role)], ct);
            foreach (var permission in requested)
            {
                var updated = await tx.ExecuteAsync(
                    $"UPDATE RolePermissionMapping SET IsActive=1 WHERE RoleCode={tx.Dialect.P("Role")} AND PermissionCode={tx.Dialect.P("Permission")}",
                    [new("Role", role), new("Permission", permission)], ct);
                if (updated == 0)
                    await tx.ExecuteAsync(
                        $"INSERT INTO RolePermissionMapping(RoleCode,PermissionCode,IsActive) VALUES({tx.Dialect.P("Role")},{tx.Dialect.P("Permission")},1)",
                        [new("Role", role), new("Permission", permission)], ct);
            }
            return true;
        }, ct);
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id = CatsId.Next(), UserId = actor.Id, UserName = actor.UserName, RoleCode = actor.RoleCode,
            Action = "ROLE_PERMISSIONS_SAVE", EntityType = "Role", EntityId = role,
            PreviousValueJson = JsonSerializer.Serialize(before), NewValueJson = JsonSerializer.Serialize(requested.OrderBy(x => x, StringComparer.OrdinalIgnoreCase)),
            Remarks = $"Permissions of role {role} changed; users of the role get them at their next sign-in",
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), CreatedAtUtc = DateTime.UtcNow
        }, ct);
        return Ok(new { role, permissions = requested.OrderBy(x => x, StringComparer.OrdinalIgnoreCase) });
    }

    private CurrentUser Require()
    {
        var user = User.ToCurrentUser();
        if (!user.HasPermission(CatsPermissions.RolePermissionsManage))
            throw new UnauthorizedAccessException("Permission to manage role permissions is required.");
        return user;
    }
}
