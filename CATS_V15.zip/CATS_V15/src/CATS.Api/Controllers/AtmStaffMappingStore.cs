using System.Globalization;
using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;

namespace CATS.Api.Controllers;

/// <summary>Reads, validates and applies ATM Staff Mapping rows. Column names only ever come from the <see cref="AtmStaffMappingColumns"/> whitelist.</summary>
internal static class AtmStaffMappingStore
{
    public const int MaxRows = TabularFileReader.MaxRows;

    public static async Task<TemplateViewConfiguration> LoadConfigurationAsync(AdoHelper db, CancellationToken ct)
    {
        var json = await db.QuerySingleAsync(
            $"SELECT SettingJson FROM ATM_MasterSettings WHERE SettingKey={db.Dialect.P("Key")}",
            r => r.Str("SettingJson"), [new("Key", AtmStaffMappingColumns.SettingKey)], ct);
        if (string.IsNullOrWhiteSpace(json)) return AtmStaffMappingColumns.DefaultConfiguration();
        try
        {
            var view = JsonSerializer.Deserialize<TemplateViewConfiguration>(json, JsonDefaults.Options);
            if (view is not null && AtmStaffMappingColumns.Normalize(view) is null) return view;
        }
        catch (JsonException)
        {
            // A damaged saved configuration falls back to the documented layout rather than blocking uploads.
        }
        return AtmStaffMappingColumns.DefaultConfiguration();
    }

    public static async Task SaveConfigurationAsync(AdoHelper db, TemplateViewConfiguration view, string user, CancellationToken ct)
    {
        var json = JsonSerializer.Serialize(new TemplateViewConfiguration
        {
            BulkFileFormat = view.BulkFileFormat, BulkFileDelimiter = view.BulkFileDelimiter, SourceColumnMappings = view.SourceColumnMappings
        }, JsonDefaults.Options);
        var args = new DbArg[] { new("Key", AtmStaffMappingColumns.SettingKey), new("Json", json), new("User", user), new("Now", DateTime.UtcNow) };
        var updated = await db.ExecuteAsync(
            $"UPDATE ATM_MasterSettings SET SettingJson={db.Dialect.P("Json")},UpdatedBy={db.Dialect.P("User")},UpdatedAtUtc={db.Dialect.P("Now")} WHERE SettingKey={db.Dialect.P("Key")}", args, ct);
        if (updated == 0)
            await db.ExecuteAsync(
                $"INSERT INTO ATM_MasterSettings(SettingKey,SettingJson,UpdatedBy,UpdatedAtUtc) VALUES({db.Dialect.P("Key")},{db.Dialect.P("Json")},{db.Dialect.P("User")},{db.Dialect.P("Now")})", args, ct);
    }

    /// <summary>Maps an uploaded file to table-column rows using the configured mapping. Only mapped columns appear in each row.</summary>
    public static List<Dictionary<string, string>> NormalizeRows(IReadOnlyList<Dictionary<string, string>> rows, TemplateViewConfiguration view)
    {
        var headers = rows[0].Keys.Select(SourceColumnMapper.Normalize).ToArray();
        if (headers.Distinct(StringComparer.Ordinal).Count() != headers.Length)
            throw new InvalidOperationException("The file contains duplicate columns after header normalization.");
        var fields = view.SourceColumnMappings.Select(x => new TemplateField { Name = x.Field }).ToList();
        var missing = SourceColumnMapper.MissingRequiredColumns(view, "BulkFileUpload", fields, rows[0].Keys, [AtmStaffMappingColumns.KeyColumn]);
        if (missing.Count > 0)
            throw new InvalidOperationException(
                $"The file is missing required column(s): {string.Join(", ", missing)}. Correct the file headers, or change the column mapping on the Staff Mapping upload page.");
        return rows.Select(source =>
            SourceColumnMapper.MapRow(view, "BulkFileUpload", fields, source)
                .ToDictionary(x => x.Key, x => x.Value.Trim(), StringComparer.OrdinalIgnoreCase)).ToList();
    }

    public static void ValidateRows(IReadOnlyList<Dictionary<string, string>> rows)
    {
        var seen = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        for (var index = 0; index < rows.Count; index++)
        {
            var row = rows[index];
            var line = index + 2;
            var atmId = Value(row, AtmStaffMappingColumns.KeyColumn);
            if (atmId.Length == 0) throw new InvalidOperationException($"ATM_ID is required (row {line}).");
            if (seen.TryGetValue(atmId, out var first))
                throw new InvalidOperationException($"ATM_ID '{atmId}' appears more than once (rows {first} and {line}).");
            seen[atmId] = line;
            foreach (var (key, value) in row)
            {
                var column = AtmStaffMappingColumns.Find(key) ?? throw new InvalidOperationException($"'{key}' is not a column of {AtmStaffMappingColumns.Table}.");
                var text = value?.Trim() ?? "";
                if (text.Length == 0) continue;
                if (column.Kind == AtmColumnKind.DateTime && !DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out _))
                    throw new InvalidOperationException($"{column.Name} must be a valid date (row {line}).");
                if (column.Kind == AtmColumnKind.Text && text.Length > column.MaxLength)
                    throw new InvalidOperationException($"{column.Name} cannot exceed {column.MaxLength} characters (row {line}).");
            }
        }
    }

    /// <summary>
    /// Builds the UPDATE or INSERT for one approved row. Mapped columns are written as supplied (a blank clears the value); system columns
    /// take the file value when present and otherwise the upload and approval details. Parameters are positional.
    /// </summary>
    public static (string Sql, List<DbArg> Args) BuildUpsert(
        IDbDialect dialect, bool insert, IReadOnlyDictionary<string, string> row, string fileName, string uploadedBy, string checker, DateTime now)
    {
        var values = new List<(string Column, object? Value)>();
        foreach (var column in AtmStaffMappingColumns.All)
        {
            if (column.Name == AtmStaffMappingColumns.KeyColumn) continue;
            var supplied = row.Any(x => x.Key.Equals(column.Name, StringComparison.OrdinalIgnoreCase));
            var text = Value(row, column.Name);
            if (supplied && (text.Length > 0 || !AtmStaffMappingColumns.IsSystemColumn(column.Name)))
            {
                values.Add((column.Name, column.Kind == AtmColumnKind.DateTime
                    ? DateTime.Parse(text, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces)
                    : text.Length == 0 ? null : text));
                continue;
            }
            object? fallback = column.Name switch
            {
                "RecordStatus" => "Approved",
                "UploadFileName" => Truncate(fileName, column.MaxLength),
                "CreatedBy" when insert => Truncate(uploadedBy, column.MaxLength),
                "CreatedDate" when insert => now,
                "ModifiedBy" when !insert => Truncate(uploadedBy, column.MaxLength),
                "ModifiedDate" when !insert => now,
                "ApprovedBy" => Truncate(checker, column.MaxLength),
                "ApprovedDate" => now,
                _ => null
            };
            if (fallback is not null) values.Add((column.Name, fallback));
        }
        var args = new List<DbArg>();
        string Param(object? value)
        {
            args.Add(new($"v{args.Count}", value));
            return dialect.P(args[^1].Name);
        }
        var atmId = Value(row, AtmStaffMappingColumns.KeyColumn);
        if (insert)
        {
            var key = Param(atmId);
            var parameters = values.Select(x => Param(x.Value)).ToList();
            return ($"INSERT INTO {AtmStaffMappingColumns.Table}({AtmStaffMappingColumns.KeyColumn},{string.Join(",", values.Select(x => x.Column))}) VALUES({key},{string.Join(",", parameters)})", args);
        }
        var assignments = values.Select(x => $"{x.Column}={Param(x.Value)}").ToList();
        return ($"UPDATE {AtmStaffMappingColumns.Table} SET {string.Join(",", assignments)} WHERE {AtmStaffMappingColumns.KeyColumn}={Param(atmId)}", args);
    }

    /// <summary>Inserts new ATMs and updates existing ones, keyed by ATM_ID. Re-running the same batch is harmless.</summary>
    public static async Task ApplyAsync(
        AdoHelper db, IReadOnlyList<Dictionary<string, string>> rows, string fileName, string uploadedBy, string checker, CancellationToken ct)
    {
        var existing = (await db.QueryAsync($"SELECT {AtmStaffMappingColumns.KeyColumn} FROM {AtmStaffMappingColumns.Table}", r => r.Str(AtmStaffMappingColumns.KeyColumn), ct: ct))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var now = DateTime.UtcNow;
        await db.InTransactionAsync(async tx =>
        {
            foreach (var row in rows)
            {
                var insert = !existing.Contains(Value(row, AtmStaffMappingColumns.KeyColumn));
                var (sql, args) = BuildUpsert(db.Dialect, insert, row, fileName, uploadedBy, checker, now);
                await tx.ExecuteAsync(sql, args, ct);
            }
            return true;
        }, ct);
    }

    /// <summary>The approved mapping for an ATM as column/value pairs, or null when none exists.</summary>
    public static async Task<Dictionary<string, string>?> FindApprovedAsync(AdoHelper db, string atmId, CancellationToken ct)
    {
        var columns = string.Join(",", AtmStaffMappingColumns.All.Select(x => x.Name));
        return (await db.QueryAsync(
            $"SELECT {columns} FROM {AtmStaffMappingColumns.Table} WHERE {AtmStaffMappingColumns.KeyColumn}={db.Dialect.P("Id")} AND RecordStatus='Approved'",
            r => AtmStaffMappingColumns.All.ToDictionary(x => x.Name, x => r.Str(x.Name), StringComparer.OrdinalIgnoreCase),
            [new("Id", atmId)], ct)).FirstOrDefault();
    }

    public static string Value(IReadOnlyDictionary<string, string> row, string key) =>
        row.FirstOrDefault(x => x.Key.Equals(key, StringComparison.OrdinalIgnoreCase)).Value?.Trim() ?? "";

    private static string Truncate(string value, int length) => value.Length <= length ? value : value[..length];
}
