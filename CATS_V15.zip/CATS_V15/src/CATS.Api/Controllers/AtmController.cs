using System.Globalization;
using System.Text.Json;
using System.Text.Json.Nodes;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

[Authorize]
[ApiController]
[Route("api/atm")]
public sealed class AtmController(
    AdoHelper db,
    ICatsRepository repo,
    AlertApplicationService alerts,
    IDataProtectorService protector) : ControllerBase
{
    private static readonly HashSet<string> UploadTypes = new(StringComparer.OrdinalIgnoreCase)
        { "StaffMaster", "OnUs", "OffUs" };

    [HttpGet("uploads")]
    public async Task<IActionResult> Uploads([FromQuery] int page = 1, [FromQuery] int pageSize = 100, [FromQuery] bool mine = false, CancellationToken ct = default)
    {
        var current = User.ToCurrentUser();
        EnsureAtmAccess(current);
        page = Math.Clamp(page, 1, 100_000);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var sql = db.Dialect.ApplyPagination(
            "SELECT Id,FileType,FileName,Status,UploadedBy,UploadedAtUtc,DecidedBy,DecidedAtUtc,DecisionRemarks FROM ATM_UploadBatches" +
            (mine ? $" WHERE UploadedBy={db.Dialect.P("Me")}" : "") + " ORDER BY UploadedAtUtc DESC",
            page, pageSize);
        var rows = await db.QueryAsync(
            sql,
            r => new
            {
                id = r.Lng("Id"), fileType = r.Str("FileType"), fileName = r.Str("FileName"),
                status = r.Str("Status"), uploadedBy = r.Str("UploadedBy"), uploadedAtUtc = r.Dt("UploadedAtUtc"),
                decidedBy = r.NStr("DecidedBy"), decidedAtUtc = r.NDt("DecidedAtUtc"), decisionRemarks = r.NStr("DecisionRemarks")
            }, mine ? [new("Me", current.UserName)] : null, ct);
        return Ok(rows);
    }

    /// <summary>The rows of one upload, so the checker can review what they are approving (first 500).</summary>
    [HttpGet("uploads/{id:long}/rows")]
    public async Task<IActionResult> UploadRows(long id, CancellationToken ct)
    {
        EnsureAtmAccess(User.ToCurrentUser());
        var batch = await db.QuerySingleAsync(
            $"SELECT FileType,FileName,RowsJson,Status FROM ATM_UploadBatches WHERE Id={db.Dialect.P("Id")}",
            r => new { fileType = r.Str("FileType"), fileName = r.Str("FileName"), rowsJson = r.Str("RowsJson"), status = r.Str("Status") },
            [new("Id", id)], ct);
        if (batch is null) return NotFound(new { message = "ATM upload batch was not found." });
        var rows = JsonSerializer.Deserialize<List<Dictionary<string, string>>>(protector.Unprotect(batch.rowsJson), JsonDefaults.Options) ?? [];
        var columns = rows.SelectMany(x => x.Keys).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        return Ok(new { batch.fileType, batch.fileName, batch.status, total = rows.Count, columns, rows = rows.Take(500) });
    }

    /// <summary>Sample OnUs/OffUs file generated from the Alert Type's current mapping, format and separator.</summary>
    [HttpGet("samples/{fileType}")]
    public async Task<IActionResult> Sample(string fileType, CancellationToken ct)
    {
        EnsurePermission(User.ToCurrentUser(), CatsPermissions.AtmUpload, "ATM upload permission is required.");
        var type = new[] { "OnUs", "OffUs" }.FirstOrDefault(x => x.Equals(fileType, StringComparison.OrdinalIgnoreCase));
        if (type is null) return BadRequest(new { message = "Sample files are available for OnUs and OffUs penalty files." });
        var view = await LoadPenaltyConfigurationAsync(type, ct);
        var sample = BuildPenaltySample(type, view);
        return File(sample.Content, sample.ContentType, $"ATM_{type}_sample{sample.Extension}");
    }

    private async Task<TemplateViewConfiguration> LoadPenaltyConfigurationAsync(string type, CancellationToken ct)
    {
        var templateCode = type.Equals("OnUs", StringComparison.OrdinalIgnoreCase) ? "ATM_ONUS" : "ATM_OFFUS";
        var template = (await repo.GetTemplatesAsync(ct))
            .Where(x => x.Code.Equals(templateCode, StringComparison.OrdinalIgnoreCase) && x.Status != TemplateStatus.Retired)
            .OrderByDescending(x => x.Version).FirstOrDefault();
        return template?.GetViewConfiguration() ?? new TemplateViewConfiguration();
    }

    /// <summary>One header per distinct file column, in the administrator's mapping order.</summary>
    internal static (byte[] Content, string ContentType, string Extension) BuildPenaltySample(string type, TemplateViewConfiguration view)
    {
        var templateCode = type.Equals("OnUs", StringComparison.OrdinalIgnoreCase) ? "ATM_ONUS" : "ATM_OFFUS";
        var penaltyField = AtmSourceColumns.PenaltyField(templateCode);
        var columns = AtmSourceColumns.EffectiveBulkMappings(templateCode, view)
            .Select((entry, index) => (Entry: entry, Index: index))
            .OrderBy(x => x.Entry.Order > 0 ? x.Entry.Order : int.MaxValue).ThenBy(x => x.Index)
            .Select(x => (x.Entry.Field, Column: string.IsNullOrWhiteSpace(x.Entry.SourceColumn) ? x.Entry.Field : x.Entry.SourceColumn.Trim()))
            .DistinctBy(x => SourceColumnMapper.Normalize(x.Column))
            .ToList();

        // The documented OnUs and OffUs files are tilde-delimited text; keep that unless the administrator chose a format or separator.
        var sampleView = new TemplateViewConfiguration { BulkFileFormat = view.BulkFileFormat, BulkFileDelimiter = view.BulkFileDelimiter };
        if (string.IsNullOrEmpty(sampleView.BulkFileDelimiter) && TabularFileReader.Normalize(sampleView.BulkFileFormat) != "Excel")
        {
            sampleView.BulkFileDelimiter = "~";
            if (string.IsNullOrEmpty(sampleView.BulkFileFormat)) sampleView.BulkFileFormat = "Txt";
        }
        return TabularFileReader.BuildSample(sampleView, columns.Select(x => x.Column).ToList(), columns.Select(x => SampleValue(templateCode, penaltyField, x.Field)).ToList());
    }

    private static string SampleValue(string templateCode, string penaltyField, string field)
    {
        if (field.Equals("ATM_ID", StringComparison.OrdinalIgnoreCase)) return "ATM0001";
        // OffUs stores the penalty in a text column, but it must still be a valid amount.
        if (field.Equals(penaltyField, StringComparison.OrdinalIgnoreCase)) return "100.00";
        if (field.Equals("Acc_No", StringComparison.OrdinalIgnoreCase)) return "1234567890";
        if (field.Equals("Penalty_Month", StringComparison.OrdinalIgnoreCase)) return "01";
        if (field.Equals("Penalty_Year", StringComparison.OrdinalIgnoreCase)) return DateTime.UtcNow.Year.ToString(CultureInfo.InvariantCulture);
        var column = AtmTableColumns.Find(templateCode, "SqlServer", field);
        return column?.Kind switch
        {
            AtmColumnKind.DateTime => DateTime.UtcNow.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
            AtmColumnKind.Int => "5",
            AtmColumnKind.Decimal => "100.00",
            AtmColumnKind.Bit => "1",
            AtmColumnKind.Text => "Sample"[..Math.Min(6, column.MaxLength)],
            _ => "Sample"
        };
    }

    [HttpPost("uploads")]
    [RequestSizeLimit(30_000_000)]
    public async Task<IActionResult> Upload(
        [FromForm] string fileType,
        [FromForm] IFormFile file,
        [FromForm] string? penaltyMonth,
        [FromForm] int? penaltyYear,
        CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        EnsurePermission(user, CatsPermissions.AtmUpload, "ATM upload permission is required.");
        if (!UploadTypes.Contains(fileType))
            return BadRequest(new { message = "File type must be StaffMaster, OnUs, or OffUs. Staff Mapping is uploaded from Masters › ATM › Staff Mapping." });
        if (file is null || file.Length is <= 0 or > 30_000_000)
            return BadRequest(new { message = "File size must be between 1 byte and 30 MB." });
        if (Path.GetFileName(file.FileName).Length > 260)
            return BadRequest(new { message = "File name cannot exceed 260 characters." });
        if ((fileType.Equals("OnUs", StringComparison.OrdinalIgnoreCase) || fileType.Equals("OffUs", StringComparison.OrdinalIgnoreCase)) &&
            Path.GetFileName(file.FileName).Length > 250)
            return BadRequest(new { message = "OnUs/OffUs file names cannot exceed 250 characters." });

        var normalizedType = UploadTypes.First(x => x.Equals(fileType, StringComparison.OrdinalIgnoreCase));
        // OnUs/OffUs follow the file format, separator and column mapping configured on their Alert Type; masters use CSV/TXT.
        var view = new TemplateViewConfiguration();
        if (normalizedType is "OnUs" or "OffUs")
        {
            view = await LoadPenaltyConfigurationAsync(normalizedType, ct);
            var unavailable = UnavailableMappedColumns(normalizedType, view);
            if (unavailable.Count > 0)
                return BadRequest(new { message = $"The Source Column Mapping maps table column(s) that do not exist in this database: {string.Join(", ", unavailable)}. Remove them in Template Designer." });
        }

        List<Dictionary<string, string>> rows;
        try
        {
            rows = TabularFileReader.Read(file.OpenReadStream(), file.FileName, view);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
        if (rows.Count is 0 or > 20_000)
            return BadRequest(new { message = "The file must contain between 1 and 20,000 data rows." });
        try
        {
            if (normalizedType is "MappingMaster" or "StaffMaster")
                rows = NormalizeMasterRows(normalizedType, rows);
            if (normalizedType is "OnUs" or "OffUs")
            {
                if (!TryParsePenaltyPeriod(penaltyMonth, penaltyYear, out var month, out var year))
                    return BadRequest(new { message = "Penalty month and year are required for OnUs/OffUs uploads. Choose a month from 1 to 12 and a year from 2000 to 2100." });
                rows = NormalizePenaltyRows(normalizedType, rows, month, year, view);
                AtmSourceColumns.ApplyUploadMetadata(rows, Path.GetFileName(file.FileName), user.UserName, DateTime.UtcNow);
            }
            ValidateRows(normalizedType, rows);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
        var id = CatsId.Next();
        var now = DateTime.UtcNow;
        await db.ExecuteAsync(
            $"INSERT INTO ATM_UploadBatches(Id,FileType,FileName,RowsJson,Status,UploadedBy,UploadedAtUtc) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Type")},{db.Dialect.P("Name")},{db.Dialect.P("Rows")},'Pending',{db.Dialect.P("User")},{db.Dialect.P("Now")})",
            [new("Id", id), new("Type", normalizedType), new("Name", Path.GetFileName(file.FileName)),
             new("Rows", protector.Protect(JsonSerializer.Serialize(rows, JsonDefaults.Options))), new("User", user.UserName), new("Now", now)], ct);
        await AuditBatchAsync(user, id, "ATM_FILE_UPLOAD", normalizedType, null, "ATM file uploaded for checker approval.", ct);
        return Ok(new { id, fileType = normalizedType, fileName = Path.GetFileName(file.FileName), rowCount = rows.Count, status = "Pending" });
    }

    [HttpPost("uploads/{id:long}/decision")]
    public async Task<IActionResult> Decide(long id, AtmUploadDecision request, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        EnsurePermission(user, CatsPermissions.AtmCheck, "ATM checker permission is required.");
        var batch = await db.QuerySingleAsync(
            $"SELECT Id,FileType,FileName,RowsJson,Status,UploadedBy FROM ATM_UploadBatches WHERE Id={db.Dialect.P("Id")}",
            r => new UploadBatch(r.Lng("Id"), r.Str("FileType"), r.Str("FileName"), r.Str("RowsJson"), r.Str("Status"), r.Str("UploadedBy")),
            [new("Id", id)], ct);
        if (batch is null) return NotFound(new { message = "ATM upload batch was not found." });
        if (batch.Status != "Pending") return Conflict(new { message = "This ATM upload has already been decided." });
        if (batch.UploadedBy.Equals(user.UserName, StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { message = "The uploader cannot approve or reject their own upload." });
        if (!string.Equals(request.Decision, "Approve", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(request.Decision, "Reject", StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { message = "Decision must be Approve or Reject." });
        if (string.Equals(request.Decision, "Reject", StringComparison.OrdinalIgnoreCase) && string.IsNullOrWhiteSpace(request.Remarks))
            return BadRequest(new { message = "A rejection reason is required." });
        if ((request.Remarks?.Length ?? 0) > 2000)
            return BadRequest(new { message = "Decision remarks cannot exceed 2,000 characters." });

        var claimed = await db.ExecuteAsync(
            $"UPDATE ATM_UploadBatches SET Status='Processing' WHERE Id={db.Dialect.P("Id")} AND Status='Pending'",
            [new("Id", id)], ct);
        if (claimed != 1) return Conflict(new { message = "This ATM upload is already being decided." });
        try
        {
            var rowsJson = protector.Unprotect(batch.RowsJson);
            var rows = JsonSerializer.Deserialize<List<Dictionary<string, string>>>(rowsJson, JsonDefaults.Options) ?? [];
            if (string.Equals(request.Decision, "Approve", StringComparison.OrdinalIgnoreCase))
            {
                if (batch.FileType.Equals(AtmStaffMappingColumns.BatchFileType, StringComparison.OrdinalIgnoreCase))
                    await AtmStaffMappingStore.ApplyAsync(db, rows, batch.FileName, batch.UploadedBy, user.UserName, ct);
                else if (batch.FileType.Equals("MappingMaster", StringComparison.OrdinalIgnoreCase) ||
                    batch.FileType.Equals("StaffMaster", StringComparison.OrdinalIgnoreCase))
                    await ApplyMasterAsync(batch, rows, ct);
                else
                    await CreateCasesAsync(batch, rows, user, ct);
            }

            var decision = string.Equals(request.Decision, "Approve", StringComparison.OrdinalIgnoreCase) ? "Approved" : "Rejected";
            var changed = await db.ExecuteAsync(
                $"UPDATE ATM_UploadBatches SET Status={db.Dialect.P("Status")},DecidedBy={db.Dialect.P("User")},DecidedAtUtc={db.Dialect.P("Now")},DecisionRemarks={db.Dialect.P("Remarks")} WHERE Id={db.Dialect.P("Id")} AND Status='Processing'",
                [new("Status", decision), new("User", user.UserName), new("Now", DateTime.UtcNow),
                 new("Remarks", request.Remarks?.Trim()), new("Id", id)], ct);
            if (changed != 1) throw new InvalidOperationException("ATM upload status changed during decision processing.");
            await AuditBatchAsync(user, id, $"ATM_FILE_{decision.ToUpperInvariant()}", batch.FileType, batch.UploadedBy,
                string.IsNullOrWhiteSpace(request.Remarks) ? $"ATM upload {decision.ToLowerInvariant()}." : request.Remarks.Trim(), ct);
            return Ok(new { id, status = decision });
        }
        catch
        {
            await db.ExecuteAsync(
                $"UPDATE ATM_UploadBatches SET Status='Pending' WHERE Id={db.Dialect.P("Id")} AND Status='Processing'",
                [new("Id", id)], CancellationToken.None);
            throw;
        }
    }

    [HttpGet("masters/{masterType}")]
    public async Task<IActionResult> Master(string masterType, [FromQuery] int page = 1, [FromQuery] int pageSize = 100, CancellationToken ct = default)
    {
        EnsureAtmAccess(User.ToCurrentUser());
        if (!string.Equals(masterType, "MappingMaster", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(masterType, "StaffMaster", StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { message = "Master type must be MappingMaster or StaffMaster." });
        page = Math.Clamp(page, 1, 100_000);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var sql = db.Dialect.ApplyPagination(
            $"SELECT RecordKey,ATMID,SourceBatchId,UpdatedAtUtc FROM ATM_MasterEntries WHERE MasterType={db.Dialect.P("Type")} ORDER BY ATMID,RecordKey",
            page, pageSize);
        var data = await db.QueryAsync(
            sql,
            r => new { recordKey = r.Str("RecordKey"), atmId = r.Str("ATMID"),
                sourceBatchId = r.Lng("SourceBatchId"), updatedAtUtc = r.Dt("UpdatedAtUtc") },
            [new("Type", masterType.Equals("MappingMaster", StringComparison.OrdinalIgnoreCase) ? "MappingMaster" : "StaffMaster")], ct);
        return Ok(data);
    }

    [HttpPost("cases/{alertId:long}/reassign")]
    public async Task<IActionResult> Reassign(long alertId, AtmReassignRequest request, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        EnsurePermission(user, CatsPermissions.AtmCaseManage, "ATM case management permission is required.");
        if (string.IsNullOrWhiteSpace(request.EmployeeId))
            return BadRequest(new { message = "EmployeeId is required." });
        var alert = await repo.GetAlertAsync(alertId, ct) ?? throw new KeyNotFoundException("ATM alert was not found.");
        var atmId = await GetCaseAtmIdAsync(alertId, ct);
        var employeeId = request.EmployeeId.Trim();
        var target = await repo.GetUserByUserNameAsync(employeeId, ct)
            ?? (long.TryParse(employeeId, System.Globalization.NumberStyles.None, System.Globalization.CultureInfo.InvariantCulture, out var employeeUserId)
                ? await repo.GetUserByIdAsync(employeeUserId, ct) : null);
        if (target is null || !target.IsActive) return BadRequest(new { message = "The selected employee is not an active CATS user." });
        var pending = (await repo.GetPendingWorkItemsAsync(alertId, ct))
            .FirstOrDefault(x => x.StageId.Equals(alert.CurrentStageId, StringComparison.OrdinalIgnoreCase));
        if (pending is null) return Conflict(new { message = "Only a case with a pending work item can be reassigned." });
        if (!target.RoleCode.Equals(pending.AssignedRoleCode, StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { message = "The selected employee must belong to the current workflow role." });
        var staffKeyByName = $"{atmId}:{target.UserName}";
        var staffKeyById = $"{atmId}:{target.Id}";
        var eligible = await db.ScalarAsync<int>(
            $"SELECT COUNT(1) FROM ATM_MasterEntries WHERE MasterType='StaffMaster' AND ATMID={db.Dialect.P("ATMID")} AND (RecordKey={db.Dialect.P("NameKey")} OR RecordKey={db.Dialect.P("IdKey")})",
            [new("ATMID", atmId), new("NameKey", staffKeyByName), new("IdKey", staffKeyById)], ct);
        if (eligible == 0) return BadRequest(new { message = "The selected employee is not mapped to this ATMID in the approved ATM Staff Master." });
        await alerts.ReassignAsync(alertId, new ReassignWorkItemRequest
        {
            StageId = pending.StageId, UserId = target.Id, Remarks = request.Remarks
        }, user, HttpContext.Connection.RemoteIpAddress?.ToString(), ct);
        return Ok(new { alertId, assignedTo = target.UserName, stageId = pending.StageId });
    }

    [HttpPost("cases/{alertId:long}/reopen")]
    public async Task<IActionResult> RequestReopen(long alertId, AtmReopenRequest request, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        EnsurePermission(user, CatsPermissions.AtmCaseManage, "ATM case management permission is required.");
        var alert = await repo.GetAlertAsync(alertId, ct) ?? throw new KeyNotFoundException("ATM alert was not found.");
        if (alert.Status != AlertStatus.Closed)
            return Conflict(new { message = "Only closed ATM cases can be reopened." });
        var caseType = await GetCaseTypeAsync(alertId, ct);
        if (caseType is null) return BadRequest(new { message = "The alert is not an OnUs or OffUs ATM case." });
        var pending = await db.ScalarAsync<int>(
            $"SELECT COUNT(1) FROM ATM_ReopenRequests WHERE OriginalAlertId={db.Dialect.P("Alert")} AND Status IN ('Pending','Processing')",
            [new("Alert", alertId)], ct);
        if (pending > 0) return Conflict(new { message = "A reopen request is already awaiting checker decision." });
        var id = CatsId.Next();
        await db.ExecuteAsync(
            $"INSERT INTO ATM_ReopenRequests(Id,OriginalAlertId,RequestBatchId,RequestedBy,RequestedAtUtc,Status) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Alert")},{db.Dialect.P("Batch")},{db.Dialect.P("User")},{db.Dialect.P("Now")},'Pending')",
            [new("Id", id), new("Alert", alertId), new("Batch", id), new("User", user.UserName), new("Now", DateTime.UtcNow)], ct);
        await AuditBatchAsync(user, id, "ATM_REOPEN_REQUEST", caseType, alertId.ToString(CultureInfo.InvariantCulture),
            string.IsNullOrWhiteSpace(request.Remarks) ? "RATC requested case reopening." : request.Remarks.Trim(), ct,
            alertId, "ATMReopenRequest");
        return Ok(new { id, status = "Pending" });
    }

    [HttpGet("reopen-requests")]
    public async Task<IActionResult> ReopenRequests([FromQuery] int page = 1, [FromQuery] int pageSize = 100, CancellationToken ct = default)
    {
        var user = User.ToCurrentUser();
        EnsureAtmAccess(user);
        page = Math.Clamp(page, 1, 100_000);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var sql = db.Dialect.ApplyPagination(
            "SELECT Id,OriginalAlertId,RequestedBy,RequestedAtUtc,Status,DecisionRemarks,NewAlertId FROM ATM_ReopenRequests ORDER BY RequestedAtUtc DESC",
            page, pageSize);
        var rows = await db.QueryAsync(
            sql,
            r => new { id = r.Lng("Id"), originalAlertId = r.Lng("OriginalAlertId"), requestedBy = r.Str("RequestedBy"),
                requestedAtUtc = r.Dt("RequestedAtUtc"), status = r.Str("Status"), decisionRemarks = r.NStr("DecisionRemarks"),
                newAlertId = r.NLng("NewAlertId") }, ct: ct);
        return Ok(rows);
    }

    [HttpPost("reopen-requests/{id:long}/decision")]
    public async Task<IActionResult> DecideReopen(long id, AtmUploadDecision request, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        EnsurePermission(user, CatsPermissions.AtmCheck, "ATM checker permission is required.");
        if (!string.Equals(request.Decision, "Approve", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(request.Decision, "Reject", StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { message = "Decision must be Approve or Reject." });
        if (string.Equals(request.Decision, "Reject", StringComparison.OrdinalIgnoreCase) && string.IsNullOrWhiteSpace(request.Remarks))
            return BadRequest(new { message = "A rejection reason is required." });
        if ((request.Remarks?.Length ?? 0) > 2000)
            return BadRequest(new { message = "Decision remarks cannot exceed 2,000 characters." });
        var requestInfo = await db.QuerySingleAsync(
            $"SELECT OriginalAlertId,RequestedBy,NewAlertId FROM ATM_ReopenRequests WHERE Id={db.Dialect.P("Id")}",
            r => new { alertId = r.Lng("OriginalAlertId"), requestedBy = r.Str("RequestedBy"),
                newAlertId = r.NLng("NewAlertId") }, [new("Id", id)], ct);
        if (requestInfo is null) return NotFound(new { message = "Reopen request was not found." });
        if (requestInfo.requestedBy.Equals(user.UserName, StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { message = "The requester cannot decide their own reopen request." });
        if (string.Equals(request.Decision, "Reject", StringComparison.OrdinalIgnoreCase) &&
            requestInfo.newAlertId.HasValue)
            return Conflict(new { message = "A reopened alert was already created; approve again to complete the interrupted request." });

        var claimed = await db.ExecuteAsync(
            $"UPDATE ATM_ReopenRequests SET Status='Processing' WHERE Id={db.Dialect.P("Id")} AND Status='Pending'",
            [new("Id", id)], ct);
        if (claimed != 1) return Conflict(new { message = "Reopen request was not found or has already been decided." });
        try
        {
            long? newAlertId = null;
            if (string.Equals(request.Decision, "Approve", StringComparison.OrdinalIgnoreCase))
            {
                var reopen = await db.QuerySingleAsync(
                    $"SELECT OriginalAlertId,RequestBatchId,RequestedBy,NewAlertId FROM ATM_ReopenRequests WHERE Id={db.Dialect.P("Id")}",
                    r => new { alertId = r.Lng("OriginalAlertId"), batchId = r.Lng("RequestBatchId"), requestedBy = r.Str("RequestedBy"), newAlertId = r.NLng("NewAlertId") },
                    [new("Id", id)], ct) ?? throw new KeyNotFoundException("ATM reopen request was not found.");
                if (reopen.requestedBy.Equals(user.UserName, StringComparison.OrdinalIgnoreCase))
                    throw new UnauthorizedAccessException("The requester cannot approve their own reopen request.");
                var original = await repo.GetAlertAsync(reopen.alertId, ct) ?? throw new KeyNotFoundException("Original ATM alert was not found.");
                if (original.Status != AlertStatus.Closed) throw new InvalidOperationException("Only closed ATM cases can be reopened.");
                var type = await GetCaseTypeAsync(original.Id, ct) ?? throw new InvalidOperationException("Original alert is not an ATM case.");
                var table = type == "OnUs" ? "tbl_ATM_Txn_Mntr_OnUs" : "tbl_ATM_Txn_Mntr_OFFUs";
                AlertRecord recreated;
                if (!reopen.newAlertId.HasValue)
                {
                    var json = JsonNode.Parse(original.DynamicDataJson) as JsonObject ?? new JsonObject();
                    json.Remove("_assignments");
                    recreated = await alerts.CreateAsync(new CreateAlertRequest
                    {
                        TemplateId = original.TemplateId, AlertType = original.AlertType, BranchCode = original.BranchCode,
                        CustomerId = protector.Unprotect(original.CustomerIdEncrypted),
                        AccountId = protector.Unprotect(original.AccountIdEncrypted),
                        Priority = original.Priority, Data = JsonSerializer.SerializeToElement(json, JsonDefaults.Options)
                    }, user, HttpContext.Connection.RemoteIpAddress?.ToString(), ct, isApprovedBatch: true);
                    await db.ExecuteAsync(
                        $"UPDATE ATM_ReopenRequests SET NewAlertId={db.Dialect.P("NewAlert")} WHERE Id={db.Dialect.P("Id")} AND Status='Processing'",
                        [new("NewAlert", recreated.Id), new("Id", id)], ct);
                }
                else
                {
                    recreated = await repo.GetAlertAsync(reopen.newAlertId.Value, ct)
                        ?? throw new InvalidOperationException("The previously created reopened alert could not be found.");
                }
                var linked = await db.ScalarAsync<int>(
                    $"SELECT COUNT(1) FROM {table} WHERE SourceBatchId={db.Dialect.P("Batch")} AND SourceRowNumber=1",
                    [new("Batch", reopen.batchId)], ct);
                if (linked == 0)
                {
                    var copiedColumns = string.Join(",",
                        new[] { "ATMID", "PenaltyMonth", "PenaltyAmount", "CaseCategory", "SourceDataJson" }
                            .Concat(AtmTableColumns.For(type == "OnUs" ? "ATM_ONUS" : "ATM_OFFUS", db.Dialect.Name).Select(x => x.Name)));
                    await db.ExecuteAsync(
                        $"INSERT INTO {table}(AlertId,{copiedColumns},SourceBatchId,SourceRowNumber,ReopenedFromAlertId) SELECT {db.Dialect.P("NewAlert")},{copiedColumns},{db.Dialect.P("Batch")},1,{db.Dialect.P("Original")} FROM {table} WHERE AlertId={db.Dialect.P("Original")}",
                        [new("NewAlert", recreated.Id), new("Batch", reopen.batchId), new("Original", original.Id)], ct);
                }
                newAlertId = recreated.Id;
            }
            var status = string.Equals(request.Decision, "Approve", StringComparison.OrdinalIgnoreCase) ? "Approved" : "Rejected";
            await db.ExecuteAsync(
                $"UPDATE ATM_ReopenRequests SET Status={db.Dialect.P("Status")},DecidedBy={db.Dialect.P("User")},DecidedAtUtc={db.Dialect.P("Now")},DecisionRemarks={db.Dialect.P("Remarks")},NewAlertId={db.Dialect.P("NewAlert")} WHERE Id={db.Dialect.P("Id")} AND Status='Processing'",
                [new("Status", status), new("User", user.UserName), new("Now", DateTime.UtcNow),
                 new("Remarks", request.Remarks?.Trim()), new("NewAlert", newAlertId), new("Id", id)], ct);
            await AuditBatchAsync(user, id, $"ATM_REOPEN_{status.ToUpperInvariant()}", "ATMCase", newAlertId?.ToString(CultureInfo.InvariantCulture),
                string.IsNullOrWhiteSpace(request.Remarks) ? $"ATM reopen request {status.ToLowerInvariant()}." : request.Remarks.Trim(), ct,
                requestInfo.alertId, "ATMReopenRequest");
            return Ok(new { id, status, newAlertId });
        }
        catch
        {
            await db.ExecuteAsync(
                $"UPDATE ATM_ReopenRequests SET Status='Pending' WHERE Id={db.Dialect.P("Id")} AND Status='Processing'",
                [new("Id", id)], CancellationToken.None);
            throw;
        }
    }

    private async Task ApplyMasterAsync(UploadBatch batch, IReadOnlyList<Dictionary<string, string>> rows, CancellationToken ct)
    {
        var type = batch.FileType;
        var now = DateTime.UtcNow;
        await db.InTransactionAsync(async tx =>
        {
            await tx.ExecuteAsync($"DELETE FROM ATM_MasterEntries WHERE MasterType={db.Dialect.P("Type")}", [new("Type", type)], ct);
            foreach (var row in rows)
            {
                var atmId = Value(row, "ATMID");
                var employeeId = Value(row, "EmployeeId");
                var key = type == "StaffMaster" ? $"{atmId}:{employeeId}" : atmId;
                await tx.ExecuteAsync(
                    $"INSERT INTO ATM_MasterEntries(MasterType,RecordKey,ATMID,DataJson,SourceBatchId,UpdatedAtUtc) VALUES({db.Dialect.P("Type")},{db.Dialect.P("Key")},{db.Dialect.P("ATMID")},{db.Dialect.P("Data")},{db.Dialect.P("Batch")},{db.Dialect.P("Now")})",
                    [new("Type", type), new("Key", key), new("ATMID", atmId),
                     new("Data", protector.Protect(JsonSerializer.Serialize(row, JsonDefaults.Options))), new("Batch", batch.Id), new("Now", now)], ct);
            }
            return true;
        }, ct);
    }

    private async Task CreateCasesAsync(UploadBatch batch, IReadOnlyList<Dictionary<string, string>> rows, CurrentUser checker, CancellationToken ct)
    {
        var isOnUs = batch.FileType.Equals("OnUs", StringComparison.OrdinalIgnoreCase);
        var code = isOnUs ? "ATM_ONUS" : "ATM_OFFUS";
        var template = (await repo.GetTemplatesAsync(ct)).FirstOrDefault(x => x.Code.Equals(code, StringComparison.OrdinalIgnoreCase));
        if (template is null || template.Status != TemplateStatus.Published || template.PublishedWorkflowId is null)
            throw new InvalidOperationException($"Publish the {code} template and workflow before approving ATM penalty uploads.");
        var fields = JsonSerializer.Deserialize<List<TemplateField>>(template.FieldsJson, JsonDefaults.Options) ?? [];
        var mappedAssignments = new Dictionary<string, IReadOnlyDictionary<string, WorkflowAssignment>>(StringComparer.OrdinalIgnoreCase);

        for (var index = 0; index < rows.Count; index++)
        {
            var rowNumber = index + 1;
            var row = rows[index];
            var table = isOnUs ? "tbl_ATM_Txn_Mntr_OnUs" : "tbl_ATM_Txn_Mntr_OFFUs";
            var exists = await db.ScalarAsync<int>(
                $"SELECT COUNT(1) FROM {table} WHERE SourceBatchId={db.Dialect.P("Batch")} AND SourceRowNumber={db.Dialect.P("Row")}",
                [new("Batch", batch.Id), new("Row", rowNumber)], ct);
            if (exists > 0) continue;

            var atmId = Value(row, "ATMID");
            if (!mappedAssignments.TryGetValue(atmId, out var trustedAssignments))
            {
                // The approved Staff Mapping master is authoritative; entries from the earlier Mapping Master upload remain a fallback.
                var mapping = await AtmStaffMappingStore.FindApprovedAsync(db, atmId, ct);
                if (mapping is null)
                {
                    var encryptedMapping = await db.QuerySingleAsync(
                        $"SELECT DataJson FROM ATM_MasterEntries WHERE MasterType='MappingMaster' AND ATMID={db.Dialect.P("ATMID")}",
                        r => r.Str("DataJson"), [new("ATMID", atmId)], ct);
                    if (encryptedMapping is null) throw new InvalidOperationException($"No approved ATM mapping exists for ATMID '{atmId}' (CSV row {rowNumber + 1}). Add it under Masters › ATM › Staff Mapping.");
                    mapping = JsonSerializer.Deserialize<Dictionary<string, string>>(protector.Unprotect(encryptedMapping), JsonDefaults.Options)
                        ?? throw new InvalidOperationException($"Approved ATM mapping for '{atmId}' is invalid.");
                }
                trustedAssignments = await ResolveMappedAssignmentsAsync(mapping, ct);
                mappedAssignments.Add(atmId, trustedAssignments);
            }
            var data = fields.ToDictionary(field => field.Name, field => (object?)Value(row, field.Name), StringComparer.OrdinalIgnoreCase);
            // A file column can share its name with a reviewer dropdown (e.g. EJ_Error: free text in the source file, a fixed list for ATMC).
            // The original text is kept in the case table; the dropdown simply starts empty instead of rejecting the whole upload.
            foreach (var field in fields.Where(x => !x.Required && x.Type.Equals("select", StringComparison.OrdinalIgnoreCase) &&
                         !x.DataSourceMode.Equals("Api", StringComparison.OrdinalIgnoreCase)))
            {
                var options = JsonSerializer.Deserialize<List<string>>(string.IsNullOrWhiteSpace(field.OptionsJson) ? "[]" : field.OptionsJson, JsonDefaults.Options) ?? [];
                if (options.Count > 0 && data[field.Name] is string text && text.Length > 0 && !options.Contains(text, StringComparer.OrdinalIgnoreCase))
                    data[field.Name] = "";
            }
            data["ATMID"] = atmId;
            data["PenaltyMonth"] = Value(row, "PenaltyMonth");
            data["PenaltyAmount"] = Value(row, "PenaltyAmount");
            var alert = await alerts.CreateAsync(new CreateAlertRequest
            {
                TemplateId = template.Id,
                AlertType = code,
                BranchCode = Value(row, "BranchCode") is { Length: > 0 } branch ? branch : "ATM",
                CustomerId = Value(row, "CustomerId") is { Length: > 0 } customerId ? customerId : $"ATM:{atmId}",
                AccountId = Value(row, "AccountId") is { Length: > 0 } accountId ? accountId : $"ATM:{atmId}",
                Priority = "Normal",
                Data = JsonSerializer.SerializeToElement(data, JsonDefaults.Options)
            }, checker, HttpContext.Connection.RemoteIpAddress?.ToString(), ct, trustedAssignments, isApprovedBatch: true);

            var (sql, args) = BuildCaseInsert(
                db.Dialect, table, code, alert.Id, batch.Id, batch.FileName, batch.UploadedBy, batch.FileType, checker.UserName, rowNumber, row);
            await db.ExecuteAsync(sql, args, ct);
        }
    }

    /// <summary>
    /// Builds the typed INSERT for an approved penalty row: the CATS linkage columns plus every table column of the catalog that has a
    /// value. Parameters are positional, so no column name is ever used as a parameter name (Oracle limits identifiers to 30 characters).
    /// </summary>
    internal static (string Sql, List<DbArg> Args) BuildCaseInsert(
        IDbDialect dialect, string table, string templateCode, long alertId, long batchId, string fileName, string uploadedBy,
        string fileType, string checkerName, int rowNumber, Dictionary<string, string> row)
    {
        var columns = new List<string>();
        var args = new List<DbArg>();
        void Add(string column, object? value)
        {
            columns.Add(column);
            args.Add(new($"v{args.Count}", value));
        }
        var atmId = Value(row, "ATMID");
        var category = Value(row, "CaseCategory");
        var amount = decimal.Parse(Value(row, "PenaltyAmount"), NumberStyles.Number, CultureInfo.InvariantCulture);
        Add("AlertId", alertId);
        Add("ATMID", atmId);
        Add("PenaltyMonth", Value(row, "PenaltyMonth"));
        Add("PenaltyAmount", amount);
        Add("CaseCategory", string.IsNullOrWhiteSpace(category) ? null : category);
        Add("SourceBatchId", batchId);
        Add("SourceRowNumber", rowNumber);
        Add("SourceDataJson", JsonSerializer.Serialize(row, JsonDefaults.Options));

        var now = DateTime.UtcNow;
        var isOnUs = templateCode == "ATM_ONUS";
        foreach (var column in AtmTableColumns.For(templateCode, dialect.Name))
        {
            var text = Value(row, column.Name);
            // Values CATS supplies when the file does not map the column.
            if (text.Length == 0)
            {
                switch (column.Name)
                {
                    case "ATM_ID": text = atmId; break;
                    case "UploadFileName": text = fileName; break;
                    case "CreatedBy": text = uploadedBy; break;
                    case "Penalty_Month": text = Value(row, "PenaltyMonth"); break;
                    case "Penalty_Year": text = Value(row, "Penalty_Year"); break;
                    case "Penalty_Rs" when isOnUs: text = amount.ToString(CultureInfo.InvariantCulture); break;
                    case "Customer_Penalty" when !isOnUs: text = amount.ToString(CultureInfo.InvariantCulture); break;
                    case "RecordStatus" when !isOnUs: text = "Approved"; break;
                    case "ApprovedBy" when !isOnUs: text = checkerName; break;
                    case "FileType" when !isOnUs: text = fileType; break;
                }
            }
            object? value = column.Kind switch
            {
                AtmColumnKind.DateTime => ParseOptionalDate(row, column.Name) ?? (column.Name is "CreatedDate" || (column.Name is "ApprovedDate" && !isOnUs) ? now : null),
                AtmColumnKind.Int => ParseOptionalInt(row, column.Name),
                AtmColumnKind.Decimal => ParseOptionalDecimal(row, column.Name),
                AtmColumnKind.Bit => ParseBit(text),
                _ => text.Length == 0 ? null : text.Length > column.MaxLength
                    ? throw new InvalidOperationException($"{column.Name} exceeds its database column length.")
                    : text
            };
            if (value is not null) Add(column.Name, value);
        }
        var sql = $"INSERT INTO {table}({string.Join(",", columns)}) VALUES({string.Join(",", args.Select(a => dialect.P(a.Name)))})";
        return (sql, args);
    }

    private async Task AuditBatchAsync(
        CurrentUser user, long id, string action, string fileType, string? previous, string remarks,
        CancellationToken ct, long? alertId = null, string entityType = "ATMUploadBatch")
    {
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id = CatsId.Next(), AlertId = alertId, UserId = user.Id, UserName = user.UserName, RoleCode = user.RoleCode,
            Action = action, EntityType = entityType, EntityId = id.ToString(CultureInfo.InvariantCulture), PreviousValueJson = previous,
            NewValueJson = JsonSerializer.Serialize(new { fileType, remarks }, JsonDefaults.Options),
            Remarks = remarks, IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), CreatedAtUtc = DateTime.UtcNow
        }, ct);
    }

    /// <summary>Mapped table columns that exist in the SQL Server catalog but not in the configured database provider.</summary>
    private List<string> UnavailableMappedColumns(string type, TemplateViewConfiguration view)
    {
        var templateCode = type.Equals("OnUs", StringComparison.OrdinalIgnoreCase) ? "ATM_ONUS" : "ATM_OFFUS";
        return AtmSourceColumns.EffectiveBulkMappings(templateCode, view)
            .Select(x => x.Field)
            .Where(field => AtmTableColumns.Find(templateCode, "SqlServer", field) is not null && AtmTableColumns.Find(templateCode, db.Dialect.Name, field) is null)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>
    /// Maps an uploaded penalty file to table columns using the Alert Type's editable Bulk File Upload mapping. ATMID, PenaltyAmount
    /// and PenaltyMonth are derived from the mapped ATM ID, penalty and period columns; the period falls back to the upload form.
    /// </summary>
    private static List<Dictionary<string, string>> NormalizePenaltyRows(
        string type,
        IReadOnlyList<Dictionary<string, string>> rows,
        string penaltyMonth,
        string penaltyYear,
        TemplateViewConfiguration view)
    {
        var normalizedHeaders = rows[0].Keys.Select(SourceColumnMapper.Normalize).ToArray();
        if (normalizedHeaders.Distinct(StringComparer.Ordinal).Count() != normalizedHeaders.Length)
            throw new InvalidOperationException("The file contains duplicate columns after header normalization.");

        var templateCode = type.Equals("OnUs", StringComparison.OrdinalIgnoreCase) ? "ATM_ONUS" : "ATM_OFFUS";
        var penaltyField = AtmSourceColumns.PenaltyField(templateCode);
        var entries = AtmSourceColumns.EffectiveBulkMappings(templateCode, view);
        var fields = entries.Select(x => x.Field).Distinct(StringComparer.OrdinalIgnoreCase).Select(name => new TemplateField { Name = name }).ToList();
        var effective = new TemplateViewConfiguration { SourceColumnMappings = entries };

        var missing = SourceColumnMapper.MissingRequiredColumns(effective, "BulkFileUpload", fields, rows[0].Keys, ["ATM_ID", penaltyField]);
        if (missing.Count > 0)
            throw new InvalidOperationException(
                $"The {type} file is missing required column(s): {string.Join(", ", missing)}. Correct the file headers, or update the Source Column Mapping of the {type} alert type in Template Designer.");

        var tableColumns = AtmTableColumns.For(templateCode, "SqlServer");
        return rows.Select((source, index) =>
        {
            // File columns that happen to share a table column's name are only used when the mapping says so.
            var row = new Dictionary<string, string>(
                source.Where(x => !tableColumns.Any(c => c.Name.Equals(x.Key, StringComparison.OrdinalIgnoreCase))), StringComparer.OrdinalIgnoreCase);
            foreach (var (field, value) in SourceColumnMapper.MapRow(effective, "BulkFileUpload", fields, source))
                row[field] = value.Trim();
            row["ATMID"] = Value(row, "ATM_ID");
            row["PenaltyAmount"] = Value(row, penaltyField);
            var month = PeriodValue(row, "Penalty_Month", penaltyMonth, 1, 12, index, "month");
            var year = PeriodValue(row, "Penalty_Year", penaltyYear, 2000, 2100, index, "year");
            row["Penalty_Month"] = month;
            row["Penalty_Year"] = year;
            row["PenaltyMonth"] = month;
            return row;
        }).ToList();
    }

    private static string PeriodValue(Dictionary<string, string> row, string key, string formValue, int min, int max, int index, string label)
    {
        var value = Value(row, key);
        if (value.Length == 0) return formValue;
        if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var number) || number < min || number > max)
            throw new InvalidOperationException($"{key} must be a {label} from {min} to {max} (CSV row {index + 2}).");
        return label == "month" ? number.ToString("D2", CultureInfo.InvariantCulture) : number.ToString(CultureInfo.InvariantCulture);
    }

    private static List<Dictionary<string, string>> NormalizeMasterRows(
        string type,
        IReadOnlyList<Dictionary<string, string>> rows) =>
        rows.Select(source =>
        {
            var row = new Dictionary<string, string>(source, StringComparer.OrdinalIgnoreCase);
            var atmId = source.FirstOrDefault(item => NormalizeHeader(item.Key) == "atmid").Value;
            if (!string.IsNullOrWhiteSpace(atmId)) row["ATMID"] = atmId;
            if (type.Equals("StaffMaster", StringComparison.OrdinalIgnoreCase))
            {
                var employeeId = source.FirstOrDefault(item => NormalizeHeader(item.Key) is "employeeid" or "employeecode" or "empcode").Value;
                if (!string.IsNullOrWhiteSpace(employeeId)) row["EmployeeId"] = employeeId;
            }
            return row;
        }).ToList();

    private static string NormalizeHeader(string header) =>
        new(header.Trim().Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());

    private static bool TryParsePenaltyPeriod(string? month, int? year, out string normalizedMonth, out string normalizedYear)
    {
        normalizedMonth = "";
        normalizedYear = "";
        if (!int.TryParse(month, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsedMonth) ||
            parsedMonth is < 1 or > 12 || year is null or < 2000 or > 2100)
            return false;
        normalizedMonth = parsedMonth.ToString("D2", CultureInfo.InvariantCulture);
        normalizedYear = year.Value.ToString(CultureInfo.InvariantCulture);
        return true;
    }

    private static void ValidateRows(string type, IReadOnlyList<Dictionary<string, string>> rows)
    {
        for (var index = 0; index < rows.Count; index++)
        {
            var row = rows[index];
            if (string.IsNullOrWhiteSpace(Value(row, "ATMID")))
                throw new InvalidOperationException($"ATMID is required (CSV row {index + 2}).");
            if (Value(row, "ATMID").Length > 100)
                throw new InvalidOperationException($"ATMID cannot exceed 100 characters (CSV row {index + 2}).");
            if (type == "StaffMaster" && string.IsNullOrWhiteSpace(Value(row, "EmployeeId")))
                throw new InvalidOperationException($"EmployeeId is required (CSV row {index + 2}).");
            if (type == "StaffMaster" && Value(row, "EmployeeId").Length > 199)
                throw new InvalidOperationException($"EmployeeId cannot exceed 199 characters (CSV row {index + 2}).");
            if (type is "OnUs" or "OffUs")
            {
                if (!decimal.TryParse(Value(row, "PenaltyAmount"), NumberStyles.Number, CultureInfo.InvariantCulture, out var amount) || amount < 0)
                    throw new InvalidOperationException($"Penalty amount must be a non-negative number (CSV row {index + 2}).");
                var templateCode = type.Equals("OnUs", StringComparison.OrdinalIgnoreCase) ? "ATM_ONUS" : "ATM_OFFUS";
                foreach (var column in AtmTableColumns.For(templateCode, "SqlServer"))
                    ValidateColumn(row, column, index);
                if (Value(row, "CaseCategory").Length > 60 || Value(row, "BranchCode").Length > 60)
                    throw new InvalidOperationException($"CaseCategory and BranchCode cannot exceed 60 characters (CSV row {index + 2}).");
                if (Value(row, "CustomerId").Length > 700 || Value(row, "AccountId").Length > 700)
                    throw new InvalidOperationException($"CustomerId and AccountId cannot exceed 700 characters (CSV row {index + 2}).");
            }
        }
    }

    private static void ValidateColumn(IReadOnlyDictionary<string, string> row, AtmTableColumn column, int index)
    {
        var value = Value(row, column.Name);
        if (value.Length == 0) return;
        switch (column.Kind)
        {
            case AtmColumnKind.Decimal: ValidateOptionalDecimal(row, column.Name, index); break;
            case AtmColumnKind.Int: ValidateOptionalInteger(row, column.Name, index); break;
            case AtmColumnKind.DateTime: ValidateOptionalDate(row, column.Name, index); break;
            case AtmColumnKind.Bit:
                if (ParseBit(value) is null) throw new InvalidOperationException($"{column.Name} must be true/false, yes/no or 1/0 (CSV row {index + 2}).");
                break;
            default: ValidateLength(row, column.Name, column.MaxLength, index); break;
        }
    }

    private static bool? ParseBit(string value) => value.Trim().ToLowerInvariant() switch
    {
        "1" or "true" or "yes" or "y" => true,
        "0" or "false" or "no" or "n" => false,
        _ => null
    };

    private static void ValidateOptionalDecimal(IReadOnlyDictionary<string, string> row, string key, int index)
    {
        var value = Value(row, key);
        if (value.Length > 0 && !decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out _))
            throw new InvalidOperationException($"{key} must be a valid number (CSV row {index + 2}).");
    }

    private static void ValidateOptionalInteger(IReadOnlyDictionary<string, string> row, string key, int index)
    {
        var value = Value(row, key);
        if (value.Length > 0 && !int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out _))
            throw new InvalidOperationException($"{key} must be a whole number (CSV row {index + 2}).");
    }

    private static void ValidateOptionalDate(IReadOnlyDictionary<string, string> row, string key, int index)
    {
        var value = Value(row, key);
        if (value.Length > 0 && !DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out _))
            throw new InvalidOperationException($"{key} must be a valid date (CSV row {index + 2}).");
    }

    private static void ValidateLength(IReadOnlyDictionary<string, string> row, string key, int maxLength, int index)
    {
        if (Value(row, key).Length > maxLength)
            throw new InvalidOperationException($"{key} cannot exceed {maxLength} characters (CSV row {index + 2}).");
    }

    private static DateTime? ParseOptionalDate(IReadOnlyDictionary<string, string> row, string key) =>
        DateTime.TryParse(Value(row, key), CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out var value) ? value : null;

    private static int? ParseOptionalInt(IReadOnlyDictionary<string, string> row, string key) =>
        int.TryParse(Value(row, key), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) ? value : null;

    private static decimal? ParseOptionalDecimal(IReadOnlyDictionary<string, string> row, string key) =>
        decimal.TryParse(Value(row, key), NumberStyles.Number, CultureInfo.InvariantCulture, out var value) ? value : null;

    private static string Value(IReadOnlyDictionary<string, string> row, string key) =>
        row.FirstOrDefault(x => x.Key.Equals(key, StringComparison.OrdinalIgnoreCase)).Value?.Trim() ?? "";

    private async Task<string> GetCaseAtmIdAsync(long alertId, CancellationToken ct)
    {
        var type = await GetCaseTypeAsync(alertId, ct) ?? throw new BadHttpRequestException("The alert is not an ATM case.");
        var table = type == "OnUs" ? "tbl_ATM_Txn_Mntr_OnUs" : "tbl_ATM_Txn_Mntr_OFFUs";
        return await db.ScalarAsync<string>(
            $"SELECT ATMID FROM {table} WHERE AlertId={db.Dialect.P("Alert")}", [new("Alert", alertId)], ct)
            ?? throw new KeyNotFoundException("ATM case details were not found.");
    }

    private async Task<string?> GetCaseTypeAsync(long alertId, CancellationToken ct)
    {
        var onUs = await db.ScalarAsync<int>(
            $"SELECT COUNT(1) FROM tbl_ATM_Txn_Mntr_OnUs WHERE AlertId={db.Dialect.P("Alert")}", [new("Alert", alertId)], ct);
        if (onUs > 0) return "OnUs";
        var offUs = await db.ScalarAsync<int>(
            $"SELECT COUNT(1) FROM tbl_ATM_Txn_Mntr_OFFUs WHERE AlertId={db.Dialect.P("Alert")}", [new("Alert", alertId)], ct);
        return offUs > 0 ? "OffUs" : null;
    }

    private async Task<IReadOnlyDictionary<string, WorkflowAssignment>> ResolveMappedAssignmentsAsync(
        IReadOnlyDictionary<string, string> mapping,
        CancellationToken ct)
    {
        var assignments = new Dictionary<string, WorkflowAssignment>(StringComparer.OrdinalIgnoreCase);
        var stageMappings = new (string StageId, string RoleCode, string[] Keys)[]
        {
            ("atmc", "ATMC", ["ATMC_EMPCode", "ATMC_EMPCode_BK", "ATMCUserId", "ATMCEmployeeId"]),
            ("ratc", "RATC", ["RATC_EMPCode", "RATC_EMPCode_BK", "RATCUserId", "RATCEmployeeId"]),
            ("sh", "SH", ["SH_EMPCode", "SHUserId", "SHEmployeeId"]),
            ("rh", "RH", ["RH_EMPCode", "WBO_RH_EMPCode", "RH_EMPCode_BK", "RHUserId", "RHEmployeeId"]),
            ("gh", "GH", ["GH_EMPCode", "GH_EMPCode_BK", "GHUserId", "GHEmployeeId"])
        };
        foreach (var (stageId, roleCode, keys) in stageMappings)
        {
            var employee = keys.Select(key => mapping.FirstOrDefault(pair => pair.Key.Equals(key, StringComparison.OrdinalIgnoreCase)).Value)
                .FirstOrDefault(value => !string.IsNullOrWhiteSpace(value))?.Trim();
            if (string.IsNullOrWhiteSpace(employee)) continue;
            var target = await repo.GetUserByUserNameAsync(employee, ct)
                ?? (long.TryParse(employee, NumberStyles.None, CultureInfo.InvariantCulture, out var employeeUserId)
                    ? await repo.GetUserByIdAsync(employeeUserId, ct) : null);
            if (target is null || !target.IsActive || !target.RoleCode.Equals(roleCode, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException($"ATM mapping target '{employee}' must be an active CATS user with role {roleCode}.");
            assignments[stageId] = new WorkflowAssignment { RoleCode = roleCode, UserId = target.Id };
        }
        return assignments;
    }

    private static void EnsurePermission(CurrentUser user, string permission, string message)
    {
        if (!user.HasPermission(permission))
            throw new UnauthorizedAccessException(message);
    }

    private static void EnsureAtmAccess(CurrentUser user)
    {
        EnsurePermission(user, CatsPermissions.AtmOperations, "ATM operations permission is required.");
    }

    private sealed record UploadBatch(long Id, string FileType, string FileName, string RowsJson, string Status, string UploadedBy);
}

public sealed class AtmUploadDecision
{
    public string Decision { get; set; } = "";
    public string? Remarks { get; set; }
}

public sealed class AtmReassignRequest
{
    public string EmployeeId { get; set; } = "";
    public string? Remarks { get; set; }
}

public sealed class AtmReopenRequest
{
    public string? Remarks { get; set; }
}
