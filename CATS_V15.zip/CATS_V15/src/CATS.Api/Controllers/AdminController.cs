using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

[Authorize]
[ApiController]
[Route("api/admin")]
public sealed class AdminController(ICatsRepository repo, IPasswordHasher hasher, AdoHelper db) : ControllerBase
{
    [HttpGet("users")]
    public async Task<IActionResult> Users(CancellationToken ct)
    {
        RequireAdmin();
        var users=await repo.GetUsersAsync(ct);
        var items=new List<UserAdminItem>(users.Count);
        foreach(var user in users)
        {
            var item=ToItem(user);
            item.Permissions=await db.QueryAsync(
                $"SELECT PermissionCode FROM UserPermissionMapping WHERE UserId={db.Dialect.P("User")} AND IsActive=1 ORDER BY PermissionCode",
                row=>row.Str("PermissionCode"),[new("User",user.Id)],ct);
            items.Add(item);
        }
        return Ok(items);
    }

    [HttpPost("users")]
    public async Task<IActionResult> SaveUser(SaveUserRequest request,CancellationToken ct)
    {
        var actor=RequireAdmin();
        if(string.IsNullOrWhiteSpace(request.UserName) || string.IsNullOrWhiteSpace(request.DisplayName) || string.IsNullOrWhiteSpace(request.RoleCode))
            return BadRequest(new{message="User name, display name and role are required."});
        var roles=await repo.GetRoleCodesAsync(ct);
        if(!roles.Contains(request.RoleCode.Trim(),StringComparer.OrdinalIgnoreCase))
            return BadRequest(new{message="Select an active role from RoleMaster."});
        var requestedPermissions=request.Permissions.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        var activePermissions=await db.QueryAsync(
            "SELECT Code FROM PermissionMaster WHERE IsActive=1",
            row=>row.Str("Code"),ct:ct);
        if(requestedPermissions.Except(activePermissions,StringComparer.OrdinalIgnoreCase).Any())
            return BadRequest(new{message="Only active permissions from PermissionMaster can be assigned."});

        var existing=request.Id is null?null:await repo.GetUserByIdAsync(request.Id.Value,ct);
        var duplicate=await repo.GetUserByUserNameAsync(request.UserName.Trim(),ct);
        if(duplicate!=null && (existing==null || duplicate.Id!=existing.Id))
            return Conflict(new{message="User name already exists."});
        if(existing==null && string.IsNullOrWhiteSpace(request.Password))
            return BadRequest(new{message="Password is required for a new user."});
        if(!string.IsNullOrWhiteSpace(request.Password) && request.Password.Length<10)
            return BadRequest(new{message="Password must contain at least 10 characters."});

        var record=new UserRecord
        {
            Id=existing?.Id ?? CatsId.Next(),
            UserName=request.UserName.Trim(),DisplayName=request.DisplayName.Trim(),
            PasswordHash=string.IsNullOrWhiteSpace(request.Password)?existing!.PasswordHash:hasher.Hash(request.Password),
            RoleCode=request.RoleCode.Trim().ToUpperInvariant(),
            DepartmentCode=(request.DepartmentCode??"").Trim().ToUpperInvariant(),
            BranchCode=(request.BranchCode??"").Trim().ToUpperInvariant(),
            PermissionsJson=JsonSerializer.Serialize(requestedPermissions.OrderBy(x=>x,StringComparer.OrdinalIgnoreCase)),
            IsActive=request.IsActive
        };
        await repo.UpsertUserAsync(record,existing==null,ct);
        await db.InTransactionAsync(async tx =>
        {
            await tx.ExecuteAsync($"DELETE FROM UserPermissionMapping WHERE UserId={tx.Dialect.P("User")}",
                [new("User", record.Id)], ct);
            foreach(var permission in requestedPermissions)
                await tx.ExecuteAsync(
                    $"INSERT INTO UserPermissionMapping(UserId,PermissionCode,IsActive) VALUES({tx.Dialect.P("User")},{tx.Dialect.P("Permission")},1)",
                    [new("User", record.Id), new("Permission", permission)], ct);
            return true;
        },ct);
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id=CatsId.Next(),UserId=actor.Id,UserName=actor.UserName,RoleCode=actor.RoleCode,
            Action=existing==null?"USER_CREATE":"USER_UPDATE",EntityType="User",EntityId=record.Id.ToString(),
            NewValueJson=JsonSerializer.Serialize(ToItem(record)),Remarks=$"User {record.UserName} saved",
            IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow
        },ct);
        return Ok(ToItem(record));
    }

    [HttpGet("aging-buckets")]
    public async Task<IActionResult> AgingBuckets(CancellationToken ct)
    {
        RequireAdmin();
        return Ok(await repo.GetAgingBucketsAsync(ct));
    }

    [HttpPost("aging-buckets")]
    public async Task<IActionResult> SaveAgingBucket(SaveAgingBucketRequest request,CancellationToken ct)
    {
        var actor=RequireAdmin();
        await repo.SaveAgingBucketAsync(request,ct);
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id=CatsId.Next(),UserId=actor.Id,UserName=actor.UserName,RoleCode=actor.RoleCode,
            Action="AGING_BUCKET_SAVE",EntityType="AgingBucket",EntityId=request.Id?.ToString(),
            NewValueJson=JsonSerializer.Serialize(request),Remarks="Aging bucket configuration saved",
            IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow
        },ct);
        return Ok(await repo.GetAgingBucketsAsync(ct));
    }

    [HttpGet("permissions")]
    public async Task<IActionResult> Permissions(CancellationToken ct)
    {
        RequireAdmin();
        var permissions=await db.QueryAsync(
            "SELECT Code FROM PermissionMaster WHERE IsActive=1 ORDER BY Code",
            row=>row.Str("Code"),ct:ct);
        return Ok(permissions);
    }

    private CurrentUser RequireAdmin()
    {
        var u=User.ToCurrentUser();
        if(!u.HasPermission(PlatformPermissions.SecurityManage)) throw new UnauthorizedAccessException("Security management permission is required.");
        return u;
    }

    private static UserAdminItem ToItem(UserRecord u)=>new()
    {
        Id=u.Id,UserName=u.UserName,DisplayName=u.DisplayName,RoleCode=u.RoleCode,
        DepartmentCode=u.DepartmentCode,BranchCode=u.BranchCode,Permissions=u.Permissions().ToList(),IsActive=u.IsActive
    };
}
