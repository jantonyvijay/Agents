using System.Security.Cryptography;
using System.Text;
using CATS.AI;
using CATS.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.Api.Controllers;

[Authorize, ApiController, Route("api/assistant")]
public sealed class AssistantController(
    ICatsAssistantService assistant,
    IOfflineSpeechToTextService speechToText,
    ICatsRepository repo) : ControllerBase
{
    [HttpGet("status")]
    public IActionResult Status()
    {
        var user = User.ToCurrentUser();
        return Ok(new
        {
            enabled = assistant.IsEnabled && user.HasPermission(PlatformPermissions.AssistantUse),
            permissionGranted = user.HasPermission(PlatformPermissions.AssistantUse),
            provider = assistant.Provider,
            model = assistant.Model,
            speechToTextEnabled = speechToText.IsAvailable
        });
    }

    [HttpPost("transcribe")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(25_000_000)]
    public async Task<IActionResult> Transcribe([FromForm] IFormFile audio, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        if (!user.HasPermission(PlatformPermissions.AssistantUse))
            throw new UnauthorizedAccessException("CATS Assistant permission is required.");
        if (!speechToText.IsAvailable)
            return Conflict(new { message = "Offline speech-to-text is not configured." });
        if (audio is null || audio.Length == 0)
            return BadRequest(new { message = "A WAV recording is required." });
        if (audio.Length > speechToText.MaxAudioBytes)
            return BadRequest(new { message = $"The recording must not exceed {speechToText.MaxAudioBytes / 1_000_000} MB." });

        await using var stream = audio.OpenReadStream();
        var text = await speechToText.TranscribeAsync(stream, ct);
        return Ok(new { text });
    }

    [HttpPost("chat")]
    public async Task<IActionResult> Chat(CatsAssistantRequest request, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        if (!user.HasPermission(PlatformPermissions.AssistantUse))
            throw new UnauthorizedAccessException("CATS Assistant permission is required.");
        if (string.IsNullOrWhiteSpace(request.Message) || request.Message.Length > 4000)
            return BadRequest(new { message = "Question is required and must not exceed 4000 characters." });

        var result = await assistant.AskAsync(request, user, ct);
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(request.Message.Trim())));
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id = CatsId.Next(), UserId = user.Id, UserName = user.UserName, RoleCode = user.RoleCode,
            Action = "ASSISTANT_QUERY", EntityType = "Assistant", EntityId = null,
            Remarks = $"Read-only CATS Assistant question submitted. SHA256={hash}",
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), CreatedAtUtc = DateTime.UtcNow
        }, ct);
        return Ok(result);
    }
}
