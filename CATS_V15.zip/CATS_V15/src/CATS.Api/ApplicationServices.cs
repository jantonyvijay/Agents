using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using CATS.Core;
using CATS.Infrastructure;
using CATS.Workflow;

namespace CATS.Api;

public sealed class AlertApplicationService(
    ICatsRepository repo, IWorkflowEngine workflow, IDataProtectorService protector,
    AssignmentRuleEngine assignment, IAiQueryAssistantService aiQuery, StorageOptions storage, IWebHostEnvironment env)
{
    public async Task<AlertRecord> CreateAsync(
        CreateAlertRequest request,
        CurrentUser user,
        string? ip,
        CancellationToken ct,
        IReadOnlyDictionary<string, WorkflowAssignment>? trustedAssignments = null,
        bool isApprovedBatch = false)
    {
        if(!isApprovedBatch && !user.HasPermission(CatsPermissions.AlertUpload))
            throw new UnauthorizedAccessException("Alert upload permission is required.");
        var template=await repo.GetTemplateAsync(request.TemplateId,ct) ?? throw new KeyNotFoundException("Template not found.");
        if(!isApprovedBatch && template.Code.StartsWith("ATM_",StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("ATM penalty alerts must be created through ATM Operations after checker approval.");
        if(template.Status!=TemplateStatus.Published || template.PublishedWorkflowId is null)
            throw new InvalidOperationException("Template must have a published workflow before alerts can be created.");
        ValidateDynamicData(template, request.Data); // creation validates supplied values; stage-level required fields are enforced when that stage submits.
        var assigned=assignment.Apply(template,request,trustedAssignments);
        var now=DateTime.UtcNow;
        var alert=new AlertRecord
        {
            Id=CatsId.Next(),AlertNo=$"ALT-{RandomNumberGenerator.GetHexString(8)}",
            TemplateId=template.Id,TemplateVersion=template.Version,AlertType=request.AlertType.Trim(),BranchCode=assigned.BranchCode.Trim(),
            CustomerIdEncrypted=protector.Protect(request.CustomerId.Trim()),AccountIdEncrypted=protector.Protect(request.AccountId.Trim()),
            DynamicDataJson=assigned.DynamicDataJson,Status=AlertStatus.New,CurrentStageId="INIT",CurrentStageName="Initialising",
            CreatedAtUtc=now,StageEnteredAtUtc=now,CreatedBy=user.UserName,Priority=string.IsNullOrWhiteSpace(request.Priority)?"Normal":request.Priority.Trim()
        };
        await repo.InsertAlertAsync(alert,ct);
        await repo.InsertAuditAsync(NewAudit(alert.Id,user,"CREATE","Alert",alert.Id,null,null,JsonSerializer.Serialize(new{alert.AlertNo,alert.AlertType,alert.BranchCode}),"Alert created",ip),ct);
        await workflow.StartAsync(alert.Id,user,ct);
        return (await repo.GetAlertAsync(alert.Id,ct))!;
    }

    public async Task<AlertDetailResponse> DetailAsync(long id,CurrentUser user,string? ip,CancellationToken ct)
    {
        var alert=await repo.GetAlertAsync(id,ct) ?? throw new KeyNotFoundException("Alert not found.");
        await EnsureViewAsync(alert,user,ct);
        var template=await repo.GetTemplateAsync(alert.TemplateId,ct) ?? throw new InvalidOperationException("Template not found.");
        await repo.InsertAuditAsync(NewAudit(alert.Id,user,"ALERT_VIEW","Alert",alert.Id,alert.CurrentStageId,null,null,"Alert detail viewed",ip),ct);
        var customer=SafeUnprotect(alert.CustomerIdEncrypted); var account=SafeUnprotect(alert.AccountIdEncrypted);
        var sections=SafeDeserialize<List<TemplateSection>>(template.SectionsJson) ?? [];
        var fields=SafeDeserialize<List<TemplateField>>(template.FieldsJson) ?? [];
        var node=JsonNode.Parse(string.IsNullOrWhiteSpace(alert.DynamicDataJson)?"{}":alert.DynamicDataJson) as JsonObject ?? new JsonObject();
        node.Remove("_assignments"); // server-owned routing metadata is not exposed to the browser.
        {
            foreach(var f in fields.Where(x=>x.Sensitive))
                if(node[f.Name]!=null) node[f.Name]=protector.Mask(node[f.Name]!.ToString());
        }
        foreach(var f in fields.Where(x=>x.Sensitive)) f.DefaultValue="";
        JsonElement data; using(var doc=JsonDocument.Parse(node.ToJsonString())) data=doc.RootElement.Clone();
        var allowedActions=(await workflow.GetAllowedActionsAsync(id,user,ct)).ToList();
        var activeInstance=await repo.GetWorkflowInstanceByAlertAsync(id,ct);
        var workflowNotice=activeInstance!=null && !activeInstance.CurrentStageId.Equals(alert.CurrentStageId,StringComparison.OrdinalIgnoreCase)
            ? $"Workflow assignment mismatch: the alert shows '{alert.CurrentStageName}', but its workflow is at '{activeInstance.CurrentStageId}'. An administrator must reconcile the stage and pending tasks before further action."
            : null;
        if(workflowNotice!=null) allowedActions.Clear();
        var editableFields=await GetEditableFieldsAsync(alert,template,fields,user,allowedActions.Count>0,ct);
        var canRaiseQuery=allowedActions.Any(x=>x.Equals("RaiseQuery",StringComparison.OrdinalIgnoreCase) || x.Equals("Query",StringComparison.OrdinalIgnoreCase));
        var aiAvailability=canRaiseQuery
            ? aiQuery.GetAvailability(template.Id.ToString(),alert.AlertType,alert.CurrentStageId,user.RoleCode)
            : AiQueryAvailability.Disabled;
        return new AlertDetailResponse
        {
            Alert=SanitizeForClient(alert),TemplateName=template.Name,WorkflowNotice=workflowNotice,
            CustomerId=protector.Mask(customer), AccountId=protector.Mask(account),
            CanUnmaskPi=user.HasPermission(CatsPermissions.PiUnmask),
            Sections=sections,Fields=fields,
            ViewConfiguration=SafeDeserialize<TemplateViewConfiguration>(template.ViewConfigurationJson) ?? new TemplateViewConfiguration(),
            DynamicData=data,AllowedActions=allowedActions,EditableFields=editableFields,
            PendingWorkItems=(await repo.GetPendingWorkItemsAsync(id,ct)).ToList(),Queries=(await repo.GetQueriesAsync(id,ct)).ToList(),
            Attachments=(await FilterVisibleAttachmentsAsync(id,user,ct)).ToList(),CanUploadAttachments=await CanUploadAttachmentAsync(alert,user,ct),
            AiQueryEnabled=aiAvailability.Enabled,AiQueryProvider=aiAvailability.Provider,AiQueryModel=aiAvailability.Model,
            Audit=user.HasPermission(CatsPermissions.AuditView)?(await repo.GetAuditAsync(id,100,ct)).ToList():[]
        };
    }

    public async Task<AiQuerySuggestion> SuggestQueryAsync(long id,AiQuerySuggestionRequest request,CurrentUser user,string? ip,CancellationToken ct)
    {
        var alert=await repo.GetAlertAsync(id,ct) ?? throw new KeyNotFoundException("Alert not found.");
        await EnsureViewAsync(alert,user,ct);
        var allowed=await workflow.GetAllowedActionsAsync(id,user,ct);
        if(!allowed.Any(x=>x.Equals("RaiseQuery",StringComparison.OrdinalIgnoreCase) || x.Equals("Query",StringComparison.OrdinalIgnoreCase)))
            throw new UnauthorizedAccessException("Raise Query is not assigned to the logged-in user/role at the current workflow stage.");

        var template=await repo.GetTemplateAsync(alert.TemplateId,ct) ?? throw new InvalidOperationException("Template not found.");
        var availability=aiQuery.GetAvailability(template.Id.ToString(),alert.AlertType,alert.CurrentStageId,user.RoleCode);
        if(!availability.Enabled) throw new InvalidOperationException("AI Query is not enabled for this template, alert type, workflow stage, or role.");

        var fields=SafeDeserialize<List<TemplateField>>(template.FieldsJson) ?? [];
        var node=JsonNode.Parse(string.IsNullOrWhiteSpace(alert.DynamicDataJson)?"{}":alert.DynamicDataJson) as JsonObject ?? new JsonObject();
        node.Remove("_assignments");
        if(aiQuery.MaskPiData)
        {
            foreach(var f in fields.Where(x=>x.Sensitive))
                if(node[f.Name]!=null) node[f.Name]=protector.Mask(node[f.Name]!.ToString());
        }

        var previous=(await repo.GetQueriesAsync(id,ct)).OrderByDescending(x=>x.RaisedAtUtc).Take(5)
            .Select(x=>new{x.QueryText,x.ResponseText,x.Status,x.RaisedAtUtc}).ToList();
        var context=new AiQueryContext
        {
            TemplateId=template.Id.ToString(),TemplateName=template.Name,AlertType=alert.AlertType,
            StageId=alert.CurrentStageId,StageName=alert.CurrentStageName,RoleCode=user.RoleCode,
            AlertNo=alert.AlertNo,Status=alert.Status.ToString(),Priority=alert.Priority,BranchCode=alert.BranchCode,
            CustomerId=aiQuery.MaskPiData?protector.Mask(SafeUnprotect(alert.CustomerIdEncrypted)):SafeUnprotect(alert.CustomerIdEncrypted),
            AccountId=aiQuery.MaskPiData?protector.Mask(SafeUnprotect(alert.AccountIdEncrypted)):SafeUnprotect(alert.AccountIdEncrypted),
            DynamicDataJson=node.ToJsonString(),PreviousQueriesJson=JsonSerializer.Serialize(previous),
            UserInstruction=string.IsNullOrWhiteSpace(request.Instruction)?null:request.Instruction.Trim()
        };
        var suggestion=await aiQuery.SuggestAsync(context,ct);
        await repo.InsertAuditAsync(NewAudit(alert.Id,user,"AI_QUERY_SUGGESTED","Alert",alert.Id,alert.CurrentStageId,null,
            JsonSerializer.Serialize(new{suggestion.QueryText,suggestion.Reason,suggestion.Provider,suggestion.Model}),
            "AI produced a query draft only; no workflow action was executed.",ip),ct);
        return suggestion;
    }

    public async Task ApplyActionAsync(long id,WorkflowActionRequest request,CurrentUser user,string? ip,CancellationToken ct)
    {
        var alert=await repo.GetAlertAsync(id,ct) ?? throw new KeyNotFoundException("Alert not found.");
        await EnsureViewAsync(alert,user,ct);
        var activeInstance=await repo.GetWorkflowInstanceByAlertAsync(id,ct);
        if(activeInstance!=null && !activeInstance.CurrentStageId.Equals(alert.CurrentStageId,StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("The alert stage and workflow stage do not match. Reconcile the pending assignment before performing an action.");
        var allowed=await workflow.GetAllowedActionsAsync(id,user,ct);
        if(!allowed.Contains(request.Action,StringComparer.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException($"Action '{request.Action}' is not assigned to the logged-in user/role.");

        if(request.Data.ValueKind==JsonValueKind.Object && request.Data.EnumerateObject().Any())
            await SaveStageResponseAsync(alert,request.Data,user,ip,ct);

        await workflow.ApplyActionAsync(id,request,user,ip,ct);
    }

    public async Task ReassignAsync(long id,ReassignWorkItemRequest request,CurrentUser user,string? ip,CancellationToken ct)
    {
        if(!user.HasPermission(CatsPermissions.AlertReassign))
            throw new UnauthorizedAccessException("Alert reassignment permission is required.");
        var alert=await repo.GetAlertAsync(id,ct) ?? throw new KeyNotFoundException("Alert not found.");
        await EnsureViewAsync(alert,user,ct);
        var stageId=string.IsNullOrWhiteSpace(request.StageId)?alert.CurrentStageId:request.StageId.Trim();
        var currentItems=(await repo.GetPendingWorkItemsAsync(id,ct)).Where(x=>x.StageId.Equals(stageId,StringComparison.OrdinalIgnoreCase)).ToList();
        if(currentItems.Count==0) throw new InvalidOperationException("No pending work item was found for the selected stage.");
        var effectiveRole=string.IsNullOrWhiteSpace(request.RoleCode)?currentItems[0].AssignedRoleCode:request.RoleCode.Trim();
        var effectiveBranch=string.IsNullOrWhiteSpace(request.BranchCode)?(string.IsNullOrWhiteSpace(currentItems[0].AssignedBranchCode)?alert.BranchCode:currentItems[0].AssignedBranchCode):request.BranchCode.Trim();
        await repo.ReassignPendingWorkItemsAsync(id,stageId,effectiveRole,effectiveBranch,request.UserId,ct);
        await repo.InsertAuditAsync(NewAudit(id,user,"REASSIGN","WorkItem",id,stageId,null,
            JsonSerializer.Serialize(new{stageId,roleCode=effectiveRole,branchCode=effectiveBranch,userId=request.UserId}),request.Remarks??"Work item reassigned",ip),ct);
    }

    public async Task<AttachmentRecord> UploadAttachmentAsync(long alertId,string stageId,IFormFile file,CurrentUser user,string? ip,CancellationToken ct)
    {
        var alert=await repo.GetAlertAsync(alertId,ct) ?? throw new KeyNotFoundException("Alert not found.");
        await EnsureViewAsync(alert,user,ct);
        if(!stageId.Equals(alert.CurrentStageId,StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("Attachments can only be uploaded to the current workflow stage.");
        var actions=await workflow.GetAllowedActionsAsync(alertId,user,ct);
        var stage=await GetWorkflowStageAsync(alert,stageId,ct);
        var configuredRoles=stage?.AttachmentUploadRoles ?? [];
        var canUpload=configuredRoles.Count>0
            ? configuredRoles.Contains(user.RoleCode,StringComparer.OrdinalIgnoreCase)
            : actions.Count>0 || user.HasPermission(CatsPermissions.AlertUpload);
        if(!canUpload)
            throw new UnauthorizedAccessException("You are not authorised to add an attachment at the current workflow stage.");
        if(file.Length<=0 || file.Length>storage.MaxFileSizeBytes) throw new InvalidOperationException($"File size must be between 1 byte and {storage.MaxFileSizeBytes} bytes.");
        var ext=Path.GetExtension(file.FileName).ToLowerInvariant();
        if(!storage.AllowedExtensions.Contains(ext,StringComparer.OrdinalIgnoreCase)) throw new InvalidOperationException("File type is not allowed.");
        var safeName=Path.GetFileName(file.FileName);
        var root=Path.IsPathRooted(storage.AttachmentRoot)?storage.AttachmentRoot:Path.Combine(env.ContentRootPath,storage.AttachmentRoot);
        Directory.CreateDirectory(root);
        var stored=Guid.NewGuid().ToString("N")+ext;
        var full=Path.Combine(root,stored);
        await using(var fs=new FileStream(full,FileMode.CreateNew,FileAccess.Write,FileShare.None,81920,true)) await file.CopyToAsync(fs,ct);
        string hash; await using(var fs=File.OpenRead(full)){hash=Convert.ToHexString(await SHA256.HashDataAsync(fs,ct));}
        var existing=await repo.GetAttachmentsAsync(alertId,ct);
        var version=existing.Where(x=>x.FileName.Equals(safeName,StringComparison.OrdinalIgnoreCase)).Select(x=>x.Version).DefaultIfEmpty(0).Max()+1;
        var rec=new AttachmentRecord{Id=CatsId.Next(),AlertId=alertId,StageId=stageId,FileName=safeName,StoredName=stored,ContentType=file.ContentType??"application/octet-stream",FileSize=file.Length,Sha256=hash,Version=version,UploadedBy=user.UserName,UploadedAtUtc=DateTime.UtcNow};
        await repo.InsertAttachmentAsync(rec,ct);
        await repo.InsertAuditAsync(NewAudit(alertId,user,"ATTACHMENT_UPLOAD","Attachment",rec.Id,stageId,null,JsonSerializer.Serialize(new{rec.FileName,rec.Version,rec.FileSize,rec.Sha256}),"Attachment uploaded",ip),ct);
        return rec;
    }

    public async Task<(string Path,AttachmentRecord Record)> GetAttachmentForDownloadAsync(long id,CurrentUser user,string? ip,CancellationToken ct)
    {
        var rec=await repo.GetAttachmentAsync(id,ct) ?? throw new KeyNotFoundException("Attachment not found.");
        var alert=await repo.GetAlertAsync(rec.AlertId,ct) ?? throw new KeyNotFoundException("Alert not found.");
        await EnsureViewAsync(alert,user,ct);
        var stage=await GetWorkflowStageAsync(alert,rec.StageId,ct);
        if(stage?.AttachmentViewRoles.Count>0 && !stage.AttachmentViewRoles.Contains(user.RoleCode,StringComparer.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("Your role is not authorised to view this attachment.");
        var root=Path.IsPathRooted(storage.AttachmentRoot)?storage.AttachmentRoot:Path.Combine(env.ContentRootPath,storage.AttachmentRoot);
        var full=Path.Combine(root,rec.StoredName);
        if(!File.Exists(full)) throw new FileNotFoundException("Stored attachment file is missing.");
        await repo.InsertAuditAsync(NewAudit(rec.AlertId,user,"ATTACHMENT_DOWNLOAD","Attachment",rec.Id,rec.StageId,null,null,"Attachment downloaded",ip),ct);
        return(full,rec);
    }

    public async Task EnsureViewAsync(AlertRecord alert,CurrentUser user,CancellationToken ct)
    {
        if(user.HasPermission(CatsPermissions.AlertViewAll)) return;
        if(alert.BranchCode.Equals(user.BranchCode,StringComparison.OrdinalIgnoreCase)) return;
        var items=await repo.GetWorkItemsAsync(alert.Id,ct);
        if(items.Any(w=>w.CompletedBy?.Equals(user.UserName,StringComparison.OrdinalIgnoreCase)==true ||
            w.AssignedUserId==user.Id ||
            // A work item assigned to a specific person (e.g. from ATM Staff Mapping) belongs to that person, not to everyone with the role.
            ((w.AssignedUserId is null or 0) && w.AssignedRoleCode.Equals(user.RoleCode,StringComparison.OrdinalIgnoreCase) &&
             (string.IsNullOrWhiteSpace(w.AssignedBranchCode) || w.AssignedBranchCode.Equals(user.BranchCode,StringComparison.OrdinalIgnoreCase))))) return;
        if(IsMappedToUser(alert,items,user)) return;
        
        throw new UnauthorizedAccessException("You are not authorised to view this alert.");
    }

    /// <summary>True when the alert's stored routing (_assignments) names the user for a stage that has no work item yet, e.g. a later approver from Staff Mapping.</summary>
    private static bool IsMappedToUser(AlertRecord alert,IReadOnlyList<WorkItemRecord> items,CurrentUser user)
    {
        try
        {
            using var doc=JsonDocument.Parse(string.IsNullOrWhiteSpace(alert.DynamicDataJson)?"{}":alert.DynamicDataJson);
            if(!doc.RootElement.TryGetProperty("_assignments",out var assignments) || assignments.ValueKind!=JsonValueKind.Object) return false;
            foreach(var stage in assignments.EnumerateObject())
            {
                if(items.Any(w=>w.StageId.Equals(stage.Name,StringComparison.OrdinalIgnoreCase))) continue;
                if(!stage.Value.TryGetProperty("userId",out var id)) continue;
                var mapped=id.ValueKind==JsonValueKind.Number&&id.TryGetInt64(out var n)?n:long.TryParse(id.GetString(),out var s)?s:0;
                if(mapped==user.Id) return true;
            }
        }
        catch(JsonException){}
        return false;
    }

    private async Task<bool> CanUploadAttachmentAsync(AlertRecord alert,CurrentUser user,CancellationToken ct)
    {
        var stage=await GetWorkflowStageAsync(alert,alert.CurrentStageId,ct);
        if(stage?.AttachmentUploadRoles.Count>0)
            return stage.AttachmentUploadRoles.Contains(user.RoleCode,StringComparer.OrdinalIgnoreCase);
        return (await workflow.GetAllowedActionsAsync(alert.Id,user,ct)).Count>0 || user.HasPermission(CatsPermissions.AlertUpload);
    }

    private async Task<IReadOnlyList<AttachmentRecord>> FilterVisibleAttachmentsAsync(long alertId,CurrentUser user,CancellationToken ct)
    {
        var alert=await repo.GetAlertAsync(alertId,ct) ?? throw new KeyNotFoundException("Alert not found.");
        var attachments=await repo.GetAttachmentsAsync(alertId,ct);
        var visible=new List<AttachmentRecord>();
        foreach(var attachment in attachments)
        {
            var stage=await GetWorkflowStageAsync(alert,attachment.StageId,ct);
            if(stage?.AttachmentViewRoles.Count is not >0 || stage.AttachmentViewRoles.Contains(user.RoleCode,StringComparer.OrdinalIgnoreCase)) visible.Add(attachment);
        }
        return visible;
    }

    private async Task<WorkflowStage?> GetWorkflowStageAsync(AlertRecord alert,string stageId,CancellationToken ct)
    {
        var instance=await repo.GetWorkflowInstanceByAlertAsync(alert.Id,ct);
        if(instance==null) return null;
        var record=await repo.GetWorkflowAsync(instance.WorkflowDefinitionId,ct);
        if(record==null) return null;
        var definition=JsonSerializer.Deserialize<WorkflowDefinitionModel>(record.DefinitionJson,JsonDefaults.Options);
        return definition?.Stages.FirstOrDefault(x=>x.Id.Equals(stageId,StringComparison.OrdinalIgnoreCase));
    }


    private async Task SaveStageResponseAsync(AlertRecord alert,JsonElement submitted,CurrentUser user,string? ip,CancellationToken ct)
    {
        var template=await repo.GetTemplateAsync(alert.TemplateId,ct) ?? throw new InvalidOperationException("Template not found.");
        var fields=SafeDeserialize<List<TemplateField>>(template.FieldsJson) ?? [];
        var editable=await GetEditableFieldsAsync(alert,template,fields,user,true,ct);
        var allowed=new HashSet<string>(editable,StringComparer.OrdinalIgnoreCase);
        var byName=fields.ToDictionary(x=>x.Name,StringComparer.OrdinalIgnoreCase);
        var root=JsonNode.Parse(string.IsNullOrWhiteSpace(alert.DynamicDataJson)?"{}":alert.DynamicDataJson) as JsonObject ?? new JsonObject();
        var changed=new List<string>();

        foreach(var property in submitted.EnumerateObject())
        {
            if(property.Name.Equals("_assignments",StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Reserved workflow assignment data cannot be modified.");
            if(!byName.TryGetValue(property.Name,out var field))
                throw new InvalidOperationException($"Unknown template field '{property.Name}'.");
            if(!allowed.Contains(field.Name))
                throw new UnauthorizedAccessException($"Field '{field.Label}' is not editable at the current workflow stage.");
            if(field.Sensitive && !user.HasPermission(CatsPermissions.PiUnmask))
                throw new UnauthorizedAccessException($"Sensitive field '{field.Label}' requires PI unmask permission to modify.");
            var existingKey=root.Select(item=>item.Key).FirstOrDefault(key=>key.Equals(field.Name,StringComparison.OrdinalIgnoreCase));
            if(existingKey!=null) root.Remove(existingKey);
            root[field.Name]=JsonNode.Parse(property.Value.GetRawText());
            changed.Add(field.Name);
        }

        using(var doc=JsonDocument.Parse(root.ToJsonString())) ValidateDynamicData(template,doc.RootElement,editable,allowStoredExtraFields:true);
        await repo.UpdateAlertDynamicDataAsync(alert.Id,root.ToJsonString(),ct);
        await repo.InsertAuditAsync(NewAudit(alert.Id,user,"RESPONSE_SAVE","Alert",alert.Id,alert.CurrentStageId,null,
            JsonSerializer.Serialize(new{fields=changed}),"Dynamic questionnaire/response values saved",ip),ct);
    }

    private async Task<List<string>> GetEditableFieldsAsync(AlertRecord alert,TemplateRecord template,List<TemplateField> fields,CurrentUser user,bool hasWorkItem,CancellationToken ct)
    {
        if(!hasWorkItem) return [];
        var instance=await repo.GetWorkflowInstanceByAlertAsync(alert.Id,ct);
        if(instance==null) return [];
        var workflowRecord=await repo.GetWorkflowAsync(instance.WorkflowDefinitionId,ct);
        if(workflowRecord==null) return [];
        var definition=JsonSerializer.Deserialize<WorkflowDefinitionModel>(workflowRecord.DefinitionJson,JsonDefaults.Options);
        if(definition==null) return [];
        var stage=definition.GetStage(instance.CurrentStageId);
        var requested=stage.EditableFields.Any(x=>x=="*")
            ? fields.Select(x=>x.Name)
            : stage.EditableFields;
        return requested.Where(name=>fields.Any(f=>f.Name.Equals(name,StringComparison.OrdinalIgnoreCase) && (!f.Sensitive || (f.AllowUnmask && user.HasPermission(CatsPermissions.PiUnmask)))))
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static AlertRecord SanitizeForClient(AlertRecord a)=>new()
    {
        Id=a.Id,AlertNo=a.AlertNo,TemplateId=a.TemplateId,TemplateVersion=a.TemplateVersion,AlertType=a.AlertType,BranchCode=a.BranchCode,
        CustomerIdEncrypted="",AccountIdEncrypted="",DynamicDataJson="{}",Status=a.Status,CurrentStageId=a.CurrentStageId,CurrentStageName=a.CurrentStageName,
        CreatedAtUtc=a.CreatedAtUtc,StageEnteredAtUtc=a.StageEnteredAtUtc,CreatedBy=a.CreatedBy,Priority=a.Priority
    };

    private static void ValidateDynamicData(TemplateRecord template, JsonElement data, IEnumerable<string>? requiredScope = null, bool allowStoredExtraFields = false)
    {
        var fields=SafeDeserialize<List<TemplateField>>(template.FieldsJson) ?? [];
        var byName=fields.ToDictionary(x=>x.Name,StringComparer.OrdinalIgnoreCase);
        var required=requiredScope==null?null:new HashSet<string>(requiredScope,StringComparer.OrdinalIgnoreCase);
        JsonElement root;
        if(data.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null)
        {
            using var empty=JsonDocument.Parse("{}"); root=empty.RootElement.Clone();
        }
        else if(data.ValueKind!=JsonValueKind.Object) throw new InvalidOperationException("Dynamic alert data must be a JSON object.");
        else root=data;

        foreach(var property in root.EnumerateObject())
        {
            if(property.Name.Equals("_assignments",StringComparison.OrdinalIgnoreCase)) continue;
            if(!allowStoredExtraFields && !byName.ContainsKey(property.Name)) throw new InvalidOperationException($"Unknown template field '{property.Name}'.");
        }

        foreach(var field in fields)
        {
            var found=TryGetIgnoreCase(root,field.Name,out var value);
            var missing=!found || value.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined ||
                        (value.ValueKind==JsonValueKind.String && string.IsNullOrWhiteSpace(value.GetString()));
            if(field.Required && required!=null && required.Contains(field.Name) && missing)
                throw new InvalidOperationException($"Field '{field.Label}' is required at the current workflow stage.");

            var dependencyRules=SafeDeserialize<List<FieldDependencyValidation>>(field.DependencyValidationsJson) ?? [];
            foreach(var rule in dependencyRules)
            {
                var conditionsMet=rule.Conditions.Count>0 && rule.Conditions.All(c =>
                {
                    if(!TryGetIgnoreCase(root,c.Field,out var other)) return false;
                    var actual=other.ValueKind==JsonValueKind.String ? other.GetString() ?? "" : other.ToString();
                    return c.Operator.Trim().ToLowerInvariant() switch
                    {
                        "neq" or "ne" => !actual.Equals(c.Value,StringComparison.OrdinalIgnoreCase),
                        "contains" => actual.Contains(c.Value,StringComparison.OrdinalIgnoreCase),
                        "notempty" => !string.IsNullOrWhiteSpace(actual),
                        "empty" => string.IsNullOrWhiteSpace(actual),
                        _ => actual.Equals(c.Value,StringComparison.OrdinalIgnoreCase)
                    };
                });
                if(!conditionsMet) continue;
                if(rule.Required && missing)
                    throw new InvalidOperationException(string.IsNullOrWhiteSpace(rule.ErrorMessage) ? $"Field '{field.Label}' is required for the selected values." : rule.ErrorMessage);
                if(!missing && !string.IsNullOrWhiteSpace(rule.MustEqualField) && TryGetIgnoreCase(root,rule.MustEqualField,out var matchValue) && !value.ToString().Equals(matchValue.ToString(),StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException(string.IsNullOrWhiteSpace(rule.ErrorMessage) ? $"Field '{field.Label}' must match '{rule.MustEqualField}'." : rule.ErrorMessage);
            }
            if(missing) continue;

            var rawText=value.ValueKind==JsonValueKind.String ? value.GetString() ?? "" : value.ToString();
            if(field.MinLength.HasValue && rawText.Length < field.MinLength.Value)
                throw new InvalidOperationException(string.IsNullOrWhiteSpace(field.CustomErrorMessage) ? $"Field '{field.Label}' must contain at least {field.MinLength.Value} characters." : field.CustomErrorMessage);
            if(field.MaxLength.HasValue && rawText.Length > field.MaxLength.Value)
                throw new InvalidOperationException(string.IsNullOrWhiteSpace(field.CustomErrorMessage) ? $"Field '{field.Label}' cannot exceed {field.MaxLength.Value} characters." : field.CustomErrorMessage);
            if(!string.IsNullOrWhiteSpace(field.ValidationPattern) && !System.Text.RegularExpressions.Regex.IsMatch(rawText, field.ValidationPattern))
                throw new InvalidOperationException(string.IsNullOrWhiteSpace(field.CustomErrorMessage) ? $"Field '{field.Label}' has an invalid format." : field.CustomErrorMessage);

            switch(field.Type.Trim().ToLowerInvariant())
            {
                case "number":
                    decimal number;
                    if(value.ValueKind==JsonValueKind.Number && value.TryGetDecimal(out number)) { }
                    else if(value.ValueKind==JsonValueKind.String && decimal.TryParse(value.GetString(),System.Globalization.NumberStyles.Any,System.Globalization.CultureInfo.InvariantCulture,out number)) { }
                    else throw new InvalidOperationException($"Field '{field.Label}' must be a valid number.");
                    if(field.MinValue.HasValue && number < field.MinValue.Value)
                        throw new InvalidOperationException(string.IsNullOrWhiteSpace(field.CustomErrorMessage) ? $"Field '{field.Label}' must be at least {field.MinValue.Value}." : field.CustomErrorMessage);
                    if(field.MaxValue.HasValue && number > field.MaxValue.Value)
                        throw new InvalidOperationException(string.IsNullOrWhiteSpace(field.CustomErrorMessage) ? $"Field '{field.Label}' cannot exceed {field.MaxValue.Value}." : field.CustomErrorMessage);
                    break;
                case "date":
                    if(value.ValueKind!=JsonValueKind.String || !DateTime.TryParse(value.GetString(),System.Globalization.CultureInfo.InvariantCulture,System.Globalization.DateTimeStyles.None,out _))
                        throw new InvalidOperationException($"Field '{field.Label}' must be a valid date.");
                    break;
                case "checkbox":
                    if(value.ValueKind is not (JsonValueKind.True or JsonValueKind.False) &&
                       (value.ValueKind!=JsonValueKind.String || !bool.TryParse(value.GetString(),out _)))
                        throw new InvalidOperationException($"Field '{field.Label}' must be true or false.");
                    break;
                case "select":
                    if(!string.Equals(field.DataSourceMode,"Api",StringComparison.OrdinalIgnoreCase))
                    {
                        var options=SafeDeserialize<List<string>>(field.OptionsJson) ?? [];
                        var selected=value.ToString();
                        if(options.Count>0 && !options.Contains(selected,StringComparer.OrdinalIgnoreCase))
                            throw new InvalidOperationException($"Field '{field.Label}' contains an invalid option.");
                    }
                    break;
            }

        }
    }

    private static bool TryGetIgnoreCase(JsonElement root,string name,out JsonElement value)
    {
        if(root.ValueKind==JsonValueKind.Object)
            foreach(var p in root.EnumerateObject())
                if(p.Name.Equals(name,StringComparison.OrdinalIgnoreCase)){value=p.Value;return true;}
        value=default; return false;
    }

    private string SafeUnprotect(string s){try{return protector.Unprotect(s);}catch{return "";}}
    private static T? SafeDeserialize<T>(string json){try{return JsonSerializer.Deserialize<T>(json,new JsonSerializerOptions(JsonSerializerDefaults.Web){PropertyNameCaseInsensitive=true});}catch{return default;}}
    private static AuditRecord NewAudit(long? alertId,CurrentUser user,string action,string entityType,object? entityId,string? stage,string? previous,string? current,string? remarks,string? ip)=>new(){Id=CatsId.Next(),AlertId=alertId,UserId=user.Id,UserName=user.UserName,RoleCode=user.RoleCode,Action=action,EntityType=entityType,EntityId=Convert.ToString(entityId,System.Globalization.CultureInfo.InvariantCulture),StageId=stage,PreviousValueJson=previous,NewValueJson=current,Remarks=remarks,IpAddress=ip,CreatedAtUtc=DateTime.UtcNow};
}

public static class CsvParser
{
    public static List<Dictionary<string,string>> Parse(string text)=>Parse(text,null);

    /// <summary>Parses delimited text. A null delimiter auto-detects comma or tilde from the header line.</summary>
    public static List<Dictionary<string,string>> Parse(string text,char? configuredDelimiter)
    {
        if(string.IsNullOrWhiteSpace(text)) return [];
        var delimiter=configuredDelimiter??DetectDelimiter(text);
        var rows=new List<List<string>>(); var row=new List<string>(); var cell=new StringBuilder(); var quoted=false;
        for(int i=0;i<text.Length;i++)
        {
            var c=text[i];
            if(c=='"'){if(quoted&&i+1<text.Length&&text[i+1]=='"'){cell.Append('"');i++;}else quoted=!quoted;}
            else if(c==delimiter&&!quoted){row.Add(cell.ToString());cell.Clear();}
            else if((c=='\n'||c=='\r')&&!quoted){if(c=='\r'&&i+1<text.Length&&text[i+1]=='\n')i++;row.Add(cell.ToString());cell.Clear();if(row.Any(x=>!string.IsNullOrWhiteSpace(x)))rows.Add(row);row=[];}
            else cell.Append(c);
        }
        if(cell.Length>0||row.Count>0){row.Add(cell.ToString());rows.Add(row);}
        if(rows.Count<2)return [];
        var headers=rows[0].Select((x,i)=>i==0?x.Trim().TrimStart('\uFEFF'):x.Trim()).ToArray();
        if(headers.Any(string.IsNullOrWhiteSpace) || headers.Distinct(StringComparer.OrdinalIgnoreCase).Count()!=headers.Length)
            throw new InvalidOperationException("CSV headers must be non-empty and unique.");
        var result=new List<Dictionary<string,string>>();
        for(var rowIndex=1;rowIndex<rows.Count;rowIndex++)
        {
            var r=rows[rowIndex];
            if(r.Count!=headers.Length)
            {
                if(headers.Length==1 && configuredDelimiter.HasValue)
                {
                    var detectedDelimiter=DetectDelimiter(text);
                    if(detectedDelimiter!=delimiter && headers[0].Contains(detectedDelimiter))
                    {
                        var configuredName=delimiter=='\t'?"tab":$"'{delimiter}'";
                        var detectedName=detectedDelimiter==','?"Comma":"Tilde";
                        throw new InvalidOperationException(
                            $"The configured column separator ({configuredName}) does not match the file header. " +
                            $"The file appears to use {detectedName.ToLowerInvariant()} separators. " +
                            $"In Template Designer > Source Column Mapping > Bulk File Upload, set Column separator to {detectedName} or Auto-detect, then upload again.");
                    }
                }
                throw new InvalidOperationException($"CSV row {rowIndex+1} contains {r.Count} values; expected {headers.Length}.");
            }
            var d=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
            for(int i=0;i<headers.Length;i++) d[headers[i]]=r[i].Trim();
            result.Add(d);
        }
        return result;
    }

    private static char DetectDelimiter(string text)
    {
        var quoted=false;
        var commas=0;
        var tildes=0;
        foreach(var c in text)
        {
            if(c=='"') quoted=!quoted;
            else if(!quoted && (c=='\r'||c=='\n')) break;
            else if(!quoted && c==',') commas++;
            else if(!quoted && c=='~') tildes++;
        }
        return tildes>commas?'~':',';
    }
}
