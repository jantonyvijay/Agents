using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;

namespace CATS.Api;

/// <summary>Reads AlertListColumnMaster, the configurable catalog of Alerts-table columns for Alert List Configuration.</summary>
public sealed class AlertListColumnService(AdoHelper db)
{
    public async Task<IReadOnlyList<AlertListColumnDefinition>> GetActiveAsync(CancellationToken ct = default) =>
        await db.QueryAsync(
            "SELECT Code,Label,DbColumn,IsFilterable,MatchMode,ControlType,OptionsJson,ValueFormat,ExcludedTemplateCodes,DisplayOrder,IsActive FROM AlertListColumnMaster WHERE IsActive=1 ORDER BY DisplayOrder,Code",
            r => new AlertListColumnDefinition
            {
                Code = r.Str("Code"), Label = r.Str("Label"), DbColumn = r.NStr("DbColumn"), IsFilterable = r.Bool("IsFilterable"),
                MatchMode = r.Str("MatchMode"), ControlType = r.Str("ControlType"), OptionsJson = r.Str("OptionsJson"),
                ValueFormat = r.NStr("ValueFormat"), ExcludedTemplateCodes = r.NStr("ExcludedTemplateCodes"),
                DisplayOrder = r.Int("DisplayOrder"), IsActive = r.Bool("IsActive")
            }, null, ct);

    /// <summary>
    /// Turns the client's {"Code":"value"} object into the validated array the Alerts procedures read: only active, searchable catalog columns
    /// are kept, and the Alerts-table column and match mode come from the catalog, never from the client.
    /// </summary>
    public async Task<string?> ResolveFiltersAsync(string? clientFilters, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(clientFilters)) return null;
        Dictionary<string, JsonElement>? requested;
        try { requested = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(clientFilters, JsonDefaults.Options); }
        catch (JsonException) { throw new InvalidOperationException("The column filters are not valid."); }
        if (requested is null || requested.Count == 0) return null;
        var catalog = (await GetActiveAsync(ct)).Where(x => x.CanSearch).ToDictionary(x => x.Code, StringComparer.OrdinalIgnoreCase);
        var resolved = new List<object>();
        foreach (var (code, element) in requested)
        {
            var value = (element.ValueKind == JsonValueKind.String ? element.GetString() : element.ToString())?.Trim();
            if (string.IsNullOrEmpty(value) || !catalog.TryGetValue(code, out var column)) continue;
            resolved.Add(new { column = column.DbColumn, mode = column.MatchMode, value = value.Length > 500 ? value[..500] : value });
        }
        return resolved.Count == 0 ? null : JsonSerializer.Serialize(resolved, JsonDefaults.Options);
    }
}
