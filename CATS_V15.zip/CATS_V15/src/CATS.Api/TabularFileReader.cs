using System.Globalization;
using System.Text;
using ClosedXML.Excel;
using CATS.Core;

namespace CATS.Api;

/// <summary>Reads a Bulk File Upload according to the template's configured file format and separator.</summary>
public static class TabularFileReader
{
    public const int MaxRows = 20_000;
    private const int MaxColumns = 500;
    private static readonly string[] Formats = ["", "Csv", "Txt", "Excel"];

    public static bool IsValidFormat(string? format) => Formats.Contains(format ?? "", StringComparer.OrdinalIgnoreCase);

    /// <summary>A delimiter is empty (auto-detect) or exactly one non-alphanumeric, non-quote character.</summary>
    public static bool IsValidDelimiter(string? delimiter) =>
        string.IsNullOrEmpty(delimiter) || (delimiter.Length == 1 && !char.IsLetterOrDigit(delimiter[0]) && delimiter[0] is not ('"' or '\r' or '\n' or ' '));

    public static string Normalize(string? format) =>
        Formats.FirstOrDefault(x => x.Equals(format ?? "", StringComparison.OrdinalIgnoreCase)) ?? "";

    public static string[] AllowedExtensions(string? format) => Normalize(format) switch
    {
        "Csv" => [".csv"],
        "Txt" => [".txt"],
        "Excel" => [".xlsx"],
        _ => [".csv", ".txt"]
    };

    public static string Describe(string? format) => Normalize(format) switch
    {
        "Csv" => "a .csv file",
        "Txt" => "a .txt file",
        "Excel" => "an Excel .xlsx workbook",
        _ => "a .csv or .txt file"
    };

    public static void EnsureExtension(string fileName, TemplateViewConfiguration view)
    {
        var extension = Path.GetExtension(fileName);
        if (!AllowedExtensions(view.BulkFileFormat).Contains(extension, StringComparer.OrdinalIgnoreCase))
            throw new InvalidOperationException($"This upload is configured for {Describe(view.BulkFileFormat)}; '{Path.GetFileName(fileName)}' has a different type.");
    }

    public static List<Dictionary<string, string>> Read(Stream stream, string fileName, TemplateViewConfiguration view)
    {
        EnsureExtension(fileName, view);
        if (Normalize(view.BulkFileFormat) == "Excel") return ReadExcel(stream);
        using var reader = new StreamReader(stream, Encoding.UTF8, true);
        var delimiter = string.IsNullOrEmpty(view.BulkFileDelimiter) ? (char?)null : view.BulkFileDelimiter[0];
        return CsvParser.Parse(reader.ReadToEnd(), delimiter);
    }

    private static List<Dictionary<string, string>> ReadExcel(Stream stream)
    {
        try
        {
            using var workbook = new XLWorkbook(stream);
            var sheet = workbook.Worksheets.FirstOrDefault(x => x.Visibility == XLWorksheetVisibility.Visible)
                ?? throw new InvalidOperationException("The Excel workbook has no visible worksheet.");
            var used = sheet.RangeUsed();
            if (used is null) return [];
            var firstRow = used.FirstRow().RowNumber();
            var lastRow = used.LastRow().RowNumber();
            var firstColumn = used.FirstColumn().ColumnNumber();
            var lastColumn = used.LastColumn().ColumnNumber();
            if (lastColumn - firstColumn + 1 > MaxColumns) throw new InvalidOperationException($"The worksheet has more than {MaxColumns} columns.");
            if (lastRow - firstRow > MaxRows) throw new InvalidOperationException($"The worksheet has more than {MaxRows:N0} data rows.");

            var headers = Enumerable.Range(firstColumn, lastColumn - firstColumn + 1).Select(c => CellText(sheet.Cell(firstRow, c)).Trim()).ToArray();
            if (headers.Any(string.IsNullOrWhiteSpace) || headers.Distinct(StringComparer.OrdinalIgnoreCase).Count() != headers.Length)
                throw new InvalidOperationException("The worksheet header row must contain non-empty, unique column names.");

            var rows = new List<Dictionary<string, string>>();
            for (var r = firstRow + 1; r <= lastRow; r++)
            {
                var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                for (var i = 0; i < headers.Length; i++) row[headers[i]] = CellText(sheet.Cell(r, firstColumn + i)).Trim();
                if (row.Values.Any(x => x.Length > 0)) rows.Add(row);
            }
            return rows;
        }
        catch (InvalidOperationException) { throw; }
        catch (Exception)
        {
            // The workbook library throws several unrelated exception types for corrupt or unsupported files.
            throw new InvalidOperationException("The file is not a valid Excel .xlsx workbook.");
        }
    }

    // Cached formula results are used so uploads never evaluate workbook formulas.
    private static string CellText(IXLCell cell)
    {
        if (cell.IsEmpty()) return "";
        var value = cell.HasFormula ? cell.CachedValue : cell.Value;
        if (value.IsBlank) return "";
        if (value.IsDateTime)
        {
            var date = value.GetDateTime();
            return date.TimeOfDay == TimeSpan.Zero ? date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : date.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
        }
        if (value.IsNumber) return value.GetNumber().ToString("0.############", CultureInfo.InvariantCulture);
        if (value.IsBoolean) return value.GetBoolean() ? "true" : "false";
        return value.ToString(CultureInfo.InvariantCulture);
    }

    /// <summary>Builds a sample file in the configured format with the given header row and one example row.</summary>
    public static (byte[] Content, string ContentType, string Extension) BuildSample(TemplateViewConfiguration view, IReadOnlyList<string> headers, IReadOnlyList<string> example)
    {
        if (Normalize(view.BulkFileFormat) == "Excel")
        {
            using var workbook = new XLWorkbook();
            var sheet = workbook.Worksheets.Add("Alerts");
            for (var i = 0; i < headers.Count; i++)
            {
                sheet.Cell(1, i + 1).SetValue(headers[i]);
                sheet.Cell(2, i + 1).SetValue(example[i]);
            }
            using var memory = new MemoryStream();
            workbook.SaveAs(memory);
            return (memory.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx");
        }
        var delimiter = string.IsNullOrEmpty(view.BulkFileDelimiter) ? ',' : view.BulkFileDelimiter[0];
        string Cell(string value) => value.Contains(delimiter) || value.Contains('"') || value.Contains('\n') ? "\"" + value.Replace("\"", "\"\"") + "\"" : value;
        var text = new StringBuilder()
            .AppendLine(string.Join(delimiter, headers.Select(Cell)))
            .AppendLine(string.Join(delimiter, example.Select(Cell))).ToString();
        var extension = Normalize(view.BulkFileFormat) == "Txt" ? ".txt" : ".csv";
        return (Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(text)).ToArray(), extension == ".txt" ? "text/plain" : "text/csv", extension);
    }
}
