namespace CATS.Api;

public sealed class JwtOptions
{
    public string Issuer { get; set; } = "CATS";
    public string Audience { get; set; } = "CATS.Web";
    public string SigningKey { get; set; } = "";
    public int ExpiryMinutes { get; set; } = 60;
    /// <summary>Longest a session can last in total, however active the user is: each refresh extends it by ExpiryMinutes but never past this from sign-in.</summary>
    public int MaxSessionMinutes { get; set; } = 480;
}

public sealed class StorageOptions
{
    public string AttachmentRoot { get; set; } = "App_Data/attachments";
    public long MaxFileSizeBytes { get; set; } = 20 * 1024 * 1024;
    public string[] AllowedExtensions { get; set; } = [".pdf",".png",".jpg",".jpeg",".doc",".docx",".xls",".xlsx",".csv",".txt"];
}

public sealed class DatabaseStartupOptions
{
    public bool AutoInitialize { get; set; } = true;
}

public sealed class GatewayAccessOptions
{
    public bool RequireForApi { get; set; } = true;
    public string HeaderName { get; set; } = "X-CATS-Gateway-Key";
    public string SharedKey { get; set; } = "cats-dev-gateway-key-change-me";
}

public sealed class SpeechToTextOptions
{
    public bool Enabled { get; set; }
    public string ModelPath { get; set; } = "App_Data/models/ggml-small.bin";
    public string Language { get; set; } = "auto";
    public long MaxAudioBytes { get; set; } = 25_000_000;
}
