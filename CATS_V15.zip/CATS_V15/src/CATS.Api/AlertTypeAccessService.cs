using CATS.Core;
using CATS.Infrastructure;

namespace CATS.Api;

/// <summary>Decides which Alert Types a user may pick, from the AlertTypeAccess table (see <see cref="AlertTypeAccess"/>).</summary>
public sealed class AlertTypeAccessService(AdoHelper db)
{
    public async Task<List<AlertTypeAccessRule>> RulesAsync(CancellationToken ct) =>
        await db.QueryAsync(
            "SELECT TemplateCode,RoleCode,PermissionCode FROM AlertTypeAccess WHERE IsActive=1",
            r => new AlertTypeAccessRule { TemplateCode = r.Str("TemplateCode"), RoleCode = r.NStr("RoleCode"), PermissionCode = r.NStr("PermissionCode") }, ct: ct);

    public async Task<List<TemplateRecord>> FilterAsync(IEnumerable<TemplateRecord> templates, CurrentUser user, CancellationToken ct)
    {
        if (AlertTypeAccess.SeesAll(user.HasPermission)) return templates.ToList();
        var rules = await RulesAsync(ct);
        return templates.Where(x => AlertTypeAccess.IsVisible(rules, x.Code, user.RoleCode, user.HasPermission)).ToList();
    }

    /// <summary>Throws when the user may not create or upload alerts of this type.</summary>
    public async Task EnsureAsync(string templateCode, CurrentUser user, CancellationToken ct)
    {
        if (AlertTypeAccess.SeesAll(user.HasPermission)) return;
        if (!AlertTypeAccess.IsVisible(await RulesAsync(ct), templateCode, user.RoleCode, user.HasPermission))
            throw new UnauthorizedAccessException($"Your role does not have access to the {templateCode} alert type.");
    }

    /// <summary>The roles an Alert Type is limited to; an empty list with Everyone=true means it is open to all roles.</summary>
    public async Task<(bool Everyone, List<string> Roles)> GetRolesAsync(string templateCode, CancellationToken ct)
    {
        var rules = (await RulesAsync(ct)).Where(x => x.TemplateCode.Equals(templateCode, StringComparison.OrdinalIgnoreCase)).ToList();
        var roles = rules.Where(x => !string.IsNullOrWhiteSpace(x.RoleCode) && string.IsNullOrWhiteSpace(x.PermissionCode))
            .Select(x => x.RoleCode!).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        return (rules.Count == 0, roles);
    }

    /// <summary>
    /// Replaces the access rows of one Alert Type. "Everyone" removes them; otherwise each role gets a row, plus the view-all permission
    /// row so central reviewers can still see the Alert Type (the same pattern as the seeded modules).
    /// </summary>
    public async Task SetRolesAsync(string templateCode, bool everyone, IEnumerable<string> roles, CancellationToken ct)
    {
        await db.ExecuteAsync($"DELETE FROM AlertTypeAccess WHERE TemplateCode={db.Dialect.P("Template")}", [new("Template", templateCode)], ct);
        if (everyone) return;
        var rows = roles.Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => (Role: (string?)x.Trim(), Permission: (string?)null))
            .Append((Role: null, Permission: CatsPermissions.AlertViewAll));
        foreach (var row in rows)
            await db.ExecuteAsync(
                $"INSERT INTO AlertTypeAccess(Id,TemplateCode,RoleCode,PermissionCode,IsActive) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Template")},{db.Dialect.P("Role")},{db.Dialect.P("Permission")},1)",
                [new("Id", CatsId.Next()), new("Template", templateCode), new("Role", row.Role), new("Permission", row.Permission)], ct);
    }
}
