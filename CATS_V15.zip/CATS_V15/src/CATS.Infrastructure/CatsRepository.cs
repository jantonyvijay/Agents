using System.Data.Common;
using System.Text.Json;
using System.Text.Json.Nodes;
using CATS.Core;

namespace CATS.Infrastructure;

public sealed class CatsRepository(AdoHelper db) : ICatsRepository
{
    private readonly TemplateDataTableService dataTables = new(db);

    private sealed record RepositoryRoute(string ModuleCode, string MethodCode);

    private static readonly IReadOnlyDictionary<string,RepositoryRoute> Routes =
        new Dictionary<string,RepositoryRoute>(StringComparer.OrdinalIgnoreCase)
    {
        ["GetUserByUserName"] = new("User", "GetByUserName"),
        ["GetUserById"] = new("User", "GetById"),
        ["GetUsers"] = new("User", "GetAll"),
        ["UpsertUser"] = new("User", "Upsert"),
        ["GetTemplates"] = new("Template", "GetAll"),
        ["GetTemplate"] = new("Template", "GetById"),
        ["SaveTemplate"] = new("Template", "Save"),
        ["GetWorkflow"] = new("Workflow", "GetById"),
        ["GetPublishedWorkflowForTemplate"] = new("Workflow", "GetPublishedByTemplate"),
        ["SaveWorkflow"] = new("Workflow", "Save"),
        ["InsertAlert"] = new("Alert", "Insert"),
        ["InsertWorkflowInstance"] = new("WorkflowInstance", "Insert"),
        ["UpdateWorkflowInstance"] = new("WorkflowInstance", "Update"),
        ["TryClaimStageTransition"] = new("WorkflowInstance", "TryClaimStageTransition"),
        ["ReleaseStageTransitionClaim"] = new("WorkflowInstance", "ReleaseStageTransitionClaim"),
        ["UpdateAlertStage"] = new("Alert", "UpdateStage"),
        ["UpdateAlertDynamicData"] = new("Alert", "UpdateDynamicData"),
        ["GetAlert"] = new("Alert", "GetById"),
        ["GetWorkflowInstanceByAlert"] = new("WorkflowInstance", "GetByAlert"),
        ["InsertWorkItems"] = new("WorkItem", "Insert"),
        ["GetPendingWorkItems"] = new("WorkItem", "GetPending"),
        ["GetWorkItem"] = new("WorkItem", "GetById"),
        ["GetWorkItems"] = new("WorkItem", "GetAllByAlert"),
        ["CompleteWorkItem"] = new("WorkItem", "Complete"),
        ["ReassignPendingWorkItems"] = new("WorkItem", "ReassignPending"),
        ["CancelPendingWorkItems"] = new("WorkItem", "CancelPending"),
        ["GetParallelWorkItems"] = new("WorkItem", "GetParallel"),
        ["InsertQuery"] = new("Query", "Insert"),
        ["RespondLatestOpenQuery"] = new("Query", "RespondLatestOpen"),
        ["GetQueries"] = new("Query", "GetAllByAlert"),
        ["InsertAttachment"] = new("Attachment", "Insert"),
        ["GetAttachments"] = new("Attachment", "GetAllByAlert"),
        ["GetAttachment"] = new("Attachment", "GetById"),
        ["InsertAudit"] = new("Audit", "Insert"),
        ["GetAudit"] = new("Audit", "GetByAlert"),
        ["GetAgingBuckets"] = new("Aging", "GetBuckets"),
        ["SaveAgingBucket"] = new("Aging", "SaveBucket"),
        ["GetDashboardAging"] = new("Dashboard", "GetAging"),
        ["GetAlertsCount"] = new("Alert", "GetCount"),
        ["GetAlerts"] = new("Alert", "GetPaged"),
        ["GetTemplateName"] = new("Template", "GetName")
    };

    private static string NewId() => Guid.NewGuid().ToString("N");

    public Task<UserRecord?> GetUserByUserNameAsync(string userName, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetUserByUserName", MapUser, new { userName }, ct);

    public Task<UserRecord?> GetUserByIdAsync(long id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetUserById", MapUser, new { id }, ct);

    public Task<IReadOnlyList<UserRecord>> GetUsersAsync(CancellationToken ct = default) =>
        QueryOperationAsync("GetUsers", MapUser, null, ct);

    public Task UpsertUserAsync(UserRecord user, bool isNew, CancellationToken ct = default) =>
        ExecuteOperationAsync("UpsertUser", new
        {
            isNew, user.Id, user.UserName, user.DisplayName, user.PasswordHash, user.RoleCode,
            user.DepartmentCode, user.BranchCode, user.PermissionsJson, user.IsActive
        }, ct);

    public Task<IReadOnlyList<TemplateRecord>> GetTemplatesAsync(CancellationToken ct = default) =>
        QueryOperationAsync("GetTemplates", MapTemplate, null, ct);

    public Task<TemplateRecord?> GetTemplateAsync(long id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetTemplate", MapTemplate, new { id }, ct);

    public async Task<TemplateRecord> SaveTemplateAsync(SaveTemplateRequest request, CurrentUser user, CancellationToken ct = default)
    {
        // IMPORTANT: send template configuration as nested JSON, not JSON encoded inside strings.
        // SQL Server JSON_VALUE returns at most nvarchar(4000). When FieldsJson/ViewConfigurationJson
        // were sent as escaped strings, large template definitions were read as NULL by JSON_VALUE
        // and the save procedure silently fell back to [] / {}. JSON_QUERY can preserve nvarchar(max)
        // when the values are real JSON arrays/objects. The SQL hotfix also remains backward compatible
        // with callers that still send the legacy string shape.
        object assignmentRulesPayload = request.AssignmentRules.ValueKind == JsonValueKind.Undefined
            ? Array.Empty<object>()
            : request.AssignmentRules;

        var saved = await QuerySingleOperationAsync("SaveTemplate", MapTemplate, new
        {
            request.Id,
            request.Code,
            request.Name,
            executionMode = request.ExecutionMode.ToString(),
            sectionsJson = request.Sections,
            fieldsJson = request.Fields,
            viewConfigurationJson = request.ViewConfiguration,
            assignmentRulesJson = assignmentRulesPayload,
            createdBy = user.UserName,
            nowUtc = DateTime.UtcNow
        }, ct);
        return saved ?? throw new InvalidOperationException("The template was not returned after it was saved.");
    }

    public Task RetireTemplateAsync(long id, CancellationToken ct = default) =>
        db.ExecuteAsync($"UPDATE Templates SET Status={db.Dialect.P("Status")} WHERE Id={db.Dialect.P("Id")}",
            [new("Status", TemplateStatus.Retired.ToString()), new("Id", id)], ct);

    public Task<WorkflowDefinitionRecord?> GetWorkflowAsync(long id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetWorkflow", MapWorkflow, new { id }, ct);

    public Task<WorkflowDefinitionRecord?> GetPublishedWorkflowForTemplateAsync(long templateId, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetPublishedWorkflowForTemplate", MapWorkflow, new { templateId }, ct);

    public async Task<WorkflowDefinitionRecord> SaveWorkflowAsync(SaveWorkflowRequest request, CurrentUser user, CancellationToken ct = default)
    {
        ValidateWorkflow(request.Definition);
        var saved = await QuerySingleOperationAsync("SaveWorkflow", MapWorkflow, new
        {
            request.TemplateId,
            request.Name,
            definitionJson = JsonSerializer.Serialize(request.Definition, JsonDefaults.Options),
            request.Publish,
            createdBy = user.UserName,
            nowUtc = DateTime.UtcNow
        }, ct);
        return saved ?? throw new InvalidOperationException("The workflow was not returned after it was saved.");
    }

    public async Task<IReadOnlyList<long>> MigrateRunningWorkflowInstancesAsync(
        long templateId,
        WorkflowDefinitionRecord workflow,
        WorkflowDefinitionModel definition,
        CancellationToken ct = default)
    {
        var instances = await db.QueryAsync(
            $"SELECT wi.Id,wi.AlertId,wi.WorkflowDefinitionId,wi.WorkflowVersion,wi.Status,wi.CurrentStageId,wi.StartedAtUtc,wi.UpdatedAtUtc " +
            $"FROM WorkflowInstances wi INNER JOIN WorkflowDefinitions wd ON wd.Id=wi.WorkflowDefinitionId " +
            $"WHERE wd.TemplateId={db.Dialect.P("Template")} AND wi.Status='Running' AND wi.WorkflowDefinitionId<>{db.Dialect.P("Workflow")}",
            MapInstance,
            [new("Template", templateId), new("Workflow", workflow.Id)],
            ct);
        var validStages = definition.Stages.Select(stage => stage.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var now = DateTime.UtcNow;
        var migrated = new List<long>();
        foreach (var instance in instances.Where(instance => validStages.Contains(instance.CurrentStageId)))
        {
            instance.WorkflowDefinitionId = workflow.Id;
            instance.WorkflowVersion = workflow.Version;
            instance.UpdatedAtUtc = now;
            await UpdateWorkflowInstanceAsync(instance, ct);
            var stage = definition.GetStage(instance.CurrentStageId);
            await db.ExecuteAsync(
                $"UPDATE WorkItems SET StageName={db.Dialect.P("StageName")},AssignedRoleCode={db.Dialect.P("RoleCode")} " +
                $"WHERE WorkflowInstanceId={db.Dialect.P("InstanceId")} AND StageId={db.Dialect.P("StageId")} " +
                $"AND Status='Pending' AND AssignedUserId IS NULL",
                [
                    new("StageName", stage.Name),
                    new("RoleCode", stage.RoleCode),
                    new("InstanceId", instance.Id),
                    new("StageId", stage.Id)
                ],
                ct);
            migrated.Add(instance.AlertId);
        }
        return migrated;
    }

    public async Task<AlertRecord> InsertAlertAsync(AlertRecord alert, CancellationToken ct = default)
    {
        // Alerts are intentionally a workflow/index record.  Persist the payload
        // separately so that generic modules and ATM source tables own business data.
        var data = alert.DynamicDataJson;
        alert.DynamicDataJson = "{}";
        await ExecuteOperationAsync("InsertAlert", alert, ct);
        await SaveAlertDataAsync(alert.Id, alert.TemplateId, alert.AlertType, data, ct);
        alert.DynamicDataJson = data;
        return alert;
    }

    public async Task<WorkflowInstanceRecord> InsertWorkflowInstanceAsync(WorkflowInstanceRecord instance, CancellationToken ct = default)
    {
        await ExecuteOperationAsync("InsertWorkflowInstance", instance, ct);
        return instance;
    }

    public Task UpdateWorkflowInstanceAsync(WorkflowInstanceRecord instance, CancellationToken ct = default) =>
        ExecuteOperationAsync("UpdateWorkflowInstance", instance, ct);

    public async Task<bool> TryClaimStageTransitionAsync(long instanceId, string expectedStageId, CancellationToken ct = default) =>
        await QuerySingleOperationAsync("TryClaimStageTransition", r => r.Bool("Claimed"),
            new { instanceId, expectedStageId, nowUtc = DateTime.UtcNow }, ct);

    public Task ReleaseStageTransitionClaimAsync(long instanceId, string expectedStageId, CancellationToken ct = default) =>
        ExecuteOperationAsync("ReleaseStageTransitionClaim", new { instanceId, expectedStageId, nowUtc = DateTime.UtcNow }, ct);

    public Task UpdateAlertStageAsync(long alertId, string stageId, string stageName, AlertStatus status, DateTime enteredAtUtc, CancellationToken ct = default) =>
        ExecuteOperationAsync("UpdateAlertStage", new { alertId, stageId, stageName, status = status.ToString(), enteredAtUtc }, ct);

    public async Task UpdateAlertDynamicDataAsync(long alertId, string dynamicDataJson, CancellationToken ct = default)
    {
        var alert = await GetAlertMetadataAsync(alertId, ct) ?? throw new KeyNotFoundException("Alert not found.");
        await SaveAlertDataAsync(alertId, alert.TemplateId, alert.AlertType, dynamicDataJson, ct);
    }

    public async Task<AlertRecord?> GetAlertAsync(long alertId, CancellationToken ct = default)
    {
        var alert = await GetAlertMetadataAsync(alertId, ct);
        if (alert is not null) alert.DynamicDataJson = await LoadAlertDataAsync(alert, ct);
        return alert;
    }

    public Task<AlertModuleRecord?> GetAlertModuleRecordAsync(long alertId, string moduleCode, CancellationToken ct = default) =>
        db.QuerySingleAsync(
            $"SELECT AlertId,ModuleCode,DataJson,UpdatedAtUtc FROM AlertModuleRecords WHERE AlertId={db.Dialect.P("Alert")} AND ModuleCode={db.Dialect.P("Module")}",
            r => new AlertModuleRecord { AlertId = r.Lng("AlertId"), ModuleCode = r.Str("ModuleCode"), DataJson = r.Str("DataJson"), UpdatedAtUtc = r.Dt("UpdatedAtUtc") },
            [new("Alert", alertId), new("Module", moduleCode)], ct);

    public Task<WorkflowInstanceRecord?> GetWorkflowInstanceByAlertAsync(long alertId, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetWorkflowInstanceByAlert", MapInstance, new { alertId }, ct);

    public Task InsertWorkItemsAsync(IEnumerable<WorkItemRecord> items, CancellationToken ct = default) =>
        ExecuteOperationAsync("InsertWorkItems", new { items = items.ToList() }, ct);

    public Task<IReadOnlyList<WorkItemRecord>> GetPendingWorkItemsAsync(long alertId, CancellationToken ct = default) =>
        QueryOperationAsync("GetPendingWorkItems", MapWorkItem, new { alertId }, ct);

    public Task<IReadOnlyList<WorkItemRecord>> GetWorkItemsAsync(long alertId, CancellationToken ct = default) =>
        QueryOperationAsync("GetWorkItems", MapWorkItem, new { alertId }, ct);

    public Task<WorkItemRecord?> GetWorkItemAsync(long id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetWorkItem", MapWorkItem, new { id }, ct);

    public Task CompleteWorkItemAsync(long id, string action, CurrentUser user, string? remarks, CancellationToken ct = default) =>
        ExecuteOperationAsync("CompleteWorkItem", new { id, action, completedBy = user.UserName, remarks, nowUtc = DateTime.UtcNow }, ct);

    public Task ReassignPendingWorkItemsAsync(long alertId, string stageId, string? roleCode, string? branchCode, long? userId, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(roleCode) && userId is null)
            throw new InvalidOperationException("RoleCode or UserId is required for reassignment.");
        return ExecuteOperationAsync("ReassignPendingWorkItems", new
        {
            alertId, stageId, roleCode = roleCode ?? "", branchCode = branchCode ?? "", userId
        }, ct);
    }

    public Task CancelPendingWorkItemsAsync(long alertId, string? parallelGroupId, CancellationToken ct = default) =>
        ExecuteOperationAsync("CancelPendingWorkItems", new { alertId, groupId = parallelGroupId }, ct);

    public Task<IReadOnlyList<WorkItemRecord>> GetParallelWorkItemsAsync(long alertId, string parallelGroupId, CancellationToken ct = default) =>
        QueryOperationAsync("GetParallelWorkItems", MapWorkItem, new { alertId, parallelGroupId }, ct);

    public Task InsertQueryAsync(QueryRecord query, CancellationToken ct = default) =>
        ExecuteOperationAsync("InsertQuery", query, ct);

    public Task RespondLatestOpenQueryAsync(long alertId, CurrentUser user, string responseText, CancellationToken ct = default) =>
        ExecuteOperationAsync("RespondLatestOpenQuery", new
        {
            alertId, responseText, respondedBy = user.UserName, nowUtc = DateTime.UtcNow
        }, ct);

    public Task<IReadOnlyList<QueryRecord>> GetQueriesAsync(long alertId, CancellationToken ct = default) =>
        QueryOperationAsync("GetQueries", MapQuery, new { alertId }, ct);

    public Task InsertAttachmentAsync(AttachmentRecord attachment, CancellationToken ct = default) =>
        ExecuteOperationAsync("InsertAttachment", attachment, ct);

    public Task<IReadOnlyList<AttachmentRecord>> GetAttachmentsAsync(long alertId, CancellationToken ct = default) =>
        QueryOperationAsync("GetAttachments", MapAttachment, new { alertId }, ct);

    public Task<AttachmentRecord?> GetAttachmentAsync(long id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetAttachment", MapAttachment, new { id }, ct);

    public Task InsertAuditAsync(AuditRecord audit, CancellationToken ct = default) =>
        ExecuteOperationAsync("InsertAudit", audit, ct);

    public async Task<IReadOnlyList<AuditRecord>> GetTemplateAuditAsync(long templateId, int page, int pageSize, CancellationToken ct = default) =>
        await db.QueryAsync(db.Dialect.ApplyPagination(
            $"SELECT a.* FROM AuditLog a WHERE (a.EntityType='Template' AND a.EntityId={db.Dialect.P("TemplateKey")}) " +
            $"OR (a.EntityType='WorkflowDefinition' AND EXISTS (SELECT 1 FROM WorkflowDefinitions w WHERE {db.Dialect.CastIdToText("w.Id")}=a.EntityId AND w.TemplateId={db.Dialect.P("TemplateId")})) " +
            "ORDER BY a.CreatedAtUtc DESC,a.Id DESC", Math.Clamp(page,1,100000), Math.Clamp(pageSize,1,100)),
            MapAudit,[new("TemplateKey",templateId.ToString(System.Globalization.CultureInfo.InvariantCulture)),new("TemplateId",templateId)],ct);

    public Task<IReadOnlyList<AuditRecord>> GetAuditAsync(long alertId, int take = 100, CancellationToken ct = default) =>
        QueryOperationAsync("GetAudit", MapAudit, new { alertId, take = Math.Clamp(take, 1, 500) }, ct);

    public Task<IReadOnlyList<AgingBucket>> GetAgingBucketsAsync(CancellationToken ct = default) =>
        QueryOperationAsync("GetAgingBuckets", MapAgingBucket, null, ct);

    public Task SaveAgingBucketAsync(SaveAgingBucketRequest request, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(request.Name)) throw new InvalidOperationException("Aging bucket name is required.");
        if (request.FromDays < 0 || (request.ToDays.HasValue && request.ToDays.Value < request.FromDays))
            throw new InvalidOperationException("Invalid aging range.");
        return ExecuteOperationAsync("SaveAgingBucket", new
        {
            id = request.Id ?? CatsId.Next(),
            isNew = request.Id is null,
            name = request.Name.Trim(), request.FromDays, request.ToDays, request.DisplayOrder, request.IsActive
        }, ct);
    }

    public async Task<DashboardAgingResponse> GetDashboardAgingAsync(CurrentUser user, AlertListFilter? filter = null, CancellationToken ct = default)
    {
        var buckets = (await GetAgingBucketsAsync(ct)).ToList();
        // The Dashboard shows each user their own workload, even for users who may view every alert elsewhere.
        filter = new AlertListFilter
        {
            TemplateId = filter?.TemplateId, AlertType = filter?.AlertType, BranchCode = filter?.BranchCode, Status = filter?.Status,
            RecordView = "All", ScopeToMe = true
        };
        var raw = await QueryOperationAsync("GetDashboardAging", r => new DashboardAgingSource(
            r.Lng("TemplateId"), r.Str("TemplateName"), r.Str("AlertType"), r.Dt("StageEnteredAtUtc")),
            CreateAlertFilterInput(filter, user), ct);
        var response = new DashboardAgingResponse { Buckets = buckets };
        foreach (var group in raw.GroupBy(x => new { x.TemplateId, x.TemplateName, x.AlertType }))
        {
            var row = new DashboardAgingRow
            {
                TemplateId = group.Key.TemplateId, TemplateName = group.Key.TemplateName, AlertType = group.Key.AlertType
            };
            foreach (var bucket in buckets) row.Counts[bucket.Name] = 0;
            foreach (var item in group)
            {
                var age = Math.Max(0, (int)Math.Floor((DateTime.UtcNow - item.EnteredAtUtc).TotalDays));
                var bucket = buckets.FirstOrDefault(b => age >= b.FromDays && (!b.ToDays.HasValue || age <= b.ToDays.Value));
                if (bucket != null) row.Counts[bucket.Name]++;
                row.Total++;
            }
            response.Rows.Add(row);
        }
        return response;
    }

    public async Task<PagedResult<AlertListItem>> GetAlertsAsync(AlertListFilter filter, CurrentUser user, Func<string, string> decrypt, Func<string, string> mask, CancellationToken ct = default)
    {
        filter.Page = Math.Max(1, filter.Page);
        filter.PageSize = Math.Clamp(filter.PageSize, 10, 100);
        var input = CreateAlertFilterInput(filter, user);
        var totalRecords = await ScalarOperationAsync<int>("GetAlertsCount", input, ct);
        var rows = await QueryOperationAsync("GetAlerts", r =>
        {
            var customer = SafeDecrypt(r.Str("CustomerIdEncrypted"), decrypt);
            var account = SafeDecrypt(r.Str("AccountIdEncrypted"), decrypt);
            return new AlertListItem
            {
                Id = r.Lng("Id"), TemplateId = r.Lng("TemplateId"), AlertNo = r.Str("AlertNo"), TemplateName = r.Str("TemplateName"),
                AlertType = r.Str("AlertType"), BranchCode = r.Str("BranchCode"),
                CustomerId = mask(customer),
                AccountId = mask(account),
                CurrentStageName = r.Str("CurrentStageName"), Status = r.Str("Status"), Priority = r.Str("Priority"),
                OverallAgingDays = r.Int("OverallAge"), StageAgingDays = r.Int("StageAge"), DynamicDataJson = r.Str("DynamicDataJson")
            };
        }, input, ct);
        foreach (var row in rows)
        {
            var alert = new AlertRecord { Id = row.Id, TemplateId = row.TemplateId, AlertType = row.AlertType };
            row.DynamicDataJson = await LoadAlertDataAsync(alert, ct);
        }
        return new PagedResult<AlertListItem>
        {
            Page = filter.Page, PageSize = filter.PageSize, TotalRecords = totalRecords, Data = rows.ToList()
        };
    }

    public async Task<string> GetTemplateNameAsync(long templateId, CancellationToken ct = default) =>
        await ScalarOperationAsync<string>("GetTemplateName", new { templateId }, ct) ?? "";

    public async Task<IReadOnlyList<string>> GetRoleCodesAsync(CancellationToken ct = default) =>
        await db.QueryAsync("SELECT Code AS RoleCode FROM RoleMaster WHERE IsActive=1 ORDER BY Code",
            r => r.Str("RoleCode"), ct: ct);

    private static object CreateAlertFilterInput(AlertListFilter? filter, CurrentUser user) => new
    {
        userId = user.Id,
        userName = user.UserName,
        recordView = filter?.RecordView ?? "All",
        roleCode = user.RoleCode,
        userBranchCode = user.BranchCode,
        canViewAll = user.HasPermission(CatsPermissions.AlertViewAll) && filter?.ScopeToMe != true,
        templateId = filter?.TemplateId,
        alertType = filter?.AlertType,
        filterBranchCode = filter?.BranchCode,
        status = filter?.Status,
        search = filter?.Search?.Trim(),
        systemFilters = string.IsNullOrWhiteSpace(filter?.ResolvedSystemFiltersJson) ? (JsonElement?)null : JsonDocument.Parse(filter.ResolvedSystemFiltersJson).RootElement.Clone(),
        dynamicFiltersJson = filter?.DynamicFiltersJson,
        agingFrom = filter?.AgingFrom,
        agingTo = filter?.AgingTo,
        page = filter?.Page ?? 1,
        pageSize = filter?.PageSize ?? 20
    };

    private static RepositoryRoute ResolveRoute(string operation) =>
        Routes.TryGetValue(operation, out var route)
            ? route
            : throw new InvalidOperationException($"No repository route is configured for Cats operation '{operation}'.");

    private Task<AlertRecord?> GetAlertMetadataAsync(long alertId, CancellationToken ct) =>
        QuerySingleOperationAsync("GetAlert", MapAlert, new { alertId }, ct);

    private static bool IsAtm(string alertType) =>
        alertType.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) ||
        alertType.Equals("ATM_OFFUS", StringComparison.OrdinalIgnoreCase);

    // Summary fields are used by the alert template but intentionally omitted from
    // the editable source-file mapping catalog. They still belong in case data.
    private static IEnumerable<AtmTableColumn> AtmCaseColumns(string templateCode,string provider) =>
        AtmTableColumns.For(templateCode,provider).Concat(new AtmTableColumn[] {
            new("ATMID",AtmColumnKind.Text,100),
            new("PenaltyMonth",AtmColumnKind.Text,20),
            new("PenaltyAmount",AtmColumnKind.Decimal)
        }).DistinctBy(column=>column.Name,StringComparer.OrdinalIgnoreCase);

    private static JsonObject MergeAtmCaseData(string templateCode,string provider,Dictionary<string,object?>? row)
    {
        var source=row is not null && row.TryGetValue("SourceDataJson",out var raw)?Convert.ToString(raw):null;
        var merged=ParseObject(source);
        if(row is not null)
            foreach(var column in AtmCaseColumns(templateCode,provider))
                if(row.TryGetValue(column.Name,out var value)) merged[column.Name]=JsonSerializer.SerializeToNode(value);
        return merged;
    }

    private async Task<string> LoadAlertDataAsync(AlertRecord alert, CancellationToken ct)
    {
        if (!IsAtm(alert.AlertType))
        {
            // A template with a generated data table reads from it; until its row exists (e.g. mid-copy) the JSON record still answers.
            var generated = alert.TemplateId == 0 ? null : await dataTables.GetByTemplateIdAsync(alert.TemplateId, ct);
            if (generated is not null && await dataTables.LoadAsync(generated, alert.Id, ct) is { } fromTable)
            {
                var routing = await GetAlertModuleRecordAsync(alert.Id, "WORKFLOW", ct);
                foreach (var item in ParseObject(routing?.DataJson))
                    if (item.Key.StartsWith("_", StringComparison.Ordinal)) fromTable[item.Key] = item.Value?.DeepClone();
                return fromTable.ToJsonString();
            }
            return (await GetAlertModuleRecordAsync(alert.Id, "GENERIC", ct))?.DataJson ?? "{}";
        }
        var templateCode = alert.AlertType.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? "ATM_ONUS" : "ATM_OFFUS";
        var table = templateCode == "ATM_ONUS" ? "tbl_ATM_Txn_Mntr_OnUs" : "tbl_ATM_Txn_Mntr_OFFUs";
        var row = await db.QuerySingleAsync(
            $"SELECT * FROM {table} WHERE AlertId={db.Dialect.P("Alert")}",
            reader =>
            {
                var data = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
                for (var index = 0; index < reader.FieldCount; index++)
                    if (!reader.IsDBNull(index)) data[reader.GetName(index)] = reader.GetValue(index);
                return data;
            }, [new("Alert", alert.Id)], ct);
        var merged = MergeAtmCaseData(templateCode,db.Dialect.Name,row);
        var workflow = await GetAlertModuleRecordAsync(alert.Id, "WORKFLOW", ct);
        foreach (var item in ParseObject(workflow?.DataJson))
            if (item.Key.StartsWith("_", StringComparison.Ordinal)) merged[item.Key] = item.Value?.DeepClone();
        return merged.ToJsonString();
    }

    private async Task SaveAlertDataAsync(long alertId, long templateId, string alertType, string dataJson, CancellationToken ct)
    {
        if (!IsAtm(alertType))
        {
            var generated = templateId == 0 ? null : await dataTables.GetByTemplateIdAsync(templateId, ct);
            if (generated is not null)
            {
                var payload = ParseObject(dataJson);
                await dataTables.SaveAsync(generated, alertId, payload, ct);
                var routing = new JsonObject();
                foreach (var item in payload.Where(x => x.Key.StartsWith("_", StringComparison.Ordinal))) routing[item.Key] = item.Value?.DeepClone();
                await ReplaceModuleRecordAsync(alertId, "WORKFLOW", routing.ToJsonString(), ct);
                return;
            }
            await ReplaceModuleRecordAsync(alertId, "GENERIC", dataJson, ct);
            return;
        }

        var templateCode = alertType.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? "ATM_ONUS" : "ATM_OFFUS";
        var table = templateCode == "ATM_ONUS" ? "tbl_ATM_Txn_Mntr_OnUs" : "tbl_ATM_Txn_Mntr_OFFUs";
        var data = ParseObject(dataJson);
        var values = AtmCaseColumns(templateCode, db.Dialect.Name)
            .Where(column => data.TryGetPropertyValue(column.Name, out _))
            .Select(column => (Column: column, Value: data[column.Name]?.ToString()))
            .ToList();
        if (values.Count > 0)
        {
            var args = new List<DbArg>();
            var updates = values.Select((item, index) =>
            {
                var name = $"Value{index}";
                args.Add(new DbArg(name, ConvertAtmValue(item.Column, item.Value)));
                return $"{item.Column.Name}={db.Dialect.P(name)}";
            });
            args.Add(new DbArg("Alert", alertId));
            await db.ExecuteAsync($"UPDATE {table} SET {string.Join(",", updates)} WHERE AlertId={db.Dialect.P("Alert")}", args, ct);
        }
        var workflow = new JsonObject();
        foreach (var item in data.Where(item => item.Key.StartsWith("_", StringComparison.Ordinal)))
            workflow[item.Key] = item.Value?.DeepClone();
        await ReplaceModuleRecordAsync(alertId, "WORKFLOW", workflow.ToJsonString(), ct);
    }

    private async Task ReplaceModuleRecordAsync(long alertId, string moduleCode, string dataJson, CancellationToken ct)
    {
        await db.ExecuteAsync(
            $"DELETE FROM AlertModuleRecords WHERE AlertId={db.Dialect.P("Alert")} AND ModuleCode={db.Dialect.P("Module")}",
            [new("Alert", alertId), new("Module", moduleCode)], ct);
        await db.ExecuteAsync(
            $"INSERT INTO AlertModuleRecords(AlertId,ModuleCode,DataJson,UpdatedAtUtc) VALUES({db.Dialect.P("Alert")},{db.Dialect.P("Module")},{db.Dialect.P("Data")},{db.Dialect.P("Now")})",
            [new("Alert", alertId), new("Module", moduleCode), new("Data", string.IsNullOrWhiteSpace(dataJson) ? "{}" : dataJson), new("Now", DateTime.UtcNow)], ct);
    }

    private static JsonObject ParseObject(string? json)
    {
        try { return JsonNode.Parse(string.IsNullOrWhiteSpace(json) ? "{}" : json) as JsonObject ?? new JsonObject(); }
        catch (JsonException) { return new JsonObject(); }
    }

    private static object? ConvertAtmValue(AtmTableColumn column, string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        return column.Kind switch
        {
            AtmColumnKind.DateTime when DateTime.TryParse(value, out var date) => date,
            AtmColumnKind.Int when int.TryParse(value, out var number) => number,
            AtmColumnKind.Decimal when decimal.TryParse(value, out var amount) => amount,
            AtmColumnKind.Bit => value.Equals("true", StringComparison.OrdinalIgnoreCase) || value == "1" || value.Equals("yes", StringComparison.OrdinalIgnoreCase),
            _ => value
        };
    }

    private static string JsonInput(object? input) =>
        JsonSerializer.Serialize(input ?? new { }, JsonDefaults.Options);

    private async Task<IReadOnlyList<T>> QueryOperationAsync<T>(string operation, Func<DbDataReader, T> map, object? input, CancellationToken ct)
    {
        var route = ResolveRoute(operation);
        return await db.QueryRepositoryAsync(route.ModuleCode, route.MethodCode, JsonInput(input), map, ct);
    }

    private Task<T?> QuerySingleOperationAsync<T>(string operation, Func<DbDataReader, T> map, object? input, CancellationToken ct)
    {
        var route = ResolveRoute(operation);
        return db.QuerySingleRepositoryAsync(route.ModuleCode, route.MethodCode, JsonInput(input), map, ct);
    }

    private Task<int> ExecuteOperationAsync(string operation, object? input, CancellationToken ct)
    {
        var route = ResolveRoute(operation);
        return db.ExecuteRepositoryAsync(route.ModuleCode, route.MethodCode, JsonInput(input), ct);
    }

    private Task<T?> ScalarOperationAsync<T>(string operation, object? input, CancellationToken ct)
    {
        var route = ResolveRoute(operation);
        return db.ScalarRepositoryAsync<T>(route.ModuleCode, route.MethodCode, JsonInput(input), ct);
    }

    private static string SafeDecrypt(string value, Func<string, string> decrypt)
    {
        try { return decrypt(value); }
        catch { return ""; }
    }

    private static void ValidateWorkflow(WorkflowDefinitionModel definition)
    {
        if (string.IsNullOrWhiteSpace(definition.StartStageId)) throw new InvalidOperationException("StartStageId is required.");
        if (definition.Stages.Count == 0) throw new InvalidOperationException("At least one workflow stage is required.");
        if (definition.Stages.Select(x => x.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() != definition.Stages.Count)
            throw new InvalidOperationException("Workflow stage IDs must be unique.");
        _ = definition.GetStage(definition.StartStageId);
        foreach (var stage in definition.Stages)
        {
            foreach (var transition in stage.Transitions.Where(x => !string.IsNullOrWhiteSpace(x.ToStageId)))
                _ = definition.GetStage(transition.ToStageId!);
            foreach (var condition in stage.Conditions) _ = definition.GetStage(condition.ToStageId);
            if (!string.IsNullOrWhiteSpace(stage.DefaultNextStageId)) _ = definition.GetStage(stage.DefaultNextStageId!);
            if (stage.Type == StageType.Human && string.IsNullOrWhiteSpace(stage.RoleCode))
                throw new InvalidOperationException($"Role is required for human stage {stage.Name}.");
            if (stage.Type == StageType.ParallelApproval && stage.Approvers.Count == 0)
                throw new InvalidOperationException($"Approvers are required for parallel stage {stage.Name}.");
        }
    }

    private static UserRecord MapUser(DbDataReader r) => new() { Id = r.Lng("Id"), UserName = r.Str("UserName"), DisplayName = r.Str("DisplayName"), PasswordHash = r.Str("PasswordHash"), RoleCode = r.Str("RoleCode"), DepartmentCode = r.Str("DepartmentCode"), BranchCode = r.Str("BranchCode"), PermissionsJson = r.Str("PermissionsJson"), IsActive = r.Bool("IsActive") };
    private static TemplateRecord MapTemplate(DbDataReader r) => new() { Id = r.Lng("Id"), Code = r.Str("Code"), Name = r.Str("Name"), Version = r.Int("Version"), Status = Enum.TryParse<TemplateStatus>(r.Str("Status"), true, out var s) ? s : TemplateStatus.Draft, ExecutionMode = Enum.TryParse<ExecutionMode>(r.Str("ExecutionMode"), true, out var m) ? m : ExecutionMode.Deterministic, SectionsJson = r.Str("SectionsJson"), FieldsJson = r.Str("FieldsJson"), AssignmentRulesJson = r.Str("AssignmentRulesJson"), ViewConfigurationJson = r.HasColumn("ViewConfigurationJson") ? r.Str("ViewConfigurationJson") : "{}", PublishedWorkflowId = r.NLng("PublishedWorkflowId"), CreatedAtUtc = r.Dt("CreatedAtUtc"), CreatedBy = r.Str("CreatedBy") };
    private static WorkflowDefinitionRecord MapWorkflow(DbDataReader r) => new() { Id = r.Lng("Id"), TemplateId = r.Lng("TemplateId"), Version = r.Int("Version"), Name = r.Str("Name"), DefinitionJson = r.Str("DefinitionJson"), IsPublished = r.Bool("IsPublished"), CreatedAtUtc = r.Dt("CreatedAtUtc"), CreatedBy = r.Str("CreatedBy") };
    private static AlertRecord MapAlert(DbDataReader r) => new() { Id = r.Lng("Id"), AlertNo = r.Str("AlertNo"), TemplateId = r.Lng("TemplateId"), TemplateVersion = r.Int("TemplateVersion"), AlertType = r.Str("AlertType"), BranchCode = r.Str("BranchCode"), CustomerIdEncrypted = r.Str("CustomerIdEncrypted"), AccountIdEncrypted = r.Str("AccountIdEncrypted"), DynamicDataJson = r.Str("DynamicDataJson"), Status = Enum.TryParse<AlertStatus>(r.Str("Status"), true, out var s) ? s : AlertStatus.New, CurrentStageId = r.Str("CurrentStageId"), CurrentStageName = r.Str("CurrentStageName"), CreatedAtUtc = r.Dt("CreatedAtUtc"), StageEnteredAtUtc = r.Dt("StageEnteredAtUtc"), CreatedBy = r.Str("CreatedBy"), Priority = r.Str("Priority") };
    private static WorkflowInstanceRecord MapInstance(DbDataReader r) => new() { Id = r.Lng("Id"), AlertId = r.Lng("AlertId"), WorkflowDefinitionId = r.Lng("WorkflowDefinitionId"), WorkflowVersion = r.Int("WorkflowVersion"), Status = r.Str("Status"), CurrentStageId = r.Str("CurrentStageId"), StartedAtUtc = r.Dt("StartedAtUtc"), UpdatedAtUtc = r.Dt("UpdatedAtUtc") };
    private static WorkItemRecord MapWorkItem(DbDataReader r) => new() { Id = r.Lng("Id"), AlertId = r.Lng("AlertId"), WorkflowInstanceId = r.Lng("WorkflowInstanceId"), StageId = r.Str("StageId"), StageName = r.Str("StageName"), AssignedRoleCode = r.Str("AssignedRoleCode"), AssignedBranchCode = r.Str("AssignedBranchCode"), AssignedUserId = r.NLng("AssignedUserId"), Status = Enum.TryParse<WorkItemStatus>(r.Str("Status"), true, out var s) ? s : WorkItemStatus.Pending, ParallelGroupId = r.NStr("ParallelGroupId"), CompletedAction = r.NStr("CompletedAction"), CompletedBy = r.NStr("CompletedBy"), CreatedAtUtc = r.Dt("CreatedAtUtc"), DueAtUtc = r.Dt("DueAtUtc"), CompletedAtUtc = r.NDt("CompletedAtUtc"), Remarks = r.NStr("Remarks") };
    private static QueryRecord MapQuery(DbDataReader r) => new() { Id = r.Lng("Id"), AlertId = r.Lng("AlertId"), RaisedBy = r.Str("RaisedBy"), RaisedToRole = r.Str("RaisedToRole"), QueryText = r.Str("QueryText"), ResponseText = r.NStr("ResponseText"), Status = r.Str("Status"), RaisedAtUtc = r.Dt("RaisedAtUtc"), RespondedAtUtc = r.NDt("RespondedAtUtc") };
    private static AttachmentRecord MapAttachment(DbDataReader r) => new() { Id = r.Lng("Id"), AlertId = r.Lng("AlertId"), StageId = r.Str("StageId"), FileName = r.Str("FileName"), StoredName = r.Str("StoredName"), ContentType = r.Str("ContentType"), FileSize = r.Lng("FileSize"), Sha256 = r.Str("Sha256"), Version = r.Int("Version"), UploadedBy = r.Str("UploadedBy"), UploadedAtUtc = r.Dt("UploadedAtUtc") };
    private static AuditRecord MapAudit(DbDataReader r) => new() { Id = r.Lng("Id"), AlertId = r.NLng("AlertId"), UserId = r.Lng("UserId"), UserName = r.Str("UserName"), RoleCode = r.Str("RoleCode"), Action = r.Str("Action"), EntityType = r.Str("EntityType"), EntityId = r.NStr("EntityId"), StageId = r.NStr("StageId"), PreviousValueJson = r.NStr("PreviousValueJson"), NewValueJson = r.NStr("NewValueJson"), Remarks = r.NStr("Remarks"), IpAddress = r.NStr("IpAddress"), CreatedAtUtc = r.Dt("CreatedAtUtc") };
    private static AgingBucket MapAgingBucket(DbDataReader r) => new() { Id = r.Lng("Id"), Name = r.Str("Name"), FromDays = r.Int("FromDays"), ToDays = r.NStr("ToDays") is null ? null : r.Int("ToDays"), DisplayOrder = r.Int("DisplayOrder") };

    private sealed record DashboardAgingSource(long TemplateId, string TemplateName, string AlertType, DateTime EnteredAtUtc);
}

public static class JsonDefaults
{
    public static readonly JsonSerializerOptions Options = Create();
    private static JsonSerializerOptions Create()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true, WriteIndented = true };
        options.Converters.Add(new System.Text.Json.Serialization.JsonStringEnumConverter());
        return options;
    }
}
