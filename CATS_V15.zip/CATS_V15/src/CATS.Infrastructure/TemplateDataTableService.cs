using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using CATS.Core;

namespace CATS.Infrastructure;

/// <summary>
/// Generates and uses a dedicated data table for a template (Alert Type), so a new template needs no code or hand-written SQL.
/// The table holds one typed column per template field plus a full JSON copy of the data (SourceDataJson), so a field added later is never
/// lost before its column exists. Existing columns are never dropped or narrowed. Generation is SQL Server only; ATM templates keep their own tables.
/// </summary>
public sealed partial class TemplateDataTableService(AdoHelper db)
{
    private static readonly SemaphoreSlim GenerationGate = new(1, 1);
    private const int BackfillBatch = 500;

    [GeneratedRegex("^[A-Za-z][A-Za-z0-9_]*$")]
    private static partial Regex Identifier();

    private string P(string name) => db.Dialect.P(name);

    /// <summary>Validated, bracket-quoted identifier. Names come from our own generator or the validated table name, never straight from a request.</summary>
    private static string Quote(string name) =>
        Identifier().IsMatch(name) && name.Length <= 128 ? $"[{name}]" : throw new InvalidOperationException($"'{name}' is not a valid column or table name.");

    public async Task<TemplateDataTableInfo?> GetAsync(string templateCode, CancellationToken ct = default)
    {
        var table = await db.ScalarAsync<string>($"SELECT TableName FROM TemplateDataTable WHERE TemplateCode={P("Code")}", [new("Code", templateCode)], ct);
        if (string.IsNullOrEmpty(table)) return null;
        var columns = await db.QueryAsync(
            $"SELECT FieldName,ColumnName,SqlType FROM TemplateDataColumn WHERE TemplateCode={P("Code")} ORDER BY ColumnName",
            r => new TemplateDataColumn(r.Str("FieldName"), r.Str("ColumnName"), r.Str("SqlType")), [new("Code", templateCode)], ct);
        return new TemplateDataTableInfo { TemplateCode = templateCode, TableName = table, Columns = columns };
    }

    private static DateTime registryMissingUntilUtc = DateTime.MinValue;

    private const string NotUpgradedMessage =
        "This database has not been upgraded for template data tables yet. Run db/sqlserver/schema.sql once (or start the API once with DatabaseStartup:AutoInitialize=true), then try again.";

    /// <summary>The registry table is missing on a database that has not been upgraded (DatabaseStartup:AutoInitialize=false).</summary>
    private static bool IsMissingObject(Microsoft.Data.SqlClient.SqlException ex) => ex.Number == 208;

    public async Task<TemplateDataTableInfo?> GetByTemplateIdAsync(long templateId, CancellationToken ct = default)
    {
        // Alert reads and writes ask this on every call. On a database without the registry the answer is simply "no table"
        // (the template keeps storing JSON), and the check is not repeated for a short while.
        if (DateTime.UtcNow < registryMissingUntilUtc) return null;
        try
        {
            var code = await db.ScalarAsync<string>($"SELECT d.TemplateCode FROM TemplateDataTable d JOIN Templates t ON t.Code=d.TemplateCode WHERE t.Id={P("Id")}", [new("Id", templateId)], ct);
            return string.IsNullOrEmpty(code) ? null : await GetAsync(code, ct);
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (IsMissingObject(ex))
        {
            registryMissingUntilUtc = DateTime.UtcNow.AddSeconds(30);
            return null;
        }
    }

    private async Task<bool> TableExistsAsync(string tableName, CancellationToken ct) =>
        await db.ScalarAsync<int>($"SELECT CASE WHEN OBJECT_ID({P("Name")},'U') IS NULL THEN 0 ELSE 1 END", [new("Name", "dbo." + tableName)], ct) == 1;

    private static List<TemplateField> FieldsOf(TemplateRecord template) =>
        JsonSerializer.Deserialize<List<TemplateField>>(template.FieldsJson, JsonDefaults.Options) ?? [];

    /// <summary>What Generate / Update would do for this template, without changing anything.</summary>
    public async Task<TemplateDataTablePlan> PlanAsync(TemplateRecord template, CancellationToken ct = default)
    {
        var plan = new TemplateDataTablePlan { TemplateCode = template.Code };
        if (TemplateDataTablePlanner.UsesLegacyTables(template.Code))
        {
            plan.Supported = false;
            plan.UnsupportedReason = "This Alert Type already has its own dedicated tables and keeps using them.";
            return plan;
        }
        if (db.Dialect.Name != "SqlServer")
        {
            plan.Supported = false;
            plan.UnsupportedReason = "Table generation is available for SQL Server only.";
            return plan;
        }
        TemplateDataTableInfo? existing;
        try { existing = await GetAsync(template.Code, ct); }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (IsMissingObject(ex)) { throw new InvalidOperationException(NotUpgradedMessage, ex); }
        plan.Generated = existing is not null;
        plan.TableNameEditable = existing is null;
        plan.TableName = existing?.TableName ?? TemplateDataTablePlanner.SuggestTableName(template.Code);
        plan.ExistingColumns = existing?.Columns ?? [];
        var (_, added, widened) = TemplateDataTablePlanner.Plan(FieldsOf(template), plan.ExistingColumns);
        plan.ColumnsToAdd = added;
        plan.ColumnsToWiden = widened;
        foreach (var column in plan.ExistingColumns)
            plan.ColumnTypeOptions[column.FieldName] = TemplateDataTablePlanner.TypeOptions(column.SqlType, column.SqlType);
        foreach (var column in added)
            plan.ColumnTypeOptions[column.FieldName] = TemplateDataTablePlanner.TypeOptions(null, column.SqlType);
        if (existing is null)
            plan.AlertsToCopy = await db.ScalarAsync<int>(
                $"SELECT COUNT(1) FROM Alerts a JOIN Templates t ON t.Id=a.TemplateId WHERE t.Code={P("Code")}", [new("Code", template.Code)], ct);
        return plan;
    }

    /// <summary>Creates the table (first time) or adds/widens columns (later), registers the field mapping and copies existing alerts into it.</summary>
    public async Task<TemplateDataTablePlan> EnsureAsync(TemplateRecord template, string? requestedTableName, string generatedBy,
        IReadOnlyDictionary<string, string>? chosenTypes = null, CancellationToken ct = default)
    {
        var before = await PlanAsync(template, ct);
        if (!before.Supported) throw new InvalidOperationException(before.UnsupportedReason);
        await GenerationGate.WaitAsync(ct);
        try
        {
            var existing = await GetAsync(template.Code, ct);
            var tableName = existing?.TableName ?? (string.IsNullOrWhiteSpace(requestedTableName) ? TemplateDataTablePlanner.SuggestTableName(template.Code) : requestedTableName.Trim());
            if (existing is null && TemplateDataTablePlanner.ValidateTableName(tableName) is { } invalid) throw new InvalidOperationException(invalid);
            var exists = await TableExistsAsync(tableName, ct);
            if (existing is null && exists)
                throw new InvalidOperationException($"A table named '{tableName}' already exists and is not managed by CATS. Choose another table name.");

            var (columns, added, widened) = TemplateDataTablePlanner.Plan(FieldsOf(template), existing?.Columns ?? [], chosenTypes);
            var table = Quote(tableName);
            if (!exists)
                await db.ExecuteAsync(
                    $"CREATE TABLE dbo.{table}(AlertId bigint NOT NULL PRIMARY KEY, SourceBatchId bigint NULL, SourceRowNumber int NULL, SourceDataJson nvarchar(max) NULL, " +
                    $"CreatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), UpdatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), " +
                    $"CONSTRAINT {Quote("FK_" + tableName + "_Alert")} FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id))", null, ct);
            if (added.Count > 0)
                await db.ExecuteAsync($"ALTER TABLE dbo.{table} ADD {string.Join(", ", added.Select(c => $"{Quote(c.ColumnName)} {c.SqlType} NULL"))}", null, ct);
            foreach (var column in widened)
                await db.ExecuteAsync($"ALTER TABLE dbo.{table} ALTER COLUMN {Quote(column.ColumnName)} {column.SqlType} NULL", null, ct);

            // Register only after the table really exists, so a reader never finds a registered table that is missing.
            var now = DateTime.UtcNow;
            if (existing is null)
                await db.ExecuteAsync(
                    $"INSERT INTO TemplateDataTable(TemplateCode,TableName,GeneratedAtUtc,UpdatedAtUtc,GeneratedBy) VALUES({P("Code")},{P("Table")},{P("Now")},{P("Now")},{P("By")})",
                    [new("Code", template.Code), new("Table", tableName), new("Now", now), new("By", generatedBy)], ct);
            else
                await db.ExecuteAsync($"UPDATE TemplateDataTable SET UpdatedAtUtc={P("Now")} WHERE TemplateCode={P("Code")}", [new("Now", now), new("Code", template.Code)], ct);
            foreach (var column in added)
                await db.ExecuteAsync(
                    $"INSERT INTO TemplateDataColumn(TemplateCode,FieldName,ColumnName,SqlType) VALUES({P("Code")},{P("Field")},{P("Column")},{P("Type")})",
                    [new("Code", template.Code), new("Field", column.FieldName), new("Column", column.ColumnName), new("Type", column.SqlType)], ct);
            foreach (var column in widened)
                await db.ExecuteAsync(
                    $"UPDATE TemplateDataColumn SET SqlType={P("Type")} WHERE TemplateCode={P("Code")} AND FieldName={P("Field")}",
                    [new("Type", column.SqlType), new("Code", template.Code), new("Field", column.FieldName)], ct);

            var info = new TemplateDataTableInfo { TemplateCode = template.Code, TableName = tableName, Columns = columns };
            if (existing is null) await CopyExistingAlertsAsync(info, ct);
            if (added.Count > 0 && existing is not null) await FillNewColumnsAsync(info, added, ct);

            var after = await PlanAsync(template, ct);
            after.AlertsToCopy = before.AlertsToCopy;
            return after;
        }
        finally { GenerationGate.Release(); }
    }

    /// <summary>First generation: alerts created while the template stored JSON are copied into the new table, together with their routing keys.</summary>
    private async Task CopyExistingAlertsAsync(TemplateDataTableInfo info, CancellationToken ct)
    {
        var table = Quote(info.TableName);
        while (true)
        {
            var batch = await db.QueryAsync(
                $"SELECT TOP {BackfillBatch} m.AlertId,m.DataJson FROM AlertModuleRecords m JOIN Alerts a ON a.Id=m.AlertId JOIN Templates t ON t.Id=a.TemplateId " +
                $"WHERE t.Code={P("Code")} AND m.ModuleCode='GENERIC' AND NOT EXISTS(SELECT 1 FROM dbo.{table} x WHERE x.AlertId=a.Id) ORDER BY m.AlertId",
                r => (AlertId: r.Lng("AlertId"), Json: r.Str("DataJson")), [new("Code", info.TemplateCode)], ct);
            if (batch.Count == 0) return;
            foreach (var (alertId, json) in batch)
            {
                var data = ParseObject(json);
                await SaveAsync(info, alertId, data, ct);
                var routing = new JsonObject();
                foreach (var item in data.Where(x => x.Key.StartsWith('_'))) routing[item.Key] = item.Value?.DeepClone();
                if (routing.Count > 0 && await db.ScalarAsync<int>($"SELECT COUNT(1) FROM AlertModuleRecords WHERE AlertId={P("A")} AND ModuleCode='WORKFLOW'", [new("A", alertId)], ct) == 0)
                    await db.ExecuteAsync(
                        $"INSERT INTO AlertModuleRecords(AlertId,ModuleCode,DataJson,UpdatedAtUtc) VALUES({P("A")},'WORKFLOW',{P("D")},{P("Now")})",
                        [new("A", alertId), new("D", routing.ToJsonString()), new("Now", DateTime.UtcNow)], ct);
            }
        }
    }

    /// <summary>Later update: rows that already exist get the new columns filled from their stored JSON copy.</summary>
    private async Task FillNewColumnsAsync(TemplateDataTableInfo info, IReadOnlyList<TemplateDataColumn> added, CancellationToken ct)
    {
        var table = Quote(info.TableName);
        long last = 0;
        while (true)
        {
            var batch = await db.QueryAsync(
                $"SELECT TOP {BackfillBatch} AlertId,SourceDataJson FROM dbo.{table} WHERE AlertId>{P("Last")} AND SourceDataJson IS NOT NULL ORDER BY AlertId",
                r => (AlertId: r.Lng("AlertId"), Json: r.Str("SourceDataJson")), [new("Last", last)], ct);
            if (batch.Count == 0) return;
            foreach (var (alertId, json) in batch)
            {
                last = alertId;
                var data = ParseObject(json);
                var sets = new List<string>();
                var args = new List<DbArg>();
                foreach (var column in added)
                {
                    var node = data.FirstOrDefault(x => x.Key.Equals(column.FieldName, StringComparison.OrdinalIgnoreCase)).Value;
                    if (node is null) continue;
                    var value = TemplateDataTablePlanner.ConvertValue(column.SqlType, NodeText(node));
                    if (value is null) continue;
                    args.Add(new($"v{args.Count}", value));
                    sets.Add($"{Quote(column.ColumnName)}={P($"v{args.Count - 1}")}");
                }
                if (sets.Count == 0) continue;
                args.Add(new("Alert", alertId));
                await db.ExecuteAsync($"UPDATE dbo.{table} SET {string.Join(",", sets)} WHERE AlertId={P("Alert")}", args, ct);
            }
        }
    }

    /// <summary>Writes an alert's business data (keys not starting with '_') to its row: typed columns plus the full JSON copy.</summary>
    public async Task SaveAsync(TemplateDataTableInfo info, long alertId, JsonObject data, CancellationToken ct = default)
    {
        var table = Quote(info.TableName);
        var business = new JsonObject();
        foreach (var item in data.Where(x => !x.Key.StartsWith('_'))) business[item.Key] = item.Value?.DeepClone();
        var columnValues = new List<(string Column, object? Value)>();
        foreach (var column in info.Columns)
        {
            var match = business.FirstOrDefault(x => x.Key.Equals(column.FieldName, StringComparison.OrdinalIgnoreCase));
            if (match.Key is null) continue;
            columnValues.Add((column.ColumnName, TemplateDataTablePlanner.ConvertValue(column.SqlType, NodeText(match.Value))));
        }
        var args = new List<DbArg> { new("Json", business.ToJsonString()), new("Now", DateTime.UtcNow), new("Alert", alertId) };
        var updates = new List<string> { $"SourceDataJson={P("Json")}", $"UpdatedAtUtc={P("Now")}" };
        var insertColumns = new List<string> { "AlertId", "SourceDataJson" };
        var insertValues = new List<string> { P("Alert"), P("Json") };
        for (var index = 0; index < columnValues.Count; index++)
        {
            var name = $"c{index}";
            args.Add(new(name, columnValues[index].Value));
            updates.Add($"{Quote(columnValues[index].Column)}={P(name)}");
            insertColumns.Add(Quote(columnValues[index].Column));
            insertValues.Add(P(name));
        }
        var changed = await db.ExecuteAsync($"UPDATE dbo.{table} SET {string.Join(",", updates)} WHERE AlertId={P("Alert")}", args, ct);
        if (changed == 0)
            await db.ExecuteAsync($"INSERT INTO dbo.{table}({string.Join(",", insertColumns)}) VALUES({string.Join(",", insertValues)})", args, ct);
    }

    /// <summary>Reads an alert's business data, or null when it has no row yet. A column value wins over the JSON copy only when they differ.</summary>
    public async Task<JsonObject?> LoadAsync(TemplateDataTableInfo info, long alertId, CancellationToken ct = default)
    {
        var table = Quote(info.TableName);
        var row = await db.QuerySingleAsync(
            $"SELECT * FROM dbo.{table} WHERE AlertId={P("Alert")}",
            reader =>
            {
                var values = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
                for (var i = 0; i < reader.FieldCount; i++) if (!reader.IsDBNull(i)) values[reader.GetName(i)] = reader.GetValue(i);
                return values;
            }, [new("Alert", alertId)], ct);
        if (row is null) return null;
        var result = ParseObject(row.TryGetValue("SourceDataJson", out var json) ? Convert.ToString(json) : null);
        foreach (var column in info.Columns)
        {
            if (!row.TryGetValue(column.ColumnName, out var stored) || stored is null) continue;
            var existingKey = result.FirstOrDefault(x => x.Key.Equals(column.FieldName, StringComparison.OrdinalIgnoreCase)).Key;
            if (existingKey is not null)
            {
                var original = TemplateDataTablePlanner.ConvertValue(column.SqlType, NodeText(result[existingKey]));
                if (original is not null && original.Equals(stored)) continue;
            }
            result[existingKey ?? column.FieldName] = ToNode(stored);
        }
        return result;
    }

    private static JsonNode? ToNode(object value) => value switch
    {
        DateTime date => JsonValue.Create(date.TimeOfDay == TimeSpan.Zero ? date.ToString("yyyy-MM-dd") : date.ToString("yyyy-MM-ddTHH:mm:ss")),
        bool flag => JsonValue.Create(flag),
        decimal number => JsonValue.Create(number),
        int whole => JsonValue.Create(whole),
        long large => JsonValue.Create(large),
        double real => JsonValue.Create(real),
        _ => JsonValue.Create(Convert.ToString(value))
    };

    private static string? NodeText(JsonNode? node) => node switch
    {
        null => null,
        JsonValue value when value.TryGetValue<string>(out var text) => text,
        _ => node.ToString()
    };

    private static JsonObject ParseObject(string? json)
    {
        try { return JsonNode.Parse(string.IsNullOrWhiteSpace(json) ? "{}" : json) as JsonObject ?? new JsonObject(); }
        catch (JsonException) { return new JsonObject(); }
    }
}
