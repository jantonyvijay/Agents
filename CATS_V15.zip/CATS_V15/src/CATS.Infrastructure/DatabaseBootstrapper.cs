using System.Text.Json;
using CATS.Core;
using Microsoft.Data.SqlClient;

namespace CATS.Infrastructure;

public sealed class DatabaseBootstrapper(DbConnectionFactory factory, AdoHelper db, Pbkdf2PasswordHasher hasher)
{
    public async Task InitializeAsync(string schemaRoot, CancellationToken ct = default)
    {
        if (factory.Dialect.Name == "SqlServer")
        {
            await EnsureSqlServerDatabaseAsync(ct);
            await ConvertSqlServerIdsToBigIntAsync(schemaRoot, ct);
        }
        var file = factory.Dialect.Name switch
        {
            "PostgreSql" => Path.Combine(schemaRoot,"postgresql","schema.sql"),
            "Oracle" => Path.Combine(schemaRoot,"oracle","schema.sql"),
            _ => Path.Combine(schemaRoot,"sqlserver","schema.sql")
        };
        if (!File.Exists(file)) throw new FileNotFoundException("CATS database schema not found.", file);
        var script = await File.ReadAllTextAsync(file, ct);
        foreach (var batch in SplitBatches(script, factory.Dialect.Name))
            if (!string.IsNullOrWhiteSpace(batch)) await db.ExecuteAsync(batch, null, ct);
        await SeedAsync(ct);
    }

    /// <summary>
    /// A database created before ids became BIGINT still has GUID text keys. Its data is converted once, in one transaction,
    /// by CATS_V19_BigIntIds_Upgrade.sql (the old GUIDs are kept in LegacyGuid); a database without Alerts is created fresh by schema.sql.
    /// </summary>
    private async Task ConvertSqlServerIdsToBigIntAsync(string schemaRoot, CancellationToken ct)
    {
        var legacy = await db.ScalarAsync<int>(
            "SELECT CASE WHEN EXISTS(SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID('dbo.Alerts') AND name='Id' AND system_type_id=167) THEN 1 ELSE 0 END",
            null, ct);
        if (legacy == 0) return;
        var file = Path.Combine(schemaRoot, "sqlserver", "CATS_V19_BigIntIds_Upgrade.sql");
        if (!File.Exists(file)) throw new FileNotFoundException("The database still uses GUID identifiers and the BIGINT upgrade script was not found.", file);
        var script = await File.ReadAllTextAsync(file, ct);
        foreach (var batch in SplitBatches(script, "SqlServer"))
            if (!string.IsNullOrWhiteSpace(batch)) await db.ExecuteAsync(batch, null, ct);
    }

    private async Task EnsureSqlServerDatabaseAsync(CancellationToken ct)
    {
        var b = new SqlConnectionStringBuilder(factory.Options.ConnectionString);
        var dbName = b.InitialCatalog;
        if (string.IsNullOrWhiteSpace(dbName)) return;
        b.InitialCatalog = "master";
        await using var cn = new SqlConnection(b.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd = cn.CreateCommand();
        cmd.CommandText = "IF DB_ID(@db) IS NULL BEGIN DECLARE @sql nvarchar(max)=N'CREATE DATABASE ['+REPLACE(@db,']',']]')+N']'; EXEC(@sql); END";
        cmd.Parameters.AddWithValue("@db",dbName);
        await cmd.ExecuteNonQueryAsync(ct);
    }

    private static IEnumerable<string> SplitBatches(string script,string provider)
    {
        if(provider=="SqlServer") return System.Text.RegularExpressions.Regex.Split(script,@"^\s*GO\s*$",System.Text.RegularExpressions.RegexOptions.Multiline|System.Text.RegularExpressions.RegexOptions.IgnoreCase).Where(x=>!string.IsNullOrWhiteSpace(x));
        if(provider=="Oracle") return System.Text.RegularExpressions.Regex.Split(script,@"^\s*/\s*$",System.Text.RegularExpressions.RegexOptions.Multiline).Where(x=>!string.IsNullOrWhiteSpace(x));
        return script.Split(';',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries);
    }

    private async Task SeedAsync(CancellationToken ct)
    {
        await EnsureAtmSecurityConfigurationAsync(ct);
        await EnsureAlertListColumnsAsync(ct);
        await EnsureMenusAsync(ct);
        await EnsureAlertTypeAccessAsync(ct);
        await SeedAgingBucketsAsync(ct);
        await SeedUsersAsync(ct);
        await EnsureAtmUsersAsync(ct);
        await EnsureGenericTemplateSeedAsync(ct);
        var desktopTemplateId = await EnsureDesktopDueDiligenceTemplateSeedAsync(ct);
        await EnsureDesktopDueDiligenceDashboardsAsync(desktopTemplateId, ct);
        await EnsureAtmTemplateSeedsAsync(ct);
    }

    /// <summary>Adds any default Alert List Configuration column that is missing; rows an administrator changed or deactivated are left as they are.</summary>
    public async Task EnsureAlertListColumnsAsync(CancellationToken ct = default)
    {
        var p = db.Dialect.P;
        foreach (var column in AlertListColumnSeeds.Defaults)
        {
            if (await db.ScalarAsync<int>($"SELECT COUNT(1) FROM AlertListColumnMaster WHERE Code={p("Code")}", [new("Code", column.Code)], ct) > 0) continue;
            await db.ExecuteAsync(
                $"INSERT INTO AlertListColumnMaster(Code,Label,DbColumn,IsFilterable,MatchMode,ControlType,OptionsJson,ValueFormat,ExcludedTemplateCodes,DisplayOrder,IsActive) " +
                $"VALUES({p("Code")},{p("Label")},{p("Db")},{p("Filter")},{p("Mode")},{p("Control")},{p("Options")},{p("Format")},{p("Excluded")},{p("Order")},1)",
                [new("Code", column.Code), new("Label", column.Label), new("Db", column.DbColumn), new("Filter", column.IsFilterable ? 1 : 0),
                 new("Mode", column.MatchMode), new("Control", column.ControlType), new("Options", column.OptionsJson), new("Format", column.ValueFormat),
                 new("Excluded", column.ExcludedTemplateCodes), new("Order", column.DisplayOrder)], ct);
        }
    }

    public async Task EnsureAtmSecurityConfigurationAsync(CancellationToken ct = default)
    {
        var roles = new (string Code, string Name)[]
        {
            ("ADMIN", "Administrator"),
            ("AUDITOR", "Auditor"),
            ("CENTRAL", "Central"),
            ("DT_CHECKER", "DT Checker"),
            ("DT_USER", "DT User"),
            ("DT_VERIFIER", "DT Verifier"),
            ("DBOPS_MAKER", "DBOPS Maker"),
            ("DBOPS_CHECKER", "DBOPS Checker"),
            ("ATMC", "ATMC"),
            ("RATC", "RATC"),
            ("SH", "SH"),
            ("RH", "RH"),
            ("GH", "GH")
        };
        foreach (var role in roles)
        {
            if (await db.ScalarAsync<int>($"SELECT COUNT(1) FROM RoleMaster WHERE Code={db.Dialect.P("Code")}",
                    [new("Code", role.Code)], ct) == 0)
                await db.ExecuteAsync(
                    $"INSERT INTO RoleMaster(Code,Name,IsActive) VALUES({db.Dialect.P("Code")},{db.Dialect.P("Name")},1)",
                    [new("Code", role.Code), new("Name", role.Name)], ct);
        }

        var permissions = new (string Code, string Name, string Category)[]
        {
            (CatsPermissions.AtmOperations, "Access ATM operations", "ATM"),
            (CatsPermissions.AtmUpload, "Upload ATM files", "ATM"),
            (CatsPermissions.AtmCheck, "Approve ATM uploads and reopen requests", "ATM"),
            (CatsPermissions.AtmCaseManage, "Reassign and reopen ATM cases", "ATM"),
            (CatsPermissions.AtmMasterConfigure, "Configure ATM master file layouts and column mappings", "ATM"),
            (CatsPermissions.AtmMasterView, "View and maintain ATM masters (Staff Mapping)", "ATM"),
            (CatsPermissions.RolePermissionsManage, "Set permissions role-wise for all users", "Security"),
            (CatsPermissions.DiagnosticsView, "View monitoring, errors and troubleshooting information", "Security")
        };
        foreach (var permission in permissions)
        {
            if (await db.ScalarAsync<int>($"SELECT COUNT(1) FROM PermissionMaster WHERE Code={db.Dialect.P("Code")}",
                    [new("Code", permission.Code)], ct) == 0)
                await db.ExecuteAsync(
                    $"INSERT INTO PermissionMaster(Code,Name,Category,IsActive) VALUES({db.Dialect.P("Code")},{db.Dialect.P("Name")},{db.Dialect.P("Category")},1)",
                    [new("Code", permission.Code), new("Name", permission.Name), new("Category", permission.Category)], ct);
        }

        var rolePermissions = new (string Role, string Permission)[]
        {
            ("ADMIN", CatsPermissions.AtmOperations), ("ADMIN", CatsPermissions.AtmUpload),
            ("ADMIN", CatsPermissions.AtmCheck), ("ADMIN", CatsPermissions.AtmCaseManage),
            ("ADMIN", CatsPermissions.AtmMasterConfigure), ("CENTRAL", CatsPermissions.AtmMasterConfigure),
            ("ADMIN", CatsPermissions.AtmMasterView), ("CENTRAL", CatsPermissions.AtmMasterView),
            ("ADMIN", CatsPermissions.RolePermissionsManage), ("CENTRAL", CatsPermissions.RolePermissionsManage),
            ("ADMIN", CatsPermissions.DiagnosticsView), ("CENTRAL", CatsPermissions.DiagnosticsView),
            ("DBOPS_MAKER", CatsPermissions.AtmMasterView), ("DBOPS_CHECKER", CatsPermissions.AtmMasterView),
            ("DBOPS_MAKER", CatsPermissions.AtmOperations), ("DBOPS_MAKER", CatsPermissions.AtmUpload), ("DBOPS_MAKER", CatsPermissions.AlertUpload),
            ("DBOPS_CHECKER", CatsPermissions.AtmOperations), ("DBOPS_CHECKER", CatsPermissions.AtmCheck),
            ("ATMC", CatsPermissions.AtmOperations),
            ("RATC", CatsPermissions.AtmOperations), ("RATC", CatsPermissions.AtmCaseManage),
            ("RATC", CatsPermissions.AlertReassign),
            ("SH", CatsPermissions.AtmOperations),
            ("RH", CatsPermissions.AtmOperations),
            ("GH", CatsPermissions.AtmOperations)
        };
        foreach (var mapping in rolePermissions)
        {
            if (await db.ScalarAsync<int>(
                    $"SELECT COUNT(1) FROM RolePermissionMapping WHERE RoleCode={db.Dialect.P("Role")} AND PermissionCode={db.Dialect.P("Permission")}",
                    [new("Role", mapping.Role), new("Permission", mapping.Permission)], ct) == 0)
                await db.ExecuteAsync(
                    $"INSERT INTO RolePermissionMapping(RoleCode,PermissionCode,IsActive) VALUES({db.Dialect.P("Role")},{db.Dialect.P("Permission")},1)",
                    [new("Role", mapping.Role), new("Permission", mapping.Permission)], ct);
        }

        // An approver does not enter data: take back the upload permission an earlier version gave DBOPS_CHECKER, once.
        const string retiredKey = "Retired.DBOPS_CHECKER.ALERT.UPLOAD";
        if (await db.ScalarAsync<int>($"SELECT COUNT(1) FROM ATM_MasterSettings WHERE SettingKey={db.Dialect.P("Key")}", [new("Key", retiredKey)], ct) == 0)
        {
            await db.ExecuteAsync(
                $"UPDATE RolePermissionMapping SET IsActive=0 WHERE RoleCode='DBOPS_CHECKER' AND PermissionCode={db.Dialect.P("Permission")}",
                [new("Permission", CatsPermissions.AlertUpload)], ct);
            await db.ExecuteAsync(
                $"INSERT INTO ATM_MasterSettings(SettingKey,SettingJson,UpdatedBy,UpdatedAtUtc) VALUES({db.Dialect.P("Key")},'{{}}','system',{db.Dialect.P("Now")})",
                [new("Key", retiredKey), new("Now", DateTime.UtcNow)], ct);
        }
    }

    /// <summary>Seeds AlertTypeAccess once (while the table is empty) so each module's Alert Types are limited to its roles and permissions.</summary>
    public async Task EnsureAlertTypeAccessAsync(CancellationToken ct = default)
    {
        if (await db.ScalarAsync<int>("SELECT COUNT(1) FROM AlertTypeAccess", null, ct) > 0) return;
        foreach (var rule in AlertTypeAccess.Defaults)
            await db.ExecuteAsync(
                $"INSERT INTO AlertTypeAccess(Id,TemplateCode,RoleCode,PermissionCode,IsActive) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Template")},{db.Dialect.P("Role")},{db.Dialect.P("Permission")},1)",
                [new("Id", CatsId.Next()), new("Template", rule.TemplateCode), new("Role", rule.RoleCode), new("Permission", rule.PermissionCode)], ct);
    }

    public async Task EnsureMenusAsync(CancellationToken ct = default)
    {
        // Staff Mapping is now governed by its own permission (ATM.MASTER.VIEW) instead of general ATM access; move the seeded entry once.
        await db.ExecuteAsync(
            $"UPDATE MenuMaster SET PermissionCode={db.Dialect.P("New")} WHERE Code='masters.atm.staffmapping' AND PermissionCode={db.Dialect.P("Old")}",
            [new("New", CatsPermissions.AtmMasterView), new("Old", CatsPermissions.AtmOperations)], ct);
        // The New / Upload Alerts entry is now also open to ATM checkers (they approve uploads there); widen the seeded permission once.
        await db.ExecuteAsync(
            $"UPDATE MenuMaster SET PermissionCode={db.Dialect.P("New")} WHERE Code='workspace.newalert' AND PermissionCode={db.Dialect.P("Old")}",
            [new("New", CatsPermissions.AlertUpload + "," + CatsPermissions.AtmCheck), new("Old", CatsPermissions.AlertUpload)], ct);
        foreach (var update in new[]
        {
            (Code: "operations", Permission: PlatformPermissions.IngestionView + "," + PlatformPermissions.MailManage),
            (Code: "operations.ingestion", Permission: PlatformPermissions.IngestionView),
            (Code: "operations.mail", Permission: PlatformPermissions.MailManage),
            (Code: "reports", Permission: PlatformPermissions.ReportsAll),
            (Code: "reports.all", Permission: PlatformPermissions.ReportsAll)
        })
            await db.ExecuteAsync(
                $"UPDATE MenuMaster SET PermissionCode={db.Dialect.P("Permission")} WHERE Code={db.Dialect.P("Code")} AND (PermissionCode IS NULL OR PermissionCode='')",
                [new("Permission", update.Permission), new("Code", update.Code)], ct);
        foreach (var retired in MenuCatalog.RetiredCodes)
            await db.ExecuteAsync($"UPDATE MenuMaster SET IsActive=0 WHERE Code={db.Dialect.P("Code")} AND IsActive<>0", [new("Code", retired)], ct);
        var ids = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        foreach (var node in MenuCatalog.Defaults)
        {
            var existing = await db.ScalarAsync<long?>($"SELECT Id FROM MenuMaster WHERE Code={db.Dialect.P("Code")}", [new("Code", node.Code)], ct);
            if (existing.HasValue)
            {
                ids[node.Code] = existing.Value;
                continue;
            }
            var id = CatsId.Next();
            ids[node.Code] = id;
            await db.ExecuteAsync(
                $"INSERT INTO MenuMaster(Id,ParentId,Code,Label,Title,Description,Icon,ViewKey,PermissionCode,DisplayOrder,IsActive) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Parent")},{db.Dialect.P("Code")},{db.Dialect.P("Label")},{db.Dialect.P("Title")},{db.Dialect.P("Desc")},{db.Dialect.P("Icon")},{db.Dialect.P("View")},{db.Dialect.P("Perm")},{db.Dialect.P("Order")},1)",
                [new("Id", id), new("Parent", node.ParentCode is null ? null : ids[node.ParentCode]), new("Code", node.Code), new("Label", node.Label),
                 new("Title", node.Title), new("Desc", node.Description), new("Icon", node.Icon), new("View", node.ViewKey),
                 new("Perm", node.PermissionCode), new("Order", node.DisplayOrder)], ct);
        }
    }

    public async Task EnsureAtmTemplateSeedsAsync(CancellationToken ct = default)
    {
        await EnsureAtmTemplateAsync("ATM_ONUS", "ATM Transaction Monitoring - OnUs", ct);
        await EnsureAtmTemplateAsync("ATM_OFFUS", "ATM Transaction Monitoring - OffUs", ct);
    }

    private async Task EnsureAtmTemplateAsync(string code, string name, CancellationToken ct)
    {
        var existing = await db.QuerySingleAsync(
            $"SELECT Id,SectionsJson,FieldsJson,ViewConfigurationJson FROM Templates WHERE Code={db.Dialect.P("Code")} AND Status<>'Retired'",
            r => new
            {
                Id = r.Lng("Id"),
                SectionsJson = r.Str("SectionsJson"),
                FieldsJson = r.Str("FieldsJson"),
                ViewConfigurationJson = r.Str("ViewConfigurationJson")
            },
            [new("Code", code)], ct);
        if (existing is not null)
        {
            await EnsureAtmTemplateFieldsAsync(existing.Id, code, existing.SectionsJson, existing.FieldsJson, existing.ViewConfigurationJson, ct);
            return;
        }

        var templateId = CatsId.Next();
        var workflowId = CatsId.Next();
        var templateFields = CreateAtmTemplateFields(code);
        var templateSections = new List<TemplateSection>
        {
            new() { Id = "penalty", Name = code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? "Penalty and Recovery Details" : "Penalty Details", Order = 1 },
            new() { Id = "transactions", Name = "Source Transaction Details", Order = 2 },
            new() { Id = "review", Name = "Case Review", Order = 3 }
        };
        var fields = JsonSerializer.Serialize(templateFields, JsonDefaults.Options);
        var sections = JsonSerializer.Serialize(templateSections, JsonDefaults.Options);
        var view = new TemplateViewConfiguration
        {
            BaseDataModes = ["BulkFileUpload"],
            AlertListFields = CreateAtmListFieldDefaults(code),
            SourceColumnMappings = AtmSourceColumns.TemplateMappings(code)
        };
        var definition = new WorkflowDefinitionModel
        {
            StartStageId = "atmc",
            Stages =
            [
                new() { Id="atmc", Name="ATMC Review", Type=StageType.Human, RoleCode="ATMC",
                    AllowedActions=["Submit"], EditableFields=code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase)
                        ? ["Recoverable_Type", "Recoverable_VendorName", "NoPenaltyApplicable", "Excess_Reported", "Excess_Date", "MailDate", "EJ_Error", "Recovery_Reason", "RecoveryReason_Remark", "Fourwayreconcilition", "ATMC_Remark"]
                        : ["CaseCategory"], SlaHours=24,
                    Transitions=[new() { Action="Submit", ToStageId="ratc" }] },
                new() { Id="ratc", Name="RATC Review", Type=StageType.Human, RoleCode="RATC",
                    AllowedActions=["Approve","Reject"], EditableFields=[], SlaHours=24,
                    Transitions=[new() { Action="Approve", ToStageId="sh" },new() { Action="Reject", ToStageId="rejected" }] },
                new() { Id="sh", Name="SH Review", Type=StageType.Human, RoleCode="SH",
                    AllowedActions=["Approve","Reject"], EditableFields=[], SlaHours=24,
                    Transitions=[new() { Action="Approve", ToStageId="shRouting" },new() { Action="Reject", ToStageId="rejected" }] },
                new() { Id="shRouting", Name="SH Case Routing", Type=StageType.Condition,
                    Conditions=[
                        new() { Field=code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? "Recoverable_Type" : "CaseCategory", Operator="eq", Value="Recoverable", ToStageId="closed" },
                        new() { Field=code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? "Recoverable_Type" : "CaseCategory", Operator="eq", Value="Service Gesture", ToStageId="closed" },
                        new() { Field=code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? "Recoverable_Type" : "CaseCategory", Operator="eq", Value="Goodfaith", ToStageId="closed" },
                        new() { Field="CaseCategory", Operator="eq", Value="Acquiring Dependency", ToStageId="closed" },
                        new() { Field="PenaltyAmount", Operator="lte", Value="10000", ToStageId="rh" }
                    ],
                    DefaultNextStageId="gh" },
                new() { Id="rh", Name="RH Approval (10,000 and below)", Type=StageType.Human, RoleCode="RH",
                    AllowedActions=["Approve","Reject"], SlaHours=24,
                    Transitions=[new() { Action="Approve", ToStageId="closed" },new() { Action="Reject", ToStageId="rejected" }] },
                new() { Id="gh", Name="GH Final Approval (over 10,000)", Type=StageType.Human, RoleCode="GH",
                    AllowedActions=["Approve","Reject"], SlaHours=24,
                    Transitions=[new() { Action="Approve", ToStageId="closed" },new() { Action="Reject", ToStageId="rejected" }] },
                new() { Id="closed", Name="Closed", Type=StageType.End, EndStatus="Closed" },
                new() { Id="rejected", Name="Rejected", Type=StageType.End, EndStatus="Rejected" }
            ]
        };
        var now = DateTime.UtcNow;
        await db.ExecuteAsync(
            $"INSERT INTO Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Code")},{db.Dialect.P("Name")},1,'Published','Deterministic',{db.Dialect.P("Sections")},{db.Dialect.P("Fields")},'[]',{db.Dialect.P("View")},{db.Dialect.P("Workflow")},{db.Dialect.P("Now")},'system')",
            [new("Id", templateId), new("Code", code), new("Name", name), new("Sections", sections),
             new("Fields", fields), new("View", JsonSerializer.Serialize(view, JsonDefaults.Options)),
             new("Workflow", workflowId), new("Now", now)], ct);
        await db.ExecuteAsync(
            $"INSERT INTO WorkflowDefinitions(Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Template")},1,{db.Dialect.P("Name")},{db.Dialect.P("Definition")},1,{db.Dialect.P("Now")},'system')",
            [new("Id", workflowId), new("Template", templateId), new("Name", $"{name} workflow"),
             new("Definition", JsonSerializer.Serialize(definition, JsonDefaults.Options)), new("Now", now)], ct);
    }

    private async Task EnsureAtmTemplateFieldsAsync(
        long templateId,
        string code,
        string sectionsJson,
        string fieldsJson,
        string viewConfigurationJson,
        CancellationToken ct)
    {
        var sections = JsonSerializer.Deserialize<List<TemplateSection>>(sectionsJson, JsonDefaults.Options) ?? [];
        var fields = JsonSerializer.Deserialize<List<TemplateField>>(fieldsJson, JsonDefaults.Options) ?? [];
        var view = JsonSerializer.Deserialize<TemplateViewConfiguration>(viewConfigurationJson, JsonDefaults.Options) ?? new();
        var changed = false;

        var seedSourceFields = !sections.Any(section => section.Id.Equals("transactions", StringComparison.OrdinalIgnoreCase));
        foreach (var section in new[]
        {
            new TemplateSection { Id = "penalty", Name = code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase) ? "Penalty and Recovery Details" : "Penalty Details", Order = 1 },
            new TemplateSection { Id = "transactions", Name = "Source Transaction Details", Order = 2 },
            new TemplateSection { Id = "review", Name = "Case Review", Order = 3 }
        })
        {
            if (sections.Any(existing => existing.Id.Equals(section.Id, StringComparison.OrdinalIgnoreCase))) continue;
            section.Order = sections.Count + 1;
            sections.Add(section);
            changed = true;
        }

        if (code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase))
        {
            var penalty = sections.First(section => section.Id.Equals("penalty", StringComparison.OrdinalIgnoreCase));
            if (!penalty.Name.Equals("Penalty and Recovery Details", StringComparison.Ordinal))
            {
                penalty.Name = "Penalty and Recovery Details";
                changed = true;
            }
            changed |= fields.RemoveAll(field => field.Name.Equals("CaseCategory", StringComparison.OrdinalIgnoreCase)) > 0;
            changed |= view.AlertListFields.RemoveAll(field => field.Field.Equals("CaseCategory", StringComparison.OrdinalIgnoreCase)) > 0;
        }

        // Earlier seeds listed EJ_Error twice (editable in Penalty and read-only in Source); the template designer rejects duplicate names, so keep the editable one.
        foreach (var duplicate in fields.GroupBy(field => field.Name, StringComparer.OrdinalIgnoreCase).Where(group => group.Count() > 1))
        {
            var keep = duplicate.FirstOrDefault(field => !field.SectionId.Equals("transactions", StringComparison.OrdinalIgnoreCase)) ?? duplicate.First();
            changed |= fields.RemoveAll(field => !ReferenceEquals(field, keep) && field.Name.Equals(keep.Name, StringComparison.OrdinalIgnoreCase)) > 0;
        }

        foreach (var field in CreateAtmTemplateFields(code))
        {
            var isUploadMetadata = field.SectionId.Equals("transactions", StringComparison.OrdinalIgnoreCase) &&
                field.Name is "UploadFileName" or "CreatedBy" or "CreatedDate";
            if (field.SectionId.Equals("transactions", StringComparison.OrdinalIgnoreCase) && !seedSourceFields && !isUploadMetadata) continue;
            if (fields.Any(existing => existing.Name.Equals(field.Name, StringComparison.OrdinalIgnoreCase))) continue;
            fields.Add(field);
            changed = true;
        }

        foreach (var listField in CreateAtmListFieldDefaults(code))
        {
            if (!fields.Any(field => field.Name.Equals(listField.Field, StringComparison.OrdinalIgnoreCase))) continue;
            if (view.AlertListFields.Any(existing => existing.Field.Equals(listField.Field, StringComparison.OrdinalIgnoreCase))) continue;
            listField.Order = view.AlertListFields.Count;
            view.AlertListFields.Add(listField);
            changed = true;
        }

        // Seed the default ATM upload column mapping once; afterwards administrators own it and it is never overwritten.
        var bulkMappings = view.SourceColumnMappings.Where(mapping => mapping.Mode == "BulkFileUpload").ToList();
        if (bulkMappings.Count == 0)
        {
            view.SourceColumnMappings.AddRange(AtmSourceColumns.TemplateMappings(code)
                .Where(mapping => fields.Any(field => field.Name.Equals(mapping.Field, StringComparison.OrdinalIgnoreCase))));
            changed = true;
        }
        else
        {
            if (bulkMappings.All(mapping => mapping.Order == 0))
            {
                // Mappings seeded before ordering existed: give them the documented file order. Anything an administrator has ordered is left alone.
                foreach (var seeded in AtmSourceColumns.TemplateMappings(code))
                {
                    var existing = bulkMappings.FirstOrDefault(mapping => mapping.Field.Equals(seeded.Field, StringComparison.OrdinalIgnoreCase));
                    if (existing is null) continue;
                    existing.Order = seeded.Order;
                    changed = true;
                }
            }

            // Mappings seeded earlier also listed derived columns (ATMID, PenaltyAmount, PenaltyMonth) and locked upload-metadata rows.
            // Those are now derived by CATS or added on demand, so drop the seeded entries once; their presence marks the old layout.
            if (bulkMappings.Any(mapping => AtmTableColumns.IsInternal(mapping.Field)))
            {
                var legacySystemRows = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                {
                    ["Penalty_Month"] = "Penalty_Month", ["Penalty_Year"] = "Penalty_Year", ["UploadFileName"] = "UploadFileName",
                    ["CreatedBy"] = "UploadBy", ["CreatedDate"] = "UploadDate"
                };
                view.SourceColumnMappings.RemoveAll(mapping => mapping.Mode == "BulkFileUpload" &&
                    (AtmTableColumns.IsInternal(mapping.Field) ||
                     (legacySystemRows.TryGetValue(mapping.Field, out var legacyColumn) && !mapping.Required &&
                      mapping.SourceColumn.Equals(legacyColumn, StringComparison.OrdinalIgnoreCase))));
                changed = true;
            }

            // OffUs headers seeded earlier used different wording; move untouched ones to the documented headers and drop the old EJ Error default.
            if (code.Equals("ATM_OFFUS", StringComparison.OrdinalIgnoreCase))
            {
                foreach (var (field, oldHeader, newHeader) in new[]
                {
                    ("Chargeback_Ref_No", "Chargeback Ref No", "Chargeback reference no"),
                    ("RRN_No", "RRN No", "RRN no"),
                    ("CARD_No", "Card No", "Card number")
                })
                {
                    var existing = view.SourceColumnMappings.FirstOrDefault(mapping => mapping.Mode == "BulkFileUpload" &&
                        mapping.Field.Equals(field, StringComparison.OrdinalIgnoreCase) &&
                        mapping.SourceColumn.Equals(oldHeader, StringComparison.OrdinalIgnoreCase));
                    if (existing is null) continue;
                    existing.SourceColumn = newHeader;
                    changed = true;
                }
                changed |= view.SourceColumnMappings.RemoveAll(mapping => mapping.Mode == "BulkFileUpload" &&
                    mapping.Field.Equals("EJError", StringComparison.OrdinalIgnoreCase) && !mapping.Required &&
                    mapping.SourceColumn.Equals("EJ Error", StringComparison.OrdinalIgnoreCase)) > 0;
            }
        }
        await db.ExecuteAsync(
            $"UPDATE Templates SET SectionsJson={db.Dialect.P("Sections")},FieldsJson={db.Dialect.P("Fields")},ViewConfigurationJson={db.Dialect.P("View")} WHERE Id={db.Dialect.P("Id")}",
            [
                new("Sections", JsonSerializer.Serialize(sections, JsonDefaults.Options)),
                new("Fields", JsonSerializer.Serialize(fields, JsonDefaults.Options)),
                new("View", JsonSerializer.Serialize(view, JsonDefaults.Options)),
                new("Id", templateId)
            ], ct);
    }

    private static List<TemplateField> CreateAtmTemplateFields(string code)
    {
        var fields = new List<TemplateField>
        {
            new() { Id = "atm", SectionId = "penalty", Name = "ATMID", Label = "ATM ID", Type = "text", Required = true, Order = 1 },
            new() { Id = "month", SectionId = "penalty", Name = "PenaltyMonth", Label = "Penalty Month", Type = "text", Required = true, Order = 2 },
            new() { Id = "amount", SectionId = "penalty", Name = "PenaltyAmount", Label = "Penalty Amount", Type = "number", Required = true, Order = 3 }
        };
        if (code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase))
        {
            const string recoverableTypes = "[\"Recoverable\",\"Non-Recoverable\",\"Goodfaith\",\"Service Gesture\"]";
            const string vendors = "[\"Admin - Boparai\",\"Admin - Modem\",\"Admin - Securens\",\"Admin - Ziacom\",\"AGS-CPT\",\"AGS-EJ\",\"CMS\",\"Diebold-CPT\",\"Diebold-EJ\",\"Euronet-CPT\",\"FSS-MS\",\"FSS-CPT\",\"FSS-LITE\",\"GRG\",\"OEM - HITACHI\",\"NCR\",\"NCR-EJ\",\"NCR-LITE\",\"NCR e-surveillance\",\"OEM - AGS\",\"OEM - Diebold\",\"OEM - NCR\",\"OEM - WINCOR\",\"OEM - OKI\",\"TSI - CPT\",\"Branch\"]";
            const string ejErrors = "[\"Power interruption\",\"Dispenser error - E*2\",\"Dispenser error - E*3\",\"Transaction missing in EJ\",\"Transaction declined\",\"Currency jam - E*4\",\"Host transaction timeout\",\"Network flapping - SST Offline/Online\",\"Clear withdrawal - No error in EJ\",\"EJ not available\",\"Cash presented timer Expired-Customer forgot to collect cash\",\"Cash presented timer Expired-Machine issue\",\"Cash presented timer Expired-Shutter fraud\",\"Other, Mentioned in remarks\",\"Timer Expired Card Not Taken\",\"Cash Not Taken By Customer In Time\",\"Cash Retract\",\"Cash Retained\",\"Media left behind\"]";
            const string reasons = "[\"No excess reported by CRA\",\"No excess reported by Branch\",\"Delay in excess reported by CRA\",\"Delay in excess reported by Branch\",\"Excess reported on time but transaction was suspect/Unidentified/Multiple Transaction Error\",\"Delayed by region\",\"Staff error\",\"Misdispensation\",\"Partial dispensation\",\"Denomination interchange\",\"Delay in CCTV footage provided by vendor\",\"Delay in CCTV footage provided by Branch\",\"CCTV not provided by vendor\",\"CCTV not provided by branch\",\"Customer forgot to collect cash & Security guard/Stranger\",\"Customer forgot to collect cash & Branch staff\",\"Shutter Fraud\",\"Misdispensation /Partial dispensation / Denomination interchange\",\"EJ Not Available\",\"ATM/CRM machine issue\",\"Excess reported but due to holidays delayed in credit\",\"As per the CCTV footage customer did not get the cash\",\"Other, Mentioned in remarks\",\"Delayed due to internal process\",\"Delay in Cash dispensed\"]";
            const string recoverableRule = "[{\"conditions\":[{\"field\":\"Recoverable_Type\",\"operator\":\"eq\",\"value\":\"Recoverable\"}],\"required\":true,\"errorMessage\":\"This field is required when Recoverable is selected.\"}]";
            fields.AddRange([
                new() { Id="recoverable-type", SectionId="penalty", Name="Recoverable_Type", Label="Recoverable / Non-recoverable", Type="select", Required=true, Order=4, OptionsJson=recoverableTypes },
                new() { Id="recoverable-vendor", SectionId="penalty", Name="Recoverable_VendorName", Label="Recoverable from whom - Vendor name", Type="select", Order=5, OptionsJson=vendors, DependencyValidationsJson=recoverableRule },
                new() { Id="no-penalty", SectionId="penalty", Name="NoPenaltyApplicable", Label="No Penalty Applicable", Type="checkbox", DefaultValue="false", Order=6, HelpText="Shown for Goodfaith and Service Gesture cases." },
                new() { Id="excess-reported", SectionId="penalty", Name="Excess_Reported", Label="Excess reported", Type="select", Order=7, OptionsJson="[\"Yes\",\"No\"]" },
                new() { Id="excess-date", SectionId="penalty", Name="Excess_Date", Label="Excess Date", Type="date", Order=8 },
                new() { Id="mail-date", SectionId="penalty", Name="MailDate", Label="Date Of Mail from Bal Team to ATM Reg Team", Type="date", Order=9 },
                new() { Id="ej-error", SectionId="penalty", Name="EJ_Error", Label="Error in EJ", Type="select", Order=10, OptionsJson=ejErrors },
                new() { Id="penalty-reason", SectionId="penalty", Name="Recovery_Reason", Label="Penalty Reason", Type="select", Order=11, OptionsJson=reasons, DependencyValidationsJson=recoverableRule },
                new() { Id="penalty-reason-remarks", SectionId="penalty", Name="RecoveryReason_Remark", Label="Penalty Reason other remarks (if any)", Type="textarea", Order=12 },
                new() { Id="four-way-recon", SectionId="penalty", Name="Fourwayreconcilition", Label="Is Transaction available in 4-way Recon", Type="radio", Order=13, OptionsJson="[\"Yes\",\"No\"]" },
                new() { Id="atmc-remark", SectionId="review", Name="ATMC_Remark", Label="ATMC Remark/Feedback", Type="textarea", Order=1 },
                new() { Id="atmc-actioned", SectionId="review", Name="ATMC_Status", Label="ATMC Actioned", Type="text", ReadOnly=true, DefaultValue="Pending", Order=2 },
                new() { Id="ratc-remark", SectionId="review", Name="RATC_Remark", Label="RATC Remark/Feedback", Type="textarea", Order=3 },
                new() { Id="ratc-actioned", SectionId="review", Name="RATC_Status", Label="RATC Actioned", Type="text", ReadOnly=true, DefaultValue="Pending", Order=4 },
                new() { Id="sh-remark", SectionId="review", Name="SH_Remark", Label="SH Remark/Feedback", Type="textarea", Order=5 },
                new() { Id="sh-actioned", SectionId="review", Name="SH_Status", Label="SH Actioned", Type="text", ReadOnly=true, DefaultValue="Pending", Order=6 },
                new() { Id="rh-remark", SectionId="review", Name="RH_Remark", Label="RH Remark/Feedback", Type="textarea", Order=7 },
                new() { Id="rh-actioned", SectionId="review", Name="RH_Status", Label="RH Actioned", Type="text", ReadOnly=true, DefaultValue="Pending", Order=8 },
                new() { Id="gh-remark", SectionId="review", Name="GH_Remark", Label="GH Remark/Feedback", Type="textarea", Order=9 },
                new() { Id="gh-actioned", SectionId="review", Name="GH_Status", Label="GH Actioned", Type="text", ReadOnly=true, DefaultValue="Pending", Order=10 }
            ]);
        }
        else
            fields.Add(new() { Id = "category", SectionId = "review", Name = "CaseCategory", Label = "Case Category", Type = "select", Required = true, Order = 1, OptionsJson = "[\"Recoverable\",\"Service Gesture\",\"Goodfaith\",\"Acquiring Dependency\",\"Non-Recoverable\"]" });
        var sourceFields = code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase)
            ? new (string Name, string Label, string Type)[]
            {
                ("Settlement_Type", "Type of Settlement", "text"),
                ("CRM_Proactive_No", "CRM No/Proactive No", "text"),
                ("Transaction_Date", "Transaction Date", "date"),
                ("Customer_Complaint_Date", "Date of Customer complaint", "date"),
                ("Customer_Acc_Credit_Date", "Date of credit to customer a/c", "date"),
                ("Acc_No", "Account Number", "text"),
                ("T_5_Calender_Days", "T+5 Calender Days", "date"),
                ("Days", "Days", "number"),
                ("Penalty_Rs", "Penalty (Rs.)", "number"),
                ("ATM_ID", "ATM ID (source)", "text"),
                ("Transaction_No", "Transaction Number", "text"),
                ("Transaction_Amount", "Transaction Amount", "number"),
                ("Disputed_Amount", "Disputed Amount", "number"),
                ("EJ_Error", "EJ Error", "text"),
                ("Narration", "Narration", "text"),
                ("Penalty_Month", "Penalty Month (source)", "text"),
                ("Penalty_Year", "Penalty Year", "text")
            }
            : new (string Name, string Label, string Type)[]
            {
                ("Chargeback_Ref_No", "Chargeback Reference Number", "text"),
                ("Chargeback_Date", "Chargeback Date", "date"),
                ("Acquiring_Bank", "Acquiring Bank", "text"),
                ("Issuing_Bank", "Issuing Bank", "text"),
                ("Transaction_Date", "Transaction Date", "date"),
                ("Transaction_Time", "Transaction Time", "text"),
                ("RRN_No", "RRN Number", "text"),
                ("ATM_ID", "ATM ID (source)", "text"),
                ("CARD_No", "Card Number", "text"),
                ("Transaction_Amount", "Transaction Amount", "number"),
                ("Disputed_Amount", "Disputed Amount", "number"),
                ("Customer_Penalty", "Customer Penalty", "text"),
                ("Adjustment_Date", "Adjustment Date", "date"),
                ("Adjustment_Type", "Adjustment Type", "text"),
                ("Adjustment_Time", "Adjustment Time", "text"),
                ("Narration", "Narration", "text"),
                ("Adjustment_Amount", "Adjustment Amount", "number"),
                ("EJError", "EJ Error", "text"),
                ("Penalty_Month", "Penalty Month", "text"),
                ("Penalty_Year", "Penalty Year", "text")
            };
        fields.AddRange(sourceFields.Where(field => !fields.Any(existing => existing.Name.Equals(field.Name, StringComparison.OrdinalIgnoreCase))).Select((field, index) => new TemplateField
        {
            Id = $"source-{field.Name}",
            SectionId = "transactions",
            Name = field.Name,
            Label = field.Label,
            Type = field.Type,
            Required = false,
            ReadOnly = true,
            Order = index + 1
        }));
        // Upload metadata columns that CATS fills in; shown on the case detail and listed in the Source Column Mapping.
        var metadataOrder = sourceFields.Length;
        foreach (var (name, label) in new[] { ("UploadFileName", "Upload File Name"), ("CreatedBy", "Uploaded By"), ("CreatedDate", "Upload Date") })
            fields.Add(new TemplateField
            {
                Id = $"source-{name}",
                SectionId = "transactions",
                Name = name,
                Label = label,
                Type = "text",
                Required = false,
                ReadOnly = true,
                Order = ++metadataOrder
            });
        return fields;
    }

    private static List<AlertListFieldConfiguration> CreateAtmListFieldDefaults(string code)
    {
        var fields = code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase)
            ? new[] { ("CRM_Proactive_No", "CRM No/Proactive No"), ("Transaction_Date", "Transaction Date"), ("Acc_No", "Account Number"), ("ATM_ID", "ATM ID (source)") }
            : new[] { ("Chargeback_Ref_No", "Chargeback Reference Number"), ("RRN_No", "RRN Number"), ("Transaction_Date", "Transaction Date"), ("ATM_ID", "ATM ID (source)") };
        var defaults = new List<AlertListFieldConfiguration>
        {
            new() { Field = "AlertNo", Label = "Alert No", ShowInGrid = true, ShowAsFilter = true, Order = 0 },
            new() { Field = "ATMID", Label = "ATM ID", ShowInGrid = true, ShowAsFilter = true, Order = 1 },
            new() { Field = "PenaltyMonth", Label = "Penalty Month", ShowInGrid = true, ShowAsFilter = true, Order = 2 },
            new() { Field = "PenaltyAmount", Label = "Penalty Amount", ShowInGrid = true, ShowAsFilter = false, Order = 3 }
        };
        if (!code.Equals("ATM_ONUS", StringComparison.OrdinalIgnoreCase))
            defaults.Add(new() { Field = "CaseCategory", Label = "Case Category", ShowInGrid = true, ShowAsFilter = true, Order = 4 });
        defaults.AddRange(fields.Select((field, index) => new AlertListFieldConfiguration
        {
            Field = field.Item1,
            Label = field.Item2,
            ShowInGrid = true,
            ShowAsFilter = false,
            Order = index + 5
        }));
        return defaults;
    }

    private async Task SeedAgingBucketsAsync(CancellationToken ct)
    {
        if ((await db.ScalarAsync<int>("SELECT COUNT(1) FROM AgingBuckets",null,ct)) != 0) return;
        var buckets = new (string,int,int?,int)[]{("0-1 Days",0,1,1),("2-3 Days",2,3,2),("4-7 Days",4,7,3),("8-15 Days",8,15,4),("16-30 Days",16,30,5),("31+ Days",31,null,6)};
        foreach(var x in buckets)
            await db.ExecuteAsync($"INSERT INTO AgingBuckets(Id,Name,FromDays,ToDays,DisplayOrder,IsActive) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Name")},{db.Dialect.P("From")},{db.Dialect.P("To")},{db.Dialect.P("Order")},1)",[new("Id",CatsId.Next()),new("Name",x.Item1),new("From",x.Item2),new("To",x.Item3),new("Order",x.Item4)],ct);
    }

    private async Task SeedUsersAsync(CancellationToken ct)
    {
        if ((await db.ScalarAsync<int>("SELECT COUNT(1) FROM CatsUsers",null,ct)) != 0) return;
        await AddUser("admin","CATS Administrator","ADMIN","HO","HO",new[]{"ADMIN","TEMPLATE.MANAGE","WORKFLOW.MANAGE","ALERT.UPLOAD","ALERT.VIEWALL","ALERT.REASSIGN","PI.UNMASK","AUDIT.VIEW"},ct);
        await AddUser("central","Central Team","CENTRAL","CENTRAL","HO",new[]{"TEMPLATE.MANAGE","WORKFLOW.MANAGE","ALERT.UPLOAD","ALERT.VIEWALL","ALERT.REASSIGN","AUDIT.VIEW"},ct);
        await AddUser("dtuser","DT User","DT_USER","DT","B001",Array.Empty<string>(),ct);
        await AddUser("checker","DT Checker","DT_CHECKER","DT","B001",new[]{"AUDIT.VIEW"},ct);
        await AddUser("verifier","DT Verifier","DT_VERIFIER","DT","B001",new[]{"AUDIT.VIEW"},ct);
        await AddUser("auditor","Auditor","AUDITOR","AUDIT","HO",new[]{"ALERT.VIEWALL","AUDIT.VIEW"},ct);
    }

    /// <summary>
    /// The ATM module roles are in RoleMaster, but the initial user seed only runs on an empty database. This adds one sign-in per ATM role
    /// when it is missing, so makers, checkers and the approval chain can be used (and mapped as assignees in Staff Mapping) right away.
    /// Existing users are never changed. All use the standard seeded password and should be changed or replaced with real staff.
    /// </summary>
    public async Task EnsureAtmUsersAsync(CancellationToken ct = default)
    {
        var users = new (string UserName, string Display, string Role)[]
        {
            ("dbops_maker", "DBOPS Maker", "DBOPS_MAKER"),
            ("dbops_checker", "DBOPS Checker", "DBOPS_CHECKER"),
            ("atmc1", "ATMC User", "ATMC"),
            ("ratc1", "RATC User", "RATC"),
            ("sh1", "State Head", "SH"),
            ("rh1", "Regional Head", "RH"),
            ("gh1", "Group Head", "GH")
        };
        foreach (var (userName, display, role) in users)
        {
            if (await db.ScalarAsync<int>($"SELECT COUNT(1) FROM CatsUsers WHERE UserName={db.Dialect.P("User")}", [new("User", userName)], ct) > 0) continue;
            await AddUser(userName, display, role, "ATM", "HO", [], ct);
        }
    }

    private async Task EnsureGenericTemplateSeedAsync(CancellationToken ct)
    {
        if ((await db.ScalarAsync<int>($"SELECT COUNT(1) FROM Templates WHERE Code={db.Dialect.P("Code")}",[new("Code","GENERIC_ALERT")],ct)) > 0) return;

        var templateId=CatsId.Next();
        var workflowId=CatsId.Next();
        var sections=JsonSerializer.Serialize(new[]{new { id="customer",name="Customer Information",order=1 },new { id="review",name="Review Questionnaire",order=2 }}, JsonDefaults.Options);
        var fields=JsonSerializer.Serialize(new object[]{
            new { id="risk",sectionId="customer",name="riskCategory",label="Risk Category",type="select",required=true,sensitive=false,order=1,optionsJson="[\"Low\",\"Medium\",\"High\"]" },
            new { id="amount",sectionId="customer",name="alertAmount",label="Alert Amount",type="number",required=true,sensitive=false,order=2,optionsJson="[]" },
            new { id="q1",sectionId="review",name="customerContacted",label="Customer contacted?",type="select",required=true,sensitive=false,order=1,optionsJson="[\"Yes\",\"No\"]" },
            new { id="q2",sectionId="review",name="remarks",label="Review Remarks",type="textarea",required=false,sensitive=false,order=2,optionsJson="[]" }}, JsonDefaults.Options);
        var viewConfiguration = JsonSerializer.Serialize(new TemplateViewConfiguration(), JsonDefaults.Options);
        var wf=new {
            startStageId="input",
            stages=new object[]{
                new { id="input",name="DT Input",type="Human",roleCode="DT_USER",allowedActions=new[]{"Submit"},editableFields=new[]{"*"},attachmentUploadRoles=new[]{"DT_USER"},attachmentViewRoles=Array.Empty<string>(),transitions=new[]{new { action="Submit",toStageId="parallelReview"}},approvalRule="Single",minimumApprovals=1,approvers=Array.Empty<object>(),slaHours=24,conditions=Array.Empty<object>(),defaultNextStageId=(string?)null,agentInstructions=(string?)null,agentPromptTemplate=(string?)null,agentFallbackAction=(string?)null,endStatus=(string?)null },
                new { id="parallelReview",name="Parallel Checker / Verifier",type="ParallelApproval",roleCode="",allowedActions=new[]{"Approve","Reject"},editableFields=Array.Empty<string>(),attachmentUploadRoles=Array.Empty<string>(),attachmentViewRoles=Array.Empty<string>(),transitions=new[]{new { action="Approve",toStageId="closed"},new { action="Reject",toStageId="rejected"}},approvalRule="All",minimumApprovals=2,approvers=new[]{new { roleCode="DT_CHECKER",label="DT Checker"},new { roleCode="DT_VERIFIER",label="DT Verifier"}},slaHours=48,conditions=Array.Empty<object>(),defaultNextStageId=(string?)null,agentInstructions=(string?)null,agentPromptTemplate=(string?)null,agentFallbackAction=(string?)null,endStatus=(string?)null },
                new { id="closed",name="Closed",type="End",roleCode="",allowedActions=Array.Empty<string>(),editableFields=Array.Empty<string>(),attachmentUploadRoles=Array.Empty<string>(),attachmentViewRoles=Array.Empty<string>(),transitions=Array.Empty<object>(),approvalRule="Single",minimumApprovals=1,approvers=Array.Empty<object>(),slaHours=1,conditions=Array.Empty<object>(),defaultNextStageId=(string?)null,agentInstructions=(string?)null,agentPromptTemplate=(string?)null,agentFallbackAction=(string?)null,endStatus="Closed" },
                new { id="rejected",name="Rejected",type="End",roleCode="",allowedActions=Array.Empty<string>(),editableFields=Array.Empty<string>(),attachmentUploadRoles=Array.Empty<string>(),attachmentViewRoles=Array.Empty<string>(),transitions=Array.Empty<object>(),approvalRule="Single",minimumApprovals=1,approvers=Array.Empty<object>(),slaHours=1,conditions=Array.Empty<object>(),defaultNextStageId=(string?)null,agentInstructions=(string?)null,agentPromptTemplate=(string?)null,agentFallbackAction=(string?)null,endStatus="Rejected" }
            }
        };
        var wfJson=JsonSerializer.Serialize(wf, JsonDefaults.Options);
        var now=DateTime.UtcNow;
        await db.ExecuteAsync($"INSERT INTO Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Code")},{db.Dialect.P("Name")},1,'Published','Hybrid',{db.Dialect.P("Sections")},{db.Dialect.P("Fields")},'[]',{db.Dialect.P("ViewConfig")},{db.Dialect.P("WorkflowId")},{db.Dialect.P("Now")},'SYSTEM')",
            [new("Id",templateId),new("Code","GENERIC_ALERT"),new("Name","Generic Alert Review"),new("Sections",sections),new("Fields",fields),new("ViewConfig",viewConfiguration),new("WorkflowId",workflowId),new("Now",now)],ct);
        await db.ExecuteAsync($"INSERT INTO WorkflowDefinitions(Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("TemplateId")},1,'Default Dynamic Approval',{db.Dialect.P("Json")},1,{db.Dialect.P("Now")},'SYSTEM')",
            [new("Id",workflowId),new("TemplateId",templateId),new("Json",wfJson),new("Now",now)],ct);
    }

    private async Task<long> EnsureDesktopDueDiligenceTemplateSeedAsync(CancellationToken ct)
    {
        const string templateCode = "DT_DD_MONEY_MULE";
        var existingTemplateId = await db.ScalarAsync<long?>($"SELECT Id FROM Templates WHERE Code={db.Dialect.P("Code")} ORDER BY Version DESC", [new("Code", templateCode)], ct);
        var templateId = existingTemplateId ?? CatsId.Next();
        var workflowId = CatsId.Next();
        var now = DateTime.UtcNow;
        var boolDefault = "false";

        var sections = new List<TemplateSection>
        {
            new() { Id="profile", Name="Customer Alert Profile", Order=1, ColumnSpan=3, PageNumber=1, DataViewMode="Grid" },
            new() { Id="questionnaire", Name="Questionary Response", Order=2, ColumnSpan=12, PageNumber=1, DataViewMode="List" },
            new() { Id="remarks", Name="Remarks & Recommendations", Order=3, ColumnSpan=12, PageNumber=1, DataViewMode="List" }
        };

        string JsonOptions(params string[] values) => JsonSerializer.Serialize(values, JsonDefaults.Options);

        var fields = new List<TemplateField>
        {
            new() { Id="fld_branch", SectionId="profile", Name="BranchCode", Label="Location", Type="text", Required=true, Order=1, ReadOnly=true },
            new() { Id="fld_analyst", SectionId="profile", Name="AnalystName", Label="Analyst Name", Type="text", Required=true, Order=2, ReadOnly=true },
            new() { Id="fld_account", SectionId="profile", Name="AccountId", Label="Account No", Type="text", Required=true, Order=3, ReadOnly=true },
            new() { Id="fld_customer", SectionId="profile", Name="CustomerId", Label="Customer Id", Type="text", Required=true, Order=4, ReadOnly=true },
            new() { Id="fld_cust_name", SectionId="profile", Name="CustomerName", Label="Customer Name", Type="text", Required=false, Order=5, ReadOnly=true },
            new() { Id="fld_rule", SectionId="profile", Name="RuleId", Label="Rule Id", Type="text", Required=false, Order=6, ReadOnly=true },
            new() { Id="fld_product", SectionId="profile", Name="ProductName", Label="Product name", Type="text", Required=false, Order=7, ReadOnly=true },
            new() { Id="fld_unit", SectionId="profile", Name="Unit", Label="Unit", Type="text", Required=false, Order=8, ReadOnly=true, DefaultValue="Money Mule" },
            new() { Id="fld_loan", SectionId="profile", Name="TotalLiveLoanAmount", Label="total_live_loan_amount", Type="number", Required=false, Order=9, ReadOnly=true },
            new() { Id="fld_state", SectionId="profile", Name="CustomerPermanentState", Label="customer_permanent_state", Type="text", Required=false, Order=10, ReadOnly=true },
            new() { Id="fld_dob", SectionId="profile", Name="CustomerDateOfBirth", Label="Customer_date_of_birth", Type="date", Required=false, Order=11, ReadOnly=true },
            new() { Id="fld_country", SectionId="profile", Name="CustomerCountry", Label="Customer_country", Type="text", Required=false, Order=12, ReadOnly=true },
            new() { Id="fld_reason", SectionId="profile", Name="ReasonDescription", Label="Reason Description", Type="textarea", Required=false, Order=13, ReadOnly=true },
            new() { Id="fld_class", SectionId="questionnaire", Name="MOClassification", Label="MO Classification", Type="select", Required=true, Order=1, OptionsJson=JsonOptions("Regular/Usual Transaction Pattern","Business Profile Aligned","Same Party/Repeated Transactions","Self Transfer/Internal Movement","Loan/OD Related Transactions","Business Receipts & Vendor Payments","Family/Related Party Transactions") },
            new() { Id="fld_q1", SectionId="questionnaire", Name="RegularUsualTransactionPattern", Label="Regular / Usual Transaction Pattern", Type="checkbox", Required=false, Order=2, DefaultValue=boolDefault },
            new() { Id="fld_q2", SectionId="questionnaire", Name="BusinessProfileAligned", Label="Business Profile Aligned", Type="checkbox", Required=false, Order=3, DefaultValue=boolDefault },
            new() { Id="fld_q3", SectionId="questionnaire", Name="SamePartyRepeatedTransactions", Label="Same Party / Repeated Transactions", Type="checkbox", Required=false, Order=4, DefaultValue=boolDefault },
            new() { Id="fld_q4", SectionId="questionnaire", Name="SelfTransferInternalMovement", Label="Self Transfer / Internal Movement", Type="checkbox", Required=false, Order=5, DefaultValue=boolDefault },
            new() { Id="fld_q5", SectionId="questionnaire", Name="LoanOdRelatedTransactions", Label="Loan / OD Related Transactions", Type="checkbox", Required=false, Order=6, DefaultValue=boolDefault },
            new() { Id="fld_q6", SectionId="questionnaire", Name="BusinessReceiptsVendorPayments", Label="Business Receipts & Vendor Payments", Type="checkbox", Required=false, Order=7, DefaultValue=boolDefault },
            new() { Id="fld_q7", SectionId="questionnaire", Name="FamilyRelatedPartyTransactions", Label="Family / Related Party Transactions", Type="checkbox", Required=false, Order=8, DefaultValue=boolDefault },
            new() { Id="fld_recommend", SectionId="remarks", Name="CDFinalRecommendation", Label="CD Final recommendations", Type="select", Required=true, Order=1, OptionsJson=JsonOptions("Continue Txn Restriction","Remove Txn Restriction","Central Due Diligence Review Positive","Central Due Diligence Review Negative") },
            new() { Id="fld_maker_remark", SectionId="remarks", Name="DTUserRemarks", Label="CD Team Maker Remark", Type="textarea", Required=false, Order=2, MaxLength=1000, Placeholder="Enter maker remarks" },
            new() { Id="fld_verifier_comment", SectionId="remarks", Name="DTVerifierComment", Label="CD Team Checker Comment", Type="textarea", Required=false, Order=3, MaxLength=1000, Placeholder="Enter verifier comment" }
        };

        var editableForDtUser = new[]
        {
            "MOClassification","RegularUsualTransactionPattern","BusinessProfileAligned","SamePartyRepeatedTransactions","SelfTransferInternalMovement",
            "LoanOdRelatedTransactions","BusinessReceiptsVendorPayments","FamilyRelatedPartyTransactions","CDFinalRecommendation","DTUserRemarks"
        };

        var workflowDefinition = new
        {
            startStageId = "dtUserReview",
            stages = new object[]
            {
                new {
                    id="dtUserReview", name="DT User Review", type="Human", roleCode="DT_USER",
                    allowedActions=new[]{"Submit"}, editableFields=editableForDtUser,
                    attachmentUploadRoles=new[]{"DT_USER"}, attachmentViewRoles=Array.Empty<string>(),
                    transitions=new[]{ new { action="Submit", toStageId="dtVerifierReview" } },
                    approvalRule="Single", minimumApprovals=1, approvers=Array.Empty<object>(), slaHours=24,
                    conditions=Array.Empty<object>(), defaultNextStageId=(string?)null,
                    agentInstructions=(string?)null, agentPromptTemplate=(string?)null, agentFallbackAction=(string?)null, endStatus=(string?)null
                },
                new {
                    id="dtVerifierReview", name="DT Verifier Review", type="Human", roleCode="DT_VERIFIER",
                    allowedActions=new[]{"Send Back","Verified"}, editableFields=new[]{"DTVerifierComment"},
                    attachmentUploadRoles=new[]{"DT_VERIFIER"}, attachmentViewRoles=Array.Empty<string>(),
                    transitions=new object[]{ new { action="Send Back", toStageId="dtUserReview" }, new { action="Verified", toStageId="closed" } },
                    approvalRule="Single", minimumApprovals=1, approvers=Array.Empty<object>(), slaHours=24,
                    conditions=Array.Empty<object>(), defaultNextStageId=(string?)null,
                    agentInstructions=(string?)null, agentPromptTemplate=(string?)null, agentFallbackAction=(string?)null, endStatus=(string?)null
                },
                new {
                    id="closed", name="Closed", type="End", roleCode="", allowedActions=Array.Empty<string>(), editableFields=Array.Empty<string>(),
                    attachmentUploadRoles=Array.Empty<string>(), attachmentViewRoles=Array.Empty<string>(), transitions=Array.Empty<object>(),
                    approvalRule="Single", minimumApprovals=1, approvers=Array.Empty<object>(), slaHours=1,
                    conditions=Array.Empty<object>(), defaultNextStageId=(string?)null,
                    agentInstructions=(string?)null, agentPromptTemplate=(string?)null, agentFallbackAction=(string?)null, endStatus="Closed"
                }
            }
        };

        var viewConfiguration = new TemplateViewConfiguration
        {
            LayoutMode = "Single",
            RememberLastSection = true,
            ShowSectionNumbers = false,
            AllowWizardStepClick = false,
            PopupSize = "xl"
        };

        var assignmentRules = new object[]
        {
            new { field="BranchCode", @operator="notempty", value="", stageId="dtUserReview", targetRoleCode="DT_USER", targetBranchCode="{BranchCode}", stop=true }
        };

        if (existingTemplateId.HasValue)
        {
            // Repair older/incomplete SYSTEM seed records in place. Earlier releases could
            // leave the Money Mule template with FieldsJson=[] and ViewConfigurationJson={}
            // while the sections/workflow already existed. Do not overwrite user-customized
            // configuration; only fill values that are still empty/default placeholders.
            var existing = await db.QuerySingleAsync(
                $"SELECT FieldsJson,ViewConfigurationJson,SectionsJson,AssignmentRulesJson FROM Templates WHERE Id={db.Dialect.P("Id")}",
                r => new
                {
                    FieldsJson = r.Str("FieldsJson"),
                    ViewConfigurationJson = r.HasColumn("ViewConfigurationJson") ? r.Str("ViewConfigurationJson") : "{}",
                    SectionsJson = r.Str("SectionsJson"),
                    AssignmentRulesJson = r.Str("AssignmentRulesJson")
                },
                [new("Id", templateId)], ct);

            if (existing is not null)
            {
                var repairFields = string.IsNullOrWhiteSpace(existing.FieldsJson) || string.Equals(existing.FieldsJson.Trim(), "[]", StringComparison.Ordinal);
                var repairView = string.IsNullOrWhiteSpace(existing.ViewConfigurationJson) || string.Equals(existing.ViewConfigurationJson.Trim(), "{}", StringComparison.Ordinal);
                var repairSections = string.IsNullOrWhiteSpace(existing.SectionsJson) || string.Equals(existing.SectionsJson.Trim(), "[]", StringComparison.Ordinal);
                var repairRules = string.IsNullOrWhiteSpace(existing.AssignmentRulesJson) || string.Equals(existing.AssignmentRulesJson.Trim(), "[]", StringComparison.Ordinal);

                if (repairFields || repairView || repairSections || repairRules)
                {
                    await db.ExecuteAsync(
                        $"UPDATE Templates SET " +
                        $"FieldsJson=CASE WHEN {db.Dialect.P("RepairFields")}=1 THEN {db.Dialect.P("Fields")} ELSE FieldsJson END," +
                        $"ViewConfigurationJson=CASE WHEN {db.Dialect.P("RepairView")}=1 THEN {db.Dialect.P("ViewConfig")} ELSE ViewConfigurationJson END," +
                        $"SectionsJson=CASE WHEN {db.Dialect.P("RepairSections")}=1 THEN {db.Dialect.P("Sections")} ELSE SectionsJson END," +
                        $"AssignmentRulesJson=CASE WHEN {db.Dialect.P("RepairRules")}=1 THEN {db.Dialect.P("Rules")} ELSE AssignmentRulesJson END " +
                        $"WHERE Id={db.Dialect.P("Id")}",
                        [
                            new("RepairFields", repairFields ? 1 : 0),
                            new("Fields", JsonSerializer.Serialize(fields, JsonDefaults.Options)),
                            new("RepairView", repairView ? 1 : 0),
                            new("ViewConfig", JsonSerializer.Serialize(viewConfiguration, JsonDefaults.Options)),
                            new("RepairSections", repairSections ? 1 : 0),
                            new("Sections", JsonSerializer.Serialize(sections, JsonDefaults.Options)),
                            new("RepairRules", repairRules ? 1 : 0),
                            new("Rules", JsonSerializer.Serialize(assignmentRules, JsonDefaults.Options)),
                            new("Id", templateId)
                        ], ct);
                }
            }
            return templateId;
        }

        await db.ExecuteAsync($"INSERT INTO Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Code")},{db.Dialect.P("Name")},1,'Published','Deterministic',{db.Dialect.P("Sections")},{db.Dialect.P("Fields")},{db.Dialect.P("Rules")},{db.Dialect.P("ViewConfig")},{db.Dialect.P("WorkflowId")},{db.Dialect.P("Now")},'SYSTEM')",
            [
                new("Id", templateId),
                new("Code", templateCode),
                new("Name", "Desktop Due Diligence Money Mule"),
                new("Sections", JsonSerializer.Serialize(sections, JsonDefaults.Options)),
                new("Fields", JsonSerializer.Serialize(fields, JsonDefaults.Options)),
                new("Rules", JsonSerializer.Serialize(assignmentRules, JsonDefaults.Options)),
                new("ViewConfig", JsonSerializer.Serialize(viewConfiguration, JsonDefaults.Options)),
                new("WorkflowId", workflowId),
                new("Now", now)
            ], ct);

        await db.ExecuteAsync($"INSERT INTO WorkflowDefinitions(Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("TemplateId")},1,{db.Dialect.P("Name")},{db.Dialect.P("Json")},1,{db.Dialect.P("Now")},'SYSTEM')",
            [
                new("Id", workflowId),
                new("TemplateId", templateId),
                new("Name", "Desktop Due Diligence Money Mule Flow"),
                new("Json", JsonSerializer.Serialize(workflowDefinition, JsonDefaults.Options)),
                new("Now", now)
            ], ct);

        return templateId;
    }

    private async Task EnsureDesktopDueDiligenceDashboardsAsync(long templateId, CancellationToken ct)
    {
        await EnsureTemplateDashboardAsync(
            code: "DT_DD_MONEY_MULE_DT_USER",
            name: "Desktop Due Diligence - DT User",
            title: "Desktop Due Diligence Money Mule",
            description: "",
            templateId: templateId,
            groupByFields: new[] { "BranchCode", "AnalystName" },
            metrics: new object[]
            {
                new { code="TOTAL", title="Total Record", type="Count", field="", value="" },
                new { code="CONTINUE", title="Continue Txn Restriction", type="FieldEquals", field="CDFinalRecommendation", value="Continue Txn Restriction" },
                new { code="REMOVE", title="Remove Txn Restriction", type="FieldEquals", field="CDFinalRecommendation", value="Remove Txn Restriction" },
                new { code="PENDING", title="Pending", type="FieldEquals", field="CurrentStageName", value="DT User Review" }
            },
            gridColumns: new[] { "AlertNo", "AccountId", "CustomerId", "RuleId", "ProductName", "Unit", "TotalLiveLoanAmount", "CustomerPermanentState", "CustomerDateOfBirth", "CustomerCountry", "Status" },
            searchFields: new[] { "AlertNo", "AccountId", "CustomerId" },
            pageSize: 20,
            displayOrder: 10,
            roleCodes: new[] { "DT_USER" },
            ct: ct);

        await EnsureTemplateDashboardAsync(
            code: "DT_DD_MONEY_MULE_DT_VERIFIER",
            name: "Desktop Due Diligence - DT Verifier",
            title: "Desktop Due Diligence Money Mule",
            description: "DT Verifier dashboard for Desktop Due Diligence Money Mule alerts.",
            templateId: templateId,
            groupByFields: new[] { "BranchCode", "AnalystName" },
            metrics: new object[]
            {
                new { code="TOTAL", title="Total", type="Count", field="", value="" },
                new { code="CONTINUE", title="Continue Txn Restriction", type="FieldEquals", field="CDFinalRecommendation", value="Continue Txn Restriction" },
                new { code="REMOVE", title="Remove Txn Restriction", type="FieldEquals", field="CDFinalRecommendation", value="Remove Txn Restriction" },
                new { code="CLOSED", title="Closed", type="StatusCount", field="", value="Closed" },
                new { code="PENDING", title="Pending", type="StatusCount", field="", value="Pending" }
            },
            gridColumns: new[] { "AlertNo", "AccountId", "CustomerId", "RuleId", "ProductName", "Unit", "TotalLiveLoanAmount", "CustomerPermanentState", "CustomerDateOfBirth", "CustomerCountry", "Status", "CurrentStageName" },
            searchFields: new[] { "AlertNo", "AccountId", "CustomerId" },
            pageSize: 20,
            displayOrder: 11,
            roleCodes: new[] { "DT_VERIFIER" },
            ct: ct);
    }

    private async Task EnsureTemplateDashboardAsync(string code,string name,string title,string description,long templateId,IReadOnlyList<string> groupByFields,object[] metrics,IReadOnlyList<string> gridColumns,IReadOnlyList<string> searchFields,int pageSize,int displayOrder,IReadOnlyList<string> roleCodes,CancellationToken ct)
    {
        var existingId = await db.ScalarAsync<long?>($"SELECT Id FROM TemplateDashboardMaster WHERE Code={db.Dialect.P("Code")}",[new("Code",code)],ct);
        var id = existingId ?? CatsId.Next();
        var now = DateTime.UtcNow;
        var args = new DbArg[]
        {
            new("Id", id), new("Code", code), new("Name", name), new("Title", title), new("Description", description),
            new("TemplateId", templateId), new("AlertType", ""), new("GroupBy", JsonSerializer.Serialize(groupByFields, JsonDefaults.Options)),
            new("Metrics", JsonSerializer.Serialize(metrics, JsonDefaults.Options)), new("Columns", JsonSerializer.Serialize(gridColumns, JsonDefaults.Options)),
            new("Search", JsonSerializer.Serialize(searchFields, JsonDefaults.Options)), new("PageSize", pageSize), new("DisplayOrder", displayOrder), new("Now", now)
        };
        if ((await db.ScalarAsync<int>($"SELECT COUNT(1) FROM TemplateDashboardMaster WHERE Id={db.Dialect.P("Id")}",[new("Id",id)],ct)) == 0)
            await db.ExecuteAsync(
                $"INSERT INTO TemplateDashboardMaster(Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive,CreatedAtUtc,UpdatedAtUtc) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Code")},{db.Dialect.P("Name")},{db.Dialect.P("Title")},{db.Dialect.P("Description")},{db.Dialect.P("TemplateId")},{db.Dialect.P("AlertType")},{db.Dialect.P("GroupBy")},{db.Dialect.P("Metrics")},{db.Dialect.P("Columns")},{db.Dialect.P("Search")},{db.Dialect.P("PageSize")},{db.Dialect.P("DisplayOrder")},1,1,{db.Dialect.P("Now")},{db.Dialect.P("Now")})",
                args,ct);
        else
            await db.ExecuteAsync(
                $"UPDATE TemplateDashboardMaster SET Name={db.Dialect.P("Name")},Title={db.Dialect.P("Title")},Description={db.Dialect.P("Description")},TemplateId={db.Dialect.P("TemplateId")},AlertType={db.Dialect.P("AlertType")},GroupByFieldsJson={db.Dialect.P("GroupBy")},MetricsJson={db.Dialect.P("Metrics")},GridColumnsJson={db.Dialect.P("Columns")},SearchFieldsJson={db.Dialect.P("Search")},PageSize={db.Dialect.P("PageSize")},DisplayOrder={db.Dialect.P("DisplayOrder")},IsDefault=1,IsActive=1,UpdatedAtUtc={db.Dialect.P("Now")} WHERE Id={db.Dialect.P("Id")}",
                args,ct);
        await db.ExecuteAsync($"DELETE FROM TemplateDashboardRoleMapping WHERE DashboardId={db.Dialect.P("DashboardId")}",[new("DashboardId",id)],ct);
        foreach (var roleCode in roleCodes.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            await db.ExecuteAsync(
                $"INSERT INTO TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) VALUES({db.Dialect.P("DashboardId")},{db.Dialect.P("RoleCode")},1)",
                [new("DashboardId", id), new("RoleCode", roleCode)], ct);
        }
    }

    private async Task AddUser(string userName,string display,string role,string dept,string branch,string[] permissions,CancellationToken ct)
    {
        await db.ExecuteAsync($"INSERT INTO CatsUsers(Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive) VALUES({db.Dialect.P("Id")},{db.Dialect.P("User")},{db.Dialect.P("Display")},{db.Dialect.P("Hash")},{db.Dialect.P("Role")},{db.Dialect.P("Dept")},{db.Dialect.P("Branch")},{db.Dialect.P("Perms")},1)",
            [new("Id",CatsId.Next()),new("User",userName),new("Display",display),new("Hash",hasher.Hash("Cats@1234")),new("Role",role),new("Dept",dept),new("Branch",branch),new("Perms",JsonSerializer.Serialize(permissions, JsonDefaults.Options))],ct);
    }
}
