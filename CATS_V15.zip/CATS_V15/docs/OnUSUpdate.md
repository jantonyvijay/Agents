
Penalty Details Section change to Penalty and Recovery Details
No.	|Field Name|Control Type
1	|Recoverable / Non-recoverable|	Dropdown  
    (Recoverable,Non-Recoverable,Goodfaith,Service Gesture)
    * if user Recoverable then Recoverable from whom – Vendor name , Penalty Reason and Penalty Reason other remarks (if any) fields are enable and   monidory
    * Goodfaith,Service Gesture selected then right side of dropdown "No Penalty Applicable" text visiable 
2	Recoverable from whom – Vendor name	| DropdownList
3	No Penalty Applicable	| Checkbox
4	Excess reported	| Dropdown (Yes,No)
5	Excess Date	| Checked Date Picker
6   Date Of Mail from Bal Team to ATM Reg Team | Checked Date Picker
7   Error in EJ | Dropdown
8	Penalty Reason | Dropdown
7	Penalty Reason other remarks (if any)	Multiline | Multiline Textbox
8	Is Transaction available in 4-way Recon	Radio Button – Yes / No
9   ATMC Remark/Feedback | Multiline Textbox
9   ATMC Actioned | Lable 
 
Case Review Section 

current one remove "Case Category"

Sr. No.	Field Name	Field Type	Displayed
1	RATC Remark/Feedback	Multiline Textbox
2	RATC Actioned	|	Lable (Pending,Completed)
3	SH Remark/Feedback	| Multiline Textbox	
4	SH Actioned	Status	| Lable (Pending,Completed,NA)
5	RH Remark/Feedback	Multiline Textbox	
6	RH Actioned	Status	| Lable (Pending,Completed,NA)
7	GH Remark/Feedback	Multiline Textbox	
8	GH Actioned	Status	| Lable (Pending,Completed,NA)

Recoverable from whom – Vendor name DropdownList
Sr. No.	Vendor Name
1	Admin – Boparai
2	Admin – Modem
3	Admin – Securens
4	Admin – Ziacom
5	AGS-CPT
6	AGS-EJ
7	CMS
8	Diebold-CPT
9	Diebold-EJ
10	Euronet-CPT
11	FSS-MS
12	FSS-CPT
13	FSS-LITE
14	GRG
15	OEM - HITACHI
16	NCR
17	NCR-EJ
18	NCR-LITE
19	NCR e-surveillance
20	OEM - AGS
21	OEM - Diebold
22	OEM - NCR
23	OEM - WINCOR
24	OEM - OKI
25	TSI - CPT
26	Branch

Error in EJ DropdownList
Sr.  Error / Exception Reason
1	Power interruption
2	Dispenser error - E*2
3	Dispenser error - E*3
4	Transaction missing in EJ
5	Transaction declined
6	Currency jam - E*4
7	Host transaction timeout
8	Network flapping - SST Offline/Online
9	Clear withdrawal - No error in EJ
10	EJ not available
11	Cash presented timer Expired-Customer forgot to collect cash
12	Cash presented timer Expired-Machine issue
13	Cash presented timer Expired-Shutter fraud
14	Other, Mentioned in remarks
15	Timer Expired Card Not Taken
16	Cash Not Taken By Customer In Time
17	Cash Retract
18	Cash Retained
19	Media left behind

Penalty Reason Dropdown list
Sr. No.	Exception / Dispute Reason
1	No excess reported by CRA
2	No excess reported by Branch
3	Delay in excess reported by CRA
4	Delay in excess reported by Branch
5	Excess reported on time but transaction was suspect/Unidentified/Multiple Transaction Error
6	Delayed by region
7	Staff error
8	Misdispensation
9	Partial dispensation
10	Denomination interchange
11	Delay in CCTV footage provided by vendor
12	Delay in CCTV footage provided by Branch
13	CCTV not provided by vendor
14	CCTV not provided by branch
15	Customer forgot to collect cash & Security guard/Stranger
16	Customer forgot to collect cash & Branch staff
17	Shutter Fraud
18	Misdispensation /Partial dispensation / Denomination interchange
19	EJ Not Available
20	ATM/CRM machine issue
21	Excess reported but due to holidays delayed in credit
22	As per the CCTV footage customer did not get the cash
23	Other, Mentioned in remarks
24	Delayed due to internal process
25	Delay in Cash dispensed