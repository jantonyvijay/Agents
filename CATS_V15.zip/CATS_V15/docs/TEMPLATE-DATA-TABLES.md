# Template data tables (generated from the front end)

A template (Alert Type) can keep its data in **its own table**, generated from its fields. No code or hand-written SQL is needed for a new Alert Type.

## How it works

- **Where:** Template Designer → *Data Storage* section, or automatically when the template's workflow is **published**.
- **First generation** creates `dbo.<table>` (default `tbl_<TEMPLATE_CODE>`, editable before the first generation) with:
  `AlertId` (key, linked to `Alerts`), `SourceBatchId`, `SourceRowNumber`, `SourceDataJson` (full JSON copy), `CreatedAtUtc`, `UpdatedAtUtc`,
  plus **one typed column per field**: number → `decimal(19,4)`, date/datetime → `datetime2`, checkbox → `bit`, textarea → `nvarchar(max)`,
  other text → `nvarchar(n)` using the field's *Max length* (default 500, over 4000 → `nvarchar(max)`).
- Column names are made safe automatically (spaces and symbols become `_`, a leading digit gets `F_`, a clash with a standard column or another field gets a numeric suffix such as `AlertId_2`).
- The field → column mapping is stored in `TemplateDataTable` / `TemplateDataColumn`.
- **Existing alerts** of the template are copied into the new table when it is first generated (including their routing information).
- **Later changes:** *Update table* (or the next publish) **adds** columns for new fields and **widens** text columns. Columns are never dropped or narrowed, and a field removed from the template keeps its column.
- Until a field has a column, its value is still safe in `SourceDataJson`, so nothing is lost between saving the template and updating the table.

## Not affected

- Templates without a generated table keep storing data exactly as before (JSON).
- `ATM_ONUS` / `ATM_OFFUS` keep their own hand-built tables and are never touched by the generator.

## Notes

- Generation is available for **SQL Server** only; the registry tables exist for PostgreSQL and Oracle but the generator reports "not supported" there.
- With `DatabaseStartup:AutoInitialize=false` the registry tables are not created at startup; run `db/sqlserver/schema.sql` once (it is re-runnable) before using this feature.
- Sensitive fields are stored the same way as before (the value as entered; masking happens when displayed).
