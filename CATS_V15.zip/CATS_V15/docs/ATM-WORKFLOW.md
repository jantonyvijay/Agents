# ATM workflow in CATS

ATM is implemented as a CATS feature, not as a separate application or workflow engine. The ATM OnUs and OffUs business records are stored in separate alert-specific tables and reference the ordinary CATS alert. CATS owns workflow instances, work items, audit records, alert visibility, and the common dashboard. The seeded ATM workflows can be edited and versioned in the existing Template and Workflow Designers.

## Delivered flow

- **Monthly uploads:** DBOPS Maker uploads the monthly Mapping Master and OnUs/OffUs penalty files. Each file is staged as a batch for independent DBOPS Checker approval. ATM Staff Master is uploaded by DBOPS Maker to support RATC reassignment eligibility. Approval replaces the relevant active master snapshot in one database transaction; rejection leaves the active snapshot unchanged.
- **Penalty file upload:** OnUs and OffUs files are staged for independent DBOPS Checker approval. Uploaded rows are encrypted at rest in the batch table. The maker selects penalty month/year because the OnUs source file contains 15 business columns and no period columns.
- **Case creation:** Approval checks the ATM mapping, creates CATS alerts through the existing alert service, starts the published ATM template workflow, and writes case fields to the appropriate OnUs or OffUs table.
- **Workflow:** Seeded templates use ATMC → RATC → SH. OnUs uses **Recoverable / Non-recoverable** for routing: Recoverable, Service Gesture, and Goodfaith close at SH; other cases at or below 10,000 route to RH, and higher amounts route to GH. OffUs retains its existing Case Category routing. RH/GH approval closes the case; rejection ends it as Rejected.
- **Reopen:** RATC may request reopening of a closed ATM case. DBOPS Checker approval creates a new CATS alert from the original case and starts the ATM workflow from ATMC; the original remains in the audit history.
- **Reassign:** RATC can reassign a pending case only to an active CATS user of its current workflow role who is present in the approved ATM Staff Master for the case ATMID.
- **Dashboard:** Both ATM templates appear in the existing all-template dashboard and alert list; OnUs and OffUs remain filterable as distinct alert types.

The generic CATS alert CSV endpoint rejects ATM templates so cases cannot bypass the ATM maker-checker process.

## File contracts and storage

Uploads accept up to 20,000 data rows and 30 MB. Header matching ignores case and punctuation. Rows with a different number of values than the header are rejected with a row number.

**OnUs and OffUs penalty files are configured in Template Designer, not hardcoded.** Open the ATM OnUs or OffUs alert type and use *Source Column Mapping › Bulk File Upload*:

- **File format:** Auto (CSV or TXT), CSV (`.csv`), TXT (`.txt`) or Excel (`.xlsx`, first visible worksheet, header in the first row). An upload of any other type is rejected.
- **Column separator** (CSV/TXT): auto-detect comma or tilde, or comma, tilde, pipe, semicolon, tab, or one custom character.
- **Source Column:** the column header in the file for each display field. Edit it whenever the file layout changes; a blank value uses the field name. Several fields may read the same file column.
- **Required in file:** a file missing a required column is rejected with the column names. Un-tick it to make a column optional (its field is then blank).

The seeded defaults match the documented files: all 15 OnUs headers are required (`Type of Settlement`, `CRM No/Proactive No`, ... `Narration`); for OffUs only `ATM ID` and `Customer Penalty` are required. The Source Column Mapping grid lists the mapped table columns in file order; each row can be edited (file column, *Required in file*, order) or deleted, and **Add column** picks any other column of the OnUs/OffUs table (workflow, recovery and reopen columns are available on SQL Server only). Nothing is locked: `Penalty_Month`, `Penalty_Year`, `UploadFileName`, `CreatedBy` (file `UploadBy`) and `CreatedDate` (file `UploadDate`) are ordinary columns that can be added when a file supplies them. A file value wins when present; otherwise CATS fills the period from the upload form and the file name, uploader and upload time from the upload itself. The CATS linkage columns (`ATMID`, `PenaltyMonth`, `PenaltyAmount`, `CaseCategory`, source batch/row) are derived — from `ATM_ID`, `Penalty_Month` and `Penalty_Rs` (OnUs) / `Customer_Penalty` (OffUs) — and never appear in the mapping, so there are no duplicate rows. `ATM_ID` and the penalty column cannot be deleted because case creation and workflow routing read them. **ATM Operations › Download sample file** produces a ready-to-upload sample (OnUs and OffUs: tilde-delimited `.txt` with the documented headers in order) from the current mapping, so it always reflects admin edits, the chosen format and the separator. **Reset to default mapping** restores the 15 OnUs / 17 OffUs documented columns. The defaults are seeded once and never overwritten at startup; mappings seeded earlier have their derived/locked rows removed once. File columns whose header happens to equal a table column name are ignored unless mapped. Mapping Master and Staff Master files are not template-driven and use these headers:

| File type | Required headers | Optional/useful headers |
| --- | --- | --- |
| Mapping Master | `ATM_ID` | `ATMC_EMPCode`, `ATMC_EMPCode_BK`, `RATC_EMPCode`, `RATC_EMPCode_BK`, `SH_EMPCode`, `WBO_RH_EMPCode`, `RH_EMPCode`, `RH_EMPCode_BK`, `GH_EMPCode`, `GH_EMPCode_BK`, `STATE` |
| Staff Master | `ATM_ID`, `EmployeeId` or `EmployeeCode` | Additional staff fields |

Headers are matched case-insensitively and punctuation-insensitively. OnUs and OffUs source fields are persisted to typed columns in their corresponding CATS alert tables (the SQL columns are fixed by the schema and populated from the template fields of the same name); the full normalized source row is also retained in `SourceDataJson` for auditability. A template field you add that has no typed SQL column appears in the case detail and in `SourceDataJson`. Pending/rejected batches remain in the shared encrypted `ATM_UploadBatches` queue. Workflow status and action history remain in CATS work items/audits rather than duplicated legacy `*_Status` columns, preventing two conflicting workflow sources of truth.

The published ATM templates define the mapped source fields as read-only fields in the CATS case-detail form. At API startup, missing built-in ATM fields are added to existing OnUs/OffUs template definitions without replacing administrator-added fields or view settings. OnUs replaces the former **Case Category** field with **Penalty and Recovery Details**: Recoverable / Non-recoverable; vendor; No Penalty Applicable; excess and mail dates; EJ error; penalty reason and remarks; and 4-way reconciliation. Vendor, penalty reason, and penalty-reason remarks are enabled and mandatory only for Recoverable cases. Goodfaith and Service Gesture automatically show No Penalty Applicable. The Case Review contains ATMC, RATC, SH, RH, and GH remarks with their action status. The ATM templates do not add Branch Code to Alert List Configuration by default; OnUs and OffUs list fields remain specific to their configured module. The template designer's alert-list settings control which configured fields appear in dashboard grids and filters; removing an optional template field removes it from those surfaces on save, while the source record remains in its typed ATM column and `SourceDataJson`. The template save endpoint does not retain or require any hardcoded ATM field, option, or dependency; upload linkage values are derived from the approved file and upload period. When adding a template field that should be populated from an upload, use its source header or mapped column name; otherwise it will be blank in alert details.

Mapping employee-code values (including backup columns) must identify an active CATS user by ID or username and match the named database-backed role. If a mapping value is blank, the published workflow's role-based assignment applies. `EmployeeId`/`EmployeeCode` in Staff Master must identify a CATS user ID or username for reassignment to succeed. If CustomerId or AccountId is not provided, the CATS alert stores an encrypted `ATM:<ATMID>` placeholder to satisfy the shared alert schema; no customer/account identifier is inferred from the ATM record.

## Roles and permissions

Provision CATS users with these role codes as appropriate: `DBOPS_MAKER`, `DBOPS_CHECKER`, `ATMC`, `RATC`, `SH`, `RH`, and `GH`. Role suggestions come from active `RoleMaster` rows. ATM role records, permission definitions, and default role-permission mappings are seeded idempotently at API startup; role permissions are granted through `RolePermissionMapping`, and individual user grants are stored in `UserPermissionMapping`. These are database-backed access controls, not role-name checks embedded in the UI. This feature does not create user accounts or passwords automatically.

| Role | ATM responsibility |
| --- | --- |
| DBOPS Maker | Upload monthly Mapping Master, OnUs/OffUs penalty files, and ATM Staff Master for checker review. Requires `ATM.UPLOAD`. |
| DBOPS Checker | Independently approve or reject uploads and decide RATC reopen requests. Requires `ATM.CHECK`; cannot decide their own upload or reopen request. |
| ATMC | Review assigned cases, set the required case category, and submit to RATC. |
| RATC | Review and approve cases to SH; request reopening of closed cases; reassign pending cases to eligible staff mapped to the case ATMID. Requires `ATM.CASE.MANAGE` and `ALERT.REASSIGN`. |
| SH | Close Recoverable, Service Gesture, Goodfaith, and Acquiring Dependency cases; route Non-Recoverable cases by penalty amount. |
| RH | Approve/reject Non-Recoverable cases with penalty amount at or below 10,000. |
| GH | Provide final approval/rejection for Non-Recoverable cases above 10,000. |

A maker cannot decide their own file batch. DBOPS Checker and Admin can decide upload and reopen requests.

For deployments using SQL Server with automatic schema initialization disabled, apply [CATS_V13_ATM_RoleMaster_Upgrade.sql](../db/sqlserver/CATS_V13_ATM_RoleMaster_Upgrade.sql) to seed the ATM roles and their permission mappings.

## Schema and upgrade

With SQL Server automatic initialization enabled, startup adds missing CATS linkage columns to existing legacy OnUs/OffUs tables before creating their indexes and foreign keys. Existing legacy rows are retained with nullable alert/source links; this does not import them into a workflow. After updating the schema scripts, rebuild the API before using `dotnet run --no-build`, because startup reads the schema copied to the build output.

Database initialization creates the ATM tables idempotently for SQL Server, PostgreSQL, and Oracle. For deployments with automatic initialization disabled, apply the provider's V12 ATM workflow upgrade followed by its V14 file-mapping upgrade and V15 CATS-linkage upgrade: [SQL Server V12](../db/sqlserver/CATS_V12_ATM_Workflow_Upgrade.sql), [V14](../db/sqlserver/CATS_V14_ATM_OnUs_FileMapping_Upgrade.sql), [V15](../db/sqlserver/CATS_V15_ATM_LegacyColumns_Upgrade.sql); [PostgreSQL V12](../db/postgresql/CATS_V12_ATM_Workflow_Upgrade.sql), [V14](../db/postgresql/CATS_V14_ATM_OnUs_FileMapping_Upgrade.sql), [V15](../db/postgresql/CATS_V15_ATM_LegacyColumns_Upgrade.sql); or [Oracle V12](../db/oracle/CATS_V12_ATM_Workflow_Upgrade.sql), [V14](../db/oracle/CATS_V14_ATM_OnUs_FileMapping_Upgrade.sql), [V15](../db/oracle/CATS_V15_ATM_LegacyColumns_Upgrade.sql). The SQL Server V15 migration is additive: it keeps the newly created legacy OnUs/OffUs tables and existing rows, adding only the CATS alert/source linkage fields and constraints the application requires. It does not drop either table. PostgreSQL V15 rebuilds only OffUs and must only be used with the confirmed-empty table; Oracle V15 adds OffUs compatibility columns. Use the script for the matching database provider; do not run PostgreSQL syntax in SQL Server. On startup, the API seeds the published OnUs and OffUs templates/workflows even when automatic schema initialization is disabled, so the alert-type lists are populated for an already upgraded database. Two separate case tables, `tbl_ATM_Txn_Mntr_OnUs` and `tbl_ATM_Txn_Mntr_OFFUs`, share the CATS `Alerts` key but are not merged into a generic ATM case table. CATS WorkItems and AuditLog remain authoritative for workflow state and history.

ATM upload approval creates each alert through CATS's ordinary workflow service. This preserves the existing workflow version and audit behavior. Multi-row alert creation is resumable by source batch/row key; a failure is returned explicitly and the batch remains pending so the checker can retry after the reported configuration/data issue is fixed.
