# ATM Staff Mapping (Masters › ATM › Staff Mapping)

The ATM-to-staff mapping is a standalone **master**, not an alert template. It lives in `tbl_ATM_Txn_Mntr_MappingMaster`, has its own pages and its own configurable file layout, and drives who each new ATM penalty case is assigned to.

## Menu

The menu is stored in the database, not in code. See [MENU-MANAGEMENT.md](MENU-MANAGEMENT.md). Staff Mapping is one entry, **Masters › ATM › Staff Mapping**, and it opens the **list page**.

## Pages

| Page | Who | What |
|---|---|---|
| **List** (landing, one page) | `ATM.OPERATIONS` | Three grids as tabs: **Approved ATMs** (search, paging, *Edit*), **Pending approval** (uploads and entries waiting for a checker, with the list of people who can approve) and **History** (approved and rejected batches with checker, time and remarks). *View* opens a popup grid with the rows of any batch. Buttons: **Add / Upload** (needs `ATM.UPLOAD`, the DBOPS Maker) and **Column mapping** (needs `ATM.MASTER.CONFIGURE`). |
| **Upload & Entry** | DBOPS Maker (`ATM.UPLOAD`) | Bulk file upload, sample download, single entry (with *Load* to edit an existing ATM). Opened from **Add / Upload** or *Edit*. |
| **Approve / Reject** | DBOPS Checker (`ATM.CHECK`) | *Approve* and *Reject* appear on the Pending tab and in the *View* popup, only for users with `ATM.CHECK`, and never for the user who uploaded the batch. Others see "Awaiting a checker". |
| **Column mapping** | Administrators and the central team (`ATM.MASTER.CONFIGURE`, granted to the `ADMIN` and `CENTRAL` roles) | File format, separator and file-to-table column mapping. Hidden from everyone else. |

## Flow (monthly master data upload)

1. DBOPS Maker uploads the file or enters one ATM. The file is validated against the configured mapping and held as a **Pending** batch (encrypted in `ATM_UploadBatches`, file type `StaffMapping`). Nothing reaches the master yet.
2. DBOPS Checker reviews the rows (*View* popup) on the Pending tab and approves or rejects (a rejection reason is required). Who the checkers are is configured in Administration by granting `ATM.CHECK` to a role or a user (seeded: `DBOPS_CHECKER` and `ADMIN`); the Pending tab lists the current checkers (`GET api/atm/staff-mapping/checkers`).
3. On approval the rows are **upserted by `ATM_ID`**: new ATMs are inserted, existing ATMs are updated for the mapped columns (a blank value clears that column). ATMs that are not in the file are left alone, so single entries and earlier uploads are kept. All audit entries are written to the audit log.
4. When an ATM penalty file (OnUs/OffUs) is approved, each ATM's approved Staff Mapping row supplies the ATMC, RATC, SH, RH and GH assignees. If an ATM has no Staff Mapping row, the earlier Mapping Master entries are used as a fallback.

## File and column mapping

Default file: tilde-separated `.txt`, headers in this order (each is required):

`ATM ID~ATMC Emp code~Backup ATMC code~RATC Emp code~Backup RATC Emp code~State Head Emp Code~Backup State Head~STATE~GH EmpCode~RH EmpCode~GH EmpCode1~Backup GH EmpCode~RH EmpCode1~Backup RH EmpCode~Backup GH EmpCode1~Backup RH EmpCode1`

| File column | Table column |
|---|---|
| ATM ID | ATM_ID |
| ATMC Emp code / Backup ATMC code | ATMC_EMPCode / ATMC_EMPCode_BK |
| RATC Emp code / Backup RATC Emp code | RATC_EMPCode / RATC_EMPCode_BK |
| State Head Emp Code | SH_EMPCode |
| Backup State Head | WBO_RH_EMPCode |
| STATE | STATE |
| GH EmpCode / Backup GH EmpCode | GH_EMPCode / GH_EMPCode_BK |
| RH EmpCode / Backup RH EmpCode | RH_EMPCode / RH_EMPCode_BK |
| GH EmpCode1 / Backup GH EmpCode1 | GH_EMPCode1 / GH_EMPCode1_BK |
| RH EmpCode1 / Backup RH EmpCode1 | RH_EMPCode1 / RH_EMPCode1_BK |

Administrators and the central team change everything on the **Column mapping** page (list page › Column mapping): file format (Auto, CSV, TXT, Excel), separator, order, file column names, *Required in file*, delete rows, add any other table column (`ATMC_/RATC_/SH_EMPCode_Reassign`, `Penalty_Month`, `Penalty_Year`, upload and approval columns), and **Reset to default mapping**. `ATM_ID` cannot be removed. The header row is not shown to makers: they use **Download sample file**, which always follows the current mapping. The configuration is stored in `ATM_MasterSettings` (key `StaffMapping`), applies to the next upload, the sample file and the single-entry form, and is not part of any template.

`UploadFileName`, `CreatedBy` (file `UploadBy`) and `CreatedDate` (file `UploadDate`), `RecordStatus`, `ModifiedBy/Date` and `ApprovedBy/Date` are filled by CATS when the file does not supply them: the upload file name, the maker, the upload time, `Approved`, and the checker with the approval time.

## Database

At startup the API also creates one sign-in for each ATM role that has none, so the maker-checker flow and the assignee chain can be used immediately: `dbops_maker`, `dbops_checker`, `atmc1`, `ratc1`, `sh1`, `rh1`, `gh1` (roles `DBOPS_MAKER`, `DBOPS_CHECKER`, `ATMC`, `RATC`, `SH`, `RH`, `GH`). They use the standard seeded password (`Cats@1234`); change it or replace them with real staff. Existing users are never touched. In Staff Mapping, an employee code must be the user name (or id) of an active user whose role matches the stage, so these user names can be used as codes.

`db/*/schema.sql` creates `ATM_MasterSettings` and `tbl_ATM_Txn_Mntr_MappingMaster` at startup (additive; an existing table gets the missing columns and a unique index on `ATM_ID` when it has no duplicates). `db/sqlserver/CATS_V16_ATM_StaffMapping_Upgrade.sql` is the same change for manual runs.

## API

`GET/PUT api/atm/staff-mapping/config`, `GET …/sample`, `POST …/uploads`, `POST …/entries`, `GET …/records[/{atmId}]`, `GET …/batches`, `GET …/batches/{id}/rows`. Approval uses `POST api/atm/uploads/{id}/decision`.
