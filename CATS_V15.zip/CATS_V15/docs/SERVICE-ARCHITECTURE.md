﻿# Service architecture

CATS now separates UI hosting from API hosting. The public gateway keeps the browser's existing URLs unchanged.

```mermaid
flowchart LR
    Browser --> Gateway["CATS.Gateway :7000"]
    Gateway -->|"pages, JS, CSS"| UI["CATS.App :7001"]
    Gateway -->|"/api/*"| API["CATS.Api :7002"]
    MCP["CATS.McpServer :9000"] --> Gateway
    API --> Workflow["Workflow and AI libraries"]
    API --> Database[(CATS database)]
    API --> Files[(Attachment volume)]
```

## Responsibilities

| Project | Owns |
| --- | --- |
| CATS.App | Home controller, Razor views, browser modules, static assets; no database or JWT configuration |
| CATS.Api | API controllers, JWT issuance/validation, gateway access validation, application services, database initialization, attachment access |
| CATS.Gateway | Public routing, gateway-header injection, CORS and rate limiting |
| CATS.McpServer | MCP transport and authenticated calls to the API through the gateway by default |
| CATS.Ingestion.Worker | Existing ingestion scheduling process |

The API is independently buildable and deployable. It retains the existing domain libraries and database schema. This is a UI/API service separation; alerts, templates, reporting, and identity still share one API deployment and database. Further domain-service extraction requires explicit ownership and transaction boundaries.

## Run locally

Stop the previous development processes before restarting; they may lock the Debug build output. Run `scripts/run.ps1`, or select the `CATS with MCP` solution launch profile. Both launch the UI, API, gateway, and MCP server. Browse `http://127.0.0.1:7000`.

Individual hosts:

```powershell
dotnet run --project src/CATS.Api --launch-profile CATS.Api
dotnet run --project src/CATS.App --launch-profile CATS.App
dotnet run --project src/CATS.Gateway --launch-profile CATS.Gateway
dotnet run --project src/CATS.McpServer -p:UseAppHost=false
```

Debug UI/API/gateway builds use the installed .NET host to avoid the previously blocked generated launcher. The UI is intended to be opened through the gateway: its default API base URL is same-origin.

## Configuration and existing data

- Database, security, JWT, storage, AI, assistant, MCP discovery, and gateway-access settings moved to `src/CATS.Api/appsettings.json`. Move corresponding production environment variables and secret bindings to the API deployment.
- `CATS.App` retains `Frontend:ApiBaseUrl`, logging, and host settings. It has no reference to the API project or data libraries.
- API routes, request/response contracts, authorization, encryption, workflow rules, and the database schema are unchanged.
- Development uses `CATS.Api/appsettings.Development.json` to keep reading and writing the existing `CATS.App/App_Data/attachments` directory. This is a transitional development storage setting, not an application dependency. Existing uploads remain accessible without moving live files.
- For independent deployment, mount persistent attachment storage at an absolute `Storage:AttachmentRoot` (environment variable `Storage__AttachmentRoot`). Reuse the existing production volume, or migrate it while uploads are stopped. Keep stored filenames unchanged; attachment metadata stays in the database. The base API configuration defaults to its own `App_Data/attachments` directory.
- MCP direct API routing now uses port 7002. Gateway routing remains the default. Direct API requests still require the configured gateway key when `GatewayAccess:RequireForApi=true`.
- `/health/live` exists on each UI/API host. `/api/health/live` is available through the gateway and remains subject to gateway access validation. Liveness confirms the host is running; it does not probe database readiness.

## Verification

```powershell
dotnet restore CATS.sln
dotnet build CATS.sln -c Release --no-restore -p:UseAppHost=false
dotnet run --project scripts/PiChecks -c Release -p:UseAppHost=false
node --experimental-vm-modules scripts/check-app-modules.cjs
node --experimental-vm-modules scripts/check-app-startup.cjs
node --experimental-vm-modules scripts/check-template-modals.cjs
node --experimental-vm-modules scripts/check-user-appearance.cjs
powershell -NoProfile -File scripts/check-service-boundaries.ps1
```

`scripts/smoke-test.ps1` remains the database-backed workflow test. It creates and advances an alert, so run it against a designated test database.
