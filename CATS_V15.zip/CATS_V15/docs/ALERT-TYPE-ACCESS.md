# Alert Type access (by role and permission)

The Alert Type dropdown in **New / Upload Alerts**, **Dashboard** and **Alerts** lists only the Alert Types a user may work with. The rules are rows in `AlertTypeAccess` (`TemplateCode`, `RoleCode`, `PermissionCode`, `IsActive`).

- An Alert Type with **no active rows is open to everyone** (so existing and new types keep working until restricted).
- Otherwise a user sees it when **at least one row matches**: the row's `RoleCode` (if set) equals the user's role **and** the row's `PermissionCode` (if set) is held by the user. A row needs a role or a permission.
- Users with `TEMPLATE.MANAGE` or `ADMIN` see every type, so they can always configure them.
- The check is applied to the template list the dropdowns use, and again when an alert is created, a file is uploaded or a sample is downloaded.

Seeded once, while the table is empty (afterwards the table is yours):

| Alert Type | Visible to |
|---|---|
| `ATM_ONUS`, `ATM_OFFUS` | permission `ATM.OPERATIONS` (ATM roles, DBOPS Maker/Checker) or `ALERT.VIEWALL` |
| `DT_DD_MONEY_MULE` | roles `DT_USER`, `DT_CHECKER`, `DT_VERIFIER`, `CENTRAL`, `AUDITOR`, or permission `ALERT.VIEWALL` |
| `GENERIC_ALERT` and any other type | everyone |

To add a module, add its Alert Type's rows here and its menu rows in `MenuMaster` ([MENU-MANAGEMENT.md](MENU-MANAGEMENT.md)). Users sign in again after their role or permissions change.

## ATM penalty files in New / Upload Alerts

Picking `ATM_ONUS` or `ATM_OFFUS` shows **Penalty month / year**; the file is read with that Alert Type's Source Column Mapping, format and separator and is sent to a DBOPS Checker (`POST api/atm/uploads`), not created directly. Users with `ATM.CHECK` get a **Pending ATM approvals** panel on the same page: uploads (view the rows in a popup, approve or reject) and reopen requests. The uploader cannot decide their own upload. A pure approver (`ATM.CHECK` without `ALERT.UPLOAD`, e.g. `DBOPS_CHECKER`) sees **only** that panel: no Alert Type, entry form or bulk upload. `DBOPS_MAKER` holds `ALERT.UPLOAD` and `ATM.UPLOAD`; ATM types are hidden from anyone without `ATM.UPLOAD`.
