# Template Designer - Source Column Mapping

The Template Designer's **Source Column Mapping** section connects the columns of each data source to the template's display fields (the *Fields* list). It sits below *Alert List Configuration* and has one tab per Base Data option that is enabled for the alert type.

| Tab | What it maps |
| --- | --- |
| Manual Single Entry | Nothing to map: values are typed into the configured entry form, so each field is filled directly. |
| Bulk File Upload | File column header -> display field. Also holds the file format and column separator. |
| SFTP Location | Column header of the file picked up by the scheduled SFTP task -> display field. |
| FC Query | Result column name of the scheduled query -> display field. |

## Mapping rules

- **Order:** drag a row or type an Order number (as in Alert List Configuration) to set the column order of each source. The order is saved with the template and sets the column order of the downloadable sample file. Fields never reordered follow the template's field order; the seeded ATM mappings follow the documented file order.
- **Source Column** is matched ignoring case, spaces and punctuation (`T+5 Calender Days` matches `T_5_Calender_Days`). A blank value means the file column is named like the field. Several fields can read one column.
- **ATM calendar header compatibility:** `T+5 Calendar Days` and the legacy spelling `T+5 Calender Days` match the same column (including underscore variants). Both populate the existing `T_5_Calender_Days` table field; saved mappings and sample headers are unchanged. Supply only one spelling in a file: including both is rejected as duplicate columns. On an older running version, set the OnUs mapping's **Source Column** to the exact header in the file and save.
- **Required in file** (Bulk File Upload): a file without that column is rejected and the missing names are listed. Unticked columns are optional; the field is blank when the column is absent.
- Mappings for a field that is later removed are dropped when the template is saved. Mappings for a mode that is disabled stay stored but are not used.
- The mapping is stored in the template's view configuration (`SourceColumnMappings`), so no database change is required and it is versioned with the template.

## Bulk File Upload format and separator

| Setting | Values |
| --- | --- |
| File format | Auto (CSV or TXT, default for existing alert types), CSV (`.csv`), TXT (`.txt`), Excel (`.xlsx`) |
| Column separator | Auto-detect (comma or tilde), comma, tilde, pipe, semicolon, tab, or one custom punctuation character. Not used for Excel. |

The upload screens (generic *New / Upload Alerts* and *ATM Operations*) accept only the configured file type and read it with the configured separator. Excel files use the first visible worksheet with the header in the first row; formulas are never evaluated (cached values are read) and dates are read as `yyyy-MM-dd`. The sample file downloaded for an alert type is generated in the configured format with the mapped column headers.

### Troubleshooting a separator mismatch

If a comma-separated CSV is uploaded with **tilde** configured, the header is read as one column. A literal `~` in a later value (for example, `Dispenser error ~ E*3`) then produces a row-width error such as `CSV row 66 contains 2 values; expected 1`. The upload now reports separator configuration guidance for this mismatch rather than the misleading row-width error.

In **Template Designer > Source Column Mapping > Bulk File Upload** for the selected alert type, set **Column separator** to **Comma** or **Auto-detect**, save the template, then upload again. Also ensure **File format** allows CSV (CSV or Auto). Auto-detect uses the header, not punctuation inside later values. Explicit separators are never silently overridden; do not remove literal punctuation from the data to work around a configuration mismatch.

## SFTP and FC Query

When an SFTP or Query ingestion task is saved without its own field mapping, it starts from the alert type's mapping for that mode. The scheduled ingestion worker currently reads task schedules only; reading the SFTP files or running the queries is not part of this change.

## ATM OnUs / OffUs

The ATM penalty uploads use the same mapping, so an administrator or central team can change file columns, required columns, format and separator without a code change. For ATM Bulk File Upload the rows are table columns of the OnUs/OffUs table: they can be added, deleted and reordered, and the derived `ATMID`/`PenaltyAmount`/`PenaltyMonth` are never listed. Defaults are seeded once at startup and are never overwritten; the designer's **Reset to default mapping** restores them. `ATM_ID` and the penalty column (`Penalty_Rs` for OnUs, `Customer_Penalty` for OffUs) must stay mapped. See [ATM-WORKFLOW.md](ATM-WORKFLOW.md).
