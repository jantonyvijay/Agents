# ATM On-Us Transaction Monitoring - File Upload Mapping

The upload file contract below is the **default** mapping. It is editable by an administrator in Template Designer (*ATM OnUs / OffUs › Source Column Mapping › Bulk File Upload*): the source column for each field, whether it is required in the file, the file format (CSV, TXT or Excel `.xlsx`) and the column separator. Uploads always follow the saved configuration. During validation, CATS maps each source header to its template field (and SQL column) and retains the source fields in the encrypted maker-checker batch. After checker approval, CATS creates an alert and stores the typed mapped values in the OnUs alert table.

## SQL Server ATM On-Us Transaction Column Mapping

**Database:** `CATS`  
 
| Sr. No. | File column (exact header) | SQL column | Target table |
|---:|---|---|---|
| 1 | Type of Settlement | Settlement_Type | tbl_ATM_Txn_Mntr_OnUs |
| 2 | CRM No/Proactive No | CRM_Proactive_No | tbl_ATM_Txn_Mntr_OnUs |
| 3 | Transaction Date | Transaction_Date | tbl_ATM_Txn_Mntr_OnUs |
| 4 | Date of Customer complaint | Customer_Complaint_Date | tbl_ATM_Txn_Mntr_OnUs |
| 5 | Date of credit to customer a/c | Customer_Acc_Credit_Date | tbl_ATM_Txn_Mntr_OnUs |
| 6 | Account Number | Acc_No | tbl_ATM_Txn_Mntr_OnUs |
| 7 | T+5 Calender Days | T_5_Calender_Days | tbl_ATM_Txn_Mntr_OnUs |
| 8 | Days | Days | tbl_ATM_Txn_Mntr_OnUs |
| 9 | Penalty (Rs.) | Penalty_Rs | tbl_ATM_Txn_Mntr_OnUs |
| 10 | ATM ID | ATM_ID | tbl_ATM_Txn_Mntr_OnUs |
| 11 | Transaction Number | Transaction_No | tbl_ATM_Txn_Mntr_OnUs |
| 12 | Transaction Amount | Transaction_Amount | tbl_ATM_Txn_Mntr_OnUs |
| 13 | Disputed Amount | Disputed_Amount | tbl_ATM_Txn_Mntr_OnUs |
| 14 | EJ Error | EJ_Error | tbl_ATM_Txn_Mntr_OnUs |
| 15 | Narration | Narration | tbl_ATM_Txn_Mntr_OnUs |
| 16 | Selected in upload form | Penalty_Month | tbl_ATM_Txn_Mntr_OnUs |
| 17 | Selected in upload form | Penalty_Year | tbl_ATM_Txn_Mntr_OnUs |
| 18 | Original uploaded file name | UploadFileName | tbl_ATM_Txn_Mntr_OnUs |
| 19 | Uploading maker | CreatedBy | tbl_ATM_Txn_Mntr_OnUs |
| 20 | Upload timestamp | CreatedDate | tbl_ATM_Txn_Mntr_OnUs |

The supplied legacy mapping labels the staging target `tbl_ATM_Txn_Mntr_OnUs_Maker`. CATS keeps pending rows in its encrypted `ATM_UploadBatches` maker-checker queue instead of duplicating pending data in a second physical maker table. After checker approval, CATS stores the mapped values in the OnUs table using the CATS-integrated structure shown in the SQL Server schema: alert linkage, canonical ATM/month/amount values, source batch/row identity, all 15 mapped transaction columns, and upload file/maker metadata. The checker and decision timestamp remain in the upload batch and audit records; they are not duplicated as OnUs table columns. CATS WorkItems and AuditLog remain authoritative for workflow status and action history.

Do not drop and recreate this table to apply the mapping. Its `AlertId` primary key and foreign key link cases to CATS Alerts, and existing rows may be referenced by workflow and audit data. The schema definition applies to new databases; existing deployments must use additive migrations and preserve existing rows. Any unused columns left by an earlier upgrade are harmless and should not be removed as part of this change.

The default file does not contain penalty month/year columns. The maker selects them in the upload form; CATS stores each selected value once in `Penalty_Month` and `Penalty_Year` and in canonical workflow fields where needed. If an administrator adds `Penalty_Month`/`Penalty_Year` to the Source Column Mapping, a valid file value is used instead of the form value.

## File Upload Header

The upload must contain these 15 source headers by default (each marked *Required in file*). CATS matches header case and punctuation-insensitively, rejects missing required headers and duplicate headers after normalization, and by default auto-detects the comma or `~` (tilde) separator; set a fixed separator or Excel format in Template Designer if needed:

```text
Type of Settlement~CRM No/Proactive No~Transaction Date~Date of Customer complaint~Date of credit to customer a/c~Account Number~T+5 Calender Days~Days~Penalty (Rs.)~ATM ID~Transaction Number~Transaction Amount~Disputed Amount~EJ Error~Narration
```

## OffUs table mapping

OffUs uses its own `tbl_ATM_Txn_Mntr_OFFUs` table and the separate legacy layout provided for that module. The upload header-to-column mapping is independent of OnUs:

| File header | SQL column |
|---|---|
| Chargeback reference no | Chargeback_Ref_No |
| Chargeback Date | Chargeback_Date |
| Acquiring Bank | Acquiring_Bank |
| Issuing Bank | Issuing_Bank |
| Transaction Date | Transaction_Date |
| Transaction Time | Transaction_Time |
| RRN no | RRN_No |
| ATM ID | ATM_ID |
| Card number | CARD_No |
| Transaction Amount | Transaction_Amount |
| Disputed Amount | Disputed_Amount |
| Customer Penalty | Customer_Penalty |
| Adjustment Date | Adjustment_Date |
| Adjustment Type | Adjustment_Type |
| Adjustment Time | Adjustment_Time |
| Narration | Narration |
| Adjustment Amount | Adjustment_Amount |

The tilde-separated header is `Chargeback reference no~Chargeback Date~Acquiring Bank~Issuing Bank~Transaction Date~Transaction Time~RRN no~ATM ID~Card number~Transaction Amount~Disputed Amount~Customer Penalty~Adjustment Date~Adjustment Type~Adjustment Time~Narration~Adjustment Amount`. `EJError` and `MailDate` are not in the default file; add them with **Add column** in Template Designer if a file supplies them.

OffUs upload headers are mapped to the SQL column names above by default (editable in Template Designer like OnUs); only `ATM ID` and `Customer Penalty` are required in the file by default. `Penalty_Month` and `Penalty_Year` are captured by the upload form, not expected in the source file. Both ATM tables retain their module-specific legacy columns while CATS links each approved case to `Alerts` using `AlertId`.
 

Requested for OnUs Table but 
 CREATE TABLE [dbo].[tbl_ATM_Txn_Mntr_OnUs] (
        [ID] NUMERIC(36,0) IDENTITY(1,1) NOT NULL,
        [Settlement_Type] VARCHAR(100) NULL,
        [CRM_Proactive_No] VARCHAR(100) NULL,
        [Transaction_Date] DATETIME NULL,
        [Customer_Complaint_Date] DATETIME NULL,
        [Customer_Acc_Credit_Date] DATETIME NULL,
        [Acc_No] VARCHAR(20) NULL,
        [T_5_Calender_Days] DATETIME NULL,
        [Days] INT NULL,
        [Penalty_Rs] NUMERIC(18,2) NULL,
        [ATM_ID] VARCHAR(100) NULL,
        [Transaction_No] VARCHAR(100) NULL,
        [Transaction_Amount] NUMERIC(18,2) NULL,
        [Disputed_Amount] NUMERIC(18,2) NULL,
        [EJ_Error] VARCHAR(100) NULL,
        [Narration] VARCHAR(500) NULL,
        [RecordStatus] VARCHAR(250) NULL,
        [UploadFileName] VARCHAR(250) NULL,
        [CreatedBy] VARCHAR(50) NULL,
        [CreatedDate] DATETIME NULL,
        [ApprovedBy] VARCHAR(100) NULL,
        [ApprovedDate] DATETIME NULL,
        [Assigned_Bucket] VARCHAR(100) NULL,
        [Assigned_On] DATETIME NULL,
        [Assigned_By] VARCHAR(100) NULL,
        [UploadRemarks] VARCHAR(MAX) NULL,
        [ATMC_Status] VARCHAR(10) NULL,
        [ATMC_By] VARCHAR(50) NULL,
        [ATMC_ActionOn] DATETIME NULL,
        [ATMC_Remark] VARCHAR(MAX) NULL,
        [RATC_Status] VARCHAR(10) NULL,
        [RATC_By] VARCHAR(50) NULL,
        [RATC_ActionOn] DATETIME NULL,
        [RATC_Remark] NVARCHAR(MAX) NULL,
        [SH_Status] VARCHAR(10) NULL,
        [SH_By] VARCHAR(50) NULL,
        [SH_ActionOn] DATETIME NULL,
        [SH_Remark] NVARCHAR(MAX) NULL,
        [ProcessStatus] VARCHAR(50) NULL,
        [Recoverable_Type] VARCHAR(100) NULL,
        [Recoverable_VendorName] VARCHAR(100) NULL,
        [Excess_Reported] VARCHAR(10) NULL,
        [Excess_Date] DATETIME NULL,
        [Recovery_Reason] VARCHAR(250) NULL,
        [ProcessBy] VARCHAR(100) NULL,
        [ProcessOn] DATETIME NULL,
        [RecoveryReason_Remark] VARCHAR(MAX) NULL,
        [Fourwayreconcilition] BIT NULL,
        [RH_By] VARCHAR(200) NULL,
        [RH_ActionOn] DATETIME NULL,
        [RH_Status] VARCHAR(MAX) NULL,
        [RH_Remark] NVARCHAR(MAX) NULL,
        [GH_By] VARCHAR(200) NULL,
        [GH_ActionOn] DATETIME NULL,
        [GH_Status] VARCHAR(MAX) NULL,
        [GH_Remark] NVARCHAR(MAX) NULL,
        [FileType] VARCHAR(100) NULL,
        [IsReopen] INT NULL,
        [ReopenBy] VARCHAR(200) NULL,
        [ReopenOn] DATETIME NULL,
        [ReopenReason] NVARCHAR(MAX) NULL,
        [FileData_Update_By] NVARCHAR(200) NULL,
        [FileData_Update_On] DATETIME NULL,
        [Penalty_Month] VARCHAR(100) NULL,
        [Penalty_Year] VARCHAR(100) NULL,
        [ReAssignBy] VARCHAR(100) NULL,
        [ReAssignOn] DATETIME NULL,
        [ReAssignEmpId] VARCHAR(100) NULL,
        [Reopen_Sent_for_Authorisation] DATETIME NULL,
        [Reopen_Authorised_by] VARCHAR(200) NULL,
        [Reopen_Sent_for_Authorisation_By] VARCHAR(100) NULL,
        [Reopen_Authorised_Remark] NVARCHAR(MAX) NULL,
        [IsEmailSent_ATMC] INT NULL,
        [IsEmailSent_RATC] INT NULL
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];
END;

we got below 
CREATE TABLE [dbo].[tbl_ATM_Txn_Mntr_OnUs](
	[AlertId] [varchar](32) NOT NULL,
	[ATMID] [varchar](100) NOT NULL,
	[PenaltyMonth] [varchar](20) NOT NULL,
	[PenaltyAmount] [decimal](19, 4) NOT NULL,
	[CaseCategory] [varchar](60) NULL,
	[SourceBatchId] [varchar](32) NOT NULL,
	[SourceRowNumber] [int] NOT NULL,
	[ReopenedFromAlertId] [varchar](32) NULL,
PRIMARY KEY CLUSTERED 
(
	[AlertId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_ATM_OnUs_Source] UNIQUE NONCLUSTERED 
(
	[SourceBatchId] ASC,
	[SourceRowNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

1 File Upload Changes and validation and table stuture changes should be done 