# Menu management (database driven)

The navigation menu is data, not code. Both the top menu and the sidebar are built from the `MenuMaster` table through `GET api/menus`, so adding a module is a few rows, not a release.

## Structure: Menu › SubMenu › Child SubMenu

`MenuMaster` is a self-referencing tree (any depth; three levels are used today):

| Column | Meaning |
|---|---|
| `Id`, `ParentId` | Tree link. A `NULL` parent is a top-level **Menu**. |
| `Code` | Unique key, e.g. `masters.atm.staffmapping`. |
| `Label` | Text shown in the menu. |
| `Title`, `Description` | Shown on the top-menu card (`Title` only for top-level menus). |
| `Icon` | `dashboard`, `alerts`, `upload`, `mail`, `workflow` or `settings`. |
| `ViewKey` | The screen the entry opens. **Empty for a Menu or SubMenu that only groups entries** (it is rendered as a heading). |
| `PermissionCode` | Permission needed to see the entry. Empty means every signed-in user. |
| `DisplayOrder`, `IsActive` | Ordering within the parent; `0` hides the entry. Deactivate instead of deleting. |

`MenuRoleMapping(MenuId, RoleCode)` is an optional extra restriction: when an entry has rows, only those roles see it.

## Who sees what

An entry is visible when the user holds its `PermissionCode` (permissions come from `RolePermissionMapping` and `UserPermissionMapping`, managed in Administration) and, if `MenuRoleMapping` rows exist for it, one of those roles. A Menu or SubMenu with nothing visible below it is removed, so a module appears only when the user can open something in it.

Seeded menu:

- **Workspace**: Dashboard, Alerts, New / Upload Alerts (`ALERT.UPLOAD` or `ATM.CHECK`; `PermissionCode` may list several permissions separated by `,` or `|`, any one is enough)
- **Operations**: Ingestion, Reports, Mail Configuration
- **Masters › ATM**: Staff Mapping (`ATM.OPERATIONS`, opens the Staff Mapping list)
- **Design**: Template Designer (`TEMPLATE.MANAGE`), Workflow Designer (`WORKFLOW.MANAGE`)
- **Admin**: Administration (`SECURITY.MANAGE`), MCP Servers (`MCP.MANAGE`)

The former *Operations › ATM Operations* and *Masters › ATM › Staff Master* entries are retired: penalty files are uploaded and approved from **New / Upload Alerts** (see [ALERT-TYPE-ACCESS.md](ALERT-TYPE-ACCESS.md)) and Staff Mapping is under Masters. Codes listed in `MenuCatalog.RetiredCodes` are set to `IsActive=0` at startup.

The defaults are written once, by `Code`; existing rows are never overwritten, so changes made in the table survive restarts.

## Adding a module

1. Add a Menu row (no `ViewKey`), a SubMenu row under it, and a child row with the `ViewKey` of the new screen and its `PermissionCode`.
2. Add the permission to `PermissionMaster` and map it to roles in `RolePermissionMapping`.
3. Register the screen's `ViewKey` in `navigate()` (`wwwroot/js/modules/core/navigation.js`). Pages opened from another screen (for example the Staff Mapping upload, logs and column-mapping pages) are not menu entries; list them in `parentViews` in `ui/top-navigation.js` so the parent stays highlighted.

Users must sign in again after their permissions change. If the menu cannot be loaded, the application falls back to Dashboard and Alerts only.

## How the menu opens (cascading)
Click a top-level menu (sidebar or top bar) and its sub menus open in a panel beside it; click or hover a sub menu and its children open in the next panel to the right. Entries are never listed below one another. A leaf opens its screen and closes the panels; Esc or a click outside also closes them. The route of the current screen is highlighted through every level.

## Opening a screen with an argument
`ViewKey` may be `view:argument`, for example `reports:ATM_ONUS` opens the Reports screen with the Alert Type preselected. A plain `reports` entry stays active only for the plain screen.

## Reports
Reports is a top-level menu: **All Alert Reports**, and **ATM > OnUs Reports / OffUs Reports**. The ATM entries need any of `ATM.OPERATIONS`, `ATM.UPLOAD`, `ATM.CHECK`, `ATM.CASE.MANAGE` or `ALERT.VIEWALL`. The old `operations.reports` entry is retired automatically.

## Role Permissions (Admin > Role Permissions)
Sets permissions role by role for every user of the role. The screen and `api/admin/role-permissions` need the permission `SECURITY.ROLEPERMISSIONS`, seeded to ADMIN and CENTRAL and changeable like any other permission (also by editing the menu row or the role mapping). Rules:
- Only active permissions of `PermissionMaster` can be granted.
- ADMIN always keeps `SECURITY.MANAGE` and `SECURITY.ROLEPERMISSIONS`, and a caller cannot remove `SECURITY.ROLEPERMISSIONS` from their own role.
- Removed permissions are switched off (`IsActive=0`), not deleted, so the startup seed does not give them back.
- Every change is written to the audit trail. Users receive new permissions at their next sign-in; permissions granted to one user on the Administration page are kept.
