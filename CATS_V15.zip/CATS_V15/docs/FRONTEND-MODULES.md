﻿# Browser modules

`src/CATS.App/wwwroot/js/app.js` is the startup entry point. The layout loads it as an ES module after jQuery and Bootstrap. No runtime bundler or npm dependency is needed.

| Directory | Responsibility |
| --- | --- |
| `modules/api` | Authenticated HTTP transport, catalogs, dependent select options |
| `modules/business` | Template defaults and normalization, field collection, dashboard labels |
| `modules/validation` | Pure field/dependency rules and form validation feedback |
| `modules/ui` | Forms, layouts, themes, account display, modals, grids, PI controls, downloads, feedback |
| `modules/events` | Application and screen event wiring; shared sync/async error handling |
| `modules/features` | Screen loading and rendering; template/workflow editor controllers |
| `modules/core` | Shared state, safe optional storage, permissions, sessions, navigation, value helpers |

Named methods document their purpose, inputs, outputs, and processing. Screen controllers retain their local closures where editor callbacks share draft state. Rendering functions pass explicit context to extracted event binders. Imports are explicit; startup installs handlers only after the module graph is loaded. Screen rendering and event binding have some reciprocal imports; those imports are accessed when functions run, not during module initialization.

Use `api()` for JSON/text and `downloadFile()` for files. Both share token attachment, HTTP 401 session cleanup, server error parsing, network messages, and request-loader accounting. `guardEvent()` preserves jQuery's receiver, arguments, and synchronous `return false`; it reports exceptions and returned promise rejections. Use `observeTask()` when a callback deliberately starts work without awaiting it. Keep existing local form-error displays when they give more useful context.

`validateFieldValue()` and `matchesDependencyRule()` accept a field lookup callback so rules can be tested without a browser. Existing validation precedence and optional-pattern behavior are preserved. Template draft normalization accepts both PascalCase and camelCase persisted records.

The active mail screen replaces the two shadowed declarations; unused legacy ingestion renderers were removed. Downloads, JSON array parsing, template defaults, and handler error reporting use common implementations.

Regression checks use Node's built-in VM module support and small browser/service mocks. Run the four JavaScript checks listed in [SERVICE-ARCHITECTURE.md](SERVICE-ARCHITECTURE.md). They cover module loading, request and download behavior, loader balancing, malformed session storage, validation, template normalization, per-user appearance, PI rendering, and modal sequencing. These checks do not replace a real-browser, database-backed workflow test.

The UI host sends JavaScript with `max-age=0,must-revalidate`, so stable ES module import paths revalidate after deployments.
