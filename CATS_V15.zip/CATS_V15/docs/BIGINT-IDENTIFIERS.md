# BIGINT identifiers (V19)

Every table key and every reference to it is a 64-bit integer. GUID text ids (`varchar(32)`) are gone from the schema and the API.

## What changed

| Area | Before | Now |
|---|---|---|
| Table keys (`Alerts.Id`, `Templates.Id`, `CatsUsers.Id`, `WorkItems.Id`, ...) | `varchar(32)` GUID | `bigint` |
| References (`AlertId`, `TemplateId`, `UserId`, `AssignedUserId`, ...) | `varchar(32)` | `bigint` |
| New ids | `Guid.NewGuid()` in the application | `CatsId.Next()` (see below) |
| API JSON / routes | `"id":"3f2c..."` | `"id":1406`, routes use `{id:long}` |
| Browser | text ids | the UI turns integer `id` / `...Id` properties into text when it parses a response, so DOM comparisons keep working; the API accepts ids as numbers or text |

Not changed on purpose: workflow stage ids, template section/field ids, trigger ids and `ParallelGroupId` (JSON/config identifiers, not table keys), and the polymorphic `AuditLog.EntityId` (text, now holding the numeric id as text).

## How new ids are generated

One database sequence per database: `dbo.seq_CatsId` (SQL Server), `seq_cats_id` (PostgreSQL), `SEQ_CATS_ID` (Oracle). It advances by 100. Each CATS process reserves a block of 100 ids with one query (`CATS.Core/CatsId.cs`) and hands them out from memory, so the API, the workers and the database itself never collide. Every key column also has `DEFAULT NEXT VALUE FOR seq` so ad-hoc inserts get an id too. Ids stay far below 2^53, so the browser never loses precision.

## Existing data: keeping the old GUIDs

Run (or let CATS run, SQL Server only) the upgrade script:

| Database | Script |
|---|---|
| SQL Server | `db/sqlserver/CATS_V19_BigIntIds_Upgrade.sql` — tested on SQL Server 2025 against a copy of a real CATS database |
| PostgreSQL | `db/postgresql/CATS_V19_BigIntIds_Upgrade.sql` — **not yet tested** |
| Oracle | `db/oracle/CATS_V19_BigIntIds_Upgrade.sql` — **not yet tested** (Oracle cannot roll DDL back; back up first) |

For every table that had a GUID key the script:

1. adds a numeric `Id` (assigned in creation order) and keeps the old GUID in a new **`LegacyGuid`** column (unique index `UX_<Table>_LegacyGuid`), so old links, bookmarks, log lines and audit text can still be mapped: `SELECT Id FROM dbo.Alerts WHERE LegacyGuid = '3f2c...'`;
2. converts every referencing column by joining on `LegacyGuid`, then drops the old text columns;
3. drops and recreates the primary keys, unique constraints, indexes and foreign keys that touch them;
4. rewrites user ids stored inside JSON: `_assignments.<stage>.userId` in `AlertModuleRecords.DataJson` and `targetUserId` in `Templates.AssignmentRulesJson`;
5. continues the sequence after the migrated ids.

Rows whose parent no longer exists are handled explicitly: nullable references become `NULL`, failed-login audit rows get user id `0`, a template-specific mail template whose template is gone is removed, other parentless rows are removed — each removal is reported as a `WARNING`. The script is re-runnable and (SQL Server, PostgreSQL) runs in one transaction.

SQL Server: `DatabaseBootstrapper` detects a database that still has GUID keys and runs the script automatically on start-up (`DatabaseStartup:AutoInitialize`). With automatic initialization disabled, run the script once, then `db/sqlserver/schema.sql`. **Back up the database before the first start** and stop all CATS processes; browser sessions issued before the upgrade are rejected and users sign in again.

Older upgrade scripts (V4/V6 consolidated, V3, ...) are historical and still describe the GUID layout; run them only on databases that have not reached V19.

## Seed data

Seeded rows no longer use fixed text ids. They are matched by their natural keys (`Code`, role/scope, event code, name) and receive a sequence id.
