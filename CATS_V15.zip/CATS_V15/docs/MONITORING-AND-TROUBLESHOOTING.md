# Monitoring & Troubleshooting

**Admin → Monitoring & Troubleshooting** is for Center and Admin users (permission `DIAGNOSTICS.VIEW`, granted to the
`ADMIN` and `CENTRAL` roles; change it under *Role Permissions*). Users must sign out and in again after the permission is granted.

## How a problem is traced

1. Every API response carries a **Reference ID** (`X-Request-Id`). When a request fails, the error message shown to the user ends with
   `(Reference ID: …)`.
2. Failed requests (HTTP 4xx/5xx) and slow requests (over 3 seconds) are written to `DiagnosticEvents` in the background, so
   monitoring never slows the request. Successful, fast requests are not stored. Records are kept for 90 days.
3. The user quotes the Reference ID; Center/Admin pastes it into **Find a Reference ID** and sees, in plain words, *what happened*,
   *the most likely cause*, *what to do* and *who should act*.

## Screen

| Tab | Purpose |
|---|---|
| Overview | Counts of system errors / user-rule issues / slow responses, trend, system health (database, mail, ingestion, ATM approval queue), most repeated problems with the recommended action, per-module table, release and environment. |
| Search problems | Filter by Reference ID, user, module, type, HTTP status and time; **Explain** opens the plain-language detail with *Copy summary* for support tickets. |
| Data audit | Who did what and when (from `AuditLog`); customer data values are not returned. Filter by user, action, record type, alert id, time. |
| How to read this | The steps above and the meaning of each problem type. |

Technical detail (exception type and stack trace) is shown only to the `ADMIN` role. Live request counts and p95 speed per module are
kept in memory and reset when the API restarts.

## Components

- `src/CATS.Api/Diagnostics.cs` – collector (`DiagnosticsService`), plain-language rules (`DiagnosticsAdvisor`), `RequestDiagnosticsMiddleware`.
- `src/CATS.Api/Controllers/DiagnosticsController.cs` – `/api/diagnostics/{summary,events,events/{requestId},audit,filters}`.
- `DiagnosticEvents` table in `db/*/schema.sql` (created automatically when the API starts).
- `src/CATS.App/wwwroot/js/modules/features/diagnostics.js` – the screen.
