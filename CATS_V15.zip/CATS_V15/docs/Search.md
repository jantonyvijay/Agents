Global Search – Feature Points
No.	Feature	Description
1	Global Search Bar	Search across the entire application from a single search box.
2	Recently Viewed	Display the last 10–20 recently accessed tickets or records.
3	Instant Search Suggestions	Display matching results as the user types.
4	Search by Alert ID	Search using IDs  
5	Search by Title	Search using ticket titles, keywords or descriptions.
6	Module-Wise Search	Search across different modules, such as CATS, CGAS, RBB and ATM.
7	Last Updated Filter	Today, Yesterday, Past 7 Days, Past 30 Days, Past Year and Anytime.
8	Project Filter	Filter results by individual projects or applications.
9	Multiple Project Selection	Select one or more projects simultaneously.
10	Search Categories	Separate tabs for tickets, projects, documents and other records.
11	View All Results	Open a dedicated search-results page with complete details.
12	Direct Navigation	Clicking a search result opens the respective ticket or record.
13	Advanced Filters	Filter by status, assignee, priority, creator and date range.
14	Role-Based Search	Display only records the logged-in user has permission to access.
15	Keyboard Navigation	Use arrow keys to select results and Enter to open them.