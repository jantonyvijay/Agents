﻿const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');

async function main() {
    const values = new Map();
    const storage = {
        getItem: (key) => values.get(key) ?? null,
        setItem: (key, value) => values.set(key, value),
        removeItem: (key) => values.delete(key),
    };
    const calls = [];
    let pending = 0,
        unauthorized = 0;
    const base = {
        document: { querySelector: () => ({ content: 'https://gateway.example/' }) },
        sessionStorage: storage,
    };
    let response = { ok: true, status: 200, text: async () => '{"ok":true}' };
    const client = await loadModules(
        'modules/api/client.js',
        {
            ...base,
            fetch: async (url, options) => {
                calls.push({ url, options });
                if (response instanceof Error) throw response;
                return response;
            },
        },
        {
            'modules/ui/feedback.js': { beginRequestLoading: () => pending++, endRequestLoading: () => pending-- },
        },
    );
    const state = [...client.cache].find(([key]) => key.endsWith('core' + require('node:path').sep + 'state.js'))[1]
        .namespace.state;
    state.token = 'test-token';
    client.exports.setUnauthorizedHandler(() => unauthorized++);
    assert.equal((await client.exports.api('/api/example', { method: 'POST', body: { value: 3 } })).ok, true);
    assert.equal(calls[0].url, 'https://gateway.example/api/example');
    assert.equal(calls[0].options.headers.get('Authorization'), 'Bearer test-token');
    assert.equal(calls[0].options.headers.get('Content-Type'), 'application/json');
    assert.equal(calls[0].options.body, '{"value":3}');
    const form = new FormData();
    form.set('name', 'file');
    await client.exports.api('/upload', { method: 'POST', body: form });
    assert.equal(calls.at(-1).options.body, form);
    assert.equal(calls.at(-1).options.headers.has('Content-Type'), false);
    response = { ok: true, status: 204, text: async () => '' };
    assert.equal(await client.exports.api('/empty'), null);
    response = { ok: true, status: 200, text: async () => 'plain text' };
    assert.equal(await client.exports.api('/text'), 'plain text');
    response = { ok: false, status: 400, text: async () => '{"errors":{"name":["Name is required."]}}' };
    await assert.rejects(client.exports.api('/bad'), /Name is required/);
    response = { ok: false, status: 500, text: async () => '<html>internal failure</html>' };
    await assert.rejects(client.exports.api('/bad'), /Request failed \(500\)/);
    response = {
        ok: false,
        status: 401,
        text: async () => {
            throw Error('must not read body');
        },
    };
    await assert.rejects(client.exports.api('/expired'), /session has expired/);
    assert.equal(unauthorized, 1);
    response = new TypeError('Failed to fetch');
    await assert.rejects(client.exports.api('/offline'), /Unable to reach the server/);
    response = {
        ok: true,
        status: 200,
        text: async () => {
            throw Error('read failure');
        },
    };
    await assert.rejects(client.exports.api('/read'), /read failure/);
    const blob = new Blob(['csv']);
    response = {
        ok: true,
        status: 200,
        blob: async () => blob,
        headers: new Headers({ 'content-disposition': 'attachment; filename="file.csv"' }),
    };
    assert.equal((await client.exports.apiDownload('/file')).blob, blob);
    assert.equal(pending, 0);
    let finish;
    response = {
        ok: true,
        status: 200,
        text: () =>
            new Promise((resolve) => {
                finish = resolve;
            }),
    };
    const request = client.exports.api('/slow');
    await new Promise((resolve) => setImmediate(resolve));
    assert.equal(pending, 1);
    finish('{}');
    await request;
    assert.equal(pending, 0);

    const rules = (await loadModules('modules/validation/field-rules.js')).exports;
    const getValue = (name) => ({ kind: 'HIGH', confirm: 'yes' })[name] || '';
    assert.equal(rules.validateFieldValue({ label: 'Name', required: true }, '', getValue), 'Name is required.');
    assert.equal(
        rules.validateFieldValue({ label: 'Code', required: false, validationPattern: '^X$' }, 'Y', getValue),
        '',
    );
    assert.match(
        rules.validateFieldValue({ label: 'Code', required: true, validationPattern: '[' }, 'Y', getValue),
        /invalid validation pattern/,
    );
    assert.match(
        rules.validateFieldValue({ label: 'Amount', type: 'amount', minValue: 5 }, '4', getValue),
        /at least 5/,
    );
    assert.match(rules.validateFieldValue({ label: 'Name', minLength: 2 }, '', getValue), /at least 2 characters/);
    assert.equal(
        rules.matchesDependencyRule({ Conditions: [{ Field: 'kind', Operator: 'eq', Value: 'high' }] }, getValue),
        true,
    );
    assert.equal(rules.matchesDependencyRule({ conditions: [] }, getValue), false);
    assert.match(
        rules.validateFieldValue(
            {
                label: 'Reason',
                dependencyValidationsJson: JSON.stringify([
                    { conditions: [{ field: 'kind', value: 'high' }], required: true },
                ]),
            },
            '',
            getValue,
        ),
        /Reason is required/,
    );

    const drafts = (await loadModules('modules/business/template-drafts.js')).exports;
    const draft = drafts.fresh();
    assert.equal(draft.viewConfiguration.layoutMode, 'Single');
    assert.equal(draft.viewConfiguration.baseDataModes.length, 4);
    assert.equal(drafts.normalizeField({ Name: 'amount', Type: 'DropdownList', Required: true }, 0).type, 'select');
    assert.equal(drafts.normalizeSection({ ColumnSpan: 20, PageNumber: 0 }, 0).columnSpan, 12);
    assert.equal(drafts.normalizeSection({ ColumnSpan: 20, PageNumber: 0 }, 0).pageNumber, 1);
    assert.equal(drafts.fromRecord({ fieldsJson: 'invalid', sectionsJson: '[]' }).fields.length, 0);
    draft.sections.push({ name: 'test' });
    assert.equal(drafts.fresh().sections.length, 0);

    const errors = [];
    const guard = (
        await loadModules(
            'modules/events/guard.js',
            {},
            { 'modules/ui/feedback.js': { toast: (message) => errors.push(message) } },
        )
    ).exports.guardEvent;
    const receiver = { value: 3 };
    assert.equal(
        guard(function (x) {
            assert.equal(this, receiver);
            assert.equal(x, 5);
            return false;
        }).call(receiver, 5),
        false,
    );
    guard(() => {
        throw Error('sync failure');
    })();
    await guard(async () => {
        throw Error('async failure');
    })();
    assert.deepEqual(errors, ['sync failure', 'async failure']);
    values.set('cats_user', 'corrupt JSON');
    const restored = (await loadModules('modules/core/state.js', { sessionStorage: storage })).exports.state;
    assert.equal(restored.user, null);
    const blocked = (
        await loadModules('modules/core/state.js', {
            sessionStorage: {
                getItem() {
                    throw Error('denied');
                },
            },
        })
    ).exports.state;
    assert.equal(blocked.token, '');
    assert.equal(blocked.user, null);
    console.log(
        'PASS: API transport, JSON/FormData, downloads, errors, loader balance, validation rules, draft normalization, event failures, and session recovery.',
    );
}
main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
