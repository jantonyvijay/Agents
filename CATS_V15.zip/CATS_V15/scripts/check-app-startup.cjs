﻿const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');

async function main() {
    const bindings = [],
        nodes = new Map();
    function $(key) {
        if (nodes.has(key)) return nodes.get(key);
        let text = '',
            html = '',
            value = '';
        const chain = new Proxy(
            { length: 0 },
            {
                get(target, name) {
                    if (name in target) return target[name];
                    if (name === 'then') return undefined;
                    if (name === 'on')
                        return (...args) => {
                            bindings.push([key, ...args]);
                            return chain;
                        };
                    if (name === 'text') return (...args) => (args.length ? ((text = String(args[0])), chain) : text);
                    if (name === 'html')
                        return (...args) => (args.length ? ((html = String(args[0])), chain) : html || text);
                    if (name === 'val') return (...args) => (args.length ? ((value = args[0]), chain) : value);
                    if (name === 'attr' || name === 'data') return (...args) => (args.length > 1 ? chain : undefined);
                    if (name === 'is' || name === 'hasClass') return () => false;
                    if (name === 'get' || name === 'toArray') return () => [];
                    return () => chain;
                },
            },
        );
        nodes.set(key, chain);
        return chain;
    }
    const storage = { getItem: () => null, setItem() {}, removeItem() {} };
    const globals = {
        $,
        sessionStorage: storage,
        localStorage: storage,
        window: { innerWidth: 1200, addEventListener() {}, matchMedia: () => ({ matches: false, addEventListener() {} }) },
        document: {
            addEventListener() {},
            body: {},
            querySelector: () => null,
            getElementById: () => ({ innerHTML: '<span>Loading</span>' }),
            documentElement: { setAttribute() {}, style: { setProperty() {}, removeProperty() {} }, dataset: {} },
        },
        setTimeout: () => 1,
        clearTimeout() {},
        setInterval: () => 1,
        clearInterval() {},
        MutationObserver: class {
            observe() {}
        },
        Node: { ELEMENT_NODE: 1 },
        bootstrap: {},
        CSS: { escape: (value) => value },
        fetch: () => {
            throw Error('Signed-out startup must not request protected data');
        },
    };
    const result = await loadModules('app.js', globals);
    assert.ok(result.cache.size >= 40, 'Startup did not load the module graph');
    for (const selector of ['#loginForm', '#logoutBtn', '#piUnmaskForm', '#catsAssistantForm']) {
        assert.ok(
            bindings.some(([key]) => key === selector),
            selector + ' was not wired',
        );
    }
    const appModules = [...result.cache.values()];
    assert.ok(appModules.every((module) => module.status === 'evaluated'));
    console.log(
        'PASS: complete browser module graph loads and signed-out startup binds login, logout, PI, and assistant actions.',
    );
}
main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
