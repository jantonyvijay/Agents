﻿const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');

async function main() {
    for (const selector of ['#sectionModal', '#fieldModal']) {
        const events = [];
        const fallback = { focus: () => events.push('fallback-focus') };
        function element(name, shown = false) {
            return {
                name,
                listeners: {},
                classList: { contains: () => shown },
                addEventListener(type, fn) {
                    this.listeners[type] = fn;
                },
                emit(type) {
                    const fn = this.listeners[type];
                    delete this.listeners[type];
                    fn?.();
                },
                querySelector() {
                    return fallback;
                },
            };
        }
        const parent = element('parent', true),
            child = element('child');
        const opener = { isConnected: true, focus: () => events.push('opener-focus') };
        const { exports: modals } = await loadModules(
            'modules/ui/modals.js',
            {
                document: { getElementById: () => parent, querySelector: () => child, activeElement: opener },
                bootstrap: {
                    Modal: {
                        getOrCreateInstance: (el) => ({
                            show: () => events.push(el.name + '-show'),
                            hide: () => events.push(el.name + '-hide'),
                        }),
                    },
                },
            },
            { 'modules/events/guard.js': { guardEvent: (handler) => handler } },
        );
        modals.showTemplateChildModal(selector);
        assert.deepEqual(events, ['parent-hide']);
        parent.emit('hidden.bs.modal');
        assert.deepEqual(events, ['parent-hide', 'child-show']);
        child.emit('hidden.bs.modal');
        assert.equal(events.at(-1), 'parent-show');
        parent.emit('shown.bs.modal');
        assert.equal(events.at(-1), 'opener-focus');
        assert.equal(Object.keys(child.listeners).length, 0);
        events.length = 0;
        modals.showTemplateChildModal(selector);
        parent.emit('hidden.bs.modal');
        opener.isConnected = false;
        child.emit('hidden.bs.modal');
        parent.emit('shown.bs.modal');
        assert.equal(events.at(-1), 'fallback-focus');
    }
    console.log('PASS: section/field modal transitions, parent restoration, focus fallback, and one-time handlers.');
}
main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
