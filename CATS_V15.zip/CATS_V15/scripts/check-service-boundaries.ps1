﻿param([int]$GatewayPort = 17000, [int]$UiPort = 17001, [int]$ApiPort = 17002)
$ErrorActionPreference = 'Stop'
$workspacePath = Split-Path -Parent $PSScriptRoot
$logDirectory = Join-Path ([System.IO.Path]::GetTempPath()) ('cats-boundary-check-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $logDirectory | Out-Null
$started = @()

function Start-TestHost([string]$projectName, [int]$port, [string[]]$extraArguments = @()) {
    $projectDirectory = Join-Path $workspacePath ('src\' + $projectName)
    $assembly = Join-Path $projectDirectory ('bin\Release\net9.0\' + $projectName + '.dll')
    if (-not (Test-Path -LiteralPath $assembly)) { throw "Build the Release solution first: $projectName is missing." }
    return Start-Process dotnet -ArgumentList (@(('"' + $assembly + '"'), '--urls', ('http://127.0.0.1:' + $port), '--environment', 'Development', '--Logging:EventLog:LogLevel:Default=None') + $extraArguments) -WorkingDirectory $projectDirectory -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $logDirectory ($projectName + '.out.log')) -RedirectStandardError (Join-Path $logDirectory ($projectName + '.err.log'))
}

function Get-Response([string]$url) {
    try { return Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 5 }
    catch { if ($null -ne $_.Exception.Response) { return $_.Exception.Response }; throw }
}

function Assert-Status([string]$url, [int]$expected) {
    $response = Get-Response $url
    if ([int]$response.StatusCode -ne $expected) { throw "Expected HTTP $expected for $url; received $($response.StatusCode)." }
    return $response
}

try {
    $started += Start-TestHost 'CATS.Api' $ApiPort @('--DatabaseStartup:AutoInitialize=false')
    $started += Start-TestHost 'CATS.App' $UiPort
    $started += Start-TestHost 'CATS.Gateway' $GatewayPort @(
        ('--ReverseProxy:Clusters:cats-api:Destinations:primary:Address=http://127.0.0.1:' + $ApiPort + '/'),
        ('--ReverseProxy:Clusters:cats-app:Destinations:primary:Address=http://127.0.0.1:' + $UiPort + '/')
    )
    foreach ($port in @($ApiPort, $UiPort, $GatewayPort)) {
        $ready = $false
        for ($attempt = 0; $attempt -lt 40; $attempt++) {
            if (@($started | Where-Object { $_.HasExited }).Count -gt 0) { throw "A test host exited. Logs: $logDirectory" }
            try { $response = Get-Response ('http://127.0.0.1:' + $port + '/health/live'); if ([int]$response.StatusCode -eq 200) { $ready = $true; break } } catch { }
            Start-Sleep -Milliseconds 250
        }
        if (-not $ready) { throw "Host on port $port did not become ready. Logs: $logDirectory" }
    }
    $uiResponse = Assert-Status "http://127.0.0.1:$GatewayPort/" 200
    if ($uiResponse.Content -notmatch 'type="module" src="/js/app.js') { throw 'The UI did not load the modular JavaScript entry point.' }
    $null = Assert-Status "http://127.0.0.1:$ApiPort/" 404
    $null = Assert-Status "http://127.0.0.1:$UiPort/api/meta/roles" 404
    $null = Assert-Status "http://127.0.0.1:$ApiPort/api/meta/roles" 403
    $null = Assert-Status "http://127.0.0.1:$GatewayPort/api/meta/roles" 401
    $health = Assert-Status "http://127.0.0.1:$GatewayPort/api/health/live" 200
    if (($health.Content | ConvertFrom-Json).service -ne 'CATS.Api') { throw 'Gateway API route did not reach CATS.Api.' }
    $module = Assert-Status "http://127.0.0.1:$GatewayPort/js/modules/api/client.js" 200
    if ($module.Headers['Cache-Control'] -notmatch 'must-revalidate') { throw 'JavaScript modules must revalidate after deployments.' }
    Write-Host 'PASS: separate UI/API hosts, gateway routing, module serving, gateway-key enforcement, and JWT protection.' -ForegroundColor Green
}
finally {
    $started | Where-Object { -not $_.HasExited } | Stop-Process -Force -ErrorAction SilentlyContinue
    Write-Host "Test logs: $logDirectory"
}
