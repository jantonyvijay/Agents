const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');

(async () => {
    const controls = new Map();
    const control = (key) => {
        if (!controls.has(key)) controls.set(key, { innerHTML: '', querySelector: control });
        return controls.get(key);
    };
    let hidden, removed = false, disposed = false, focused = false;
    const element = { setAttribute() {}, querySelector: control,
        addEventListener: (_, fn) => { hidden = fn; }, remove: () => { removed = true; } };
    const requests = [];
    const { exports: audit } = await loadModules('modules/ui/template-audit.js', {
        $: () => ({ text(value) { return { html: () => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;') }; } }),
        document: { getElementById: () => null, createElement: () => element,
            activeElement: { isConnected: true, focus: () => { focused = true; } }, body: { appendChild() {} } },
        bootstrap: { Modal: { getOrCreateInstance: () => ({ show() {}, dispose: () => { disposed = true; } }) } },
    }, {
        'modules/api/client.js': { api: async (url) => {
            requests.push(url);
            return { hasMore: requests.length === 1, items: [{ action: 'TEMPLATE_UPDATE', userName: '<script>',
                roleCode: 'CENTRAL', createdAtUtc: '2026-10-26T00:00:00Z', remarks: '', entityType: 'Template' }] };
        } },
    });
    audit.showTemplateAudit({ id: 'template/1', name: '<Test>', code: 'TEST' });
    const detailHtml = audit.auditDetailsHtml({ available: true, hasPrevious: true, totalChanges: 1,
        changes: [{ property: 'fields.amount.required', before: '<old>', after: 'true' }] });
    assert.ok(detailHtml.includes('Before') && detailHtml.includes('After') && detailHtml.includes('&lt;old&gt;'));
    assert.ok(audit.auditDetailsHtml(undefined).includes('API did not return'));
    assert.ok(audit.auditDetailsHtml({ available: false }).includes('snapshot could not be read'));
    assert.ok(audit.auditDetailsHtml({ available: true, hasPrevious: false, totalChanges: 1,
        changes: [{ property: 'name', before: null, after: 'New' }] }).includes('No previous snapshot'));
    await new Promise(setImmediate);
    assert.equal(requests[0], '/api/templates/template%2F1/audit?page=1');
    assert.ok(element.innerHTML.includes('&lt;Test&gt;'));
    assert.ok(control('[data-audit-content]').innerHTML.includes('&lt;script&gt;'));
    assert.equal(control('[data-audit-prev]').disabled, true);
    assert.equal(control('[data-audit-next]').disabled, false);
    await control('[data-audit-next]').onclick();
    assert.ok(requests[1].endsWith('page=2'));
    assert.equal(control('[data-audit-next]').disabled, true);
    hidden();
    assert.ok(removed && disposed && focused);
    console.log('PASS: template-scoped audit request, escaped content, pagination, modal cleanup and focus restoration.');
})().catch((error) => { console.error(error); process.exitCode = 1; });
