param([switch]$Install)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$config=Get-Content (Join-Path $root 'src/CATS.Api/appsettings.json') -Raw | ConvertFrom-Json
$connection=New-Object System.Data.SqlClient.SqlConnection($config.Database.ConnectionString)
$connection.Open()
$transaction=$connection.BeginTransaction()
try {
    $command=$connection.CreateCommand()
    $command.Transaction=$transaction
    if($Install) {
        $sql=[IO.File]::ReadAllText((Join-Path $root 'db/sqlserver/CATS_V14_AlertRecordViews_Upgrade.sql'))
        foreach($batch in [regex]::Split($sql,'(?m)^GO\s*$')) {
            if([string]::IsNullOrWhiteSpace($batch)){continue}
            $command.CommandText=$batch
            [void]$command.ExecuteNonQuery()
        }
    }
    $transaction.Save('fixtures')
    $alertId=[guid]::NewGuid().ToString('N')
    $command.CommandText=@'
DECLARE @template varchar(32),@workflow varchar(32);
SELECT TOP 1 @template=TemplateId,@workflow=Id FROM WorkflowDefinitions ORDER BY CreatedAtUtc;
IF @template IS NULL THROW 50000,'A workflow is required for the test.',1;
INSERT Alerts(Id,AlertNo,TemplateId,TemplateVersion,AlertType,BranchCode,CustomerIdEncrypted,AccountIdEncrypted,DynamicDataJson,Status,CurrentStageId,CurrentStageName,CreatedAtUtc,StageEnteredAtUtc,CreatedBy,Priority)
VALUES(@id,@id,@template,1,'TEST_RECORD_VIEWS','test-record','','','{}','Pending','atmc','ATMC Review',SYSUTCDATETIME(),SYSUTCDATETIME(),'test','Normal');
INSERT WorkflowInstances(Id,AlertId,WorkflowDefinitionId,WorkflowVersion,Status,CurrentStageId,StartedAtUtc,UpdatedAtUtc)
VALUES(@id,@id,@workflow,1,'Running','atmc',SYSUTCDATETIME(),SYSUTCDATETIME());
INSERT WorkItems(Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,Status,CreatedAtUtc,DueAtUtc)
VALUES(@id,@id,@id,'atmc','ATMC Review','TEST_ATMC','','Pending',SYSUTCDATETIME(),SYSUTCDATETIME());
'@
    [void]$command.Parameters.AddWithValue('@id',$alertId)
    [void]$command.ExecuteNonQuery()
    function Check-View($role,$userId,$userName,$view,$expected) {
        $payload=@{roleCode=$role;userId=$userId;userName=$userName;userBranchCode='test-user';recordView=$view;search=$alertId;page=1;pageSize=20;canViewAll=$false}|ConvertTo-Json -Compress
        $check=$connection.CreateCommand();$check.Transaction=$transaction
        $check.CommandText='EXEC dbo.USP_Alert_GetCount @strJson=@payload'
        [void]$check.Parameters.AddWithValue('@payload',$payload)
        $count=[int]$check.ExecuteScalar()
        if($count -ne $expected){throw "$role/$view count: expected $expected, got $count"}
        $check.CommandText='EXEC dbo.USP_Alert_GetPaged @strJson=@payload'
        $reader=$check.ExecuteReader();$rows=0
        while($reader.Read()){$rows++}
        $reader.Close();$check.Dispose()
        if($rows -ne $expected){throw "$role/$view page: expected $expected, got $rows"}
        Write-Output "PASS: $role / $userName / $view = $expected"
    }
    Check-View 'TEST_ATMC' 'actor1' 'actor1' 'MyActionable' 1
    Check-View 'TEST_RATC' 'actor2' 'actor2' 'MyActionable' 0
    $command.CommandText=@'
UPDATE WorkItems SET Status='Completed',CompletedBy='actor1',CompletedAction='Submit',CompletedAtUtc=SYSUTCDATETIME() WHERE Id=@id;
UPDATE Alerts SET CurrentStageId='ratc',CurrentStageName='RATC Review' WHERE Id=@id;
UPDATE WorkflowInstances SET CurrentStageId='ratc' WHERE Id=@id;
INSERT WorkItems(Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,AssignedUserId,Status,CreatedAtUtc,DueAtUtc)
VALUES(REPLACE(CONVERT(varchar(36),NEWID()),'-',''),@id,@id,'ratc','RATC Review','TEST_RATC','','actor2','Pending',SYSUTCDATETIME(),SYSUTCDATETIME());
'@
    [void]$command.ExecuteNonQuery()
    Check-View 'TEST_ATMC' 'actor1' 'actor1' 'MyActionable' 0
    Check-View 'TEST_ATMC' 'actor1' 'actor1' 'ActionedByMe' 1
    Check-View 'TEST_ATMC' 'actor3' 'actor3' 'ActionedByMe' 0
    Check-View 'TEST_ATMC' 'actor1' 'actor1' 'All' 1
    Check-View 'TEST_RATC' 'actor2' 'actor2' 'MyActionable' 1
    Check-View 'TEST_RATC' 'actor3' 'actor3' 'MyActionable' 0
    Check-View 'UNRELATED' 'actor4' 'actor4' 'All' 0
    $command.CommandText="UPDATE Alerts SET Status='Closed' WHERE Id=@id; UPDATE WorkItems SET Status='Completed',CompletedBy='actor2' WHERE AlertId=@id AND Status='Pending';"
    [void]$command.ExecuteNonQuery()
    Check-View 'TEST_RATC' 'actor2' 'actor2' 'MyActionable' 0
    Check-View 'TEST_ATMC' 'actor1' 'actor1' 'Closed' 1
    Check-View 'TEST_ATMC' 'actor1' 'actor1' 'ActionedByMe' 1
    Check-View 'UNRELATED' 'actor4' 'actor4' 'Closed' 0
    $transaction.Rollback('fixtures')
    $transaction.Commit()
    Write-Output 'PASS: all temporary records rolled back; counts and paged rows agree.'
} catch { $transaction.Rollback(); throw } finally { $connection.Dispose() }
