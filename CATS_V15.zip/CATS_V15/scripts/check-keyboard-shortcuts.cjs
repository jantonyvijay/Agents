const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');
(async () => {
    const listeners = {}, windowListeners = {};
    let elements = [], modal = null, overlays = [], clicked = [], focused = [];
    function element(name, kind = 'button', disabled = false) {
        return { textContent: name, isConnected: true, style: {}, children: [],
            getAttribute: () => null, setAttribute() {}, closest: () => null,
            matches: (selector) => selector === ':disabled' ? disabled : kind === 'input',
            getBoundingClientRect: () => ({ left: 20, top: 30, right: 120, bottom: 60, width: 100, height: 30 }),
            focus: () => focused.push(name), click: () => clicked.push(name),
            appendChild(child) { this.children.push(child); }, contains(child) { return this.children.includes(child); },
            remove() { overlays = overlays.filter((item) => item !== this); },
        };
    }
    const document = {
        addEventListener: (type, fn) => { listeners[type] = fn; },
        querySelectorAll: (selector) => selector.startsWith('.modal') ? (modal ? [modal] : []) : elements,
        contains: (item) => elements.includes(item), createElement: () => element(''),
        body: { appendChild: (item) => overlays.push(item) },
    };
    const { exports: shortcuts } = await loadModules('modules/ui/keyboard-shortcuts.js', {
        document, window: { innerWidth: 1000, innerHeight: 800,
            getComputedStyle: () => ({ visibility: 'visible', display: 'block' }),
            addEventListener: (type, fn) => { windowListeners[type] = fn; } },
        MutationObserver: class { observe() {} disconnect() {} },
    });
    const tips = shortcuts.assignKeyTips(Array.from({ length: 150 }, (_, i) => element(i < 2 ? 'Save' : 'Other')));
    assert.equal(new Set(tips.map((tip) => tip.key)).size, 150);
    assert.equal(tips[0].key, 'S');
    assert.ok(tips.every((tip, i) => tips.every((other, j) => i === j || !other.key.startsWith(tip.key))));
    shortcuts.enableKeyboardShortcuts();
    const event = (key, extra = {}) => ({ key, preventDefault() {}, stopImmediatePropagation() {}, ...extra });
    const press = (key, extra) => listeners.keydown(event(key, extra));
    const alt = () => { press('Alt'); listeners.keyup(event('Alt')); };
    elements = [element('Save'), element('Preview'), element('Search', 'input'), element('Disabled', 'button', true)];
    alt();
    assert.equal(overlays[0].children.length, 4); // Help plus three enabled controls.
    press('S'); assert.deepEqual(clicked, ['Save']); assert.equal(overlays.length, 0);
    alt(); press('F'); assert.deepEqual(focused, ['Save', 'Search']); assert.deepEqual(clicked, ['Save']);
    alt(); press('Escape'); assert.equal(overlays.length, 0);
    press('Alt'); press('F4', { altKey: true }); listeners.keyup(event('Alt')); assert.equal(overlays.length, 0);
    const close = element('Close');
    modal = { ...element('dialog'), querySelectorAll: () => [close], contains: (item) => item === close };
    alt(); assert.equal(overlays[0].children.length, 2);
    press('C'); assert.deepEqual(clicked, ['Save', 'Close']);
    modal = null; alt(); windowListeners.blur(); assert.equal(overlays.length, 0);
    console.log('PASS: unique prefix-free tips, Alt toggle, actions, input focus, disabled controls, modal scope, Escape and native Alt combinations.');
})().catch((error) => { console.error(error); process.exitCode = 1; });
