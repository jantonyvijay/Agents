﻿const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');

async function main() {
    const storage = new Map(),
        attrs = {},
        state = { user: { id: 'alice' }, detail: { alert: { id: 'alert-1' } } };
    const elements = new Map();
    function $(key) {
        if (!elements.has(key))
            elements.set(key, {
                text() {
                    return this;
                },
                each() {
                    return this;
                },
                val(v) {
                    this.value = v;
                    return this;
                },
                toggleClass(name, active) {
                    this[name] = active ?? !this[name];
                    return this;
                },
                hasClass(name) {
                    return !!this[name];
                },
                attr(values) {
                    this.attributes = { ...this.attributes, ...values };
                    return this;
                },
            });
        return elements.get(key);
    }
    const globals = {
        $,
        window: { innerWidth: 1200, matchMedia: () => ({ matches: true }) },
        document: {
            querySelector: () => null,
            documentElement: {
                setAttribute: (k, v) => (attrs[k] = v),
                style: { setProperty: (k, v) => (attrs[k] = v) },
                dataset: {},
            },
        },
        localStorage: { getItem: (k) => storage.get(k) ?? null, setItem: (k, v) => storage.set(k, v) },
    };
    const { exports: appearance } = await loadModules('modules/ui/appearance.js', globals, {
        'modules/core/state.js': { state },
    });
    for (const theme of ['light', 'dark', 'system', 'ocean', 'forest', 'violet', 'white', 'blue', 'custom']) {
        appearance.applyTheme(theme);
        assert.equal(attrs['data-cats-theme'], theme);
        assert.equal(attrs['data-bs-theme'], ['dark', 'system'].includes(theme) ? 'dark' : 'light');
    }
    storage.set('cats_theme_color_alice', '#287A57');
    appearance.applyTheme('custom');
    assert.equal(attrs['--cats-accent'], '#287A57');
    assert.equal(attrs['--cats-topbar-bg'], '#287A57');
    appearance.applyTheme('forest');
    appearance.applyLayout('compact');
    state.user = { id: 'bob' };
    appearance.restoreAppearance();
    assert.equal(attrs['data-cats-theme'], 'system');
    assert.equal(globals.document.documentElement.dataset.catsLayout, 'standard');
    appearance.applyTheme('ocean');
    appearance.applyLayout('wide');
    assert.equal(elements.get('body')['sidebar-collapsed'], true);
    state.user = { id: 'alice' };
    appearance.restoreAppearance();
    assert.equal(attrs['data-cats-theme'], 'forest');
    assert.equal(globals.document.documentElement.dataset.catsLayout, 'compact');
    appearance.applyTheme('invalid');
    appearance.applyLayout('invalid');
    assert.equal(attrs['data-cats-theme'], 'system');
    assert.equal(globals.document.documentElement.dataset.catsLayout, 'standard');

    appearance.applyLayout('top-menu');
    appearance.toggleSidebar();
    appearance.restoreAppearance();
    assert.equal(globals.document.documentElement.dataset.catsLayout, 'top-menu');
    assert.equal(storage.get('cats_layout_alice'), 'top-menu');
    assert.equal(elements.get('body')['sidebar-collapsed'], false);

    // Closing and reopening navigation must never replace the user's workspace appearance.
    appearance.applyTheme('forest');
    for (const layout of ['minimal', 'compact', 'standard', 'wide']) {
        appearance.applyLayout(layout);
        const initiallyCollapsed = layout === 'wide';
        appearance.toggleSidebar();
        assert.equal(elements.get('body')['sidebar-collapsed'], !initiallyCollapsed);
        assert.equal(elements.get('#sidebarToggle').attributes['data-sidebar-state'], initiallyCollapsed ? 'open' : 'closed');
        appearance.toggleSidebar();
        assert.equal(elements.get('body')['sidebar-collapsed'], initiallyCollapsed);
        assert.equal(globals.document.documentElement.dataset.catsLayout, layout);
        assert.equal(elements.get('#userLayout').value, layout);
        assert.equal(storage.get('cats_layout_alice'), layout);
        assert.equal(attrs['data-cats-theme'], 'forest');
    }
    appearance.applyLayout('minimal');
    appearance.toggleSidebar();
    appearance.restoreAppearance();
    assert.equal(globals.document.documentElement.dataset.catsLayout, 'minimal');
    globals.window.innerWidth = 500;
    appearance.toggleSidebar();
    assert.equal(elements.get('#sidebar').hasClass('mobile-open'), true);
    assert.equal(elements.get('#sidebarToggle').attributes['data-sidebar-state'], 'open');
    appearance.toggleSidebar();
    assert.equal(elements.get('#sidebar').hasClass('mobile-open'), false);
    assert.equal(elements.get('#sidebarToggle').attributes['data-sidebar-state'], 'closed');
    assert.equal(globals.document.documentElement.dataset.catsLayout, 'minimal');
    assert.equal(storage.get('cats_layout_alice'), 'minimal');
    assert.equal(attrs['data-cats-theme'], 'forest');
    globals.window.innerWidth = 1200;

    let allowed = true;
    const escape = (s) =>
        String(s ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('"', '&quot;')
            .replaceAll('<', '&lt;');
    const { exports: forms } = await loadModules('modules/ui/forms.js', globals, {
        'modules/core/state.js': { state },
        'modules/core/utils.js': { esc: escape, json: JSON.parse, fieldValue: (v) => String(v) },
        'modules/core/permissions.js': { has: (p) => allowed && p === 'PI.UNMASK' },
        'modules/ui/appearance.js': { getSectionLayout: appearance.getSectionLayout },
    });
    const field = { name: 'tax"<id', sensitive: true, allowUnmask: true, type: 'text' };
    let html = forms.templateFieldControlHtml(field, '***123', 'detail-dynamic-field', true);
    assert.match(html, /pi-reveal/);
    assert.match(html, /data-pi-edit="%7B/);
    assert.match(html, /tax&amp;quot;|tax&quot;/);
    assert.doesNotMatch(html, /<input/);
    field.allowUnmask = false;
    html = forms.templateFieldControlHtml(field, '***123', 'detail-dynamic-field', false);
    assert.doesNotMatch(html, /pi-reveal/);
    assert.match(html, /\*\*\*123/);
    allowed = false;
    field.allowUnmask = true;
    assert.doesNotMatch(forms.templateFieldControlHtml(field, '***123', 'detail-dynamic-field', false), /pi-reveal/);
    const sections = [
        { id: 's1', name: 'First', order: 1 },
        { id: 's2', name: 'Second', order: 2 },
    ];
    const cfg = { layoutMode: 'Accordion', showSectionNumbers: true };
    for (const [mode, marker] of [
        ['template', 'accordion-item'],
        ['single', 'data-section-page'],
        ['tab', 'nav-tabs'],
        ['accordion', 'accordion-item'],
        ['popup', 'cats-template-popup'],
        ['wizard', 'cats-wizard-pane'],
    ]) {
        appearance.applySectionLayout(mode);
        const rendered = forms.configuredSectionsHtml(sections, [], {}, null, 'dynamic-field', cfg);
        assert.ok(rendered.includes(marker), mode + ' did not render');
        assert.ok(rendered.includes('First') && rendered.includes('Second'), mode + ' dropped a section');
        assert.equal(cfg.layoutMode, 'Accordion', 'User preference modified template');
    }
    state.user = { id: 'bob' };
    assert.equal(appearance.getSectionLayout(), 'template');
    state.user = { id: 'alice' };
    assert.equal(appearance.getSectionLayout(), 'wizard');
    appearance.applySectionLayout('invalid');
    assert.equal(appearance.getSectionLayout(), 'template');
    console.log(
        'PASS: nine themes, per-user preferences, page and section layouts, PI masking, and unchanged template configuration.',
    );
}
main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
