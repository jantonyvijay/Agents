﻿using System.Reflection;
using System.Security.Claims;
using System.Text.Json;
using CATS.Api;
using CATS.Api.Controllers;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

if(args.Contains("--verify-atm-display"))
{
 using var configuration=JsonDocument.Parse(File.ReadAllText("src/CATS.Api/appsettings.json"));
 var database=configuration.RootElement.GetProperty("Database");
 var displayRepo=new CatsRepository(new AdoHelper(new DbConnectionFactory(new DatabaseOptions {
  Provider=database.GetProperty("Provider").GetString()!,ConnectionString=database.GetProperty("ConnectionString").GetString()!
 })));
 var displayAlert=await displayRepo.GetAlertAsync(long.Parse(args[Array.IndexOf(args,"--verify-atm-display")+1]))??throw new Exception("Alert not found");
 using var displayData=JsonDocument.Parse(displayAlert.DynamicDataJson);
 foreach(var field in new[]{"ATMID","PenaltyMonth","PenaltyAmount"})
 {
  if(!displayData.RootElement.TryGetProperty(field,out var value)||string.IsNullOrWhiteSpace(value.ToString()))throw new Exception($"Missing display field {field}");
  Console.WriteLine($"PASS: {field} is populated by the case data loader.");
 }
 return;
}

// Optional read-only check against saved audit snapshots; never prints configuration values.
if(args.Contains("--verify-template-audit"))
{
 using var config=JsonDocument.Parse(File.ReadAllText("src/CATS.Api/appsettings.json"));
 await using var connection=new Microsoft.Data.SqlClient.SqlConnection(config.RootElement.GetProperty("Database").GetProperty("ConnectionString").GetString());
 await connection.OpenAsync();
 await using var command=connection.CreateCommand();
 command.CommandText="SELECT TOP 10 Action,PreviousValueJson,NewValueJson FROM AuditLog WHERE EntityType IN ('Template','WorkflowDefinition') ORDER BY CreatedAtUtc DESC";
 await using var reader=await command.ExecuteReaderAsync();
 while(await reader.ReadAsync())
 {
  var auditResult=ConfigurationAuditDetails.Compare(reader.IsDBNull(1)?null:reader.GetString(1),reader.IsDBNull(2)?null:reader.GetString(2));
  if(!auditResult.Available)throw new Exception("A recent audit snapshot could not be parsed.");
  Console.WriteLine($"PASS: {reader.GetString(0)} snapshot readable; {auditResult.TotalChanges} changes.");
 }
 return;
}

long nextIdBlock=1000; CatsId.Configure(()=>{var start=nextIdBlock;nextIdBlock+=CatsId.BlockSize;return start;});
var repo=DispatchProxy.Create<ICatsRepository,RepoFake>();
var fake=(RepoFake)(object)repo;
var hasher=new Pbkdf2PasswordHasher();
fake.User.PasswordHash=hasher.Hash("test-password");
var protector=new Protector();
var service=new AlertApplicationService(repo,null!,protector,null!,null!,null!,null!);
var atmCaseData=new AtmCaseDataService(repo,null!);
var controller=new AlertsController(repo,null!,service,atmCaseData,protector,hasher);
void Login(bool permitted=true,string branch="B1") {
 var claims=new List<Claim>{new(ClaimTypes.NameIdentifier,"1"),new(ClaimTypes.Name,"tester"),new("branch",branch)};
 if(permitted)claims.Add(new("permission",CatsPermissions.PiUnmask));
 controller.ControllerContext=new(){HttpContext=new DefaultHttpContext{User=new ClaimsPrincipal(new ClaimsIdentity(claims,"test"))}};
}
async Task<IActionResult> Reveal(string name="taxId",string password="test-password")=>await controller.UnmaskPi(1,new(){Field=name,Password=password},default);
void Check(bool ok,string message){if(!ok)throw new Exception(message);}
var mergeAtm=typeof(CatsRepository).GetMethod("MergeAtmCaseData",BindingFlags.NonPublic|BindingFlags.Static)!;
foreach(var atmType in new[]{"ATM_ONUS","ATM_OFFUS"})
{
 var row=new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["ATMID"]="TESTATM",["PenaltyMonth"]="10",["PenaltyAmount"]=2100m,["SourceDataJson"]="{\"RATC_Status\":\"Pending\",\"ATMID\":\"stale\"}"};
 var merged=(System.Text.Json.Nodes.JsonObject)mergeAtm.Invoke(null,[atmType,"SqlServer",row])!;
 Check(merged["ATMID"]!.ToString()=="TESTATM" && merged["PenaltyMonth"]!.ToString()=="10" && merged["PenaltyAmount"]!.GetValue<decimal>()==2100m && merged["RATC_Status"]!.ToString()=="Pending","ATM summary fields must be loaded from the authoritative row alongside response data.");
}
Console.WriteLine("PASS: OnUs and OffUs summary fields survive source-data loading without changing the upload mapping catalog.");
var assignmentMethod=typeof(CATS.Workflow.CatsWorkflowEngine).GetMethod("IsAssignedTo",BindingFlags.NonPublic|BindingFlags.Static)!;
var assignmentUser=new CurrentUser{Id=101,UserName="atmc1",RoleCode="ATMC",BranchCode="B1"};
bool Assigned(WorkItemRecord item)=>(bool)assignmentMethod.Invoke(null,[item,assignmentUser])!;
Check(Assigned(new(){AssignedRoleCode="ATMC",AssignedBranchCode="B1"}),"Role/branch pending assignment should be actionable.");
Check(!Assigned(new(){AssignedRoleCode="RATC",AssignedBranchCode="B1"}),"ATMC must not action RATC work.");
Check(!Assigned(new(){AssignedRoleCode="ATMC",AssignedUserId=999,AssignedBranchCode="B1"}),"Named assignment must not grant actions to another user in the same role.");
Check(Assigned(new(){AssignedRoleCode="RATC",AssignedUserId=101,AssignedBranchCode="B2"}),"Explicit user assignment must remain actionable.");
fake.WorkItems=[new(){CompletedBy="atmc1",AssignedRoleCode="OLD_ROLE",AssignedBranchCode="B2",Status=WorkItemStatus.Completed}];
await service.EnsureViewAsync(new(){Id=7,BranchCode="B2"},assignmentUser,default);
fake.WorkItems=[];
Console.WriteLine("PASS: role/branch and exclusive named assignments; personal action history remains viewable.");
var designBefore=JsonSerializer.Serialize(new { FieldsJson="[{\"id\":\"amount\",\"required\":false,\"defaultValue\":\"old-secret\"}]",ViewConfigurationJson="{\"layoutMode\":\"Single\"}" });
var designAfter=JsonSerializer.Serialize(new { FieldsJson="[{\"id\":\"amount\",\"required\":true,\"defaultValue\":\"new-secret\"}]",ViewConfigurationJson="{\"layoutMode\":\"Tab\"}" });
var designChanges=ConfigurationAuditDetails.Compare(designBefore,designAfter);
Check(designChanges.TotalChanges==3 && designChanges.Changes.Any(x=>x.Property=="fields[amount].required" && x.Before=="false" && x.After=="true"),"Field audit must show precise before/after changes.");
Check(designChanges.Changes.Any(x=>x.Property=="viewconfiguration.layoutmode" && x.After=="Tab"),"Layout changes must appear in audit.");
Check(!JsonSerializer.Serialize(designChanges).Contains("secret"),"Audit must not disclose field defaults.");
var workflowChanges=ConfigurationAuditDetails.Compare("{\"stages\":[{\"id\":\"atmc\",\"editableFields\":[]}]}","{\"stages\":[{\"id\":\"atmc\",\"editableFields\":[\"*\"]}]}");
Check(workflowChanges.Changes.Any(x=>x.Property=="stages[atmc].editablefields[0]" && x.After=="*"),"Workflow audit must include edit permissions.");
Check(!ConfigurationAuditDetails.Compare(null,"{}").HasPrevious && !ConfigurationAuditDetails.Compare("invalid","{}").Available,"Legacy/malformed audit snapshots must be handled explicitly.");
Console.WriteLine("PASS: detailed field, design and workflow audit differences, redaction and legacy snapshots.");
var mixedBefore=JsonSerializer.Serialize(new { FieldsJson="[{\"id\":\"f1\",\"optionsJson\":\"plain text\",\"required\":false}]",ViewConfigurationJson="" });
var mixedAfter=JsonSerializer.Serialize(new { FieldsJson="[{\"id\":\"f1\",\"optionsJson\":\"other text\",\"required\":true}]",ViewConfigurationJson="" });
var mixedAudit=ConfigurationAuditDetails.Compare(mixedBefore,mixedAfter);
Check(mixedAudit.Available && mixedAudit.Changes.Any(x=>x.Property=="fields[f1].required" && x.After=="true") && mixedAudit.Changes.Any(x=>x.Property=="fields[f1].optionsjson" && x.Before=="plain text"),"Malformed nested JSON must not hide other audit changes.");
Console.WriteLine("PASS: empty and plain-text nested JSON remain comparable without disabling audit details.");
var sqlServerSchema=File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"db","sqlserver","schema.sql"));
var schemaBatches=((IEnumerable<string>)typeof(DatabaseBootstrapper)
 .GetMethod("SplitBatches",BindingFlags.NonPublic|BindingFlags.Static)!
 .Invoke(null,[sqlServerSchema,"SqlServer"])!).ToList();
foreach(var table in new[]{"tbl_ATM_Txn_Mntr_OnUs","tbl_ATM_Txn_Mntr_OFFUs"})
{
 foreach(var column in new[]{"AlertId","ATMID","PenaltyMonth","PenaltyAmount","CaseCategory","SourceBatchId","SourceRowNumber","ReopenedFromAlertId","SourceDataJson"})
 {
  var columnBatch=schemaBatches.FindIndex(batch=>batch.Contains($"ALTER TABLE dbo.{table} ADD {column} "));
  var firstIndexBatch=schemaBatches.FindIndex(batch=>batch.Contains($" ON dbo.{table}("));
  Check(columnBatch>=0 && firstIndexBatch>columnBatch,$"{table}.{column} must be added in a separate batch before legacy table indexes.");
 }
}
Console.WriteLine("PASS: SQL Server legacy ATM linkage columns are added before dependent indexes in separate startup batches.");
var onUsCsv = CsvParser.Parse("Type of Settlement~CRM No/Proactive No~Transaction Date~Date of Customer complaint~Date of credit to customer a/c~Account Number~T+5 Calender Days~Days~Penalty (Rs.)~ATM ID~Transaction Number~Transaction Amount~Disputed Amount~EJ Error~Narration\nCash~CRM-1~2025-01-01~2025-01-02~2025-01-03~00123~2025-01-08~5~250.50~ATM-1~TXN-1~1000.00~250.50~None~\"Contains ~ delimiter\"");
Check(onUsCsv.Count==1 && onUsCsv[0]["Narration"]=="Contains ~ delimiter","Tilde-delimited OnUs CSV parsing failed");
var normalizePenaltyRows=typeof(AtmController).GetMethod("NormalizePenaltyRows",BindingFlags.NonPublic|BindingFlags.Static)!;
var defaultView=new TemplateViewConfiguration();
var normalizedOnUs=(List<Dictionary<string,string>>)normalizePenaltyRows.Invoke(null,["OnUs",onUsCsv,"01","2025",defaultView])!;
Check(normalizedOnUs[0]["ATMID"]=="ATM-1" && normalizedOnUs[0]["PenaltyAmount"]=="250.50" &&
 normalizedOnUs[0]["Settlement_Type"]=="Cash" && normalizedOnUs[0]["Acc_No"]=="00123" &&
 normalizedOnUs[0]["Penalty_Month"]=="01" && normalizedOnUs[0]["Penalty_Year"]=="2025","OnUs source-to-table field mapping failed");
var onUsSourceToTable = new (string Source, string Target)[]
{
 ("Type of Settlement","Settlement_Type"),("CRM No/Proactive No","CRM_Proactive_No"),
 ("Transaction Date","Transaction_Date"),("Date of Customer complaint","Customer_Complaint_Date"),
 ("Date of credit to customer a/c","Customer_Acc_Credit_Date"),("Account Number","Acc_No"),
 ("T+5 Calender Days","T_5_Calender_Days"),("Days","Days"),("Penalty (Rs.)","Penalty_Rs"),
 ("ATM ID","ATM_ID"),("Transaction Number","Transaction_No"),("Transaction Amount","Transaction_Amount"),
 ("Disputed Amount","Disputed_Amount"),("EJ Error","EJ_Error"),("Narration","Narration")
};
Check(onUsSourceToTable.All(mapping=>normalizedOnUs[0][mapping.Target]==onUsCsv[0][mapping.Source]),
 "An OnUs source header did not map to its documented SQL column.");
foreach(var calendarHeader in new[]{"T+5 Calendar Days","T_5_Calendar_Days","T+5 Calender Days"})
{
 var calendarSource=new Dictionary<string,string>(onUsCsv[0],StringComparer.OrdinalIgnoreCase);
 var calendarValue=calendarSource["T+5 Calender Days"];
 calendarSource.Remove("T+5 Calender Days");
 calendarSource[calendarHeader]=calendarValue;
 foreach(var mappingHeader in new[]{"T+5 Calender Days","T+5 Calendar Days","T_5_Calender_Days"})
 {
  var calendarView=new TemplateViewConfiguration{SourceColumnMappings=AtmSourceColumns.TemplateMappings("ATM_ONUS")};
  calendarView.SourceColumnMappings.Single(x=>x.Field=="T_5_Calender_Days").SourceColumn=mappingHeader;
  var calendarRows=(List<Dictionary<string,string>>)normalizePenaltyRows.Invoke(null,["OnUs",new List<Dictionary<string,string>>{calendarSource},"01","2025",calendarView])!;
  Check(calendarRows[0]["T_5_Calender_Days"]==calendarValue,
   $"OnUs header '{calendarHeader}' did not populate the legacy column with mapping '{mappingHeader}'");
 }
}
var missingCalendarSource=new Dictionary<string,string>(onUsCsv[0],StringComparer.OrdinalIgnoreCase);
missingCalendarSource.Remove("T+5 Calender Days");
try
{
 normalizePenaltyRows.Invoke(null,["OnUs",new List<Dictionary<string,string>>{missingCalendarSource},"01","2025",defaultView]);
 throw new Exception("Missing required calendar column accepted");
}
catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException invalid &&
 invalid.Message.Contains("missing required column(s): T+5 Calender Days")){}
var duplicateCalendarSource=new Dictionary<string,string>(onUsCsv[0],StringComparer.OrdinalIgnoreCase)
 {["T+5 Calendar Days"]="2025-01-09"};
try
{
 normalizePenaltyRows.Invoke(null,["OnUs",new List<Dictionary<string,string>>{duplicateCalendarSource},"01","2025",defaultView]);
 throw new Exception("Conflicting Calendar/Calender columns accepted");
}
catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException invalid &&
 invalid.Message.Contains("duplicate columns after header normalization")){}
Check(SourceColumnMapper.Normalize("Calendar Date")!=SourceColumnMapper.Normalize("Calender Date"),
 "ATM calendar compatibility must not alter unrelated column names");
Console.WriteLine("PASS: OnUs Calendar/Calender headers map to the legacy column in both directions; missing and duplicate columns remain rejected.");
try
{
 normalizePenaltyRows.Invoke(null,["OnUs",CsvParser.Parse("Type of Settlement~Type_of_Settlement~CRM No/Proactive No~Transaction Date~Date of Customer complaint~Date of credit to customer a/c~Account Number~T+5 Calender Days~Days~Penalty (Rs.)~ATM ID~Transaction Number~Transaction Amount~Disputed Amount~EJ Error~Narration\nCash~Other~CRM-1~2025-01-01~2025-01-02~2025-01-03~00123~2025-01-08~5~250.50~ATM-1~TXN-1~1000.00~250.50~None~Narration"),"01","2025",defaultView]);
 throw new Exception("Duplicate normalized OnUs header accepted");
}
catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){}
typeof(AtmController).GetMethod("ValidateRows",BindingFlags.NonPublic|BindingFlags.Static)!.Invoke(null,["OnUs",normalizedOnUs]);
var offUsCsv=CsvParser.Parse("ATM ID,Customer Penalty,Chargeback reference no,Chargeback Date,Transaction Amount,Card number,RRN no\nATM-2,900,CB-1,2025-02-03,900,4111,RRN-7");
var normalizedOffUs=(List<Dictionary<string,string>>)normalizePenaltyRows.Invoke(null,["OffUs",offUsCsv,"02","2025",defaultView])!;
Check(normalizedOffUs[0]["ATMID"]=="ATM-2" && normalizedOffUs[0]["PenaltyAmount"]=="900" &&
 normalizedOffUs[0]["Chargeback_Ref_No"]=="CB-1" && normalizedOffUs[0]["CARD_No"]=="4111" && normalizedOffUs[0]["RRN_No"]=="RRN-7" && !normalizedOffUs[0].ContainsKey("EJError"),
 "OffUs source-to-table field mapping failed");
Check(AtmSourceColumns.OffUs.Select(x=>x.Header).SequenceEqual("Chargeback reference no~Chargeback Date~Acquiring Bank~Issuing Bank~Transaction Date~Transaction Time~RRN no~ATM ID~Card number~Transaction Amount~Disputed Amount~Customer Penalty~Adjustment Date~Adjustment Type~Adjustment Time~Narration~Adjustment Amount".Split('~')),"OffUs default headers do not match the documented file");
var atmTemplateFields=typeof(DatabaseBootstrapper).GetMethod("CreateAtmTemplateFields",BindingFlags.NonPublic|BindingFlags.Static)!;
var atmListFieldDefaults=typeof(DatabaseBootstrapper).GetMethod("CreateAtmListFieldDefaults",BindingFlags.NonPublic|BindingFlags.Static)!;
var onUsTemplateFields=(List<TemplateField>)atmTemplateFields.Invoke(null,["ATM_ONUS"])!;
var offUsTemplateFields=(List<TemplateField>)atmTemplateFields.Invoke(null,["ATM_OFFUS"])!;
var onUsListDefaults=(List<AlertListFieldConfiguration>)atmListFieldDefaults.Invoke(null,["ATM_ONUS"])!;
var offUsListDefaults=(List<AlertListFieldConfiguration>)atmListFieldDefaults.Invoke(null,["ATM_OFFUS"])!;
Check(onUsTemplateFields.Any(field=>field.Name=="CRM_Proactive_No"&&field.Label=="CRM No/Proactive No") &&
 onUsTemplateFields.Any(field=>field.Name=="Customer_Acc_Credit_Date"&&field.Type=="date"&&field.ReadOnly) &&
 offUsTemplateFields.Any(field=>field.Name=="Chargeback_Ref_No") &&
 offUsTemplateFields.Select(field=>field.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count()==offUsTemplateFields.Count &&
 onUsListDefaults.All(field=>!field.Field.Equals("BranchCode",StringComparison.OrdinalIgnoreCase)) &&
 offUsListDefaults.All(field=>!field.Field.Equals("BranchCode",StringComparison.OrdinalIgnoreCase)),
 "ATM template detail fields are missing, editable, or duplicated");
try{CsvParser.Parse("a~b\n1");throw new Exception("Malformed CSV row width accepted");}
catch(InvalidOperationException){}
var commaPenaltyText="\uFEFFATM ID,EJ Error,Narration\r\n"+
 string.Concat(Enumerable.Repeat("ATM-1,No error,Penalty paid\r\n",64))+
 "ATM-2,Dispenser error ~ E*3,\"Contains, a comma\"\r\n";
foreach(var separator in new char?[]{null,','})
{
 var parsedPenalty=CsvParser.Parse(commaPenaltyText,separator);
 Check(parsedPenalty.Count==65 && parsedPenalty[64].Count==3 &&
  parsedPenalty[64]["EJ Error"]=="Dispenser error ~ E*3" &&
  parsedPenalty[64]["Narration"]=="Contains, a comma","Comma CSV with a literal tilde at row 66 did not parse correctly");
}
try
{
 CsvParser.Parse(commaPenaltyText,'~');
 throw new Exception("A configured tilde separator silently accepted comma CSV");
}
catch(InvalidOperationException ex)when(ex.Message.Contains("configured column separator") &&
 ex.Message.Contains("Comma or Auto-detect") && ex.Message.Contains("Template Designer")){}
try
{
 CsvParser.Parse("ATM ID~Narration\nATM-1~Contains, comma",',');
 throw new Exception("A configured comma separator silently accepted tilde text");
}
catch(InvalidOperationException ex)when(ex.Message.Contains("Tilde or Auto-detect")){}
Check(CsvParser.Parse("Narration\nDispenser error ~ E*3",',')[0]["Narration"]=="Dispenser error ~ E*3",
 "A valid single-column file with a literal tilde was rejected");
try
{
 CsvParser.Parse("ATM ID,EJ Error\nATM-1,Error,Extra",',');
 throw new Exception("Malformed comma CSV row width accepted");
}
catch(InvalidOperationException ex)when(ex.Message=="CSV row 2 contains 3 values; expected 2."){}
Console.WriteLine("PASS: Comma CSV preserves literal tildes and quoted commas; separator mismatches provide configuration guidance without overriding explicit settings.");
Console.WriteLine("PASS: Tilde OnUs parsing, exact OnUs/OffUs field mapping, upload period metadata, and row-width validation.");
Login();
var result=(OkObjectResult)await Reveal("TAXID");
var payload=JsonSerializer.SerializeToElement(result.Value);
Check(payload.GetProperty("field").GetString()=="taxId" && payload.GetProperty("value").GetString()=="PRIVATE-1234","Authorised reveal failed");
Check(fake.Audits.Count==1 && fake.Audits[0].Action=="PI_UNMASK_VIEW" && !JsonSerializer.Serialize(fake.Audits[0]).Contains("PRIVATE-1234"),"Audit must not contain the private value");
Check(await Reveal(password:"wrong") is BadRequestObjectResult,"Wrong password accepted");
fake.Field.AllowUnmask=false;
Check(await Reveal() is BadRequestObjectResult,"Disabled reveal accepted");
fake.Field.AllowUnmask=true;fake.Field.Sensitive=false;
Check(await Reveal() is BadRequestObjectResult,"Non-PI field accepted");
fake.Field.Sensitive=true;
Check(await Reveal("unknown") is BadRequestObjectResult,"Unknown field accepted");
Login(false);
try {await Reveal();throw new Exception("Missing permission accepted");}catch(UnauthorizedAccessException){}
Login(true,"OTHER");
try {await Reveal();throw new Exception("Out-of-scope alert accepted");}catch(UnauthorizedAccessException){}
Check(fake.Audits.Count==1,"Failed reveals were recorded as successes");
Login();
Check(await Reveal("customerId") is OkObjectResult,"Customer ID reveal regressed");
Check(JsonSerializer.Deserialize<TemplateField>("{\"Sensitive\":true}")!.AllowUnmask,"Existing template compatibility failed");
Console.WriteLine("PASS: PI permission, password, field configuration, alert scope, audit privacy and legacy field defaults.");

var platform=DispatchProxy.Create<IPlatformRepository,DashboardFake>();
var gridController=new AlertsController(repo,platform,service,atmCaseData,protector,hasher){ControllerContext=controller.ControllerContext};
var gridResult=(OkObjectResult)await gridController.List(new(){DashboardId=5,DashboardMetricCode="PENDING"},default);
Check(await gridController.List(new(){DashboardId=5},default) is BadRequestObjectResult,"Missing metric returned unfiltered alerts");
var grid=(PagedResult<AlertListItem>)gridResult.Value!;
Check(grid.Data.Single().DynamicFields["CUSTOMERNAME"]=="Test Customer","Dashboard customer name was dropped");
Check(grid.Data.Single().DynamicFields["taxId"]=="***","Dashboard masked value changed");
Check(!grid.Data.Single().DynamicFields.ContainsKey("Unconfigured"),"Unconfigured field exposed");
Check(!grid.Data.Single().DynamicFields.ContainsKey("__CustomerIdRaw"),"Internal field exposed");
Console.WriteLine("PASS: Dashboard grid dynamic fields and masked values preserved; unconfigured/internal fields excluded.");

var validate=typeof(AlertApplicationService).GetMethod("ValidateDynamicData",BindingFlags.NonPublic|BindingFlags.Static)!;
var responseTemplate=new TemplateRecord{FieldsJson="[{\"name\":\"CDFinalRecommendation\",\"label\":\"CD Final recommendations\",\"type\":\"text\",\"required\":true}]"};
void ValidateResponse(string json,bool stored)=>validate.Invoke(null,[responseTemplate,JsonDocument.Parse(json).RootElement,new[]{"CDFinalRecommendation"},stored]);
ValidateResponse("{\"ACCOUNTNO\":\"legacy-import\",\"CDFinalRecommendation\":\"Central Due Diligence Review Positive\"}",true);
try{ValidateResponse("{\"ACCOUNTNO\":\"new-unknown\"}",false);throw new Exception("Unknown submitted field accepted");}catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){}
try{ValidateResponse("{\"ACCOUNTNO\":\"legacy-import\"}",true);throw new Exception("Required recommendation not validated");}catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){}
var matches=typeof(PlatformRepository).GetMethod("MatchesMetric",BindingFlags.NonPublic|BindingFlags.Static)!;
bool Matches(string recommendation,string metricValue,string stage="DT Verifier Review")=>(bool)matches.Invoke(null,[new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["CDFinalRecommendation"]=recommendation,["CurrentStageName"]=stage},new TemplateDashboardMetric{Type="FieldEquals",Field="CDFinalRecommendation",Value=metricValue}])!;
Check(Matches("Central Due Diligence Review Positive","Remove Txn Restriction"),"Positive review not counted as remove");
Check(Matches("Central Due Diligence Review Negative","Continue Txn Restriction"),"Negative review not counted as continue");
Check(!Matches("Central Due Diligence Review Positive","Continue Txn Restriction"),"Positive review counted as continue");
Check(Matches("Remove Txn Restriction","Remove Txn Restriction"),"Existing recommendation compatibility failed");
Check(!Matches("Central Due Diligence Review Positive","Remove Txn Restriction","DT User Review"),"Unsubmitted DT user recommendation was counted as remove");
var dtUserPendingMetric=new TemplateDashboardMetric{Code="PENDING",Title="Pending",Type="FieldEquals",Field="CurrentStageName",Value="DT User Review"};
Check((bool)matches.Invoke(null,[new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["CurrentStageName"]="DT User Review"},dtUserPendingMetric])!,"DT user review was not counted as pending");
Check(!(bool)matches.Invoke(null,[new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["CurrentStageName"]="DT Verifier Review"},dtUserPendingMetric])!,"Submitted DT user review remained pending");
var pendingMetric=new TemplateDashboardMetric{Code="PENDING",Title="Pending",Type="StatusCount",Value="Pending"};
var metricValueMethod=typeof(PlatformRepository).GetMethod("MetricValue",BindingFlags.NonPublic|BindingFlags.Static)!;
foreach(var expected in new[]{13,50}) {
 var fixture=Enumerable.Range(0,50).Select(i=>new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["Status"]=i<expected?"Pending":"Closed"}).ToList();
 var count=(long)metricValueMethod.Invoke(null,[fixture,pendingMetric])!;
 var drill=fixture.Where(row=>(bool)matches.Invoke(null,[row,pendingMetric])!).ToList();
 Check(count==expected&&drill.Count==expected,"Pending summary/drill-down count mismatch");
}
Console.WriteLine("PASS: Legacy import validation, required response validation, recommendation mapping, and exact 13/50 pending drill-down counts.");

var mappingFields=new List<TemplateField>{new(){Name="CustomerId",Label="Customer"},new(){Name="AccountId",Label="Account"},new(){Name="Remarks",Label="Remarks"}};
var mappingView=new TemplateViewConfiguration{SourceColumnMappings=[
 new(){Mode="BulkFileUpload",Field="CustomerId",SourceColumn="Cust No.",Required=true},
 new(){Mode="BulkFileUpload",Field="Remarks",SourceColumn="Notes"},
 new(){Mode="Sftp",Field="AccountId",SourceColumn="ACCT_NUMBER"}]};
var bulkValues=SourceColumnMapper.MapRow(mappingView,"BulkFileUpload",mappingFields,new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase){["cust_no"]="C-1",["AccountId"]="A-1",["notes"]="ok"});
Check(bulkValues["CustomerId"]=="C-1"&&bulkValues["AccountId"]=="A-1"&&bulkValues["Remarks"]=="ok","Bulk source column mapping or field-name default failed");
var sftpValues=SourceColumnMapper.MapRow(mappingView,"Sftp",mappingFields,new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase){["Acct Number"]="A-2",["Cust No."]="ignored"});
Check(sftpValues["AccountId"]=="A-2"&&sftpValues["CustomerId"]=="","Mappings leaked between ingestion modes");
Check(SourceColumnMapper.MissingRequiredColumns(mappingView,"BulkFileUpload",mappingFields,["Other"]).SequenceEqual(["Cust No."]),"Missing required source column was not reported");
Check(SourceColumnMapper.MissingRequiredColumns(mappingView,"BulkFileUpload",mappingFields,["Notes","Cust_No"]).Count==0,"Normalized source header, or an optional column, was reported missing");
Check(SourceColumnMapper.ToFieldMap(mappingView,"Sftp",mappingFields)["AccountId"]=="ACCT_NUMBER","Ingestion task field map did not use the template mapping");
foreach(var atmCode in new[]{"ATM_ONUS","ATM_OFFUS"}){
 var atmNames=((List<TemplateField>)atmTemplateFields.Invoke(null,[atmCode])!).Select(x=>x.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
 Check(AtmSourceColumns.TemplateMappings(atmCode).All(x=>x.Mode=="BulkFileUpload"&&atmNames.Contains(x.Field)),$"{atmCode} template mapping references a missing field");
}

var saveFake=DispatchProxy.Create<ICatsRepository,TemplateSaveFake>();
var templatesController=new TemplatesController(saveFake,null!){ControllerContext=new(){HttpContext=new DefaultHttpContext{User=new ClaimsPrincipal(new ClaimsIdentity(
 [new Claim(ClaimTypes.NameIdentifier,"1"),new Claim(ClaimTypes.Name,"tester"),new Claim("permission",CatsPermissions.TemplateManage)],"test"))}}};
SaveTemplateRequest MappingRequest(string code,params SourceColumnMappingConfiguration[] mappings){
 var request=new SaveTemplateRequest{Code=code,Name="Mapping test",Sections=[new(){Id="s1",Name="Section"}],
  Fields=[new(){SectionId="s1",Name="CustomerId",Label="Customer"},new(){SectionId="s1",Name="AccountId",Label="Account"}]};
 request.ViewConfiguration.SourceColumnMappings=mappings.ToList();
 return request;
}
SourceColumnMappingConfiguration Map(string mode,string field,string column)=>new(){Mode=mode,Field=field,SourceColumn=column};
var mappingSave=(OkObjectResult)await templatesController.Save(MappingRequest("MAP_TEST",
 Map("bulkfileupload","customerid"," Cust No "),
 Map("Sftp","AccountId","ACCT"),
 Map("ManualSingle","AccountId","ignored"),
 Map("FcQuery","AccountId","   "),
 Map("BulkFileUpload","RemovedField","stale")),default);
var savedMappings=((TemplateRecord)mappingSave.Value!).ViewConfigurationJson;
var savedView=JsonSerializer.Deserialize<TemplateViewConfiguration>(savedMappings,JsonDefaults.Options)!;
Check(savedView.SourceColumnMappings.Count==2&&savedView.SourceColumnMappings[0] is {Mode:"BulkFileUpload",Field:"CustomerId",SourceColumn:"Cust No"}&&savedView.SourceColumnMappings[1] is {Mode:"Sftp",Field:"AccountId",SourceColumn:"ACCT"},"Template save did not normalize, prune, and persist source column mappings");
Check(await templatesController.Save(MappingRequest("MAP_TEST",Map("Bulk","CustomerId","x")),default) is BadRequestObjectResult,"Invalid mapping mode accepted");
Check(await templatesController.Save(MappingRequest("MAP_TEST",Map("Sftp","CustomerId","a"),Map("Sftp","CustomerId","b")),default) is BadRequestObjectResult,"Duplicate mapping for one field accepted");
var atmRequest=new SaveTemplateRequest{Code="ATM_ONUS",Name="ATM",Sections=[new(){Id="s1",Name="Section"}],Fields=[
 new(){SectionId="s1",Name="ATMID",Label="ATM ID",Required=true},new(){SectionId="s1",Name="PenaltyMonth",Label="Month",Required=true},
 new(){SectionId="s1",Name="PenaltyAmount",Label="Amount",Type="number",Required=true},
 new(){SectionId="s1",Name="CaseCategory",Label="Category",Type="select",Required=true,OptionsJson="[\"Recoverable\",\"Service Gesture\",\"Goodfaith\",\"Acquiring Dependency\",\"Non-Recoverable\"]"},
 new(){SectionId="s1",Name="Settlement_Type",Label="Settlement"}]};
atmRequest.ViewConfiguration.SourceColumnMappings=[
 new(){Mode="BulkFileUpload",Field="Settlement_Type",SourceColumn=" Settlement "},
 new(){Mode="BulkFileUpload",Field="ATM_ID",SourceColumn="ATM ID",Required=true},
 new(){Mode="BulkFileUpload",Field="Penalty_Rs",SourceColumn="Penalty (Rs.)",Required=true},
 new(){Mode="Sftp",Field="ATMID",SourceColumn="ATM"}];
atmRequest.ViewConfiguration.BulkFileFormat="txt";
atmRequest.ViewConfiguration.BulkFileDelimiter="|";
var atmSave=(OkObjectResult)await templatesController.Save(atmRequest,default);
var atmView=JsonSerializer.Deserialize<TemplateViewConfiguration>(((TemplateRecord)atmSave.Value!).ViewConfigurationJson,JsonDefaults.Options)!;
Check(atmView.SourceColumnMappings.Any(x=>x.Mode=="BulkFileUpload"&&x.Field=="Settlement_Type"&&x.SourceColumn=="Settlement")&&
 atmView.SourceColumnMappings.Any(x=>x.Mode=="Sftp"&&x.Field=="ATMID")&&
 atmView.SourceColumnMappings.Any(x=>x.Mode=="BulkFileUpload"&&x.Field=="ATM_ID"&&x.Required)&&
 !atmView.SourceColumnMappings.Any(x=>x.Mode=="BulkFileUpload"&&x.Field=="ATMID"),"Admin-edited ATM mapping was overwritten, or a derived column was mapped");
Check(atmView.BulkFileFormat=="Txt"&&atmView.BulkFileDelimiter=="|","Bulk file format and separator were not saved");
SaveTemplateRequest FormatRequest(string format,string delimiter){var r=MappingRequest("MAP_TEST");r.ViewConfiguration.BulkFileFormat=format;r.ViewConfiguration.BulkFileDelimiter=delimiter;return r;}
Check(await templatesController.Save(FormatRequest("Pdf",""),default) is BadRequestObjectResult,"Unsupported bulk file format accepted");
Check(await templatesController.Save(FormatRequest("Csv","ab"),default) is BadRequestObjectResult,"Multi-character separator accepted");
Check(await templatesController.Save(FormatRequest("Csv","a"),default) is BadRequestObjectResult,"Alphanumeric separator accepted");
var excelSave=(OkObjectResult)await templatesController.Save(FormatRequest("excel","|"),default);
var excelSavedView=JsonSerializer.Deserialize<TemplateViewConfiguration>(((TemplateRecord)excelSave.Value!).ViewConfigurationJson,JsonDefaults.Options)!;
Check(excelSavedView.BulkFileFormat=="Excel"&&excelSavedView.BulkFileDelimiter=="","Excel format kept a text separator");

// An administrator can rename a file column, mark columns optional, and choose the separator; the ATM upload follows it.
var customAtmView=new TemplateViewConfiguration{BulkFileDelimiter="|",SourceColumnMappings=[
 new(){Mode="BulkFileUpload",Field="ATM_ID",SourceColumn="Terminal",Required=true},
 new(){Mode="BulkFileUpload",Field="Penalty_Rs",SourceColumn="Fine Amount",Required=true},
 new(){Mode="BulkFileUpload",Field="Settlement_Type",SourceColumn="Settlement"},
 new(){Mode="BulkFileUpload",Field="Narration",SourceColumn=""}]};
var pipeRows=TabularFileReader.Read(new MemoryStream(System.Text.Encoding.UTF8.GetBytes("Terminal|Fine Amount|Narration\nATM-9|75.5|text, with comma")),"penalty.txt",customAtmView);
var customNormalized=(List<Dictionary<string,string>>)normalizePenaltyRows.Invoke(null,["OnUs",pipeRows,"03","2025",customAtmView])!;
Check(customNormalized[0]["ATMID"]=="ATM-9"&&customNormalized[0]["PenaltyAmount"]=="75.5"&&customNormalized[0]["Settlement_Type"]==""&&
 customNormalized[0]["Narration"]=="text, with comma"&&customNormalized[0]["PenaltyMonth"]=="03","Edited ATM column mapping or separator was not applied to the upload");
try{normalizePenaltyRows.Invoke(null,["OnUs",CsvParser.Parse("ATM ID,Fine Amount\nATM-9,5"),"03","2025",customAtmView]);throw new Exception("A missing required mapped column was accepted");}
catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException ex&&ex.Message.Contains("Terminal")){}

// File format enforcement and Excel reading.
try{TabularFileReader.Read(new MemoryStream([1]),"a.csv",new TemplateViewConfiguration{BulkFileFormat="Excel"});throw new Exception("CSV accepted for an Excel upload");}catch(InvalidOperationException){}
try{TabularFileReader.Read(new MemoryStream([1]),"a.csv",new TemplateViewConfiguration{BulkFileFormat="Txt"});throw new Exception("CSV accepted for a TXT upload");}catch(InvalidOperationException){}
try{TabularFileReader.Read(new MemoryStream(System.Text.Encoding.UTF8.GetBytes("not a workbook")),"a.xlsx",new TemplateViewConfiguration{BulkFileFormat="Excel"});throw new Exception("Corrupt Excel file accepted");}catch(InvalidOperationException ex)when(ex.Message.Contains("Excel")){}
var excelView=new TemplateViewConfiguration{BulkFileFormat="Excel"};
using(var xlsx=new MemoryStream())
{
 using(var workbook=new ClosedXML.Excel.XLWorkbook())
 {
  var sheet=workbook.Worksheets.Add("Data");
  sheet.Cell(1,1).Value="ATM ID";sheet.Cell(1,2).Value="Penalty (Rs.)";sheet.Cell(1,3).Value="Txn Date";
  sheet.Cell(2,1).Value="ATM-5";sheet.Cell(2,2).Value=1200.5;sheet.Cell(2,3).Value=new DateTime(2025,1,31);
  workbook.SaveAs(xlsx);
 }
 xlsx.Position=0;
 var excelRows=TabularFileReader.Read(xlsx,"upload.xlsx",excelView);
 Check(excelRows.Count==1&&excelRows[0]["ATM ID"]=="ATM-5"&&excelRows[0]["Penalty (Rs.)"]=="1200.5"&&excelRows[0]["Txn Date"]=="2025-01-31","Excel upload was not read correctly");
}
var excelSample=TabularFileReader.BuildSample(excelView,["ATM ID","Fine"],["A1","2"]);
Check(excelSample.Extension==".xlsx"&&TabularFileReader.Read(new MemoryStream(excelSample.Content),"s.xlsx",excelView)[0]["Fine"]=="2","Excel sample file did not round-trip");
var tildeView=new TemplateViewConfiguration{BulkFileFormat="Txt",BulkFileDelimiter="~"};
var tildeSample=TabularFileReader.BuildSample(tildeView,["ATM ID","Note"],["A1","a~b"]);
Check(tildeSample.Extension==".txt"&&TabularFileReader.Read(new MemoryStream(tildeSample.Content),"s.txt",tildeView)[0]["Note"]=="a~b","TXT sample file did not round-trip with its separator");
Console.WriteLine("PASS: Source column mapping and file format/separator are admin-editable, validated on save, enforced on upload (CSV/TXT/Excel), and drive the ATM penalty upload.");

// The downloadable ATM sample must carry the documented headers in order and upload cleanly.
var buildPenaltySample=typeof(AtmController).GetMethod("BuildPenaltySample",BindingFlags.NonPublic|BindingFlags.Static)!;
(byte[] Content,string ContentType,string Extension) Sample(string type,TemplateViewConfiguration view)=>((byte[],string,string))buildPenaltySample.Invoke(null,[type,view])!;
var onUsSampleView=new TemplateViewConfiguration{SourceColumnMappings=AtmSourceColumns.TemplateMappings("ATM_ONUS")};
var onUsSample=Sample("OnUs",onUsSampleView);
var onUsSampleHeader=System.Text.Encoding.UTF8.GetString(onUsSample.Content).TrimStart('\uFEFF').Split('\n')[0].TrimEnd('\r');
Check(onUsSample.Extension==".txt"&&onUsSampleHeader==string.Join("~",AtmSourceColumns.OnUs.Select(x=>x.Header)),"OnUs sample file does not match the documented tilde-delimited 15-column layout");
var onUsSampleRows=TabularFileReader.Read(new MemoryStream(onUsSample.Content),"sample.txt",new TemplateViewConfiguration{BulkFileFormat="Txt",BulkFileDelimiter="~"});
var onUsSampleNormalized=(List<Dictionary<string,string>>)normalizePenaltyRows.Invoke(null,["OnUs",onUsSampleRows,"01","2025",onUsSampleView])!;
typeof(AtmController).GetMethod("ValidateRows",BindingFlags.NonPublic|BindingFlags.Static)!.Invoke(null,["OnUs",onUsSampleNormalized]);
Check(onUsSampleNormalized.Count==1&&onUsSampleNormalized[0]["Penalty_Rs"]=="100.00"&&onUsSampleNormalized[0]["ATMID"]=="ATM0001","OnUs sample file did not map into the case fields");
var offUsSampleView=new TemplateViewConfiguration{SourceColumnMappings=AtmSourceColumns.TemplateMappings("ATM_OFFUS")};
var offUsSample=Sample("OffUs",offUsSampleView);
var offUsSampleRows=TabularFileReader.Read(new MemoryStream(offUsSample.Content),"sample"+offUsSample.Extension,new TemplateViewConfiguration());
var offUsSampleNormalized=(List<Dictionary<string,string>>)normalizePenaltyRows.Invoke(null,["OffUs",offUsSampleRows,"02","2025",offUsSampleView])!;
typeof(AtmController).GetMethod("ValidateRows",BindingFlags.NonPublic|BindingFlags.Static)!.Invoke(null,["OffUs",offUsSampleNormalized]);
var excelOnUsView=new TemplateViewConfiguration{BulkFileFormat="Excel",SourceColumnMappings=onUsSampleView.SourceColumnMappings};
var excelOnUsSample=Sample("OnUs",excelOnUsView);
var excelOnUsRows=TabularFileReader.Read(new MemoryStream(excelOnUsSample.Content),"sample.xlsx",excelOnUsView);
Check(excelOnUsSample.Extension==".xlsx"&&excelOnUsRows[0].Keys.SequenceEqual(AtmSourceColumns.OnUs.Select(x=>x.Header)),"Excel OnUs sample file headers are wrong");
var editedSampleView=new TemplateViewConfiguration{SourceColumnMappings=[new(){Mode="BulkFileUpload",Field="ATM_ID",SourceColumn="Terminal",Required=true},new(){Mode="BulkFileUpload",Field="Penalty_Rs",SourceColumn="Fine",Required=true}]};
var editedSampleHeader=System.Text.Encoding.UTF8.GetString(Sample("OnUs",editedSampleView).Content).TrimStart('\uFEFF').Split('\n')[0].TrimEnd('\r');
Check(editedSampleHeader=="Terminal~Fine","Sample file did not follow the administrator's edited column mapping");
Console.WriteLine("PASS: ATM OnUs/OffUs sample files match the template mapping (documented 15 OnUs columns), follow admin edits and formats, and upload without errors.");

// Mapping order: kept on save (even for fields with no column), clamped, and used for sample file column order.
var orderedMappingFields=new List<TemplateField>{new(){Name="A"},new(){Name="B"},new(){Name="C"}};
var orderedView=new TemplateViewConfiguration{SourceColumnMappings=[new(){Mode="BulkFileUpload",Field="C",Order=1},new(){Mode="BulkFileUpload",Field="A",Order=2}]};
Check(SourceColumnMapper.OrderedFields(orderedView,"BulkFileUpload",orderedMappingFields).Select(x=>x.Name).SequenceEqual(["C","A","B"]),"Mapping order did not apply, or unordered fields did not follow in field order");
Check(SourceColumnMapper.OrderedFields(orderedView,"Sftp",orderedMappingFields).Select(x=>x.Name).SequenceEqual(["A","B","C"]),"Mapping order leaked into another ingestion mode");
SourceColumnMappingConfiguration Ordered(string field,int order,string column="")=>new(){Mode="BulkFileUpload",Field=field,SourceColumn=column,Order=order};
var orderSave=(OkObjectResult)await templatesController.Save(MappingRequest("MAP_TEST",Ordered("AccountId",1),Ordered("CustomerId",99999,"Cust"),Ordered("Unknown",3)),default);
var orderSaved=JsonSerializer.Deserialize<TemplateViewConfiguration>(((TemplateRecord)orderSave.Value!).ViewConfigurationJson,JsonDefaults.Options)!.SourceColumnMappings;
Check(orderSaved.Count==2&&orderSaved[0] is {Field:"AccountId",Order:1,SourceColumn:""}&&orderSaved[1] is {Field:"CustomerId",Order:10000},"Mapping order was not saved, pruned for removed fields, and clamped");
var negativeSave=(OkObjectResult)await templatesController.Save(MappingRequest("MAP_TEST",Ordered("AccountId",-5)),default);
Check(JsonSerializer.Deserialize<TemplateViewConfiguration>(((TemplateRecord)negativeSave.Value!).ViewConfigurationJson,JsonDefaults.Options)!.SourceColumnMappings.Count==0,"A negative order was kept");
var movedMappings=AtmSourceColumns.TemplateMappings("ATM_ONUS");
movedMappings.ForEach(m=>m.Order=m.Field=="Narration"?1:m.Order+1);
var movedSampleHeader=System.Text.Encoding.UTF8.GetString(Sample("OnUs",new TemplateViewConfiguration{SourceColumnMappings=movedMappings}).Content).TrimStart('\uFEFF').Split('\n')[0].TrimEnd('\r');
Check(movedSampleHeader=="Narration~"+string.Join("~",AtmSourceColumns.OnUs.Take(14).Select(x=>x.Header)),"Sample file column order did not follow the mapping order");
Check(AtmSourceColumns.TemplateMappings("ATM_ONUS").Where(x=>AtmSourceColumns.OnUs.Any(c=>c.Column==x.Field)).Select(x=>x.Order).SequenceEqual(Enumerable.Range(1,15)),"Default ATM mapping is not in the documented file order");
Console.WriteLine("PASS: Source column mapping order is saved per source, clamped, defaults to the documented file order, and drives sample file column order.");

// ATM mapping is table-column based: every table column can be added or deleted, nothing is locked, and derived columns are never listed.
foreach(var atmCode in new[]{"ATM_ONUS","ATM_OFFUS"}){
 var defaultMappings=AtmSourceColumns.TemplateMappings(atmCode);
 Check(defaultMappings.Count==(atmCode=="ATM_ONUS"?15:17)&&defaultMappings.All(m=>!AtmTableColumns.IsInternal(m.Field)),$"{atmCode} default mapping must list only the documented file columns");
 foreach(var column in AtmTableColumns.For(atmCode,"SqlServer").Select(x=>x.Name)) Check(!AtmTableColumns.IsInternal(column),$"{column} is a derived column but is mappable");
 foreach(var meta in new[]{"Penalty_Month","Penalty_Year","UploadFileName","CreatedBy","CreatedDate","RecordStatus","ATMC_Status"})
  Check(AtmTableColumns.Find(atmCode,"SqlServer",meta) is not null,$"{atmCode} table column {meta} cannot be mapped");
 Check(AtmTableColumns.Find(atmCode,"PostgreSql","ATMC_Status") is null&&AtmTableColumns.Find(atmCode,"PostgreSql","Penalty_Month") is not null,"Provider column availability is wrong");
}
var atmFull=new SaveTemplateRequest{Code="ATM_ONUS",Name="ATM",Sections=atmRequest.Sections,Fields=[..atmRequest.Fields]};
atmFull.ViewConfiguration.SourceColumnMappings=[
 new(){Mode="BulkFileUpload",Field="ATMID",SourceColumn="x",Required=true,Order=1},
 new(){Mode="BulkFileUpload",Field="PenaltyAmount",SourceColumn="x",Required=true,Order=2},
 new(){Mode="BulkFileUpload",Field="ATM_ID",SourceColumn="Terminal",Required=true,Order=3},
 new(){Mode="BulkFileUpload",Field="Penalty_Rs",SourceColumn="Fine",Required=true,Order=4},
 new(){Mode="BulkFileUpload",Field="CreatedBy",SourceColumn="Maker",Order=5},
 new(){Mode="BulkFileUpload",Field="Penalty_Month",SourceColumn="Mon",Required=true,Order=6},
 new(){Mode="BulkFileUpload",Field="NotAColumn",SourceColumn="zzz",Order=7}];
var atmFullSave=(OkObjectResult)await templatesController.Save(atmFull,default);
var atmFullMappings=JsonSerializer.Deserialize<TemplateViewConfiguration>(((TemplateRecord)atmFullSave.Value!).ViewConfigurationJson,JsonDefaults.Options)!.SourceColumnMappings;
Check(atmFullMappings.Select(x=>x.Field).SequenceEqual(["ATM_ID","Penalty_Rs","CreatedBy","Penalty_Month"])&&
 atmFullMappings.Any(x=>x.Field=="CreatedBy"&&x.SourceColumn=="Maker"&&!x.Required)&&atmFullMappings.Any(x=>x.Field=="Penalty_Month"&&x.Required),"ATM mapping did not keep editable table columns, or kept derived/unknown ones");
var atmNoPenalty=new SaveTemplateRequest{Code="ATM_ONUS",Name="ATM",Sections=atmRequest.Sections,Fields=[..atmRequest.Fields]};
atmNoPenalty.ViewConfiguration.SourceColumnMappings=[new(){Mode="BulkFileUpload",Field="ATM_ID",SourceColumn="Terminal",Order=1}];
Check(await templatesController.Save(atmNoPenalty,default) is BadRequestObjectResult,"An ATM mapping without the penalty column was accepted");

// File-supplied period wins when valid, the upload form fills it otherwise, and upload metadata only fills blanks.
var periodView=new TemplateViewConfiguration{SourceColumnMappings=[..AtmSourceColumns.TemplateMappings("ATM_ONUS"),
 new(){Mode="BulkFileUpload",Field="Penalty_Month",SourceColumn="Month"},new(){Mode="BulkFileUpload",Field="CreatedBy",SourceColumn="UploadBy"}]};
var periodRows=CsvParser.Parse("Type of Settlement~CRM No/Proactive No~Transaction Date~Date of Customer complaint~Date of credit to customer a/c~Account Number~T+5 Calender Days~Days~Penalty (Rs.)~ATM ID~Transaction Number~Transaction Amount~Disputed Amount~EJ Error~Narration~Month~UploadBy\nCash~CRM-1~2025-01-01~2025-01-02~2025-01-03~00123~2025-01-08~5~250.50~ATM-1~TXN-1~1000.00~250.50~None~N~7~someone");
var periodNormalized=(List<Dictionary<string,string>>)normalizePenaltyRows.Invoke(null,["OnUs",periodRows,"01","2025",periodView])!;
AtmSourceColumns.ApplyUploadMetadata(periodNormalized,"real.txt","maker1",new DateTime(2025,3,4,5,6,7,DateTimeKind.Utc));
Check(periodNormalized[0]["Penalty_Month"]=="07"&&periodNormalized[0]["PenaltyMonth"]=="07"&&periodNormalized[0]["Penalty_Year"]=="2025"&&periodNormalized[0]["CreatedBy"]=="someone"&&
 periodNormalized[0]["UploadFileName"]=="real.txt"&&periodNormalized[0]["CreatedDate"]=="2025-03-04 05:06:07"&&periodNormalized[0]["ATM_ID"]=="ATM-1"&&periodNormalized[0]["Penalty_Rs"]=="250.50","Period or upload metadata were not resolved from the file, then the upload");
var badMonthRows=periodRows.Select(r=>new Dictionary<string,string>(r){["Month"]="13"}).ToList();
try{normalizePenaltyRows.Invoke(null,["OnUs",badMonthRows,"01","2025",periodView]);throw new Exception("An invalid file month was accepted");}catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){}
// Table-column-named file headers are ignored unless mapped, so a deleted mapping really stops the column being filled.
var noNarrationView=new TemplateViewConfiguration{SourceColumnMappings=AtmSourceColumns.TemplateMappings("ATM_ONUS").Where(x=>x.Field!="Narration").ToList()};
var noNarration=(List<Dictionary<string,string>>)normalizePenaltyRows.Invoke(null,["OnUs",CsvParser.Parse("Type of Settlement~CRM No/Proactive No~Transaction Date~Date of Customer complaint~Date of credit to customer a/c~Account Number~T+5 Calender Days~Days~Penalty (Rs.)~ATM ID~Transaction Number~Transaction Amount~Disputed Amount~EJ Error~Narration\nCash~CRM-1~2025-01-01~2025-01-02~2025-01-03~00123~2025-01-08~5~250.50~ATM-1~TXN-1~1000.00~250.50~None~Hello"),"01","2025",noNarrationView])!;
Check(!noNarration[0].ContainsKey("Narration")||noNarration[0]["Narration"]=="","A deleted mapping still populated its table column");
// Generic catalog validation.
var validateRows=typeof(AtmController).GetMethod("ValidateRows",BindingFlags.NonPublic|BindingFlags.Static)!;
foreach(var (column,value) in new[]{("Days","x"),("Acc_No",new string('1',21)),("Transaction_Date","not a date"),("Fourwayreconcilition","maybe"),("Transaction_Amount","abc")}){
 var invalid=new Dictionary<string,string>(periodNormalized[0],StringComparer.OrdinalIgnoreCase){[column]=value};
 try{validateRows.Invoke(null,["OnUs",new List<Dictionary<string,string>>{invalid}]);throw new Exception($"Invalid {column} was accepted");}catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){}
}
// The typed INSERT uses positional parameters and only whitelisted column names, for every provider.
var buildCaseInsert=typeof(AtmController).GetMethod("BuildCaseInsert",BindingFlags.NonPublic|BindingFlags.Static)!;
var insertRow=new Dictionary<string,string>(periodNormalized[0],StringComparer.OrdinalIgnoreCase){["ATMC_Status"]="Yes",["Fourwayreconcilition"]="1"};
foreach(var dialect in new IDbDialect[]{new SqlServerDialect(),new PostgreSqlDialect(),new OracleDialect()}){
 var (insertSql,insertArgs)=((string,List<DbArg>))buildCaseInsert.Invoke(null,[dialect,"tbl_ATM_Txn_Mntr_OnUs","ATM_ONUS",1001L,2002L,"real.txt","maker1","OnUs","checker1",3,insertRow])!;
 var insertColumns=insertSql[(insertSql.IndexOf('(')+1)..insertSql.IndexOf(") VALUES")].Split(',');
 Check(insertColumns.Length==insertArgs.Count&&insertColumns.Distinct(StringComparer.OrdinalIgnoreCase).Count()==insertColumns.Length&&insertArgs.All(a=>a.Name.Length<=30),$"{dialect.Name}: INSERT columns and parameters do not line up");
 Check(insertColumns.Contains("ATM_ID")&&insertColumns.Contains("Penalty_Rs")&&insertColumns.Contains("Narration")&&insertColumns.Contains("Penalty_Month")&&insertColumns.Contains("CreatedBy")&&insertColumns.Contains("ATMID"),$"{dialect.Name}: INSERT is missing mapped or derived columns");
 Check(insertColumns.Contains("ATMC_Status")==(dialect.Name=="SqlServer"),$"{dialect.Name}: legacy workflow columns must be written on SQL Server only");
}
Console.WriteLine("PASS: ATM mapping lists editable table columns only (no locks, no duplicates), supports add/delete, resolves period and metadata, and validates every mapped column by type.");

// ATM Staff Mapping master: documented headers and table columns, configuration rules, upload mapping, and typed upsert on every provider.
var staffStore=typeof(AtmController).Assembly.GetType("CATS.Api.Controllers.AtmStaffMappingStore")!;
T StaffCall<T>(string name,params object?[] args){
 try{return (T)staffStore.GetMethod(name,BindingFlags.Public|BindingFlags.Static)!.Invoke(null,args)!;}
 catch(TargetInvocationException e)when(e.InnerException is not null){System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(e.InnerException).Throw();throw;}
}
var staffHeader="ATM ID~ATMC Emp code~Backup ATMC code~RATC Emp code~Backup RATC Emp code~State Head Emp Code~Backup State Head~STATE~GH EmpCode~RH EmpCode~GH EmpCode1~Backup GH EmpCode~RH EmpCode1~Backup RH EmpCode~Backup GH EmpCode1~Backup RH EmpCode1";
Check(AtmStaffMappingColumns.Defaults.Select(x=>x.Header).SequenceEqual(staffHeader.Split('~')),"Staff Mapping default headers do not match the documented file");
Check(AtmStaffMappingColumns.Defaults.Where(x=>x.Column is "ATM_ID" or "ATMC_EMPCode" or "ATMC_EMPCode_BK" or "RATC_EMPCode" or "RATC_EMPCode_BK" or "SH_EMPCode" or "WBO_RH_EMPCode" or "STATE" or "GH_EMPCode" or "RH_EMPCode" or "GH_EMPCode_BK" or "RH_EMPCode_BK").Count()==12&&
 AtmStaffMappingColumns.Defaults.Single(x=>x.Header=="Backup State Head").Column=="WBO_RH_EMPCode"&&AtmStaffMappingColumns.Defaults.Single(x=>x.Header=="Backup RH EmpCode").Column=="RH_EMPCode_BK","Staff Mapping header to table column mapping does not follow the documented mapping");
foreach(var column in AtmStaffMappingColumns.All.Select(x=>x.Name)){
 Check(sqlServerSchema.Contains(column),$"SQL Server schema is missing {column} of {AtmStaffMappingColumns.Table}");
 foreach(var provider in new[]{"postgresql","oracle"})
  Check(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"db",provider,"schema.sql")).Contains(column,StringComparison.OrdinalIgnoreCase),$"{provider} schema is missing {column}");
}
var staffDefault=AtmStaffMappingColumns.DefaultConfiguration();
Check(AtmStaffMappingColumns.Normalize(staffDefault) is null&&staffDefault.SourceColumnMappings.Count==16&&staffDefault.BulkFileDelimiter=="~"&&staffDefault.SourceColumnMappings.Select(x=>x.Order).SequenceEqual(Enumerable.Range(1,16)),"Default Staff Mapping configuration is not valid");
TemplateViewConfiguration StaffView(params (string Field,string Source)[] entries)=>new(){SourceColumnMappings=entries.Select((x,i)=>new SourceColumnMappingConfiguration{Mode="BulkFileUpload",Field=x.Field,SourceColumn=x.Source,Order=i+1}).ToList()};
Check(AtmStaffMappingColumns.Normalize(StaffView(("ATMC_EMPCode","A")))is not null,"A Staff Mapping without ATM_ID was accepted");
Check(AtmStaffMappingColumns.Normalize(StaffView(("ATM_ID","A"),("Nope","B")))is not null,"An unknown table column was accepted");
Check(AtmStaffMappingColumns.Normalize(StaffView(("ATM_ID","A"),("STATE","a ")))is not null,"The same file column was mapped twice");
var staffEdited=StaffView(("ATM_ID","Terminal"),("STATE","State"),("SH_EMPCode","Head"));
Check(AtmStaffMappingColumns.Normalize(staffEdited) is null&&staffEdited.SourceColumnMappings[0].Required,"An edited Staff Mapping was rejected, or ATM_ID is not required");

var staffRows=CsvParser.Parse(staffHeader.Replace("~","\t").Replace("\t","~")+"\nATM-1~E1~E1B~E2~E2B~E3~E4~Maharashtra~E5~E6~E7~E8~E9~E10~E11~E12\nATM-2~~~~~~~Goa~~~~~~~~");
var staffNormalized=StaffCall<List<Dictionary<string,string>>>("NormalizeRows",staffRows,staffDefault);
Check(staffNormalized[0]["ATM_ID"]=="ATM-1"&&staffNormalized[0]["WBO_RH_EMPCode"]=="E4"&&staffNormalized[0]["RH_EMPCode_BK"]=="E10"&&staffNormalized[0]["GH_EMPCode1_BK"]=="E11"&&staffNormalized[1]["STATE"]=="Goa","Staff Mapping file columns did not map to table columns");
staffStore.GetMethod("ValidateRows")!.Invoke(null,[staffNormalized]);
try{StaffCall<List<Dictionary<string,string>>>("NormalizeRows",CsvParser.Parse("ATM ID~STATE\nA~B"),staffDefault);throw new Exception("A file missing required headers was accepted");}catch(InvalidOperationException ex)when(ex.Message.Contains("missing required")){}
var staffEditedRows=StaffCall<List<Dictionary<string,string>>>("NormalizeRows",CsvParser.Parse("Terminal,State,Head,Other\nATM-9,Kerala,E77,x"),staffEdited);
Check(staffEditedRows[0].Count==3&&staffEditedRows[0]["SH_EMPCode"]=="E77"&&!staffEditedRows[0].ContainsKey("ATMC_EMPCode"),"An edited mapping was not applied, or unmapped columns leaked into the row");
Dictionary<string,string> StaffRow(params (string Key,string Value)[] kv)=>kv.ToDictionary(x=>x.Key,x=>x.Value,StringComparer.OrdinalIgnoreCase);
void ExpectInvalid(string message,params Dictionary<string,string>[] rows){try{staffStore.GetMethod("ValidateRows")!.Invoke(null,[rows.ToList()]);throw new Exception(message);}catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){}}
ExpectInvalid("A duplicate ATM_ID was accepted",StaffRow(("ATM_ID","X")),StaffRow(("atm_id","x")));
ExpectInvalid("A blank ATM_ID was accepted",StaffRow(("ATM_ID"," ")));
ExpectInvalid("An over-long employee code was accepted",StaffRow(("ATM_ID","X"),("ATMC_EMPCode",new string('9',51))));
ExpectInvalid("An invalid date was accepted",StaffRow(("ATM_ID","X"),("CreatedDate","not a date")));
ExpectInvalid("An unknown column was accepted",StaffRow(("ATM_ID","X"),("Bogus","1")));
foreach(var dialect in new IDbDialect[]{new SqlServerDialect(),new PostgreSqlDialect(),new OracleDialect()}){
 foreach(var insert in new[]{true,false}){
  var (staffSql,staffArgs)=StaffCall<(string,List<DbArg>)>("BuildUpsert",dialect,insert,staffNormalized[0],"master.txt","maker1","checker1",new DateTime(2025,5,6,7,8,9,DateTimeKind.Utc));
  var named=System.Text.RegularExpressions.Regex.Matches(staffSql,@"[@:]v\d+").Count;
  Check(named==staffArgs.Count&&staffArgs.Select(a=>a.Name).Distinct().Count()==staffArgs.Count&&staffArgs.All(a=>a.Name.Length<=30),$"{dialect.Name}: Staff Mapping statement parameters do not line up");
  Check(insert==staffSql.StartsWith("INSERT INTO tbl_ATM_Txn_Mntr_MappingMaster(ATM_ID,")&&(insert||staffSql.Contains(" WHERE ATM_ID=")),$"{dialect.Name}: wrong Staff Mapping statement shape");
  var values=staffArgs.Select(a=>a.Value).ToList();
  Check(values.Contains("master.txt")&&values.Contains("checker1")&&values.Contains("Approved")&&values.Contains(insert?"maker1":"maker1"),$"{dialect.Name}: approval and upload details were not recorded");
  Check(insert==staffSql.Contains("CreatedDate")&&insert!=staffSql.Contains("ModifiedDate"),$"{dialect.Name}: created/modified columns are wrong for {(insert?"an insert":"an update")}");
 }
}
Console.WriteLine("PASS: Staff Mapping master has the documented headers and columns in every schema, a validated admin-editable mapping, strict row validation, and a typed upsert for every provider.");

// Navigation is stored in the database as a Menu > SubMenu > Child tree and filtered by role and permission.
var menuDefaults=MenuCatalog.Defaults;
Check(menuDefaults.Select(x=>x.Code).Distinct(StringComparer.OrdinalIgnoreCase).Count()==menuDefaults.Count,"Default menu codes must be unique");
Check(menuDefaults.Where(x=>x.ParentCode is not null).All(x=>menuDefaults.Any(p=>p.Code==x.ParentCode)),"A default menu entry points at a missing parent");
List<MenuNode> MenuNodes(){var ids=menuDefaults.Select((x,i)=>(x.Code,Id:(long)(i+1))).ToDictionary(x=>x.Code,x=>x.Id);return menuDefaults.Select(x=>new MenuNode{Id=ids[x.Code],ParentId=x.ParentCode is null?null:ids[x.ParentCode],Code=x.Code,Label=x.Label,Title=x.Title,Description=x.Description,Icon=x.Icon,ViewKey=x.ViewKey,PermissionCode=x.PermissionCode,DisplayOrder=x.DisplayOrder}).ToList();}
var adminMenu=MenuCatalog.Build(MenuNodes(),_=>true,"ADMIN");
var mastersMenu=adminMenu.Single(x=>x.Code=="masters");
var atmSubMenu=mastersMenu.Children.Single(x=>x.Code=="masters.atm");
Check(mastersMenu.View==""&&atmSubMenu.View==""&&atmSubMenu.Children.Select(x=>x.View).SequenceEqual(["atmStaffList"])&&atmSubMenu.Children[0].Label=="Staff Mapping","Masters > ATM > Staff Mapping is not a three-level menu");
Check(!menuDefaults.Any(x=>x.Code is "operations.atm" or "masters.atm.staffmaster"||x.ViewKey is "atm" or "atmStaffMaster")&&MenuCatalog.RetiredCodes.Contains("operations.atm")&&MenuCatalog.RetiredCodes.Contains("masters.atm.staffmaster"),"A retired menu entry (ATM Operations, Staff Master) is still seeded");
// An approver (ATM.CHECK only) reaches New / Upload Alerts; the permission list on a menu entry means "any of".
Check(MenuCatalog.Build(MenuNodes(),p=>p==CatsPermissions.AtmCheck,"DBOPS_CHECKER").Single(x=>x.Code=="workspace").Children.Any(x=>x.Code=="workspace.newalert")&&!MenuCatalog.Build(MenuNodes(),p=>p==CatsPermissions.AtmOperations,"RATC").Single(x=>x.Code=="workspace").Children.Any(x=>x.Code=="workspace.newalert"),"New / Upload Alerts must be visible to uploaders and ATM checkers only");
// Alert Types are limited by role and permission, so each module's types only show for its users.
var accessRules=AlertTypeAccess.Defaults;
bool TypeVisible(string code,string role,params string[] perms)=>AlertTypeAccess.IsVisible(accessRules,code,role,p=>perms.Contains(p));
Check(TypeVisible("ATM_ONUS","RATC",CatsPermissions.AtmOperations)&&TypeVisible("ATM_OFFUS","DBOPS_MAKER",CatsPermissions.AtmOperations)&&TypeVisible("ATM_ONUS","AUDITOR",CatsPermissions.AlertViewAll)&&!TypeVisible("ATM_ONUS","DT_USER")&&!TypeVisible("ATM_OFFUS","DT_CHECKER"),"ATM Alert Types are not limited to ATM users");
Check(TypeVisible("DT_DD_MONEY_MULE","DT_USER")&&TypeVisible("DT_DD_MONEY_MULE","CENTRAL")&&!TypeVisible("DT_DD_MONEY_MULE","RATC",CatsPermissions.AtmOperations)&&TypeVisible("GENERIC_ALERT","RATC")&&TypeVisible("UNLISTED_TYPE","ANY"),"Alert Type access by role is wrong, or an unrestricted type is hidden");
Check(AlertTypeAccess.SeesAll(p=>p==CatsPermissions.TemplateManage)&&AlertTypeAccess.SeesAll(p=>p==CatsPermissions.Admin)&&!AlertTypeAccess.SeesAll(p=>p==CatsPermissions.AtmOperations),"Only template managers and administrators should see every Alert Type");
Check(!AlertTypeAccess.IsVisible([new(){TemplateCode="X"}],"X","R",_=>true)&&AlertTypeAccess.IsVisible([new(){TemplateCode="X",RoleCode="R",PermissionCode="P"}],"X","r",p=>p=="P")&&!AlertTypeAccess.IsVisible([new(){TemplateCode="X",RoleCode="R",PermissionCode="P"}],"X","R",_=>false),"An access rule needs its role and permission to both match");
Check(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"db","sqlserver","schema.sql")).Contains("dbo.AlertTypeAccess"),"The Alert Type access table is missing from the schema");
Check(adminMenu.Select(x=>x.Code).SequenceEqual(["workspace","operations","reports","masters","design","administration"]),"Top-level menu order is wrong");
var reportsMenu=adminMenu.Single(x=>x.Code=="reports");
Check(reportsMenu.Children.Select(x=>x.Code).SequenceEqual(["reports.all","reports.atm"])&&reportsMenu.Children[1].View==""&&reportsMenu.Children[1].Children.Select(x=>x.View).SequenceEqual(["reports:ATM_ONUS","reports:ATM_OFFUS"])&&MenuCatalog.RetiredCodes.Contains("operations.reports")&&!menuDefaults.Any(x=>x.Code=="operations.reports"),"Reports must be a top-level menu with ATM as a sub menu");
Check(!MenuCatalog.Build(MenuNodes(),_=>false,"ATMC").Single(x=>x.Code=="reports").Children.Any(x=>x.Code=="reports.atm")&&MenuCatalog.Build(MenuNodes(),p=>p==CatsPermissions.AtmCaseManage,"RATC").Single(x=>x.Code=="reports").Children.Any(x=>x.Code=="reports.atm"),"ATM reports must only show for ATM users");
var admin2=adminMenu.Single(x=>x.Code=="administration");
Check(admin2.Children.Any(x=>x.View=="rolePermissions")&&!MenuCatalog.Build(MenuNodes(),p=>p=="SECURITY.MANAGE","X").Single(x=>x.Code=="administration").Children.Any(x=>x.View=="rolePermissions"),"The Role Permissions menu entry must depend on SECURITY.ROLEPERMISSIONS");
Check(RolePermissionRules.IsLocked("ADMIN","SECURITY.MANAGE")&&!RolePermissionRules.IsLocked("CENTRAL","SECURITY.MANAGE")&&RolePermissionRules.MissingRequired("ADMIN","CENTRAL",["ALERT.UPLOAD"]).Count==2&&RolePermissionRules.MissingRequired("CENTRAL","CENTRAL",["ALERT.UPLOAD"]).Single()=="SECURITY.ROLEPERMISSIONS"&&RolePermissionRules.MissingRequired("RATC","CENTRAL",[]).Count==0&&RolePermissionRules.MissingRequired("CENTRAL","ADMIN",[]).Count==0,"The role permission lock-out guard is wrong");
var makerPerms=new HashSet<string>{CatsPermissions.AtmOperations,CatsPermissions.AtmUpload,CatsPermissions.AtmMasterView};
var makerMenu=MenuCatalog.Build(MenuNodes(),makerPerms.Contains,"DBOPS_MAKER");
Check(makerMenu.Any(x=>x.Code=="masters")&&makerMenu.All(x=>x.Code is not ("design" or "administration"))&&!makerMenu.Single(x=>x.Code=="workspace").Children.Any(c=>c.Code=="workspace.newalert"),"The menu does not follow the user's permissions");
Check(!MenuCatalog.Build(MenuNodes(),p=>p==CatsPermissions.AtmOperations||p==CatsPermissions.AtmCaseManage,"RATC").Any(x=>x.Code=="masters"),"ATM roles without ATM.MASTER.VIEW (GH, RH, SH, RATC, ATMC) must not see Masters > ATM > Staff Mapping");
var plainMenu=MenuCatalog.Build(MenuNodes(),_=>false,"ATMC");
Check(plainMenu.Select(x=>x.Code).SequenceEqual(["workspace","operations","reports"])&&plainMenu.All(x=>x.Children.All(c=>c.Code is "workspace.dashboard" or "workspace.alerts" or "operations.ingestion" or "reports.all" or "operations.mail")),"A user without permissions sees restricted menu entries, or an empty module");
var restricted=MenuNodes();foreach(var restrictedNode in restricted.Where(x=>x.Code is "masters.atm.staffmapping" or "masters.atm.staffmaster"))restrictedNode.Roles=["DBOPS_MAKER"];
Check(!MenuCatalog.Build(restricted,_=>true,"ADMIN").Any(x=>x.Code=="masters")&&MenuCatalog.Build(restricted,_=>true,"dbops_maker").Any(x=>x.Code=="masters"),"A role restriction on a menu entry is not applied (and an emptied module must disappear)");
var extra=MenuNodes();extra.Add(new MenuNode{Id=9001,ParentId=extra.First(n=>n.Code=="masters").Id,Code="masters.hr",Label="HR",DisplayOrder=20});extra.Add(new MenuNode{Id=9002,ParentId=9001,Code="masters.hr.staff",Label="Staff",ViewKey="hrStaff",PermissionCode="HR.VIEW",DisplayOrder=10});
Check(MenuCatalog.Build(extra,_=>true,"ADMIN").Single(x=>x.Code=="masters").Children.Select(x=>x.Code).SequenceEqual(["masters.atm","masters.hr"])&&!MenuCatalog.Build(extra,p=>p!="HR.VIEW","ADMIN").Single(x=>x.Code=="masters").Children.Any(x=>x.Code=="masters.hr"),"A new module added to the menu table is not shown, ordered and permission-filtered");
Check(AtmStaffMappingColumns.Find("ATM_ID")is not null&&CatsPermissions.AtmMasterConfigure=="ATM.MASTER.CONFIGURE","The Staff Mapping configuration permission is missing");
foreach(var provider in new[]{"sqlserver","postgresql","oracle"}){
 var schemaText=File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"db",provider,"schema.sql"));
 Check(schemaText.Contains("MenuMaster")&&schemaText.Contains("MenuRoleMapping"),$"{provider} schema is missing the menu tables");
}
Console.WriteLine("PASS: Navigation is a database-driven Menu > SubMenu > Child tree filtered by role and permission; Masters > ATM > Staff Mapping opens the list page; new modules need only table rows.");

public class TemplateSaveFake:DispatchProxy {
 protected override object? Invoke(MethodInfo? method,object?[]? args)=>method!.Name switch {
  "SaveTemplateAsync"=>Save((SaveTemplateRequest)args![0]!),
  "InsertAuditAsync"=>Task.CompletedTask,
  _=>throw new NotSupportedException(method.Name)
 };
 static Task<TemplateRecord> Save(SaveTemplateRequest request)=>Task.FromResult(new TemplateRecord{
  Id=9,Code=request.Code,Name=request.Name,
  FieldsJson=JsonSerializer.Serialize(request.Fields,JsonDefaults.Options),
  ViewConfigurationJson=JsonSerializer.Serialize(request.ViewConfiguration,JsonDefaults.Options)});
}

public class RepoFake:DispatchProxy {
 public List<WorkItemRecord> WorkItems=[];
 public UserRecord User=new(){Id=1,UserName="tester",IsActive=true};
 public TemplateField Field=new(){Name="taxId",Sensitive=true};
 public List<AuditRecord> Audits=[];
 protected override object? Invoke(MethodInfo? method,object?[]? args)=>method!.Name switch {
  "GetUserByUserNameAsync"=>Task.FromResult<UserRecord?>(User),
  "GetAlertAsync"=>Task.FromResult<AlertRecord?>(new(){Id=1,TemplateId=2,BranchCode="B1",CustomerIdEncrypted="customer",DynamicDataJson="{\"taxId\":\"PRIVATE-1234\"}"}),
  "GetTemplateAsync"=>Task.FromResult<TemplateRecord?>(new(){Id=2,FieldsJson=JsonSerializer.Serialize(new[]{Field}),ViewConfigurationJson="{\"alertListFields\":[{\"field\":\"CUSTOMERNAME\",\"showInGrid\":true},{\"field\":\"taxId\",\"showInGrid\":true},{\"field\":\"__CustomerIdRaw\",\"showInGrid\":true}]}"}),
  "GetTemplateNameAsync"=>Task.FromResult("Test Template"),
  "GetWorkItemsAsync"=>Task.FromResult<IReadOnlyList<WorkItemRecord>>(WorkItems),
  "InsertAuditAsync"=>Audit((AuditRecord)args![0]!),
  _=>throw new NotSupportedException(method.Name)
 };
 Task Audit(AuditRecord record){Audits.Add(record);return Task.CompletedTask;}
}
public class Protector:IDataProtectorService {
 public string Protect(string value)=>value;
 public string Unprotect(string value)=>value;
 public string Mask(string value,int visibleTail=4)=>"***";
}

public class DashboardFake:DispatchProxy {
 protected override object? Invoke(MethodInfo? method,object?[]? args)=>method!.Name switch {
  "GetTemplateDashboardDataAsync"=>Task.FromResult(new TemplateDashboardDataResponse {
   Dashboard=new(){TemplateId=2},Page=1,PageSize=20,TotalRecords=1,
   Rows=[new(StringComparer.OrdinalIgnoreCase){["Id"]=1L,["CustomerName"]="Test Customer",["taxId"]="***",["Unconfigured"]="omit",["__CustomerIdRaw"]="omit"}]
  }),
  _=>throw new NotSupportedException(method.Name)
 };
}
