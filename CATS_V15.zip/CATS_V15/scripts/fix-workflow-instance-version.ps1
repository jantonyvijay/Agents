param([string]$AlertNo = 'ALT-A510828D')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$config = Get-Content (Join-Path $root 'src/CATS.Api/appsettings.json') -Raw | ConvertFrom-Json
$connection = New-Object System.Data.SqlClient.SqlConnection($config.Database.ConnectionString)
$connection.Open()
$transaction = $connection.BeginTransaction()
try {
    $command = $connection.CreateCommand()
    $command.Transaction = $transaction
    $module = [IO.File]::ReadAllText((Join-Path $root 'db/sqlserver/modules/17_WorkflowInstance.sql'))
    $command.CommandText = ($module -split '(?m)^GO\s*$' | Where-Object { $_ -match 'CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_Update\s' })
    [void]$command.ExecuteNonQuery()
    $command.CommandText = @'
DECLARE @Id varchar(32), @OldId varchar(32), @OldVersion int, @NewId varchar(32), @NewVersion int,
        @Stage varchar(100), @Status varchar(30), @AlertId varchar(32), @Definition nvarchar(max);
SELECT @Id=wi.Id,@OldId=wi.WorkflowDefinitionId,@OldVersion=wi.WorkflowVersion,
       @NewId=w.Id,@NewVersion=w.Version,@Stage=wi.CurrentStageId,@Status=wi.Status,
       @AlertId=a.Id,@Definition=w.DefinitionJson
FROM dbo.Alerts a JOIN dbo.WorkflowInstances wi WITH (UPDLOCK) ON wi.AlertId=a.Id
JOIN dbo.Templates t ON t.Id=a.TemplateId
JOIN dbo.WorkflowDefinitions w ON w.Id=t.PublishedWorkflowId AND w.IsPublished=1
WHERE a.AlertNo=@AlertNo AND wi.Status='Running';
IF @Id IS NULL THROW 50000, 'Running alert with a published workflow was not found.', 1;
IF NOT EXISTS (SELECT 1 FROM OPENJSON(@Definition,'$.stages') WITH (id varchar(100) '$.id') WHERE id=@Stage)
    THROW 50000, 'Current stage is absent from the published workflow.', 1;
IF @OldId<>@NewId OR @OldVersion<>@NewVersion
BEGIN
    DECLARE @Payload nvarchar(max)=(SELECT @Id id,@NewId workflowDefinitionId,@NewVersion workflowVersion,
        @Status status,@Stage currentStageId,SYSUTCDATETIME() updatedAtUtc FOR JSON PATH,WITHOUT_ARRAY_WRAPPER);
    EXEC dbo.USP_WorkflowInstance_Update @strJson=@Payload;
    IF NOT EXISTS (SELECT 1 FROM dbo.WorkflowInstances WHERE Id=@Id AND WorkflowDefinitionId=@NewId
        AND WorkflowVersion=@NewVersion AND CurrentStageId=@Stage AND Status=@Status)
        THROW 50000, 'Workflow version update verification failed.', 1;
    INSERT dbo.AuditLog(Id,AlertId,UserId,UserName,RoleCode,Action,EntityType,EntityId,StageId,
        PreviousValueJson,NewValueJson,Remarks,CreatedAtUtc)
    VALUES(REPLACE(CONVERT(varchar(36),NEWID()),'-',''),@AlertId,'system','system','SYSTEM',
        'WORKFLOW_CONFIGURATION_UPDATED','Alert',@AlertId,@Stage,
        (SELECT @OldId workflowDefinitionId,@OldVersion workflowVersion FOR JSON PATH,WITHOUT_ARRAY_WRAPPER),
        (SELECT @NewId workflowDefinitionId,@NewVersion workflowVersion FOR JSON PATH,WITHOUT_ARRAY_WRAPPER),
        'Repaired workflow version persistence; applied published configuration without changing stage or alert data.',SYSUTCDATETIME());
END;
SELECT WorkflowVersion FROM dbo.WorkflowInstances WHERE Id=@Id;
'@
    [void]$command.Parameters.AddWithValue('@AlertNo', $AlertNo)
    # The procedure emits an affected-row result before the verification result.
    $reader = $command.ExecuteReader()
    do { while ($reader.Read()) { Write-Output ($reader.GetName(0) + ': ' + $reader.GetValue(0)) } } while ($reader.NextResult())
    $reader.Close()
    $transaction.Commit()
    Write-Output 'PASS: procedure installed and published workflow version verified; stage and data preserved.'
} catch {
    $transaction.Rollback()
    throw
} finally {
    $connection.Dispose()
}
