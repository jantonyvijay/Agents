﻿const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '../src/CATS.App/wwwroot/js');

/** Load actual browser modules in an isolated context, optionally replacing boundary services. */
async function loadModules(entry, globals = {}, stubs = {}) {
    const context = vm.createContext({ console, URL, URLSearchParams, Headers, FormData, Blob, ...globals });
    const cache = new Map();
    function get(filename) {
        filename = path.resolve(filename);
        if (cache.has(filename)) return cache.get(filename);
        const key = path.relative(root, filename).replaceAll('\\', '/');
        const stub = stubs[key];
        const module = stub
            ? new vm.SyntheticModule(
                  Object.keys(stub),
                  function () {
                      for (const [name, value] of Object.entries(stub)) this.setExport(name, value);
                  },
                  { context, identifier: filename },
              )
            : new vm.SourceTextModule(fs.readFileSync(filename, 'utf8'), { context, identifier: filename });
        cache.set(filename, module);
        return module;
    }
    const module = get(path.resolve(root, entry));
    await module.link((specifier, parent) => get(path.resolve(path.dirname(parent.identifier), specifier)));
    await module.evaluate();
    return { exports: module.namespace, context, cache };
}
module.exports = { loadModules };
