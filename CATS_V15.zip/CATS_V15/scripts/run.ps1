﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$processes = @()
$services = @(
    @{ Name = 'API'; Project = 'CATS.Api'; Port = 7002 },
    @{ Name = 'UI'; Project = 'CATS.App'; Port = 7001 },
    @{ Name = 'Gateway'; Project = 'CATS.Gateway'; Port = 7000 },
    @{ Name = 'MCP server'; Project = 'CATS.McpServer'; Port = 9000 }
)

try {
    foreach ($service in $services) {
        $projectPath = Join-Path $root ('src\' + $service.Project + '\' + $service.Project + '.csproj')
        Write-Host ('Starting CATS ' + $service.Name + ' on http://127.0.0.1:' + $service.Port + ' ...')
        $processes += Start-Process dotnet -ArgumentList @(
            'run', '--project', ('"' + $projectPath + '"'), '-p:UseAppHost=false',
            '--urls', ('http://127.0.0.1:' + $service.Port)
        ) -WorkingDirectory $root -WindowStyle Hidden -PassThru
    }
    $processes.Id | Set-Content (Join-Path $PSScriptRoot '.cats-pids')
    Write-Host 'Open http://127.0.0.1:7000 after the services finish starting.' -ForegroundColor Green
    Write-Host 'Use scripts/stop.ps1 to stop these processes.'
}
catch {
    $processes | Where-Object { -not $_.HasExited } | Stop-Process -Force -ErrorAction SilentlyContinue
    throw
}
