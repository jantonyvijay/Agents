const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');

(async () => {
    const { exports: logic } = await loadModules('modules/business/workflow-logic.js');
    const roles = ['DT_USER', 'DT_CHECKER', 'DT_VERIFIER'];
    // Results come from another VM realm, so compare plain copies.
    const plain = (value) => JSON.parse(JSON.stringify(value));

    assert.equal(logic.slugify('  Checker Review (L1)! '), 'checker_review_l1');
    assert.deepEqual(
        JSON.parse(JSON.stringify(logic.parseTransitions('Submit:review\nApprove:END\nReject:'))),
        [
            { action: 'Submit', toStageId: 'review' },
            { action: 'Approve', toStageId: null },
            { action: 'Reject', toStageId: null },
        ],
    );
    assert.equal(logic.transitionsToText([{ action: 'Approve', toStageId: null }, { action: 'Return', toStageId: 'maker' }]), 'Approve:END\nReturn:maker');

    for (const kind of ['single', 'maker_checker', 'maker_checker_verifier']) {
        const flow = logic.presetWorkflow(kind, roles);
        const problems = plain(logic.validateWorkflow(flow, roles));
        assert.deepEqual(problems, [], `${kind} preset should be ready to save: ${JSON.stringify(problems)}`);
        assert.ok(logic.workflowSummary(flow)[0].start, `${kind} summary starts at the start step`);
    }
    const mc = logic.presetWorkflow('maker_checker', roles);
    assert.equal(mc.stages.find((s) => s.id === 'maker').roleCode, 'DT_USER');
    assert.equal(mc.stages.find((s) => s.id === 'checker').roleCode, 'DT_CHECKER');
    // Unknown roles leave the role blank and only produce a warning, never a blocking error.
    const noRoles = logic.validateWorkflow(logic.presetWorkflow('maker_checker', []), []);
    assert.ok(noRoles.length && noRoles.every((p) => p.level === 'warn'));

    const broken = {
        startStageId: '',
        stages: [
            { id: 'a', name: 'A', type: 'Human', roleCode: 'DT_USER', allowedActions: ['Submit', 'Approve'], transitions: [{ action: 'Submit', toStageId: 'gone' }] },
            { id: 'orphan', name: 'Orphan', type: 'Human', roleCode: 'DT_USER', allowedActions: [], transitions: [] },
        ],
    };
    const messages = logic.validateWorkflow(broken, roles).map((p) => p.text).join('|');
    assert.match(messages, /Choose which step alerts start/);
    assert.match(messages, /"Approve" button on "A" does not lead anywhere/);
    assert.match(messages, /goes to a step that no longer exists/);
    assert.match(messages, /no buttons/);
    assert.match(messages, /No step finishes the alert/);
    assert.deepEqual(plain(logic.validateWorkflow({ stages: [] }, roles)).map((p) => p.level), ['error']);

    const routing = {
        startStageId: 'route',
        stages: [
            { id: 'route', name: 'Route', type: 'Condition', conditions: [{ field: 'Amount', operator: 'gt', value: '100', toStageId: 'big' }], defaultNextStageId: 'small', transitions: [] },
            { id: 'big', name: 'Big', type: 'End', endStatus: 'Closed' },
            { id: 'small', name: 'Small', type: 'End', endStatus: 'Closed' },
        ],
    };
    assert.deepEqual(plain(logic.validateWorkflow(routing, roles)), []);
    assert.match(logic.workflowSummary(routing)[0].text, /Amount is greater than "100" go to Big; otherwise go to Small/);
    assert.deepEqual(plain(logic.orderedStages(routing)).map((s) => s.id), ['route', 'big', 'small']);
    console.log('PASS: workflow ids, transitions, presets, plain-English summary and checklist rules.');

    const { exports: tpl } = await loadModules('modules/business/template-logic.js');
    assert.equal(tpl.fieldCodeFromLabel('Account no.', []), 'AccountNo');
    assert.equal(tpl.fieldCodeFromLabel('Account no', ['accountno']), 'AccountNo2');
    assert.equal(tpl.fieldCodeFromLabel('2nd name', []), 'Field2ndName');
    assert.equal(tpl.moduleCodeFromName('Cheque Return (Review)'), 'CHEQUE_RETURN_REVIEW');
    const draft = {
        code: 'X', name: 'X',
        sections: [{ id: 's1', name: 'A' }, { id: 's2', name: 'Empty' }],
        fields: [
            { name: 'A', label: 'A', sectionId: 's1', type: 'text' },
            { name: 'a', label: 'Dup', sectionId: 's1', type: 'text' },
            { name: 'L', label: 'List', sectionId: 's1', type: 'select', optionsJson: '[]', dataSourceMode: 'Static' },
            { name: 'O', label: 'Orphan', sectionId: 'gone', type: 'text' },
        ],
    };
    const texts = plain(tpl.templateChecklist(draft)).map((p) => `${p.level}:${p.text}`).join('|');
    assert.match(texts, /error:Two fields share the code/);
    assert.match(texts, /error:"List" is a list but has no choices/);
    assert.match(texts, /error:"Orphan" is not in any section/);
    assert.match(texts, /warn:Section "Empty" has no fields yet/);
    assert.deepEqual(plain(tpl.templateChecklist({ code: 'X', name: 'X', sections: [{ id: 's', name: 'S' }], fields: [{ name: 'F', label: 'F', sectionId: 's', type: 'text' }] })), []);
    console.log('PASS: template checklist and field/module codes.');

    const { exports: mod } = await loadModules('modules/business/module-wizard-logic.js');
    const wz = {
        name: 'Cheque Return', code: 'CHEQUE_RETURN', sectionName: 'Details',
        questions: [{ label: 'Cheque number', type: 'text', required: true }, { label: 'Reason', type: 'select', choices: 'Funds, Signature' }, { label: '  ' }],
        flow: 'maker_checker', roles: { maker: 'DT_USER', checker: 'DT_CHECKER' }, everyone: false, accessRoles: ['DT_USER', 'DT_CHECKER'],
    };
    assert.equal(mod.validateWizardStep(wz, 1), null);
    assert.equal(mod.validateWizardStep({ ...wz, name: '' }, 1), 'Type a name for the module.');
    assert.equal(mod.validateWizardStep({ ...wz, questions: [{ label: 'Pick', type: 'select', choices: '' }] }, 2), 'Type the choices for "Pick" (separate them with commas).');
    assert.match(mod.validateWizardStep({ ...wz, roles: { maker: 'DT_USER' } }, 3), /Who approves it/);
    assert.match(mod.validateWizardStep({ ...wz, accessRoles: [] }, 4), /Tick at least one role/);
    const made = plain(mod.buildModule(wz, ['DT_USER', 'DT_CHECKER']));
    assert.equal(made.template.code, 'CHEQUE_RETURN');
    assert.deepEqual(made.template.fields.map((f) => f.name), ['ChequeNumber', 'Reason']);
    assert.equal(made.template.fields[0].required, true);
    assert.equal(made.template.fields[1].optionsJson, '["Funds","Signature"]');
    assert.ok(made.template.fields.every((f) => f.sectionId === made.template.sections[0].id));
    assert.equal(made.workflow.definition.stages.find((s) => s.id === 'checker').roleCode, 'DT_CHECKER');
    assert.deepEqual(plain(logic.validateWorkflow(made.workflow.definition, ['DT_USER', 'DT_CHECKER'])), []);
    assert.deepEqual(made.access, { everyone: false, roles: ['DT_USER', 'DT_CHECKER'] });
    console.log('PASS: New Module wizard validation and request building.');
})().catch((error) => {
    console.error(error);
    process.exit(1);
});
