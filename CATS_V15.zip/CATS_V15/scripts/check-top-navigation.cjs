const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');
(async () => {
 const { exports: nav } = await loadModules('modules/ui/top-navigation.js', {}, { 'modules/core/state.js': { state: { user: null } }, 'modules/core/utils.js': { esc: value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('"', '&quot;') } });
 const all = nav.getTopNavigationGroups(() => true);
 assert.equal(all.length, 4);
 assert.equal(all.flatMap(g => g.items).length, 11);
 const restricted = nav.getTopNavigationGroups(() => false);
 assert.deepEqual(Array.from(restricted, g => g.id), ['workspace', 'operations']);
 assert.equal(restricted.flatMap(g => g.items).length, 5);
 const html = nav.topNavigationHtml(restricted);
 for (const view of ['newAlert', 'atm', 'templates', 'workflow', 'admin', 'mcp']) assert.ok(!html.includes(`data-view="${view}"`));
 for (const group of all) for (const item of group.items) assert.ok(nav.topNavigationHtml(all).includes(`data-view="${item.view}"`));
 assert.equal(nav.getTopNavigationGroups(() => true).flatMap(g => g.items).length, 11);
 console.log('PASS: all navigation destinations retained; restricted items and empty groups omitted without mutating configuration.');
})().catch(error => { console.error(error); process.exitCode = 1; });
