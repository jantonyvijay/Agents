const assert = require('node:assert/strict');
const { loadModules } = require('./js-module-harness.cjs');
(async () => {
    const { exports: preview } = await loadModules('modules/ui/template-preview.js', {
        structuredClone,
        $: () => ({ text(value) { return { html: () => String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;') }; } }),
    }, {
        'modules/ui/appearance.js': { getSectionLayout: () => ({}) },
        'modules/events/forms.js': { bindConfiguredFields() {} },
    });
    const draft = {
        sections: [{ id: 's1', name: 'Penalty details', order: 1 }],
        fields: [
            { name: 'amount', label: 'Amount', sectionId: 's1', type: 'number', required: true },
            { name: 'vendor', label: 'Vendor', sectionId: 's1', type: 'select', dataSourceMode: 'API', defaultValue: 'production-value' },
            { name: 'private', label: 'Private', sectionId: 's1', type: 'text', sensitive: true, defaultValue: 'secret-default' },
        ],
        viewConfiguration: { layoutMode: 'Single' },
    };
    for (const [mode, marker] of [['Single','section-box'],['Tab','tab-pane'],['Accordion','accordion'],['Wizard','cats-wizard'],['Popup','cats-template-popup']]) {
        draft.viewConfiguration.layoutMode = mode;
        const before = JSON.stringify(draft);
        const html = preview.templatePreviewHtml(draft);
        assert.ok(html.includes(marker), mode);
        assert.ok(html.includes('preview-dynamic-field'));
        assert.ok(html.includes('aria-required="true"'));
        assert.ok(html.includes('Preview option'));
        assert.ok(!html.includes('cats-api-select'));
        assert.ok(!html.includes('production-value') && !html.includes('secret-default'));
        assert.equal(JSON.stringify(draft), before);
    }
    console.log('PASS: five preview layouts, required controls, local dropdowns, sensitive defaults omitted, draft preserved.');
})().catch((error) => { console.error(error); process.exitCode = 1; });
