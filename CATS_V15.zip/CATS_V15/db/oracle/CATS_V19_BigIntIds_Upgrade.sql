/* =====================================================================================
   CATS V19 - Convert GUID VARCHAR2(32) identifiers to NUMBER(19) (Oracle 12c or later)

   NOT YET TESTED against an Oracle server - rehearse it on a copy of your schema first.
   Oracle commits DDL implicitly, so this script cannot roll back: take a full backup before running it.

   Same behaviour as db/sqlserver/CATS_V19_BigIntIds_Upgrade.sql:
   - creates sequence SEQ_CATS_ID (every new id comes from it);
   - adds a numeric Id to every table that used a GUID Id and keeps the old GUID in LEGACYGUID (unique);
   - converts every referencing column through LEGACYGUID and drops the old VARCHAR2 columns;
   - recreates the primary keys, unique constraints, indexes and foreign keys that touch those columns;
   - rewrites the user ids embedded in JSON (_assignments.<stage>.userId, targetUserId);
   - is re-runnable (nothing happens when ALERTS.ID is already numeric).

   Stop CATS before running. Run it as the schema owner (SQL*Plus / SQLcl).
   ===================================================================================== */
SET SERVEROUTPUT ON
DECLARE
    TYPE t_names IS TABLE OF VARCHAR2(128);
    pk_tables t_names := t_names('AGINGBUCKETS','ALERTQUERIES','ALERTS','ALERTTYPEACCESS','ATM_REOPENREQUESTS',
        'ATM_UPLOADBATCHES','ATTACHMENTS','AUDITLOG','CATSUSERS','DASHBOARDWIDGETMASTER','DATASCOPEMASTER',
        'INGESTIONCONFIGURATION','INGESTIONCONNECTOR','INGESTIONRUN','MAILCONFIGURATION','MAILQUEUE','MAILTEMPLATE',
        'MENUMASTER','TEMPLATEDASHBOARDMASTER','TEMPLATES','WORKFLOWDEFINITIONS','WORKFLOWINSTANCES','WORKITEMS');
    TYPE t_col IS RECORD (tbl VARCHAR2(128), col VARCHAR2(128), ref VARCHAR2(128), is_pk BOOLEAN, nullable BOOLEAN);
    TYPE t_cols IS TABLE OF t_col INDEX BY PLS_INTEGER;
    cols t_cols;
    TYPE t_ddl IS RECORD (kind NUMBER, tbl VARCHAR2(128), name VARCHAR2(128), stmt VARCHAR2(4000));
    TYPE t_ddls IS TABLE OF t_ddl INDEX BY PLS_INTEGER;
    ddls t_ddls;
    n PLS_INTEGER := 0;
    base NUMBER := 0;
    cnt NUMBER;
    ord_col VARCHAR2(128);
    ord_expr VARCHAR2(300);
    v_sql VARCHAR2(4000);

    FUNCTION table_exists(p_table VARCHAR2) RETURN BOOLEAN IS
        c NUMBER;
    BEGIN
        SELECT COUNT(*) INTO c FROM user_tables WHERE table_name = p_table;
        RETURN c > 0;
    END;

    FUNCTION is_affected(p_table VARCHAR2, p_col VARCHAR2) RETURN BOOLEAN IS
    BEGIN
        FOR i IN 1 .. n LOOP
            IF cols(i).tbl = p_table AND cols(i).col = p_col THEN RETURN TRUE; END IF;
        END LOOP;
        RETURN FALSE;
    END;

    FUNCTION is_affected_table(p_table VARCHAR2) RETURN BOOLEAN IS
    BEGIN
        FOR i IN 1 .. n LOOP
            IF cols(i).tbl = p_table THEN RETURN TRUE; END IF;
        END LOOP;
        RETURN FALSE;
    END;

    PROCEDURE add_ref(p_table VARCHAR2, p_col VARCHAR2, p_ref VARCHAR2, p_pk BOOLEAN) IS
        c NUMBER;
        v_null VARCHAR2(1);
    BEGIN
        SELECT COUNT(*), MAX(nullable) INTO c, v_null FROM user_tab_columns
        WHERE table_name = p_table AND column_name = p_col AND data_type = 'VARCHAR2';
        IF c = 1 THEN
            n := n + 1;
            cols(n).tbl := p_table; cols(n).col := p_col; cols(n).ref := p_ref; cols(n).is_pk := p_pk; cols(n).nullable := (v_null = 'Y');
        END IF;
    END;

    FUNCTION col_list(p_constraint VARCHAR2) RETURN VARCHAR2 IS
        r VARCHAR2(4000);
    BEGIN
        FOR k IN (SELECT column_name FROM user_cons_columns WHERE constraint_name = p_constraint ORDER BY position) LOOP
            r := r || CASE WHEN r IS NULL THEN '' ELSE ',' END || k.column_name;
        END LOOP;
        RETURN r;
    END;

    FUNCTION touches_affected(p_constraint VARCHAR2, p_table VARCHAR2) RETURN BOOLEAN IS
    BEGIN
        FOR k IN (SELECT column_name FROM user_cons_columns WHERE constraint_name = p_constraint) LOOP
            IF is_affected(p_table, k.column_name) THEN RETURN TRUE; END IF;
        END LOOP;
        RETURN FALSE;
    END;

    PROCEDURE keep(p_kind NUMBER, p_tbl VARCHAR2, p_name VARCHAR2, p_stmt VARCHAR2) IS
        i PLS_INTEGER := ddls.COUNT + 1;
    BEGIN
        ddls(i).kind := p_kind; ddls(i).tbl := p_tbl; ddls(i).name := p_name; ddls(i).stmt := p_stmt;
    END;
BEGIN
    IF NOT table_exists('ALERTS') THEN
        DBMS_OUTPUT.PUT_LINE('CATS V19: ALERTS does not exist - nothing to migrate.');
        RETURN;
    END IF;
    SELECT COUNT(*) INTO cnt FROM user_tab_columns WHERE table_name = 'ALERTS' AND column_name = 'ID' AND data_type = 'NUMBER';
    IF cnt > 0 THEN
        DBMS_OUTPUT.PUT_LINE('CATS V19: identifiers are already numeric - nothing to do.');
        RETURN;
    END IF;

    /* ---------- 1. Which tables/columns are converted ---------- */
    FOR i IN 1 .. pk_tables.COUNT LOOP
        IF table_exists(pk_tables(i)) THEN add_ref(pk_tables(i), 'ID', NULL, TRUE); END IF;
    END LOOP;
    FOR r IN (
        SELECT 'ALERTMODULERECORDS' t, 'ALERTID' c, 'ALERTS' p FROM dual UNION ALL
        SELECT 'ALERTQUERIES','ALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'ALERTS','TEMPLATEID','TEMPLATES' FROM dual UNION ALL
        SELECT 'ATM_MASTERENTRIES','SOURCEBATCHID','ATM_UPLOADBATCHES' FROM dual UNION ALL
        SELECT 'ATM_REOPENREQUESTS','ORIGINALALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'ATM_REOPENREQUESTS','REQUESTBATCHID','ATM_UPLOADBATCHES' FROM dual UNION ALL
        SELECT 'ATM_REOPENREQUESTS','NEWALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'ATTACHMENTS','ALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'AUDITLOG','ALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'AUDITLOG','USERID','CATSUSERS' FROM dual UNION ALL
        SELECT 'DASHBOARDWIDGETROLEMAPPING','WIDGETID','DASHBOARDWIDGETMASTER' FROM dual UNION ALL
        SELECT 'INGESTIONCONFIGURATION','TEMPLATEID','TEMPLATES' FROM dual UNION ALL
        SELECT 'INGESTIONCONFIGURATION','CONNECTORID','INGESTIONCONNECTOR' FROM dual UNION ALL
        SELECT 'INGESTIONRUN','CONFIGURATIONID','INGESTIONCONFIGURATION' FROM dual UNION ALL
        SELECT 'INGESTIONSTAGING','RUNID','INGESTIONRUN' FROM dual UNION ALL
        SELECT 'INGESTIONSTAGING','TEMPLATEID','TEMPLATES' FROM dual UNION ALL
        SELECT 'MAILQUEUE','ALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'MAILTEMPLATE','TEMPLATEID','TEMPLATES' FROM dual UNION ALL
        SELECT 'MENUMASTER','PARENTID','MENUMASTER' FROM dual UNION ALL
        SELECT 'MENUROLEMAPPING','MENUID','MENUMASTER' FROM dual UNION ALL
        SELECT 'TBL_ATM_TXN_MNTR_OFFUS','ALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'TBL_ATM_TXN_MNTR_OFFUS','SOURCEBATCHID','ATM_UPLOADBATCHES' FROM dual UNION ALL
        SELECT 'TBL_ATM_TXN_MNTR_OFFUS','REOPENEDFROMALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'TBL_ATM_TXN_MNTR_ONUS','ALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'TBL_ATM_TXN_MNTR_ONUS','SOURCEBATCHID','ATM_UPLOADBATCHES' FROM dual UNION ALL
        SELECT 'TBL_ATM_TXN_MNTR_ONUS','REOPENEDFROMALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'TEMPLATEDASHBOARDMASTER','TEMPLATEID','TEMPLATES' FROM dual UNION ALL
        SELECT 'TEMPLATEDASHBOARDROLEMAPPING','DASHBOARDID','TEMPLATEDASHBOARDMASTER' FROM dual UNION ALL
        SELECT 'TEMPLATES','PUBLISHEDWORKFLOWID','WORKFLOWDEFINITIONS' FROM dual UNION ALL
        SELECT 'USERPERMISSIONMAPPING','USERID','CATSUSERS' FROM dual UNION ALL
        SELECT 'WORKFLOWDEFINITIONS','TEMPLATEID','TEMPLATES' FROM dual UNION ALL
        SELECT 'WORKFLOWINSTANCES','ALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'WORKFLOWINSTANCES','WORKFLOWDEFINITIONID','WORKFLOWDEFINITIONS' FROM dual UNION ALL
        SELECT 'WORKITEMS','ALERTID','ALERTS' FROM dual UNION ALL
        SELECT 'WORKITEMS','WORKFLOWINSTANCEID','WORKFLOWINSTANCES' FROM dual UNION ALL
        SELECT 'WORKITEMS','ASSIGNEDUSERID','CATSUSERS' FROM dual) LOOP
        IF table_exists(r.p) AND is_affected(r.p, 'ID') THEN add_ref(r.t, r.c, r.p, FALSE); END IF;
    END LOOP;

    /* ---------- 2. Remember and drop the constraints / indexes that touch those columns ---------- */
    FOR k IN (SELECT constraint_name, table_name, constraint_type, r_constraint_name, delete_rule FROM user_constraints
              WHERE constraint_type IN ('P', 'U', 'R') ORDER BY CASE constraint_type WHEN 'R' THEN 0 ELSE 1 END) LOOP
        IF k.constraint_type = 'R' THEN
            DECLARE
                v_rt VARCHAR2(128);
            BEGIN
                SELECT table_name INTO v_rt FROM user_constraints WHERE constraint_name = k.r_constraint_name;
                IF is_affected_table(k.table_name) OR is_affected_table(v_rt) THEN
                    keep(3, k.table_name, k.constraint_name,
                         'ALTER TABLE ' || k.table_name || ' ADD CONSTRAINT ' ||
                         CASE WHEN k.constraint_name LIKE 'SYS\_%' ESCAPE '\' THEN SUBSTR('FK_' || k.table_name || '_' || col_list(k.constraint_name), 1, 30) ELSE k.constraint_name END ||
                         ' FOREIGN KEY (' || col_list(k.constraint_name) || ') REFERENCES ' || v_rt || ' (' || col_list(k.r_constraint_name) || ')' ||
                         CASE WHEN k.delete_rule = 'CASCADE' THEN ' ON DELETE CASCADE' WHEN k.delete_rule = 'SET NULL' THEN ' ON DELETE SET NULL' ELSE '' END);
                    EXECUTE IMMEDIATE 'ALTER TABLE ' || k.table_name || ' DROP CONSTRAINT ' || k.constraint_name;
                END IF;
            END;
        ELSIF is_affected_table(k.table_name) AND touches_affected(k.constraint_name, k.table_name) THEN
            keep(1, k.table_name, k.constraint_name,
                 'ALTER TABLE ' || k.table_name || ' ADD CONSTRAINT ' ||
                 CASE WHEN k.constraint_name LIKE 'SYS\_%' ESCAPE '\' THEN SUBSTR(CASE k.constraint_type WHEN 'P' THEN 'PK_' ELSE 'UQ_' END || k.table_name, 1, 30) ELSE k.constraint_name END ||
                 CASE k.constraint_type WHEN 'P' THEN ' PRIMARY KEY (' ELSE ' UNIQUE (' END || col_list(k.constraint_name) || ')');
            EXECUTE IMMEDIATE 'ALTER TABLE ' || k.table_name || ' DROP CONSTRAINT ' || k.constraint_name;
        END IF;
    END LOOP;
    FOR i IN (SELECT index_name, table_name, uniqueness FROM user_indexes
              WHERE index_type = 'NORMAL' AND NOT EXISTS (SELECT 1 FROM user_constraints c WHERE c.index_name = user_indexes.index_name)) LOOP
        IF is_affected_table(i.table_name) THEN
            DECLARE
                v_touch BOOLEAN := FALSE;
                v_cols VARCHAR2(4000);
            BEGIN
                FOR c IN (SELECT column_name FROM user_ind_columns WHERE index_name = i.index_name ORDER BY column_position) LOOP
                    v_cols := v_cols || CASE WHEN v_cols IS NULL THEN '' ELSE ',' END || c.column_name;
                    IF is_affected(i.table_name, c.column_name) THEN v_touch := TRUE; END IF;
                END LOOP;
                IF v_touch THEN
                    keep(2, i.table_name, i.index_name,
                         'CREATE ' || CASE WHEN i.uniqueness = 'UNIQUE' THEN 'UNIQUE ' ELSE '' END || 'INDEX ' || i.index_name ||
                         ' ON ' || i.table_name || ' (' || v_cols || ')');
                    EXECUTE IMMEDIATE 'DROP INDEX ' || i.index_name;
                END IF;
            END;
        END IF;
    END LOOP;

    /* ---------- 3. New numeric key + LEGACYGUID on every GUID table (chronological per table) ---------- */
    FOR i IN 1 .. n LOOP
        IF cols(i).is_pk THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || cols(i).tbl || ' ADD (LEGACYGUID VARCHAR2(32), ID_N NUMBER(19))';
            EXECUTE IMMEDIATE 'UPDATE ' || cols(i).tbl || ' SET LEGACYGUID = ID';
            ord_col := NULL;
            BEGIN
                SELECT column_name INTO ord_col FROM (
                    SELECT column_name FROM user_tab_columns
                    WHERE table_name = cols(i).tbl AND column_name IN ('CREATEDATUTC', 'RAISEDATUTC', 'UPLOADEDATUTC', 'STARTEDATUTC')
                    ORDER BY CASE column_name WHEN 'CREATEDATUTC' THEN 1 WHEN 'RAISEDATUTC' THEN 2 WHEN 'UPLOADEDATUTC' THEN 3 ELSE 4 END)
                WHERE ROWNUM = 1;
            EXCEPTION WHEN NO_DATA_FOUND THEN ord_col := NULL;
            END;
            ord_expr := CASE WHEN ord_col IS NULL THEN 'ID' ELSE ord_col || ', ID' END;
            EXECUTE IMMEDIATE 'UPDATE ' || cols(i).tbl || ' x SET ID_N = :b + (SELECT rn FROM (SELECT ROWID rid, ROW_NUMBER() OVER (ORDER BY ' ||
                              ord_expr || ') rn FROM ' || cols(i).tbl || ') s WHERE s.rid = x.ROWID)' USING base;
            EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || cols(i).tbl INTO cnt;
            base := base + cnt;
        END IF;
    END LOOP;

    /* ---------- 4. Referencing columns follow through LEGACYGUID ---------- */
    FOR i IN 1 .. n LOOP
        IF NOT cols(i).is_pk THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || cols(i).tbl || ' ADD (' || cols(i).col || '_N NUMBER(19))';
            EXECUTE IMMEDIATE 'UPDATE ' || cols(i).tbl || ' c SET ' || cols(i).col || '_N = (SELECT p.ID_N FROM ' || cols(i).ref ||
                              ' p WHERE p.LEGACYGUID = c.' || cols(i).col || ')';
        END IF;
    END LOOP;

    -- A reopen request stores its own id as REQUESTBATCHID, so it may not match an upload batch: fall back to itself.
    IF is_affected('ATM_REOPENREQUESTS', 'REQUESTBATCHID') THEN
        EXECUTE IMMEDIATE 'UPDATE ATM_REOPENREQUESTS r SET REQUESTBATCHID_N = COALESCE(r.REQUESTBATCHID_N, ' ||
                          '(SELECT p.ID_N FROM ATM_REOPENREQUESTS p WHERE p.LEGACYGUID = r.REQUESTBATCHID), r.ID_N)';
    END IF;

    -- Orphans: nullable columns become NULL; failed-login audit rows get user 0; a template-specific mail template whose
    -- Template no longer exists is dead data; other rows without a parent are removed.
    FOR i IN 1 .. n LOOP
        IF NOT cols(i).is_pk THEN
            IF cols(i).tbl = 'AUDITLOG' AND cols(i).col = 'USERID' THEN
                EXECUTE IMMEDIATE 'UPDATE AUDITLOG SET USERID_N = 0 WHERE USERID_N IS NULL';
            ELSIF NOT cols(i).nullable OR (cols(i).tbl = 'MAILTEMPLATE' AND cols(i).col = 'TEMPLATEID') THEN
                v_sql := 'DELETE FROM ' || cols(i).tbl || ' WHERE ' || cols(i).col || '_N IS NULL AND ' ||
                         CASE WHEN cols(i).nullable THEN cols(i).col || ' IS NOT NULL' ELSE '1 = 1' END;
                EXECUTE IMMEDIATE v_sql;
                IF SQL%ROWCOUNT > 0 THEN
                    DBMS_OUTPUT.PUT_LINE('WARNING: removed ' || SQL%ROWCOUNT || ' orphan row(s) from ' || cols(i).tbl || ' (' || cols(i).col || ' has no matching parent).');
                END IF;
            END IF;
        END IF;
    END LOOP;

    /* ---------- 5. Swap the new columns in ---------- */
    FOR i IN 1 .. n LOOP
        EXECUTE IMMEDIATE 'ALTER TABLE ' || cols(i).tbl || ' DROP COLUMN ' || cols(i).col;
        EXECUTE IMMEDIATE 'ALTER TABLE ' || cols(i).tbl || ' RENAME COLUMN ' || cols(i).col || '_N TO ' || cols(i).col;
        IF NOT cols(i).nullable THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || cols(i).tbl || ' MODIFY (' || cols(i).col || ' NOT NULL)';
        END IF;
    END LOOP;

    /* ---------- 6. Recreate keys, indexes, foreign keys; sequence default; LEGACYGUID lookup ---------- */
    BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_cats_id'; EXCEPTION WHEN OTHERS THEN IF SQLCODE != -2289 THEN RAISE; END IF; END;
    EXECUTE IMMEDIATE 'CREATE SEQUENCE seq_cats_id START WITH ' || (base + 1) || ' INCREMENT BY 100 CACHE 100';
    FOR kind IN 1 .. 3 LOOP
        FOR i IN 1 .. ddls.COUNT LOOP
            IF ddls(i).kind = kind THEN EXECUTE IMMEDIATE ddls(i).stmt; END IF;
        END LOOP;
    END LOOP;
    FOR i IN 1 .. n LOOP
        IF cols(i).is_pk THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || cols(i).tbl || ' MODIFY (ID DEFAULT seq_cats_id.NEXTVAL)';
            EXECUTE IMMEDIATE 'CREATE UNIQUE INDEX ' || SUBSTR('UX_' || cols(i).tbl || '_LG', 1, 30) || ' ON ' || cols(i).tbl || ' (LEGACYGUID)';
        END IF;
    END LOOP;

    /* ---------- 7. JSON documents that embed user ids ---------- */
    IF table_exists('CATSUSERS') THEN
        FOR u IN (SELECT ID, LEGACYGUID FROM CATSUSERS WHERE LEGACYGUID IS NOT NULL) LOOP
            IF table_exists('ALERTMODULERECORDS') THEN
                UPDATE ALERTMODULERECORDS
                SET DATAJSON = REPLACE(REPLACE(DATAJSON, '"userId":"' || u.LEGACYGUID || '"', '"userId":' || u.ID),
                                       '"userId": "' || u.LEGACYGUID || '"', '"userId": ' || u.ID)
                WHERE DATAJSON LIKE '%' || u.LEGACYGUID || '%';
            END IF;
            IF table_exists('TEMPLATES') THEN
                UPDATE TEMPLATES
                SET ASSIGNMENTRULESJSON = REPLACE(REPLACE(ASSIGNMENTRULESJSON, '"targetUserId":"' || u.LEGACYGUID || '"', '"targetUserId":' || u.ID),
                                                  '"targetUserId": "' || u.LEGACYGUID || '"', '"targetUserId": ' || u.ID)
                WHERE ASSIGNMENTRULESJSON LIKE '%' || u.LEGACYGUID || '%';
            END IF;
        END LOOP;
    END IF;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('CATS V19 completed.');
END;
/
