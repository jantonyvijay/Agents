DECLARE
    PROCEDURE add_column(p_definition VARCHAR2) IS
    BEGIN
        EXECUTE IMMEDIATE 'ALTER TABLE TBL_ATM_TXN_MNTR_ONUS ADD (' || p_definition || ')';
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE != -1430 THEN RAISE; END IF;
    END;
BEGIN
    add_column('ATMC_STATUS VARCHAR2(10)');
    add_column('ATMC_REMARK CLOB');
    add_column('RATC_STATUS VARCHAR2(10)');
    add_column('RATC_REMARK CLOB');
    add_column('SH_STATUS VARCHAR2(10)');
    add_column('SH_REMARK CLOB');
    add_column('RECOVERABLE_TYPE VARCHAR2(100)');
    add_column('RECOVERABLE_VENDORNAME VARCHAR2(100)');
    add_column('NOPENALTYAPPLICABLE NUMBER(1)');
    add_column('EXCESS_REPORTED VARCHAR2(10)');
    add_column('EXCESS_DATE TIMESTAMP');
    add_column('RECOVERY_REASON VARCHAR2(250)');
    add_column('MAILDATE TIMESTAMP');
    add_column('RECOVERYREASON_REMARK CLOB');
    add_column('FOURWAYRECONCILITION NUMBER(1)');
    add_column('RH_STATUS CLOB');
    add_column('RH_REMARK CLOB');
    add_column('GH_STATUS CLOB');
    add_column('GH_REMARK CLOB');
END;
/
