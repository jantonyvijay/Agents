DECLARE
    PROCEDURE add_column(p_table VARCHAR2, p_definition VARCHAR2) IS
    BEGIN
        EXECUTE IMMEDIATE 'ALTER TABLE ' || p_table || ' ADD (' || p_definition || ')';
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE != -1430 THEN RAISE; END IF;
    END;
BEGIN
    add_column('TBL_ATM_TXN_MNTR_OFFUS', 'RECORDSTATUS VARCHAR2(250)');
    add_column('TBL_ATM_TXN_MNTR_OFFUS', 'APPROVEDBY VARCHAR2(100)');
    add_column('TBL_ATM_TXN_MNTR_OFFUS', 'APPROVEDDATE TIMESTAMP');
    add_column('TBL_ATM_TXN_MNTR_OFFUS', 'FILETYPE VARCHAR2(100)');
    add_column('TBL_ATM_TXN_MNTR_OFFUS', 'EJERROR VARCHAR2(250)');
END;
/
