-- V18 module-owned payload migration. Run after the V12/V14 ATM upgrades.
BEGIN
  EXECUTE IMMEDIATE 'CREATE TABLE AlertModuleRecords (AlertId VARCHAR2(32) NOT NULL REFERENCES Alerts(Id), ModuleCode VARCHAR2(60) NOT NULL, DataJson CLOB NOT NULL, UpdatedAtUtc TIMESTAMP NOT NULL, CONSTRAINT PK_AlertModuleRecords PRIMARY KEY(AlertId,ModuleCode))';
EXCEPTION WHEN OTHERS THEN IF SQLCODE != -955 THEN RAISE; END IF;
END;
/
DECLARE
  TYPE names_t IS TABLE OF VARCHAR2(4000);
  statements names_t := names_t(
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (Recoverable_Type VARCHAR2(100))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (Recoverable_VendorName VARCHAR2(100))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (NoPenaltyApplicable NUMBER(1))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (Excess_Reported VARCHAR2(10))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (Excess_Date TIMESTAMP)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (MailDate TIMESTAMP)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (EJ_Error VARCHAR2(100))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (Recovery_Reason VARCHAR2(250))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (RecoveryReason_Remark CLOB)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (Fourwayreconcilition NUMBER(1))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (ATMC_Remark CLOB)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (ATMC_Status VARCHAR2(10))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (RATC_Remark CLOB)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (RATC_Status VARCHAR2(10))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (SH_Remark CLOB)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (SH_Status VARCHAR2(10))',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (RH_Remark CLOB)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (RH_Status CLOB)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (GH_Remark CLOB)',
    'ALTER TABLE tbl_ATM_Txn_Mntr_OnUs ADD (GH_Status CLOB)');
BEGIN
  FOR i IN 1..statements.COUNT LOOP
    BEGIN EXECUTE IMMEDIATE statements(i); EXCEPTION WHEN OTHERS THEN IF SQLCODE != -1430 THEN RAISE; END IF; END;
  END LOOP;
END;
/
MERGE INTO AlertModuleRecords m
USING (SELECT Id,DynamicDataJson FROM Alerts WHERE AlertType NOT IN ('ATM_ONUS','ATM_OFFUS')) a
ON (m.AlertId=a.Id AND m.ModuleCode='GENERIC')
WHEN NOT MATCHED THEN INSERT(AlertId,ModuleCode,DataJson,UpdatedAtUtc) VALUES(a.Id,'GENERIC',NVL(a.DynamicDataJson,'{}'),SYSTIMESTAMP);
/
UPDATE tbl_ATM_Txn_Mntr_OnUs t SET SourceDataJson=(SELECT a.DynamicDataJson FROM Alerts a WHERE a.Id=t.AlertId)
 WHERE EXISTS (SELECT 1 FROM Alerts a WHERE a.Id=t.AlertId AND a.AlertType='ATM_ONUS' AND DBMS_LOB.COMPARE(a.DynamicDataJson,TO_CLOB('{}'))<>0);
/
UPDATE tbl_ATM_Txn_Mntr_OFFUs t SET SourceDataJson=(SELECT a.DynamicDataJson FROM Alerts a WHERE a.Id=t.AlertId)
 WHERE EXISTS (SELECT 1 FROM Alerts a WHERE a.Id=t.AlertId AND a.AlertType='ATM_OFFUS' AND DBMS_LOB.COMPARE(a.DynamicDataJson,TO_CLOB('{}'))<>0);
/
UPDATE Alerts SET DynamicDataJson=TO_CLOB('{}') WHERE DBMS_LOB.COMPARE(DynamicDataJson,TO_CLOB('{}'))<>0;
/
CREATE OR REPLACE PROCEDURE USP_AlertModule_Get(p_AlertId IN VARCHAR2,p_ModuleCode IN VARCHAR2,p_Result OUT SYS_REFCURSOR) AS
BEGIN OPEN p_Result FOR SELECT AlertId,ModuleCode,DataJson,UpdatedAtUtc FROM AlertModuleRecords WHERE AlertId=p_AlertId AND ModuleCode=p_ModuleCode; END;
/
CREATE OR REPLACE PROCEDURE USP_AlertModule_Upsert(p_AlertId IN VARCHAR2,p_ModuleCode IN VARCHAR2,p_DataJson IN CLOB) AS
BEGIN
 MERGE INTO AlertModuleRecords m USING (SELECT p_AlertId AlertId,p_ModuleCode ModuleCode FROM dual) s
 ON (m.AlertId=s.AlertId AND m.ModuleCode=s.ModuleCode)
 WHEN MATCHED THEN UPDATE SET m.DataJson=NVL(p_DataJson,'{}'),m.UpdatedAtUtc=SYSTIMESTAMP
 WHEN NOT MATCHED THEN INSERT(AlertId,ModuleCode,DataJson,UpdatedAtUtc) VALUES(p_AlertId,p_ModuleCode,NVL(p_DataJson,'{}'),SYSTIMESTAMP);
END;
/
