-- V18 module-owned payload migration. Alerts retain only workflow/index data.
BEGIN;
CREATE TABLE IF NOT EXISTS AlertModuleRecords(
    AlertId varchar(32) NOT NULL REFERENCES Alerts(Id), ModuleCode varchar(60) NOT NULL,
    DataJson text NOT NULL DEFAULT '{}', UpdatedAtUtc timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(AlertId,ModuleCode));
INSERT INTO AlertModuleRecords(AlertId,ModuleCode,DataJson,UpdatedAtUtc)
SELECT Id,'GENERIC',COALESCE(NULLIF(DynamicDataJson,''),'{}'),CURRENT_TIMESTAMP
FROM Alerts WHERE AlertType NOT IN ('ATM_ONUS','ATM_OFFUS')
ON CONFLICT(AlertId,ModuleCode) DO NOTHING;
UPDATE tbl_ATM_Txn_Mntr_OnUs t SET SourceDataJson=a.DynamicDataJson
FROM Alerts a WHERE a.Id=t.AlertId AND a.AlertType='ATM_ONUS' AND a.DynamicDataJson <> '{}';
UPDATE tbl_ATM_Txn_Mntr_OFFUs t SET SourceDataJson=a.DynamicDataJson
FROM Alerts a WHERE a.Id=t.AlertId AND a.AlertType='ATM_OFFUS' AND a.DynamicDataJson <> '{}';
UPDATE Alerts SET DynamicDataJson='{}' WHERE DynamicDataJson <> '{}';
CREATE INDEX IF NOT EXISTS IX_AlertModuleRecords_Module ON AlertModuleRecords(ModuleCode,UpdatedAtUtc);
CREATE OR REPLACE FUNCTION usp_alertmodule_get(p_alert_id varchar,p_module_code varchar)
RETURNS TABLE(AlertId varchar,ModuleCode varchar,DataJson text,UpdatedAtUtc timestamp)
LANGUAGE sql AS $$ SELECT AlertId,ModuleCode,DataJson,UpdatedAtUtc FROM AlertModuleRecords WHERE AlertId=p_alert_id AND ModuleCode=p_module_code $$;
CREATE OR REPLACE FUNCTION usp_alertmodule_upsert(p_alert_id varchar,p_module_code varchar,p_data_json text)
RETURNS void LANGUAGE plpgsql AS $$ BEGIN
 INSERT INTO AlertModuleRecords(AlertId,ModuleCode,DataJson,UpdatedAtUtc) VALUES(p_alert_id,p_module_code,COALESCE(p_data_json,'{}'),CURRENT_TIMESTAMP)
 ON CONFLICT(AlertId,ModuleCode) DO UPDATE SET DataJson=EXCLUDED.DataJson,UpdatedAtUtc=EXCLUDED.UpdatedAtUtc;
END $$;
COMMIT;
