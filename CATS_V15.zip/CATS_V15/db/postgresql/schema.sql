CREATE SEQUENCE IF NOT EXISTS seq_cats_id AS bigint START WITH 1 INCREMENT BY 100;
CREATE TABLE IF NOT EXISTS CatsUsers(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), UserName varchar(100) NOT NULL UNIQUE, DisplayName varchar(200) NOT NULL,
 PasswordHash varchar(500) NOT NULL, RoleCode varchar(60) NOT NULL, DepartmentCode varchar(60) NOT NULL,
 BranchCode varchar(60) NOT NULL, PermissionsJson text NOT NULL, IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS Templates(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), Code varchar(80) NOT NULL, Name varchar(250) NOT NULL, Version integer NOT NULL,
 Status varchar(30) NOT NULL, ExecutionMode varchar(30) NOT NULL, SectionsJson text NOT NULL, FieldsJson text NOT NULL,
 AssignmentRulesJson text NOT NULL, ViewConfigurationJson text NOT NULL DEFAULT '{}', PublishedWorkflowId bigint, CreatedAtUtc timestamp NOT NULL, CreatedBy varchar(100) NOT NULL,
 UNIQUE(Code,Version));
CREATE TABLE IF NOT EXISTS WorkflowDefinitions(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), TemplateId bigint NOT NULL REFERENCES Templates(Id), Version integer NOT NULL, Name varchar(250) NOT NULL,
 DefinitionJson text NOT NULL, IsPublished integer NOT NULL DEFAULT 0, CreatedAtUtc timestamp NOT NULL, CreatedBy varchar(100) NOT NULL,
 UNIQUE(TemplateId,Version));
CREATE TABLE IF NOT EXISTS Alerts(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), AlertNo varchar(60) NOT NULL UNIQUE, TemplateId bigint NOT NULL REFERENCES Templates(Id), TemplateVersion integer NOT NULL,
 AlertType varchar(150) NOT NULL, BranchCode varchar(60) NOT NULL, CustomerIdEncrypted text NOT NULL, AccountIdEncrypted text NOT NULL,
 DynamicDataJson text NOT NULL, Status varchar(30) NOT NULL, CurrentStageId varchar(100) NOT NULL, CurrentStageName varchar(200) NOT NULL,
 CreatedAtUtc timestamp NOT NULL, StageEnteredAtUtc timestamp NOT NULL, CreatedBy varchar(100) NOT NULL, Priority varchar(30) NOT NULL);
 CREATE TABLE IF NOT EXISTS AlertModuleRecords(
  AlertId bigint NOT NULL REFERENCES Alerts(Id), ModuleCode varchar(60) NOT NULL, DataJson text NOT NULL,
  UpdatedAtUtc timestamp NOT NULL, PRIMARY KEY(AlertId,ModuleCode));
CREATE TABLE IF NOT EXISTS WorkflowInstances(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), AlertId bigint NOT NULL REFERENCES Alerts(Id), WorkflowDefinitionId bigint NOT NULL REFERENCES WorkflowDefinitions(Id),
 WorkflowVersion integer NOT NULL, Status varchar(30) NOT NULL, CurrentStageId varchar(100) NOT NULL, StartedAtUtc timestamp NOT NULL, UpdatedAtUtc timestamp NOT NULL);
CREATE TABLE IF NOT EXISTS WorkItems(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), AlertId bigint NOT NULL REFERENCES Alerts(Id), WorkflowInstanceId bigint NOT NULL REFERENCES WorkflowInstances(Id),
 StageId varchar(100) NOT NULL, StageName varchar(200) NOT NULL, AssignedRoleCode varchar(60) NOT NULL, AssignedBranchCode varchar(60) NOT NULL DEFAULT '', AssignedUserId bigint, Status varchar(30) NOT NULL,
 ParallelGroupId varchar(32), CompletedAction varchar(60), CompletedBy varchar(100), CreatedAtUtc timestamp NOT NULL, DueAtUtc timestamp NOT NULL,
 CompletedAtUtc timestamp, Remarks text);
CREATE TABLE IF NOT EXISTS AlertQueries(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), AlertId bigint NOT NULL REFERENCES Alerts(Id), RaisedBy varchar(100) NOT NULL, RaisedToRole varchar(60) NOT NULL,
 QueryText text NOT NULL, ResponseText text, Status varchar(30) NOT NULL, RaisedAtUtc timestamp NOT NULL, RespondedAtUtc timestamp);
CREATE TABLE IF NOT EXISTS Attachments(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), AlertId bigint NOT NULL REFERENCES Alerts(Id), StageId varchar(100) NOT NULL, FileName varchar(260) NOT NULL,
 StoredName varchar(100) NOT NULL, ContentType varchar(150) NOT NULL, FileSize bigint NOT NULL, Sha256 varchar(64) NOT NULL,
 Version integer NOT NULL, UploadedBy varchar(100) NOT NULL, UploadedAtUtc timestamp NOT NULL);
CREATE TABLE IF NOT EXISTS AuditLog(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), AlertId bigint, UserId bigint NOT NULL, UserName varchar(100) NOT NULL, RoleCode varchar(60) NOT NULL,
 Action varchar(80) NOT NULL, EntityType varchar(80) NOT NULL, EntityId varchar(32), StageId varchar(100), PreviousValueJson text, NewValueJson text,
 Remarks text, IpAddress varchar(100), CreatedAtUtc timestamp NOT NULL);
CREATE TABLE IF NOT EXISTS DiagnosticEvents(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), RequestId varchar(64) NOT NULL, OccurredAtUtc timestamp NOT NULL, UserId bigint, UserName varchar(100),
 RoleCode varchar(60), Module varchar(60) NOT NULL, HttpMethod varchar(10) NOT NULL, Path varchar(500) NOT NULL, StatusCode integer NOT NULL, DurationMs integer NOT NULL,
 Severity varchar(20) NOT NULL, ExceptionType varchar(200), Message varchar(1000), StackTrace varchar(4000), IpAddress varchar(100), ReleaseVersion varchar(60));
CREATE INDEX IF NOT EXISTS IX_DiagnosticEvents_Time ON DiagnosticEvents(OccurredAtUtc DESC);
CREATE INDEX IF NOT EXISTS IX_DiagnosticEvents_Request ON DiagnosticEvents(RequestId);
CREATE TABLE IF NOT EXISTS AlertListColumnMaster(
 Code varchar(60) PRIMARY KEY, Label varchar(100) NOT NULL, DbColumn varchar(128), IsFilterable integer NOT NULL DEFAULT 0,
 MatchMode varchar(10) NOT NULL DEFAULT 'Contains', ControlType varchar(20) NOT NULL DEFAULT 'text', OptionsJson text NOT NULL DEFAULT '[]',
 ValueFormat varchar(60), ExcludedTemplateCodes varchar(500), DisplayOrder integer NOT NULL DEFAULT 100, IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS TemplateDataTable(
 TemplateCode varchar(100) PRIMARY KEY, TableName varchar(128) NOT NULL UNIQUE, GeneratedAtUtc timestamp NOT NULL, UpdatedAtUtc timestamp NOT NULL, GeneratedBy varchar(100));
CREATE TABLE IF NOT EXISTS TemplateDataColumn(
 TemplateCode varchar(100) NOT NULL REFERENCES TemplateDataTable(TemplateCode), FieldName varchar(200) NOT NULL, ColumnName varchar(128) NOT NULL, SqlType varchar(40) NOT NULL,
 PRIMARY KEY(TemplateCode,FieldName), UNIQUE(TemplateCode,ColumnName));
CREATE TABLE IF NOT EXISTS ATM_UploadBatches(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), FileType varchar(30) NOT NULL, FileName varchar(260) NOT NULL, RowsJson text NOT NULL,
 Status varchar(30) NOT NULL, UploadedBy varchar(100) NOT NULL, UploadedAtUtc timestamp NOT NULL,
 DecidedBy varchar(100), DecidedAtUtc timestamp, DecisionRemarks varchar(2000));
CREATE TABLE IF NOT EXISTS ATM_MasterEntries(
 MasterType varchar(30) NOT NULL, RecordKey varchar(300) NOT NULL, ATMID varchar(100) NOT NULL,
 DataJson text NOT NULL, SourceBatchId bigint NOT NULL, UpdatedAtUtc timestamp NOT NULL,
 PRIMARY KEY(MasterType,RecordKey));
CREATE TABLE IF NOT EXISTS tbl_ATM_Txn_Mntr_OnUs(
 AlertId bigint PRIMARY KEY REFERENCES Alerts(Id), ATMID varchar(100) NOT NULL, PenaltyMonth varchar(20) NOT NULL,
 PenaltyAmount numeric(19,4) NOT NULL, CaseCategory varchar(60), SourceBatchId bigint NOT NULL,
 SourceRowNumber integer NOT NULL, ReopenedFromAlertId bigint, ATM_ID varchar(100),
 Penalty_Month varchar(100), Penalty_Year varchar(100), Settlement_Type varchar(100), CRM_Proactive_No varchar(100),
 Transaction_Date timestamp, Customer_Complaint_Date timestamp, Customer_Acc_Credit_Date timestamp,
 Acc_No varchar(20), T_5_Calender_Days timestamp, Days integer, Penalty_Rs numeric(18,2),
 Transaction_No varchar(100), Transaction_Amount numeric(18,2), Disputed_Amount numeric(18,2),
 EJ_Error varchar(100), Narration varchar(500), UploadFileName varchar(250), CreatedBy varchar(50),
 CreatedDate timestamp, SourceDataJson text, ATMC_Status varchar(10), ATMC_Remark text, RATC_Status varchar(10),
 RATC_Remark text, SH_Status varchar(10), SH_Remark text, Recoverable_Type varchar(100),
 Recoverable_VendorName varchar(100), NoPenaltyApplicable boolean, Excess_Reported varchar(10), Excess_Date timestamp,
 Recovery_Reason varchar(250), MailDate timestamp, RecoveryReason_Remark text, Fourwayreconcilition boolean,
 RH_Status text, RH_Remark text, GH_Status text, GH_Remark text, UNIQUE(SourceBatchId,SourceRowNumber));
CREATE TABLE IF NOT EXISTS tbl_ATM_Txn_Mntr_OFFUs(
 ID bigint GENERATED BY DEFAULT AS IDENTITY,
 AlertId bigint PRIMARY KEY REFERENCES Alerts(Id), ATMID varchar(100) NOT NULL, PenaltyMonth varchar(20) NOT NULL,
 PenaltyAmount numeric(19,4) NOT NULL, CaseCategory varchar(60), SourceBatchId bigint NOT NULL,
 SourceRowNumber integer NOT NULL, ReopenedFromAlertId bigint, ATM_ID varchar(100), Penalty_Month varchar(100),
 Penalty_Year varchar(100), SourceDataJson text, UploadFileName varchar(250), CreatedBy varchar(50), CreatedDate timestamp,
 Chargeback_Ref_No varchar(100), Chargeback_Date timestamp, Acquiring_Bank varchar(500), Issuing_Bank varchar(500),
 Transaction_Date timestamp, Transaction_Time varchar(50), RRN_No varchar(100), CARD_No varchar(100),
 Transaction_Amount numeric(18,2), Disputed_Amount numeric(18,2), Customer_Penalty varchar(100),
 Adjustment_Date timestamp, Adjustment_Type varchar(100), Adjustment_Time varchar(50), Narration varchar(500),
 Adjustment_Amount numeric(18,2), RecordStatus varchar(250), UploadRemarks text,
 ApprovedBy varchar(100), ApprovedDate timestamp, Assigned_Bucket varchar(100), Assigned_On timestamp,
 Assigned_By varchar(100), ATMC_Status varchar(10), ATMC_By varchar(50), ATMC_ActionOn timestamp,
 ATMC_Remark text, RATC_Status varchar(10), RATC_By varchar(50), RATC_ActionOn timestamp,
 RATC_Remark text, SH_Status varchar(10), SH_By varchar(50), SH_ActionOn timestamp, SH_Remark text,
 ProcessStatus varchar(50), ProcessBy varchar(100), ProcessOn timestamp, Recoverable_Type varchar(100),
 Recoverable_VendorName varchar(100), Excess_Reported varchar(10), Excess_Date timestamp,
 Recovery_Reason varchar(250), MailDate timestamp, EJError varchar(250), RecoveryReason_Remark text,
 Fourwayreconcilition boolean, RH_By varchar(200), RH_ActionOn timestamp, RH_Status text, RH_Remark text,
 GH_By varchar(200), GH_ActionOn timestamp, GH_Status text, GH_Remark text, FileType varchar(100),
 IsReopen integer, ReopenBy varchar(200), ReopenOn timestamp, ReopenReason text,
 FileData_Update_By varchar(200), FileData_Update_On timestamp, ReAssignBy varchar(100),
 ReAssignOn timestamp, ReAssignEmpId varchar(100), Reopen_Sent_for_Authorisation timestamp,
 Reopen_Authorised_by varchar(200), Reopen_Sent_for_Authorisation_By varchar(100),
 Reopen_Authorised_Remark text, IsEmailSent_ATMC integer, IsEmailSent_RATC integer,
 UNIQUE(SourceBatchId,SourceRowNumber));
CREATE TABLE IF NOT EXISTS ATM_ReopenRequests(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), OriginalAlertId bigint NOT NULL, RequestBatchId bigint NOT NULL,
 RequestedBy varchar(100) NOT NULL, RequestedAtUtc timestamp NOT NULL, Status varchar(30) NOT NULL,
 DecidedBy varchar(100), DecidedAtUtc timestamp, DecisionRemarks varchar(2000), NewAlertId bigint);
CREATE TABLE IF NOT EXISTS AlertTypeAccess(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), TemplateCode varchar(100) NOT NULL, RoleCode varchar(60), PermissionCode varchar(100), IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS MenuMaster(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), ParentId bigint, Code varchar(100) NOT NULL UNIQUE, Label varchar(150) NOT NULL, Title varchar(200),
 Description varchar(300), Icon varchar(40), ViewKey varchar(60), PermissionCode varchar(100), DisplayOrder integer NOT NULL DEFAULT 100, IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS MenuRoleMapping(
 MenuId bigint NOT NULL, RoleCode varchar(60) NOT NULL, PRIMARY KEY(MenuId,RoleCode));
CREATE TABLE IF NOT EXISTS ATM_MasterSettings(
 SettingKey varchar(60) PRIMARY KEY, SettingJson text NOT NULL, UpdatedBy varchar(100), UpdatedAtUtc timestamp NOT NULL);
CREATE TABLE IF NOT EXISTS tbl_ATM_Txn_Mntr_MappingMaster(
 ID bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
 ATM_ID varchar(250), ATMC_EMPCode varchar(50), ATMC_EMPCode_BK varchar(50), RATC_EMPCode varchar(50), RATC_EMPCode_BK varchar(50),
 SH_EMPCode varchar(50), WBO_RH_EMPCode varchar(50), GH_EMPCode varchar(50), RH_EMPCode varchar(50), GH_EMPCode_BK varchar(50),
 RH_EMPCode_BK varchar(50), GH_EMPCode1 varchar(50), RH_EMPCode1 varchar(50), GH_EMPCode1_BK varchar(50), RH_EMPCode1_BK varchar(50),
 ATMC_EMPCode_Reassign varchar(50), RATC_EMPCode_Reassign varchar(50), SH_EMPCode_Reassign varchar(50),
 STATE varchar(250), Penalty_Month varchar(100), Penalty_Year varchar(100), RecordStatus varchar(10), UploadFileName varchar(250),
 CreatedBy varchar(50), CreatedDate timestamp, ModifiedBy varchar(50), ModifiedDate timestamp, ApprovedBy varchar(50), ApprovedDate timestamp);
CREATE UNIQUE INDEX IF NOT EXISTS UX_ATM_MappingMaster_ATM_ID ON tbl_ATM_Txn_Mntr_MappingMaster(ATM_ID);
CREATE INDEX IF NOT EXISTS IX_ATM_Master_ATMID ON ATM_MasterEntries(MasterType,ATMID);
CREATE INDEX IF NOT EXISTS IX_ATM_OnUs_ATMID_Month ON tbl_ATM_Txn_Mntr_OnUs(ATMID,PenaltyMonth);
CREATE INDEX IF NOT EXISTS IX_ATM_OffUs_ATMID_Month ON tbl_ATM_Txn_Mntr_OFFUs(ATMID,PenaltyMonth);
CREATE TABLE IF NOT EXISTS AgingBuckets(
 Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'), Name varchar(60) NOT NULL UNIQUE, FromDays integer NOT NULL, ToDays integer, DisplayOrder integer NOT NULL, IsActive integer NOT NULL DEFAULT 1);
CREATE INDEX IF NOT EXISTS IX_Alerts_StageEntered ON Alerts(StageEnteredAtUtc,Status,TemplateId);
CREATE INDEX IF NOT EXISTS IX_WorkItems_Assignment ON WorkItems(Status,AssignedRoleCode,AssignedBranchCode,AssignedUserId,AlertId);
CREATE INDEX IF NOT EXISTS IX_Audit_Alert ON AuditLog(AlertId,CreatedAtUtc DESC);
CREATE UNIQUE INDEX IF NOT EXISTS UX_WorkflowInstances_Alert ON WorkflowInstances(AlertId);

-- CATS V2 platform tables
CREATE TABLE IF NOT EXISTS RoleMaster(Code varchar(60) PRIMARY KEY,Name varchar(150) NOT NULL,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS PermissionMaster(Code varchar(100) PRIMARY KEY,Name varchar(200) NOT NULL,Category varchar(60) NOT NULL,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS RolePermissionMapping(RoleCode varchar(60) NOT NULL,PermissionCode varchar(100) NOT NULL,IsActive integer NOT NULL DEFAULT 1,PRIMARY KEY(RoleCode,PermissionCode));
CREATE TABLE IF NOT EXISTS UserPermissionMapping(UserId bigint NOT NULL,PermissionCode varchar(100) NOT NULL,IsActive integer NOT NULL DEFAULT 1,PRIMARY KEY(UserId,PermissionCode));
CREATE TABLE IF NOT EXISTS DataScopeMaster(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),RoleCode varchar(60) NOT NULL,ScopeType varchar(30) NOT NULL,ScopeValue varchar(150) NOT NULL DEFAULT '',Priority integer NOT NULL DEFAULT 100,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS DashboardWidgetMaster(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),Code varchar(80) UNIQUE NOT NULL,Title varchar(150) NOT NULL,WidgetType varchar(30) NOT NULL,PermissionCode varchar(100) NOT NULL DEFAULT '',FilterJson text NOT NULL DEFAULT '{}',DrillDownUrl varchar(500) NOT NULL DEFAULT '',DisplayOrder integer NOT NULL DEFAULT 1,Width integer NOT NULL DEFAULT 3,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS DashboardWidgetRoleMapping(WidgetId bigint NOT NULL,RoleCode varchar(60) NOT NULL,DisplayOrder integer NOT NULL DEFAULT 1,Width integer NOT NULL DEFAULT 3,IsVisible integer NOT NULL DEFAULT 1,PRIMARY KEY(WidgetId,RoleCode));
CREATE TABLE IF NOT EXISTS IngestionConnector(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),Name varchar(150) NOT NULL,ConnectorType varchar(30) NOT NULL,Host varchar(300) NOT NULL DEFAULT '',Port integer NOT NULL DEFAULT 0,DatabaseName varchar(200) NOT NULL DEFAULT '',UserName varchar(200) NOT NULL DEFAULT '',SecretEncrypted text NOT NULL DEFAULT '',ExtraJson text NOT NULL DEFAULT '{}',IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS IngestionConfiguration(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),Name varchar(150) NOT NULL,TemplateId bigint NOT NULL,SourceType varchar(30) NOT NULL,ConnectorId bigint,FilePath varchar(500) NOT NULL DEFAULT '',FileName varchar(260) NOT NULL DEFAULT '',FilePattern varchar(260) NOT NULL DEFAULT '',ScheduleTriggersJson text NOT NULL DEFAULT '[]',ScheduleCron varchar(100) NOT NULL DEFAULT '',QueryText text NOT NULL DEFAULT '',FieldMappingJson text NOT NULL DEFAULT '{}',DuplicateKeyFields varchar(500) NOT NULL DEFAULT '',ArchivePath varchar(500) NOT NULL DEFAULT '',ErrorPath varchar(500) NOT NULL DEFAULT '',IntervalMinutes integer NOT NULL DEFAULT 1,IsActive integer NOT NULL DEFAULT 1);
ALTER TABLE IngestionConfiguration ADD COLUMN IF NOT EXISTS FilePath varchar(500) NOT NULL DEFAULT '';
ALTER TABLE IngestionConfiguration ADD COLUMN IF NOT EXISTS FileName varchar(260) NOT NULL DEFAULT '';
ALTER TABLE IngestionConfiguration ADD COLUMN IF NOT EXISTS ScheduleTriggersJson text NOT NULL DEFAULT '[]';
CREATE TABLE IF NOT EXISTS IngestionRun(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),ConfigurationId bigint NOT NULL,SourceReference varchar(500) NOT NULL DEFAULT '',StartedAtUtc timestamp NOT NULL,EndedAtUtc timestamp,RowsRead integer NOT NULL DEFAULT 0,RowsInserted integer NOT NULL DEFAULT 0,RowsDuplicate integer NOT NULL DEFAULT 0,RowsFailed integer NOT NULL DEFAULT 0,Status varchar(30) NOT NULL,ErrorMessage text);
CREATE TABLE IF NOT EXISTS IngestionStaging(Id bigserial PRIMARY KEY,RunId bigint NOT NULL,RowNo integer NOT NULL,TemplateId bigint NOT NULL,AlertType varchar(150) NOT NULL,BranchCode varchar(60) NOT NULL,CustomerIdEncrypted text NOT NULL,AccountIdEncrypted text NOT NULL,Priority varchar(30) NOT NULL,DynamicDataJson text NOT NULL,DedupKey varchar(500) NOT NULL DEFAULT '',ProcessStatus varchar(30) NOT NULL DEFAULT 'Pending',ErrorMessage text);
CREATE TABLE IF NOT EXISTS MailConfiguration(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),Name varchar(150) NOT NULL,ProviderType varchar(30) NOT NULL,Host varchar(300) NOT NULL,Port integer NOT NULL,UserName varchar(200) NOT NULL DEFAULT '',SecretEncrypted text NOT NULL DEFAULT '',FromAddress varchar(300) NOT NULL,UseSsl integer NOT NULL DEFAULT 1,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS MailTemplate(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),TemplateId bigint,EventCode varchar(80) NOT NULL,SubjectTemplate varchar(500) NOT NULL,BodyTemplate text NOT NULL,UseMafEnrichment integer NOT NULL DEFAULT 0,IsActive integer NOT NULL DEFAULT 1);
ALTER TABLE MailTemplate ADD COLUMN IF NOT EXISTS TemplateId bigint;
ALTER TABLE MailTemplate DROP CONSTRAINT IF EXISTS mailtemplate_eventcode_key;
CREATE UNIQUE INDEX IF NOT EXISTS UX_MailTemplate_TemplateEvent ON MailTemplate(TemplateId,EventCode);
CREATE TABLE IF NOT EXISTS MailQueue(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),EventCode varchar(80) NOT NULL,AlertId bigint,ToAddress text NOT NULL,CcAddress text,Subject varchar(500) NOT NULL,Body text NOT NULL,Status varchar(30) NOT NULL DEFAULT 'Pending',Attempts integer NOT NULL DEFAULT 0,NextAttemptAtUtc timestamp NOT NULL,CreatedAtUtc timestamp NOT NULL,SentAtUtc timestamp,ErrorMessage text);

CREATE TABLE IF NOT EXISTS TemplateDashboardMaster(Id bigint PRIMARY KEY DEFAULT nextval('seq_cats_id'),Code varchar(80) UNIQUE NOT NULL,Name varchar(150) NOT NULL,Title varchar(250) NOT NULL,Description varchar(1000) NOT NULL DEFAULT '',TemplateId bigint NOT NULL,AlertType varchar(150) NOT NULL DEFAULT '',GroupByFieldsJson text NOT NULL DEFAULT '["BranchCode"]',MetricsJson text NOT NULL DEFAULT '[]',GridColumnsJson text NOT NULL DEFAULT '[]',SearchFieldsJson text NOT NULL DEFAULT '["AlertNo","AccountId","CustomerId"]',PageSize integer NOT NULL DEFAULT 20,DisplayOrder integer NOT NULL DEFAULT 1,IsDefault integer NOT NULL DEFAULT 0,IsActive integer NOT NULL DEFAULT 1,CreatedAtUtc timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,UpdatedAtUtc timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS TemplateDashboardRoleMapping(DashboardId bigint NOT NULL,RoleCode varchar(60) NOT NULL,IsVisible integer NOT NULL DEFAULT 1,PRIMARY KEY(DashboardId,RoleCode));

ALTER TABLE Templates ADD COLUMN IF NOT EXISTS ViewConfigurationJson text NOT NULL DEFAULT '{}';
