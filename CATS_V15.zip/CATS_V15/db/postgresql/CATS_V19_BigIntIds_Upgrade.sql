/* =====================================================================================
   CATS V19 - Convert GUID varchar(32) identifiers to BIGINT (PostgreSQL)

   NOT YET TESTED against a PostgreSQL server - rehearse it on a copy of your database first.

   Same behaviour as db/sqlserver/CATS_V19_BigIntIds_Upgrade.sql:
   - creates sequence seq_cats_id (every new id comes from it);
   - adds a bigint Id to every table that used a GUID Id and keeps the old GUID in LegacyGuid
     (unique) so old links, bookmarks and audit text can still be mapped;
   - converts every referencing column through LegacyGuid and drops the old varchar columns;
   - drops and recreates the primary keys, unique constraints, indexes and foreign keys;
   - rewrites the user ids embedded in JSON (_assignments.<stage>.userId, targetUserId);
   - is re-runnable (nothing happens when alerts.id is already bigint) and runs in one transaction.

   Take a full backup and stop CATS before running it.
   ===================================================================================== */
DO $mig$
DECLARE
    pk_tables text[] := ARRAY['agingbuckets','alertqueries','alerts','alerttypeaccess','atm_reopenrequests',
        'atm_uploadbatches','attachments','auditlog','catsusers','dashboardwidgetmaster','datascopemaster',
        'ingestionconfiguration','ingestionconnector','ingestionrun','mailconfiguration','mailqueue','mailtemplate',
        'menumaster','templatedashboardmaster','templates','workflowdefinitions','workflowinstances','workitems'];
    t text;
    r record;
    affected oid[];
    ord_col text;
    ord_expr text;
    removed bigint;
    last_id bigint;
BEGIN
    IF to_regclass('alerts') IS NULL THEN
        RAISE NOTICE 'CATS V19: alerts does not exist - nothing to migrate.';
        RETURN;
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_schema = current_schema() AND table_name = 'alerts' AND column_name = 'id' AND data_type = 'bigint') THEN
        RAISE NOTICE 'CATS V19: identifiers are already bigint - nothing to do.';
        RETURN;
    END IF;

    CREATE SEQUENCE IF NOT EXISTS seq_cats_id AS bigint START WITH 1 INCREMENT BY 1;

    /* ---------- 1. Which tables/columns are converted ---------- */
    CREATE TEMP TABLE mig_cols(tbl text NOT NULL, col text NOT NULL, ref text, is_pk boolean NOT NULL, is_nullable boolean) ON COMMIT DROP;
    INSERT INTO mig_cols(tbl, col, ref, is_pk) SELECT unnest(pk_tables), 'id', NULL, true;
    INSERT INTO mig_cols(tbl, col, ref, is_pk) VALUES
        ('alertmodulerecords','alertid','alerts',false), ('alertqueries','alertid','alerts',false),
        ('alerts','templateid','templates',false), ('atm_masterentries','sourcebatchid','atm_uploadbatches',false),
        ('atm_reopenrequests','originalalertid','alerts',false), ('atm_reopenrequests','requestbatchid','atm_uploadbatches',false),
        ('atm_reopenrequests','newalertid','alerts',false), ('attachments','alertid','alerts',false),
        ('auditlog','alertid','alerts',false), ('auditlog','userid','catsusers',false),
        ('dashboardwidgetrolemapping','widgetid','dashboardwidgetmaster',false),
        ('ingestionconfiguration','templateid','templates',false), ('ingestionconfiguration','connectorid','ingestionconnector',false),
        ('ingestionrun','configurationid','ingestionconfiguration',false),
        ('ingestionstaging','runid','ingestionrun',false), ('ingestionstaging','templateid','templates',false),
        ('mailqueue','alertid','alerts',false), ('mailtemplate','templateid','templates',false),
        ('menumaster','parentid','menumaster',false), ('menurolemapping','menuid','menumaster',false),
        ('tbl_atm_txn_mntr_offus','alertid','alerts',false), ('tbl_atm_txn_mntr_offus','sourcebatchid','atm_uploadbatches',false),
        ('tbl_atm_txn_mntr_offus','reopenedfromalertid','alerts',false),
        ('tbl_atm_txn_mntr_onus','alertid','alerts',false), ('tbl_atm_txn_mntr_onus','sourcebatchid','atm_uploadbatches',false),
        ('tbl_atm_txn_mntr_onus','reopenedfromalertid','alerts',false),
        ('templatedashboardmaster','templateid','templates',false),
        ('templatedashboardrolemapping','dashboardid','templatedashboardmaster',false),
        ('templates','publishedworkflowid','workflowdefinitions',false),
        ('userpermissionmapping','userid','catsusers',false),
        ('workflowdefinitions','templateid','templates',false),
        ('workflowinstances','alertid','alerts',false), ('workflowinstances','workflowdefinitionid','workflowdefinitions',false),
        ('workitems','alertid','alerts',false), ('workitems','workflowinstanceid','workflowinstances',false),
        ('workitems','assigneduserid','catsusers',false);

    -- Older databases may not have every table/column; keep only varchar columns that exist.
    DELETE FROM mig_cols m WHERE NOT EXISTS (
        SELECT 1 FROM information_schema.columns ic
        WHERE ic.table_schema = current_schema() AND ic.table_name = m.tbl AND ic.column_name = m.col AND ic.data_type = 'character varying');
    DELETE FROM mig_cols WHERE is_pk = false AND ref NOT IN (SELECT tbl FROM mig_cols WHERE is_pk);
    UPDATE mig_cols m SET is_nullable = (
        SELECT ic.is_nullable = 'YES' FROM information_schema.columns ic
        WHERE ic.table_schema = current_schema() AND ic.table_name = m.tbl AND ic.column_name = m.col);
    SELECT array_agg(DISTINCT (tbl)::regclass::oid) INTO affected FROM mig_cols;

    /* ---------- 2. Remember the constraints and indexes that touch those tables ---------- */
    CREATE TEMP TABLE mig_ddl(ord serial, kind int NOT NULL, tbl text NOT NULL, name text NOT NULL, ddl text NOT NULL) ON COMMIT DROP;
    INSERT INTO mig_ddl(kind, tbl, name, ddl)
    SELECT CASE WHEN c.contype = 'f' THEN 3 ELSE 1 END, c.conrelid::regclass::text, c.conname,
           format('ALTER TABLE %s ADD CONSTRAINT %I %s', c.conrelid::regclass, c.conname, pg_get_constraintdef(c.oid))
    FROM pg_constraint c
    WHERE c.contype IN ('p', 'u', 'f') AND (c.conrelid = ANY(affected) OR c.confrelid = ANY(affected));
    INSERT INTO mig_ddl(kind, tbl, name, ddl)
    SELECT 2, i.indrelid::regclass::text, ic.relname,
           regexp_replace(pg_get_indexdef(i.indexrelid), '^CREATE (UNIQUE )?INDEX', 'CREATE \1INDEX IF NOT EXISTS')
    FROM pg_index i JOIN pg_class ic ON ic.oid = i.indexrelid
    WHERE i.indrelid = ANY(affected) AND NOT EXISTS (SELECT 1 FROM pg_constraint k WHERE k.conindid = i.indexrelid);

    -- Foreign keys go first so parent keys can be replaced.
    FOR r IN SELECT tbl, name FROM mig_ddl WHERE kind = 3 LOOP
        EXECUTE format('ALTER TABLE %s DROP CONSTRAINT %I', r.tbl, r.name);
    END LOOP;

    /* ---------- 3. New bigint key + LegacyGuid on every GUID table (chronological per table) ---------- */
    FOR t IN SELECT tbl FROM mig_cols WHERE is_pk LOOP
        EXECUTE format('ALTER TABLE %I ADD COLUMN legacyguid varchar(32), ADD COLUMN id_n bigint', t);
        EXECUTE format('UPDATE %I SET legacyguid = id', t);
        SELECT column_name INTO ord_col FROM information_schema.columns
        WHERE table_schema = current_schema() AND table_name = t
          AND column_name IN ('createdatutc', 'raisedatutc', 'uploadedatutc', 'startedatutc')
        ORDER BY CASE column_name WHEN 'createdatutc' THEN 1 WHEN 'raisedatutc' THEN 2 WHEN 'uploadedatutc' THEN 3 ELSE 4 END
        LIMIT 1;
        ord_expr := CASE WHEN ord_col IS NULL THEN 'id' ELSE format('%I, id', ord_col) END;
        EXECUTE format('UPDATE %1$I x SET id_n = s.n FROM (SELECT o.id, nextval(''seq_cats_id'') AS n FROM (SELECT id FROM %1$I ORDER BY %2$s) o) s WHERE s.id = x.id', t, ord_expr);
    END LOOP;

    /* ---------- 4. Referencing columns follow through LegacyGuid ---------- */
    FOR r IN SELECT tbl, col, ref, is_nullable FROM mig_cols WHERE NOT is_pk LOOP
        EXECUTE format('ALTER TABLE %I ADD COLUMN %I bigint', r.tbl, r.col || '_n');
        EXECUTE format('UPDATE %1$I c SET %2$I = p.id_n FROM %3$I p WHERE p.legacyguid = c.%4$I', r.tbl, r.col || '_n', r.ref, r.col);
    END LOOP;

    -- A reopen request stores its own id as RequestBatchId, so it may not match an upload batch: fall back to itself.
    IF EXISTS (SELECT 1 FROM mig_cols WHERE tbl = 'atm_reopenrequests' AND col = 'requestbatchid') THEN
        UPDATE atm_reopenrequests r SET requestbatchid_n = COALESCE(r.requestbatchid_n,
            (SELECT p.id_n FROM atm_reopenrequests p WHERE p.legacyguid = r.requestbatchid), r.id_n);
    END IF;

    -- Orphans: nullable columns become NULL; failed-login audit rows get user 0; a template-specific mail template whose
    -- Template no longer exists is dead data; other rows without a parent are removed.
    FOR r IN SELECT tbl, col, is_nullable FROM mig_cols WHERE NOT is_pk LOOP
        IF r.tbl = 'auditlog' AND r.col = 'userid' THEN
            EXECUTE 'UPDATE auditlog SET userid_n = 0 WHERE userid_n IS NULL';
        ELSIF (NOT r.is_nullable) OR (r.tbl = 'mailtemplate' AND r.col = 'templateid') THEN
            EXECUTE format('DELETE FROM %I WHERE %I IS NULL AND COALESCE(%I, '''') <> ''''', r.tbl, r.col || '_n', r.col);
            GET DIAGNOSTICS removed = ROW_COUNT;
            IF removed > 0 THEN
                RAISE WARNING 'CATS V19: removed % orphan row(s) from % (% has no matching parent).', removed, r.tbl, r.col;
            END IF;
            IF NOT r.is_nullable THEN
                EXECUTE format('DELETE FROM %I WHERE %I IS NULL', r.tbl, r.col || '_n');
            END IF;
        END IF;
    END LOOP;

    /* ---------- 5. Swap the new columns in ---------- */
    FOR r IN SELECT tbl, col, is_nullable FROM mig_cols LOOP
        EXECUTE format('ALTER TABLE %I DROP COLUMN %I CASCADE', r.tbl, r.col);
        EXECUTE format('ALTER TABLE %I RENAME COLUMN %I TO %I', r.tbl, r.col || '_n', r.col);
        IF NOT r.is_nullable THEN
            EXECUTE format('ALTER TABLE %I ALTER COLUMN %I SET NOT NULL', r.tbl, r.col);
        END IF;
    END LOOP;

    /* ---------- 6. Recreate keys, indexes, foreign keys; sequence default; LegacyGuid lookup ---------- */
    FOR r IN SELECT kind, tbl, name, ddl FROM mig_ddl ORDER BY kind, ord LOOP
        IF r.kind = 2 THEN
            EXECUTE r.ddl;
        ELSIF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = r.name AND conrelid = r.tbl::regclass) THEN
            EXECUTE r.ddl;
        END IF;
    END LOOP;
    FOR t IN SELECT tbl FROM mig_cols WHERE is_pk LOOP
        EXECUTE format('ALTER TABLE %I ALTER COLUMN id SET DEFAULT nextval(''seq_cats_id'')', t);
        EXECUTE format('CREATE UNIQUE INDEX %I ON %I(legacyguid) WHERE legacyguid IS NOT NULL', 'ux_' || t || '_legacyguid', t);
    END LOOP;

    /* ---------- 7. JSON documents that embed user ids ---------- */
    IF to_regclass('catsusers') IS NOT NULL THEN
        FOR r IN SELECT id, legacyguid FROM catsusers WHERE legacyguid IS NOT NULL LOOP
            IF to_regclass('alertmodulerecords') IS NOT NULL THEN
                UPDATE alertmodulerecords
                SET datajson = replace(replace(datajson, '"userId":"' || r.legacyguid || '"', '"userId":' || r.id),
                                       '"userId": "' || r.legacyguid || '"', '"userId": ' || r.id)
                WHERE datajson LIKE '%' || r.legacyguid || '%';
            END IF;
            IF to_regclass('templates') IS NOT NULL THEN
                UPDATE templates
                SET assignmentrulesjson = replace(replace(assignmentrulesjson, '"targetUserId":"' || r.legacyguid || '"', '"targetUserId":' || r.id),
                                                  '"targetUserId": "' || r.legacyguid || '"', '"targetUserId": ' || r.id)
                WHERE assignmentrulesjson LIKE '%' || r.legacyguid || '%';
            END IF;
        END LOOP;
    END IF;

    /* ---------- 8. Sequence continues after the migrated ids; each CATS process reserves blocks of 100 ---------- */
    SELECT last_value INTO last_id FROM seq_cats_id;
    PERFORM setval('seq_cats_id', last_id);
    ALTER SEQUENCE seq_cats_id INCREMENT BY 100;
    RAISE NOTICE 'CATS V19 completed: % tables converted.', (SELECT count(*) FROM mig_cols WHERE is_pk);
END
$mig$;
