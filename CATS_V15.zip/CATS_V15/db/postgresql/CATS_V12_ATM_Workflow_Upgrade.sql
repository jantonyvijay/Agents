CREATE TABLE IF NOT EXISTS ATM_UploadBatches(
 Id varchar(32) PRIMARY KEY, FileType varchar(30) NOT NULL, FileName varchar(260) NOT NULL, RowsJson text NOT NULL,
 Status varchar(30) NOT NULL, UploadedBy varchar(100) NOT NULL, UploadedAtUtc timestamp NOT NULL,
 DecidedBy varchar(100), DecidedAtUtc timestamp, DecisionRemarks varchar(2000));
CREATE TABLE IF NOT EXISTS ATM_MasterEntries(
 MasterType varchar(30) NOT NULL, RecordKey varchar(300) NOT NULL, ATMID varchar(100) NOT NULL,
 DataJson text NOT NULL, SourceBatchId varchar(32) NOT NULL, UpdatedAtUtc timestamp NOT NULL,
 PRIMARY KEY(MasterType,RecordKey));
CREATE TABLE IF NOT EXISTS tbl_ATM_Txn_Mntr_OnUs(
 AlertId varchar(32) PRIMARY KEY REFERENCES Alerts(Id), ATMID varchar(100) NOT NULL, PenaltyMonth varchar(20) NOT NULL,
 PenaltyAmount numeric(19,4) NOT NULL, CaseCategory varchar(60), SourceBatchId varchar(32) NOT NULL,
 SourceRowNumber integer NOT NULL, ReopenedFromAlertId varchar(32), UNIQUE(SourceBatchId,SourceRowNumber));
CREATE TABLE IF NOT EXISTS tbl_ATM_Txn_Mntr_OFFUs(
 AlertId varchar(32) PRIMARY KEY REFERENCES Alerts(Id), ATMID varchar(100) NOT NULL, PenaltyMonth varchar(20) NOT NULL,
 PenaltyAmount numeric(19,4) NOT NULL, CaseCategory varchar(60), SourceBatchId varchar(32) NOT NULL,
 SourceRowNumber integer NOT NULL, ReopenedFromAlertId varchar(32), UNIQUE(SourceBatchId,SourceRowNumber));
CREATE TABLE IF NOT EXISTS ATM_ReopenRequests(
 Id varchar(32) PRIMARY KEY, OriginalAlertId varchar(32) NOT NULL, RequestBatchId varchar(32) NOT NULL,
 RequestedBy varchar(100) NOT NULL, RequestedAtUtc timestamp NOT NULL, Status varchar(30) NOT NULL,
 DecidedBy varchar(100), DecidedAtUtc timestamp, DecisionRemarks varchar(2000), NewAlertId varchar(32));
CREATE INDEX IF NOT EXISTS IX_ATM_Master_ATMID ON ATM_MasterEntries(MasterType,ATMID);
CREATE INDEX IF NOT EXISTS IX_ATM_OnUs_ATMID_Month ON tbl_ATM_Txn_Mntr_OnUs(ATMID,PenaltyMonth);
CREATE INDEX IF NOT EXISTS IX_ATM_OffUs_ATMID_Month ON tbl_ATM_Txn_Mntr_OFFUs(ATMID,PenaltyMonth);
