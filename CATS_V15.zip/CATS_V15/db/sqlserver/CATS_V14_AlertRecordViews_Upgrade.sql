CREATE OR ALTER PROCEDURE dbo.USP_Alert_GetCount
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT COUNT(1) AS TotalRecords
        FROM dbo.Alerts AS a
        WHERE
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId OR vw.CompletedBy=JSON_VALUE(@strJson,'$.userName')
                    )
              )
          )
          AND (
            COALESCE(JSON_VALUE(@strJson,'$.recordView'),'All')='All'
            OR (JSON_VALUE(@strJson,'$.recordView')='Closed' AND a.Status='Closed')
            OR (JSON_VALUE(@strJson,'$.recordView')='ActionedByMe' AND EXISTS (
                SELECT 1 FROM dbo.WorkItems acted WHERE acted.AlertId=a.Id
                AND acted.Status='Completed' AND acted.CompletedBy=JSON_VALUE(@strJson,'$.userName')))
            OR (JSON_VALUE(@strJson,'$.recordView')='MyActionable'
                AND a.Status NOT IN ('Closed','Rejected','Cancelled') AND EXISTS (
                SELECT 1 FROM dbo.WorkItems pending WHERE pending.AlertId=a.Id
                AND pending.Status='Pending' AND pending.StageId=a.CurrentStageId
                AND (pending.AssignedUserId=JSON_VALUE(@strJson,'$.userId')
                    OR (NULLIF(LTRIM(RTRIM(pending.AssignedUserId)),'') IS NULL
                        AND pending.AssignedRoleCode=JSON_VALUE(@strJson,'$.roleCode')
                        AND (NULLIF(pending.AssignedBranchCode,'') IS NULL OR pending.AssignedBranchCode=JSON_VALUE(@strJson,'$.userBranchCode'))))))
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status)
          AND (@AgingFrom IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=@AgingFrom)
          AND (@AgingTo IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())<=@AgingTo)
          AND
          (
              NULLIF(LTRIM(RTRIM(COALESCE(@Search,N''))),N'') IS NULL
              OR UPPER(a.AlertNo) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.AlertType) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.BranchCode) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
          );
        RETURN;
END
GO


CREATE OR ALTER PROCEDURE dbo.USP_Alert_GetPaged
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SET @Page=COALESCE(@Page,1);
        IF @Page<1 SET @Page=1;
        SET @PageSize=COALESCE(@PageSize,20);
        IF @PageSize<10 SET @PageSize=10;
        IF @PageSize>100 SET @PageSize=100;

        SELECT a.Id,a.TemplateId,a.AlertNo,t.Name AS TemplateName,a.AlertType,a.BranchCode,
             a.CustomerIdEncrypted,a.AccountIdEncrypted,a.DynamicDataJson,a.CurrentStageName,a.Status,a.Priority,
               DATEDIFF(day,a.CreatedAtUtc,SYSUTCDATETIME()) AS OverallAge,
               DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME()) AS StageAge
        FROM dbo.Alerts AS a
        INNER JOIN dbo.Templates AS t ON t.Id=a.TemplateId
        WHERE
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId OR vw.CompletedBy=JSON_VALUE(@strJson,'$.userName')
                    )
              )
          )
          AND (
            COALESCE(JSON_VALUE(@strJson,'$.recordView'),'All')='All'
            OR (JSON_VALUE(@strJson,'$.recordView')='Closed' AND a.Status='Closed')
            OR (JSON_VALUE(@strJson,'$.recordView')='ActionedByMe' AND EXISTS (
                SELECT 1 FROM dbo.WorkItems acted WHERE acted.AlertId=a.Id
                AND acted.Status='Completed' AND acted.CompletedBy=JSON_VALUE(@strJson,'$.userName')))
            OR (JSON_VALUE(@strJson,'$.recordView')='MyActionable'
                AND a.Status NOT IN ('Closed','Rejected','Cancelled') AND EXISTS (
                SELECT 1 FROM dbo.WorkItems pending WHERE pending.AlertId=a.Id
                AND pending.Status='Pending' AND pending.StageId=a.CurrentStageId
                AND (pending.AssignedUserId=JSON_VALUE(@strJson,'$.userId')
                    OR (NULLIF(LTRIM(RTRIM(pending.AssignedUserId)),'') IS NULL
                        AND pending.AssignedRoleCode=JSON_VALUE(@strJson,'$.roleCode')
                        AND (NULLIF(pending.AssignedBranchCode,'') IS NULL OR pending.AssignedBranchCode=JSON_VALUE(@strJson,'$.userBranchCode'))))))
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status)
          AND (@AgingFrom IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=@AgingFrom)
          AND (@AgingTo IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())<=@AgingTo)
          AND
          (
              NULLIF(LTRIM(RTRIM(COALESCE(@Search,N''))),N'') IS NULL
              OR UPPER(a.AlertNo) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.AlertType) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.BranchCode) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
          )
        ORDER BY a.StageEnteredAtUtc DESC
        OFFSET ((@Page-1)*@PageSize) ROWS FETCH NEXT @PageSize ROWS ONLY;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetAlerts
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @DTTemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),@DTAlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),@DTUserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),@DTRoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),@DTCanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));
  SELECT TOP(5000) a.Id,a.AlertNo,a.TemplateId,a.AlertType,a.BranchCode,a.CustomerIdEncrypted,a.AccountIdEncrypted,a.Status,a.CurrentStageName,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc,a.DynamicDataJson
  FROM dbo.Alerts a WHERE a.TemplateId=@DTTemplateId AND (NULLIF(@DTAlertType,'') IS NULL OR a.AlertType=@DTAlertType) AND (@DTCanViewAll=1 OR a.BranchCode=@DTUserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND (wi.CompletedBy=JSON_VALUE(@strJson,'$.userName') OR wi.AssignedUserId=@UserId OR (wi.AssignedRoleCode=@DTRoleCode AND (wi.AssignedBranchCode='' OR wi.AssignedBranchCode=@DTUserBranch)))))
          AND (
            COALESCE(JSON_VALUE(@strJson,'$.recordView'),'All')='All'
            OR (JSON_VALUE(@strJson,'$.recordView')='Closed' AND a.Status='Closed')
            OR (JSON_VALUE(@strJson,'$.recordView')='ActionedByMe' AND EXISTS (
                SELECT 1 FROM dbo.WorkItems acted WHERE acted.AlertId=a.Id
                AND acted.Status='Completed' AND acted.CompletedBy=JSON_VALUE(@strJson,'$.userName')))
            OR (JSON_VALUE(@strJson,'$.recordView')='MyActionable'
                AND a.Status NOT IN ('Closed','Rejected','Cancelled') AND EXISTS (
                SELECT 1 FROM dbo.WorkItems pending WHERE pending.AlertId=a.Id
                AND pending.Status='Pending' AND pending.StageId=a.CurrentStageId
                AND (pending.AssignedUserId=JSON_VALUE(@strJson,'$.userId')
                    OR (NULLIF(LTRIM(RTRIM(pending.AssignedUserId)),'') IS NULL
                        AND pending.AssignedRoleCode=JSON_VALUE(@strJson,'$.roleCode')
                        AND (NULLIF(pending.AssignedBranchCode,'') IS NULL OR pending.AssignedBranchCode=JSON_VALUE(@strJson,'$.userBranchCode'))))))
          )
 ORDER BY a.CreatedAtUtc DESC; RETURN;
END
GO

