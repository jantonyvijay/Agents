IF OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs','U') IS NULL
    THROW 50001, 'Run CATS_V12_ATM_Workflow_Upgrade.sql before this migration.', 1;
GO

IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','ATM_ID') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD ATM_ID varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Penalty_Month') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Penalty_Month varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Penalty_Year') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Penalty_Year varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Settlement_Type') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Settlement_Type varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','CRM_Proactive_No') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD CRM_Proactive_No varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Transaction_Date') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Transaction_Date datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Customer_Complaint_Date') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Customer_Complaint_Date datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Customer_Acc_Credit_Date') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Customer_Acc_Credit_Date datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Acc_No') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Acc_No varchar(20) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','T_5_Calender_Days') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD T_5_Calender_Days datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Days') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Days int NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Penalty_Rs') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Penalty_Rs decimal(18,2) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Transaction_No') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Transaction_No varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Transaction_Amount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Transaction_Amount decimal(18,2) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Disputed_Amount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Disputed_Amount decimal(18,2) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','EJ_Error') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD EJ_Error varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','Narration') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD Narration varchar(500) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','UploadFileName') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD UploadFileName varchar(250) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','CreatedBy') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD CreatedBy varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','CreatedDate') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD CreatedDate datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','SourceDataJson') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD SourceDataJson nvarchar(max) NULL;
GO

IF OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs','U') IS NULL
    THROW 50002, 'Run CATS_V12_ATM_Workflow_Upgrade.sql before this migration.', 1;
GO
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','ATM_ID') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD ATM_ID varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Penalty_Month') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Penalty_Month varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Penalty_Year') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Penalty_Year varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','SourceDataJson') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD SourceDataJson nvarchar(max) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','UploadFileName') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD UploadFileName varchar(250) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','CreatedBy') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD CreatedBy varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','CreatedDate') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD CreatedDate datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Chargeback_Ref_No') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Chargeback_Ref_No varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Chargeback_Date') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Chargeback_Date datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Acquiring_Bank') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Acquiring_Bank varchar(500) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Issuing_Bank') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Issuing_Bank varchar(500) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Transaction_Date') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Transaction_Date datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Transaction_Time') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Transaction_Time varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','RRN_No') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD RRN_No varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','CARD_No') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD CARD_No varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Transaction_Amount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Transaction_Amount decimal(18,2) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Disputed_Amount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Disputed_Amount decimal(18,2) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Customer_Penalty') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Customer_Penalty varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Adjustment_Date') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Adjustment_Date datetime2 NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Adjustment_Type') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Adjustment_Type varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Adjustment_Time') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Adjustment_Time varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Narration') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Narration varchar(500) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','Adjustment_Amount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD Adjustment_Amount decimal(18,2) NULL;
GO

UPDATE dbo.tbl_ATM_Txn_Mntr_OnUs
SET ATM_ID=COALESCE(ATM_ID,ATMID), Penalty_Month=COALESCE(Penalty_Month,PenaltyMonth)
WHERE ATM_ID IS NULL OR Penalty_Month IS NULL;
UPDATE dbo.tbl_ATM_Txn_Mntr_OFFUs
SET ATM_ID=COALESCE(ATM_ID,ATMID), Penalty_Month=COALESCE(Penalty_Month,PenaltyMonth)
WHERE ATM_ID IS NULL OR Penalty_Month IS NULL;
UPDATE dbo.tbl_ATM_Txn_Mntr_OnUs SET ATMID=ATM_ID
WHERE ATMID IS NULL AND ATM_ID IS NOT NULL;
UPDATE dbo.tbl_ATM_Txn_Mntr_OnUs SET PenaltyMonth=Penalty_Month
WHERE PenaltyMonth IS NULL AND Penalty_Month IS NOT NULL;
UPDATE dbo.tbl_ATM_Txn_Mntr_OnUs SET PenaltyAmount=TRY_CONVERT(decimal(19,4),Penalty_Rs)
WHERE PenaltyAmount IS NULL AND Penalty_Rs IS NOT NULL;
UPDATE dbo.tbl_ATM_Txn_Mntr_OFFUs SET ATMID=ATM_ID
WHERE ATMID IS NULL AND ATM_ID IS NOT NULL;
UPDATE dbo.tbl_ATM_Txn_Mntr_OFFUs SET PenaltyMonth=Penalty_Month
WHERE PenaltyMonth IS NULL AND Penalty_Month IS NOT NULL;
UPDATE dbo.tbl_ATM_Txn_Mntr_OFFUs SET PenaltyAmount=TRY_CONVERT(decimal(19,4),Customer_Penalty)
WHERE PenaltyAmount IS NULL AND Customer_Penalty IS NOT NULL;
GO
