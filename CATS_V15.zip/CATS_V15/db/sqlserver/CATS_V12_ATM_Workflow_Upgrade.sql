IF OBJECT_ID('dbo.ATM_UploadBatches','U') IS NULL
CREATE TABLE dbo.ATM_UploadBatches(
 Id varchar(32) NOT NULL PRIMARY KEY, FileType varchar(30) NOT NULL, FileName nvarchar(260) NOT NULL,
 RowsJson nvarchar(max) NOT NULL, Status varchar(30) NOT NULL, UploadedBy varchar(100) NOT NULL,
 UploadedAtUtc datetime2 NOT NULL, DecidedBy varchar(100) NULL, DecidedAtUtc datetime2 NULL,
 DecisionRemarks nvarchar(2000) NULL
);
GO
IF OBJECT_ID('dbo.ATM_MasterEntries','U') IS NULL
CREATE TABLE dbo.ATM_MasterEntries(
 MasterType varchar(30) NOT NULL, RecordKey varchar(300) NOT NULL, ATMID varchar(100) NOT NULL,
 DataJson nvarchar(max) NOT NULL, SourceBatchId varchar(32) NOT NULL, UpdatedAtUtc datetime2 NOT NULL,
 CONSTRAINT PK_ATM_MasterEntries PRIMARY KEY(MasterType,RecordKey)
);
GO
IF OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs','U') IS NULL
CREATE TABLE dbo.tbl_ATM_Txn_Mntr_OnUs(
 AlertId varchar(32) NOT NULL PRIMARY KEY, ATMID varchar(100) NOT NULL, PenaltyMonth varchar(20) NOT NULL,
 PenaltyAmount decimal(19,4) NOT NULL, CaseCategory varchar(60) NULL, SourceBatchId varchar(32) NOT NULL,
 SourceRowNumber int NOT NULL, ReopenedFromAlertId varchar(32) NULL,
 CONSTRAINT FK_ATM_OnUs_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id),
 CONSTRAINT UQ_ATM_OnUs_Source UNIQUE(SourceBatchId,SourceRowNumber)
);
GO
IF OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs','U') IS NULL
CREATE TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs(
 AlertId varchar(32) NOT NULL PRIMARY KEY, ATMID varchar(100) NOT NULL, PenaltyMonth varchar(20) NOT NULL,
 PenaltyAmount decimal(19,4) NOT NULL, CaseCategory varchar(60) NULL, SourceBatchId varchar(32) NOT NULL,
 SourceRowNumber int NOT NULL, ReopenedFromAlertId varchar(32) NULL,
 CONSTRAINT FK_ATM_OffUs_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id),
 CONSTRAINT UQ_ATM_OffUs_Source UNIQUE(SourceBatchId,SourceRowNumber)
);
GO
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','AlertId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD AlertId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','ATMID') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD ATMID varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','PenaltyMonth') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD PenaltyMonth varchar(20) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','PenaltyAmount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD PenaltyAmount decimal(19,4) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','CaseCategory') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD CaseCategory varchar(60) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','SourceBatchId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD SourceBatchId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','SourceRowNumber') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD SourceRowNumber int NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','ReopenedFromAlertId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD ReopenedFromAlertId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','AlertId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD AlertId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','ATMID') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD ATMID varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','PenaltyMonth') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD PenaltyMonth varchar(20) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','PenaltyAmount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD PenaltyAmount decimal(19,4) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','CaseCategory') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD CaseCategory varchar(60) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','SourceBatchId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD SourceBatchId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','SourceRowNumber') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD SourceRowNumber int NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','ReopenedFromAlertId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD ReopenedFromAlertId varchar(32) NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs') AND name='UQ_ATM_OnUs_Source')
 CREATE UNIQUE INDEX UQ_ATM_OnUs_Source ON dbo.tbl_ATM_Txn_Mntr_OnUs(SourceBatchId,SourceRowNumber) WHERE SourceBatchId IS NOT NULL AND SourceRowNumber IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs') AND name='UQ_ATM_OffUs_Source')
 CREATE UNIQUE INDEX UQ_ATM_OffUs_Source ON dbo.tbl_ATM_Txn_Mntr_OFFUs(SourceBatchId,SourceRowNumber) WHERE SourceBatchId IS NOT NULL AND SourceRowNumber IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes i JOIN sys.index_columns ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id AND ic.key_ordinal=1 JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id WHERE i.object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs') AND i.is_unique=1 AND c.name='AlertId')
 CREATE UNIQUE INDEX UX_ATM_OnUs_AlertId ON dbo.tbl_ATM_Txn_Mntr_OnUs(AlertId) WHERE AlertId IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes i JOIN sys.index_columns ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id AND ic.key_ordinal=1 JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id WHERE i.object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs') AND i.is_unique=1 AND c.name='AlertId')
 CREATE UNIQUE INDEX UX_ATM_OffUs_AlertId ON dbo.tbl_ATM_Txn_Mntr_OFFUs(AlertId) WHERE AlertId IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs') AND name='FK_ATM_OnUs_Alert')
 ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD CONSTRAINT FK_ATM_OnUs_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id);
IF NOT EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs') AND name='FK_ATM_OffUs_Alert')
 ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD CONSTRAINT FK_ATM_OffUs_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id);
GO
IF OBJECT_ID('dbo.ATM_ReopenRequests','U') IS NULL
CREATE TABLE dbo.ATM_ReopenRequests(
 Id varchar(32) NOT NULL PRIMARY KEY, OriginalAlertId varchar(32) NOT NULL, RequestBatchId varchar(32) NOT NULL,
 RequestedBy varchar(100) NOT NULL, RequestedAtUtc datetime2 NOT NULL, Status varchar(30) NOT NULL,
 DecidedBy varchar(100) NULL, DecidedAtUtc datetime2 NULL, DecisionRemarks nvarchar(2000) NULL,
 NewAlertId varchar(32) NULL
);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name='IX_ATM_Master_ATMID') CREATE INDEX IX_ATM_Master_ATMID ON dbo.ATM_MasterEntries(MasterType,ATMID);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name='IX_ATM_OnUs_ATMID_Month') CREATE INDEX IX_ATM_OnUs_ATMID_Month ON dbo.tbl_ATM_Txn_Mntr_OnUs(ATMID,PenaltyMonth);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name='IX_ATM_OffUs_ATMID_Month') CREATE INDEX IX_ATM_OffUs_ATMID_Month ON dbo.tbl_ATM_Txn_Mntr_OFFUs(ATMID,PenaltyMonth);
GO
