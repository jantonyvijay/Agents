/*
  V18: Alerts are workflow/index records.  Business payloads live in the
  module record table (generic templates) or ATM transaction tables (ATM).
  This upgrade is idempotent and preserves workflow, audit and attachments.
*/
SET XACT_ABORT ON;
BEGIN TRANSACTION;

IF OBJECT_ID('dbo.AlertModuleRecords','U') IS NULL
CREATE TABLE dbo.AlertModuleRecords(
    AlertId varchar(32) NOT NULL,
    ModuleCode varchar(60) NOT NULL,
    DataJson nvarchar(max) NOT NULL CONSTRAINT DF_AlertModuleRecords_Data DEFAULT N'{}',
    UpdatedAtUtc datetime2 NOT NULL CONSTRAINT DF_AlertModuleRecords_Updated DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_AlertModuleRecords PRIMARY KEY(AlertId,ModuleCode),
    CONSTRAINT FK_AlertModuleRecords_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id)
);

INSERT INTO dbo.AlertModuleRecords(AlertId,ModuleCode,DataJson,UpdatedAtUtc)
SELECT a.Id,'GENERIC',COALESCE(NULLIF(a.DynamicDataJson,N''),N'{}'),SYSUTCDATETIME()
FROM dbo.Alerts a
WHERE a.AlertType NOT IN ('ATM_ONUS','ATM_OFFUS')
  AND NOT EXISTS(SELECT 1 FROM dbo.AlertModuleRecords m WHERE m.AlertId=a.Id AND m.ModuleCode='GENERIC');

-- Alerts currently sitting at the workflow's initiator (start) stage, e.g. ATMC
-- for ATM, dtUserReview for Desktop Due Diligence, input for the generic flow.
-- They remain editable, so their working data is kept on the alert as well.
SELECT DISTINCT a.Id AS AlertId
INTO #InitiatorAlerts
FROM dbo.Alerts a
INNER JOIN dbo.WorkflowInstances wi ON wi.AlertId=a.Id
INNER JOIN dbo.WorkflowDefinitions wd ON wd.Id=wi.WorkflowDefinitionId
WHERE ISJSON(wd.DefinitionJson)=1
  AND a.CurrentStageId=COALESCE(JSON_VALUE(wd.DefinitionJson,'$.startStageId'),JSON_VALUE(wd.DefinitionJson,'$.StartStageId'));

UPDATE t SET SourceDataJson=a.DynamicDataJson
FROM dbo.tbl_ATM_Txn_Mntr_OnUs t INNER JOIN dbo.Alerts a ON a.Id=t.AlertId
WHERE a.AlertType='ATM_ONUS' AND ISJSON(a.DynamicDataJson)=1;
UPDATE t SET SourceDataJson=a.DynamicDataJson
FROM dbo.tbl_ATM_Txn_Mntr_OFFUs t INNER JOIN dbo.Alerts a ON a.Id=t.AlertId
WHERE a.AlertType='ATM_OFFUS' AND ISJSON(a.DynamicDataJson)=1;

-- Back at the initiator: later-role actions no longer apply, so reset them to
-- Pending in both the typed columns and the retained source JSON.
UPDATE t SET
    RATC_Status='Pending', SH_Status='Pending', RH_Status='Pending', GH_Status='Pending',
    SourceDataJson=CASE WHEN ISJSON(t.SourceDataJson)=1 THEN
        JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(t.SourceDataJson,
            '$.RATC_Status','Pending'),'$.SH_Status','Pending'),'$.RH_Status','Pending'),'$.GH_Status','Pending')
        ELSE t.SourceDataJson END
FROM dbo.tbl_ATM_Txn_Mntr_OnUs t
INNER JOIN #InitiatorAlerts i ON i.AlertId=t.AlertId;

UPDATE a SET DynamicDataJson=
    JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(a.DynamicDataJson,
        '$.RATC_Status','Pending'),'$.SH_Status','Pending'),'$.RH_Status','Pending'),'$.GH_Status','Pending')
FROM dbo.Alerts a INNER JOIN #InitiatorAlerts i ON i.AlertId=a.Id
WHERE a.AlertType='ATM_ONUS' AND ISJSON(a.DynamicDataJson)=1;

UPDATE a SET DynamicDataJson=N'{}'
FROM dbo.Alerts a
WHERE a.DynamicDataJson<>N'{}'
  AND NOT EXISTS(SELECT 1 FROM #InitiatorAlerts i WHERE i.AlertId=a.Id);

DROP TABLE #InitiatorAlerts;
CREATE INDEX IX_AlertModuleRecords_Module ON dbo.AlertModuleRecords(ModuleCode,UpdatedAtUtc);

CREATE OR ALTER PROCEDURE dbo.USP_AlertModule_Get
    @AlertId varchar(32), @ModuleCode varchar(60)
AS
    SELECT AlertId,ModuleCode,DataJson,UpdatedAtUtc FROM dbo.AlertModuleRecords
    WHERE AlertId=@AlertId AND ModuleCode=@ModuleCode;
GO
CREATE OR ALTER PROCEDURE dbo.USP_AlertModule_Upsert
    @AlertId varchar(32), @ModuleCode varchar(60), @DataJson nvarchar(max)
AS
BEGIN
    SET XACT_ABORT ON;
    MERGE dbo.AlertModuleRecords AS target
    USING (SELECT @AlertId AlertId,@ModuleCode ModuleCode) AS source
    ON target.AlertId=source.AlertId AND target.ModuleCode=source.ModuleCode
    WHEN MATCHED THEN UPDATE SET DataJson=COALESCE(@DataJson,N'{}'),UpdatedAtUtc=SYSUTCDATETIME()
    WHEN NOT MATCHED THEN INSERT(AlertId,ModuleCode,DataJson,UpdatedAtUtc)
         VALUES(@AlertId,@ModuleCode,COALESCE(@DataJson,N'{}'),SYSUTCDATETIME());
END;
GO
COMMIT TRANSACTION;
