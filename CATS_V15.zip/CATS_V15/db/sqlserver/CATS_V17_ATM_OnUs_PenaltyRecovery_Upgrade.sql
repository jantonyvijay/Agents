IF OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs','U') IS NULL
    THROW 50001, 'Run the ATM workflow upgrade before applying this OnUs penalty and recovery migration.', 1;
GO

IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','NoPenaltyApplicable') IS NULL
    ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD NoPenaltyApplicable bit NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','MailDate') IS NULL
    ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD MailDate datetime2 NULL;
GO
