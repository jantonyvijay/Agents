IF OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs','U') IS NULL
   OR OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs','U') IS NULL
    THROW 50001, 'Create the OnUs and OffUs legacy tables before applying this CATS integration migration.', 1;
GO

IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','AlertId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD AlertId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','ATMID') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD ATMID varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','PenaltyMonth') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD PenaltyMonth varchar(20) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','PenaltyAmount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD PenaltyAmount decimal(19,4) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','CaseCategory') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD CaseCategory varchar(60) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','SourceBatchId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD SourceBatchId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','SourceRowNumber') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD SourceRowNumber int NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','ReopenedFromAlertId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD ReopenedFromAlertId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OnUs','SourceDataJson') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD SourceDataJson nvarchar(max) NULL;

IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','AlertId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD AlertId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','ATMID') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD ATMID varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','PenaltyMonth') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD PenaltyMonth varchar(20) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','PenaltyAmount') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD PenaltyAmount decimal(19,4) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','CaseCategory') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD CaseCategory varchar(60) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','SourceBatchId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD SourceBatchId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','SourceRowNumber') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD SourceRowNumber int NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','ReopenedFromAlertId') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD ReopenedFromAlertId varchar(32) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','SourceDataJson') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD SourceDataJson nvarchar(max) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_OFFUs','EJError') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD EJError varchar(250) NULL;
GO

IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs') AND name='UQ_ATM_OnUs_Source')
    CREATE UNIQUE INDEX UQ_ATM_OnUs_Source ON dbo.tbl_ATM_Txn_Mntr_OnUs(SourceBatchId,SourceRowNumber)
        WHERE SourceBatchId IS NOT NULL AND SourceRowNumber IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs') AND name='UQ_ATM_OffUs_Source')
    CREATE UNIQUE INDEX UQ_ATM_OffUs_Source ON dbo.tbl_ATM_Txn_Mntr_OFFUs(SourceBatchId,SourceRowNumber)
        WHERE SourceBatchId IS NOT NULL AND SourceRowNumber IS NOT NULL;
IF NOT EXISTS(
    SELECT 1 FROM sys.indexes i
    JOIN sys.index_columns ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id AND ic.key_ordinal=1
    JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
    WHERE i.object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs') AND i.is_unique=1 AND c.name='AlertId')
    CREATE UNIQUE INDEX UX_ATM_OnUs_AlertId ON dbo.tbl_ATM_Txn_Mntr_OnUs(AlertId) WHERE AlertId IS NOT NULL;
IF NOT EXISTS(
    SELECT 1 FROM sys.indexes i
    JOIN sys.index_columns ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id AND ic.key_ordinal=1
    JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
    WHERE i.object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs') AND i.is_unique=1 AND c.name='AlertId')
    CREATE UNIQUE INDEX UX_ATM_OffUs_AlertId ON dbo.tbl_ATM_Txn_Mntr_OFFUs(AlertId) WHERE AlertId IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs') AND name='FK_ATM_OnUs_Alert')
    ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OnUs ADD CONSTRAINT FK_ATM_OnUs_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id);
IF NOT EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs') AND name='FK_ATM_OffUs_Alert')
    ALTER TABLE dbo.tbl_ATM_Txn_Mntr_OFFUs ADD CONSTRAINT FK_ATM_OffUs_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OnUs') AND name='IX_ATM_OnUs_ATMID_Month')
    CREATE INDEX IX_ATM_OnUs_ATMID_Month ON dbo.tbl_ATM_Txn_Mntr_OnUs(ATMID,PenaltyMonth);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_OFFUs') AND name='IX_ATM_OffUs_ATMID_Month')
    CREATE INDEX IX_ATM_OffUs_ATMID_Month ON dbo.tbl_ATM_Txn_Mntr_OFFUs(ATMID,PenaltyMonth);
GO
