/* =====================================================================================
   CATS V19 - Convert GUID varchar(32) identifiers to BIGINT (SQL Server)

   What this script does
   - Creates dbo.seq_CatsId. Every new row id is taken from this single sequence.
   - Adds a bigint Id to every table that used a GUID Id and keeps the original GUID in
     a new LegacyGuid column (unique, filtered) so old links/bookmarks/audit text can still
     be mapped to the new numeric id.
   - Converts every referencing column (AlertId, TemplateId, UserId, ...) to bigint by
     joining on LegacyGuid, then drops the old varchar columns.
   - Drops and recreates the primary keys, unique constraints, indexes and foreign keys that
     touch the converted columns.
   - Is re-runnable: when dbo.Alerts.Id is already bigint nothing is changed.
   - Runs in one transaction; any failure rolls everything back.

   Before running: take a full backup and stop the CATS API / workers.
   After running:  start CATS once (or run db/sqlserver/schema.sql) so the stored
                   procedures are refreshed.
   ===================================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

DECLARE @alreadyMigrated bit = CASE WHEN EXISTS(
    SELECT 1 FROM sys.columns c
    WHERE c.object_id = OBJECT_ID(N'dbo.Alerts') AND c.name = N'Id' AND c.system_type_id = 127) THEN 1 ELSE 0 END;

IF OBJECT_ID(N'dbo.Alerts', N'U') IS NULL
BEGIN
    PRINT N'dbo.Alerts does not exist - nothing to migrate.';
END
ELSE IF @alreadyMigrated = 1
BEGIN
    PRINT N'CATS V19: identifiers are already bigint - nothing to do.';
END
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;

    IF NOT EXISTS (SELECT 1 FROM sys.sequences WHERE name = N'seq_CatsId' AND schema_id = SCHEMA_ID(N'dbo'))
        CREATE SEQUENCE dbo.seq_CatsId AS bigint START WITH 1 INCREMENT BY 1 CACHE 100;

    /* ---------- 1. Which tables/columns are converted ---------- */
    CREATE TABLE #PkTable(TableName sysname NOT NULL PRIMARY KEY);
    INSERT #PkTable(TableName) VALUES
        (N'AgingBuckets'),(N'AlertQueries'),(N'Alerts'),(N'AlertTypeAccess'),(N'ATM_ReopenRequests'),
        (N'ATM_UploadBatches'),(N'Attachments'),(N'AuditLog'),(N'CatsUsers'),(N'DashboardWidgetMaster'),
        (N'DataScopeMaster'),(N'IngestionConfiguration'),(N'IngestionConnector'),(N'IngestionRun'),
        (N'MailConfiguration'),(N'MailQueue'),(N'MailTemplate'),(N'MenuMaster'),(N'TemplateDashboardMaster'),
        (N'Templates'),(N'WorkflowDefinitions'),(N'WorkflowInstances'),(N'WorkItems');

    CREATE TABLE #IdCol(
        TableName sysname NOT NULL, ColumnName sysname NOT NULL, RefTable sysname NULL,
        IsNullable bit NULL, IsPk bit NOT NULL, PRIMARY KEY(TableName, ColumnName));

    INSERT #IdCol(TableName, ColumnName, RefTable, IsPk)
    SELECT TableName, N'Id', NULL, 1 FROM #PkTable;

    INSERT #IdCol(TableName, ColumnName, RefTable, IsPk) VALUES
        (N'AlertModuleRecords',N'AlertId',N'Alerts',0),
        (N'AlertQueries',N'AlertId',N'Alerts',0),
        (N'Alerts',N'TemplateId',N'Templates',0),
        (N'ATM_MasterEntries',N'SourceBatchId',N'ATM_UploadBatches',0),
        (N'ATM_ReopenRequests',N'OriginalAlertId',N'Alerts',0),
        (N'ATM_ReopenRequests',N'RequestBatchId',N'ATM_UploadBatches',0),
        (N'ATM_ReopenRequests',N'NewAlertId',N'Alerts',0),
        (N'Attachments',N'AlertId',N'Alerts',0),
        (N'AuditLog',N'AlertId',N'Alerts',0),
        (N'AuditLog',N'UserId',N'CatsUsers',0),
        (N'DashboardWidgetRoleMapping',N'WidgetId',N'DashboardWidgetMaster',0),
        (N'IngestionConfiguration',N'TemplateId',N'Templates',0),
        (N'IngestionConfiguration',N'ConnectorId',N'IngestionConnector',0),
        (N'IngestionRun',N'ConfigurationId',N'IngestionConfiguration',0),
        (N'IngestionStaging',N'RunId',N'IngestionRun',0),
        (N'IngestionStaging',N'TemplateId',N'Templates',0),
        (N'MailQueue',N'AlertId',N'Alerts',0),
        (N'MailTemplate',N'TemplateId',N'Templates',0),
        (N'MenuMaster',N'ParentId',N'MenuMaster',0),
        (N'MenuRoleMapping',N'MenuId',N'MenuMaster',0),
        (N'tbl_ATM_Txn_Mntr_OFFUs',N'AlertId',N'Alerts',0),
        (N'tbl_ATM_Txn_Mntr_OFFUs',N'SourceBatchId',N'ATM_UploadBatches',0),
        (N'tbl_ATM_Txn_Mntr_OFFUs',N'ReopenedFromAlertId',N'Alerts',0),
        (N'tbl_ATM_Txn_Mntr_OnUs',N'AlertId',N'Alerts',0),
        (N'tbl_ATM_Txn_Mntr_OnUs',N'SourceBatchId',N'ATM_UploadBatches',0),
        (N'tbl_ATM_Txn_Mntr_OnUs',N'ReopenedFromAlertId',N'Alerts',0),
        (N'TemplateDashboardMaster',N'TemplateId',N'Templates',0),
        (N'TemplateDashboardRoleMapping',N'DashboardId',N'TemplateDashboardMaster',0),
        (N'Templates',N'PublishedWorkflowId',N'WorkflowDefinitions',0),
        (N'UserPermissionMapping',N'UserId',N'CatsUsers',0),
        (N'WorkflowDefinitions',N'TemplateId',N'Templates',0),
        (N'WorkflowInstances',N'AlertId',N'Alerts',0),
        (N'WorkflowInstances',N'WorkflowDefinitionId',N'WorkflowDefinitions',0),
        (N'WorkItems',N'AlertId',N'Alerts',0),
        (N'WorkItems',N'WorkflowInstanceId',N'WorkflowInstances',0),
        (N'WorkItems',N'AssignedUserId',N'CatsUsers',0);

    -- Older databases may not have every table/column; keep only varchar columns that exist.
    DELETE d FROM #IdCol d
    WHERE NOT EXISTS (SELECT 1 FROM sys.columns c
                      WHERE c.object_id = OBJECT_ID(N'dbo.' + QUOTENAME(d.TableName))
                        AND c.name = d.ColumnName AND c.system_type_id = 167);
    DELETE FROM #PkTable WHERE NOT EXISTS (SELECT 1 FROM #IdCol d WHERE d.TableName = #PkTable.TableName AND d.ColumnName = N'Id');
    DELETE FROM #IdCol WHERE RefTable IS NOT NULL AND RefTable NOT IN (SELECT TableName FROM #PkTable);

    UPDATE d SET IsNullable = c.is_nullable
    FROM #IdCol d JOIN sys.columns c ON c.object_id = OBJECT_ID(N'dbo.' + QUOTENAME(d.TableName)) AND c.name = d.ColumnName;

    -- A template-specific mail template whose Template no longer exists is dead data (it must not
    -- turn into a second "global" row), so it is removed together with the other orphans below.
    CREATE TABLE #DeleteOrphan(TableName sysname NOT NULL, ColumnName sysname NOT NULL);
    INSERT #DeleteOrphan VALUES (N'MailTemplate', N'TemplateId');

    CREATE TABLE #Affected(TableName sysname NOT NULL PRIMARY KEY);
    INSERT #Affected SELECT DISTINCT TableName FROM #IdCol;

    /* ---------- 2. Build the ordered plan ---------- */
    CREATE TABLE #Plan(Phase int NOT NULL, Seq int IDENTITY(1,1) NOT NULL, Stmt nvarchar(max) NOT NULL);

    -- 10: drop foreign keys that touch an affected table
    INSERT #Plan(Phase, Stmt)
    SELECT 10, N'ALTER TABLE dbo.' + QUOTENAME(pt.name) + N' DROP CONSTRAINT ' + QUOTENAME(fk.name)
    FROM sys.foreign_keys fk
    JOIN sys.tables pt ON pt.object_id = fk.parent_object_id
    JOIN sys.tables rt ON rt.object_id = fk.referenced_object_id
    WHERE pt.schema_id = SCHEMA_ID(N'dbo') AND rt.schema_id = SCHEMA_ID(N'dbo')
      AND (pt.name IN (SELECT TableName FROM #Affected) OR rt.name IN (SELECT TableName FROM #Affected));

    -- 70: recreate them
    INSERT #Plan(Phase, Stmt)
    SELECT 70,
        N'ALTER TABLE dbo.' + QUOTENAME(pt.name) + N' ADD CONSTRAINT ' + QUOTENAME(fk.name)
        + N' FOREIGN KEY (' + pc.cols + N') REFERENCES dbo.' + QUOTENAME(rt.name) + N' (' + rc.cols + N')'
        + CASE WHEN fk.delete_referential_action = 0 THEN N'' ELSE N' ON DELETE ' + REPLACE(fk.delete_referential_action_desc, N'_', N' ') END
        + CASE WHEN fk.update_referential_action = 0 THEN N'' ELSE N' ON UPDATE ' + REPLACE(fk.update_referential_action_desc, N'_', N' ') END
    FROM sys.foreign_keys fk
    JOIN sys.tables pt ON pt.object_id = fk.parent_object_id
    JOIN sys.tables rt ON rt.object_id = fk.referenced_object_id
    CROSS APPLY (SELECT STUFF((SELECT N',' + QUOTENAME(c.name)
                               FROM sys.foreign_key_columns k JOIN sys.columns c ON c.object_id = k.parent_object_id AND c.column_id = k.parent_column_id
                               WHERE k.constraint_object_id = fk.object_id ORDER BY k.constraint_column_id
                               FOR XML PATH(N''), TYPE).value('.', 'nvarchar(max)'), 1, 1, N'')) pc(cols)
    CROSS APPLY (SELECT STUFF((SELECT N',' + QUOTENAME(c.name)
                               FROM sys.foreign_key_columns k JOIN sys.columns c ON c.object_id = k.referenced_object_id AND c.column_id = k.referenced_column_id
                               WHERE k.constraint_object_id = fk.object_id ORDER BY k.constraint_column_id
                               FOR XML PATH(N''), TYPE).value('.', 'nvarchar(max)'), 1, 1, N'')) rc(cols)
    WHERE pt.schema_id = SCHEMA_ID(N'dbo') AND rt.schema_id = SCHEMA_ID(N'dbo')
      AND (pt.name IN (SELECT TableName FROM #Affected) OR rt.name IN (SELECT TableName FROM #Affected));

    -- Indexes / PK / unique constraints that contain a converted column
    SELECT t.object_id AS TableId, t.name AS TableName, i.index_id, i.name AS IndexName, i.type AS IndexType,
           i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition
    INTO #Idx
    FROM sys.indexes i JOIN sys.tables t ON t.object_id = i.object_id
    WHERE t.schema_id = SCHEMA_ID(N'dbo') AND t.name IN (SELECT TableName FROM #Affected)
      AND i.type IN (1, 2) AND i.is_hypothetical = 0
      AND EXISTS (SELECT 1 FROM sys.index_columns ic JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                  JOIN #IdCol d ON d.TableName = t.name AND d.ColumnName = c.name
                  WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id);

    -- 20: drop plain indexes, 25: drop PK / unique constraints
    INSERT #Plan(Phase, Stmt)
    SELECT CASE WHEN is_primary_key = 1 OR is_unique_constraint = 1 THEN 25 ELSE 20 END,
           CASE WHEN is_primary_key = 1 OR is_unique_constraint = 1
                THEN N'ALTER TABLE dbo.' + QUOTENAME(TableName) + N' DROP CONSTRAINT ' + QUOTENAME(IndexName)
                ELSE N'DROP INDEX ' + QUOTENAME(IndexName) + N' ON dbo.' + QUOTENAME(TableName) END
    FROM #Idx;

    -- 60: recreate PK / unique constraints, 65: recreate indexes
    INSERT #Plan(Phase, Stmt)
    SELECT CASE WHEN x.is_primary_key = 1 OR x.is_unique_constraint = 1 THEN 60 ELSE 65 END,
           CASE WHEN x.is_primary_key = 1 OR x.is_unique_constraint = 1
                THEN N'ALTER TABLE dbo.' + QUOTENAME(x.TableName) + N' ADD CONSTRAINT ' + QUOTENAME(x.IndexName)
                     + CASE WHEN x.is_primary_key = 1 THEN N' PRIMARY KEY ' ELSE N' UNIQUE ' END
                     + CASE WHEN x.IndexType = 1 THEN N'CLUSTERED ' ELSE N'NONCLUSTERED ' END
                     + N'(' + k.cols + N')'
                ELSE N'CREATE ' + CASE WHEN x.is_unique = 1 THEN N'UNIQUE ' ELSE N'' END
                     + CASE WHEN x.IndexType = 1 THEN N'CLUSTERED ' ELSE N'NONCLUSTERED ' END
                     + N'INDEX ' + QUOTENAME(x.IndexName) + N' ON dbo.' + QUOTENAME(x.TableName) + N'(' + k.cols + N')'
                     + CASE WHEN inc.cols IS NULL THEN N'' ELSE N' INCLUDE (' + inc.cols + N')' END
                     + CASE WHEN x.filter_definition IS NULL THEN N'' ELSE N' WHERE ' + x.filter_definition END
           END
    FROM #Idx x
    CROSS APPLY (SELECT STUFF((SELECT N',' + QUOTENAME(c.name) + CASE WHEN ic.is_descending_key = 1 THEN N' DESC' ELSE N' ASC' END
                               FROM sys.index_columns ic JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                               WHERE ic.object_id = x.TableId AND ic.index_id = x.index_id AND ic.is_included_column = 0
                               ORDER BY ic.key_ordinal FOR XML PATH(N''), TYPE).value('.', 'nvarchar(max)'), 1, 1, N'')) k(cols)
    CROSS APPLY (SELECT STUFF((SELECT N',' + QUOTENAME(c.name)
                               FROM sys.index_columns ic JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                               WHERE ic.object_id = x.TableId AND ic.index_id = x.index_id AND ic.is_included_column = 1
                               ORDER BY ic.index_column_id FOR XML PATH(N''), TYPE).value('.', 'nvarchar(max)'), 1, 1, N'')) inc(cols);

    -- 30/31: LegacyGuid + new bigint key on every GUID table
    INSERT #Plan(Phase, Stmt)
    SELECT 30, N'ALTER TABLE dbo.' + QUOTENAME(TableName) + N' ADD LegacyGuid varchar(32) NULL, Id_n bigint NULL' FROM #PkTable;
    INSERT #Plan(Phase, Stmt)
    SELECT 31, N'UPDATE dbo.' + QUOTENAME(TableName) + N' SET LegacyGuid = Id' FROM #PkTable;

    -- 32: assign new ids chronologically per table
    INSERT #Plan(Phase, Stmt)
    SELECT 32,
        N'SELECT t.Id AS OldId, NEXT VALUE FOR dbo.seq_CatsId OVER (ORDER BY '
        + ISNULL((SELECT TOP (1) N't.' + QUOTENAME(c.name) + N', ' FROM sys.columns c
                  WHERE c.object_id = OBJECT_ID(N'dbo.' + QUOTENAME(p.TableName))
                    AND c.name IN (N'CreatedAtUtc', N'RaisedAtUtc', N'UploadedAtUtc', N'StartedAtUtc')
                  ORDER BY CASE c.name WHEN N'CreatedAtUtc' THEN 1 WHEN N'RaisedAtUtc' THEN 2 WHEN N'UploadedAtUtc' THEN 3 ELSE 4 END), N'')
        + N't.Id) AS NewId INTO #m FROM dbo.' + QUOTENAME(p.TableName) + N' t; '
        + N'UPDATE x SET Id_n = m.NewId FROM dbo.' + QUOTENAME(p.TableName) + N' x JOIN #m m ON m.OldId = x.Id;'
    FROM #PkTable p;

    -- 40/41/42: new bigint column per referencing column, filled through LegacyGuid
    INSERT #Plan(Phase, Stmt)
    SELECT 40, N'ALTER TABLE dbo.' + QUOTENAME(TableName) + N' ADD ' + QUOTENAME(ColumnName + N'_n') + N' bigint NULL'
    FROM #IdCol WHERE IsPk = 0;
    INSERT #Plan(Phase, Stmt)
    SELECT 41, N'UPDATE c SET ' + QUOTENAME(ColumnName + N'_n') + N' = p.Id_n FROM dbo.' + QUOTENAME(TableName)
        + N' c JOIN dbo.' + QUOTENAME(RefTable) + N' p ON p.LegacyGuid = c.' + QUOTENAME(ColumnName)
    FROM #IdCol WHERE IsPk = 0;
    -- A reopen request stores its own id as RequestBatchId, so it may not match an upload batch: fall back to itself.
    IF EXISTS (SELECT 1 FROM #IdCol WHERE TableName = N'ATM_ReopenRequests' AND ColumnName = N'RequestBatchId')
        INSERT #Plan(Phase, Stmt) VALUES (41,
            N'UPDATE r SET RequestBatchId_n = COALESCE(r.RequestBatchId_n, p.Id_n, r.Id_n) FROM dbo.ATM_ReopenRequests r LEFT JOIN dbo.ATM_ReopenRequests p ON p.LegacyGuid = r.RequestBatchId');
    INSERT #Plan(Phase, Stmt)
    SELECT 42,
        CASE WHEN TableName = N'AuditLog' AND ColumnName = N'UserId'
             THEN N'UPDATE dbo.AuditLog SET UserId_n = 0 WHERE UserId_n IS NULL;'
             ELSE N'DECLARE @c int = (SELECT COUNT(*) FROM dbo.' + QUOTENAME(TableName) + N' WHERE ' + QUOTENAME(ColumnName + N'_n') + N' IS NULL); '
                + N'IF @c > 0 BEGIN RAISERROR(N''WARNING: removed %d orphan row(s) from dbo.' + TableName + N' (' + ColumnName + N' has no matching parent).'', 0, 1, @c) WITH NOWAIT; '
                + N'DELETE FROM dbo.' + QUOTENAME(TableName) + N' WHERE ' + QUOTENAME(ColumnName + N'_n') + N' IS NULL; END'
        END
    FROM #IdCol WHERE IsPk = 0 AND IsNullable = 0;
    INSERT #Plan(Phase, Stmt)
    SELECT 42,
        N'DECLARE @c int = (SELECT COUNT(*) FROM dbo.' + QUOTENAME(i.TableName) + N' WHERE ISNULL(' + QUOTENAME(i.ColumnName) + N', '''') <> '''' AND '
        + QUOTENAME(i.ColumnName + N'_n') + N' IS NULL); '
        + N'IF @c > 0 BEGIN RAISERROR(N''WARNING: removed %d orphan row(s) from dbo.' + i.TableName + N' (' + i.ColumnName + N' has no matching parent).'', 0, 1, @c) WITH NOWAIT; '
        + N'DELETE FROM dbo.' + QUOTENAME(i.TableName) + N' WHERE ISNULL(' + QUOTENAME(i.ColumnName) + N', '''') <> '''' AND ' + QUOTENAME(i.ColumnName + N'_n') + N' IS NULL; END'
    FROM #IdCol i JOIN #DeleteOrphan o ON o.TableName = i.TableName AND o.ColumnName = i.ColumnName;

    -- 50/51/52: swap the new columns in
    INSERT #Plan(Phase, Stmt)
    SELECT 50, N'ALTER TABLE dbo.' + QUOTENAME(TableName) + N' DROP COLUMN ' + QUOTENAME(ColumnName) FROM #IdCol;
    INSERT #Plan(Phase, Stmt)
    SELECT 51, N'EXEC sys.sp_rename N''dbo.' + TableName + N'.' + ColumnName + N'_n'', N''' + ColumnName + N''', N''COLUMN'''
    FROM #IdCol;
    INSERT #Plan(Phase, Stmt)
    SELECT 52, N'ALTER TABLE dbo.' + QUOTENAME(TableName) + N' ALTER COLUMN ' + QUOTENAME(ColumnName) + N' bigint NOT NULL'
    FROM #IdCol WHERE IsNullable = 0;

    -- 80: LegacyGuid lookup index and sequence default on the new key
    INSERT #Plan(Phase, Stmt)
    SELECT 80, N'CREATE UNIQUE INDEX ' + QUOTENAME(N'UX_' + TableName + N'_LegacyGuid') + N' ON dbo.' + QUOTENAME(TableName)
        + N'(LegacyGuid) WHERE LegacyGuid IS NOT NULL' FROM #PkTable;
    INSERT #Plan(Phase, Stmt)
    SELECT 81, N'ALTER TABLE dbo.' + QUOTENAME(TableName) + N' ADD CONSTRAINT ' + QUOTENAME(N'DF_' + TableName + N'_Id')
        + N' DEFAULT (NEXT VALUE FOR dbo.seq_CatsId) FOR Id' FROM #PkTable;

    /* ---------- 3. Execute the plan ---------- */
    DECLARE @stmt nvarchar(max), @n int = 0;
    DECLARE planCursor CURSOR LOCAL FAST_FORWARD FOR SELECT Stmt FROM #Plan ORDER BY Phase, Seq;
    OPEN planCursor;
    FETCH NEXT FROM planCursor INTO @stmt;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @n += 1;
        EXEC sys.sp_executesql @stmt;
        FETCH NEXT FROM planCursor INTO @stmt;
    END
    CLOSE planCursor;
    DEALLOCATE planCursor;

    /* ---------- 3b. JSON documents that embed user ids ---------- */
    -- Per-alert stage assignments (_assignments.<stage>.userId) and template assignment rules (targetUserId)
    -- keep the user id inside JSON, so the old GUID is replaced with the new numeric id there as well.
    IF OBJECT_ID(N'dbo.CatsUsers', N'U') IS NOT NULL
    BEGIN
        DECLARE @userId bigint, @userGuid varchar(32), @userText varchar(20), @jsonSql nvarchar(max);
        CREATE TABLE #Users(Id bigint NOT NULL, LegacyGuid varchar(32) NOT NULL);
        EXEC sys.sp_executesql N'INSERT #Users(Id, LegacyGuid) SELECT Id, LegacyGuid FROM dbo.CatsUsers WHERE LegacyGuid IS NOT NULL';
        DECLARE userCursor CURSOR LOCAL FAST_FORWARD FOR SELECT Id, LegacyGuid FROM #Users;
        OPEN userCursor;
        FETCH NEXT FROM userCursor INTO @userId, @userGuid;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @userText = CAST(@userId AS varchar(20));
            IF OBJECT_ID(N'dbo.AlertModuleRecords', N'U') IS NOT NULL
            BEGIN
                SET @jsonSql = N'UPDATE dbo.AlertModuleRecords SET DataJson = REPLACE(REPLACE(DataJson, ''"userId":"'' + @g + ''"'', ''"userId":'' + @t), ''"userId": "'' + @g + ''"'', ''"userId": '' + @t) WHERE DataJson LIKE ''%'' + @g + ''%''';
                EXEC sys.sp_executesql @jsonSql, N'@g varchar(32), @t varchar(20)', @g = @userGuid, @t = @userText;
            END
            IF OBJECT_ID(N'dbo.Templates', N'U') IS NOT NULL
            BEGIN
                SET @jsonSql = N'UPDATE dbo.Templates SET AssignmentRulesJson = REPLACE(REPLACE(AssignmentRulesJson, ''"targetUserId":"'' + @g + ''"'', ''"targetUserId":'' + @t), ''"targetUserId": "'' + @g + ''"'', ''"targetUserId": '' + @t) WHERE AssignmentRulesJson LIKE ''%'' + @g + ''%''';
                EXEC sys.sp_executesql @jsonSql, N'@g varchar(32), @t varchar(20)', @g = @userGuid, @t = @userText;
            END
            FETCH NEXT FROM userCursor INTO @userId, @userGuid;
        END
        CLOSE userCursor;
        DEALLOCATE userCursor;
    END

    -- Sequence continues after the migrated ids; each CATS process reserves blocks of 100.
    DECLARE @next bigint = ISNULL((SELECT CAST(current_value AS bigint) FROM sys.sequences WHERE name = N'seq_CatsId' AND schema_id = SCHEMA_ID(N'dbo')), 0) + 1;
    DECLARE @alter nvarchar(200) = N'ALTER SEQUENCE dbo.seq_CatsId RESTART WITH ' + CAST(@next AS nvarchar(30)) + N' INCREMENT BY 100';
    EXEC sys.sp_executesql @alter;

    /* ---------- 4. Verify ---------- */
    DECLARE @bad int = 0, @tbl sysname, @vsql nvarchar(max), @cnt int;
    DECLARE chk CURSOR LOCAL FAST_FORWARD FOR SELECT TableName FROM #PkTable;
    OPEN chk; FETCH NEXT FROM chk INTO @tbl;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @vsql = N'SELECT @c = COUNT(*) FROM dbo.' + QUOTENAME(@tbl) + N' WHERE Id IS NULL OR LegacyGuid IS NULL';
        EXEC sys.sp_executesql @vsql, N'@c int OUTPUT', @c = @cnt OUTPUT;
        IF @cnt > 0 SET @bad += 1;
        FETCH NEXT FROM chk INTO @tbl;
    END
    CLOSE chk; DEALLOCATE chk;
    IF @bad > 0 THROW 50019, 'CATS V19 verification failed: rows without a new Id or LegacyGuid. Transaction rolled back.', 1;

    COMMIT TRANSACTION;
    DECLARE @tables int = (SELECT COUNT(*) FROM #PkTable);
    PRINT N'CATS V19 completed: ' + CAST(@n AS nvarchar(20)) + N' steps executed, ' + CAST(@tables AS nvarchar(20)) + N' tables converted.';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        DECLARE @msg nvarchar(2048) = N'CATS V19 failed and was rolled back: ' + ERROR_MESSAGE() + N' (line ' + CAST(ERROR_LINE() AS nvarchar(10)) + N')';
        THROW 50020, @msg, 1;
    END CATCH
END
GO
