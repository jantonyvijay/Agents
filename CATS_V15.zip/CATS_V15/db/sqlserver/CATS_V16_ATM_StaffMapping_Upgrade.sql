-- CATS V16: ATM Staff Mapping master (Masters > ATM > Staff Mapping) and the database-driven menu.
-- Safe to re-run. The API also applies this at startup through schema.sql, and seeds MenuMaster on first start.
IF OBJECT_ID('dbo.MenuMaster','U') IS NULL
CREATE TABLE dbo.MenuMaster(
 Id varchar(32) NOT NULL PRIMARY KEY, ParentId varchar(32) NULL, Code varchar(100) NOT NULL UNIQUE,
 Label nvarchar(150) NOT NULL, Title nvarchar(200) NULL, Description nvarchar(300) NULL, Icon varchar(40) NULL,
 ViewKey varchar(60) NULL, PermissionCode varchar(100) NULL, DisplayOrder int NOT NULL DEFAULT 100, IsActive int NOT NULL DEFAULT 1
);
GO
IF OBJECT_ID('dbo.AlertTypeAccess','U') IS NULL
CREATE TABLE dbo.AlertTypeAccess(
 Id varchar(32) NOT NULL PRIMARY KEY, TemplateCode varchar(100) NOT NULL, RoleCode varchar(60) NULL,
 PermissionCode varchar(100) NULL, IsActive int NOT NULL DEFAULT 1
);
GO
IF OBJECT_ID('dbo.MenuRoleMapping','U') IS NULL
CREATE TABLE dbo.MenuRoleMapping(
 MenuId varchar(32) NOT NULL, RoleCode varchar(60) NOT NULL, PRIMARY KEY(MenuId,RoleCode)
);
GO
IF OBJECT_ID('dbo.ATM_MasterSettings','U') IS NULL
CREATE TABLE dbo.ATM_MasterSettings(
 SettingKey varchar(60) NOT NULL PRIMARY KEY, SettingJson nvarchar(max) NOT NULL,
 UpdatedBy varchar(100) NULL, UpdatedAtUtc datetime2 NOT NULL
);
GO
IF OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_MappingMaster','U') IS NULL
CREATE TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster(
 ID numeric(36,0) IDENTITY(1,1) NOT NULL PRIMARY KEY,
 ATM_ID varchar(250) NULL, ATMC_EMPCode varchar(50) NULL, ATMC_EMPCode_BK varchar(50) NULL, RATC_EMPCode varchar(50) NULL,
 RATC_EMPCode_BK varchar(50) NULL, SH_EMPCode varchar(50) NULL, WBO_RH_EMPCode varchar(50) NULL, STATE varchar(250) NULL,
 RecordStatus varchar(10) NULL, UploadFileName varchar(250) NULL, CreatedBy varchar(50) NULL, CreatedDate datetime NULL,
 ModifiedBy varchar(50) NULL, ModifiedDate datetime NULL, ApprovedBy varchar(50) NULL, ApprovedDate datetime NULL
);
GO
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','GH_EMPCode') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD GH_EMPCode varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','RH_EMPCode') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD RH_EMPCode varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','GH_EMPCode_BK') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD GH_EMPCode_BK varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','RH_EMPCode_BK') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD RH_EMPCode_BK varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','GH_EMPCode1') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD GH_EMPCode1 varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','RH_EMPCode1') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD RH_EMPCode1 varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','GH_EMPCode1_BK') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD GH_EMPCode1_BK varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','RH_EMPCode1_BK') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD RH_EMPCode1_BK varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','ATMC_EMPCode_Reassign') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD ATMC_EMPCode_Reassign varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','RATC_EMPCode_Reassign') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD RATC_EMPCode_Reassign varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','SH_EMPCode_Reassign') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD SH_EMPCode_Reassign varchar(50) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','Penalty_Month') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD Penalty_Month varchar(100) NULL;
IF COL_LENGTH('dbo.tbl_ATM_Txn_Mntr_MappingMaster','Penalty_Year') IS NULL ALTER TABLE dbo.tbl_ATM_Txn_Mntr_MappingMaster ADD Penalty_Year varchar(100) NULL;
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.tbl_ATM_Txn_Mntr_MappingMaster') AND name='UX_ATM_MappingMaster_ATM_ID')
 AND NOT EXISTS(SELECT ATM_ID FROM dbo.tbl_ATM_Txn_Mntr_MappingMaster WHERE ATM_ID IS NOT NULL GROUP BY ATM_ID HAVING COUNT(*)>1)
 CREATE UNIQUE INDEX UX_ATM_MappingMaster_ATM_ID ON dbo.tbl_ATM_Txn_Mntr_MappingMaster(ATM_ID) WHERE ATM_ID IS NOT NULL;
GO
