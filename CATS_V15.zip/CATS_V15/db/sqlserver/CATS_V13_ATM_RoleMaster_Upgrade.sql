SET XACT_ABORT ON;
BEGIN TRANSACTION;

MERGE dbo.RoleMaster AS target
USING (VALUES
    ('DBOPS_MAKER','DBOPS Maker'),
    ('DBOPS_CHECKER','DBOPS Checker'),
    ('ATMC','ATMC'),
    ('RATC','RATC'),
    ('SH','SH'),
    ('RH','RH'),
    ('GH','GH')
) AS source(Code,Name)
ON target.Code=source.Code
WHEN NOT MATCHED THEN
    INSERT(Code,Name,IsActive) VALUES(source.Code,source.Name,1);

MERGE dbo.PermissionMaster AS target
USING (VALUES
    ('ATM.OPERATIONS','Access ATM operations','ATM'),
    ('ATM.UPLOAD','Upload ATM files','ATM'),
    ('ATM.CHECK','Approve ATM uploads and reopen requests','ATM'),
    ('ATM.CASE.MANAGE','Reassign and reopen ATM cases','ATM')
) AS source(Code,Name,Category)
ON target.Code=source.Code
WHEN NOT MATCHED THEN
    INSERT(Code,Name,Category,IsActive) VALUES(source.Code,source.Name,source.Category,1);

MERGE dbo.RolePermissionMapping AS target
USING (VALUES
    ('ADMIN','ATM.OPERATIONS'),
    ('ADMIN','ATM.UPLOAD'),
    ('ADMIN','ATM.CHECK'),
    ('ADMIN','ATM.CASE.MANAGE'),
    ('DBOPS_MAKER','ATM.OPERATIONS'),
    ('DBOPS_MAKER','ATM.UPLOAD'),
    ('DBOPS_CHECKER','ATM.OPERATIONS'),
    ('DBOPS_CHECKER','ATM.CHECK'),
    ('ATMC','ATM.OPERATIONS'),
    ('RATC','ATM.OPERATIONS'),
    ('RATC','ATM.CASE.MANAGE'),
    ('RATC','ALERT.REASSIGN'),
    ('SH','ATM.OPERATIONS'),
    ('RH','ATM.OPERATIONS'),
    ('GH','ATM.OPERATIONS')
) AS source(RoleCode,PermissionCode)
ON target.RoleCode=source.RoleCode AND target.PermissionCode=source.PermissionCode
WHEN NOT MATCHED THEN
    INSERT(RoleCode,PermissionCode,IsActive) VALUES(source.RoleCode,source.PermissionCode,1);

COMMIT TRANSACTION;
