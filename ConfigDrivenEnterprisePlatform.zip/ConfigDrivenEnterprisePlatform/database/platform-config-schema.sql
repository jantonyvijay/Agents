/* Optional production schema if you later move platform metadata from JSON into SQL Server.
   The supplied demo intentionally uses JSON so it can run without a database. */
CREATE TABLE dbo.PlatformProject
(
    ProjectCode varchar(50) NOT NULL PRIMARY KEY,
    ProjectName nvarchar(200) NOT NULL,
    Description nvarchar(1000) NULL,
    IsEnabled bit NOT NULL DEFAULT (1),
    CreatedOn datetime2 NOT NULL DEFAULT (sysutcdatetime())
);

CREATE TABLE dbo.PlatformDataSource
(
    DataSourceCode varchar(50) NOT NULL PRIMARY KEY,
    DataSourceName nvarchar(200) NOT NULL,
    Provider varchar(30) NOT NULL,
    SecretReference nvarchar(500) NULL,
    IsEnabled bit NOT NULL DEFAULT (1)
);

CREATE TABLE dbo.PlatformEntity
(
    ProjectCode varchar(50) NOT NULL,
    EntityCode varchar(80) NOT NULL,
    EntityName nvarchar(200) NOT NULL,
    DataSourceCode varchar(50) NOT NULL,
    PrimaryKeyName varchar(100) NOT NULL,
    ConfigJson nvarchar(max) NOT NULL,
    CONSTRAINT PK_PlatformEntity PRIMARY KEY(ProjectCode, EntityCode)
);

CREATE TABLE dbo.PlatformPage
(
    ProjectCode varchar(50) NOT NULL,
    PageCode varchar(80) NOT NULL,
    PageTitle nvarchar(200) NOT NULL,
    EntityCode varchar(80) NOT NULL,
    SortOrder int NOT NULL DEFAULT (0),
    IsEnabled bit NOT NULL DEFAULT (1),
    ConfigJson nvarchar(max) NOT NULL,
    CONSTRAINT PK_PlatformPage PRIMARY KEY(ProjectCode, PageCode)
);

CREATE TABLE dbo.PlatformSchedule
(
    ScheduleCode varchar(80) NOT NULL PRIMARY KEY,
    ProjectCode varchar(50) NOT NULL,
    ScheduleName nvarchar(200) NOT NULL,
    ScheduleType varchar(30) NOT NULL,
    ScheduleValue varchar(100) NULL,
    IsEnabled bit NOT NULL DEFAULT (1),
    JobConfigJson nvarchar(max) NOT NULL
);

CREATE TABLE dbo.PlatformExecutionLog
(
    ExecutionId bigint IDENTITY(1,1) PRIMARY KEY,
    ScheduleCode varchar(80) NOT NULL,
    ProjectCode varchar(50) NOT NULL,
    JobType varchar(50) NOT NULL,
    StartUtc datetime2 NOT NULL,
    EndUtc datetime2 NULL,
    Status varchar(20) NOT NULL,
    RecordCount int NOT NULL DEFAULT (0),
    Message nvarchar(2000) NULL,
    ServerName nvarchar(200) NULL
);
