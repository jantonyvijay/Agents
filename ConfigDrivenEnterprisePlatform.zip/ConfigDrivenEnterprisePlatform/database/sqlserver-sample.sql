/* Example business objects for SQL Server.
   The platform never accepts SQL from the browser. Commands are server-side configuration only. */
CREATE TABLE dbo.CustomerMaster
(
    CustomerId   BIGINT IDENTITY(1,1) PRIMARY KEY,
    CustomerName NVARCHAR(200) NOT NULL,
    Status       VARCHAR(20) NOT NULL CONSTRAINT DF_CustomerMaster_Status DEFAULT ('ACTIVE'),
    CreatedOn    DATETIME2 NOT NULL CONSTRAINT DF_CustomerMaster_CreatedOn DEFAULT (SYSUTCDATETIME())
);
GO

CREATE OR ALTER PROCEDURE dbo.usp_Customer_List
    @Status VARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (500) CustomerId, CustomerName, Status, CreatedOn
    FROM dbo.CustomerMaster
    WHERE @Status IS NULL OR Status = @Status
    ORDER BY CustomerId DESC;
END
GO

CREATE OR ALTER PROCEDURE dbo.usp_Customer_Create
    @CustomerName NVARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT dbo.CustomerMaster(CustomerName) VALUES (@CustomerName);
END
GO
