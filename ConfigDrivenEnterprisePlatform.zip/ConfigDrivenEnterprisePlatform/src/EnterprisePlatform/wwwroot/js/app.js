(function ($) {
    "use strict";

    const state = {
        projectCode: "DEMO",
        projects: [],
        pages: [],
        entities: [],
        page: null,
        rows: [],
        editRow: null,
        editIndex: -1
    };

    function getData(payload) {
        return apiPost("/api/GetData", payload);
    }

    function crudRequest(payload) {
        return apiPost("/api/CrudRequest", payload);
    }

    function apiPost(url, payload) {
        return $.ajax({
            url: url,
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(payload)
        }).then(function (res) {
            if (!res.success) return $.Deferred().reject(res).promise();
            return res;
        }, function (xhr) {
            const body = xhr.responseJSON || { success: false, message: xhr.statusText || "Request failed" };
            return $.Deferred().reject(body).promise();
        });
    }

    function escapeHtml(value) {
        return String(value == null ? "" : value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }

    function showToast(message, isError) {
        const $toast = $("#toast");
        $toast.stop(true, true).toggleClass("error", !!isError).text(message).fadeIn(140);
        setTimeout(() => $toast.fadeOut(220), 2800);
    }

    function showLoader() {
        $("#content").html('<div class="loader"><div><div class="spinner"></div><div>Loading configuration...</div></div></div>');
    }

    function setTitle(title, subtitle) {
        $("#pageTitle").text(title);
        $("#pageSubtitle").text(subtitle || "Configuration-driven application platform");
    }

    function loadBootData() {
        showLoader();
        return getData({ projectCode: state.projectCode, entity: "@PROJECTS", action: "LIST" })
            .then(function (res) {
                state.projects = res.data || [];
                const $select = $("#projectSelect").empty();
                state.projects.forEach(p => $select.append(`<option value="${escapeHtml(p.code)}">${escapeHtml(p.name)}</option>`));
                if (!state.projects.some(p => p.code === state.projectCode) && state.projects.length) state.projectCode = state.projects[0].code;
                $select.val(state.projectCode);
                return loadMetadata();
            })
            .then(() => navigateFromHash())
            .catch(err => renderFatal(err.message || "Unable to load platform configuration."));
    }

    function loadMetadata() {
        return $.when(
            getData({ projectCode: state.projectCode, entity: "@PAGES", action: "LIST" }),
            getData({ projectCode: state.projectCode, entity: "@ENTITIES", action: "LIST" })
        ).then(function (pagesRes, entitiesRes) {
            state.pages = pagesRes.data || [];
            state.entities = entitiesRes.data || [];
            renderDynamicMenu();
        });
    }

    function renderDynamicMenu() {
        const $menu = $("#dynamicMenu").empty();
        state.pages.filter(p => p.showInMenu).forEach(function (page) {
            $menu.append(`<button class="menu-item" data-route="page:${escapeHtml(page.code)}"><span class="menu-icon">▦</span><span>${escapeHtml(page.title)}</span></button>`);
        });
    }

    function navigateFromHash() {
        const route = (location.hash || "#dashboard").substring(1);
        navigate(route, false);
    }

    function navigate(route, pushHash) {
        if (pushHash !== false) location.hash = route;
        $(".menu-item").removeClass("active");
        $(`.menu-item[data-route="${CSS.escape(route)}"]`).addClass("active");
        if (window.innerWidth <= 780) $("#sidebar").removeClass("open");

        if (route === "dashboard") return renderDashboard();
        if (route === "schedules") return renderSchedules();
        if (route === "datasources") return renderDataSources();
        if (route === "executions") return renderExecutions();
        if (route.startsWith("page:")) return renderConfiguredPage(route.substring(5));
        renderDashboard();
    }

    function renderDashboard() {
        setTitle("Dashboard", "Runtime overview generated from platform configuration");
        showLoader();
        getData({ projectCode: state.projectCode, entity: "@DASHBOARD", action: "GET" })
            .then(function (res) {
                const d = res.data || {};
                const project = d.project || {};
                const last = d.lastExecution;
                $("#content").html(`
                    <section class="hero">
                        <div>
                            <h2>${escapeHtml(project.name || "Configured Application")}</h2>
                            <p>${escapeHtml(project.description || "Pages, data sources, jobs and workflow actions are resolved from configuration at runtime.")}</p>
                        </div>
                        <div class="hero-code">POST /api/GetData<br/>POST /api/CrudRequest</div>
                    </section>
                    <section class="stats-grid">
                        ${statCard("Configured Pages", d.pageCount || 0, "Rendered dynamically")}
                        ${statCard("Configured Entities", d.entityCount || 0, "Routed by metadata")}
                        ${statCard("Active Schedules", d.activeSchedules || 0, "Single scheduler runtime")}
                        ${statCard("Last Job", last ? last.status : "—", last ? formatDate(last.endUtc || last.startUtc) : "No execution yet")}
                    </section>
                    <section class="panel">
                        <div class="panel-header">
                            <div><div class="panel-title">Platform Flow</div><div class="panel-subtitle">Same runtime for every configured project</div></div>
                        </div>
                        <div class="panel-body">
                            <div class="architecture-line">
                                <div class="config-grid">
                                    ${flowCard("1", "Configure", "Project, page, fields, source, schedule")}
                                    ${flowCard("2", "Route", "GetData / CrudRequest resolve entity metadata")}
                                    ${flowCard("3", "Execute", "JSON, SQL Server, Oracle or PostgreSQL provider")}
                                </div>
                            </div>
                        </div>
                    </section>
                `);
            })
            .catch(handleError);
    }

    function statCard(label, value, foot) {
        return `<div class="stat-card"><div class="stat-label">${escapeHtml(label)}</div><div class="stat-value">${escapeHtml(value)}</div><div class="stat-foot">${escapeHtml(foot)}</div></div>`;
    }

    function flowCard(number, title, text) {
        return `<div class="config-card"><div class="provider-badge">STEP ${number}</div><h3 style="margin-top:10px">${escapeHtml(title)}</h3><div class="muted-sm">${escapeHtml(text)}</div></div>`;
    }

    function renderConfiguredPage(code) {
        setTitle("Loading...", "Reading page metadata");
        showLoader();
        getData({ projectCode: state.projectCode, entity: "@PAGE", action: "GET", filters: { code: code } })
            .then(function (res) {
                state.page = res.data;
                state.editRow = null;
                const page = state.page;
                setTitle(page.title, `Entity: ${page.entity} • UI generated from page configuration`);
                renderPageShell(page);
                return loadPageRows();
            })
            .catch(handleError);
    }

    function renderPageShell(page) {
        const canCreate = (page.actions || []).includes("CREATE");
        $("#content").html(`
            <section class="panel">
                <div class="panel-header">
                    <div><div class="panel-title">${escapeHtml(page.title)}</div><div class="panel-subtitle">No page-specific API or JavaScript required</div></div>
                    <div class="panel-actions">
                        ${canCreate ? '<button class="btn btn-secondary" id="importCsvBtn">Import CSV</button>' : ''}
                        ${canCreate ? '<button class="btn btn-primary" id="newRecordBtn">+ New Record</button>' : ''}
                    </div>
                </div>
                <div class="panel-body" style="padding-bottom:10px">
                    <div class="toolbar"><input class="search" id="gridSearch" placeholder="Search records..."/><button class="btn btn-secondary" id="searchBtn">Search</button><button class="btn btn-secondary" id="refreshBtn">Refresh</button></div>
                </div>
                <div class="table-wrap" id="gridHost"><div class="loader"><div><div class="spinner"></div><div>Loading records...</div></div></div></div>
            </section>
        `);
    }

    function loadPageRows() {
        if (!state.page) return;
        const search = $("#gridSearch").val();
        const filters = search ? { search: search } : {};
        $("#gridHost").html('<div class="loader"><div><div class="spinner"></div><div>Loading records...</div></div></div>');
        return getData({ projectCode: state.projectCode, entity: state.page.entity, action: "LIST", filters: filters, page: 1, pageSize: 100 })
            .then(function (res) {
                state.rows = res.data || [];
                renderGrid(state.page, state.rows);
            })
            .catch(handleError);
    }

    function renderGrid(page, rows) {
        const columns = page.columns || [];
        let html = '<table><thead><tr>';
        columns.forEach(c => html += `<th>${escapeHtml(c.title)}</th>`);
        html += '<th>Actions</th></tr></thead><tbody>';
        if (!rows.length) {
            html += `<tr><td colspan="${columns.length + 1}"><div class="empty">No records found.</div></td></tr>`;
        } else {
            rows.forEach(function (row, index) {
                html += '<tr>';
                columns.forEach(c => html += `<td>${formatCell(c.field, row[c.field])}</td>`);
                html += `<td><div class="actions">${renderRowActions(page.actions || [], row, index)}</div></td></tr>`;
            });
        }
        html += '</tbody></table>';
        $("#gridHost").html(html);
    }

    function formatCell(field, value) {
        if (field.toLowerCase() === "status") {
            const cls = String(value || "").toLowerCase().replace(/[^a-z]/g, "");
            return `<span class="status ${cls}">${escapeHtml(value)}</span>`;
        }
        return escapeHtml(value);
    }

    function renderRowActions(actions, row, index) {
        let html = "";
        if (actions.includes("EDIT")) html += `<button class="btn btn-secondary btn-sm row-edit" data-index="${index}">Edit</button>`;
        if (actions.includes("APPROVE") && String(row.Status || row.status || "").toLowerCase() === "pending") html += `<button class="btn btn-secondary btn-sm row-approve" data-index="${index}">Approve</button>`;
        if (actions.includes("REJECT") && String(row.Status || row.status || "").toLowerCase() === "pending") html += `<button class="btn btn-secondary btn-sm row-reject" data-index="${index}">Reject</button>`;
        if (actions.includes("DELETE")) html += `<button class="btn btn-danger btn-sm row-delete" data-index="${index}">Delete</button>`;
        return html;
    }

    function currentEntityMeta() {
        if (!state.page) return null;
        return state.entities.find(e => e.code === state.page.entity) || null;
    }

    function openRecordModal(row, index) {
        const page = state.page;
        if (!page) return;
        state.editRow = row || null;
        state.editIndex = typeof index === "number" ? index : -1;
        $("#modalTitle").text(row ? "Edit Record" : "New Record");
        $("#modalSubtitle").text(page.title);
        const $host = $("#formFields").empty();

        (page.fields || []).forEach(function (field) {
            const value = row ? (row[field.field] == null ? "" : row[field.field]) : "";
            const required = field.required ? '<span class="req">*</span>' : '';
            let control;
            if (field.control === "textarea") {
                control = `<textarea class="field-input" name="${escapeHtml(field.field)}" ${field.required ? "required" : ""} ${field.readOnly ? "readonly" : ""}>${escapeHtml(value)}</textarea>`;
            } else if (field.control === "dropdown") {
                const options = (field.options || []).map(o => `<option value="${escapeHtml(o.value)}" ${String(o.value) === String(value) ? "selected" : ""}>${escapeHtml(o.text)}</option>`).join("");
                control = `<select class="field-input" name="${escapeHtml(field.field)}" ${field.required ? "required" : ""} ${field.readOnly ? "disabled" : ""}><option value="">Select</option>${options}</select>`;
            } else {
                const type = field.control === "number" ? "number" : field.control === "date" ? "date" : "text";
                control = `<input type="${type}" class="field-input" name="${escapeHtml(field.field)}" value="${escapeHtml(value)}" ${field.required ? "required" : ""} ${field.readOnly ? "readonly" : ""}/>`;
            }
            $host.append(`<div class="field ${field.control === "textarea" ? "full" : ""}"><label>${escapeHtml(field.label)} ${required}</label>${control}</div>`);
        });
        $("#recordModal").addClass("open");
    }

    function saveRecord() {
        if (!state.page) return;
        const data = {};
        $("#recordForm").serializeArray().forEach(x => data[x.name] = x.value);
        const meta = currentEntityMeta();
        const isEdit = !!state.editRow;
        const payload = {
            projectCode: state.projectCode,
            entity: state.page.entity,
            action: isEdit ? "UPDATE" : "CREATE",
            data: data
        };
        if (isEdit && meta) payload.keys = { [meta.primaryKey]: state.editRow[meta.primaryKey] };

        crudRequest(payload).then(function (res) {
            closeModal();
            showToast(res.message || "Saved");
            loadPageRows();
        }).catch(handleError);
    }

    function workflowAction(index, action) {
        const row = state.rows[index];
        const meta = currentEntityMeta();
        if (!row || !meta || !state.page) return;
        let remarks = "";
        if (action === "REJECT") {
            remarks = window.prompt("Enter rejection remarks:", "") || "";
            if (!remarks) return;
        }
        crudRequest({
            projectCode: state.projectCode,
            entity: state.page.entity,
            action: action,
            keys: { [meta.primaryKey]: row[meta.primaryKey] },
            remarks: remarks
        }).then(function (res) {
            showToast(res.message || `${action} completed`);
            loadPageRows();
        }).catch(handleError);
    }

    function deleteRow(index) {
        const row = state.rows[index];
        const meta = currentEntityMeta();
        if (!row || !meta || !state.page) return;
        if (!window.confirm(`Delete record ${row[meta.primaryKey]}?`)) return;
        crudRequest({
            projectCode: state.projectCode,
            entity: state.page.entity,
            action: "DELETE",
            keys: { [meta.primaryKey]: row[meta.primaryKey] }
        }).then(function (res) {
            showToast(res.message || "Deleted");
            loadPageRows();
        }).catch(handleError);
    }

    function importCsv(file) {
        if (!file || !state.page) return;
        const reader = new FileReader();
        reader.onload = function () {
            const rows = parseCsv(String(reader.result || ""));
            if (!rows.length) return showToast("CSV contains no data rows.", true);
            let chain = $.Deferred().resolve().promise();
            let imported = 0;
            rows.forEach(function (data) {
                chain = chain.then(() => crudRequest({ projectCode: state.projectCode, entity: state.page.entity, action: "CREATE", data: data }))
                    .then(() => { imported++; });
            });
            chain.then(function () {
                showToast(`Imported ${imported} record(s)`);
                loadPageRows();
            }).catch(handleError);
        };
        reader.readAsText(file);
    }

    function parseCsv(text) {
        const lines = text.split(/\r?\n/).filter(x => x.trim());
        if (lines.length < 2) return [];
        const headers = splitCsvLine(lines[0]);
        return lines.slice(1).map(function (line) {
            const values = splitCsvLine(line);
            const row = {};
            headers.forEach((h, i) => row[h.trim()] = values[i] == null ? "" : values[i]);
            return row;
        });
    }

    function splitCsvLine(line) {
        const values = [];
        let current = "", quoted = false;
        for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            if (ch === '"') {
                if (quoted && line[i + 1] === '"') { current += '"'; i++; }
                else quoted = !quoted;
            } else if (ch === "," && !quoted) { values.push(current.trim()); current = ""; }
            else current += ch;
        }
        values.push(current.trim());
        return values;
    }

    function closeModal() {
        $("#recordModal").removeClass("open");
        $("#recordForm")[0].reset();
        state.editRow = null;
        state.editIndex = -1;
    }

    function renderSchedules() {
        setTitle("Schedules", "One server scheduler executes all configured project jobs");
        showLoader();
        getData({ projectCode: state.projectCode, entity: "@SCHEDULES", action: "LIST" })
            .then(function (res) {
                const rows = res.data || [];
                let html = `<section class="panel"><div class="panel-header"><div><div class="panel-title">Configured Schedules</div><div class="panel-subtitle">Changes are saved to configuration; no Windows Task Scheduler entry per project</div></div></div><div class="table-wrap"><div class="schedule-row header"><div>Name</div><div>Type</div><div>Value</div><div>Enabled</div><div></div></div>`;
                rows.forEach(function (s) {
                    const isDaily = String(s.scheduleType).toUpperCase() === "DAILY";
                    const valueInput = isDaily
                        ? `<input class="field-input schedule-value" type="time" value="${escapeHtml(s.time || "06:00")}"/>`
                        : `<input class="field-input schedule-value" type="number" min="1" value="${escapeHtml(s.intervalMinutes || 60)}"/>`;
                    html += `<div class="schedule-row" data-code="${escapeHtml(s.code)}" data-type="${escapeHtml(s.scheduleType)}">
                        <div><div class="small-strong">${escapeHtml(s.name)}</div><div class="muted-xs mono">${escapeHtml(s.code)} • ${escapeHtml(s.job && s.job.type)}</div></div>
                        <div>${escapeHtml(s.scheduleType)}</div>
                        <div>${valueInput}</div>
                        <div><label class="switch"><input class="schedule-enabled" type="checkbox" ${s.enabled ? "checked" : ""}/><span class="slider"></span></label></div>
                        <div><button class="btn btn-secondary btn-sm save-schedule">Save</button></div>
                    </div>`;
                });
                html += '</div></section>';
                $("#content").html(html);
            })
            .catch(handleError);
    }

    function saveSchedule($row) {
        const code = $row.data("code");
        const type = String($row.data("type")).toUpperCase();
        const enabled = $row.find(".schedule-enabled").is(":checked");
        const value = $row.find(".schedule-value").val();
        const data = { enabled: enabled };
        if (type === "DAILY") data.time = value;
        else data.intervalMinutes = Number(value);
        crudRequest({ projectCode: state.projectCode, entity: "@SCHEDULES", action: "UPDATE", keys: { code: code }, data: data })
            .then(res => showToast(res.message || "Schedule updated"))
            .catch(handleError);
    }

    function renderDataSources() {
        setTitle("Data Sources", "Provider-independent configuration for application data");
        showLoader();
        getData({ projectCode: state.projectCode, entity: "@DATASOURCES", action: "LIST" })
            .then(function (res) {
                const rows = res.data || [];
                let html = '<section class="panel"><div class="panel-header"><div><div class="panel-title">Data Source Registry</div><div class="panel-subtitle">SQL Server, Oracle and PostgreSQL use the same API contract</div></div></div><div class="panel-body"><div class="config-grid">';
                rows.forEach(function (d) {
                    html += `<div class="config-card">
                        <h3>${escapeHtml(d.name)}</h3>
                        <div class="muted-sm mono">${escapeHtml(d.code)}</div>
                        <span class="provider-badge">${escapeHtml(d.provider)}</span>
                        <div class="muted-xs" style="margin-top:10px">Status: ${d.enabled ? "Enabled" : "Disabled / sample"}</div>
                        <div class="muted-xs" style="margin-top:4px">${d.filePath ? "File: " + escapeHtml(d.filePath) : "Connection string kept server-side"}</div>
                    </div>`;
                });
                html += '</div></div></section>';
                $("#content").html(html);
            })
            .catch(handleError);
    }

    function renderExecutions() {
        setTitle("Execution Log", "Scheduler run history from the common runtime service");
        showLoader();
        getData({ projectCode: state.projectCode, entity: "@EXECUTIONS", action: "LIST" })
            .then(function (res) {
                const rows = res.data || [];
                let html = '<section class="panel"><div class="panel-header"><div><div class="panel-title">Recent Executions</div><div class="panel-subtitle">Latest 200 project runs</div></div><button class="btn btn-secondary" id="execRefresh">Refresh</button></div><div class="table-wrap"><table><thead><tr><th>Schedule</th><th>Job</th><th>Start</th><th>End</th><th>Records</th><th>Status</th><th>Message</th><th>Server</th></tr></thead><tbody>';
                if (!rows.length) html += '<tr><td colspan="8"><div class="empty">No scheduler executions yet. The enabled demo job runs automatically.</div></td></tr>';
                rows.forEach(function (x) {
                    html += `<tr><td>${escapeHtml(x.scheduleCode)}</td><td>${escapeHtml(x.jobType)}</td><td>${escapeHtml(formatDate(x.startUtc))}</td><td>${escapeHtml(formatDate(x.endUtc))}</td><td>${escapeHtml(x.records)}</td><td><span class="status ${String(x.status || '').toLowerCase()}">${escapeHtml(x.status)}</span></td><td>${escapeHtml(x.message)}</td><td>${escapeHtml(x.serverName)}</td></tr>`;
                });
                html += '</tbody></table></div></section>';
                $("#content").html(html);
            })
            .catch(handleError);
    }

    function formatDate(value) {
        if (!value) return "—";
        const d = new Date(value);
        return Number.isNaN(d.getTime()) ? value : d.toLocaleString();
    }

    function renderFatal(message) {
        setTitle("Platform Error", "Unable to initialize application");
        $("#content").html(`<section class="panel"><div class="empty"><strong>Application could not start.</strong><br/><br/>${escapeHtml(message)}<br/><br/><span class="muted-sm">Check Config/platform-config.json and server logs.</span></div></section>`);
    }

    function handleError(err) {
        const message = (err && err.message) || "Request failed.";
        showToast(message, true);
        console.error(err);
    }

    $(document).on("click", ".menu-item", function () { navigate($(this).data("route")); });
    $(window).on("hashchange", navigateFromHash);
    $(document).on("click", "#newRecordBtn", () => openRecordModal(null, -1));
    $(document).on("click", "#refreshBtn", loadPageRows);
    $(document).on("click", "#searchBtn", loadPageRows);
    $(document).on("keydown", "#gridSearch", e => { if (e.key === "Enter") loadPageRows(); });
    $(document).on("click", ".row-edit", function () { const i = Number($(this).data("index")); openRecordModal(state.rows[i], i); });
    $(document).on("click", ".row-approve", function () { workflowAction(Number($(this).data("index")), "APPROVE"); });
    $(document).on("click", ".row-reject", function () { workflowAction(Number($(this).data("index")), "REJECT"); });
    $(document).on("click", ".row-delete", function () { deleteRow(Number($(this).data("index"))); });
    $(document).on("click", "#modalClose,#modalCancel", closeModal);
    $(document).on("submit", "#recordForm", function (e) { e.preventDefault(); saveRecord(); });
    $(document).on("click", "#recordModal", function (e) { if (e.target === this) closeModal(); });
    $(document).on("click", "#importCsvBtn", () => $("#csvFileInput").val("").trigger("click"));
    $(document).on("change", "#csvFileInput", function () { importCsv(this.files && this.files[0]); });
    $(document).on("click", ".save-schedule", function () { saveSchedule($(this).closest(".schedule-row")); });
    $(document).on("click", "#execRefresh", renderExecutions);
    $("#menuToggle").on("click", () => $("#sidebar").toggleClass("open"));
    $("#projectSelect").on("change", function () {
        state.projectCode = $(this).val();
        loadMetadata().then(() => navigate("dashboard"));
    });

    loadBootData();
})(jQuery);
