namespace EnterprisePlatform.Models;

public sealed class PlatformConfig
{
    public int Version { get; set; } = 1;
    public List<ProjectConfig> Projects { get; set; } = new();
    public List<DataSourceConfig> DataSources { get; set; } = new();
    public List<EntityConfig> Entities { get; set; } = new();
    public List<PageConfig> Pages { get; set; } = new();
    public List<ScheduleConfig> Schedules { get; set; } = new();
}

public sealed class ProjectConfig
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
}

public sealed class DataSourceConfig
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Provider { get; set; } = "JSON"; // JSON | SQLSERVER | ORACLE | POSTGRESQL
    public string ConnectionString { get; set; } = string.Empty;
    public string? FilePath { get; set; }
    public bool Enabled { get; set; } = true;
}

public sealed class EntityConfig
{
    public string ProjectCode { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string DataSourceCode { get; set; } = string.Empty;
    public string PrimaryKey { get; set; } = "Id";
    public List<string> AllowedReadActions { get; set; } = new() { "LIST", "GET" };
    public List<string> AllowedWriteActions { get; set; } = new() { "CREATE", "UPDATE", "DELETE" };
    public Dictionary<string, CommandConfig> Commands { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class CommandConfig
{
    public string Type { get; set; } = "Text"; // Text | StoredProcedure
    public string Text { get; set; } = string.Empty;
    public List<ParameterBinding> Parameters { get; set; } = new();
}

public sealed class ParameterBinding
{
    public string Name { get; set; } = string.Empty;
    public string Source { get; set; } = string.Empty; // filter:x | data:x | key:x | request:page | request:pageSize | request:remarks | param:x
    public string? DbType { get; set; }
    public bool Required { get; set; }
}

public sealed class PageConfig
{
    public string ProjectCode { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Entity { get; set; } = string.Empty;
    public string PageType { get; set; } = "grid";
    public string Icon { get; set; } = "table";
    public int Order { get; set; }
    public bool ShowInMenu { get; set; } = true;
    public List<PageColumnConfig> Columns { get; set; } = new();
    public List<FormFieldConfig> Fields { get; set; } = new();
    public List<string> Actions { get; set; } = new();
}

public sealed class PageColumnConfig
{
    public string Field { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? Format { get; set; }
}

public sealed class FormFieldConfig
{
    public string Field { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public string Control { get; set; } = "textbox"; // textbox, textarea, number, date, dropdown
    public bool Required { get; set; }
    public bool ReadOnly { get; set; }
    public List<OptionConfig>? Options { get; set; }
}

public sealed class OptionConfig
{
    public string Value { get; set; } = string.Empty;
    public string Text { get; set; } = string.Empty;
}

public sealed class ScheduleConfig
{
    public string Code { get; set; } = string.Empty;
    public string ProjectCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public string ScheduleType { get; set; } = "DAILY"; // DAILY | INTERVAL_MINUTES
    public string? Time { get; set; } = "06:00"; // HH:mm for DAILY
    public int? IntervalMinutes { get; set; }
    public SchedulerJobConfig Job { get; set; } = new();
}

public sealed class SchedulerJobConfig
{
    public string Type { get; set; } = "GETDATA"; // GETDATA | FILEDROP_IMPORT | COPY_ENTITY
    public string? SourceEntity { get; set; }
    public string? TargetEntity { get; set; }
    public string? SourceFolder { get; set; }
    public string? FilePattern { get; set; }
    public string? ArchiveFolder { get; set; }
    public Dictionary<string, string>? Settings { get; set; }
}

public sealed class SchedulerState
{
    public Dictionary<string, DateTimeOffset> LastRunUtc { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class ExecutionLogItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string ScheduleCode { get; set; } = string.Empty;
    public string ProjectCode { get; set; } = string.Empty;
    public string JobType { get; set; } = string.Empty;
    public DateTimeOffset StartUtc { get; set; }
    public DateTimeOffset? EndUtc { get; set; }
    public string Status { get; set; } = "RUNNING";
    public int Records { get; set; }
    public string Message { get; set; } = string.Empty;
    public string ServerName { get; set; } = Environment.MachineName;
}
