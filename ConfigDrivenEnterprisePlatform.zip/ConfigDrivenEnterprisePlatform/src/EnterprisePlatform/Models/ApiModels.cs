using System.Text.Json;

namespace EnterprisePlatform.Models;

public sealed class GetDataRequest
{
    public string ProjectCode { get; set; } = "DEMO";
    public string Entity { get; set; } = string.Empty;
    public string Action { get; set; } = "LIST";
    public Dictionary<string, JsonElement>? Filters { get; set; }
    public Dictionary<string, JsonElement>? Parameters { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 50;
}

public sealed class CrudRequest
{
    public string ProjectCode { get; set; } = "DEMO";
    public string Entity { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public Dictionary<string, JsonElement>? Keys { get; set; }
    public Dictionary<string, JsonElement>? Data { get; set; }
    public Dictionary<string, JsonElement>? Parameters { get; set; }
    public string? Remarks { get; set; }
}

public sealed class ApiResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public object? Data { get; set; }
    public int? TotalRecords { get; set; }
    public string? CorrelationId { get; set; }

    public static ApiResult Ok(object? data = null, string message = "Success", int? totalRecords = null, string? correlationId = null)
        => new() { Success = true, Data = data, Message = message, TotalRecords = totalRecords, CorrelationId = correlationId };

    public static ApiResult Fail(string message, string? correlationId = null)
        => new() { Success = false, Message = message, CorrelationId = correlationId };
}
