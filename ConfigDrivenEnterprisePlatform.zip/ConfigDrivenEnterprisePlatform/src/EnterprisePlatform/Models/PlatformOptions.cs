namespace EnterprisePlatform.Models;

public sealed class PlatformOptions
{
    public string ConfigPath { get; set; } = "Config/platform-config.json";
    public string SchedulerStatePath { get; set; } = "DataStore/scheduler-state.json";
    public string ExecutionLogPath { get; set; } = "DataStore/execution-log.json";
    public int PollSeconds { get; set; } = 15;
    public bool SchedulerEnabled { get; set; } = true;
}
