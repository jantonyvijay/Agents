using EnterprisePlatform.Data;
using EnterprisePlatform.Jobs;
using EnterprisePlatform.Models;
using EnterprisePlatform.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<PlatformOptions>(builder.Configuration.GetSection("Platform"));
builder.Services.AddSingleton<IPlatformConfigStore, JsonPlatformConfigStore>();
builder.Services.AddSingleton<JsonEntityStore>();
builder.Services.AddSingleton<DatabaseExecutor>();
builder.Services.AddSingleton<ExecutionLogStore>();
builder.Services.AddSingleton<RequestRouter>();
builder.Services.AddSingleton<SchedulerStateStore>();
builder.Services.AddSingleton<ConfiguredJobExecutor>();
builder.Services.AddHostedService<ConfigSchedulerService>();

builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.PropertyNameCaseInsensitive = true;
    options.SerializerOptions.WriteIndented = false;
});

var app = builder.Build();

app.Use(async (context, next) =>
{
    var correlationId = context.Request.Headers["X-Correlation-Id"].FirstOrDefault()
                        ?? Guid.NewGuid().ToString("N");
    context.Items["CorrelationId"] = correlationId;
    context.Response.Headers["X-Correlation-Id"] = correlationId;
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
    await next();
});

app.UseDefaultFiles();
app.UseStaticFiles();

// Business API endpoint #1 - all reads
app.MapPost("/api/GetData", async (GetDataRequest request, RequestRouter router, HttpContext http, CancellationToken ct) =>
{
    var correlationId = http.Items["CorrelationId"]?.ToString();
    try
    {
        var result = await router.GetDataAsync(request, ct);
        result.CorrelationId = correlationId;
        return Results.Json(result, statusCode: result.Success ? StatusCodes.Status200OK : StatusCodes.Status400BadRequest);
    }
    catch (UnauthorizedAccessException ex)
    {
        return Results.Json(ApiResult.Fail(ex.Message, correlationId), statusCode: StatusCodes.Status403Forbidden);
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "GetData failed. CorrelationId={CorrelationId}", correlationId);
        return Results.Json(ApiResult.Fail(ex.Message, correlationId), statusCode: StatusCodes.Status500InternalServerError);
    }
});

// Business API endpoint #2 - all creates/updates/deletes/workflow actions
app.MapPost("/api/CrudRequest", async (CrudRequest request, RequestRouter router, HttpContext http, CancellationToken ct) =>
{
    var correlationId = http.Items["CorrelationId"]?.ToString();
    try
    {
        var result = await router.CrudAsync(request, ct);
        result.CorrelationId = correlationId;
        return Results.Json(result, statusCode: result.Success ? StatusCodes.Status200OK : StatusCodes.Status400BadRequest);
    }
    catch (UnauthorizedAccessException ex)
    {
        return Results.Json(ApiResult.Fail(ex.Message, correlationId), statusCode: StatusCodes.Status403Forbidden);
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "CrudRequest failed. CorrelationId={CorrelationId}", correlationId);
        return Results.Json(ApiResult.Fail(ex.Message, correlationId), statusCode: StatusCodes.Status500InternalServerError);
    }
});

app.MapFallbackToFile("index.html");
app.Run();
