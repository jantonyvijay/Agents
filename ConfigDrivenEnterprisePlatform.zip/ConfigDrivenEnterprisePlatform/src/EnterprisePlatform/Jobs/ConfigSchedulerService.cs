using EnterprisePlatform.Models;
using EnterprisePlatform.Services;
using Microsoft.Extensions.Options;

namespace EnterprisePlatform.Jobs;

public sealed class ConfigSchedulerService : BackgroundService
{
    private readonly IPlatformConfigStore _configStore;
    private readonly SchedulerStateStore _stateStore;
    private readonly ConfiguredJobExecutor _executor;
    private readonly ExecutionLogStore _logs;
    private readonly PlatformOptions _options;
    private readonly ILogger<ConfigSchedulerService> _logger;
    private readonly SemaphoreSlim _runGate = new(1, 1);

    public ConfigSchedulerService(
        IPlatformConfigStore configStore,
        SchedulerStateStore stateStore,
        ConfiguredJobExecutor executor,
        ExecutionLogStore logs,
        IOptions<PlatformOptions> options,
        ILogger<ConfigSchedulerService> logger)
    {
        _configStore = configStore;
        _stateStore = stateStore;
        _executor = executor;
        _logs = logs;
        _options = options.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!_options.SchedulerEnabled)
        {
            _logger.LogInformation("Configuration scheduler is disabled.");
            return;
        }

        _logger.LogInformation("Configuration scheduler started. Poll interval: {Seconds}s", _options.PollSeconds);
        while (!stoppingToken.IsCancellationRequested)
        {
            try { await RunDueJobsAsync(stoppingToken); }
            catch (Exception ex) { _logger.LogError(ex, "Scheduler polling cycle failed."); }

            await Task.Delay(TimeSpan.FromSeconds(Math.Max(5, _options.PollSeconds)), stoppingToken);
        }
    }

    private async Task RunDueJobsAsync(CancellationToken ct)
    {
        if (!await _runGate.WaitAsync(0, ct)) return;
        try
        {
            var config = await _configStore.GetAsync(ct);
            var state = await _stateStore.GetAsync(ct);
            var now = DateTimeOffset.Now;

            foreach (var schedule in config.Schedules.Where(x => x.Enabled))
            {
                state.LastRunUtc.TryGetValue(schedule.Code, out var lastRun);
                DateTimeOffset? last = state.LastRunUtc.ContainsKey(schedule.Code) ? lastRun : null;
                if (!ScheduleCalculator.IsDue(schedule, now, last)) continue;

                var log = new ExecutionLogItem
                {
                    ScheduleCode = schedule.Code,
                    ProjectCode = schedule.ProjectCode,
                    JobType = schedule.Job.Type,
                    StartUtc = DateTimeOffset.UtcNow
                };

                try
                {
                    var records = await _executor.ExecuteAsync(schedule, ct);
                    log.Records = records;
                    log.Status = "SUCCESS";
                    log.Message = $"Processed {records} record(s).";
                }
                catch (Exception ex)
                {
                    log.Status = "FAILED";
                    log.Message = ex.Message;
                    _logger.LogError(ex, "Scheduled job {ScheduleCode} failed.", schedule.Code);
                }
                finally
                {
                    log.EndUtc = DateTimeOffset.UtcNow;
                    state.LastRunUtc[schedule.Code] = DateTimeOffset.UtcNow;
                    await _stateStore.SaveAsync(state, ct);
                    await _logs.AppendAsync(log, ct);
                }
            }
        }
        finally { _runGate.Release(); }
    }
}
