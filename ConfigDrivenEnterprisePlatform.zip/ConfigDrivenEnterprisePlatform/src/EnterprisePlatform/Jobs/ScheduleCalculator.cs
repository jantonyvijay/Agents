using EnterprisePlatform.Models;

namespace EnterprisePlatform.Jobs;

public static class ScheduleCalculator
{
    public static bool IsDue(ScheduleConfig schedule, DateTimeOffset now, DateTimeOffset? lastRunUtc)
    {
        if (!schedule.Enabled) return false;

        if (schedule.ScheduleType.Equals("INTERVAL_MINUTES", StringComparison.OrdinalIgnoreCase))
        {
            var minutes = Math.Max(1, schedule.IntervalMinutes ?? 60);
            return lastRunUtc is null || now.ToUniversalTime() >= lastRunUtc.Value.AddMinutes(minutes);
        }

        if (schedule.ScheduleType.Equals("DAILY", StringComparison.OrdinalIgnoreCase))
        {
            if (!TimeOnly.TryParse(schedule.Time, out var dueTime)) return false;
            var localNow = now.LocalDateTime;
            var dueToday = localNow.Date + dueTime.ToTimeSpan();
            var alreadyRanToday = lastRunUtc is not null && lastRunUtc.Value.ToLocalTime().Date == localNow.Date;
            return !alreadyRanToday && localNow >= dueToday;
        }

        return false;
    }
}
