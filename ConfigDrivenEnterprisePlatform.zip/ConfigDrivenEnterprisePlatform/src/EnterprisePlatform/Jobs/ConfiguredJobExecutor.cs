using System.Text.Json;
using EnterprisePlatform.Models;
using EnterprisePlatform.Services;

namespace EnterprisePlatform.Jobs;

public sealed class ConfiguredJobExecutor
{
    private readonly RequestRouter _router;
    private readonly ILogger<ConfiguredJobExecutor> _logger;

    public ConfiguredJobExecutor(RequestRouter router, ILogger<ConfiguredJobExecutor> logger)
    {
        _router = router;
        _logger = logger;
    }

    public async Task<int> ExecuteAsync(ScheduleConfig schedule, CancellationToken ct)
    {
        var type = schedule.Job.Type.ToUpperInvariant();
        return type switch
        {
            "GETDATA" => await ExecuteGetDataAsync(schedule, ct),
            "COPY_ENTITY" => await ExecuteCopyEntityAsync(schedule, ct),
            "FILEDROP_IMPORT" => await ExecuteFileDropImportAsync(schedule, ct),
            _ => throw new NotSupportedException($"Scheduler job type '{schedule.Job.Type}' is not supported.")
        };
    }

    private async Task<int> ExecuteGetDataAsync(ScheduleConfig schedule, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(schedule.Job.SourceEntity)) throw new InvalidOperationException("sourceEntity is required.");
        var result = await _router.GetDataAsync(new GetDataRequest
        {
            ProjectCode = schedule.ProjectCode,
            Entity = schedule.Job.SourceEntity,
            Action = "LIST",
            Page = 1,
            PageSize = 500
        }, ct);
        if (!result.Success) throw new InvalidOperationException(result.Message);
        return result.TotalRecords ?? CountArray(result.Data);
    }

    private async Task<int> ExecuteCopyEntityAsync(ScheduleConfig schedule, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(schedule.Job.SourceEntity) || string.IsNullOrWhiteSpace(schedule.Job.TargetEntity))
            throw new InvalidOperationException("sourceEntity and targetEntity are required.");

        var result = await _router.GetDataAsync(new GetDataRequest
        {
            ProjectCode = schedule.ProjectCode,
            Entity = schedule.Job.SourceEntity,
            Action = "LIST",
            Page = 1,
            PageSize = 500
        }, ct);
        if (!result.Success) throw new InvalidOperationException(result.Message);

        var element = JsonSerializer.SerializeToElement(result.Data);
        if (element.ValueKind != JsonValueKind.Array) return 0;
        var count = 0;
        foreach (var row in element.EnumerateArray())
        {
            var data = row.EnumerateObject().ToDictionary(x => x.Name, x => x.Value.Clone(), StringComparer.OrdinalIgnoreCase);
            var create = await _router.CrudAsync(new CrudRequest
            {
                ProjectCode = schedule.ProjectCode,
                Entity = schedule.Job.TargetEntity,
                Action = "CREATE",
                Data = data
            }, ct);
            if (create.Success) count++;
        }
        return count;
    }

    private async Task<int> ExecuteFileDropImportAsync(ScheduleConfig schedule, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(schedule.Job.SourceFolder) || string.IsNullOrWhiteSpace(schedule.Job.TargetEntity))
            throw new InvalidOperationException("sourceFolder and targetEntity are required.");

        var folder = Environment.ExpandEnvironmentVariables(schedule.Job.SourceFolder);
        var archive = Environment.ExpandEnvironmentVariables(schedule.Job.ArchiveFolder ?? Path.Combine(folder, "archive"));
        var pattern = schedule.Job.FilePattern ?? "*.csv";
        if (!Directory.Exists(folder))
        {
            _logger.LogWarning("File-drop folder {Folder} does not exist.", folder);
            return 0;
        }

        Directory.CreateDirectory(archive);
        var total = 0;
        foreach (var file in Directory.GetFiles(folder, pattern))
        {
            var rows = await ReadCsvAsync(file, ct);
            foreach (var row in rows)
            {
                var data = row.ToDictionary(k => k.Key, v => JsonSerializer.SerializeToElement(v.Value), StringComparer.OrdinalIgnoreCase);
                var result = await _router.CrudAsync(new CrudRequest
                {
                    ProjectCode = schedule.ProjectCode,
                    Entity = schedule.Job.TargetEntity,
                    Action = "CREATE",
                    Data = data
                }, ct);
                if (result.Success) total++;
            }

            var destination = Path.Combine(archive, $"{DateTime.Now:yyyyMMddHHmmssfff}_{Path.GetFileName(file)}");
            File.Move(file, destination, true);
        }
        return total;
    }

    private static async Task<List<Dictionary<string, string>>> ReadCsvAsync(string path, CancellationToken ct)
    {
        var lines = await File.ReadAllLinesAsync(path, ct);
        if (lines.Length < 2) return new();
        var headers = SplitCsvLine(lines[0]);
        var rows = new List<Dictionary<string, string>>();
        foreach (var line in lines.Skip(1).Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            var values = SplitCsvLine(line);
            var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < headers.Count; i++) row[headers[i]] = i < values.Count ? values[i] : string.Empty;
            rows.Add(row);
        }
        return rows;
    }

    private static List<string> SplitCsvLine(string line)
    {
        var result = new List<string>();
        var current = new System.Text.StringBuilder();
        var quoted = false;
        for (var i = 0; i < line.Length; i++)
        {
            var ch = line[i];
            if (ch == '"')
            {
                if (quoted && i + 1 < line.Length && line[i + 1] == '"') { current.Append('"'); i++; }
                else quoted = !quoted;
            }
            else if (ch == ',' && !quoted) { result.Add(current.ToString().Trim()); current.Clear(); }
            else current.Append(ch);
        }
        result.Add(current.ToString().Trim());
        return result;
    }

    private static int CountArray(object? data)
    {
        var element = JsonSerializer.SerializeToElement(data);
        return element.ValueKind == JsonValueKind.Array ? element.GetArrayLength() : 0;
    }
}
