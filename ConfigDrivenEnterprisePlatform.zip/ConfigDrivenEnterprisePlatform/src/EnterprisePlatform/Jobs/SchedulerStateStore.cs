using System.Text.Json;
using EnterprisePlatform.Models;
using Microsoft.Extensions.Options;

namespace EnterprisePlatform.Jobs;

public sealed class SchedulerStateStore
{
    private readonly string _path;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    public SchedulerStateStore(IWebHostEnvironment env, IOptions<PlatformOptions> options)
    {
        _path = Path.GetFullPath(Path.Combine(env.ContentRootPath, options.Value.SchedulerStatePath));
    }

    public async Task<SchedulerState> GetAsync(CancellationToken ct)
    {
        await _gate.WaitAsync(ct);
        try
        {
            if (!File.Exists(_path)) return new SchedulerState();
            await using var stream = File.OpenRead(_path);
            return await JsonSerializer.DeserializeAsync<SchedulerState>(stream, Options, ct) ?? new SchedulerState();
        }
        finally { _gate.Release(); }
    }

    public async Task SaveAsync(SchedulerState state, CancellationToken ct)
    {
        await _gate.WaitAsync(ct);
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
            await using var stream = File.Create(_path);
            await JsonSerializer.SerializeAsync(stream, state, Options, ct);
        }
        finally { _gate.Release(); }
    }
}
