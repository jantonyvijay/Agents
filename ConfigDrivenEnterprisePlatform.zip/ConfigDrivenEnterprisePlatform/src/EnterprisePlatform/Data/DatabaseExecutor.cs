using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Text.Json;
using EnterprisePlatform.Models;
using Microsoft.Data.SqlClient;
using Npgsql;
using Oracle.ManagedDataAccess.Client;

namespace EnterprisePlatform.Data;

public sealed class DatabaseExecutor
{
    public async Task<ApiResult> GetAsync(
        EntityConfig entity,
        DataSourceConfig source,
        GetDataRequest request,
        CancellationToken ct)
    {
        var commandConfig = ResolveCommand(entity, request.Action, source.Provider);
        await using var connection = CreateConnection(source);
        await connection.OpenAsync(ct);
        await using var command = connection.CreateCommand();
        ConfigureCommand(command, commandConfig, source.Provider);
        AddParameters(command, commandConfig.Parameters, request, null);

        var rows = new List<Dictionary<string, object?>>();
        await using var reader = await command.ExecuteReaderAsync(ct);
        do
        {
            while (await reader.ReadAsync(ct))
            {
                var row = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
                for (var i = 0; i < reader.FieldCount; i++)
                    row[reader.GetName(i)] = await reader.IsDBNullAsync(i, ct) ? null : reader.GetValue(i);
                rows.Add(row);
            }
        } while (await reader.NextResultAsync(ct));

        return ApiResult.Ok(rows, totalRecords: rows.Count);
    }

    public async Task<ApiResult> CrudAsync(
        EntityConfig entity,
        DataSourceConfig source,
        CrudRequest request,
        CancellationToken ct)
    {
        var commandConfig = ResolveCommand(entity, request.Action, source.Provider);
        await using var connection = CreateConnection(source);
        await connection.OpenAsync(ct);
        await using var transaction = await connection.BeginTransactionAsync(ct);
        await using var command = connection.CreateCommand();
        command.Transaction = transaction;
        ConfigureCommand(command, commandConfig, source.Provider);
        AddParameters(command, commandConfig.Parameters, null, request);

        try
        {
            var affected = await command.ExecuteNonQueryAsync(ct);
            await transaction.CommitAsync(ct);
            return ApiResult.Ok(new { affectedRows = affected }, $"{request.Action} completed successfully");
        }
        catch
        {
            await transaction.RollbackAsync(ct);
            throw;
        }
    }

    private static DbConnection CreateConnection(DataSourceConfig source)
    {
        var connection = source.Provider.ToUpperInvariant() switch
        {
            "SQLSERVER" => (DbConnection)new SqlConnection(),
            "ORACLE" => new OracleConnection(),
            "POSTGRESQL" => new NpgsqlConnection(),
            _ => throw new NotSupportedException($"Database provider '{source.Provider}' is not supported.")
        };
        var connectionString = source.ConnectionString;
        if (connectionString.StartsWith("ENV:", StringComparison.OrdinalIgnoreCase))
        {
            var variable = connectionString[4..].Trim();
            connectionString = Environment.GetEnvironmentVariable(variable)
                ?? throw new InvalidOperationException($"Environment variable '{variable}' is not configured for data source '{source.Code}'.");
        }
        connection.ConnectionString = connectionString;
        return connection;
    }

    private static void ConfigureCommand(DbCommand command, CommandConfig config, string provider)
    {
        command.CommandText = config.Text;
        command.CommandType = config.Type.Equals("StoredProcedure", StringComparison.OrdinalIgnoreCase)
            ? CommandType.StoredProcedure
            : CommandType.Text;
        command.CommandTimeout = 120;

        if (provider.Equals("ORACLE", StringComparison.OrdinalIgnoreCase))
        {
            var bindByName = command.GetType().GetProperty("BindByName");
            bindByName?.SetValue(command, true);
        }
    }

    private static CommandConfig ResolveCommand(EntityConfig entity, string action, string provider)
    {
        var upperAction = action.ToUpperInvariant();
        var providerKey = $"{upperAction}:{provider.ToUpperInvariant()}";
        if (entity.Commands.TryGetValue(providerKey, out var providerCommand)) return providerCommand;
        if (entity.Commands.TryGetValue(upperAction, out var command)) return command;
        throw new InvalidOperationException($"No command configured for {entity.Code}/{action}/{provider}.");
    }

    private static void AddParameters(
        DbCommand command,
        IEnumerable<ParameterBinding> bindings,
        GetDataRequest? get,
        CrudRequest? crud)
    {
        foreach (var binding in bindings)
        {
            var value = ResolveBinding(binding.Source, get, crud);
            if (binding.Required && value is null)
                throw new InvalidOperationException($"Required parameter '{binding.Name}' is missing.");

            var parameter = command.CreateParameter();
            parameter.ParameterName = binding.Name;
            parameter.Value = value ?? DBNull.Value;
            if (!string.IsNullOrWhiteSpace(binding.DbType) && Enum.TryParse<DbType>(binding.DbType, true, out var dbType))
                parameter.DbType = dbType;
            command.Parameters.Add(parameter);
        }
    }

    private static object? ResolveBinding(string source, GetDataRequest? get, CrudRequest? crud)
    {
        if (string.IsNullOrWhiteSpace(source)) return null;
        var parts = source.Split(':', 2);
        var scope = parts[0].ToLowerInvariant();
        var key = parts.Length > 1 ? parts[1] : string.Empty;

        return scope switch
        {
            "filter" => TryGetJson(get?.Filters, key),
            "param" => TryGetJson(get?.Parameters ?? crud?.Parameters, key),
            "data" => TryGetJson(crud?.Data, key),
            "key" => TryGetJson(crud?.Keys, key),
            "request" when key.Equals("page", StringComparison.OrdinalIgnoreCase) => get?.Page,
            "request" when key.Equals("pagesize", StringComparison.OrdinalIgnoreCase) => get?.PageSize,
            "request" when key.Equals("remarks", StringComparison.OrdinalIgnoreCase) => crud?.Remarks,
            "constant" => key,
            _ => null
        };
    }

    private static object? TryGetJson(Dictionary<string, JsonElement>? source, string key)
    {
        if (source is null || !source.TryGetValue(key, out var value)) return null;
        return value.ValueKind switch
        {
            JsonValueKind.String => value.GetString(),
            JsonValueKind.Number when value.TryGetInt64(out var i) => i,
            JsonValueKind.Number when value.TryGetDecimal(out var d) => d,
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            JsonValueKind.Null => null,
            _ => value.GetRawText()
        };
    }
}
