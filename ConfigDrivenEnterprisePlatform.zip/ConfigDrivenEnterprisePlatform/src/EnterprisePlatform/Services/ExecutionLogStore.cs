using System.Text.Json;
using EnterprisePlatform.Models;
using Microsoft.Extensions.Options;

namespace EnterprisePlatform.Services;

public sealed class ExecutionLogStore
{
    private readonly string _path;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    public ExecutionLogStore(IWebHostEnvironment env, IOptions<PlatformOptions> options)
    {
        _path = Path.GetFullPath(Path.Combine(env.ContentRootPath, options.Value.ExecutionLogPath));
    }

    public async Task<List<ExecutionLogItem>> GetAsync(CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            if (!File.Exists(_path)) return new();
            await using var stream = File.OpenRead(_path);
            return await JsonSerializer.DeserializeAsync<List<ExecutionLogItem>>(stream, Options, cancellationToken) ?? new();
        }
        finally { _gate.Release(); }
    }

    public async Task AppendAsync(ExecutionLogItem item, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            List<ExecutionLogItem> items;
            if (File.Exists(_path))
            {
                await using var read = File.OpenRead(_path);
                items = await JsonSerializer.DeserializeAsync<List<ExecutionLogItem>>(read, Options, cancellationToken) ?? new();
            }
            else items = new();

            items.Insert(0, item);
            if (items.Count > 500) items = items.Take(500).ToList();
            Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
            await using var write = File.Create(_path);
            await JsonSerializer.SerializeAsync(write, items, Options, cancellationToken);
        }
        finally { _gate.Release(); }
    }
}
