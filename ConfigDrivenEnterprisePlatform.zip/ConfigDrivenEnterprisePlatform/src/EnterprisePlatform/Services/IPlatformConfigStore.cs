using EnterprisePlatform.Models;

namespace EnterprisePlatform.Services;

public interface IPlatformConfigStore
{
    Task<PlatformConfig> GetAsync(CancellationToken cancellationToken = default);
    Task SaveAsync(PlatformConfig config, CancellationToken cancellationToken = default);
}
