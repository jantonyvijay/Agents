using System.Text.Json;
using EnterprisePlatform.Models;
using Microsoft.Extensions.Options;

namespace EnterprisePlatform.Services;

public sealed class JsonPlatformConfigStore : IPlatformConfigStore
{
    private readonly string _path;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public JsonPlatformConfigStore(IWebHostEnvironment env, IOptions<PlatformOptions> options)
    {
        _path = Path.GetFullPath(Path.Combine(env.ContentRootPath, options.Value.ConfigPath));
    }

    public async Task<PlatformConfig> GetAsync(CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            if (!File.Exists(_path))
                throw new FileNotFoundException("Platform configuration file was not found.", _path);

            await using var stream = File.OpenRead(_path);
            return await JsonSerializer.DeserializeAsync<PlatformConfig>(stream, JsonOptions, cancellationToken)
                   ?? new PlatformConfig();
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task SaveAsync(PlatformConfig config, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
            var tmp = _path + ".tmp";
            await using (var stream = File.Create(tmp))
                await JsonSerializer.SerializeAsync(stream, config, JsonOptions, cancellationToken);

            File.Move(tmp, _path, true);
        }
        finally
        {
            _gate.Release();
        }
    }
}
