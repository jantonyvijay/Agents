using System.Globalization;
using System.Text.Json;
using System.Text.Json.Nodes;
using EnterprisePlatform.Models;

namespace EnterprisePlatform.Services;

public sealed class JsonEntityStore
{
    private readonly IWebHostEnvironment _env;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    public JsonEntityStore(IWebHostEnvironment env) => _env = env;

    public async Task<ApiResult> GetAsync(EntityConfig entity, DataSourceConfig source, GetDataRequest request, CancellationToken ct)
    {
        var path = ResolvePath(source);
        await _gate.WaitAsync(ct);
        try
        {
            var rows = await ReadArrayAsync(path, ct);
            IEnumerable<JsonObject> query = rows.OfType<JsonObject>();

            if (request.Filters is { Count: > 0 })
            {
                foreach (var filter in request.Filters)
                {
                    if (string.IsNullOrWhiteSpace(filter.Value.ToString())) continue;
                    query = query.Where(row => Matches(row, filter.Key, filter.Value));
                }
            }

            var all = query.ToList();
            if (request.Action.Equals("GET", StringComparison.OrdinalIgnoreCase) && request.Filters is { Count: > 0 })
                return ApiResult.Ok(all.FirstOrDefault());

            var page = Math.Max(1, request.Page);
            var pageSize = Math.Clamp(request.PageSize, 1, 500);
            var paged = all.Skip((page - 1) * pageSize).Take(pageSize).ToList();
            return ApiResult.Ok(paged, totalRecords: all.Count);
        }
        finally { _gate.Release(); }
    }

    public async Task<ApiResult> CrudAsync(EntityConfig entity, DataSourceConfig source, CrudRequest request, CancellationToken ct)
    {
        var path = ResolvePath(source);
        await _gate.WaitAsync(ct);
        try
        {
            var rows = await ReadArrayAsync(path, ct);
            var action = request.Action.ToUpperInvariant();
            var keyName = entity.PrimaryKey;

            switch (action)
            {
                case "CREATE":
                {
                    var obj = ToJsonObject(request.Data);
                    if (obj[keyName] is null)
                        obj[keyName] = NextNumericKey(rows, keyName);
                    if (obj["CreatedOn"] is null) obj["CreatedOn"] = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    if (obj["Status"] is null) obj["Status"] = "Pending";
                    rows.Add(obj);
                    await WriteArrayAsync(path, rows, ct);
                    return ApiResult.Ok(obj, "Created successfully");
                }
                case "UPDATE":
                {
                    var row = FindByKey(rows, keyName, request.Keys) ?? throw new KeyNotFoundException("Record not found.");
                    if (request.Data is not null)
                        foreach (var pair in request.Data) row[pair.Key] = JsonNode.Parse(pair.Value.GetRawText());
                    row["ModifiedOn"] = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    await WriteArrayAsync(path, rows, ct);
                    return ApiResult.Ok(row, "Updated successfully");
                }
                case "DELETE":
                {
                    var row = FindByKey(rows, keyName, request.Keys) ?? throw new KeyNotFoundException("Record not found.");
                    rows.Remove(row);
                    await WriteArrayAsync(path, rows, ct);
                    return ApiResult.Ok(message: "Deleted successfully");
                }
                case "APPROVE":
                case "REJECT":
                {
                    var row = FindByKey(rows, keyName, request.Keys) ?? throw new KeyNotFoundException("Record not found.");
                    row["Status"] = action == "APPROVE" ? "Approved" : "Rejected";
                    row["Remarks"] = request.Remarks ?? string.Empty;
                    row["ModifiedOn"] = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    await WriteArrayAsync(path, rows, ct);
                    return ApiResult.Ok(row, $"{row["Status"]} successfully");
                }
                default:
                    return ApiResult.Fail($"Unsupported JSON CRUD action: {request.Action}");
            }
        }
        finally { _gate.Release(); }
    }

    private string ResolvePath(DataSourceConfig source)
    {
        if (string.IsNullOrWhiteSpace(source.FilePath)) throw new InvalidOperationException($"JSON source {source.Code} has no filePath.");
        return Path.GetFullPath(Path.Combine(_env.ContentRootPath, source.FilePath));
    }

    private static async Task<JsonArray> ReadArrayAsync(string path, CancellationToken ct)
    {
        if (!File.Exists(path)) return new JsonArray();
        var text = await File.ReadAllTextAsync(path, ct);
        return JsonNode.Parse(text)?.AsArray() ?? new JsonArray();
    }

    private static async Task WriteArrayAsync(string path, JsonArray rows, CancellationToken ct)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await File.WriteAllTextAsync(path, rows.ToJsonString(Options), ct);
    }

    private static JsonObject ToJsonObject(Dictionary<string, JsonElement>? data)
    {
        var obj = new JsonObject();
        if (data is null) return obj;
        foreach (var pair in data) obj[pair.Key] = JsonNode.Parse(pair.Value.GetRawText());
        return obj;
    }

    private static int NextNumericKey(JsonArray rows, string keyName)
    {
        var max = 0;
        foreach (var row in rows.OfType<JsonObject>())
        {
            if (int.TryParse(row[keyName]?.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
                max = Math.Max(max, value);
        }
        return max + 1;
    }

    private static JsonObject? FindByKey(JsonArray rows, string keyName, Dictionary<string, JsonElement>? keys)
    {
        if (keys is null || !keys.TryGetValue(keyName, out var keyValue)) return null;
        var expected = keyValue.ToString();
        return rows.OfType<JsonObject>().FirstOrDefault(x => string.Equals(x[keyName]?.ToString(), expected, StringComparison.OrdinalIgnoreCase));
    }

    private static bool Matches(JsonObject row, string field, JsonElement filter)
    {
        var actual = row[field]?.ToString() ?? string.Empty;
        var expected = filter.ToString();
        if (field.Equals("search", StringComparison.OrdinalIgnoreCase))
            return row.Any(kv => (kv.Value?.ToString() ?? string.Empty).Contains(expected, StringComparison.OrdinalIgnoreCase));
        return actual.Contains(expected, StringComparison.OrdinalIgnoreCase);
    }
}
