using EnterprisePlatform.Data;
using EnterprisePlatform.Models;

namespace EnterprisePlatform.Services;

public sealed class RequestRouter
{
    private readonly IPlatformConfigStore _configStore;
    private readonly JsonEntityStore _jsonStore;
    private readonly DatabaseExecutor _database;
    private readonly ExecutionLogStore _executionLogs;

    public RequestRouter(
        IPlatformConfigStore configStore,
        JsonEntityStore jsonStore,
        DatabaseExecutor database,
        ExecutionLogStore executionLogs)
    {
        _configStore = configStore;
        _jsonStore = jsonStore;
        _database = database;
        _executionLogs = executionLogs;
    }

    public async Task<ApiResult> GetDataAsync(GetDataRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Entity)) return ApiResult.Fail("Entity is required.");
        var config = await _configStore.GetAsync(ct);

        if (request.Entity.StartsWith('@'))
            return await GetSystemDataAsync(config, request, ct);

        var entity = ResolveEntity(config, request.ProjectCode, request.Entity);
        EnsureAllowed(entity.AllowedReadActions, request.Action, entity.Code);
        var source = ResolveSource(config, entity.DataSourceCode);
        EnsureSourceEnabled(source);

        return source.Provider.Equals("JSON", StringComparison.OrdinalIgnoreCase)
            ? await _jsonStore.GetAsync(entity, source, request, ct)
            : await _database.GetAsync(entity, source, request, ct);
    }

    public async Task<ApiResult> CrudAsync(CrudRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Entity)) return ApiResult.Fail("Entity is required.");
        if (string.IsNullOrWhiteSpace(request.Action)) return ApiResult.Fail("Action is required.");
        var config = await _configStore.GetAsync(ct);

        if (request.Entity.StartsWith('@'))
            return await CrudSystemDataAsync(config, request, ct);

        var entity = ResolveEntity(config, request.ProjectCode, request.Entity);
        EnsureAllowed(entity.AllowedWriteActions, request.Action, entity.Code);
        var source = ResolveSource(config, entity.DataSourceCode);
        EnsureSourceEnabled(source);

        return source.Provider.Equals("JSON", StringComparison.OrdinalIgnoreCase)
            ? await _jsonStore.CrudAsync(entity, source, request, ct)
            : await _database.CrudAsync(entity, source, request, ct);
    }

    private async Task<ApiResult> GetSystemDataAsync(PlatformConfig config, GetDataRequest request, CancellationToken ct)
    {
        var entity = request.Entity.ToUpperInvariant();
        return entity switch
        {
            "@PROJECTS" => ApiResult.Ok(config.Projects.Where(x => x.Enabled).OrderBy(x => x.Name)),
            "@DATASOURCES" => ApiResult.Ok(config.DataSources.OrderBy(x => x.Name)),
            "@ENTITIES" => ApiResult.Ok(config.Entities.Where(x => x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Name)),
            "@PAGES" => ApiResult.Ok(config.Pages.Where(x => x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Order)),
            "@PAGE" => GetPage(config, request),
            "@SCHEDULES" => ApiResult.Ok(config.Schedules.Where(x => x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Name)),
            "@EXECUTIONS" => ApiResult.Ok((await _executionLogs.GetAsync(ct)).Where(x => x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase)).Take(200)),
            "@DASHBOARD" => await GetDashboardAsync(config, request, ct),
            _ => ApiResult.Fail($"Unknown system entity: {request.Entity}")
        };
    }

    private static ApiResult GetPage(PlatformConfig config, GetDataRequest request)
    {
        var code = request.Filters is not null && request.Filters.TryGetValue("code", out var value) ? value.ToString() : string.Empty;
        var page = config.Pages.FirstOrDefault(x =>
            x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase) &&
            x.Code.Equals(code, StringComparison.OrdinalIgnoreCase));
        return page is null ? ApiResult.Fail($"Page '{code}' not found.") : ApiResult.Ok(page);
    }

    private async Task<ApiResult> GetDashboardAsync(PlatformConfig config, GetDataRequest request, CancellationToken ct)
    {
        var project = config.Projects.FirstOrDefault(x => x.Code.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase));
        var schedules = config.Schedules.Where(x => x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase)).ToList();
        var logs = (await _executionLogs.GetAsync(ct)).Where(x => x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase)).Take(20).ToList();
        return ApiResult.Ok(new
        {
            project,
            pageCount = config.Pages.Count(x => x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase)),
            entityCount = config.Entities.Count(x => x.ProjectCode.Equals(request.ProjectCode, StringComparison.OrdinalIgnoreCase)),
            activeSchedules = schedules.Count(x => x.Enabled),
            lastExecution = logs.FirstOrDefault()
        });
    }

    private async Task<ApiResult> CrudSystemDataAsync(PlatformConfig config, CrudRequest request, CancellationToken ct)
    {
        if (!request.Entity.Equals("@SCHEDULES", StringComparison.OrdinalIgnoreCase))
            return ApiResult.Fail("Only schedule administration is enabled in this demo system configuration API.");

        if (!request.Action.Equals("UPDATE", StringComparison.OrdinalIgnoreCase))
            return ApiResult.Fail("Only UPDATE is supported for @SCHEDULES.");

        var code = request.Keys is not null && request.Keys.TryGetValue("code", out var key) ? key.ToString() : string.Empty;
        var schedule = config.Schedules.FirstOrDefault(x => x.Code.Equals(code, StringComparison.OrdinalIgnoreCase));
        if (schedule is null) return ApiResult.Fail($"Schedule '{code}' not found.");

        if (request.Data is not null)
        {
            if (request.Data.TryGetValue("enabled", out var enabled) && enabled.ValueKind is System.Text.Json.JsonValueKind.True or System.Text.Json.JsonValueKind.False)
                schedule.Enabled = enabled.GetBoolean();
            if (request.Data.TryGetValue("time", out var time) && time.ValueKind == System.Text.Json.JsonValueKind.String)
                schedule.Time = time.GetString();
            if (request.Data.TryGetValue("intervalMinutes", out var interval) && interval.TryGetInt32(out var minutes))
                schedule.IntervalMinutes = minutes;
        }

        await _configStore.SaveAsync(config, ct);
        return ApiResult.Ok(schedule, "Schedule updated");
    }

    private static EntityConfig ResolveEntity(PlatformConfig config, string projectCode, string entityCode)
        => config.Entities.FirstOrDefault(x =>
               x.ProjectCode.Equals(projectCode, StringComparison.OrdinalIgnoreCase) &&
               x.Code.Equals(entityCode, StringComparison.OrdinalIgnoreCase))
           ?? throw new KeyNotFoundException($"Entity '{projectCode}/{entityCode}' is not configured.");

    private static DataSourceConfig ResolveSource(PlatformConfig config, string code)
        => config.DataSources.FirstOrDefault(x => x.Code.Equals(code, StringComparison.OrdinalIgnoreCase))
           ?? throw new KeyNotFoundException($"Data source '{code}' is not configured.");

    private static void EnsureAllowed(IEnumerable<string> allowed, string action, string entity)
    {
        if (!allowed.Any(x => x.Equals(action, StringComparison.OrdinalIgnoreCase)))
            throw new UnauthorizedAccessException($"Action '{action}' is not allowed for entity '{entity}'.");
    }

    private static void EnsureSourceEnabled(DataSourceConfig source)
    {
        if (!source.Enabled) throw new InvalidOperationException($"Data source '{source.Code}' is disabled.");
    }
}
