@echo off
setlocal
cd /d %~dp0
echo Restoring packages...
dotnet restore
if errorlevel 1 goto :error

echo Starting Enterprise Platform...
dotnet run --project .\src\EnterprisePlatform\EnterprisePlatform.csproj
goto :eof

:error
echo.
echo Failed. Confirm .NET 8 SDK is installed and NuGet access is available.
pause
exit /b 1
