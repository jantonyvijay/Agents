# Config Driven Enterprise Platform

A runnable starter application for the architecture discussed:

- Lightweight **HTML + CSS + jQuery** UI.
- Exactly **two business API endpoints**:
  - `POST /api/GetData`
  - `POST /api/CrudRequest`
- UI pages, fields, columns and actions come from configuration.
- One configuration-driven scheduler executes all project jobs.
- Manual CSV import through the same `CrudRequest` API.
- Server-side file-drop/DCPFTP-style scheduled import sample.
- Multi-database runtime support:
  - SQL Server
  - Oracle
  - PostgreSQL
- Demo runs without any database by using a JSON data source.

## Solution

```text
ConfigDrivenEnterprisePlatform/
├─ ConfigDrivenEnterprisePlatform.sln
├─ src/EnterprisePlatform/
│  ├─ Program.cs
│  ├─ Config/platform-config.json
│  ├─ Data/DatabaseExecutor.cs
│  ├─ Jobs/
│  │  ├─ ConfigSchedulerService.cs
│  │  ├─ ConfiguredJobExecutor.cs
│  │  └─ ScheduleCalculator.cs
│  ├─ Services/
│  │  ├─ RequestRouter.cs
│  │  ├─ JsonEntityStore.cs
│  │  └─ JsonPlatformConfigStore.cs
│  └─ wwwroot/
│     ├─ index.html
│     ├─ css/app.css
│     └─ js/app.js
├─ database/
│  ├─ sqlserver-sample.sql
│  ├─ oracle-sample.sql
│  ├─ postgresql-sample.sql
│  └─ platform-config-schema.sql
└─ docs/
   ├─ API-EXAMPLES.md
   └─ sample-import.csv
```

## Run locally

Prerequisites:

1. Install .NET 8 SDK.
2. Internet access during `dotnet restore` for NuGet packages.
3. Internet access from the browser for the jQuery CDN, or host jQuery locally in `wwwroot/lib`.

Commands:

```powershell
cd ConfigDrivenEnterprisePlatform
dotnet restore
dotnet run --project .\src\EnterprisePlatform\EnterprisePlatform.csproj
```

Open the URL printed by ASP.NET Core in the terminal.

The demo starts with three sample cases. The enabled `DEMO_CASE_POLL` scheduler job will run automatically and will appear in **Execution Log**.

## What is configurable

Edit:

```text
src/EnterprisePlatform/Config/platform-config.json
```

The configuration contains:

- projects
- data sources
- entities
- read/write commands
- parameter bindings
- pages
- fields
- columns
- actions
- schedules
- scheduler jobs

A normal new application therefore does not need a new controller or a new scheduler executable.

## Two API model

### Read

```text
POST /api/GetData
```

Used for page metadata, grids, dropdown-style data, dashboard information, schedules, execution logs, and normal business reads.

### Write

```text
POST /api/CrudRequest
```

Used for create, update, delete, approve, reject and platform configuration updates enabled by the server.

See `docs/API-EXAMPLES.md`.

## Important security design

The browser never sends SQL text, procedure names or connection strings.

The browser sends only:

```text
ProjectCode + Entity + Action + Values
```

The server resolves the permitted data source and command from configuration. This is intentional; do not change the design to accept SQL from the client.

For production, add your existing enterprise authentication/SSO and role authorization before exposing the application.

## SQL Server configuration

Set an environment variable on the application server:

```powershell
setx CORE_SQL_CONNECTION "Server=SERVER;Database=DB;Integrated Security=True;TrustServerCertificate=True;"
```

Then enable `CORE_SQL` in `platform-config.json`.

Example configured command:

```json
"LIST:SQLSERVER": {
  "type": "StoredProcedure",
  "text": "dbo.usp_Customer_List",
  "parameters": [
    { "name": "@Status", "source": "filter:status", "dbType": "String", "required": false }
  ]
}
```

Run `database/sqlserver-sample.sql` for a sample table/procedure.

## Oracle configuration

Set:

```powershell
setx CORE_ORACLE_CONNECTION "User Id=USER;Password=PASSWORD;Data Source=HOST:1521/SERVICE;"
```

Enable `CORE_ORACLE` in the configuration. The runtime sets Oracle command `BindByName=true` when supported.

Run `database/oracle-sample.sql` for a sample table.

## PostgreSQL configuration

Set:

```powershell
setx CORE_POSTGRES_CONNECTION "Host=HOST;Port=5432;Database=DB;Username=USER;Password=PASSWORD;"
```

Enable `CORE_POSTGRES` in configuration.

Run `database/postgresql-sample.sql` for a sample table.

## Scheduler configuration

The application has one common `BackgroundService` scheduler. It periodically reads configuration and executes due jobs.

Supported starter job types:

### `GETDATA`
Runs a configured entity read. Useful for polling/validation/demo jobs.

### `COPY_ENTITY`
Reads from one configured entity and creates rows in another configured entity. The source and target may use different database providers.

### `FILEDROP_IMPORT`
Reads configured CSV files from a server folder and inserts them into a configured target entity, then archives the files.

Example:

```json
{
  "code": "DCPFTP_IMPORT_SAMPLE",
  "projectCode": "DEMO",
  "name": "DCPFTP File Import Sample",
  "enabled": false,
  "scheduleType": "DAILY",
  "time": "06:00",
  "job": {
    "type": "FILEDROP_IMPORT",
    "targetEntity": "CASES",
    "sourceFolder": "C:\\DCPFTP\\Input",
    "filePattern": "*.csv",
    "archiveFolder": "C:\\DCPFTP\\Archive"
  }
}
```

There is no Windows Task Scheduler entry per project.

## IIS / application server

For a demo or low-risk internal environment, the included scheduler runs inside the same ASP.NET Core process.

For production workloads where schedules must run even when IIS is recycled or idle, keep the same configuration/runtime design but host the scheduler as a dedicated Windows Service on the **same application server**. That avoids tying critical schedule execution to the IIS process lifecycle.

Recommended production deployment:

```text
Application Server
├─ IIS
│  └─ EnterprisePlatform API + jQuery UI
├─ Windows Service
│  └─ Configuration Scheduler Runtime
└─ Secure connection/environment settings

Database Servers
├─ SQL Server
├─ Oracle
└─ PostgreSQL
```

The Web API and scheduler should share the same configuration repository and common execution library.

## Manual CSV upload

Open **Case Management → Import CSV** and select `docs/sample-import.csv`.

The browser parses the file and sends normal `CREATE` requests to `/api/CrudRequest`; no third upload API is needed for this starter implementation.

For very large files, change the implementation to server-side staged file storage while keeping the business operation routed through `CrudRequest`.

## Production items to add next

The starter intentionally concentrates on the architecture you requested. Before bank/enterprise production use, add:

- SSO / Entra ID or your corporate authentication.
- role/page/action authorization.
- maker-checker role separation.
- centralized audit trail in a database.
- secret vault integration instead of plain connection strings.
- scheduler leader election/distributed lock if more than one scheduler instance runs.
- retry/dead-letter/error queue for channel jobs.
- file checksum/idempotency to prevent duplicate imports.
- structured logging and monitoring.
- request size/rate limits.
- antivirus/content validation for uploaded files.
- deployment pipeline and environment-specific configuration.

## Notes

The current configuration store is JSON so the demo runs immediately. `database/platform-config-schema.sql` provides a starting schema for moving platform metadata into a central SQL configuration database later without changing the browser/API contract.
