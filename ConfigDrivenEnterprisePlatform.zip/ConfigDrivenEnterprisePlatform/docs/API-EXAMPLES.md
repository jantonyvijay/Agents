# Two Generic Business APIs

## 1. POST `/api/GetData`

### List records
```json
{
  "projectCode": "DEMO",
  "entity": "CASES",
  "action": "LIST",
  "filters": { "status": "Pending" },
  "page": 1,
  "pageSize": 50
}
```

### Fetch page metadata
```json
{
  "projectCode": "DEMO",
  "entity": "@PAGE",
  "action": "GET",
  "filters": { "code": "CASES" }
}
```

## 2. POST `/api/CrudRequest`

### Create
```json
{
  "projectCode": "DEMO",
  "entity": "CASES",
  "action": "CREATE",
  "data": {
    "AccountNo": "XXXX9999",
    "CustomerName": "New Customer",
    "RiskCategory": "HIGH",
    "Remarks": "Created by generic API"
  }
}
```

### Update
```json
{
  "projectCode": "DEMO",
  "entity": "CASES",
  "action": "UPDATE",
  "keys": { "CaseId": 1001 },
  "data": { "RiskCategory": "MEDIUM" }
}
```

### Approve
```json
{
  "projectCode": "DEMO",
  "entity": "CASES",
  "action": "APPROVE",
  "keys": { "CaseId": 1001 },
  "remarks": "Approved by checker"
}
```

## Important security rule
The UI never sends SQL, stored procedure names, connection strings, or table names. It sends only configured project/entity/action/values. The server resolves the permitted command from configuration.
