param(
    [string]$Output = ".\publish"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

dotnet restore
dotnet publish .\src\EnterprisePlatform\EnterprisePlatform.csproj -c Release -o $Output

Write-Host "Published to $Output" -ForegroundColor Cyan
Write-Host "Create an IIS site/application pointing to this folder and use an ASP.NET Core No Managed Code app pool." -ForegroundColor Cyan
Write-Host "For production-grade scheduling, split/host the scheduler as a Windows Service on the same application server." -ForegroundColor Yellow
