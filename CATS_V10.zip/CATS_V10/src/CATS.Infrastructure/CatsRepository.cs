using System.Data.Common;
using System.Text.Json;
using CATS.Core;

namespace CATS.Infrastructure;

public sealed class CatsRepository(AdoHelper db) : ICatsRepository
{
    private sealed record RepositoryRoute(string ModuleCode, string MethodCode);

    private static readonly IReadOnlyDictionary<string,RepositoryRoute> Routes =
        new Dictionary<string,RepositoryRoute>(StringComparer.OrdinalIgnoreCase)
    {
        ["GetUserByUserName"] = new("User", "GetByUserName"),
        ["GetUserById"] = new("User", "GetById"),
        ["GetUsers"] = new("User", "GetAll"),
        ["UpsertUser"] = new("User", "Upsert"),
        ["GetTemplates"] = new("Template", "GetAll"),
        ["GetTemplate"] = new("Template", "GetById"),
        ["SaveTemplate"] = new("Template", "Save"),
        ["GetWorkflow"] = new("Workflow", "GetById"),
        ["GetPublishedWorkflowForTemplate"] = new("Workflow", "GetPublishedByTemplate"),
        ["SaveWorkflow"] = new("Workflow", "Save"),
        ["InsertAlert"] = new("Alert", "Insert"),
        ["InsertWorkflowInstance"] = new("WorkflowInstance", "Insert"),
        ["UpdateWorkflowInstance"] = new("WorkflowInstance", "Update"),
        ["TryClaimStageTransition"] = new("WorkflowInstance", "TryClaimStageTransition"),
        ["ReleaseStageTransitionClaim"] = new("WorkflowInstance", "ReleaseStageTransitionClaim"),
        ["UpdateAlertStage"] = new("Alert", "UpdateStage"),
        ["UpdateAlertDynamicData"] = new("Alert", "UpdateDynamicData"),
        ["GetAlert"] = new("Alert", "GetById"),
        ["GetWorkflowInstanceByAlert"] = new("WorkflowInstance", "GetByAlert"),
        ["InsertWorkItems"] = new("WorkItem", "Insert"),
        ["GetPendingWorkItems"] = new("WorkItem", "GetPending"),
        ["GetWorkItem"] = new("WorkItem", "GetById"),
        ["GetWorkItems"] = new("WorkItem", "GetAllByAlert"),
        ["CompleteWorkItem"] = new("WorkItem", "Complete"),
        ["ReassignPendingWorkItems"] = new("WorkItem", "ReassignPending"),
        ["CancelPendingWorkItems"] = new("WorkItem", "CancelPending"),
        ["GetParallelWorkItems"] = new("WorkItem", "GetParallel"),
        ["InsertQuery"] = new("Query", "Insert"),
        ["RespondLatestOpenQuery"] = new("Query", "RespondLatestOpen"),
        ["GetQueries"] = new("Query", "GetAllByAlert"),
        ["InsertAttachment"] = new("Attachment", "Insert"),
        ["GetAttachments"] = new("Attachment", "GetAllByAlert"),
        ["GetAttachment"] = new("Attachment", "GetById"),
        ["InsertAudit"] = new("Audit", "Insert"),
        ["GetAudit"] = new("Audit", "GetByAlert"),
        ["GetAgingBuckets"] = new("Aging", "GetBuckets"),
        ["SaveAgingBucket"] = new("Aging", "SaveBucket"),
        ["GetDashboardAging"] = new("Dashboard", "GetAging"),
        ["GetAlertsCount"] = new("Alert", "GetCount"),
        ["GetAlerts"] = new("Alert", "GetPaged"),
        ["GetTemplateName"] = new("Template", "GetName"),
        ["GetRoleCodes"] = new("Security", "GetRoleCodes")
    };

    private static string NewId() => Guid.NewGuid().ToString("N");

    public Task<UserRecord?> GetUserByUserNameAsync(string userName, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetUserByUserName", MapUser, new { userName }, ct);

    public Task<UserRecord?> GetUserByIdAsync(string id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetUserById", MapUser, new { id }, ct);

    public Task<IReadOnlyList<UserRecord>> GetUsersAsync(CancellationToken ct = default) =>
        QueryOperationAsync("GetUsers", MapUser, null, ct);

    public Task UpsertUserAsync(UserRecord user, bool isNew, CancellationToken ct = default) =>
        ExecuteOperationAsync("UpsertUser", new
        {
            isNew, user.Id, user.UserName, user.DisplayName, user.PasswordHash, user.RoleCode,
            user.DepartmentCode, user.BranchCode, user.PermissionsJson, user.IsActive
        }, ct);

    public Task<IReadOnlyList<TemplateRecord>> GetTemplatesAsync(CancellationToken ct = default) =>
        QueryOperationAsync("GetTemplates", MapTemplate, null, ct);

    public Task<TemplateRecord?> GetTemplateAsync(string id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetTemplate", MapTemplate, new { id }, ct);

    public async Task<TemplateRecord> SaveTemplateAsync(SaveTemplateRequest request, CurrentUser user, CancellationToken ct = default)
    {
        var saved = await QuerySingleOperationAsync("SaveTemplate", MapTemplate, new
        {
            request.Id,
            request.Code,
            request.Name,
            executionMode = request.ExecutionMode.ToString(),
            sectionsJson = JsonSerializer.Serialize(request.Sections, JsonDefaults.Options),
            fieldsJson = JsonSerializer.Serialize(request.Fields, JsonDefaults.Options),
            viewConfigurationJson = JsonSerializer.Serialize(request.ViewConfiguration, JsonDefaults.Options),
            assignmentRulesJson = request.AssignmentRules.ValueKind == JsonValueKind.Undefined ? "[]" : request.AssignmentRules.GetRawText(),
            createdBy = user.UserName,
            nowUtc = DateTime.UtcNow
        }, ct);
        return saved ?? throw new InvalidOperationException("The template was not returned after it was saved.");
    }

    public Task RetireTemplateAsync(string id, CancellationToken ct = default) =>
        db.ExecuteAsync($"UPDATE Templates SET Status={db.Dialect.P("Status")} WHERE Id={db.Dialect.P("Id")}",
            [new("Status", TemplateStatus.Retired.ToString()), new("Id", id)], ct);

    public Task<WorkflowDefinitionRecord?> GetWorkflowAsync(string id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetWorkflow", MapWorkflow, new { id }, ct);

    public Task<WorkflowDefinitionRecord?> GetPublishedWorkflowForTemplateAsync(string templateId, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetPublishedWorkflowForTemplate", MapWorkflow, new { templateId }, ct);

    public async Task<WorkflowDefinitionRecord> SaveWorkflowAsync(SaveWorkflowRequest request, CurrentUser user, CancellationToken ct = default)
    {
        ValidateWorkflow(request.Definition);
        var saved = await QuerySingleOperationAsync("SaveWorkflow", MapWorkflow, new
        {
            request.TemplateId,
            request.Name,
            definitionJson = JsonSerializer.Serialize(request.Definition, JsonDefaults.Options),
            request.Publish,
            createdBy = user.UserName,
            nowUtc = DateTime.UtcNow
        }, ct);
        return saved ?? throw new InvalidOperationException("The workflow was not returned after it was saved.");
    }

    public async Task<AlertRecord> InsertAlertAsync(AlertRecord alert, CancellationToken ct = default)
    {
        await ExecuteOperationAsync("InsertAlert", alert, ct);
        return alert;
    }

    public async Task<WorkflowInstanceRecord> InsertWorkflowInstanceAsync(WorkflowInstanceRecord instance, CancellationToken ct = default)
    {
        await ExecuteOperationAsync("InsertWorkflowInstance", instance, ct);
        return instance;
    }

    public Task UpdateWorkflowInstanceAsync(WorkflowInstanceRecord instance, CancellationToken ct = default) =>
        ExecuteOperationAsync("UpdateWorkflowInstance", instance, ct);

    public async Task<bool> TryClaimStageTransitionAsync(string instanceId, string expectedStageId, CancellationToken ct = default) =>
        await QuerySingleOperationAsync("TryClaimStageTransition", r => r.Bool("Claimed"),
            new { instanceId, expectedStageId, nowUtc = DateTime.UtcNow }, ct);

    public Task ReleaseStageTransitionClaimAsync(string instanceId, string expectedStageId, CancellationToken ct = default) =>
        ExecuteOperationAsync("ReleaseStageTransitionClaim", new { instanceId, expectedStageId, nowUtc = DateTime.UtcNow }, ct);

    public Task UpdateAlertStageAsync(string alertId, string stageId, string stageName, AlertStatus status, DateTime enteredAtUtc, CancellationToken ct = default) =>
        ExecuteOperationAsync("UpdateAlertStage", new { alertId, stageId, stageName, status = status.ToString(), enteredAtUtc }, ct);

    public Task UpdateAlertDynamicDataAsync(string alertId, string dynamicDataJson, CancellationToken ct = default) =>
        ExecuteOperationAsync("UpdateAlertDynamicData", new { alertId, dynamicDataJson }, ct);

    public Task<AlertRecord?> GetAlertAsync(string alertId, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetAlert", MapAlert, new { alertId }, ct);

    public Task<WorkflowInstanceRecord?> GetWorkflowInstanceByAlertAsync(string alertId, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetWorkflowInstanceByAlert", MapInstance, new { alertId }, ct);

    public Task InsertWorkItemsAsync(IEnumerable<WorkItemRecord> items, CancellationToken ct = default) =>
        ExecuteOperationAsync("InsertWorkItems", new { items = items.ToList() }, ct);

    public Task<IReadOnlyList<WorkItemRecord>> GetPendingWorkItemsAsync(string alertId, CancellationToken ct = default) =>
        QueryOperationAsync("GetPendingWorkItems", MapWorkItem, new { alertId }, ct);

    public Task<IReadOnlyList<WorkItemRecord>> GetWorkItemsAsync(string alertId, CancellationToken ct = default) =>
        QueryOperationAsync("GetWorkItems", MapWorkItem, new { alertId }, ct);

    public Task<WorkItemRecord?> GetWorkItemAsync(string id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetWorkItem", MapWorkItem, new { id }, ct);

    public Task CompleteWorkItemAsync(string id, string action, CurrentUser user, string? remarks, CancellationToken ct = default) =>
        ExecuteOperationAsync("CompleteWorkItem", new { id, action, completedBy = user.UserName, remarks, nowUtc = DateTime.UtcNow }, ct);

    public Task ReassignPendingWorkItemsAsync(string alertId, string stageId, string? roleCode, string? branchCode, string? userId, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(roleCode) && string.IsNullOrWhiteSpace(userId))
            throw new InvalidOperationException("RoleCode or UserId is required for reassignment.");
        return ExecuteOperationAsync("ReassignPendingWorkItems", new
        {
            alertId, stageId, roleCode = roleCode ?? "", branchCode = branchCode ?? "", userId
        }, ct);
    }

    public Task CancelPendingWorkItemsAsync(string alertId, string? parallelGroupId, CancellationToken ct = default) =>
        ExecuteOperationAsync("CancelPendingWorkItems", new { alertId, groupId = parallelGroupId }, ct);

    public Task<IReadOnlyList<WorkItemRecord>> GetParallelWorkItemsAsync(string alertId, string parallelGroupId, CancellationToken ct = default) =>
        QueryOperationAsync("GetParallelWorkItems", MapWorkItem, new { alertId, parallelGroupId }, ct);

    public Task InsertQueryAsync(QueryRecord query, CancellationToken ct = default) =>
        ExecuteOperationAsync("InsertQuery", query, ct);

    public Task RespondLatestOpenQueryAsync(string alertId, CurrentUser user, string responseText, CancellationToken ct = default) =>
        ExecuteOperationAsync("RespondLatestOpenQuery", new
        {
            alertId, responseText, respondedBy = user.UserName, nowUtc = DateTime.UtcNow
        }, ct);

    public Task<IReadOnlyList<QueryRecord>> GetQueriesAsync(string alertId, CancellationToken ct = default) =>
        QueryOperationAsync("GetQueries", MapQuery, new { alertId }, ct);

    public Task InsertAttachmentAsync(AttachmentRecord attachment, CancellationToken ct = default) =>
        ExecuteOperationAsync("InsertAttachment", attachment, ct);

    public Task<IReadOnlyList<AttachmentRecord>> GetAttachmentsAsync(string alertId, CancellationToken ct = default) =>
        QueryOperationAsync("GetAttachments", MapAttachment, new { alertId }, ct);

    public Task<AttachmentRecord?> GetAttachmentAsync(string id, CancellationToken ct = default) =>
        QuerySingleOperationAsync("GetAttachment", MapAttachment, new { id }, ct);

    public Task InsertAuditAsync(AuditRecord audit, CancellationToken ct = default) =>
        ExecuteOperationAsync("InsertAudit", audit, ct);

    public Task<IReadOnlyList<AuditRecord>> GetAuditAsync(string alertId, int take = 100, CancellationToken ct = default) =>
        QueryOperationAsync("GetAudit", MapAudit, new { alertId, take = Math.Clamp(take, 1, 500) }, ct);

    public Task<IReadOnlyList<AgingBucket>> GetAgingBucketsAsync(CancellationToken ct = default) =>
        QueryOperationAsync("GetAgingBuckets", MapAgingBucket, null, ct);

    public Task SaveAgingBucketAsync(SaveAgingBucketRequest request, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(request.Name)) throw new InvalidOperationException("Aging bucket name is required.");
        if (request.FromDays < 0 || (request.ToDays.HasValue && request.ToDays.Value < request.FromDays))
            throw new InvalidOperationException("Invalid aging range.");
        return ExecuteOperationAsync("SaveAgingBucket", new
        {
            id = string.IsNullOrWhiteSpace(request.Id) ? NewId() : request.Id,
            isNew = string.IsNullOrWhiteSpace(request.Id),
            name = request.Name.Trim(), request.FromDays, request.ToDays, request.DisplayOrder, request.IsActive
        }, ct);
    }

    public async Task<DashboardAgingResponse> GetDashboardAgingAsync(CurrentUser user, AlertListFilter? filter = null, CancellationToken ct = default)
    {
        var buckets = (await GetAgingBucketsAsync(ct)).ToList();
        var raw = await QueryOperationAsync("GetDashboardAging", r => new DashboardAgingSource(
            r.Str("TemplateId"), r.Str("TemplateName"), r.Str("AlertType"), r.Dt("StageEnteredAtUtc")),
            CreateAlertFilterInput(filter, user), ct);
        var response = new DashboardAgingResponse { Buckets = buckets };
        foreach (var group in raw.GroupBy(x => new { x.TemplateId, x.TemplateName, x.AlertType }))
        {
            var row = new DashboardAgingRow
            {
                TemplateId = group.Key.TemplateId, TemplateName = group.Key.TemplateName, AlertType = group.Key.AlertType
            };
            foreach (var bucket in buckets) row.Counts[bucket.Name] = 0;
            foreach (var item in group)
            {
                var age = Math.Max(0, (int)Math.Floor((DateTime.UtcNow - item.EnteredAtUtc).TotalDays));
                var bucket = buckets.FirstOrDefault(b => age >= b.FromDays && (!b.ToDays.HasValue || age <= b.ToDays.Value));
                if (bucket != null) row.Counts[bucket.Name]++;
                row.Total++;
            }
            response.Rows.Add(row);
        }
        return response;
    }

    public async Task<PagedResult<AlertListItem>> GetAlertsAsync(AlertListFilter filter, CurrentUser user, Func<string, string> decrypt, Func<string, string> mask, CancellationToken ct = default)
    {
        filter.Page = Math.Max(1, filter.Page);
        filter.PageSize = Math.Clamp(filter.PageSize, 10, 100);
        var input = CreateAlertFilterInput(filter, user);
        var totalRecords = await ScalarOperationAsync<int>("GetAlertsCount", input, ct);
        var rows = await QueryOperationAsync("GetAlerts", r =>
        {
            var customer = SafeDecrypt(r.Str("CustomerIdEncrypted"), decrypt);
            var account = SafeDecrypt(r.Str("AccountIdEncrypted"), decrypt);
            return new AlertListItem
            {
                Id = r.Str("Id"), AlertNo = r.Str("AlertNo"), TemplateName = r.Str("TemplateName"),
                AlertType = r.Str("AlertType"), BranchCode = r.Str("BranchCode"),
                CustomerId = user.HasPermission(CatsPermissions.PiiUnmask) ? customer : mask(customer),
                AccountId = user.HasPermission(CatsPermissions.PiiUnmask) ? account : mask(account),
                CurrentStageName = r.Str("CurrentStageName"), Status = r.Str("Status"), Priority = r.Str("Priority"),
                OverallAgingDays = r.Int("OverallAge"), StageAgingDays = r.Int("StageAge")
            };
        }, input, ct);
        return new PagedResult<AlertListItem>
        {
            Page = filter.Page, PageSize = filter.PageSize, TotalRecords = totalRecords, Data = rows.ToList()
        };
    }

    public async Task<string> GetTemplateNameAsync(string templateId, CancellationToken ct = default) =>
        await ScalarOperationAsync<string>("GetTemplateName", new { templateId }, ct) ?? "";

    public Task<IReadOnlyList<string>> GetRoleCodesAsync(CancellationToken ct = default) =>
        QueryOperationAsync("GetRoleCodes", r => r.Str("RoleCode"), null, ct);

    private static object CreateAlertFilterInput(AlertListFilter? filter, CurrentUser user) => new
    {
        userId = user.Id,
        roleCode = user.RoleCode,
        userBranchCode = user.BranchCode,
        canViewAll = user.HasPermission(CatsPermissions.AlertViewAll),
        templateId = filter?.TemplateId,
        alertType = filter?.AlertType,
        filterBranchCode = filter?.BranchCode,
        status = filter?.Status,
        search = filter?.Search?.Trim(),
        agingFrom = filter?.AgingFrom,
        agingTo = filter?.AgingTo,
        page = filter?.Page ?? 1,
        pageSize = filter?.PageSize ?? 20
    };

    private static RepositoryRoute ResolveRoute(string operation) =>
        Routes.TryGetValue(operation, out var route)
            ? route
            : throw new InvalidOperationException($"No repository route is configured for Cats operation '{operation}'.");

    private static string JsonInput(object? input) =>
        JsonSerializer.Serialize(input ?? new { }, JsonDefaults.Options);

    private async Task<IReadOnlyList<T>> QueryOperationAsync<T>(string operation, Func<DbDataReader, T> map, object? input, CancellationToken ct)
    {
        var route = ResolveRoute(operation);
        return await db.QueryRepositoryAsync(route.ModuleCode, route.MethodCode, JsonInput(input), map, ct);
    }

    private Task<T?> QuerySingleOperationAsync<T>(string operation, Func<DbDataReader, T> map, object? input, CancellationToken ct)
    {
        var route = ResolveRoute(operation);
        return db.QuerySingleRepositoryAsync(route.ModuleCode, route.MethodCode, JsonInput(input), map, ct);
    }

    private Task<int> ExecuteOperationAsync(string operation, object? input, CancellationToken ct)
    {
        var route = ResolveRoute(operation);
        return db.ExecuteRepositoryAsync(route.ModuleCode, route.MethodCode, JsonInput(input), ct);
    }

    private Task<T?> ScalarOperationAsync<T>(string operation, object? input, CancellationToken ct)
    {
        var route = ResolveRoute(operation);
        return db.ScalarRepositoryAsync<T>(route.ModuleCode, route.MethodCode, JsonInput(input), ct);
    }

    private static string SafeDecrypt(string value, Func<string, string> decrypt)
    {
        try { return decrypt(value); }
        catch { return ""; }
    }

    private static void ValidateWorkflow(WorkflowDefinitionModel definition)
    {
        if (string.IsNullOrWhiteSpace(definition.StartStageId)) throw new InvalidOperationException("StartStageId is required.");
        if (definition.Stages.Count == 0) throw new InvalidOperationException("At least one workflow stage is required.");
        if (definition.Stages.Select(x => x.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() != definition.Stages.Count)
            throw new InvalidOperationException("Workflow stage IDs must be unique.");
        _ = definition.GetStage(definition.StartStageId);
        foreach (var stage in definition.Stages)
        {
            foreach (var transition in stage.Transitions.Where(x => !string.IsNullOrWhiteSpace(x.ToStageId)))
                _ = definition.GetStage(transition.ToStageId!);
            foreach (var condition in stage.Conditions) _ = definition.GetStage(condition.ToStageId);
            if (!string.IsNullOrWhiteSpace(stage.DefaultNextStageId)) _ = definition.GetStage(stage.DefaultNextStageId!);
            if (stage.Type == StageType.Human && string.IsNullOrWhiteSpace(stage.RoleCode))
                throw new InvalidOperationException($"Role is required for human stage {stage.Name}.");
            if (stage.Type == StageType.ParallelApproval && stage.Approvers.Count == 0)
                throw new InvalidOperationException($"Approvers are required for parallel stage {stage.Name}.");
        }
    }

    private static UserRecord MapUser(DbDataReader r) => new() { Id = r.Str("Id"), UserName = r.Str("UserName"), DisplayName = r.Str("DisplayName"), PasswordHash = r.Str("PasswordHash"), RoleCode = r.Str("RoleCode"), DepartmentCode = r.Str("DepartmentCode"), BranchCode = r.Str("BranchCode"), PermissionsJson = r.Str("PermissionsJson"), IsActive = r.Bool("IsActive") };
    private static TemplateRecord MapTemplate(DbDataReader r) => new() { Id = r.Str("Id"), Code = r.Str("Code"), Name = r.Str("Name"), Version = r.Int("Version"), Status = Enum.TryParse<TemplateStatus>(r.Str("Status"), true, out var s) ? s : TemplateStatus.Draft, ExecutionMode = Enum.TryParse<ExecutionMode>(r.Str("ExecutionMode"), true, out var m) ? m : ExecutionMode.Deterministic, SectionsJson = r.Str("SectionsJson"), FieldsJson = r.Str("FieldsJson"), AssignmentRulesJson = r.Str("AssignmentRulesJson"), ViewConfigurationJson = r.HasColumn("ViewConfigurationJson") ? r.Str("ViewConfigurationJson") : "{}", PublishedWorkflowId = r.NStr("PublishedWorkflowId"), CreatedAtUtc = r.Dt("CreatedAtUtc"), CreatedBy = r.Str("CreatedBy") };
    private static WorkflowDefinitionRecord MapWorkflow(DbDataReader r) => new() { Id = r.Str("Id"), TemplateId = r.Str("TemplateId"), Version = r.Int("Version"), Name = r.Str("Name"), DefinitionJson = r.Str("DefinitionJson"), IsPublished = r.Bool("IsPublished"), CreatedAtUtc = r.Dt("CreatedAtUtc"), CreatedBy = r.Str("CreatedBy") };
    private static AlertRecord MapAlert(DbDataReader r) => new() { Id = r.Str("Id"), AlertNo = r.Str("AlertNo"), TemplateId = r.Str("TemplateId"), TemplateVersion = r.Int("TemplateVersion"), AlertType = r.Str("AlertType"), BranchCode = r.Str("BranchCode"), CustomerIdEncrypted = r.Str("CustomerIdEncrypted"), AccountIdEncrypted = r.Str("AccountIdEncrypted"), DynamicDataJson = r.Str("DynamicDataJson"), Status = Enum.TryParse<AlertStatus>(r.Str("Status"), true, out var s) ? s : AlertStatus.New, CurrentStageId = r.Str("CurrentStageId"), CurrentStageName = r.Str("CurrentStageName"), CreatedAtUtc = r.Dt("CreatedAtUtc"), StageEnteredAtUtc = r.Dt("StageEnteredAtUtc"), CreatedBy = r.Str("CreatedBy"), Priority = r.Str("Priority") };
    private static WorkflowInstanceRecord MapInstance(DbDataReader r) => new() { Id = r.Str("Id"), AlertId = r.Str("AlertId"), WorkflowDefinitionId = r.Str("WorkflowDefinitionId"), WorkflowVersion = r.Int("WorkflowVersion"), Status = r.Str("Status"), CurrentStageId = r.Str("CurrentStageId"), StartedAtUtc = r.Dt("StartedAtUtc"), UpdatedAtUtc = r.Dt("UpdatedAtUtc") };
    private static WorkItemRecord MapWorkItem(DbDataReader r) => new() { Id = r.Str("Id"), AlertId = r.Str("AlertId"), WorkflowInstanceId = r.Str("WorkflowInstanceId"), StageId = r.Str("StageId"), StageName = r.Str("StageName"), AssignedRoleCode = r.Str("AssignedRoleCode"), AssignedBranchCode = r.Str("AssignedBranchCode"), AssignedUserId = r.NStr("AssignedUserId"), Status = Enum.TryParse<WorkItemStatus>(r.Str("Status"), true, out var s) ? s : WorkItemStatus.Pending, ParallelGroupId = r.NStr("ParallelGroupId"), CompletedAction = r.NStr("CompletedAction"), CompletedBy = r.NStr("CompletedBy"), CreatedAtUtc = r.Dt("CreatedAtUtc"), DueAtUtc = r.Dt("DueAtUtc"), CompletedAtUtc = r.NDt("CompletedAtUtc"), Remarks = r.NStr("Remarks") };
    private static QueryRecord MapQuery(DbDataReader r) => new() { Id = r.Str("Id"), AlertId = r.Str("AlertId"), RaisedBy = r.Str("RaisedBy"), RaisedToRole = r.Str("RaisedToRole"), QueryText = r.Str("QueryText"), ResponseText = r.NStr("ResponseText"), Status = r.Str("Status"), RaisedAtUtc = r.Dt("RaisedAtUtc"), RespondedAtUtc = r.NDt("RespondedAtUtc") };
    private static AttachmentRecord MapAttachment(DbDataReader r) => new() { Id = r.Str("Id"), AlertId = r.Str("AlertId"), StageId = r.Str("StageId"), FileName = r.Str("FileName"), StoredName = r.Str("StoredName"), ContentType = r.Str("ContentType"), FileSize = r.Lng("FileSize"), Sha256 = r.Str("Sha256"), Version = r.Int("Version"), UploadedBy = r.Str("UploadedBy"), UploadedAtUtc = r.Dt("UploadedAtUtc") };
    private static AuditRecord MapAudit(DbDataReader r) => new() { Id = r.Str("Id"), AlertId = r.NStr("AlertId"), UserId = r.Str("UserId"), UserName = r.Str("UserName"), RoleCode = r.Str("RoleCode"), Action = r.Str("Action"), EntityType = r.Str("EntityType"), EntityId = r.NStr("EntityId"), StageId = r.NStr("StageId"), PreviousValueJson = r.NStr("PreviousValueJson"), NewValueJson = r.NStr("NewValueJson"), Remarks = r.NStr("Remarks"), IpAddress = r.NStr("IpAddress"), CreatedAtUtc = r.Dt("CreatedAtUtc") };
    private static AgingBucket MapAgingBucket(DbDataReader r) => new() { Id = r.Str("Id"), Name = r.Str("Name"), FromDays = r.Int("FromDays"), ToDays = r.NStr("ToDays") is null ? null : r.Int("ToDays"), DisplayOrder = r.Int("DisplayOrder") };

    private sealed record DashboardAgingSource(string TemplateId, string TemplateName, string AlertType, DateTime EnteredAtUtc);
}

public static class JsonDefaults
{
    public static readonly JsonSerializerOptions Options = Create();
    private static JsonSerializerOptions Create()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true, WriteIndented = true };
        options.Converters.Add(new System.Text.Json.Serialization.JsonStringEnumConverter());
        return options;
    }
}
