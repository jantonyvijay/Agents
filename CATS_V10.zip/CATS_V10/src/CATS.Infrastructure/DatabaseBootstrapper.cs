using System.Text.Json;
using CATS.Core;
using Microsoft.Data.SqlClient;

namespace CATS.Infrastructure;

public sealed class DatabaseBootstrapper(DbConnectionFactory factory, AdoHelper db, Pbkdf2PasswordHasher hasher)
{
    public async Task InitializeAsync(string schemaRoot, CancellationToken ct = default)
    {
        if (factory.Dialect.Name == "SqlServer") await EnsureSqlServerDatabaseAsync(ct);
        var file = factory.Dialect.Name switch
        {
            "PostgreSql" => Path.Combine(schemaRoot,"postgresql","schema.sql"),
            "Oracle" => Path.Combine(schemaRoot,"oracle","schema.sql"),
            _ => Path.Combine(schemaRoot,"sqlserver","schema.sql")
        };
        if (!File.Exists(file)) throw new FileNotFoundException("CATS database schema not found.", file);
        var script = await File.ReadAllTextAsync(file, ct);
        foreach (var batch in SplitBatches(script, factory.Dialect.Name))
            if (!string.IsNullOrWhiteSpace(batch)) await db.ExecuteAsync(batch, null, ct);
        await SeedAsync(ct);
    }

    private async Task EnsureSqlServerDatabaseAsync(CancellationToken ct)
    {
        var b = new SqlConnectionStringBuilder(factory.Options.ConnectionString);
        var dbName = b.InitialCatalog;
        if (string.IsNullOrWhiteSpace(dbName)) return;
        b.InitialCatalog = "master";
        await using var cn = new SqlConnection(b.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd = cn.CreateCommand();
        cmd.CommandText = "IF DB_ID(@db) IS NULL BEGIN DECLARE @sql nvarchar(max)=N'CREATE DATABASE ['+REPLACE(@db,']',']]')+N']'; EXEC(@sql); END";
        cmd.Parameters.AddWithValue("@db",dbName);
        await cmd.ExecuteNonQueryAsync(ct);
    }

    private static IEnumerable<string> SplitBatches(string script,string provider)
    {
        if(provider=="SqlServer") return System.Text.RegularExpressions.Regex.Split(script,@"^\s*GO\s*$",System.Text.RegularExpressions.RegexOptions.Multiline|System.Text.RegularExpressions.RegexOptions.IgnoreCase).Where(x=>!string.IsNullOrWhiteSpace(x));
        if(provider=="Oracle") return System.Text.RegularExpressions.Regex.Split(script,@"^\s*/\s*$",System.Text.RegularExpressions.RegexOptions.Multiline).Where(x=>!string.IsNullOrWhiteSpace(x));
        return script.Split(';',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries);
    }

    private async Task SeedAsync(CancellationToken ct)
    {
        await SeedAgingBucketsAsync(ct);
        await SeedUsersAsync(ct);
        await EnsureGenericTemplateSeedAsync(ct);
        var desktopTemplateId = await EnsureDesktopDueDiligenceTemplateSeedAsync(ct);
        await EnsureDesktopDueDiligenceDashboardsAsync(desktopTemplateId, ct);
    }

    private async Task SeedAgingBucketsAsync(CancellationToken ct)
    {
        if ((await db.ScalarAsync<int>("SELECT COUNT(1) FROM AgingBuckets",null,ct)) != 0) return;
        var buckets = new (string,int,int?,int)[]{("0-1 Days",0,1,1),("2-3 Days",2,3,2),("4-7 Days",4,7,3),("8-15 Days",8,15,4),("16-30 Days",16,30,5),("31+ Days",31,null,6)};
        foreach(var x in buckets)
            await db.ExecuteAsync($"INSERT INTO AgingBuckets(Id,Name,FromDays,ToDays,DisplayOrder,IsActive) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Name")},{db.Dialect.P("From")},{db.Dialect.P("To")},{db.Dialect.P("Order")},1)",[new("Id",Guid.NewGuid().ToString("N")),new("Name",x.Item1),new("From",x.Item2),new("To",x.Item3),new("Order",x.Item4)],ct);
    }

    private async Task SeedUsersAsync(CancellationToken ct)
    {
        if ((await db.ScalarAsync<int>("SELECT COUNT(1) FROM CatsUsers",null,ct)) != 0) return;
        await AddUser("admin","CATS Administrator","ADMIN","HO","HO",new[]{"ADMIN","TEMPLATE.MANAGE","WORKFLOW.MANAGE","ALERT.UPLOAD","ALERT.VIEWALL","ALERT.REASSIGN","PII.UNMASK","AUDIT.VIEW"},ct);
        await AddUser("central","Central Team","CENTRAL","CENTRAL","HO",new[]{"TEMPLATE.MANAGE","WORKFLOW.MANAGE","ALERT.UPLOAD","ALERT.VIEWALL","ALERT.REASSIGN","AUDIT.VIEW"},ct);
        await AddUser("dtuser","DT User","DT_USER","DT","B001",Array.Empty<string>(),ct);
        await AddUser("checker","DT Checker","DT_CHECKER","DT","B001",new[]{"AUDIT.VIEW"},ct);
        await AddUser("verifier","DT Verifier","DT_VERIFIER","DT","B001",new[]{"AUDIT.VIEW"},ct);
        await AddUser("auditor","Auditor","AUDITOR","AUDIT","HO",new[]{"ALERT.VIEWALL","AUDIT.VIEW"},ct);
    }

    private async Task EnsureGenericTemplateSeedAsync(CancellationToken ct)
    {
        if ((await db.ScalarAsync<int>($"SELECT COUNT(1) FROM Templates WHERE Code={db.Dialect.P("Code")}",[new("Code","GENERIC_ALERT")],ct)) > 0) return;

        var templateId=Guid.NewGuid().ToString("N");
        var workflowId=Guid.NewGuid().ToString("N");
        var sections=JsonSerializer.Serialize(new[]{new { id="customer",name="Customer Information",order=1 },new { id="review",name="Review Questionnaire",order=2 }}, JsonDefaults.Options);
        var fields=JsonSerializer.Serialize(new object[]{
            new { id="risk",sectionId="customer",name="riskCategory",label="Risk Category",type="select",required=true,sensitive=false,order=1,optionsJson="[\"Low\",\"Medium\",\"High\"]" },
            new { id="amount",sectionId="customer",name="alertAmount",label="Alert Amount",type="number",required=true,sensitive=false,order=2,optionsJson="[]" },
            new { id="q1",sectionId="review",name="customerContacted",label="Customer contacted?",type="select",required=true,sensitive=false,order=1,optionsJson="[\"Yes\",\"No\"]" },
            new { id="q2",sectionId="review",name="remarks",label="Review Remarks",type="textarea",required=false,sensitive=false,order=2,optionsJson="[]" }}, JsonDefaults.Options);
        var viewConfiguration = JsonSerializer.Serialize(new TemplateViewConfiguration(), JsonDefaults.Options);
        var wf=new {
            startStageId="input",
            stages=new object[]{
                new { id="input",name="DT Input",type="Human",roleCode="DT_USER",allowedActions=new[]{"Submit"},editableFields=new[]{"*"},attachmentUploadRoles=new[]{"DT_USER"},attachmentViewRoles=Array.Empty<string>(),transitions=new[]{new { action="Submit",toStageId="parallelReview"}},approvalRule="Single",minimumApprovals=1,approvers=Array.Empty<object>(),slaHours=24,conditions=Array.Empty<object>(),defaultNextStageId=(string?)null,agentInstructions=(string?)null,agentPromptTemplate=(string?)null,agentFallbackAction=(string?)null,endStatus=(string?)null },
                new { id="parallelReview",name="Parallel Checker / Verifier",type="ParallelApproval",roleCode="",allowedActions=new[]{"Approve","Reject"},editableFields=Array.Empty<string>(),attachmentUploadRoles=Array.Empty<string>(),attachmentViewRoles=Array.Empty<string>(),transitions=new[]{new { action="Approve",toStageId="closed"},new { action="Reject",toStageId="rejected"}},approvalRule="All",minimumApprovals=2,approvers=new[]{new { roleCode="DT_CHECKER",label="DT Checker"},new { roleCode="DT_VERIFIER",label="DT Verifier"}},slaHours=48,conditions=Array.Empty<object>(),defaultNextStageId=(string?)null,agentInstructions=(string?)null,agentPromptTemplate=(string?)null,agentFallbackAction=(string?)null,endStatus=(string?)null },
                new { id="closed",name="Closed",type="End",roleCode="",allowedActions=Array.Empty<string>(),editableFields=Array.Empty<string>(),attachmentUploadRoles=Array.Empty<string>(),attachmentViewRoles=Array.Empty<string>(),transitions=Array.Empty<object>(),approvalRule="Single",minimumApprovals=1,approvers=Array.Empty<object>(),slaHours=1,conditions=Array.Empty<object>(),defaultNextStageId=(string?)null,agentInstructions=(string?)null,agentPromptTemplate=(string?)null,agentFallbackAction=(string?)null,endStatus="Closed" },
                new { id="rejected",name="Rejected",type="End",roleCode="",allowedActions=Array.Empty<string>(),editableFields=Array.Empty<string>(),attachmentUploadRoles=Array.Empty<string>(),attachmentViewRoles=Array.Empty<string>(),transitions=Array.Empty<object>(),approvalRule="Single",minimumApprovals=1,approvers=Array.Empty<object>(),slaHours=1,conditions=Array.Empty<object>(),defaultNextStageId=(string?)null,agentInstructions=(string?)null,agentPromptTemplate=(string?)null,agentFallbackAction=(string?)null,endStatus="Rejected" }
            }
        };
        var wfJson=JsonSerializer.Serialize(wf, JsonDefaults.Options);
        var now=DateTime.UtcNow;
        await db.ExecuteAsync($"INSERT INTO Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Code")},{db.Dialect.P("Name")},1,'Published','Hybrid',{db.Dialect.P("Sections")},{db.Dialect.P("Fields")},'[]',{db.Dialect.P("ViewConfig")},{db.Dialect.P("WorkflowId")},{db.Dialect.P("Now")},'SYSTEM')",
            [new("Id",templateId),new("Code","GENERIC_ALERT"),new("Name","Generic Alert Review"),new("Sections",sections),new("Fields",fields),new("ViewConfig",viewConfiguration),new("WorkflowId",workflowId),new("Now",now)],ct);
        await db.ExecuteAsync($"INSERT INTO WorkflowDefinitions(Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("TemplateId")},1,'Default Dynamic Approval',{db.Dialect.P("Json")},1,{db.Dialect.P("Now")},'SYSTEM')",
            [new("Id",workflowId),new("TemplateId",templateId),new("Json",wfJson),new("Now",now)],ct);
    }

    private async Task<string> EnsureDesktopDueDiligenceTemplateSeedAsync(CancellationToken ct)
    {
        const string templateCode = "DT_DD_MONEY_MULE";
        var existingTemplateId = await db.ScalarAsync<string?>($"SELECT Id FROM Templates WHERE Code={db.Dialect.P("Code")} ORDER BY Version DESC", [new("Code", templateCode)], ct);
        if (!string.IsNullOrWhiteSpace(existingTemplateId)) return existingTemplateId!;

        var templateId = Guid.NewGuid().ToString("N");
        var workflowId = Guid.NewGuid().ToString("N");
        var now = DateTime.UtcNow;
        var boolDefault = "false";

        var sections = new List<TemplateSection>
        {
            new() { Id="profile", Name="Customer Alert Profile", Order=1, ColumnSpan=3, PageNumber=1, DataViewMode="Grid" },
            new() { Id="questionnaire", Name="Questionary Response", Order=2, ColumnSpan=12, PageNumber=1, DataViewMode="List" },
            new() { Id="remarks", Name="Remarks & Recommendations", Order=3, ColumnSpan=12, PageNumber=1, DataViewMode="List" }
        };

        string JsonOptions(params string[] values) => JsonSerializer.Serialize(values, JsonDefaults.Options);

        var fields = new List<TemplateField>
        {
            new() { Id="fld_branch", SectionId="profile", Name="BranchCode", Label="Location", Type="text", Required=true, Order=1, ReadOnly=true },
            new() { Id="fld_analyst", SectionId="profile", Name="AnalystName", Label="Analyst Name", Type="text", Required=true, Order=2, ReadOnly=true },
            new() { Id="fld_account", SectionId="profile", Name="AccountId", Label="Account No", Type="text", Required=true, Order=3, ReadOnly=true },
            new() { Id="fld_customer", SectionId="profile", Name="CustomerId", Label="Customer Id", Type="text", Required=true, Order=4, ReadOnly=true },
            new() { Id="fld_cust_name", SectionId="profile", Name="CustomerName", Label="Customer Name", Type="text", Required=false, Order=5, ReadOnly=true },
            new() { Id="fld_rule", SectionId="profile", Name="RuleId", Label="Rule Id", Type="text", Required=false, Order=6, ReadOnly=true },
            new() { Id="fld_product", SectionId="profile", Name="ProductName", Label="Product name", Type="text", Required=false, Order=7, ReadOnly=true },
            new() { Id="fld_unit", SectionId="profile", Name="Unit", Label="Unit", Type="text", Required=false, Order=8, ReadOnly=true, DefaultValue="Money Mule" },
            new() { Id="fld_loan", SectionId="profile", Name="TotalLiveLoanAmount", Label="total_live_loan_amount", Type="number", Required=false, Order=9, ReadOnly=true },
            new() { Id="fld_state", SectionId="profile", Name="CustomerPermanentState", Label="customer_permanent_state", Type="text", Required=false, Order=10, ReadOnly=true },
            new() { Id="fld_dob", SectionId="profile", Name="CustomerDateOfBirth", Label="Customer_date_of_birth", Type="date", Required=false, Order=11, ReadOnly=true },
            new() { Id="fld_country", SectionId="profile", Name="CustomerCountry", Label="Customer_country", Type="text", Required=false, Order=12, ReadOnly=true },
            new() { Id="fld_reason", SectionId="profile", Name="ReasonDescription", Label="Reason Description", Type="textarea", Required=false, Order=13, ReadOnly=true },
            new() { Id="fld_class", SectionId="questionnaire", Name="MOClassification", Label="MO Classification", Type="select", Required=true, Order=1, OptionsJson=JsonOptions("Regular/Usual Transaction Pattern","Business Profile Aligned","Same Party/Repeated Transactions","Self Transfer/Internal Movement","Loan/OD Related Transactions","Business Receipts & Vendor Payments","Family/Related Party Transactions") },
            new() { Id="fld_q1", SectionId="questionnaire", Name="RegularUsualTransactionPattern", Label="Regular / Usual Transaction Pattern", Type="checkbox", Required=false, Order=2, DefaultValue=boolDefault },
            new() { Id="fld_q2", SectionId="questionnaire", Name="BusinessProfileAligned", Label="Business Profile Aligned", Type="checkbox", Required=false, Order=3, DefaultValue=boolDefault },
            new() { Id="fld_q3", SectionId="questionnaire", Name="SamePartyRepeatedTransactions", Label="Same Party / Repeated Transactions", Type="checkbox", Required=false, Order=4, DefaultValue=boolDefault },
            new() { Id="fld_q4", SectionId="questionnaire", Name="SelfTransferInternalMovement", Label="Self Transfer / Internal Movement", Type="checkbox", Required=false, Order=5, DefaultValue=boolDefault },
            new() { Id="fld_q5", SectionId="questionnaire", Name="LoanOdRelatedTransactions", Label="Loan / OD Related Transactions", Type="checkbox", Required=false, Order=6, DefaultValue=boolDefault },
            new() { Id="fld_q6", SectionId="questionnaire", Name="BusinessReceiptsVendorPayments", Label="Business Receipts & Vendor Payments", Type="checkbox", Required=false, Order=7, DefaultValue=boolDefault },
            new() { Id="fld_q7", SectionId="questionnaire", Name="FamilyRelatedPartyTransactions", Label="Family / Related Party Transactions", Type="checkbox", Required=false, Order=8, DefaultValue=boolDefault },
            new() { Id="fld_recommend", SectionId="remarks", Name="CDFinalRecommendation", Label="CD Final recommendations", Type="select", Required=true, Order=1, OptionsJson=JsonOptions("Continue Txn Restriction","Remove Txn Restriction","Central Due Diligence Review Positive","Central Due Diligence Review Negative") },
            new() { Id="fld_maker_remark", SectionId="remarks", Name="DTUserRemarks", Label="CD Team Maker Remark", Type="textarea", Required=false, Order=2, MaxLength=1000, Placeholder="Enter maker remarks" },
            new() { Id="fld_verifier_comment", SectionId="remarks", Name="DTVerifierComment", Label="CD Team Checker Comment", Type="textarea", Required=false, Order=3, MaxLength=1000, Placeholder="Enter verifier comment" }
        };

        var editableForDtUser = new[]
        {
            "MOClassification","RegularUsualTransactionPattern","BusinessProfileAligned","SamePartyRepeatedTransactions","SelfTransferInternalMovement",
            "LoanOdRelatedTransactions","BusinessReceiptsVendorPayments","FamilyRelatedPartyTransactions","CDFinalRecommendation","DTUserRemarks"
        };

        var workflowDefinition = new
        {
            startStageId = "dtUserReview",
            stages = new object[]
            {
                new {
                    id="dtUserReview", name="DT User Review", type="Human", roleCode="DT_USER",
                    allowedActions=new[]{"Submit"}, editableFields=editableForDtUser,
                    attachmentUploadRoles=new[]{"DT_USER"}, attachmentViewRoles=Array.Empty<string>(),
                    transitions=new[]{ new { action="Submit", toStageId="dtVerifierReview" } },
                    approvalRule="Single", minimumApprovals=1, approvers=Array.Empty<object>(), slaHours=24,
                    conditions=Array.Empty<object>(), defaultNextStageId=(string?)null,
                    agentInstructions=(string?)null, agentPromptTemplate=(string?)null, agentFallbackAction=(string?)null, endStatus=(string?)null
                },
                new {
                    id="dtVerifierReview", name="DT Verifier Review", type="Human", roleCode="DT_VERIFIER",
                    allowedActions=new[]{"Send Back","Verified"}, editableFields=new[]{"DTVerifierComment"},
                    attachmentUploadRoles=new[]{"DT_VERIFIER"}, attachmentViewRoles=Array.Empty<string>(),
                    transitions=new object[]{ new { action="Send Back", toStageId="dtUserReview" }, new { action="Verified", toStageId="closed" } },
                    approvalRule="Single", minimumApprovals=1, approvers=Array.Empty<object>(), slaHours=24,
                    conditions=Array.Empty<object>(), defaultNextStageId=(string?)null,
                    agentInstructions=(string?)null, agentPromptTemplate=(string?)null, agentFallbackAction=(string?)null, endStatus=(string?)null
                },
                new {
                    id="closed", name="Closed", type="End", roleCode="", allowedActions=Array.Empty<string>(), editableFields=Array.Empty<string>(),
                    attachmentUploadRoles=Array.Empty<string>(), attachmentViewRoles=Array.Empty<string>(), transitions=Array.Empty<object>(),
                    approvalRule="Single", minimumApprovals=1, approvers=Array.Empty<object>(), slaHours=1,
                    conditions=Array.Empty<object>(), defaultNextStageId=(string?)null,
                    agentInstructions=(string?)null, agentPromptTemplate=(string?)null, agentFallbackAction=(string?)null, endStatus="Closed"
                }
            }
        };

        var viewConfiguration = new TemplateViewConfiguration
        {
            LayoutMode = "Single",
            RememberLastSection = true,
            ShowSectionNumbers = false,
            AllowWizardStepClick = false,
            PopupSize = "xl"
        };

        var assignmentRules = new object[]
        {
            new { field="BranchCode", @operator="notempty", value="", stageId="dtUserReview", targetRoleCode="DT_USER", targetBranchCode="{BranchCode}", stop=true }
        };

        await db.ExecuteAsync($"INSERT INTO Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Code")},{db.Dialect.P("Name")},1,'Published','Deterministic',{db.Dialect.P("Sections")},{db.Dialect.P("Fields")},{db.Dialect.P("Rules")},{db.Dialect.P("ViewConfig")},{db.Dialect.P("WorkflowId")},{db.Dialect.P("Now")},'SYSTEM')",
            [
                new("Id", templateId),
                new("Code", templateCode),
                new("Name", "Desktop Due Diligence Money Mule"),
                new("Sections", JsonSerializer.Serialize(sections, JsonDefaults.Options)),
                new("Fields", JsonSerializer.Serialize(fields, JsonDefaults.Options)),
                new("Rules", JsonSerializer.Serialize(assignmentRules, JsonDefaults.Options)),
                new("ViewConfig", JsonSerializer.Serialize(viewConfiguration, JsonDefaults.Options)),
                new("WorkflowId", workflowId),
                new("Now", now)
            ], ct);

        await db.ExecuteAsync($"INSERT INTO WorkflowDefinitions(Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy) VALUES({db.Dialect.P("Id")},{db.Dialect.P("TemplateId")},1,{db.Dialect.P("Name")},{db.Dialect.P("Json")},1,{db.Dialect.P("Now")},'SYSTEM')",
            [
                new("Id", workflowId),
                new("TemplateId", templateId),
                new("Name", "Desktop Due Diligence Money Mule Flow"),
                new("Json", JsonSerializer.Serialize(workflowDefinition, JsonDefaults.Options)),
                new("Now", now)
            ], ct);

        return templateId;
    }

    private async Task EnsureDesktopDueDiligenceDashboardsAsync(string templateId, CancellationToken ct)
    {
        await EnsureTemplateDashboardAsync(
            code: "DT_DD_MONEY_MULE_DT_USER",
            name: "Desktop Due Diligence - DT User",
            title: "Desktop Due Diligence Money Mule",
            description: "DT User dashboard for Desktop Due Diligence Money Mule alerts.",
            templateId: templateId,
            groupByFields: new[] { "BranchCode", "AnalystName" },
            metrics: new object[]
            {
                new { code="TOTAL", title="Total Record", type="Count", field="", value="" },
                new { code="CONTINUE", title="Continue Txn Restriction", type="FieldEquals", field="CDFinalRecommendation", value="Continue Txn Restriction" },
                new { code="REMOVE", title="Remove Txn Restriction", type="FieldEquals", field="CDFinalRecommendation", value="Remove Txn Restriction" },
                new { code="PENDING", title="Pending", type="StatusCount", field="", value="Pending" }
            },
            gridColumns: new[] { "AlertNo", "AccountId", "CustomerId", "RuleId", "ProductName", "Unit", "TotalLiveLoanAmount", "CustomerPermanentState", "CustomerDateOfBirth", "CustomerCountry", "Status" },
            searchFields: new[] { "AlertNo", "AccountId", "CustomerId" },
            pageSize: 20,
            displayOrder: 10,
            roleCodes: new[] { "DT_USER" },
            ct: ct);

        await EnsureTemplateDashboardAsync(
            code: "DT_DD_MONEY_MULE_DT_VERIFIER",
            name: "Desktop Due Diligence - DT Verifier",
            title: "Desktop Due Diligence Money Mule",
            description: "DT Verifier dashboard for Desktop Due Diligence Money Mule alerts.",
            templateId: templateId,
            groupByFields: new[] { "BranchCode", "AnalystName" },
            metrics: new object[]
            {
                new { code="TOTAL", title="Total", type="Count", field="", value="" },
                new { code="CONTINUE", title="Continue Txn Restriction", type="FieldEquals", field="CDFinalRecommendation", value="Continue Txn Restriction" },
                new { code="REMOVE", title="Remove Txn Restriction", type="FieldEquals", field="CDFinalRecommendation", value="Remove Txn Restriction" },
                new { code="CLOSED", title="Closed", type="StatusCount", field="", value="Closed" },
                new { code="PENDING", title="Pending", type="StatusCount", field="", value="Pending" }
            },
            gridColumns: new[] { "AlertNo", "AccountId", "CustomerId", "RuleId", "ProductName", "Unit", "TotalLiveLoanAmount", "CustomerPermanentState", "CustomerDateOfBirth", "CustomerCountry", "Status", "CurrentStageName" },
            searchFields: new[] { "AlertNo", "AccountId", "CustomerId" },
            pageSize: 20,
            displayOrder: 11,
            roleCodes: new[] { "DT_VERIFIER" },
            ct: ct);
    }

    private async Task EnsureTemplateDashboardAsync(string code,string name,string title,string description,string templateId,IReadOnlyList<string> groupByFields,object[] metrics,IReadOnlyList<string> gridColumns,IReadOnlyList<string> searchFields,int pageSize,int displayOrder,IReadOnlyList<string> roleCodes,CancellationToken ct)
    {
        var id = await db.ScalarAsync<string?>($"SELECT Id FROM TemplateDashboardMaster WHERE Code={db.Dialect.P("Code")}",[new("Code",code)],ct);
        id=string.IsNullOrWhiteSpace(id)?Guid.NewGuid().ToString("N"):id;
        var now = DateTime.UtcNow;
        var args = new DbArg[]
        {
            new("Id", id), new("Code", code), new("Name", name), new("Title", title), new("Description", description),
            new("TemplateId", templateId), new("AlertType", ""), new("GroupBy", JsonSerializer.Serialize(groupByFields, JsonDefaults.Options)),
            new("Metrics", JsonSerializer.Serialize(metrics, JsonDefaults.Options)), new("Columns", JsonSerializer.Serialize(gridColumns, JsonDefaults.Options)),
            new("Search", JsonSerializer.Serialize(searchFields, JsonDefaults.Options)), new("PageSize", pageSize), new("DisplayOrder", displayOrder), new("Now", now)
        };
        if ((await db.ScalarAsync<int>($"SELECT COUNT(1) FROM TemplateDashboardMaster WHERE Id={db.Dialect.P("Id")}",[new("Id",id)],ct)) == 0)
            await db.ExecuteAsync(
                $"INSERT INTO TemplateDashboardMaster(Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive,CreatedAtUtc,UpdatedAtUtc) VALUES({db.Dialect.P("Id")},{db.Dialect.P("Code")},{db.Dialect.P("Name")},{db.Dialect.P("Title")},{db.Dialect.P("Description")},{db.Dialect.P("TemplateId")},{db.Dialect.P("AlertType")},{db.Dialect.P("GroupBy")},{db.Dialect.P("Metrics")},{db.Dialect.P("Columns")},{db.Dialect.P("Search")},{db.Dialect.P("PageSize")},{db.Dialect.P("DisplayOrder")},1,1,{db.Dialect.P("Now")},{db.Dialect.P("Now")})",
                args,ct);
        else
            await db.ExecuteAsync(
                $"UPDATE TemplateDashboardMaster SET Name={db.Dialect.P("Name")},Title={db.Dialect.P("Title")},Description={db.Dialect.P("Description")},TemplateId={db.Dialect.P("TemplateId")},AlertType={db.Dialect.P("AlertType")},GroupByFieldsJson={db.Dialect.P("GroupBy")},MetricsJson={db.Dialect.P("Metrics")},GridColumnsJson={db.Dialect.P("Columns")},SearchFieldsJson={db.Dialect.P("Search")},PageSize={db.Dialect.P("PageSize")},DisplayOrder={db.Dialect.P("DisplayOrder")},IsDefault=1,IsActive=1,UpdatedAtUtc={db.Dialect.P("Now")} WHERE Id={db.Dialect.P("Id")}",
                args,ct);
        await db.ExecuteAsync($"DELETE FROM TemplateDashboardRoleMapping WHERE DashboardId={db.Dialect.P("DashboardId")}",[new("DashboardId",id)],ct);
        foreach (var roleCode in roleCodes.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            await db.ExecuteAsync(
                $"INSERT INTO TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) VALUES({db.Dialect.P("DashboardId")},{db.Dialect.P("RoleCode")},1)",
                [new("DashboardId", id), new("RoleCode", roleCode)], ct);
        }
    }

    private async Task AddUser(string userName,string display,string role,string dept,string branch,string[] permissions,CancellationToken ct)
    {
        await db.ExecuteAsync($"INSERT INTO CatsUsers(Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive) VALUES({db.Dialect.P("Id")},{db.Dialect.P("User")},{db.Dialect.P("Display")},{db.Dialect.P("Hash")},{db.Dialect.P("Role")},{db.Dialect.P("Dept")},{db.Dialect.P("Branch")},{db.Dialect.P("Perms")},1)",
            [new("Id",Guid.NewGuid().ToString("N")),new("User",userName),new("Display",display),new("Hash",hasher.Hash("Cats@1234")),new("Role",role),new("Dept",dept),new("Branch",branch),new("Perms",JsonSerializer.Serialize(permissions, JsonDefaults.Options))],ct);
    }
}
