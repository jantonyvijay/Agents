(() => {
    'use strict';
    const apiBaseUrl = (document.querySelector('meta[name="cats-api-base-url"]')?.content || '').replace(/\/$/, '');
    const apiUrl = path => `${apiBaseUrl}/${path.replace(/^\//, '')}`;
    const state = {
        token: sessionStorage.getItem('cats_token') || '',
        user: JSON.parse(sessionStorage.getItem('cats_user') || 'null'),
        templates: [],
        roles: [],
        alertFilter: { page: 1, pageSize: 20 },
        templateDraft: { id: null, code: '', name: '', executionMode: 'Deterministic', viewConfiguration: { layoutMode: 'Single', rememberLastSection: true, showSectionNumbers: true, allowWizardStepClick: false, popupSize: 'xl' }, sections: [], fields: [], assignmentRules: [] },
        workflowDraft: { templateId: '', name: 'Dynamic Workflow', startStageId: '', stages: [] },
        pendingAction: null
    };

    const themeMedia = window.matchMedia('(prefers-color-scheme: dark)');
    const themeLabels = { light: 'Light', dark: 'Dark', system: 'Match browser' };

    function getThemePreference() {
        try {
            const value = localStorage.getItem('cats_theme');
            return Object.hasOwn(themeLabels, value) ? value : 'system';
        } catch {
            return 'system';
        }
    }

    function updateThemeControls(preference) {
        const selected = Object.hasOwn(themeLabels, preference) ? preference : 'system';
        $('#themeCurrentLabel').text(themeLabels[selected]);
        $('.theme-option').each(function () {
            const active = $(this).data('theme') === selected;
            $(this).toggleClass('is-active', active).attr('aria-checked', String(active));
            $(this).find('.theme-option-check').toggleClass('is-visible', active);
        });
    }

    function applyTheme(preference, persist = true) {
        const selected = Object.hasOwn(themeLabels, preference) ? preference : 'system';
        const resolved = selected === 'system' ? (themeMedia.matches ? 'dark' : 'light') : selected;
        document.documentElement.setAttribute('data-bs-theme', resolved);
        document.documentElement.setAttribute('data-cats-theme', selected);
        document.documentElement.style.colorScheme = resolved;
        if (persist) {
            try { localStorage.setItem('cats_theme', selected); } catch { }
        }
        updateThemeControls(selected);
    }

    function userInitials(user) {
        const source = (user?.displayName || user?.userName || '').trim();
        if (!source) return 'U';
        const words = source.split(/\s+/).filter(Boolean);
        return (words.length > 1 ? words[0][0] + words[words.length - 1][0] : words[0].slice(0, 2)).toUpperCase();
    }

    function renderAccountDetails() {
        const user = state.user || {};
        const displayName = (user.displayName || user.userName || 'User').trim();
        const userName = (user.userName || '').trim();
        const role = (user.roleCode || 'USER').trim();
        const context = [];
        if (user.departmentCode) context.push(`Department: ${user.departmentCode}`);
        if (user.branchCode) context.push(`Branch: ${user.branchCode}`);
        $('#headerAvatar, #accountAvatar').text(userInitials(user));
        $('#headerUserName, #accountDisplayName').text(displayName);
        $('#headerRole, #accountRole').text(role);
        $('#accountUserName').text(userName || 'Signed-in user');
        $('#accountContext').text(context.join(' · ') || 'Authenticated session');
        $('#accountMenuButton').attr('aria-label', `Open account menu for ${displayName}`);
    }

    function setPasswordVisibility(visible) {
        $('#loginPassword').attr('type', visible ? 'text' : 'password');
        $('#toggleLoginPassword')
            .toggleClass('is-visible', visible)
            .attr({ 'aria-pressed': String(visible), 'aria-label': visible ? 'Hide password' : 'Show password' });
        $('#passwordToggleText').text(visible ? 'Hide password' : 'Show password');
    }

    function setLoginBusy(busy) {
        $('#loginForm').attr('aria-busy', String(busy));
        $('#loginSubmitBtn').prop('disabled', busy);
        $('.login-submit-spinner').toggleClass('d-none', !busy);
        $('.login-submit-arrow').toggleClass('d-none', busy);
        $('.login-submit-label').text(busy ? 'Signing in…' : 'Sign in securely');
    }

    function setLoginStatus(message = '') {
        $('#loginStatus').text(message).toggleClass('d-none', !message);
    }

    const esc = v => $('<div>').text(v ?? '').html();
    const uid = () => 'x' + Math.random().toString(36).slice(2, 10);
    const json = (s, fallback) => { try { return JSON.parse(s || ''); } catch { return fallback; } };
    const has = p => (state.user?.permissions || []).some(x => x.toLowerCase() === p.toLowerCase());
    const statusBadge = s => `<span class="badge rounded-pill text-bg-${/closed|approved/i.test(s) ? 'success' : /reject|cancel/i.test(s) ? 'danger' : /query/i.test(s) ? 'warning' : 'primary'}">${esc(s)}</span>`;

    function enableMovableModals() {
        let drag = null;
        $(document).on('pointerdown', '.modal.show .modal-header', function (event) {
            const pointer = event.originalEvent;
            if (pointer.button !== 0 || $(event.target).closest('button,a,input,select,textarea,label').length) return;
            const dialog = $(this).closest('.modal-dialog')[0];
            if (!dialog) return;
            const rect = dialog.getBoundingClientRect();
            drag = {
                dialog,
                pointerId: pointer.pointerId,
                startX: pointer.clientX,
                startY: pointer.clientY,
                originX: Number(dialog.dataset.dragX || 0),
                originY: Number(dialog.dataset.dragY || 0),
                rect
            };
            dialog.classList.add('is-dragging');
            this.setPointerCapture?.(pointer.pointerId);
            event.preventDefault();
        });
        $(document).on('pointermove', function (event) {
            const pointer = event.originalEvent;
            if (!drag || pointer.pointerId !== drag.pointerId) return;
            const rawX = pointer.clientX - drag.startX;
            const rawY = pointer.clientY - drag.startY;
            const deltaX = Math.max(-drag.rect.left, Math.min(window.innerWidth - drag.rect.right, rawX));
            const deltaY = Math.max(-drag.rect.top, Math.min(window.innerHeight - drag.rect.bottom, rawY));
            const x = drag.originX + deltaX;
            const y = drag.originY + deltaY;
            drag.dialog.dataset.dragX = String(x);
            drag.dialog.dataset.dragY = String(y);
            drag.dialog.style.transform = `translate(${x}px, ${y}px)`;
        });
        $(document).on('pointerup pointercancel', function (event) {
            if (!drag || event.originalEvent.pointerId !== drag.pointerId) return;
            drag.dialog.classList.remove('is-dragging');
            drag = null;
        });
        $(document).on('hidden.bs.modal', '.modal', function () {
            const dialog = this.querySelector('.modal-dialog');
            if (!dialog) return;
            dialog.classList.remove('is-dragging');
            dialog.style.removeProperty('transform');
            delete dialog.dataset.dragX;
            delete dialog.dataset.dragY;
            if (drag?.dialog === dialog) drag = null;
        });
    }

    enableMovableModals();
    const piiEye = (alertId, field) => has('PII.UNMASK') ? `<button type="button" class="btn btn-sm btn-link pii-reveal p-0 ms-1" data-alert-id="${esc(alertId)}" data-field="${field}" aria-label="Reveal ${field === 'customerId' ? 'Customer ID' : 'Account ID'}" title="Reveal after password verification"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg></button>` : '';
    const piiMaskEye = (alertId, field) => `<button type="button" class="btn btn-sm btn-link pii-mask p-0 ms-1" data-alert-id="${esc(alertId)}" data-field="${field}" aria-label="Mask ${field === 'customerId' ? 'Customer ID' : 'Account ID'}" title="Mask this value"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m3 3 18 18"/><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 4.2A10.8 10.8 0 0 1 12 4c6.5 0 10 8 10 8a18.5 18.5 0 0 1-2.1 3.2M6.6 6.6C3.5 8.5 2 12 2 12s3.5 8 10 8a10.5 10.5 0 0 0 4.1-.8"/></svg></button>`;
    const makePiiCell = (cell, alertId, field) => { if (!has('PII.UNMASK') || !cell.length || cell.find('.pii-reveal,.pii-mask').length) return; const masked=cell.text(); cell.attr('data-pii-value', field).attr('data-alert-id', alertId).attr('data-masked-value',masked).addClass('text-nowrap').append(piiEye(alertId, field)); };
    function enhancePiiGrids(root = document) {
        if (!has('PII.UNMASK')) return;
        $(root).find('table').addBack('table').each(function () {
            const table = $(this), fields = [];
            table.find('thead th').each(function (index) {
                const heading = $(this).text().replace(/\s/g, '').toLowerCase();
                if (heading === 'customer' || heading === 'customerid') fields.push([index, 'customerId']);
                if (heading === 'account' || heading === 'accountid') fields.push([index, 'accountId']);
            });
            if (!fields.length) return;
            table.find('tbody tr[data-id]').each(function () {
                const row = $(this), alertId = row.data('id');
                fields.forEach(([index, field]) => makePiiCell(row.children('td').eq(index), alertId, field));
            });
        });
    }
    function removeWorkflowDefinitionJson(root = document) {
        $(root).find('details').addBack('details').filter(function () {
            return $(this).children('summary').first().text().trim() === 'Definition JSON';
        }).remove();
    }
    function hideAssignmentRulesJson(root = document) {
        $(root).find('label').addBack('label').filter(function () {
            return $(this).text().trim() === 'Assignment Rules JSON';
        }).closest('.mt-4').addClass('d-none').attr('aria-hidden','true');
    }

    async function api(url, options = {}) {
        const opt = { method: 'GET', ...options, headers: { ...(options.headers || {}) } };
        if (state.token) opt.headers.Authorization = `Bearer ${state.token}`;
        if (opt.body && !(opt.body instanceof FormData) && typeof opt.body !== 'string') {
            opt.headers['Content-Type'] = 'application/json';
            opt.body = JSON.stringify(opt.body);
        }
        const r = await fetch(apiUrl(url), opt);
        const text = await r.text();
        let data = null; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
        if (r.status === 401) { logout(false); throw new Error('Your session has expired. Please sign in again.'); }
        if (!r.ok) throw new Error(data?.detail || data?.message || data?.title || `Request failed (${r.status})`);
        return data;
    }

    function toast(message, type = 'success') {
        const id = uid();
        $('#toastHost').append(`<div id="${id}" class="toast align-items-center text-bg-${type} border-0" role="alert"><div class="d-flex"><div class="toast-body">${esc(message)}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div>`);
        const el = document.getElementById(id); const t = new bootstrap.Toast(el, { delay: 3500 }); el.addEventListener('hidden.bs.toast', () => el.remove()); t.show();
    }
    function loading() { $('#viewHost').html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>'); }
    function header(title, sub = '', actions = '') { $('#pageHeader').html(`<div><h1 class="h4 mb-0">${esc(title)}</h1><div class="small text-secondary">${esc(sub)}</div></div><div>${actions}</div>`); }

    function enhanceGrid(table) {
        const $table = $(table); if ($table.data('catsGrid') || !$table.find('thead th').length) return;
        $table.data('catsGrid', true).addClass('cats-grid');
        const headings = $table.find('thead th').map((i, th) => $(th).text().trim() || `Column ${i + 1}`).get();
        const key = 'cats_grid_' + headings.join('|').toLowerCase().replace(/[^a-z0-9|]+/g, '_');
        let prefs = json(localStorage.getItem(key), { hidden: [], compact: false, wrap: false });
        const $wrap = $table.closest('.table-responsive').addClass('cats-grid-scroll');
        const $toolbar = $(`<div class="cats-grid-toolbar"><span class="small text-secondary">Grid options</span><div class="dropdown"><button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown" data-bs-auto-close="outside">Columns</button><div class="dropdown-menu dropdown-menu-end p-2 cats-column-menu"></div></div><button class="btn btn-sm btn-outline-secondary cats-density">${prefs.compact ? 'Comfortable' : 'Compact'}</button><button class="btn btn-sm btn-outline-secondary cats-wrap">${prefs.wrap ? 'No wrap' : 'Wrap text'}</button><button class="btn btn-sm btn-link cats-reset">Reset</button></div>`);
        $wrap.before($toolbar);
        const save = () => { try { localStorage.setItem(key, JSON.stringify(prefs)); } catch { } };
        const setColumn = (index, visible) => $table.find('tr').each((_, row) => $(row).children().eq(index).toggle(visible));
        headings.forEach((name, index) => { const checked = !prefs.hidden.includes(index); $('.cats-column-menu', $toolbar).append(`<label class="dropdown-item form-check mb-0"><input class="form-check-input me-2 cats-column" type="checkbox" data-index="${index}" ${checked ? 'checked' : ''}>${esc(name)}</label>`); setColumn(index, checked); });
        $table.toggleClass('table-sm', !!prefs.compact).toggleClass('cats-grid-wrap', !!prefs.wrap);
        $table.find('thead th').each(function (index) { if (!$(this).text().trim()) return; const sort = () => { const ascending = $(this).attr('aria-sort') !== 'ascending'; $table.find('thead th').attr('aria-sort', 'none'); $(this).attr('aria-sort', ascending ? 'ascending' : 'descending'); const rows = $table.find('tbody tr').get().filter(row => $(row).children().length > 1); rows.sort((a, b) => { const av = $(a).children().eq(index).text().trim(), bv = $(b).children().eq(index).text().trim(); const an = Number(av.replace(/[^0-9.-]/g, '')), bn = Number(bv.replace(/[^0-9.-]/g, '')); const result = av && bv && !Number.isNaN(an) && !Number.isNaN(bn) ? an - bn : av.localeCompare(bv, undefined, { numeric: true, sensitivity: 'base' }); return ascending ? result : -result; }); $table.children('tbody').append(rows); }; $(this).addClass('cats-sortable').attr({ tabindex: 0, role: 'button', 'aria-sort': 'none', title: 'Sort column' }).on('click', sort).on('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); sort(); } }); });
        $('.cats-column', $toolbar).on('change', function () { const index = +$(this).data('index'); setColumn(index, this.checked); prefs.hidden = $('.cats-column:not(:checked)', $toolbar).map((_, x) => +x.dataset.index).get(); save(); });
        $('.cats-density', $toolbar).on('click', function () { prefs.compact = !prefs.compact; $table.toggleClass('table-sm', prefs.compact); $(this).text(prefs.compact ? 'Comfortable' : 'Compact'); save(); });
        $('.cats-wrap', $toolbar).on('click', function () { prefs.wrap = !prefs.wrap; $table.toggleClass('cats-grid-wrap', prefs.wrap); $(this).text(prefs.wrap ? 'No wrap' : 'Wrap text'); save(); });
        $('.cats-reset', $toolbar).on('click', () => { localStorage.removeItem(key); prefs = { hidden: [], compact: false, wrap: false }; $('.cats-column', $toolbar).prop('checked', true); headings.forEach((_, i) => setColumn(i, true)); $table.removeClass('table-sm cats-grid-wrap'); $('.cats-density', $toolbar).text('Compact'); $('.cats-wrap', $toolbar).text('Wrap text'); });
    }
    new MutationObserver(() => $('#viewHost table').each((_, table) => enhanceGrid(table))).observe(document.getElementById('viewHost'), { childList: true, subtree: true });

    async function loadTemplates(force = false) {
        if (state.templates.length && !force) return state.templates;
        state.templates = await api('/api/templates'); return state.templates;
    }
    async function loadRoles(force = false) {
        if (state.roles.length && !force) return state.roles;
        state.roles = await api('/api/meta/roles');
        $('#roleOptions').html(state.roles.map(r => `<option value="${esc(r)}"></option>`).join(''));
        return state.roles;
    }
    const templateOptions = (selected = '') => `<option value="">All / Select template</option>` + state.templates.map(t => `<option value="${esc(t.id)}" ${t.id === selected ? 'selected' : ''}>${esc(t.name)} v${t.version} (${esc(t.status)})</option>`).join('');
    const alertTypeOptions = (selected = '', requireSelection = false) => `${requireSelection ? '<option value="">Select alert type</option>' : '<option value="">All alert types</option>'}` + state.templates.filter(t => t.status === 'Published').map(t => `<option value="${esc(t.id)}" ${t.id === selected ? 'selected' : ''}>${esc(t.code)}</option>`).join('');

    function applyPermissions() {
        $('.permission-template').toggle(has('TEMPLATE.MANAGE'));
        $('.permission-workflow').toggle(has('WORKFLOW.MANAGE'));
        $('.permission-upload').toggle(has('ALERT.UPLOAD'));
        $('.permission-admin').toggle(has('SECURITY.MANAGE'));
        $('.permission-mcp').toggle(has('MCP.MANAGE'));
    }

    function showApp() {
        $('body').addClass('app-authenticated');
        $('#loginPage').addClass('d-none'); $('#appShell').removeClass('d-none');
        renderAccountDetails(); applyPermissions();
        refreshAssistantStatus().catch(() => { $('#catsAssistantLauncher,#catsAssistantPanel').addClass('d-none'); });
    }
    function showLogin() { setLoginBusy(false); $('body').removeClass('app-authenticated'); $('#appShell').addClass('d-none'); $('#loginPage').removeClass('d-none'); setTimeout(() => $('#loginUser').trigger('focus'), 100); }
    function logout(show = true) { $('#catsAssistantLauncher,#catsAssistantPanel').addClass('d-none'); const menuButton = document.getElementById('accountMenuButton'); if (menuButton) bootstrap.Dropdown.getInstance(menuButton)?.hide(); state.token = ''; state.user = null; state.templates = []; state.roles = []; sessionStorage.removeItem('cats_token'); sessionStorage.removeItem('cats_user'); $('#loginPassword').val(''); setPasswordVisibility(false); setLoginStatus(); if (show) toast('Signed out', 'secondary'); showLogin(); }
    async function signOut() { try { if (state.token) await api('/api/auth/logout', { method: 'POST' }); } catch { } finally { logout(true); } }

    async function navigate(view, arg) {
        $('.sidebar .nav-link').removeClass('active'); $(`.sidebar .nav-link[data-view="${view}"]`).addClass('active');
        if (window.innerWidth < 768) $('#sidebar').removeClass('mobile-open');
        try {
            if (view === 'dashboard') await renderDashboard();
            if (view === 'alerts') await renderAlerts(arg || state.alertFilter);
            if (view === 'newAlert') await renderNewAlert();
            if (view === 'templates') await renderTemplateDesigner();
            if (view === 'workflow') await renderWorkflowDesigner();
            if (view === 'mcp') await renderMcpDiscovery();
            if (view === 'admin') await renderAdmin();
            if (view === 'ingestion') await renderPlatformIngestion();
            if (view === 'reports') await renderPlatformReports();
            if (view === 'mail') await renderPlatformMail();
            if (view === 'detail') await renderDetail(arg);
        } catch (e) { header('Error'); $('#viewHost').html(`<div class="alert alert-danger">${esc(e.message)}</div>`); }
    }

    async function renderDashboard() {
        header('Dashboard', 'Alert-type aging and operational dashboards'); loading(); await loadTemplates();
        let templateDashboards=[];
        try { templateDashboards=has('DASHBOARD.VIEW') ? await api('/api/platform/dashboard/templates') : []; } catch { templateDashboards=[]; }
        const role=String(state.user?.roleCode||'').toUpperCase();
        const dedicatedCode=role==='DT_USER'?'DT_DD_MONEY_MULE_DT_USER':role==='DT_VERIFIER'?'DT_DD_MONEY_MULE_DT_VERIFIER':'';
        const dedicatedDashboard=dedicatedCode?templateDashboards.find(x=>String(x.code).toUpperCase()===dedicatedCode):null;
        if(dedicatedCode){if(!dedicatedDashboard){$('#viewHost').html('<div class="alert alert-warning">The role-specific Desktop Due Diligence Money Mule dashboard is not configured.</div>');return;}$('#viewHost').html('<div id="dashboardContent"></div>');await renderConfiguredTemplateDashboard(dedicatedDashboard.id,'#dashboardContent');return;}
        const selector=templateDashboards.map(x=>`<option value="${esc(x.id)}">${esc(x.title || x.name)}</option>`).join('');
        $('#viewHost').html(`<div class="card mb-3"><div class="card-body"><div class="row g-2 align-items-end">
          <div class="col-lg-5"><label class="form-label">Dashboard</label><select id="dashboardMode" class="form-select"><option value="overview">Overview / Aging Matrix</option>${selector}</select></div>
          <div class="col-lg-7 d-flex justify-content-lg-end gap-2"><button id="manageTemplateDashboards" class="btn btn-outline-primary ${has('DASHBOARD.CONFIGURE')?'':'d-none'}">⚙ Manage Alert Type Dashboards</button></div>
        </div></div></div><div id="dashboardContent"></div>`);
        $('#dashboardMode').on('change',async function(){const id=$(this).val();if(id==='overview')await renderOverviewDashboard('#dashboardContent');else await renderConfiguredTemplateDashboard(id,'#dashboardContent');});
        $('#manageTemplateDashboards').on('click',()=>renderTemplateDashboardManager());
        await renderOverviewDashboard('#dashboardContent');
    }

    async function renderOverviewDashboard(host) {
        $(host).html(`<div class="card mb-3"><div class="card-body"><form id="dashFilter" class="row g-2 align-items-end">
          <div class="col-lg-4"><label class="form-label">Alert Type <span class="text-danger">*</span></label><select id="dashAlertType" class="form-select" required>${alertTypeOptions('', true)}</select></div>
          <div class="col-lg-2"><label class="form-label">Branch</label><input id="dashBranch" class="form-control" /></div>
          <div class="col-lg-2"><label class="form-label">Status</label><select id="dashStatus" class="form-select"><option value="">Active statuses</option><option>Pending</option><option>InProgress</option><option>Query</option></select></div>
          <div class="col-lg-2"><label class="form-label">View</label><select id="dashView" class="form-select"><option value="aging">Aging Matrix</option><option value="type">Alert Type Summary</option></select></div>
          <div class="col-12 d-grid d-lg-flex justify-content-lg-end"><button class="btn btn-primary px-4">Apply Filters</button></div>
        </form></div></div><div id="dashBody"></div>`);
        async function load(){
            $('#dashBody').html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>');
            const q=new URLSearchParams({templateId:$('#dashAlertType').val()||'',branchCode:$('#dashBranch').val()||'',status:$('#dashStatus').val()||''});
            const d=await api('/api/dashboard/aging?'+q.toString());
            let html='';
            if($('#dashView').val()==='type'){
                const types=Object.values(d.rows.reduce((all,row)=>{const name=row.alertType||'Unspecified';all[name]||={name,total:0,breached:0,rows:[]};all[name].total+=row.total;all[name].breached+=row.counts['31+ Days']||0;all[name].rows.push(row);return all;},{})).sort((a,b)=>b.total-a.total);
                html+=`<div class="row g-3 mb-3">${types.map(x=>`<div class="col-md-6 col-xl-4"><button class="card alert-type-card w-100 text-start" data-type="${esc(x.name)}"><div class="card-body"><div class="d-flex justify-content-between"><span class="fw-semibold">${esc(x.name)}</span><span class="badge text-bg-primary">${x.total}</span></div><div class="small text-secondary mt-2">${x.rows.length} template(s) · ${x.breached} aged 31+ days</div></div></button></div>`).join('')}</div>`;
                $('#dashBody').html(html);$('.alert-type-card').on('click',function(){navigate('alerts',{page:1,pageSize:20,alertType:$(this).data('type')});});return;
            }
            html+=`<div class="card"><div class="card-header bg-white fw-semibold">Alert Aging</div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Alert Type</th>${d.buckets.map(b=>`<th class="text-center">${esc(b.name)}</th>`).join('')}<th class="text-center">Total</th></tr></thead><tbody>`;
            for(const r of d.rows){html+=`<tr><td>${esc(r.alertType)}</td>`;for(const b of d.buckets){const c=r.counts[b.name]||0;html+=`<td class="text-center"><button class="btn btn-sm ${c?'btn-outline-primary':'btn-light'} click-count" data-template="${r.templateId}" data-type="${esc(r.alertType)}" data-from="${b.fromDays}" data-to="${b.toDays??''}" ${c?'':'disabled'}>${c}</button></td>`;}html+=`<td class="text-center"><button class="btn btn-sm btn-primary click-total" data-template="${r.templateId}" data-type="${esc(r.alertType)}">${r.total}</button></td></tr>`;}
            html+='</tbody></table></div></div>';$('#dashBody').html(html);
            $('.click-count').on('click',function(){navigate('alerts',{page:1,pageSize:20,templateId:$(this).data('template'),alertType:$(this).data('type'),agingFrom:$(this).data('from'),agingTo:$(this).data('to')||null});});
            $('.click-total').on('click',function(){navigate('alerts',{page:1,pageSize:20,templateId:$(this).data('template'),alertType:$(this).data('type')});});
        }
        $('#dashFilter').on('submit',e=>{e.preventDefault();load().catch(x=>toast(x.message,'danger'));});$('#dashBody').html('<div class="alert alert-light border text-secondary">Select an alert type and apply filters to load the dashboard.</div>');
    }

    function parseJsonArray(value,fallback=[]){try{const x=JSON.parse(value||'[]');return Array.isArray(x)?x:fallback;}catch{return fallback;}}
    function dictionaryValue(row,key){if(!row)return'';const actual=Object.keys(row).find(x=>x.toLowerCase()===String(key).toLowerCase());return actual?row[actual]:'';}
    function dashboardFieldLabel(field){const labels={AlertNo:'Alert ID',AccountId:'Account No',CustomerId:'Customer ID',BranchCode:'Location',AnalystName:'Analyst Name',RuleId:'Rule Id',ProductName:'Product Name',TotalLiveLoanAmount:'Total Live Loan Amount',CustomerPermanentState:'Customer Permanent State',CustomerDateOfBirth:'Customer Date of Birth',CustomerCountry:'Customer Country',CurrentStageName:'Current Stage'};return labels[field]||String(field).replace(/([A-Z])/g,' $1').trim();}
    async function renderConfiguredTemplateDashboard(id,host){
        $(host).html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>');
        const config=await api(`/api/platform/dashboard/templates/${encodeURIComponent(id)}`); const searchFields=parseJsonArray(config.searchFieldsJson,['AlertNo','AccountId','CustomerId']);
        $(host).html(`<div class="card mb-3 border-0 shadow-sm"><div class="card-header text-white template-dashboard-title"><div class="fw-semibold fs-5">${esc(config.title)}</div><div class="small opacity-75">${esc(config.description||'')}</div></div><div class="card-body"><form id="tdSearch" class="row g-2 align-items-end">${searchFields.map(f=>`<div class="col-md-3"><label class="form-label">${esc(dashboardFieldLabel(f))}</label><input class="form-control td-search" data-field="${esc(f)}"></div>`).join('')}<div class="col-md-3 d-flex gap-2"><button class="btn btn-primary flex-fill">Search</button><button type="button" id="tdClear" class="btn btn-outline-secondary">Clear</button></div></form></div></div><div id="tdResults"></div>`);
        async function load(page=1){
            $('#tdResults').html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>'); const q=new URLSearchParams({page,pageSize:config.pageSize||20});
            $('.td-search').each(function(){const field=$(this).data('field'),value=$(this).val();if(value){if(String(field).toLowerCase()==='alertno')q.set('alertNo',value);else if(String(field).toLowerCase()==='accountid')q.set('accountId',value);else if(String(field).toLowerCase()==='customerid')q.set('customerId',value);else q.set('search',value);}});
            const d=await api(`/api/platform/dashboard/templates/${encodeURIComponent(id)}/data?${q}`), groups=parseJsonArray(d.dashboard.groupByFieldsJson,['BranchCode']), metrics=parseJsonArray(d.dashboard.metricsJson,[]), columns=parseJsonArray(d.dashboard.gridColumnsJson,['AlertNo','AlertType','BranchCode','Status','CurrentStageName']);
            const metricTitles=metrics.length?metrics.map(x=>x.title):['Total Record','Pending'];
            const showSerial=String(d.dashboard.code||'').toUpperCase()==='DT_DD_MONEY_MULE_DT_VERIFIER';
            const summaryOnly=['DT_DD_MONEY_MULE_DT_USER','DT_DD_MONEY_MULE_DT_VERIFIER'].includes(String(d.dashboard.code||'').toUpperCase());
            const summaryRows=d.summaryRows.map((r,ri)=>`<tr>${showSerial?`<td>${ri+1}</td>`:''}${groups.map(x=>`<td>${esc(dictionaryValue(r,x))}</td>`).join('')}${metricTitles.map((x,mi)=>`<td class="text-center"><button class="btn btn-link p-0 fw-semibold td-summary-count" data-index="${ri}" data-metric-index="${mi}">${Number(dictionaryValue(r,x)||0).toLocaleString()}</button></td>`).join('')}</tr>`).join('');
            const totalRow=showSerial&&d.summaryRows.length?`<tr class="fw-semibold table-light"><td colspan="${groups.length+1}" class="text-end">Total</td>${metricTitles.map((x,mi)=>`<td class="text-center"><button class="btn btn-link p-0 fw-semibold td-total-count" data-metric-index="${mi}">${d.summaryRows.reduce((sum,row)=>sum+Number(dictionaryValue(row,x)||0),0).toLocaleString()}</button></td>`).join('')}</tr>`:'';
            let h=`<div class="card mb-3"><div class="table-responsive"><table class="table table-sm table-bordered align-middle mb-0 template-summary-table"><thead><tr>${showSerial?'<th>Sr No.</th>':''}${groups.map(x=>`<th>${esc(dashboardFieldLabel(x))}</th>`).join('')}${metricTitles.map(x=>`<th class="text-center">${esc(x)}</th>`).join('')}</tr></thead><tbody>${summaryRows||`<tr><td colspan="${groups.length+metricTitles.length+(showSerial?1:0)}" class="text-center text-secondary py-4">No records</td></tr>`}${totalRow}</tbody></table></div></div>`;
            if(!summaryOnly)h+=`<div class="card"><div class="card-header bg-white d-flex justify-content-between"><span class="fw-semibold">Alert Records</span><span class="text-secondary small">${d.totalRecords.toLocaleString()} records</span></div><div class="table-responsive"><table class="table table-sm table-hover table-bordered align-middle mb-0 template-detail-grid"><thead><tr>${columns.map(x=>`<th>${esc(dashboardFieldLabel(x))}</th>`).join('')}</tr></thead><tbody>${d.rows.map(r=>`<tr class="td-alert-row" data-id="${esc(dictionaryValue(r,'Id'))}">${columns.map(x=>`<td>${esc(dictionaryValue(r,x)??'')}</td>`).join('')}</tr>`).join('')||`<tr><td colspan="${columns.length}" class="text-center text-secondary py-4">No matching alerts</td></tr>`}</tbody></table></div><div class="card-footer bg-white d-flex justify-content-between"><span>Page ${d.page}</span><div><button class="btn btn-sm btn-outline-primary td-prev" ${d.page<=1?'disabled':''}>Previous</button> <button class="btn btn-sm btn-outline-primary td-next" ${(d.page*d.pageSize)>=d.totalRecords?'disabled':''}>Next</button></div></div></div>`;
            else if(!d.totalRecords)h+='<div class="alert alert-info">No Desktop Due Diligence Money Mule alerts are currently available for this role. Create or upload alerts using the DT_DD_MONEY_MULE alert type.</div>';
            $('#tdResults').html(h);$('.td-alert-row').on('click',function(){navigate('detail',$(this).data('id'));});$('.td-prev').on('click',()=>load(d.page-1));$('.td-next').on('click',()=>load(d.page+1));
            function drillDown(row,metricIndex){
                const groupFilters={};if(row)groups.forEach(group=>groupFilters[group]=String(dictionaryValue(row,group)??''));
                const metric=metrics[metricIndex];const filters={page:1,pageSize:config.pageSize||20,templateId:d.dashboard.templateId,alertType:d.dashboard.alertType||'',dashboardId:id,dashboardGroupFiltersJson:JSON.stringify(groupFilters),dashboardMetricCode:metric?.code||'',dashboardMetricTitle:metric?.title||'Total'};
                if(groupFilters.BranchCode)filters.branchCode=groupFilters.BranchCode;
                if(String(metric?.type||'').toUpperCase()==='STATUSCOUNT')filters.status=metric.value||'';
                $('.td-search').each(function(){const field=String($(this).data('field')||''),value=$(this).val();if(value){if(field.toLowerCase()==='alertno')filters.alertNo=value;else if(field.toLowerCase()==='accountid')filters.accountId=value;else if(field.toLowerCase()==='customerid')filters.customerId=value;else filters.search=value;}});
                navigate('alerts',filters);
            }
            $('.td-summary-count').on('click',function(){drillDown(d.summaryRows[Number($(this).data('index'))],Number($(this).data('metric-index')));});
            $('.td-total-count').on('click',function(){drillDown(null,Number($(this).data('metric-index')));});
        }
        $('#tdSearch').on('submit',e=>{e.preventDefault();load(1).catch(x=>toast(x.message,'danger'));});$('#tdClear').on('click',()=>{$('.td-search').val('');load(1);});await load(1);
    }

    async function renderTemplateDashboardManager(){
        header('Alert Type Dashboard Configuration','Central Team / Admin permission controlled configuration');await loadTemplates();const dashboards=await api('/api/platform/dashboard/templates?includeInactive=true');
        $('#viewHost').html(`<div class="d-flex justify-content-end mb-3"><button id="addTemplateDashboard" class="btn btn-primary">+ New Dashboard</button></div><div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Name</th><th>Alert Type</th><th>Filter</th><th>Roles</th><th>Status</th><th></th></tr></thead><tbody>${dashboards.map(x=>`<tr><td><b>${esc(x.title)}</b><div class="small text-secondary">${esc(x.name)}</div></td><td>${esc(state.templates.find(t=>t.id===x.templateId)?.code||'')}</td><td>${esc(x.alertType||'All')}</td><td>${esc((x.roleCodes||[]).join(', '))}</td><td>${x.isActive?'Active':'Inactive'}</td><td><button class="btn btn-sm btn-outline-primary edit-td" data-id="${x.id}">Edit</button></td></tr>`).join('')}</tbody></table></div></div>`);
        async function open(item={}){await loadRoles();const metrics=parseJsonArray(item.metricsJson,[{code:'TOTAL',title:'Total Record',type:'Count'},{code:'PENDING',title:'Pending',type:'StatusCount',value:'Pending'}]);const modal=$(`<div class="modal fade" id="templateDashboardModal"><div class="modal-dialog modal-xl"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Template Dashboard</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="templateDashboardForm"><div class="modal-body"><div class="row g-3"><div class="col-md-4"><label class="form-label">Name</label><input id="tdmName" class="form-control" value="${esc(item.name||'')}" required></div><div class="col-md-4"><label class="form-label">Dashboard Title</label><input id="tdmTitle" class="form-control" value="${esc(item.title||'')}" required></div><div class="col-md-4"><label class="form-label">Template</label><select id="tdmTemplate" class="form-select" required>${templateOptions(item.templateId||'')}</select></div><div class="col-md-4"><label class="form-label">Alert Type (blank = all)</label><input id="tdmAlertType" class="form-control" value="${esc(item.alertType||'')}"></div><div class="col-md-8"><label class="form-label">Description</label><input id="tdmDescription" class="form-control" value="${esc(item.description||'')}"></div><div class="col-md-6"><label class="form-label">Group By fields (comma)</label><input id="tdmGroups" class="form-control" value="${esc(parseJsonArray(item.groupByFieldsJson,['BranchCode']).join(','))}"><div class="form-text">Example: BranchCode, AnalystName</div></div><div class="col-md-6"><label class="form-label">Search fields (comma)</label><input id="tdmSearch" class="form-control" value="${esc(parseJsonArray(item.searchFieldsJson,['AlertNo','AccountId','CustomerId']).join(','))}"></div><div class="col-12"><label class="form-label">Grid columns (comma)</label><input id="tdmColumns" class="form-control" value="${esc(parseJsonArray(item.gridColumnsJson,['AlertNo','AccountId','CustomerId','AlertType','BranchCode','Status']).join(','))}"></div><div class="col-12"><label class="form-label">Metrics JSON</label><textarea id="tdmMetrics" class="form-control font-monospace" rows="6">${esc(JSON.stringify(metrics,null,2))}</textarea><div class="form-text">Types: Count, StatusCount, FieldEquals, FieldNotEmpty.</div></div><div class="col-md-8"><label class="form-label">Visible Roles</label><div class="border rounded p-2" style="max-height:150px;overflow:auto">${state.roles.map(r=>`<label class="form-check"><input class="form-check-input tdm-role" type="checkbox" value="${esc(r)}" ${(item.roleCodes||[]).includes(r)?'checked':''}><span class="form-check-label">${esc(r)}</span></label>`).join('')}</div></div><div class="col-md-2"><label class="form-label">Page Size</label><input id="tdmPageSize" type="number" class="form-control" value="${item.pageSize||20}"></div><div class="col-md-2"><label class="form-label">Order</label><input id="tdmOrder" type="number" class="form-control" value="${item.displayOrder||1}"></div><div class="col-6 form-check ms-2"><input id="tdmDefault" class="form-check-input" type="checkbox" ${item.isDefault?'checked':''}><label class="form-check-label">Default for role</label></div><div class="col-5 form-check"><input id="tdmActive" class="form-check-input" type="checkbox" ${item.isActive===false?'':'checked'}><label class="form-check-label">Active</label></div></div></div><div class="modal-footer"><button class="btn btn-light" type="button" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Dashboard</button></div></form></div></div></div>`).appendTo(document.body);new bootstrap.Modal(modal[0]).show();modal.on('hidden.bs.modal',()=>modal.remove());$('#templateDashboardForm').on('submit',async e=>{e.preventDefault();let metricsJson;try{metricsJson=JSON.stringify(JSON.parse($('#tdmMetrics').val()));}catch{return toast('Metrics JSON is invalid.','danger');}const split=id=>$(id).val().split(',').map(x=>x.trim()).filter(Boolean);await api('/api/platform/dashboard/templates',{method:'POST',body:{id:item.id||'',code:item.code||'',name:$('#tdmName').val(),title:$('#tdmTitle').val(),description:$('#tdmDescription').val(),templateId:$('#tdmTemplate').val(),alertType:$('#tdmAlertType').val(),groupByFieldsJson:JSON.stringify(split('#tdmGroups')),searchFieldsJson:JSON.stringify(split('#tdmSearch')),gridColumnsJson:JSON.stringify(split('#tdmColumns')),metricsJson,pageSize:Number($('#tdmPageSize').val()),displayOrder:Number($('#tdmOrder').val()),isDefault:$('#tdmDefault').is(':checked'),isActive:$('#tdmActive').is(':checked'),roleCodes:$('.tdm-role:checked').map((_,x)=>x.value).get()}});bootstrap.Modal.getInstance(modal[0]).hide();toast('Template dashboard saved.','success');renderTemplateDashboardManager();});}
        const normalizeAlertTypeDashboardModal=(selected='')=>setTimeout(()=>{const modal=$('#templateDashboardModal');modal.find('.modal-title').text('Alert Type Dashboard');modal.find('label').filter(function(){return $(this).text().trim()==='Template';}).text('Alert Type');$('#tdmTemplate').html(alertTypeOptions(selected,true));},0);
        $('#addTemplateDashboard').on('click',()=>{open();normalizeAlertTypeDashboardModal();});$('.edit-td').on('click',function(){const item=dashboards.find(x=>x.id===$(this).data('id'))||{};open(item);normalizeAlertTypeDashboardModal(item.templateId||'');});
    }

    async function renderAlerts(filter = {}) {
        await loadTemplates(); state.alertFilter = { page: 1, pageSize: 20, ...filter }; header('Alerts', 'Role-filtered work queue and alert records');
        const dashboardGroups=state.alertFilter.dashboardId?json(state.alertFilter.dashboardGroupFiltersJson||'{}',{}):{};
        const dashboardCriteria=Object.entries(dashboardGroups).map(([key,value])=>`${dashboardFieldLabel(key)}: ${value}`).concat(state.alertFilter.dashboardMetricTitle?[`Metric: ${state.alertFilter.dashboardMetricTitle}`]:[]);
        const drillDownBanner=state.alertFilter.dashboardId?`<div class="alert alert-info d-flex flex-wrap justify-content-between align-items-center gap-2"><span><strong>Dashboard drill-down</strong>${dashboardCriteria.length?' · '+esc(dashboardCriteria.join(' · ')):''}</span><button id="backToDashboard" type="button" class="btn btn-sm btn-outline-primary">Back to Dashboard</button></div>`:'';
        $('#viewHost').html(`${drillDownBanner}<div class="card mb-3"><div class="card-body"><form id="alertFilterForm" class="row g-2 align-items-end">
      <div class="col-lg-3"><label class="form-label">Alert Type</label><select id="afAlertType" class="form-select">${alertTypeOptions(state.alertFilter.templateId || '')}</select></div>
      <div class="col-lg-2"><label class="form-label">Branch</label><input id="afBranch" value="${esc(state.alertFilter.branchCode || '')}" class="form-control" /></div>
      <div class="col-lg-2"><label class="form-label">Status</label><select id="afStatus" class="form-select"><option value="">All</option>${['New', 'Pending', 'InProgress', 'Query', 'Approved', 'Rejected', 'Closed'].map(x => `<option ${state.alertFilter.status === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
      <div class="col-lg-3"><label class="form-label">Search</label><div class="input-group"><input id="afSearch" value="${esc(state.alertFilter.search || '')}" class="form-control" placeholder="Alert no / type / branch" /><button class="btn btn-primary">Search</button></div></div>
      <div class="col-12 small text-secondary">Aging filter: ${state.alertFilter.agingFrom ?? 'Any'} to ${state.alertFilter.agingTo ?? 'Any'} days <button id="clearAging" type="button" class="btn btn-link btn-sm">clear</button></div>
    </form></div></div><div id="alertGrid"></div>`);
        async function load(page = state.alertFilter.page || 1) { state.alertFilter.page = page; const q = new URLSearchParams(); Object.entries(state.alertFilter).forEach(([k, v]) => { if (v !== null && v !== undefined && v !== '') q.set(k, v) }); $('#alertGrid').html('<div class="spinner-overlay"><div class="spinner-border text-primary"></div></div>'); const d = await api('/api/alerts?' + q.toString()); let h = `<div class="card"><div class="card-header bg-white d-flex justify-content-between"><span class="fw-semibold">Records</span><span class="text-secondary small">${d.totalRecords.toLocaleString()} record(s)</span></div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Alert</th><th>Alert Type</th><th>Branch</th><th>Customer</th><th>Stage</th><th>Stage Age</th><th>Status</th><th></th></tr></thead><tbody>`; for (const r of d.data) h += `<tr class="pointer alert-row" data-id="${r.id}"><td class="fw-semibold text-primary">${esc(r.alertNo)}</td><td>${esc(r.alertType)}</td><td>${esc(r.branchCode)}</td><td>${esc(r.customerId)}</td><td>${esc(r.currentStageName)}</td><td>${r.stageAgingDays} day(s)</td><td>${statusBadge(r.status)}</td><td><button class="btn btn-sm btn-outline-primary">Open</button></td></tr>`; if (!d.data.length) h += '<tr><td colspan="8" class="text-center text-secondary py-5">No records found.</td></tr>'; h += '</tbody></table></div><div class="card-footer bg-white d-flex justify-content-between align-items-center"><span class="small text-secondary">Page ' + d.page + ' of ' + Math.max(1, d.totalPages) + '</span><div><button id="prevPage" class="btn btn-sm btn-outline-secondary me-1" ' + (d.page <= 1 ? 'disabled' : '') + '>Previous</button><button id="nextPage" class="btn btn-sm btn-outline-secondary" ' + (d.page >= d.totalPages ? 'disabled' : '') + '>Next</button></div></div></div>'; $('#alertGrid').html(h); $('.alert-row').on('click', function () { navigate('detail', $(this).data('id')); }); $('#prevPage').on('click', () => load(d.page - 1)); $('#nextPage').on('click', () => load(d.page + 1)); }
        $('#alertFilterForm').on('submit', e => { e.preventDefault(); state.alertFilter = { ...state.alertFilter, page: 1, templateId: $('#afAlertType').val(), alertType: '', branchCode: $('#afBranch').val(), status: $('#afStatus').val(), search: $('#afSearch').val() }; load(1).catch(x => toast(x.message, 'danger')); });
        $('#backToDashboard').on('click',()=>navigate('dashboard'));
        $('#clearAging').on('click', () => { delete state.alertFilter.agingFrom; delete state.alertFilter.agingTo; renderAlerts(state.alertFilter); }); await load();
    }

    function templateViewConfig(source) {
        const cfg = source?.viewConfiguration || json(source?.viewConfigurationJson || '{}', {});
        return Object.assign({ layoutMode:'Single', baseDataModes:['ManualSingle','BulkFileUpload','Sftp','FcQuery'], rememberLastSection:true, showSectionNumbers:true, allowWizardStepClick:false, popupSize:'xl' }, cfg || {});
    }

    function templateAllowsBaseDataMode(template, mode) {
        const modes=templateViewConfig(template).baseDataModes;
        return Array.isArray(modes) && modes.some(value=>String(value).toLowerCase()===String(mode).toLowerCase());
    }

    function templateFieldControlHtml(f, val, cssClass, editable = true) {
        const value = val ?? f.defaultValue ?? '';
        const disabled = !editable || f.readOnly;
        if (disabled) return `<div class="fw-medium cats-field-readonly">${esc(fieldValue(value)) || '<span class="text-secondary">—</span>'}</div>`;
        const req=f.required?'required':'';
        const placeholder=f.placeholder?` placeholder="${esc(f.placeholder)}"`:'';
        const minLen=f.minLength!=null?` minlength="${Number(f.minLength)}"`:'';
        const maxLen=f.maxLength!=null?` maxlength="${Number(f.maxLength)}"`:'';
        const min=f.minValue!=null?` min="${Number(f.minValue)}"`:'';
        const max=f.maxValue!=null?` max="${Number(f.maxValue)}"`:'';
        const pattern=f.validationPattern?` pattern="${esc(f.validationPattern)}"`:'';
        const meta=`data-field-config="${encodeURIComponent(JSON.stringify(f))}" data-name="${esc(f.name)}"`;
        let html='';
        if(f.type==='select') {
            if(String(f.dataSourceMode||'Static').toLowerCase()==='api') html=`<select class="form-select ${cssClass} cats-api-select" ${meta} data-current-value="${esc(value)}" ${req}><option value="">Loading…</option></select>`;
            else { const opts=json(f.optionsJson,[]); html=`<select class="form-select ${cssClass}" ${meta} ${req}><option value="">Select</option>${opts.map(o=>`<option value="${esc(o)}" ${String(value)===String(o)?'selected':''}>${esc(o)}</option>`).join('')}</select>`; }
        } else if(f.type==='textarea') html=`<textarea class="form-control ${cssClass}" ${meta} rows="3" ${req}${placeholder}${minLen}${maxLen}${pattern}>${esc(value)}</textarea>`;
        else if(f.type==='checkbox') html=`<div class="form-check"><input class="form-check-input ${cssClass}" ${meta} type="checkbox" ${value===true||value==='true'?'checked':''}></div>`;
        else html=`<input class="form-control ${cssClass}" ${meta} type="${f.type==='number'?'number':f.type==='date'?'date':'text'}" value="${esc(value)}" ${req}${placeholder}${minLen}${maxLen}${min}${max}${pattern}/>`;
        const counter=(f.type==='text'||f.type==='textarea') && f.maxLength!=null ? `<div class="form-text text-end cats-field-counter" data-counter-for="${esc(f.name)}">0/${Number(f.maxLength)}</div>` : '';
        const help=f.helpText?`<div class="form-text">${esc(f.helpText)}</div>`:'';
        return html+counter+help+`<div class="invalid-feedback cats-field-error">${esc(f.customErrorMessage||'Please enter a valid value.')}</div>`;
    }

    function sectionContentHtml(section, fields, data, editableSet, cssClass) {
        const listMode=String(section.dataViewMode||'Grid').toLowerCase()==='list';
        const span=listMode?12:Math.min(12,Math.max(2,Number(section.columnSpan??6)||6));
        return `<div class="row g-3 ${listMode?'cats-section-list':''}">${fields.filter(x=>x.sectionId===section.id).sort((a,b)=>a.order-b.order).map(f=>{
            const editable=editableSet===null ? !f.readOnly : editableSet.has(String(f.name).toLowerCase());
            const label=`${esc(f.label)}${f.required?' <span class="text-danger">*</span>':''}`;
            const control=templateFieldControlHtml(f,data[f.name],cssClass,editable);
            return listMode
                ? `<div class="col-12"><div class="row align-items-start"><div class="col-md-4"><label class="small text-secondary mb-1">${label}</label></div><div class="col-md-8">${control}</div></div></div>`
                : `<div class="col-12 col-md-${span}"><label class="small text-secondary mb-1">${label}</label>${control}</div>`;
        }).join('')}</div>`;
    }

    function configuredSectionsHtml(sections, fields, data, editableSet, cssClass, cfg, prefix='cats-layout') {
        const ordered=[...(sections||[])].sort((a,b)=>(Number(a.pageNumber||1)-Number(b.pageNumber||1))||(Number(a.order||0)-Number(b.order||0)));
        if(!ordered.length) return '<div class="text-secondary">This template has no dynamic sections.</div>';
        const title=(s,i)=>`${cfg.showSectionNumbers?`${i+1}. `:''}${esc(s.name)}`;
        const body=(s)=>sectionContentHtml(s,fields,data,editableSet,cssClass);
        const configuredMode=String(cfg.layoutMode||'Single').toLowerCase();
        const mode=configuredMode==='auto'?(ordered.length>1?'tab':'single'):configuredMode;
        if(mode==='tab') return `<ul class="nav nav-tabs mb-3" role="tablist">${ordered.map((x,i)=>`<li class="nav-item"><button class="nav-link ${i===0?'active':''}" data-bs-toggle="tab" data-bs-target="#${prefix}-tab-${i}" type="button">${title(x,i)}</button></li>`).join('')}</ul><div class="tab-content">${ordered.map((x,i)=>`<div class="tab-pane fade ${i===0?'show active':''}" id="${prefix}-tab-${i}"><div class="section-box">${body(x)}</div></div>`).join('')}</div>`;
        if(mode==='accordion') return `<div class="accordion mb-3" id="${prefix}-accordion">${ordered.map((x,i)=>`<div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button ${i?'collapsed':''}" type="button" data-bs-toggle="collapse" data-bs-target="#${prefix}-acc-${i}">${title(x,i)}</button></h2><div id="${prefix}-acc-${i}" class="accordion-collapse collapse ${i===0?'show':''}" data-bs-parent="#${prefix}-accordion"><div class="accordion-body">${body(x)}</div></div></div>`).join('')}</div>`;
        if(mode==='popup') return `<div class="row g-3 mb-3">${ordered.map((x,i)=>`<div class="col-md-6 col-xl-4"><button type="button" class="btn btn-outline-primary w-100 text-start p-3" data-bs-toggle="modal" data-bs-target="#${prefix}-popup-${i}"><span class="fw-semibold">${title(x,i)}</span><span class="d-block small text-secondary">Open section</span></button></div>`).join('')}</div>${ordered.map((x,i)=>`<div class="modal fade cats-template-popup" id="${prefix}-popup-${i}" tabindex="-1"><div class="modal-dialog modal-${esc(cfg.popupSize||'xl')} modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${title(x,i)}</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">${body(x)}</div><div class="modal-footer"><button class="btn btn-primary" data-bs-dismiss="modal">Done</button></div></div></div></div>`).join('')}`;
        if(mode==='wizard') return `<div class="cats-wizard" data-wizard-prefix="${prefix}"><div class="d-flex flex-wrap gap-2 mb-3">${ordered.map((x,i)=>`<button type="button" class="btn btn-sm ${i===0?'btn-primary':'btn-outline-secondary'} cats-wizard-step" data-step="${i}" ${cfg.allowWizardStepClick?'':'disabled'}>${title(x,i)}</button>`).join('')}</div>${ordered.map((x,i)=>`<div class="section-box cats-wizard-pane ${i===0?'':'d-none'}" data-step="${i}">${body(x)}<div class="d-flex justify-content-between mt-4"><button type="button" class="btn btn-outline-secondary cats-wizard-prev" ${i===0?'disabled':''}>Previous</button><button type="button" class="btn btn-primary cats-wizard-next" ${i===ordered.length-1?'disabled':''}>Next</button></div></div>`).join('')}</div>`;
        return ordered.map((x,i)=>`<div class="section-box" data-section-page="${x.pageNumber||1}"><h6>${title(x,i)}</h6>${body(x)}</div>`).join('');
    }

    function getConfiguredFieldValue(root,name,cssClass) {
        const el=$(root).find(`.${cssClass}`).filter(function(){return String($(this).data('name')).toLowerCase()===String(name).toLowerCase();}).first();
        if(!el.length) return '';
        return el.attr('type')==='checkbox' ? String(el.prop('checked')) : String(el.val()??'');
    }

    async function loadApiSelect(select, root, cssClass) {
        const f=JSON.parse(decodeURIComponent(select.attr('data-field-config')||'%7B%7D'));
        let url=String(f.apiUrl||'');
        (String(f.dependsOnFields||'').split(',').map(x=>x.trim()).filter(Boolean)).forEach(name=>{ url=url.replaceAll(`{${name}}`,encodeURIComponent(getConfiguredFieldValue(root,name,cssClass))); });
        if(!url.toLowerCase().startsWith('/api/')) { select.html('<option value="">Invalid API configuration</option>'); return; }
        const current=String(select.attr('data-current-value')??select.data('initial-value')??select.val()??'');
        try {
            const result=await api(url), rows=Array.isArray(result)?result:(Array.isArray(result?.data)?result.data:Array.isArray(result?.items)?result.items:Array.isArray(result?.results)?result.results:[]);
            const valueField=f.apiValueField||'value', textField=f.apiTextField||'text';
            select.html('<option value="">Select</option>'+rows.map(x=>{const v=typeof x==='object'?(x[valueField]??x.Value??x.id??x.Id):x;const t=typeof x==='object'?(x[textField]??x.Text??x.name??x.Name??v):x;return `<option value="${esc(v)}" ${String(v)===current?'selected':''}>${esc(t)}</option>`;}).join(''));
        } catch(e) { select.html(`<option value="">Unable to load options</option>`); }
    }

    function dependencyRuleMatches(rule,root,cssClass) {
        const conditions=rule?.conditions||rule?.Conditions||[];
        return conditions.length>0 && conditions.every(c=>{const actual=getConfiguredFieldValue(root,c.field??c.Field,cssClass), expected=String(c.value??c.Value??''),op=String(c.operator??c.Operator??'eq').toLowerCase();if(op==='neq'||op==='ne')return actual.toLowerCase()!==expected.toLowerCase();if(op==='contains')return actual.toLowerCase().includes(expected.toLowerCase());if(op==='empty')return !actual.trim();if(op==='notempty')return !!actual.trim();return actual.toLowerCase()===expected.toLowerCase();});
    }

    function validateConfiguredFields(root,cssClass) {
        let first=null, valid=true;
        $(root).find(`.${cssClass}`).each(function(){
            const el=$(this), f=JSON.parse(decodeURIComponent(el.attr('data-field-config')||'%7B%7D')), value=el.attr('type')==='checkbox'?(el.prop('checked')?'true':'false'):String(el.val()??'');
            let message='';
            if(f.required && !String(value).trim()) message=f.customErrorMessage||`${f.label} is required.`;
            if(!message && f.minLength!=null && value.length<Number(f.minLength)) message=f.customErrorMessage||`${f.label} must contain at least ${f.minLength} characters.`;
            if(!message && f.maxLength!=null && value.length>Number(f.maxLength)) message=f.customErrorMessage||`${f.label} cannot exceed ${f.maxLength} characters.`;
            if(!message && f.validationPattern && value && !(new RegExp(f.validationPattern).test(value))) message=f.customErrorMessage||`${f.label} has an invalid format.`;
            if(!message && f.type==='number' && value){const n=Number(value);if(Number.isNaN(n))message=`${f.label} must be a number.`;else if(f.minValue!=null&&n<Number(f.minValue))message=f.customErrorMessage||`${f.label} must be at least ${f.minValue}.`;else if(f.maxValue!=null&&n>Number(f.maxValue))message=f.customErrorMessage||`${f.label} cannot exceed ${f.maxValue}.`;}
            const rules=json(f.dependencyValidationsJson||'[]',[]); for(const r of rules){if(!dependencyRuleMatches(r,root,cssClass))continue;if((r.required??r.Required)&&!value.trim())message=r.errorMessage??r.ErrorMessage??`${f.label} is required for the selected values.`;const match=r.mustEqualField??r.MustEqualField;if(!message&&match&&value!==getConfiguredFieldValue(root,match,cssClass))message=r.errorMessage??r.ErrorMessage??`${f.label} must match ${match}.`;}
            el.toggleClass('is-invalid',!!message);el.siblings('.cats-field-error').text(message||f.customErrorMessage||'Please enter a valid value.');if(message){valid=false;first=first||el;}
        });
        if(first?.length){const modal=first.closest('.modal');if(modal.length)bootstrap.Modal.getOrCreateInstance(modal[0]).show();first.trigger('focus');}
        return valid;
    }

    function bindConfiguredFields(root,cssClass) {
        $(root).find(`.${cssClass}`).each(function(){const el=$(this),f=JSON.parse(decodeURIComponent(el.attr('data-field-config')||'%7B%7D'));el.data('initial-value',el.val());const updateCounter=()=>{if(f.maxLength!=null)$(root).find(`[data-counter-for="${f.name}"]`).text(`${String(el.val()??'').length}/${f.maxLength}`);};el.on('input change',()=>{updateCounter();el.removeClass('is-invalid');});updateCounter();});
        $(root).find('.cats-api-select').each(function(){loadApiSelect($(this),root,cssClass);});
        $(root).find(`.${cssClass}`).on('change',function(){const changed=String($(this).data('name')||'');$(root).find('.cats-api-select').each(function(){const f=JSON.parse(decodeURIComponent($(this).attr('data-field-config')||'%7B%7D'));if(String(f.dependsOnFields||'').split(',').map(x=>x.trim().toLowerCase()).includes(changed.toLowerCase()))loadApiSelect($(this),root,cssClass);});});
        $(root).find('.cats-wizard').each(function(){const wizard=$(this),show=i=>{wizard.find('.cats-wizard-pane').addClass('d-none').filter(`[data-step="${i}"]`).removeClass('d-none');wizard.find('.cats-wizard-step').removeClass('btn-primary').addClass('btn-outline-secondary').filter(`[data-step="${i}"]`).addClass('btn-primary').removeClass('btn-outline-secondary');};wizard.on('click','.cats-wizard-next',function(){show(Number($(this).closest('.cats-wizard-pane').data('step'))+1);});wizard.on('click','.cats-wizard-prev',function(){show(Number($(this).closest('.cats-wizard-pane').data('step'))-1);});wizard.on('click','.cats-wizard-step:not(:disabled)',function(){show(Number($(this).data('step')));});});
    }

    function dynamicFormHtml(template, data = {}) {
        const sections=json(template.sectionsJson,[]),fields=json(template.fieldsJson,[]),cfg=templateViewConfig(template);
        return configuredSectionsHtml(sections,fields,data,null,'dynamic-field',cfg,'new-alert-layout');
    }

    async function renderNewAlert() {
        if (!has('ALERT.UPLOAD')) throw new Error('Alert upload permission is required.'); await loadTemplates(); header('New / Upload Alerts', 'Create a single alert or upload a CSV file');
        const published = state.templates.filter(t => t.status === 'Published');
        $('#viewHost').html(`<div class="row g-3"><div class="col-xl-8"><div class="card"><div class="card-header bg-white fw-semibold">Create Alert</div><div class="card-body"><form id="newAlertForm"><div class="row g-3 mb-3"><div class="col-md-8"><label class="form-label">Alert Type <span class="text-danger">*</span></label><select id="newAlertType" class="form-select" required><option value="">Select alert type</option>${published.map(t => `<option value="${esc(t.id)}">${esc(t.code)}</option>`).join('')}</select></div><div class="col-md-4"><label class="form-label">Priority</label><select id="newPriority" class="form-select"><option>Normal</option><option>High</option><option>Critical</option><option>Low</option></select></div></div><div id="newDynamic"><div class="text-secondary">Select an alert type to load its configured fields.</div></div><div class="text-end"><button class="btn btn-primary px-4">Submit Alert</button></div></form></div></div></div><div class="col-xl-4"><div class="card"><div class="card-header bg-white fw-semibold">Bulk CSV Upload</div><div class="card-body"><p class="small text-secondary">Upload records using the field mapping defined by the selected alert configuration.</p><input id="csvFile" type="file" accept=".csv,text/csv" class="form-control mb-3"/><button id="uploadCsvBtn" class="btn btn-outline-primary w-100">Upload CSV</button><div id="csvResult" class="small mt-3"></div></div></div></div></div>`);
        $('#csvFile').before('<button id="downloadSampleCsv" type="button" class="btn btn-sm btn-link px-0 mb-2">Download sample file for selected Alert Type</button>');
        $('#newAlertType').on('change', function () { const t = published.find(x => x.id === $(this).val()); $('#newDynamic').html(t ? dynamicFormHtml(t) : '<div class="text-secondary">Select an alert type to load its configured fields.</div>'); if(t) bindConfiguredFields('#newDynamic','dynamic-field'); });
        $('#newAlertForm').on('submit', async e => { e.preventDefault(); try { const t = published.find(x => x.id === $('#newAlertType').val()); if (!t) throw new Error('Select an alert type.'); if(!validateConfiguredFields('#newDynamic','dynamic-field')) throw new Error('Please correct the highlighted fields.'); const data = {}; $('.dynamic-field').each(function () { const n = $(this).data('name'); data[n] = $(this).attr('type') === 'checkbox' ? this.checked : $(this).val(); }); const configuredValue = name => { const key = Object.keys(data).find(x => x.toLowerCase() === name.toLowerCase()); return key ? data[key] : ''; }; const r = await api('/api/alerts', { method: 'POST', body: { templateId: t.id, alertType: t.code, branchCode: configuredValue('BranchCode'), customerId: configuredValue('CustomerId'), accountId: configuredValue('AccountId'), priority: $('#newPriority').val(), data } }); toast(`Alert ${r.alertNo} created`); navigate('detail', r.id); } catch (x) { toast(x.message, 'danger'); } });
        $('#downloadSampleCsv').on('click',async()=>{try{const templateId=$('#newAlertType').val();if(!templateId)throw new Error('Select an Alert Type first.');const response=await fetch(apiUrl(`/api/alerts/sample-csv/${encodeURIComponent(templateId)}`),{headers:{Authorization:`Bearer ${state.token}`}});if(!response.ok){let error;try{error=await response.json();}catch{}throw new Error(error?.message||'Sample CSV download failed.');}const blob=await response.blob(),link=document.createElement('a'),type=published.find(x=>x.id===templateId);link.href=URL.createObjectURL(blob);link.download=`${type?.code||'AlertType'}-sample.csv`;link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);}catch(x){toast(x.message,'danger');}});
        $('#uploadCsvBtn').on('click', async () => { try { const templateId=$('#newAlertType').val(); if(!templateId)throw new Error('Select an Alert Type first.'); const f = $('#csvFile')[0].files[0]; if (!f) throw new Error('Select a CSV file.'); const fd = new FormData(); fd.append('file', f); fd.append('templateId',templateId); $('#csvResult').html('Uploading...'); const r = await api('/api/alerts/upload-csv', { method: 'POST', body: fd }); $('#csvResult').html(`<div class="alert ${r.failed ? 'alert-warning' : 'alert-success'} py-2">Success: ${r.success}, Failed: ${r.failed}</div>${r.results.slice(0, 10).map(x => `<div>Line ${x.line}: ${esc(x.status)} ${x.alertNo ? esc(x.alertNo) : esc(x.error || '')}</div>`).join('')}`); } catch (x) { toast(x.message, 'danger'); } });
    }

    function fieldValue(v) { if (v === null || v === undefined) return ''; if (typeof v === 'object') return JSON.stringify(v); return String(v); }
    async function renderDetail(id) {
        header('Alert Detail', 'Dynamic template view and role-based workflow actions', '<button id="backAlerts" class="btn btn-sm btn-outline-secondary">← Back</button>');
        loading();
        const d = await api('/api/alerts/' + id);
        const data = d.dynamicData || {};
        const editable = new Set((d.editableFields || []).map(x => String(x).toLowerCase()));
        const detailViewConfig=templateViewConfig({viewConfiguration:d.viewConfiguration});
        const sections=configuredSectionsHtml(d.sections,d.fields,data,editable,'detail-dynamic-field',detailViewConfig,'detail-layout');
        const actions = (d.allowedActions || []).map(a => `<button class="btn ${/reject/i.test(a) ? 'btn-outline-danger' : /query|return/i.test(a) ? 'btn-outline-warning' : 'btn-primary'} workflow-action" data-action="${esc(a)}">${esc(a)}</button>`).join('');
        const reassign = has('ALERT.REASSIGN') ? `<div class="card mb-3"><div class="card-header bg-white fw-semibold">Reassign Current Stage</div><div class="card-body"><div class="row g-2"><div class="col-md-4"><input id="reassignRole" class="form-control form-control-sm" placeholder="Role code" list="roleOptions"></div><div class="col-md-4"><input id="reassignBranch" class="form-control form-control-sm" placeholder="Branch (optional)"></div><div class="col-md-4"><input id="reassignUser" class="form-control form-control-sm" placeholder="User ID (optional)"></div><div class="col-12"><input id="reassignRemarks" class="form-control form-control-sm" placeholder="Reason / remarks"></div><div class="col-12 d-grid"><button id="reassignBtn" class="btn btn-sm btn-outline-primary">Reassign</button></div></div></div></div>` : '';
        let h = `<div class="row g-3"><div class="col-xl-8"><div class="card mb-3"><div class="card-body"><div class="d-flex flex-wrap justify-content-between gap-2"><div><div class="text-secondary small">Alert Number</div><h4 class="text-primary">${esc(d.alert.alertNo)}</h4><div class="small text-secondary">Alert Type</div><div class="fw-semibold">${esc(d.alert.alertType)}</div></div><div>${statusBadge(d.alert.status)}</div></div></div></div>${editable.size ? '<div class="alert alert-info py-2 small">Fields shown as inputs can be updated by your role at the current workflow stage. Values are saved when you perform a workflow action.</div>' : ''}${sections}<div class="card"><div class="card-header bg-white fw-semibold">Attachments</div><div class="card-body"><form id="attachmentForm" class="row g-2"><div class="col-md-8"><input id="attachmentFile" class="form-control" type="file" /></div><div class="col-md-4 d-grid"><button class="btn btn-outline-primary">Upload to Current Stage</button></div></form><div class="mt-3">${d.attachments.length ? d.attachments.map(a => `<a class="d-block mb-1" target="_blank" href="#" data-attachment="${a.id}">📎 ${esc(a.fileName)} v${a.version} <span class="text-secondary small">${Math.ceil(a.fileSize / 1024)} KB</span></a>`).join('') : '<span class="text-secondary small">No attachments.</span>'}</div></div></div></div><div class="col-xl-4"><div class="card mb-3"><div class="card-header bg-white fw-semibold">Current Workflow</div><div class="card-body"><div class="mb-2"><span class="small text-secondary">Stage</span><div class="fw-semibold">${esc(d.alert.currentStageName)}</div></div><div class="d-flex flex-wrap gap-2">${actions || '<span class="text-secondary small">No action assigned to your role.</span>'}</div></div></div>${reassign}<div class="card mb-3"><div class="card-header bg-white fw-semibold">Queries</div><div class="card-body">${d.queries.length ? d.queries.map(q => `<div class="mb-3"><div class="small text-secondary">${esc(q.raisedBy)} · ${new Date(q.raisedAtUtc).toLocaleString()}</div><div>${esc(q.queryText)}</div>${q.responseText ? `<div class="mt-1 ps-2 border-start text-secondary">${esc(q.responseText)}</div>` : ''}<span class="badge text-bg-light">${esc(q.status)}</span></div>`).join('') : '<span class="text-secondary small">No queries.</span>'}</div></div><div class="card"><div class="card-header bg-white fw-semibold">Audit Trail</div><div class="card-body cats-audit">${d.audit.length ? d.audit.slice(0, 30).map(a => `<div class="audit-line"><div class="fw-medium">${esc(a.action)}</div><div class="small text-secondary">${esc(a.userName)} · ${esc(a.roleCode)} · ${new Date(a.createdAtUtc).toLocaleString()}</div>${a.remarks ? `<div class="small">${esc(a.remarks)}</div>` : ''}</div>`).join('') : '<span class="text-secondary small">Audit trail not available for your role.</span>'}</div></div></div></div>`;
        $('#viewHost').html(h);
        bindConfiguredFields('#viewHost','detail-dynamic-field');
        if (!d.canUploadAttachments) $('#attachmentForm').replaceWith('<div class="alert alert-light border py-2 small mb-0">Your role can view permitted attachments but cannot upload at the current stage.</div>');
        const split = $('#viewHost > .row').first().addClass('detail-split-view');
        const panes = split.children('[class*="col-xl-"]');
        panes.first().addClass('detail-main-pane');
        panes.last().addClass('detail-side-pane').attr('id', 'alertDetailSidePane');
        const makeSideCardCollapsible = (title, key, defaultOpen, count = null) => {
            const header = panes.last().find('.card-header').filter((_, element) => $(element).text().trim() === title).first();
            if (!header.length) return;
            const body = header.next('.card-body');
            if (!body.length) return;
            const storageKey = `cats_detail_section_${key}_open`;
            const savedState = sessionStorage.getItem(storageKey);
            const isOpen = savedState === null ? defaultOpen : savedState === 'true';
            const collapseId = `detail-${key}-collapse`;
            const toggleId = `detail-${key}-toggle`;
            const countBadge = count === null ? '' : `<span class="badge rounded-pill text-bg-light ms-2">${Number(count).toLocaleString()}</span>`;
            const collapse = $(`<div id="${collapseId}" class="collapse${isOpen ? ' show' : ''}" data-detail-section="${key}" role="region" aria-labelledby="${toggleId}"></div>`);
            body.wrap(collapse);
            header.addClass('p-0').html(`<button id="${toggleId}" class="detail-card-toggle${isOpen ? '' : ' collapsed'}" type="button" data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="${isOpen}" aria-controls="${collapseId}"><span class="d-inline-flex align-items-center">${esc(title)}${countBadge}</span><span class="detail-card-chevron" aria-hidden="true"></span></button>`);
            header.closest('.card').addClass('detail-collapsible-card');
            $(`#${collapseId}`).on('shown.bs.collapse hidden.bs.collapse', function () { sessionStorage.setItem(storageKey, String($(this).hasClass('show'))); });
        };
        makeSideCardCollapsible('Reassign Current Stage', 'reassign', false);
        makeSideCardCollapsible('Queries', 'queries', d.queries.length > 0, d.queries.length);
        makeSideCardCollapsible('Audit Trail', 'audit', false, d.audit.length);
        split.append('<button id="detailPanelToggle" class="detail-panel-toggle" type="button" aria-controls="alertDetailSidePane"><span aria-hidden="true"></span></button>');
        const setDetailPanelCollapsed = collapsed => { split.toggleClass('is-collapsed', collapsed); $('#detailPanelToggle').attr({ 'aria-expanded': String(!collapsed), 'aria-label': collapsed ? 'Expand details' : 'Collapse details', 'title': collapsed ? 'Expand details' : 'Collapse details' }).find('span').text(collapsed ? '‹' : '›'); sessionStorage.setItem('cats_detail_panel_collapsed', String(collapsed)); };
        setDetailPanelCollapsed(sessionStorage.getItem('cats_detail_panel_collapsed') === 'true');
        $('#detailPanelToggle').on('click', () => setDetailPanelCollapsed(!split.hasClass('is-collapsed')));
        $('#backAlerts').off('click').on('click', () => navigate('alerts', state.alertFilter));
        const collectResponse = () => { if(!validateConfiguredFields('#viewHost','detail-dynamic-field')) throw new Error('Please correct the highlighted fields.'); const result = {}; $('.detail-dynamic-field').each(function () { const name = $(this).data('name'); result[name] = $(this).attr('type') === 'checkbox' ? this.checked : $(this).val(); }); return result; };
        $('.workflow-action').on('click', function () {
            const action = String($(this).data('action') || '');
            const isQuery = /^(RaiseQuery|Query)$/i.test(action);
            state.pendingAction = { id, action, collect: collectResponse, aiQueryEnabled: isQuery && !!d.aiQueryEnabled };
            $('#actionModalTitle').text(action);
            $('#actionRemarks').val('');
            $('#aiQueryInstruction').val('');
            $('#aiQueryStatus').text('');
            $('#actionRemarksLabel').text(isQuery ? 'Query text / remarks' : 'Remarks / reason');
            $('#aiQueryAssistPanel').toggleClass('d-none', !(isQuery && d.aiQueryEnabled));
            $('#aiQueryHumanNotice').toggleClass('d-none', !(isQuery && d.aiQueryEnabled));
            if (isQuery && d.aiQueryEnabled) $('#aiQueryModelInfo').text(`Draft only · ${d.aiQueryProvider || 'Configured provider'} / ${d.aiQueryModel || 'Configured model'}`);
            bootstrap.Modal.getOrCreateInstance('#actionModal').show();
        });
        $('#reassignBtn').on('click', async () => { try { const role = $('#reassignRole').val().trim(), branch = $('#reassignBranch').val().trim(), userId = $('#reassignUser').val().trim(); if (!role && !userId) throw new Error('Enter a role code or user ID.'); await api(`/api/alerts/${id}/reassign`, { method: 'POST', body: { stageId: d.alert.currentStageId, roleCode: role || null, branchCode: branch || null, userId: userId || null, remarks: $('#reassignRemarks').val() } }); toast('Work item reassigned'); renderDetail(id); } catch (x) { toast(x.message, 'danger'); } });
        $('[data-attachment]').on('click', async function (e) { e.preventDefault(); try { const aid = $(this).data('attachment'); const r = await fetch(apiUrl('/api/alerts/attachments/' + aid), { headers: { Authorization: `Bearer ${state.token}` } }); if (!r.ok) throw new Error('Download failed'); const blob = await r.blob(); const cd = r.headers.get('content-disposition') || ''; const name = (cd.match(/filename\*=UTF-8''([^;]+)/) || cd.match(/filename="?([^";]+)"?/))?.[1] || 'attachment'; const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = decodeURIComponent(name); a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); } catch (x) { toast(x.message, 'danger'); } });
        $('#attachmentForm').on('submit', async e => { e.preventDefault(); try { const f = $('#attachmentFile')[0].files[0]; if (!f) throw new Error('Select a file.'); const fd = new FormData(); fd.append('stageId', d.alert.currentStageId); fd.append('file', f); await api(`/api/alerts/${id}/attachments`, { method: 'POST', body: fd }); toast('Attachment uploaded'); renderDetail(id); } catch (x) { toast(x.message, 'danger'); } });
    }

    async function renderTemplateDesigner(preserveDraft = false) {
        if (!has('TEMPLATE.MANAGE')) throw new Error('Template management permission is required.'); await loadTemplates(true); header('Template Designer', 'Configure reusable sections, fields and assignment rules');
        $('#viewHost').html(`<div class="card mb-3"><div class="card-body"><div class="row g-2"><div class="col-md-8"><select id="tdSelect" class="form-select"><option value="">+ New Template</option>${state.templates.map(t => `<option value="${t.id}">${esc(t.name)} v${t.version} · ${esc(t.status)}</option>`).join('')}</select></div><div class="col-md-4 d-grid"><button id="tdLoad" class="btn btn-outline-primary">Load</button></div></div></div></div><div id="tdEditor"></div>`);
        const fresh = () => ({ id: null, code: '', name: '', version: 0, status: 'Draft', executionMode: 'Deterministic', viewConfiguration: { layoutMode: 'Single', baseDataModes: ['ManualSingle','BulkFileUpload','Sftp','FcQuery'], rememberLastSection: true, showSectionNumbers: true, allowWizardStepClick: false, popupSize: 'xl' }, sections: [], fields: [], assignmentRules: [] });
        const normalizeSection = (x, i) => ({ id: x.id ?? x.Id ?? uid(), name: x.name ?? x.Name ?? '', order: x.order ?? x.Order ?? i + 1, columnSpan: Math.min(12, Math.max(2, Number(x.columnSpan ?? x.ColumnSpan ?? 6) || 6)), pageNumber: Math.max(1, Number(x.pageNumber ?? x.PageNumber ?? 1) || 1), dataViewMode: x.dataViewMode ?? x.DataViewMode ?? 'Grid' });
        const normalizeField = (x, i) => ({ id: x.id ?? x.Id ?? uid(), sectionId: x.sectionId ?? x.SectionId ?? '', name: x.name ?? x.Name ?? '', label: x.label ?? x.Label ?? '', type: x.type ?? x.Type ?? 'text', required: x.required ?? x.Required ?? false, sensitive: x.sensitive ?? x.Sensitive ?? false, order: x.order ?? x.Order ?? i + 1, optionsJson: x.optionsJson ?? x.OptionsJson ?? '[]', placeholder:x.placeholder??x.Placeholder??'', helpText:x.helpText??x.HelpText??'', minLength:x.minLength??x.MinLength??null, maxLength:x.maxLength??x.MaxLength??null, minValue:x.minValue??x.MinValue??null, maxValue:x.maxValue??x.MaxValue??null, validationPattern:x.validationPattern??x.ValidationPattern??'', customErrorMessage:x.customErrorMessage??x.CustomErrorMessage??'', dataSourceMode:x.dataSourceMode??x.DataSourceMode??'Static', apiUrl:x.apiUrl??x.ApiUrl??'', apiValueField:x.apiValueField??x.ApiValueField??'value', apiTextField:x.apiTextField??x.ApiTextField??'text', dependsOnFields:x.dependsOnFields??x.DependsOnFields??'', dependencyValidationsJson:x.dependencyValidationsJson??x.DependencyValidationsJson??'[]', readOnly:x.readOnly??x.ReadOnly??false, defaultValue:x.defaultValue??x.DefaultValue??'' });
        const fromRecord = t => ({ id: t.id, code: t.code, name: t.name, version: t.version, status: t.status, executionMode: t.executionMode, viewConfiguration: Object.assign({ layoutMode:'Single', baseDataModes:['ManualSingle','BulkFileUpload','Sftp','FcQuery'], rememberLastSection:true, showSectionNumbers:true, allowWizardStepClick:false, popupSize:'xl' }, json(t.viewConfigurationJson, {})), sections: json(t.sectionsJson, []).map(normalizeSection), fields: json(t.fieldsJson, []).map(normalizeField), assignmentRules: json(t.assignmentRulesJson, []) });
        function draw() { const d = state.templateDraft; $('#tdEditor').html(`<div class="card"><div class="card-body"><div class="row g-3"><div class="col-md-3"><label class="form-label">Template Code</label><input id="tdCode" class="form-control" value="${esc(d.code)}" /></div><div class="col-md-5"><label class="form-label">Template Name</label><input id="tdName" class="form-control" value="${esc(d.name)}" /></div><div class="col-md-4"><label class="form-label">Execution Mode</label><select id="tdMode" class="form-select">${['Deterministic', 'Hybrid', 'Agentic'].map(x => `<option ${d.executionMode === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div></div><div class="card bg-light border-0 mt-3"><div class="card-body"><div class="fw-semibold mb-2">View / Layout Configuration</div><div class="row g-3"><div class="col-md-4"><label class="form-label">Alert Detail Layout</label><select id="tdLayoutMode" class="form-select">${['Single','Tab','Popup','Accordion','Wizard'].map(x=>`<option ${d.viewConfiguration?.layoutMode===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="col-md-2"><label class="form-label">Popup Size</label><select id="tdPopupSize" class="form-select">${['sm','lg','xl'].map(x=>`<option ${d.viewConfiguration?.popupSize===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="col-md-2 form-check mt-5 ms-2"><input id="tdRememberSection" class="form-check-input" type="checkbox" ${d.viewConfiguration?.rememberLastSection!==false?'checked':''}><label class="form-check-label">Remember section</label></div><div class="col-md-2 form-check mt-5"><input id="tdShowSectionNumbers" class="form-check-input" type="checkbox" ${d.viewConfiguration?.showSectionNumbers!==false?'checked':''}><label class="form-check-label">Show section numbers</label></div><div class="col-md-2 form-check mt-5"><input id="tdWizardStepClick" class="form-check-input" type="checkbox" ${d.viewConfiguration?.allowWizardStepClick?'checked':''}><label class="form-check-label">Wizard step click</label></div></div><div class="form-text mt-2">Single, Tab, Popup, Accordion and Wizard layouts use the same configured sections and fields. No code change is required per template.</div></div></div><hr/><div class="d-flex justify-content-between mb-2"><h6>Sections</h6><button id="addSection" class="btn btn-sm btn-outline-primary">+ Add Section</button></div><div class="table-responsive"><table class="table table-sm"><thead><tr><th>#</th><th>Name</th><th></th></tr></thead><tbody>${d.sections.map((s, i) => `<tr><td>${i + 1}</td><td>${esc(s.name)}</td><td class="text-end"><button class="btn btn-sm btn-outline-danger del-section" data-i="${i}">Delete</button></td></tr>`).join('') || '<tr><td colspan="3" class="text-secondary">No sections.</td></tr>'}</tbody></table></div><div class="d-flex justify-content-between mb-2 mt-4"><h6>Fields</h6><button id="addField" class="btn btn-sm btn-outline-primary">+ Add Field</button></div><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Section</th><th>Field</th><th>Type</th><th>Required</th><th>Sensitive</th><th></th></tr></thead><tbody>${d.fields.map((f, i) => `<tr><td>${esc(d.sections.find(s => s.id === f.sectionId)?.name || '')}</td><td>${esc(f.label)}</td><td>${esc(f.type)}</td><td>${f.required ? 'Yes' : 'No'}</td><td>${f.sensitive ? 'Yes' : 'No'}</td><td class="text-end"><button class="btn btn-sm btn-outline-secondary edit-field" data-i="${i}">Edit</button> <button class="btn btn-sm btn-outline-danger del-field" data-i="${i}">Delete</button></td></tr>`).join('') || '<tr><td colspan="6" class="text-secondary">No fields.</td></tr>'}</tbody></table></div><div class="mt-4"><label class="form-label">Assignment Rules JSON</label><textarea id="tdRules" class="form-control font-monospace" rows="6">${esc(JSON.stringify(d.assignmentRules, null, 2))}</textarea><div class="form-text">Example: [{"field":"riskCategory","operator":"eq","value":"High","stageId":"input","targetRoleCode":"DT_USER","targetBranchCode":"B001","stop":true}]</div></div><div class="text-end mt-3"><button id="saveTemplate" class="btn btn-primary px-4">Save Template</button></div></div></div>`); bind(); }
        function bind() { const d=state.templateDraft,sectionTable=$('#tdEditor table').first(); sectionTable.find('thead th').eq(1).after('<th>Field Column Width</th><th>Data View</th>'); d.sections.forEach((s,i)=>{const row=sectionTable.find('tbody tr').eq(i);row.find('td').eq(1).after(`<td>${s.columnSpan} / 12</td><td>${esc(s.dataViewMode||'Grid')}</td>`);row.find('td:last').prepend(`<button class="btn btn-sm btn-outline-secondary edit-section me-1" data-i="${i}">Edit</button>`);}); if(d.id&&d.status!=='Retired')$('#saveTemplate').before('<button id="retireTemplate" type="button" class="btn btn-outline-danger me-2">Retire Template</button>'); $('#tdCode').on('input',function(){d.code=$(this).val();}); $('#tdName').on('input',function(){d.name=$(this).val();}); $('#tdMode').on('change',function(){d.executionMode=$(this).val();}); $('#tdLayoutMode').on('change',function(){d.viewConfiguration.layoutMode=$(this).val();}); $('#tdPopupSize').on('change',function(){d.viewConfiguration.popupSize=$(this).val();}); $('#tdRememberSection').on('change',function(){d.viewConfiguration.rememberLastSection=this.checked;}); $('#tdShowSectionNumbers').on('change',function(){d.viewConfiguration.showSectionNumbers=this.checked;}); $('#tdWizardStepClick').on('change',function(){d.viewConfiguration.allowWizardStepClick=this.checked;}); $('#tdRules').on('input',function(){const rules=json($(this).val(),null);if(rules)d.assignmentRules=rules;}); $('#addSection').on('click', () => openSection(-1)); $('.edit-section').on('click',function(){openSection(+$(this).data('i'));}); $('.del-section').on('click', function () { const i = +$(this).data('i'), id = state.templateDraft.sections[i].id; state.templateDraft.sections.splice(i, 1); state.templateDraft.fields = state.templateDraft.fields.filter(f => f.sectionId !== id); draw(); }); $('#addField').on('click', () => openField(-1)); $('.edit-field').on('click', function () { openField(+$(this).data('i')); }); $('.del-field').on('click', function () { state.templateDraft.fields.splice(+$(this).data('i'), 1); draw(); }); $('#saveTemplate').on('click', save); $('#retireTemplate').on('click',retire); }
        function decorateTemplateConfiguration() {
            const d=state.templateDraft;
            const configuredModes=Array.isArray(d.viewConfiguration?.baseDataModes)?d.viewConfiguration.baseDataModes:['ManualSingle','BulkFileUpload','Sftp','FcQuery'];
            const baseDataOptions=[
                {value:'ManualSingle',label:'Manual Single Entry',help:'Create one alert from the configured form.'},
                {value:'BulkFileUpload',label:'Bulk File Upload',help:'Upload multiple alert records from CSV.'},
                {value:'Sftp',label:'SFTP Location',help:'Allow a scheduled SFTP ingestion task.'},
                {value:'FcQuery',label:'FC Query',help:'Allow a scheduled query ingestion task.'}
            ];
            const viewCard=$('#tdLayoutMode').closest('.card-body');
            viewCard.prepend(`<div class="fw-semibold mb-2">Base Data Configuration</div><div id="tdBaseDataModes" class="row g-2 mb-3">${baseDataOptions.map(option=>`<div class="col-md-6 col-xl-3"><div class="form-check border rounded bg-white p-3 h-100"><input class="form-check-input td-base-data-mode ms-0 me-2" type="checkbox" value="${option.value}" id="tdBaseData-${option.value}" ${configuredModes.some(value=>String(value).toLowerCase()===option.value.toLowerCase())?'checked':''}><label class="form-check-label fw-semibold" for="tdBaseData-${option.value}">${option.label}</label><div class="small text-secondary mt-1">${option.help}</div></div></div>`).join('')}</div><hr class="my-3">`);
            viewCard.find('.fw-semibold').filter(function(){return $(this).text().trim()==='View / Layout Configuration';}).text('View / Layout Configuration');
            const layouts=[
                {value:'Auto',label:'Automatic (tabs for multiple sections)'},
                {value:'Single',label:'Single View (all sections)'},
                {value:'Tab',label:'Tabbed View (one section per tab)'},
                {value:'Popup',label:'Popup View'},
                {value:'Accordion',label:'Accordion View'},
                {value:'Wizard',label:'Wizard / Step View'}
            ];
            $('#tdLayoutMode').html(layouts.map(option=>`<option value="${option.value}" ${String(d.viewConfiguration?.layoutMode||'Single').toLowerCase()===option.value.toLowerCase()?'selected':''}>${option.label}</option>`).join(''));
            viewCard.find('.form-text').first().text('Automatic uses Single View for one section and Tabbed View for multiple sections. You can also explicitly choose either layout.');
            $('.td-base-data-mode').on('change',function(){
                const selected=$('.td-base-data-mode:checked').map((_,element)=>element.value).get();
                if(!selected.length){this.checked=true;toast('Select at least one Base Data option.','warning');return;}
                d.viewConfiguration.baseDataModes=$('.td-base-data-mode:checked').map((_,element)=>element.value).get();
            });
        }
        const drawTemplateEditor=draw;
        draw=function(){drawTemplateEditor();decorateTemplateConfiguration();};
        function openSection(i) { const s=i>=0?state.templateDraft.sections[i]:{name:'',columnSpan:6,pageNumber:1,dataViewMode:'Grid'}; $('#sectionEditIndex').val(i);$('#sectionName').val(s.name);$('#sectionPageNumber').val(s.pageNumber||1);$('#sectionColumnSpan').val(s.columnSpan||6);$('#sectionDataViewMode').val(s.dataViewMode||'Grid');bootstrap.Modal.getOrCreateInstance('#sectionModal').show(); }
        $('#saveSectionBtn').off('click').on('click',()=>{const i=+$('#sectionEditIndex').val(),name=$('#sectionName').val().trim(),columnSpan=Number($('#sectionColumnSpan').val()),pageNumber=Number($('#sectionPageNumber').val());if(!name){toast('Section name is required','warning');return;}if(!Number.isInteger(pageNumber)||pageNumber<1){toast('Section page must be 1 or greater','warning');return;}const s={id:i>=0?state.templateDraft.sections[i].id:uid(),name,order:i>=0?state.templateDraft.sections[i].order:state.templateDraft.sections.length+1,columnSpan,pageNumber,dataViewMode:$('#sectionDataViewMode').val()||'Grid'};if(i>=0)state.templateDraft.sections[i]=s;else state.templateDraft.sections.push(s);state.templateDraft.sections.sort((a,b)=>(a.pageNumber-b.pageNumber)||(a.order-b.order));bootstrap.Modal.getOrCreateInstance('#sectionModal').hide();draw();});
        function openField(i) {
            if (!state.templateDraft.sections.length) { toast('Add a section first', 'warning'); return; }
            const f = i >= 0 ? state.templateDraft.fields[i] : normalizeField({ sectionId: state.templateDraft.sections[0].id }, state.templateDraft.fields.length);
            $('#fieldEditIndex').val(i);
            $('#fieldSection').html(state.templateDraft.sections.map(s => `<option value="${s.id}" ${s.id === f.sectionId ? 'selected' : ''}>${esc(s.name)}</option>`));
            $('#fieldName').val(f.name); $('#fieldLabel').val(f.label); $('#fieldType').val(f.type);
            $('#fieldRequired').prop('checked', !!f.required); $('#fieldSensitive').prop('checked', !!f.sensitive); $('#fieldReadOnly').prop('checked', !!f.readOnly);
            $('#fieldOptions').val(json(f.optionsJson, []).join(',')); $('#fieldPlaceholder').val(f.placeholder||''); $('#fieldHelpText').val(f.helpText||'');
            $('#fieldMinLength').val(f.minLength??''); $('#fieldMaxLength').val(f.maxLength??''); $('#fieldMinValue').val(f.minValue??''); $('#fieldMaxValue').val(f.maxValue??'');
            $('#fieldValidationPattern').val(f.validationPattern||''); $('#fieldCustomError').val(f.customErrorMessage||''); $('#fieldDefaultValue').val(f.defaultValue||'');
            $('#fieldDataSourceMode').val(f.dataSourceMode||'Static'); $('#fieldApiUrl').val(f.apiUrl||''); $('#fieldApiValueField').val(f.apiValueField||'value'); $('#fieldApiTextField').val(f.apiTextField||'text'); $('#fieldDependsOnFields').val(f.dependsOnFields||'');
            $('#fieldDependencyJson').val(JSON.stringify(json(f.dependencyValidationsJson, []), null, 2));
            bootstrap.Modal.getOrCreateInstance('#fieldModal').show();
        }
        $('#saveFieldBtn').off('click').on('click', () => {
            try {
                const i = +$('#fieldEditIndex').val();
                const dependency = json($('#fieldDependencyJson').val()||'[]', null); if(!dependency) throw new Error('Dependent Validation JSON is invalid.');
                const nullableNumber = id => $(id).val()==='' ? null : Number($(id).val());
                const f = {
                    id: i >= 0 ? state.templateDraft.fields[i].id : uid(), sectionId: $('#fieldSection').val(), name: $('#fieldName').val().trim(), label: $('#fieldLabel').val().trim(), type: $('#fieldType').val(),
                    required: $('#fieldRequired').prop('checked'), sensitive: $('#fieldSensitive').prop('checked'), readOnly:$('#fieldReadOnly').prop('checked'), order: i >= 0 ? state.templateDraft.fields[i].order : state.templateDraft.fields.length + 1,
                    optionsJson: JSON.stringify($('#fieldOptions').val().split(',').map(x => x.trim()).filter(Boolean)), placeholder:$('#fieldPlaceholder').val().trim(), helpText:$('#fieldHelpText').val().trim(),
                    minLength:nullableNumber('#fieldMinLength'), maxLength:nullableNumber('#fieldMaxLength'), minValue:nullableNumber('#fieldMinValue'), maxValue:nullableNumber('#fieldMaxValue'),
                    validationPattern:$('#fieldValidationPattern').val().trim(), customErrorMessage:$('#fieldCustomError').val().trim(), defaultValue:$('#fieldDefaultValue').val(),
                    dataSourceMode:$('#fieldDataSourceMode').val()||'Static', apiUrl:$('#fieldApiUrl').val().trim(), apiValueField:$('#fieldApiValueField').val().trim()||'value', apiTextField:$('#fieldApiTextField').val().trim()||'text', dependsOnFields:$('#fieldDependsOnFields').val().trim(),
                    dependencyValidationsJson:JSON.stringify(dependency)
                };
                if (!f.name || !f.label) throw new Error('Field name and label are required.');
                if(f.minLength!==null && f.maxLength!==null && f.minLength>f.maxLength) throw new Error('Min length cannot exceed Max length.');
                if(f.minValue!==null && f.maxValue!==null && f.minValue>f.maxValue) throw new Error('Min value cannot exceed Max value.');
                if(f.type==='select' && f.dataSourceMode==='Api' && !f.apiUrl.toLowerCase().startsWith('/api/')) throw new Error('API dropdown URL must start with /api/ so it is routed through the CATS Gateway.');
                if (i >= 0) state.templateDraft.fields[i] = f; else state.templateDraft.fields.push(f);
                bootstrap.Modal.getOrCreateInstance('#fieldModal').hide(); draw();
            } catch(x) { toast(x.message,'danger'); }
        });
        async function save() { try { state.templateDraft.code = $('#tdCode').val().trim(); state.templateDraft.name = $('#tdName').val().trim(); state.templateDraft.executionMode = $('#tdMode').val(); state.templateDraft.viewConfiguration={layoutMode:$('#tdLayoutMode').val()||'Single',popupSize:$('#tdPopupSize').val()||'xl',rememberLastSection:$('#tdRememberSection').is(':checked'),showSectionNumbers:$('#tdShowSectionNumbers').is(':checked'),allowWizardStepClick:$('#tdWizardStepClick').is(':checked')}; state.templateDraft.assignmentRules = json($('#tdRules').val(), null); if (!state.templateDraft.code || !state.templateDraft.name) throw new Error('Code and name are required.'); if (!state.templateDraft.sections.length) throw new Error('Add at least one section.'); if (!state.templateDraft.assignmentRules) throw new Error('Assignment Rules JSON is invalid.'); const r = await api('/api/templates', { method: 'POST', body: { id: state.templateDraft.id, code: state.templateDraft.code, name: state.templateDraft.name, executionMode: state.templateDraft.executionMode, sections: state.templateDraft.sections, fields: state.templateDraft.fields, assignmentRules: state.templateDraft.assignmentRules, viewConfiguration: state.templateDraft.viewConfiguration } }); state.templateDraft = fromRecord(r); await loadTemplates(true); toast(`Template ${r.name} v${r.version} saved`); await renderTemplateDesigner(true); $('#tdSelect').val(r.id); } catch (x) { toast(x.message, 'danger'); } }
        async function retire() { if(!state.templateDraft.id||!confirm(`Retire ${state.templateDraft.name}? It will no longer be available for new alerts.`))return; try { const r=await api(`/api/templates/${encodeURIComponent(state.templateDraft.id)}/retire`,{method:'POST'}); state.templateDraft=fromRecord(r); await loadTemplates(true); toast(`Template ${r.name} v${r.version} retired`); await renderTemplateDesigner(true); $('#tdSelect').val(r.id); } catch(x){toast(x.message,'danger');} }
        $('#tdLoad').on('click', async () => { try { const id = $('#tdSelect').val(); if (!id) { state.templateDraft = fresh(); draw(); return; } const t = await api('/api/templates/' + id); state.templateDraft = fromRecord(t); draw(); } catch (x) { toast(x.message, 'danger'); } }); if(!preserveDraft)state.templateDraft = fresh(); draw();
    }

    async function renderMcpDiscovery() {
        if (!has('MCP.MANAGE')) throw new Error('MCP management permission is required.');
        header('MCP Server Connections', 'Monitor configured MCP servers and available tools');
        loading();
        const servers = await api('/api/mcp/servers');
        const rows = servers.map(x => `<tr data-mcp-code="${esc(x.code)}"><td><div class="fw-semibold">${esc(x.name || x.code)}</div><code>${esc(x.code)}</code></td><td class="text-break small">${esc(x.endpoint)}</td><td class="mcp-status">${x.enabled ? '<span class="badge text-bg-info">Waiting</span>' : '<span class="badge text-bg-secondary">Disabled</span>'}</td><td class="mcp-tool-count">${x.approvedToolCount || 0} approved</td><td class="text-end"><button class="btn btn-sm btn-outline-primary mcp-discover" data-code="${esc(x.code)}" ${x.enabled ? '' : 'disabled'}>Reconnect</button></td></tr>`).join('');
        $('#viewHost').html(`<div class="alert alert-light border small"><strong>Automatic connection:</strong> Enabled servers connect when this page opens. Only approved read-only tools are available to the CATS Assistant.</div><div class="card mb-3"><div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2"><span class="fw-semibold">Discover another MCP server</span><div><button id="mcpClearResults" type="button" class="btn btn-sm btn-outline-secondary me-1">Clear results</button><button id="mcpResetPage" type="button" class="btn btn-sm btn-outline-danger">Reset page</button></div></div><div class="card-body"><form id="mcpEndpointDiscoveryForm" class="row g-2 align-items-end"><div class="col-md-3"><label class="form-label">Server name</label><input id="mcpEndpointName" class="form-control" maxlength="120" placeholder="Example: Finance MCP"></div><div class="col-md-7"><label class="form-label">MCP endpoint</label><input id="mcpEndpointUrl" class="form-control" type="url" required placeholder="https://server.example.com/mcp"></div><div class="col-md-2 d-grid"><button id="mcpEndpointDiscover" class="btn btn-primary">Discover server</button></div><div class="col-12 form-text">Temporary discovery only. You can inspect multiple servers during this session; their tools are not automatically approved or saved.</div></form></div></div><div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Server</th><th>Endpoint</th><th>Connection</th><th>Tools</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="text-secondary text-center py-4">No MCP servers are configured.</td></tr>'}</tbody></table></div></div><div id="mcpDiscoveryResults" class="mt-3"></div>`);

        async function discover(code) {
            const row = $(`tr[data-mcp-code="${CSS.escape(code)}"]`), button = row.find('.mcp-discover');
            row.find('.mcp-status').html('<span class="badge text-bg-info">Connecting...</span>');
            button.prop('disabled', true).text('Connecting...');
            try {
                const result = await api(`/api/mcp/servers/${encodeURIComponent(code)}/discover`, { method: 'POST' });
                const tools = result.tools || [];
                row.find('.mcp-status').html('<span class="badge text-bg-success">Connected</span>');
                row.find('.mcp-tool-count').text(`${tools.length} discovered / ${tools.filter(x => x.approvedReadOnly).length} approved`);
                const toolRows = tools.map(t => `<tr><td><code>${esc(t.name)}</code></td><td>${esc(t.description || '')}</td><td>${t.approvedReadOnly ? '<span class="badge text-bg-success">Approved read-only</span>' : '<span class="badge text-bg-warning">Not approved</span>'}</td></tr>`).join('');
                $('#mcpDiscoveryResults').append(`<div class="card mb-3"><div class="card-header bg-white fw-semibold">${esc(result.serverName || code)} - Available tools</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Tool</th><th>Description</th><th>Assistant access</th></tr></thead><tbody>${toolRows || '<tr><td colspan="3" class="text-secondary">Connected successfully; the server returned no tools.</td></tr>'}</tbody></table></div></div>`);
            } catch (x) {
                row.find('.mcp-status').html('<span class="badge text-bg-danger">Connection failed</span>');
                row.find('.mcp-tool-count').html(`<span class="text-danger small">${esc(x.message)}</span>`);
            } finally {
                button.prop('disabled', false).text('Reconnect');
            }
        }

        $('.mcp-discover').on('click', function () {
            const code = String($(this).data('code') || '');
            $('#mcpDiscoveryResults').empty();
            discover(code);
        });
        $('#mcpEndpointDiscoveryForm').on('submit', async e => {
            e.preventDefault();
            const button = $('#mcpEndpointDiscover');
            const request = { name: $('#mcpEndpointName').val().trim(), endpoint: $('#mcpEndpointUrl').val().trim(), timeoutSeconds: 30 };
            try {
                button.prop('disabled', true).text('Connecting...');
                const result = await api('/api/mcp/discover', { method: 'POST', body: request });
                const tools = result.tools || [];
                const toolRows = tools.map(t => `<tr><td><code>${esc(t.name)}</code></td><td>${esc(t.description || '')}</td><td><span class="badge text-bg-secondary">Session discovery only</span></td></tr>`).join('');
                $('#mcpDiscoveryResults').prepend(`<div class="card mb-3 border-success"><div class="card-header bg-white d-flex justify-content-between align-items-center"><span class="fw-semibold">${esc(result.serverName || request.name || request.endpoint)} - Available tools</span><span class="badge text-bg-success">Connected / ${tools.length} tools</span></div><div class="card-body py-2 small text-secondary text-break">${esc(request.endpoint)}</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Tool</th><th>Description</th><th>Assistant access</th></tr></thead><tbody>${toolRows || '<tr><td colspan="3" class="text-secondary">Connected successfully; the server returned no tools.</td></tr>'}</tbody></table></div></div>`);
                $('#mcpEndpointName,#mcpEndpointUrl').val('');
                toast(`${result.serverName || 'MCP server'} discovered`);
            } catch (x) {
                toast(x.message, 'danger');
            } finally {
                button.prop('disabled', false).text('Discover server');
            }
        });
        $('#mcpClearResults').on('click', () => {
            $('#mcpDiscoveryResults').empty();
            toast('Discovery results cleared', 'secondary');
        });
        $('#mcpResetPage').on('click', async () => {
            $('#mcpEndpointName,#mcpEndpointUrl').val('');
            await renderMcpDiscovery();
            toast('MCP server page reset', 'secondary');
        });
        await Promise.all(servers.filter(x => x.enabled).map(x => discover(String(x.code))));
    }

    async function renderAdmin() {
        if (!has('SECURITY.MANAGE')) throw new Error('Security management permission is required.');
        header('Administration', 'Manage aging bucket configuration'); loading();
        const users = [], permissions = [], buckets = await api('/api/admin/aging-buckets');
        let userRows = users.map(u => `<tr><td>${esc(u.userName)}</td><td>${esc(u.displayName)}</td><td><span class="badge text-bg-light">${esc(u.roleCode)}</span></td><td>${esc(u.departmentCode)}</td><td>${esc(u.branchCode)}</td><td>${u.isActive ? 'Active' : 'Inactive'}</td><td class="text-end"><button class="btn btn-sm btn-outline-primary edit-user" data-id="${u.id}">Edit</button></td></tr>`).join('');
        let bucketRows = buckets.map(b => `<tr><td>${esc(b.name)}</td><td>${b.fromDays}</td><td>${b.toDays ?? '∞'}</td><td>${b.displayOrder}</td><td class="text-end"><button class="btn btn-sm btn-outline-primary edit-bucket" data-id="${b.id}">Edit</button></td></tr>`).join('');
        $('#viewHost').html(`<div class="card"><div class="card-header bg-white d-flex justify-content-between align-items-center"><span class="fw-semibold">Aging Buckets</span><button id="newBucketBtn" class="btn btn-sm btn-outline-primary">+ Add</button></div><div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Name</th><th>From</th><th>To</th><th>Order</th><th></th></tr></thead><tbody>${bucketRows}</tbody></table></div></div><div id="adminEditor" class="mt-3"></div>`);

        function userEditor(u) { u = u || { id: null, userName: '', displayName: '', roleCode: '', departmentCode: '', branchCode: '', permissions: [], isActive: true }; const checks = permissions.map(p => `<label class="form-check form-check-inline"><input class="form-check-input admin-perm" type="checkbox" value="${esc(p)}" ${(u.permissions || []).includes(p) ? 'checked' : ''}><span class="form-check-label small">${esc(p)}</span></label>`).join(''); $('#adminEditor').html(`<div class="card"><div class="card-header bg-white fw-semibold">${u.id ? 'Edit' : 'Create'} User</div><div class="card-body"><form id="adminUserForm" class="row g-3"><input id="auId" type="hidden" value="${esc(u.id || '')}"><div class="col-md-3"><label class="form-label">User Name</label><input id="auUser" class="form-control" value="${esc(u.userName)}" required></div><div class="col-md-3"><label class="form-label">Display Name</label><input id="auDisplay" class="form-control" value="${esc(u.displayName)}" required></div><div class="col-md-2"><label class="form-label">Role Code</label><input id="auRole" class="form-control" value="${esc(u.roleCode)}" required></div><div class="col-md-2"><label class="form-label">Department</label><input id="auDept" class="form-control" value="${esc(u.departmentCode)}"></div><div class="col-md-2"><label class="form-label">Branch</label><input id="auBranch" class="form-control" value="${esc(u.branchCode)}"></div><div class="col-md-4"><label class="form-label">Password ${u.id ? '<span class="text-secondary">(leave blank to keep)</span>' : ''}</label><input id="auPassword" type="password" class="form-control" ${u.id ? '' : 'required'}></div><div class="col-md-2 d-flex align-items-end"><div class="form-check mb-2"><input id="auActive" class="form-check-input" type="checkbox" ${u.isActive ? 'checked' : ''}><label class="form-check-label">Active</label></div></div><div class="col-12"><label class="form-label">Permissions</label><div>${checks}</div></div><div class="col-12 text-end"><button type="button" id="cancelAdminEdit" class="btn btn-light me-2">Cancel</button><button class="btn btn-primary">Save User</button></div></form></div></div>`); $('#cancelAdminEdit').on('click', () => $('#adminEditor').empty()); $('#adminUserForm').on('submit', async e => { e.preventDefault(); try { const body = { id: $('#auId').val() || null, userName: $('#auUser').val(), displayName: $('#auDisplay').val(), password: $('#auPassword').val() || null, roleCode: $('#auRole').val(), departmentCode: $('#auDept').val(), branchCode: $('#auBranch').val(), permissions: $('.admin-perm:checked').map((_, x) => x.value).get(), isActive: $('#auActive').prop('checked') }; await api('/api/admin/users', { method: 'POST', body }); toast('User saved'); state.roles = []; await loadRoles(true); renderAdmin(); } catch (x) { toast(x.message, 'danger'); } }); }
        function bucketEditor(b) { b = b || { id: null, name: '', fromDays: 0, toDays: null, displayOrder: buckets.length + 1, isActive: true }; $('#adminEditor').html(`<div class="card"><div class="card-header bg-white fw-semibold">${b.id ? 'Edit' : 'Add'} Aging Bucket</div><div class="card-body"><form id="bucketForm" class="row g-3"><input id="abId" type="hidden" value="${esc(b.id || '')}"><div class="col-md-4"><label class="form-label">Name</label><input id="abName" class="form-control" value="${esc(b.name)}" required></div><div class="col-md-2"><label class="form-label">From Days</label><input id="abFrom" type="number" min="0" class="form-control" value="${b.fromDays}" required></div><div class="col-md-2"><label class="form-label">To Days</label><input id="abTo" type="number" min="0" class="form-control" value="${b.toDays ?? ''}" placeholder="No max"></div><div class="col-md-2"><label class="form-label">Order</label><input id="abOrder" type="number" min="1" class="form-control" value="${b.displayOrder}" required></div><div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100">Save</button></div></form></div></div>`); $('#bucketForm').on('submit', async e => { e.preventDefault(); try { await api('/api/admin/aging-buckets', { method: 'POST', body: { id: $('#abId').val() || null, name: $('#abName').val(), fromDays: +$('#abFrom').val(), toDays: $('#abTo').val() === '' ? null : +$('#abTo').val(), displayOrder: +$('#abOrder').val(), isActive: true } }); toast('Aging bucket saved'); renderAdmin(); } catch (x) { toast(x.message, 'danger'); } }); }
        $('#newUserBtn').on('click', () => userEditor(null)); $('.edit-user').on('click', function () { userEditor(users.find(x => x.id === $(this).data('id'))); }); $('#newBucketBtn').on('click', () => bucketEditor(null)); $('.edit-bucket').on('click', function () { bucketEditor(buckets.find(x => x.id === $(this).data('id'))); });

        if (false && has('MCP.MANAGE')) {
            try {
                const servers = await api('/api/mcp/servers');
                const rows = servers.map(x => `<tr><td>${esc(x.name || x.code)}</td><td><code>${esc(x.code)}</code></td><td class="text-break small">${esc(x.endpoint)}</td><td>${x.enabled ? '<span class="badge text-bg-success">Enabled</span>' : '<span class="badge text-bg-secondary">Disabled</span>'}</td><td>${x.approvedToolCount || 0}</td><td class="text-end"><button class="btn btn-sm btn-outline-primary mcp-discover" data-code="${esc(x.code)}">Discover</button></td></tr>`).join('');
                $('#viewHost').append(`<div class="card mt-3"><div class="card-header bg-white d-flex justify-content-between align-items-center"><div><div class="fw-semibold">MCP Server Discovery</div><div class="small text-secondary">Connections are created by the CATS API through the gateway-managed application. Discovered tools are not automatically approved.</div></div></div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Server</th><th>Code</th><th>Endpoint</th><th>Status</th><th>Approved tools</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="text-secondary text-center py-4">No MCP servers are configured in the MCP configuration section.</td></tr>'}</tbody></table></div><div id="mcpDiscoveryResult" class="card-body border-top d-none"></div></div>`);
                $('.mcp-discover').on('click', async function () {
                    const button = $(this), code = String(button.data('code') || '');
                    const original = button.text();
                    try {
                        button.prop('disabled', true).text('Discovering…');
                        const result = await api(`/api/mcp/servers/${encodeURIComponent(code)}/discover`, { method: 'POST' });
                        const tools = (result.tools || []).map(t => `<tr><td><code>${esc(t.name)}</code></td><td>${esc(t.description || '')}</td><td>${t.approvedReadOnly ? '<span class="badge text-bg-success">Approved read-only</span>' : '<span class="badge text-bg-warning">Not approved</span>'}</td></tr>`).join('');
                        $('#mcpDiscoveryResult').removeClass('d-none').html(`<div class="fw-semibold mb-2">${esc(result.serverName || code)} · Discovered tools</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Tool</th><th>Description</th><th>Assistant policy</th></tr></thead><tbody>${tools || '<tr><td colspan="3" class="text-secondary">No tools were returned.</td></tr>'}</tbody></table></div>`);
                    } catch (x) {
                        toast(x.message, 'danger');
                    } finally {
                        button.prop('disabled', false).text(original);
                    }
                });
            } catch (x) {
                $('#viewHost').append(`<div class="alert alert-warning mt-3"><b>MCP discovery:</b> ${esc(x.message)}</div>`);
            }
        }
    }

    async function renderWorkflowDesigner() {
        if (!has('WORKFLOW.MANAGE')) throw new Error('Workflow management permission is required.'); await loadTemplates(true); header('Workflow Designer', 'Dynamic role-driven sequential, conditional and parallel workflow');
        $('#viewHost').html(`<div class="card mb-3"><div class="card-body"><div class="row g-2 align-items-end"><div class="col-md-6"><label class="form-label">Alert Type</label><select id="wfTemplate" class="form-select"><option value="">Select alert type</option>${state.templates.map(t => `<option value="${t.id}">${esc(t.code)}</option>`).join('')}</select></div><div class="col-md-3"><label class="form-label">Workflow Name</label><input id="wfName" class="form-control" value="Dynamic Workflow" /></div><div class="col-md-3 d-grid"><button id="wfLoad" class="btn btn-outline-primary">Load Published Workflow</button></div></div></div></div><div id="wfEditor"></div>`);
        const blank = () => ({ templateId: $('#wfTemplate').val() || '', name: $('#wfName').val() || 'Dynamic Workflow', startStageId: '', stages: [] });
        function draw() { const d = state.workflowDraft; let cards = ''; d.stages.forEach((s, i) => { cards += `<div class="d-flex"><div class="workflow-card ${d.startStageId === s.id ? 'start' : ''}" draggable="true" data-i="${i}"><div class="d-flex justify-content-between"><span class="badge badge-soft stage-type">${esc(s.type)}</span><span class="small text-secondary">${esc(s.roleCode || 'SYSTEM')}</span></div><div class="fw-semibold mt-2">${esc(s.name)}</div><div class="small text-secondary mt-1">${esc((s.allowedActions || []).join(' · ') || 'Automatic')}</div><div class="small mt-2">${(s.transitions || []).map(t => `${esc(t.action)} → ${esc(t.toStageId || 'END')}`).join('<br>')}</div><div class="mt-3 d-flex gap-1"><button class="btn btn-sm btn-outline-primary set-start" data-i="${i}">Start</button><button class="btn btn-sm btn-outline-secondary edit-stage" data-i="${i}">Edit</button><button class="btn btn-sm btn-outline-danger del-stage" data-i="${i}">×</button></div></div>${i < d.stages.length - 1 ? '<div class="workflow-arrow">→</div>' : ''}</div>`; }); $('#wfEditor').html(`<div class="card"><div class="card-header bg-white d-flex flex-wrap justify-content-between gap-2"><span class="fw-semibold">Workflow Canvas</span><div><button id="addStage" class="btn btn-sm btn-outline-primary">+ Add Stage</button> <button id="newWorkflow" class="btn btn-sm btn-outline-secondary">New</button></div></div><div class="card-body"><div class="workflow-lane" id="workflowLane">${cards || '<div class="text-secondary py-4">Add stages to define the workflow. Maker / Checker / Verifier are configurable roles, not fixed stages.</div>'}</div><div class="alert alert-light border small"><strong>Start:</strong> ${esc(d.startStageId || 'not selected')} · Parallel stages support All / Any / Minimum approvals. Conditions and Agent stages route automatically.</div><details class="mb-3"><summary class="pointer">Definition JSON</summary><pre class="bg-light p-3 rounded small mt-2" style="max-height:300px;overflow:auto">${esc(JSON.stringify({ startStageId: d.startStageId, stages: d.stages }, null, 2))}</pre></details><div class="d-flex justify-content-end align-items-center gap-2"><div class="form-check me-2"><input id="wfPublish" class="form-check-input" type="checkbox" checked><label class="form-check-label">Publish</label></div><button id="saveWorkflow" class="btn btn-primary px-4">Save Workflow</button></div></div></div>`); bind(); }
        function bind() { $('#addStage').on('click', () => openStage(-1)); $('#newWorkflow').on('click', () => { state.workflowDraft = blank(); draw(); }); $('.edit-stage').on('click', function () { openStage(+$(this).data('i')); }); $('.del-stage').on('click', function () { const i = +$(this).data('i'), id = state.workflowDraft.stages[i].id; state.workflowDraft.stages.splice(i, 1); if (state.workflowDraft.startStageId === id) state.workflowDraft.startStageId = state.workflowDraft.stages[0]?.id || ''; draw(); }); $('.set-start').on('click', function () { state.workflowDraft.startStageId = state.workflowDraft.stages[+$(this).data('i')].id; draw(); }); $('#saveWorkflow').on('click', save); $('.workflow-card').on('dragstart', function (e) { e.originalEvent.dataTransfer.setData('text/plain', $(this).data('i')); }).on('dragover', e => e.preventDefault()).on('drop', function (e) { e.preventDefault(); const from = +e.originalEvent.dataTransfer.getData('text/plain'), to = +$(this).data('i'); const [item] = state.workflowDraft.stages.splice(from, 1); state.workflowDraft.stages.splice(to, 0, item); draw(); }); }
        function openStage(i) { const s = i >= 0 ? state.workflowDraft.stages[i] : { id: 'stage' + (state.workflowDraft.stages.length + 1), name: 'New Stage', type: 'Human', roleCode: 'DT_USER', allowedActions: ['Submit'], editableFields: ['*'], transitions: [], approvalRule: 'Single', minimumApprovals: 1, approvers: [], slaHours: 24, conditions: [], defaultNextStageId: null, agentInstructions: null, agentPromptTemplate: null, agentFallbackAction: null, endStatus: null }; $('#stageEditIndex').val(i); $('#stageId').val(s.id); $('#stageName').val(s.name); $('#stageType').val(s.type); $('#stageRole').val(s.roleCode || ''); $('#stageActions').val((s.allowedActions || []).join(',')); $('#stageEditableFields').val((s.editableFields || []).join(',')); $('#stageSla').val(s.slaHours || 24); $('#stageTransitions').val((s.transitions || []).map(t => `${t.action}:${t.toStageId || 'END'}`).join('\n')); $('#stageApprovers').val((s.approvers || []).map(a => a.roleCode).join(',')); $('#stageApprovalRule').val(s.approvalRule || 'All'); $('#stageMin').val(s.minimumApprovals || 1); $('#stageConditions').val(JSON.stringify(s.conditions || [], null, 2)); $('#stageDefaultNext').val(s.defaultNextStageId || ''); $('#stageEndStatus').val(s.endStatus || ''); $('#stageAgentPrompt').val(s.agentPromptTemplate || s.agentInstructions || ''); $('#stageAgentFallback').val(s.agentFallbackAction || ''); bootstrap.Modal.getOrCreateInstance('#stageModal').show(); }
        $('#saveStageBtn').off('click').on('click', () => { try { const i = +$('#stageEditIndex').val(), old = i >= 0 ? state.workflowDraft.stages[i] : null; const transitions = $('#stageTransitions').val().split(/\r?\n/).map(x => x.trim()).filter(Boolean).map(x => { const p = x.split(':'); return { action: p[0].trim(), toStageId: (p.slice(1).join(':').trim().toUpperCase() === 'END' || !p.slice(1).join(':').trim()) ? null : p.slice(1).join(':').trim(), resultStatus: null }; }); const conditions = json($('#stageConditions').val() || '[]', null); if (!conditions) throw new Error('Conditions JSON is invalid.'); const s = { id: $('#stageId').val().trim(), name: $('#stageName').val().trim(), type: $('#stageType').val(), roleCode: $('#stageRole').val(), allowedActions: $('#stageActions').val().split(',').map(x => x.trim()).filter(Boolean), editableFields: $('#stageEditableFields').val().split(',').map(x => x.trim()).filter(Boolean), transitions, approvalRule: $('#stageApprovalRule').val(), minimumApprovals: +$('#stageMin').val() || 1, approvers: $('#stageApprovers').val().split(',').map(x => x.trim()).filter(Boolean).map(x => ({ roleCode: x, label: x })), slaHours: +$('#stageSla').val() || 24, conditions, defaultNextStageId: $('#stageDefaultNext').val().trim() || null, agentInstructions: $('#stageAgentPrompt').val().trim() || null, agentPromptTemplate: $('#stageAgentPrompt').val().trim() || null, agentFallbackAction: $('#stageAgentFallback').val().trim() || null, endStatus: $('#stageEndStatus').val().trim() || null }; if (!s.id || !s.name) throw new Error('Stage ID and name are required.'); if (state.workflowDraft.stages.some((x, j) => j !== i && x.id.toLowerCase() === s.id.toLowerCase())) throw new Error('Stage ID must be unique.'); if (i >= 0) state.workflowDraft.stages[i] = s; else state.workflowDraft.stages.push(s); if (!state.workflowDraft.startStageId || state.workflowDraft.startStageId === old?.id) state.workflowDraft.startStageId = s.id; bootstrap.Modal.getOrCreateInstance('#stageModal').hide(); draw(); } catch (x) { toast(x.message, 'danger'); } });
        async function save() { try { state.workflowDraft.templateId = $('#wfTemplate').val() || state.workflowDraft.templateId; state.workflowDraft.name = $('#wfName').val() || state.workflowDraft.name; if (!state.workflowDraft.templateId) throw new Error('Select a template.'); if (!state.workflowDraft.startStageId) throw new Error('Select a start stage.'); const req = { templateId: state.workflowDraft.templateId, name: state.workflowDraft.name, definition: { startStageId: state.workflowDraft.startStageId, stages: state.workflowDraft.stages }, publish: $('#wfPublish').prop('checked') }; const r = await api('/api/templates/workflow', { method: 'POST', body: req }); toast(`Workflow v${r.version} saved${r.isPublished ? ' and published' : ''}`); await loadTemplates(true); } catch (x) { toast(x.message, 'danger'); } }
        $('#wfLoad').on('click', async () => { const tid = $('#wfTemplate').val(); if (!tid) { toast('Select a template', 'warning'); return; } try { const x = await api(`/api/templates/${tid}/workflow`); state.workflowDraft = { templateId: tid, name: x.record.name, startStageId: x.definition.startStageId, stages: x.definition.stages || [] }; $('#wfName').val(state.workflowDraft.name); draw(); } catch (e) { state.workflowDraft = blank(); state.workflowDraft.templateId = tid; draw(); toast('No published workflow found. Start a new one.', 'secondary'); } }); state.workflowDraft = blank(); draw();
    }

    $('#aiSuggestQueryBtn').on('click', async () => {
        const a = state.pendingAction;
        if (!a || !a.aiQueryEnabled) return;
        const btn = $('#aiSuggestQueryBtn');
        try {
            btn.prop('disabled', true).text('Generating…');
            $('#aiQueryStatus').removeClass('text-danger text-success').addClass('text-secondary').text('Preparing a draft from the authorised alert context…');
            const result = await api(`/api/alerts/${a.id}/ai-query-suggestion`, { method: 'POST', body: { instruction: $('#aiQueryInstruction').val() || null } });
            $('#actionRemarks').val(result.queryText || '');
            $('#aiQueryStatus').removeClass('text-secondary text-danger').addClass('text-success').text(`Draft generated${result.model ? ` using ${result.model}` : ''}. Review/edit before confirming.`);
        } catch (x) {
            $('#aiQueryStatus').removeClass('text-secondary text-success').addClass('text-danger').text(x.message || 'AI Query suggestion failed. You can continue typing the query manually.');
        } finally { btn.prop('disabled', false).text('✨ Suggest Query'); }
    });

    $('#confirmActionBtn').on('click', async () => { if (!state.pendingAction) return; const a = state.pendingAction; try { await api(`/api/alerts/${a.id}/action`, { method: 'POST', body: { action: a.action, remarks: $('#actionRemarks').val(), data: a.collect ? a.collect() : {} } }); bootstrap.Modal.getOrCreateInstance('#actionModal').hide(); toast(`${a.action} completed`); state.pendingAction = null; renderDetail(a.id); } catch (x) { toast(x.message, 'danger'); } });
    $('.theme-option').on('click', function () { applyTheme($(this).data('theme')); });
    const handleSystemThemeChange = () => { if (getThemePreference() === 'system') applyTheme('system', false); };
    if (themeMedia.addEventListener) themeMedia.addEventListener('change', handleSystemThemeChange); else themeMedia.addListener(handleSystemThemeChange);
    applyTheme(getThemePreference(), false);

    $('#toggleLoginPassword').on('click', () => setPasswordVisibility($('#loginPassword').attr('type') === 'password'));
    $('#loginUser, #loginPassword').on('input', () => setLoginStatus());
    $('#loginForm').on('submit', async e => {
        e.preventDefault();
        setLoginStatus();
        setLoginBusy(true);
        try {
            const r = await api('/api/auth/login', { method: 'POST', body: { userName: $('#loginUser').val(), password: $('#loginPassword').val() } });
            state.token = r.token;
            state.user = r.user;
            sessionStorage.setItem('cats_token', state.token);
            sessionStorage.setItem('cats_user', JSON.stringify(state.user));
            $('#loginPassword').val('');
            setPasswordVisibility(false);
            showApp();
            await Promise.all([loadTemplates(true), loadRoles(true)]);
            await navigate('dashboard');
        } catch (x) {
            setLoginStatus(x.message);
            toast(x.message, 'danger');
        } finally {
            setLoginBusy(false);
        }
    });
    $('#logoutBtn').on('click', () => signOut());
    $('#switchAccountBtn').on('click', async () => { $('#loginUser, #loginPassword').val(''); await signOut(); });
    $('#sidebarToggle').on('click', () => { if (window.innerWidth < 768) $('#sidebar').toggleClass('mobile-open'); else $('body').toggleClass('sidebar-collapsed'); });
    $('.sidebar .nav-link').on('click', function () { navigate($(this).data('view')); });

    (async () => { if (state.token && state.user) { showApp(); try { await Promise.all([loadTemplates(), loadRoles()]); await navigate('dashboard'); } catch { logout(false); } } else showLogin(); })();

    // Kept for reference while older deployments are upgraded to the current ingestion designer.
    async function renderPlatformIngestionLegacyV2() {
        const [d,configs] = await Promise.all([api('/api/platform/ingestion/dashboard'),api('/api/platform/ingestion/configurations')]);
        header('Ingestion Configuration & Logs', 'Configure here; CATS.Ingestion.Worker or Windows Task Scheduler executes active schedules');
        $('#viewHost').html(`<div class="row g-3 mb-3"><div class="col-md-3"><div class="card p-3"><small>Active Configurations</small><h3>${d.activeConfigurations}</h3></div></div><div class="col-md-3"><div class="card p-3"><small>Runs Today</small><h3>${d.runsToday}</h3></div></div><div class="col-md-3"><div class="card p-3"><small>Successful</small><h3>${d.successfulToday}</h3></div></div><div class="col-md-3"><div class="card p-3"><small>Failed</small><h3>${d.failedToday}</h3></div></div></div><div class="card"><div class="card-header bg-white fw-semibold">Recent Runs</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Source</th><th>Started</th><th>Read</th><th>Inserted</th><th>Duplicate</th><th>Failed</th><th>Status</th></tr></thead><tbody>${(d.recentRuns || []).map(x => `<tr><td>${esc(x.sourceReference)}</td><td>${esc(x.startedAtUtc)}</td><td>${x.rowsRead}</td><td>${x.rowsInserted}</td><td>${x.rowsDuplicate}</td><td>${x.rowsFailed}</td><td>${esc(x.status)}</td></tr>`).join('')}</tbody></table></div></div>`);
        const templateOptions=state.templates.map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('');
        $('#viewHost').prepend(`<div class="card mb-3"><div class="card-header">Add ingestion option</div><div class="card-body"><form id="ingestionForm" class="row g-2"><div class="col-md-3"><input id="icName" class="form-control" placeholder="Configuration name" required></div><div class="col-md-2"><select id="icType" class="form-select"><option>MANUAL_CSV</option><option>SINGLE_ENTRY</option><option>SHARED_FOLDER</option><option>SFTP</option><option>FC_QUERY</option></select></div><div class="col-md-3"><select id="icTemplate" class="form-select" required><option value="">Template</option>${templateOptions}</select></div><div class="col-md-2"><input id="icCron" class="form-control" value="*/15 * * * *"></div><div class="col-md-2"><input id="icMinutes" type="number" min="1" value="15" class="form-control"></div><div class="col-12"><button class="btn btn-primary">Save configuration</button></div></form><small class="text-secondary">Sample scheduler: every 15 minutes. Task Scheduler command: CATS.Ingestion.Worker.exe</small></div></div><div class="card mb-3"><div class="card-header">Configured schedules</div><div class="card-body">${configs.map(x=>`<div><b>${esc(x.name)}</b> · ${esc(x.sourceType)} · ${esc(x.scheduleCron)} · ${x.intervalMinutes} minutes · ${x.isActive?'Active':'Disabled'}</div>`).join('')||'No configurations.'}</div></div>`);
        $('#ingestionForm').on('submit',async e=>{e.preventDefault();await api('/api/platform/ingestion/configurations',{method:'POST',body:{name:$('#icName').val(),templateId:$('#icTemplate').val(),sourceType:$('#icType').val(),filePattern:'*.csv',scheduleCron:$('#icCron').val(),intervalMinutes:Number($('#icMinutes').val()),fieldMappingJson:'{}',duplicateKeyFields:'',queryText:'',archivePath:'C:\\CATS\\archive',errorPath:'C:\\CATS\\error',isActive:true}});toast('Ingestion configuration saved.','success');renderPlatformIngestion();});
    }
    async function renderPlatformReports() {
        await loadTemplates(); header('Reports', 'MIS, Alert Wise and All Alert reports');
        $('#viewHost').html(`<div class="card"><div class="card-body"><form id="reportForm" class="row g-2 mb-3"><div class="col-md-2"><select id="reportType" class="form-select"><option>MIS</option><option>ALERTWISE</option><option>ALL</option></select></div><div class="col-md-2"><select id="rfType" class="form-select">${state.templates.filter(t=>t.status==='Published').map(t=>`<option value="${esc(t.code)}">${esc(t.code)}</option>`).join('')}</select></div><div class="col-md-2"><input id="rfStatus" class="form-control" placeholder="Status"></div><div class="col-md-2"><input id="rfFrom" type="date" class="form-control"></div><div class="col-md-2"><input id="rfTo" type="date" class="form-control"></div><div class="col-md-2"><button class="btn btn-primary">Apply</button> <button id="reportCsv" type="button" class="btn btn-success">CSV</button></div></form><div id="reportHost"></div></div></div>`);
        const query=()=>new URLSearchParams({page:1,pageSize:200,alertType:$('#rfType').val(),status:$('#rfStatus').val(),fromDate:$('#rfFrom').val(),toDate:$('#rfTo').val()}).toString();
        $('#reportForm').on('submit',async e=>{e.preventDefault();const r=await api('/api/platform/reports/'+$('#reportType').val()+'?'+query());const rows=r.data||[];if(!rows.length){$('#reportHost').html('<span class="text-secondary">No matching records.</span>');return;}const keys=Object.keys(rows[0].values).filter(k=>!/^template(name|id)?$/i.test(k));$('#reportHost').html(`<div class="mb-2">${r.totalRecords} record(s)</div><div class="table-responsive"><table class="table table-sm"><thead><tr>${keys.map(k=>`<th>${esc(k)}</th>`).join('')}</tr></thead><tbody>${rows.map(x=>`<tr>${keys.map(k=>`<td>${esc(x.values[k]??'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);});
        $('#reportCsv').on('click',async()=>{const response=await fetch(apiUrl('/api/platform/reports/'+$('#reportType').val()+'/export?'+query()),{headers:{Authorization:`Bearer ${state.token}`}});if(!response.ok)throw new Error('CSV export failed.');const blob=await response.blob(),link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download=`CATS-${$('#reportType').val()}.csv`;link.click();URL.revokeObjectURL(link.href);});
    }
    async function renderPlatformMail() { const [cfg, tpl] = await Promise.all([api('/api/platform/mail/configurations'), api('/api/platform/mail/templates')]); header('Mail Configuration', 'Deterministic mail delivery with optional MAF content enrichment'); $('#viewHost').html(`<div class="row g-3"><div class="col-lg-6"><div class="card"><div class="card-header bg-white fw-semibold">Mail Providers</div><div class="card-body">${cfg.map(x => `<div class="border rounded p-2 mb-2"><b>${esc(x.name)}</b><div class="small text-secondary">${esc(x.providerType)} · ${esc(x.host)}:${x.port} · ${esc(x.fromAddress)}</div></div>`).join('') || '<span class="text-secondary">No configuration.</span>'}</div></div></div><div class="col-lg-6"><div class="card"><div class="card-header bg-white fw-semibold">Mail Templates</div><div class="card-body">${tpl.map(x => `<div class="border rounded p-2 mb-2"><b>${esc(x.eventCode)}</b><div class="small">${esc(x.subjectTemplate)}</div><div class="small text-secondary">MAF enrichment: ${x.useMafEnrichment ? 'Yes' : 'No'}</div></div>`).join('') || '<span class="text-secondary">No templates.</span>'}</div></div></div></div>`); }
    async function renderPlatformMail() {
        const [cfg,tpl,logs]=await Promise.all([api('/api/platform/mail/configurations'),api('/api/platform/mail/templates'),api('/api/platform/mail/logs?take=50')]);
        header('Mail Configuration & Logs','Manage SMTP settings, templates and delivery history in this portal');
        const mailTemplateOptions=state.templates.map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('');
        $('#viewHost').html(`<div class="row g-3 mb-3"><div class="col-lg-6"><div class="card"><div class="card-header">SMTP provider</div><div class="card-body"><form id="mailProviderForm" class="row g-2"><input id="mcName" class="form-control" placeholder="Provider name" required><input id="mcHost" class="form-control" placeholder="smtp.example.com" required><input id="mcPort" type="number" value="587" class="form-control"><input id="mcFrom" type="email" class="form-control" placeholder="cats@example.com" required><input id="mcUser" class="form-control" placeholder="User name"><input id="mcSecret" type="password" class="form-control" placeholder="Password / secret"><button class="btn btn-primary">Save provider</button></form></div></div></div><div class="col-lg-6"><div class="card"><div class="card-header">Mail template based on alert template</div><div class="card-body"><form id="mailTplForm" class="row g-2"><select id="mtTemplate" class="form-select" required><option value="">Select alert template</option>${mailTemplateOptions}</select><select id="mtEvent" class="form-select"><option>ALERT_CREATED</option><option>STAGE_ASSIGNED</option><option>QUERY_RAISED</option><option>ALERT_CLOSED</option></select><input id="mtSubject" value="CATS alert {{AlertNo}} created" class="form-control"><textarea id="mtBody" rows="4" class="form-control"><p>Hello {{DisplayName}},</p><p>Alert {{AlertNo}} has status {{Status}}.</p></textarea><button class="btn btn-primary">Save template</button></form></div></div></div></div><div class="card mb-3"><div class="card-header">Configured providers and templates</div><div class="card-body">${cfg.map(x=>`<div><b>${esc(x.name)}</b> · ${esc(x.host)}:${x.port} · ${esc(x.fromAddress)}</div>`).join('')}<hr>${tpl.map(x=>`<div><b>${esc(state.templates.find(t=>t.id===x.templateId)?.name||'All templates')}</b> · ${esc(x.eventCode)} · ${esc(x.subjectTemplate)}</div>`).join('')}</div></div><div class="card"><div class="card-header">Mail delivery logs</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Created</th><th>Event</th><th>Recipient</th><th>Status</th><th>Attempts</th><th>Error</th></tr></thead><tbody>${logs.map(x=>`<tr><td>${esc(x.createdAtUtc)}</td><td>${esc(x.eventCode)}</td><td>${esc(x.toAddress)}</td><td>${esc(x.status)}</td><td>${x.attempts}</td><td>${esc(x.errorMessage||'')}</td></tr>`).join('')}</tbody></table></div></div>`);
        $('#mailProviderForm').on('submit',async e=>{e.preventDefault();await api('/api/platform/mail/configurations',{method:'POST',body:{name:$('#mcName').val(),providerType:'SMTP',host:$('#mcHost').val(),port:Number($('#mcPort').val()),userName:$('#mcUser').val(),secretEncrypted:$('#mcSecret').val(),fromAddress:$('#mcFrom').val(),useSsl:true,isActive:true}});toast('Mail provider saved.','success');renderPlatformMail();});
        $('#mailTplForm').on('submit',async e=>{e.preventDefault();await api('/api/platform/mail/templates',{method:'POST',body:{templateId:$('#mtTemplate').val(),eventCode:$('#mtEvent').val(),subjectTemplate:$('#mtSubject').val(),bodyTemplate:$('#mtBody').val(),useMafEnrichment:false,isActive:true}});toast('Template-based mail saved.','success');renderPlatformMail();});
    }
    async function renderPlatformIngestionLegacyV8() {
        const [dashboard,configs]=await Promise.all([api('/api/platform/ingestion/dashboard'),api('/api/platform/ingestion/configurations')]);
        $('#ingestionAddModal').remove(); $('.modal-backdrop').remove(); $('body').removeClass('modal-open').css('padding-right','');
        header('Ingestion Configuration & Logs','Configuration records and execution logs are available as separate pages in this section');
        const templates=state.templates.map(x=>`<option value="${esc(x.id)}">${esc(x.code)}</option>`).join('');
        const records=configs.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.sourceType)}</td><td>${esc(state.templates.find(t=>t.id===x.templateId)?.code||'')}</td><td>${esc(x.scheduleCron)}</td><td>${x.intervalMinutes} min</td><td>${x.isActive?'Active':'Disabled'}</td></tr>`).join('');
        const logs=(dashboard.recentRuns||[]).map(x=>`<tr><td>${esc(x.sourceReference)}</td><td>${esc(x.startedAtUtc)}</td><td>${x.rowsRead}</td><td>${x.rowsInserted}</td><td>${x.rowsDuplicate}</td><td>${x.rowsFailed}</td><td>${esc(x.status)}</td></tr>`).join('');
        $('#viewHost').html(`<div class="row g-3 mb-3"><div class="col-md-3"><div class="card p-3"><small>Active Configurations</small><h3>${dashboard.activeConfigurations}</h3></div></div><div class="col-md-3"><div class="card p-3"><small>Runs Today</small><h3>${dashboard.runsToday}</h3></div></div><div class="col-md-3"><div class="card p-3"><small>Successful</small><h3>${dashboard.successfulToday}</h3></div></div><div class="col-md-3"><div class="card p-3"><small>Failed</small><h3>${dashboard.failedToday}</h3></div></div></div><div class="d-flex justify-content-between mb-3"><div class="btn-group"><button id="showIngestionRecords" class="btn btn-primary">Configuration Records</button><button id="showIngestionLogs" class="btn btn-outline-primary">Execution Logs</button></div><button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ingestionAddModal">+ Add Option</button></div><div id="ingestionRecordsPage" class="card"><div class="card-header">List of Records</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Name</th><th>Source</th><th>Template</th><th>Schedule</th><th>Repeat</th><th>Status</th></tr></thead><tbody>${records}</tbody></table></div></div><div id="ingestionLogsPage" class="card d-none"><div class="card-header">Execution Logs</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Source</th><th>Started</th><th>Read</th><th>Inserted</th><th>Duplicate</th><th>Failed</th><th>Status</th></tr></thead><tbody>${logs}</tbody></table></div></div><div class="modal fade" id="ingestionAddModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><div><h5 class="modal-title">Add Ingestion Option</h5><div class="small text-secondary">Choose where data comes from and when it should run.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><form id="ingestionForm"><div class="modal-body"><div class="row g-3"><div class="col-md-6"><label class="form-label">Configuration name</label><input id="icName" class="form-control" placeholder="Example: Daily branch CSV" required><div class="form-text">A simple name your team will recognize.</div></div><div class="col-md-6"><label class="form-label">Where does the data come from?</label><select id="icType" class="form-select"><option value="MANUAL_CSV">CSV uploaded by a user</option><option value="SINGLE_ENTRY">Single record entered in portal</option><option value="SHARED_FOLDER">CSV files in a shared folder</option><option value="SFTP">Files downloaded from SFTP</option><option value="FC_QUERY">Records returned by a database query</option></select></div><div class="col-md-6"><label class="form-label">Create alerts using template</label><select id="icTemplate" class="form-select" required><option value="">Select template</option>${templates}</select></div><div class="col-md-6"><label class="form-label">How often should it run?</label><select id="icFrequency" class="form-select"><option value="ONCE">One time</option><option value="DAILY" selected>Daily</option><option value="WEEKLY">Weekly</option><option value="MONTHLY">Monthly</option></select></div><div class="col-md-6"><label class="form-label">Start date</label><input id="icStartDate" type="date" class="form-control" required></div><div class="col-md-6"><label class="form-label">Start time</label><input id="icStartTime" type="time" class="form-control" value="09:00" required></div><div id="icWeekdayGroup" class="col-md-6 d-none"><label class="form-label">Day of week</label><select id="icWeekday" class="form-select"><option value="1">Monday</option><option value="2">Tuesday</option><option value="3">Wednesday</option><option value="4">Thursday</option><option value="5">Friday</option><option value="6">Saturday</option><option value="0">Sunday</option></select></div><div id="icMonthdayGroup" class="col-md-6 d-none"><label class="form-label">Day of month</label><input id="icMonthday" type="number" min="1" max="31" value="1" class="form-control"></div><div class="col-md-6"><label class="form-label">Check for new data every</label><select id="icMinutes" class="form-select"><option value="5">5 minutes</option><option value="15" selected>15 minutes</option><option value="30">30 minutes</option><option value="60">1 hour</option></select><div class="form-text">Used by automatic folder, SFTP and query imports.</div></div><div class="col-md-6 d-flex align-items-end"><div class="form-check form-switch mb-2"><input id="icEnabled" class="form-check-input" type="checkbox" checked><label class="form-check-label" for="icEnabled">Enabled and ready to run</label></div></div></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Option</button></div></form></div></div></div>`);
        $('#ingestionAddModal').appendTo(document.body);
        $('#ingestionRecordsPage th').filter(function(){return $(this).text().trim()==='Template';}).text('Alert Type');
        $('#ingestionAddModal label').filter(function(){return $(this).text().trim()==='Create alerts using template';}).text('Alert Type');
        $('#icTemplate option:first').text('Select alert type');
        const showPage=showLogs=>{$('#ingestionRecordsPage').toggleClass('d-none',showLogs);$('#ingestionLogsPage').toggleClass('d-none',!showLogs);$('#showIngestionRecords').toggleClass('btn-primary',!showLogs).toggleClass('btn-outline-primary',showLogs);$('#showIngestionLogs').toggleClass('btn-primary',showLogs).toggleClass('btn-outline-primary',!showLogs);};
        $('#showIngestionRecords').on('click',()=>showPage(false)); $('#showIngestionLogs').on('click',()=>showPage(true));
        $('#icStartDate').val(new Date().toISOString().slice(0,10));
        $('#icFrequency').on('change',function(){const value=$(this).val();$('#icWeekdayGroup').toggleClass('d-none',value!=='WEEKLY');$('#icMonthdayGroup').toggleClass('d-none',value!=='MONTHLY');});
        $('#ingestionForm').on('submit',async e=>{e.preventDefault();const frequency=$('#icFrequency').val(),time=$('#icStartTime').val().split(':'),minute=Number(time[1]),hour=Number(time[0]),date=$('#icStartDate').val();let schedule=frequency==='ONCE'?`ONCE:${date}T${$('#icStartTime').val()}`:frequency==='WEEKLY'?`${minute} ${hour} * * ${$('#icWeekday').val()}`:frequency==='MONTHLY'?`${minute} ${hour} ${$('#icMonthday').val()} * *`:`${minute} ${hour} * * *`;await api('/api/platform/ingestion/configurations',{method:'POST',body:{name:$('#icName').val(),templateId:$('#icTemplate').val(),sourceType:$('#icType').val(),filePattern:'*.csv',scheduleCron:schedule,intervalMinutes:Number($('#icMinutes').val()),fieldMappingJson:'{}',duplicateKeyFields:'',queryText:'',archivePath:'C:\\CATS\\archive',errorPath:'C:\\CATS\\error',isActive:$('#icEnabled').is(':checked')}});bootstrap.Modal.getInstance(document.getElementById('ingestionAddModal'))?.hide();toast('Ingestion option saved.','success');renderPlatformIngestion();});
    }
    async function renderPlatformIngestion() {
        const [dashboard, configs] = await Promise.all([
            api('/api/platform/ingestion/dashboard'),
            api('/api/platform/ingestion/configurations')
        ]);
        $('#ingestionAddModal').remove();
        $('.modal-backdrop').remove();
        $('body').removeClass('modal-open').css('padding-right', '');
        header('Ingestion Tasks & Logs', 'Create one task with one or more simple schedule triggers');

        const sourceLabel = sourceType => sourceType === 'SFTP' ? 'File Download from SFTP' : sourceType === 'QUERY' || sourceType === 'FC_QUERY' ? 'Records returned by Query' : sourceType;
        const triggerList = config => {
            const parsed = json(config.scheduleTriggersJson, []);
            return Array.isArray(parsed) ? parsed : [];
        };
        const weekdayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const triggerSummary = trigger => {
            const frequency = String(trigger.frequency || '').toUpperCase();
            const time = trigger.startTime || '';
            if (frequency === 'ONCE') return `Once on ${trigger.startDate || ''} at ${time}`;
            if (frequency === 'WEEKLY') return `Weekly on ${weekdayNames[Number(trigger.dayOfWeek)] || 'selected day'} at ${time}`;
            if (frequency === 'MONTHLY') return `Monthly on day ${trigger.dayOfMonth || 1} at ${time}`;
            return `Daily at ${time}`;
        };
        const records = configs.map(config => {
            const triggers = triggerList(config);
            const schedules = triggers.length
                ? triggers.map(trigger => `<div class="small">${esc(triggerSummary(trigger))}</div>`).join('')
                : `<div class="small">${esc(config.scheduleCron || 'No trigger')}</div>`;
            const detail = config.sourceType === 'SFTP'
                ? `<div class="small text-secondary">${esc(config.filePath || '')}${config.filePath && config.fileName ? ' / ' : ''}${esc(config.fileName || config.filePattern || '')}</div>`
                : `<div class="small text-secondary text-truncate" style="max-width:320px" title="${esc(config.queryText || '')}">${esc(config.queryText || '')}</div>`;
            return `<tr><td><div class="fw-semibold">${esc(config.name)}</div></td><td>${esc(sourceLabel(config.sourceType))}${detail}</td><td>${esc(state.templates.find(template => template.id === config.templateId)?.code || '')}</td><td><span class="badge text-bg-light mb-1">${triggers.length || 1} trigger${(triggers.length || 1) === 1 ? '' : 's'}</span>${schedules}</td><td>${config.isActive ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Disabled</span>'}</td></tr>`;
        }).join('');
        const logs = (dashboard.recentRuns || []).map(run => `<tr><td>${esc(run.sourceReference)}</td><td>${esc(run.startedAtUtc)}</td><td>${run.rowsRead}</td><td>${run.rowsInserted}</td><td>${run.rowsDuplicate}</td><td>${run.rowsFailed}</td><td>${esc(run.status)}</td></tr>`).join('');
        const templates = state.templates.map(template => `<option value="${esc(template.id)}">${esc(template.code)}</option>`).join('');

        $('#viewHost').html(`
            <div class="row g-3 mb-3">
              <div class="col-md-3"><div class="card p-3"><small>Active Tasks</small><h3>${dashboard.activeConfigurations}</h3></div></div>
              <div class="col-md-3"><div class="card p-3"><small>Runs Today</small><h3>${dashboard.runsToday}</h3></div></div>
              <div class="col-md-3"><div class="card p-3"><small>Successful</small><h3>${dashboard.successfulToday}</h3></div></div>
              <div class="col-md-3"><div class="card p-3"><small>Failed</small><h3>${dashboard.failedToday}</h3></div></div>
            </div>
            <div class="d-flex justify-content-between mb-3">
              <div class="btn-group"><button id="showIngestionRecords" class="btn btn-primary">Tasks</button><button id="showIngestionLogs" class="btn btn-outline-primary">Execution Logs</button></div>
              <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ingestionAddModal">+ Add Ingestion Option</button>
            </div>
            <div id="ingestionRecordsPage" class="card"><div class="card-header bg-white fw-semibold">Task Scheduler</div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Task</th><th>Data Source</th><th>Alert Type</th><th>Triggers</th><th>Status</th></tr></thead><tbody>${records || '<tr><td colspan="5" class="text-center text-secondary py-4">No ingestion tasks configured.</td></tr>'}</tbody></table></div></div>
            <div id="ingestionLogsPage" class="card d-none"><div class="card-header bg-white fw-semibold">Execution Logs</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Source</th><th>Started</th><th>Read</th><th>Inserted</th><th>Duplicate</th><th>Failed</th><th>Status</th></tr></thead><tbody>${logs || '<tr><td colspan="7" class="text-center text-secondary py-4">No execution logs.</td></tr>'}</tbody></table></div></div>
            <div class="modal fade" id="ingestionAddModal" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-centered"><div class="modal-content">
              <div class="modal-header"><div><h5 class="modal-title">Add Ingestion Option</h5><div class="small text-secondary">Configure the source and add multiple triggers to this task.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
              <form id="ingestionForm"><div class="modal-body"><div class="row g-3">
                <div class="col-md-4"><label class="form-label" for="icName">Task name</label><input id="icName" class="form-control" maxlength="150" placeholder="Example: Daily branch alerts" required></div>
                <div class="col-md-4"><label class="form-label" for="icType">Where does the data come from?</label><select id="icType" class="form-select"><option value="SFTP">File Download from SFTP</option><option value="QUERY">Records returned by Query</option></select></div>
                <div class="col-md-4"><label class="form-label" for="icTemplate">Alert Type</label><select id="icTemplate" class="form-select" required><option value="">Select alert type</option>${templates}</select></div>
                <div class="col-12"><div class="ingestion-source-panel">
                  <div id="icSftpFields" class="row g-3"><div class="col-md-7"><label class="form-label" for="icFilePath">File Path</label><input id="icFilePath" class="form-control" maxlength="500" placeholder="/incoming/alerts" required></div><div class="col-md-5"><label class="form-label" for="icFileName">File Name</label><input id="icFileName" class="form-control" maxlength="260" placeholder="alerts.csv" required></div></div>
                  <div id="icQueryFields" class="d-none"><label class="form-label" for="icQuery">Query</label><textarea id="icQuery" class="form-control font-monospace" rows="5" placeholder="SELECT ..."></textarea></div>
                </div></div>
                <div class="col-12"><div class="ingestion-scheduler-panel">
                  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><div><div class="fw-semibold">Task Scheduler</div><div class="small text-secondary">All triggers below belong to this one ingestion task.</div></div><button id="icAddTrigger" type="button" class="btn btn-sm btn-outline-primary">+ Add Trigger</button></div>
                  <div id="icTriggers" class="d-grid gap-2"></div>
                </div></div>
                <div class="col-12"><div class="form-check form-switch"><input id="icEnabled" class="form-check-input" type="checkbox" checked><label class="form-check-label" for="icEnabled">Enabled and ready to run</label></div></div>
              </div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Task</button></div></form>
            </div></div></div>`);
        $('#ingestionAddModal').appendTo(document.body);

        const showPage = showLogs => {
            $('#ingestionRecordsPage').toggleClass('d-none', showLogs);
            $('#ingestionLogsPage').toggleClass('d-none', !showLogs);
            $('#showIngestionRecords').toggleClass('btn-primary', !showLogs).toggleClass('btn-outline-primary', showLogs);
            $('#showIngestionLogs').toggleClass('btn-primary', showLogs).toggleClass('btn-outline-primary', !showLogs);
        };
        $('#showIngestionRecords').on('click', () => showPage(false));
        $('#showIngestionLogs').on('click', () => showPage(true));

        const today = (() => { const date = new Date(); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; })();
        const renumberTriggers = () => $('.ingestion-trigger').each(function (index) { $(this).find('.ingestion-trigger-title').text(`Trigger ${index + 1}`); });
        const addTrigger = (values = {}) => {
            if ($('.ingestion-trigger').length >= 20) { toast('A task can contain up to 20 triggers.', 'warning'); return; }
            const id = values.id || uid();
            $('#icTriggers').append(`<div class="ingestion-trigger" data-trigger-id="${esc(id)}"><div class="d-flex justify-content-between align-items-center mb-2"><span class="ingestion-trigger-title fw-semibold"></span><button type="button" class="btn btn-sm btn-link text-danger text-decoration-none ic-remove-trigger">Remove</button></div><div class="row g-2 align-items-end"><div class="col-md-3"><label class="form-label">Repeat</label><select class="form-select ic-trigger-frequency"><option value="ONCE">One time</option><option value="DAILY">Daily</option><option value="WEEKLY">Weekly</option><option value="MONTHLY">Monthly</option></select></div><div class="col-md-3"><label class="form-label">Start date</label><input type="date" class="form-control ic-trigger-date" required></div><div class="col-md-2"><label class="form-label">Time</label><input type="time" class="form-control ic-trigger-time" required></div><div class="col-md-3 ic-trigger-extra"></div><div class="col-md-1"></div></div></div>`);
            const card = $('#icTriggers .ingestion-trigger').last();
            card.find('.ic-trigger-frequency').val(values.frequency || 'DAILY');
            card.find('.ic-trigger-date').val(values.startDate || today);
            card.find('.ic-trigger-time').val(values.startTime || '09:00');
            const updateExtra = () => {
                const frequency = card.find('.ic-trigger-frequency').val();
                const host = card.find('.ic-trigger-extra').empty();
                if (frequency === 'WEEKLY') {
                    host.html(`<label class="form-label">Day of week</label><select class="form-select ic-trigger-weekday">${weekdayNames.map((name, index) => `<option value="${index}">${name}</option>`).join('')}</select>`);
                    host.find('select').val(values.dayOfWeek ?? 1);
                } else if (frequency === 'MONTHLY') {
                    host.html('<label class="form-label">Day of month</label><input type="number" min="1" max="31" value="1" class="form-control ic-trigger-monthday" required>');
                    host.find('input').val(values.dayOfMonth ?? 1);
                }
            };
            card.find('.ic-trigger-frequency').on('change', () => { values = {}; updateExtra(); });
            card.find('.ic-remove-trigger').on('click', () => {
                if ($('.ingestion-trigger').length === 1) { toast('At least one trigger is required.', 'warning'); return; }
                card.remove();
                renumberTriggers();
            });
            updateExtra();
            renumberTriggers();
        };
        $('#icAddTrigger').on('click', () => addTrigger());
        addTrigger();

        const toggleSourceFields = () => {
            const sftp = $('#icType').val() === 'SFTP';
            $('#icSftpFields').toggleClass('d-none', !sftp).find('input').prop('required', sftp);
            $('#icQueryFields').toggleClass('d-none', sftp).find('textarea').prop('required', !sftp);
        };
        $('#icType').on('change', toggleSourceFields);
        toggleSourceFields();

        $('#ingestionForm').on('submit', async event => {
            event.preventDefault();
            try {
                const triggers = $('.ingestion-trigger').map(function () {
                    const card = $(this), frequency = card.find('.ic-trigger-frequency').val();
                    return {
                        id: String(card.data('trigger-id')),
                        frequency,
                        startDate: card.find('.ic-trigger-date').val(),
                        startTime: card.find('.ic-trigger-time').val(),
                        dayOfWeek: frequency === 'WEEKLY' ? Number(card.find('.ic-trigger-weekday').val()) : null,
                        dayOfMonth: frequency === 'MONTHLY' ? Number(card.find('.ic-trigger-monthday').val()) : null,
                        cron: ''
                    };
                }).get();
                const sourceType = $('#icType').val();
                await api('/api/platform/ingestion/configurations', {
                    method: 'POST',
                    body: {
                        name: $('#icName').val(),
                        templateId: $('#icTemplate').val(),
                        sourceType,
                        filePath: sourceType === 'SFTP' ? $('#icFilePath').val() : '',
                        fileName: sourceType === 'SFTP' ? $('#icFileName').val() : '',
                        filePattern: sourceType === 'SFTP' ? $('#icFileName').val() : '',
                        queryText: sourceType === 'QUERY' ? $('#icQuery').val() : '',
                        scheduleTriggersJson: JSON.stringify(triggers),
                        scheduleCron: '',
                        intervalMinutes: 1,
                        fieldMappingJson: '{}',
                        duplicateKeyFields: '',
                        archivePath: '',
                        errorPath: '',
                        isActive: $('#icEnabled').is(':checked')
                    }
                });
                bootstrap.Modal.getInstance(document.getElementById('ingestionAddModal'))?.hide();
                toast('Ingestion task saved.', 'success');
                renderPlatformIngestion();
            } catch (error) { toast(error.message, 'danger'); }
        });
    }

    async function renderPlatformMail() {
        const [providers,templates,logs]=await Promise.all([api('/api/platform/mail/configurations'),api('/api/platform/mail/templates'),api('/api/platform/mail/logs?take=50')]);
        $('#mailProviderModal,#mailTemplateModal').remove(); $('.modal-backdrop').remove(); $('body').removeClass('modal-open').css('padding-right','');
        header('Email Templates & Logs','Configure alert-based email templates here; sending is executed by your external mail system or job worker');
        const alertTemplates=state.templates.map(x=>`<option value="${esc(x.id)}">${esc(x.code)}</option>`).join('');
        $('#viewHost').html(`<div class="alert alert-info"><b>Configuration only:</b> This portal stores mail settings, template content and delivery logs. The external mail service reads active configuration and performs delivery.</div><div class="d-flex gap-2 mb-3"><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#mailProviderModal">+ Add Mail Configuration</button><button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#mailTemplateModal">+ Add Email Template</button></div><div class="card mb-3"><div class="card-header">Mail Configurations</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Name</th><th>Provider</th><th>Server</th><th>From address</th><th>Status</th></tr></thead><tbody>${providers.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.providerType)}</td><td>${esc(x.host)}:${x.port}</td><td>${esc(x.fromAddress)}</td><td>${x.isActive?'Active':'Disabled'}</td></tr>`).join('')}</tbody></table></div></div><div class="card mb-3"><div class="card-header">Email Templates</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Alert Template</th><th>Event</th><th>Subject</th><th>Status</th></tr></thead><tbody>${templates.map(x=>`<tr><td>${esc(state.templates.find(t=>t.id===x.templateId)?.name||'All templates')}</td><td>${esc(x.eventCode)}</td><td>${esc(x.subjectTemplate)}</td><td>${x.isActive?'Active':'Disabled'}</td></tr>`).join('')}</tbody></table></div></div><div class="card"><div class="card-header">External Delivery Logs</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Created</th><th>Event</th><th>Recipient</th><th>Status</th><th>Attempts</th><th>Error</th></tr></thead><tbody>${logs.map(x=>`<tr><td>${esc(x.createdAtUtc)}</td><td>${esc(x.eventCode)}</td><td>${esc(x.toAddress)}</td><td>${esc(x.status)}</td><td>${x.attempts}</td><td>${esc(x.errorMessage||'')}</td></tr>`).join('')}</tbody></table></div></div><div class="modal fade" id="mailProviderModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Add Mail Configuration</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="mailProviderPopupForm"><div class="modal-body"><div class="mb-3"><label class="form-label">Configuration name</label><input id="mcName" class="form-control" placeholder="Example: Corporate SMTP" required></div><div class="row g-3"><div class="col-8"><label class="form-label">Mail server</label><input id="mcHost" class="form-control" placeholder="smtp.example.com" required></div><div class="col-4"><label class="form-label">Port</label><input id="mcPort" type="number" value="587" class="form-control"></div><div class="col-12"><label class="form-label">From address</label><input id="mcFrom" type="email" class="form-control" placeholder="cats@example.com" required></div><div class="col-6"><label class="form-label">User name</label><input id="mcUser" class="form-control"></div><div class="col-6"><label class="form-label">Password / secret</label><input id="mcSecret" type="password" class="form-control"></div></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Configuration</button></div></form></div></div></div><div class="modal fade" id="mailTemplateModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Add Email Template</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="mailTemplatePopupForm"><div class="modal-body"><div class="row g-3"><div class="col-md-6"><label class="form-label">Alert template</label><select id="mtTemplate" class="form-select" required><option value="">Select alert template</option>${alertTemplates}</select></div><div class="col-md-6"><label class="form-label">When should this email be used?</label><select id="mtEvent" class="form-select"><option>ALERT_CREATED</option><option>STAGE_ASSIGNED</option><option>QUERY_RAISED</option><option>ALERT_CLOSED</option></select></div><div class="col-12"><label class="form-label">Email subject</label><input id="mtSubject" class="form-control" value="CATS alert {{AlertNo}} update" required></div><div class="col-12"><label class="form-label">Email body</label><textarea id="mtBody" rows="7" class="form-control"><p>Hello {{DisplayName}},</p><p>Alert {{AlertNo}} has status {{Status}}.</p></textarea><div class="form-text">Available values: {{AlertNo}}, {{DisplayName}}, {{Status}}, {{StageName}}, {{BranchCode}}</div></div></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Email Template</button></div></form></div></div></div>`);
        const emailTemplateCard=$('.card-header').filter(function(){return $(this).text().trim()==='Email Templates';}).closest('.card');
        emailTemplateCard.find('th:first').text('Alert Type');
        templates.forEach((x,index)=>emailTemplateCard.find('tbody tr').eq(index).find('td:first').text(state.templates.find(t=>t.id===x.templateId)?.code||''));
        $('#mailTemplatePopupForm label').filter(function(){return $(this).text().trim()==='Alert template';}).text('Alert Type');
        $('#mtTemplate option:first').text('Select alert type');
        $('#viewHost .alert-info').html('<b>Template management only:</b> This portal stores email templates and delivery logs. Your external mail service performs delivery.');
        $('[data-bs-target="#mailProviderModal"]').remove();
        $('.card-header').filter(function(){return $(this).text().trim()==='Mail Configurations';}).closest('.card').remove();
        $('#mailProviderModal').remove();
        $('#mailTemplateModal').appendTo(document.body);
        $('#mailProviderPopupForm').on('submit',async e=>{e.preventDefault();await api('/api/platform/mail/configurations',{method:'POST',body:{name:$('#mcName').val(),providerType:'SMTP',host:$('#mcHost').val(),port:Number($('#mcPort').val()),userName:$('#mcUser').val(),secretEncrypted:$('#mcSecret').val(),fromAddress:$('#mcFrom').val(),useSsl:true,isActive:true}});bootstrap.Modal.getInstance(document.getElementById('mailProviderModal'))?.hide();toast('Mail configuration saved.','success');renderPlatformMail();});
        $('#mailTemplatePopupForm').on('submit',async e=>{e.preventDefault();await api('/api/platform/mail/templates',{method:'POST',body:{templateId:$('#mtTemplate').val(),eventCode:$('#mtEvent').val(),subjectTemplate:$('#mtSubject').val(),bodyTemplate:$('#mtBody').val(),useMafEnrichment:false,isActive:true}});bootstrap.Modal.getInstance(document.getElementById('mailTemplateModal'))?.hide();toast('Email template saved.','success');renderPlatformMail();});
    }

    $(document).on('click', '.pii-reveal', function (e) {
        e.preventDefault();
        e.stopPropagation();
        state.pendingPii = { alertId: String($(this).data('alert-id')), field: String($(this).data('field')) };
        $('#piiPassword').val('');
        $('#piiUnmaskError').addClass('d-none').text('');
        bootstrap.Modal.getOrCreateInstance('#piiUnmaskModal').show();
        setTimeout(() => $('#piiPassword').trigger('focus'), 200);
    });
    $(document).on('click', '.pii-mask', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const button=$(this), cell=button.closest('[data-pii-value]'), alertId=String(button.data('alert-id')), field=String(button.data('field'));
        button.remove();
        cell.contents().filter((_,node)=>node.nodeType===Node.TEXT_NODE).remove();
        cell.prepend(document.createTextNode(cell.attr('data-masked-value')||''));
        cell.append(piiEye(alertId,field));
    });
    $('#piiUnmaskForm').on('submit', async e => {
        e.preventDefault();
        if (!state.pendingPii) return;
        const pending = state.pendingPii, button = $('#confirmPiiUnmask');
        try {
            button.prop('disabled', true);
            const result = await api(`/api/alerts/${pending.alertId}/unmask-pii`, { method: 'POST', body: { field: pending.field, password: $('#piiPassword').val() } });
            $('[data-pii-value]').filter(function () { return String($(this).data('alert-id')) === pending.alertId && String($(this).data('pii-value')) === result.field; }).each(function () {
                const cell = $(this);
                cell.contents().filter((_, node) => node.nodeType === Node.TEXT_NODE).remove();
                cell.prepend(document.createTextNode(result.value));
                cell.find('.pii-reveal').remove();
                cell.append(piiMaskEye(pending.alertId,result.field));
            });
            state.pendingPii = null;
            $('#piiPassword').val('');
            bootstrap.Modal.getOrCreateInstance('#piiUnmaskModal').hide();
            toast('Sensitive value revealed.');
        } catch (x) {
            $('#piiPassword').val('').trigger('focus');
            $('#piiUnmaskError').removeClass('d-none').text(x.message);
        } finally {
            button.prop('disabled', false);
        }
    });
    $('#stageModal').on('show.bs.modal', () => {
        const index=Number($('#stageEditIndex').val()), stage=index>=0?state.workflowDraft.stages[index]:null;
        $('#stageAttachmentUploadRoles').val((stage?.attachmentUploadRoles||[]).join(','));
        $('#stageAttachmentViewRoles').val((stage?.attachmentViewRoles||[]).join(','));
    });
    $(document).on('click', '#saveStageBtn', () => setTimeout(() => {
        const id=$('#stageId').val().trim(), stage=state.workflowDraft.stages.find(x=>x.id===id);
        if(!stage) return;
        const roles=selector=>$(selector).val().split(',').map(x=>x.trim().toUpperCase()).filter(Boolean);
        stage.attachmentUploadRoles=roles('#stageAttachmentUploadRoles');
        stage.attachmentViewRoles=roles('#stageAttachmentViewRoles');
    },0));

    async function refreshAssistantStatus() {

        debugger;
        if (!state.user || !has('ASSISTANT.USE')) {
            $('#catsAssistantLauncher,#catsAssistantPanel').addClass('d-none');
            return;
        }
        const status = await api('/api/assistant/status');
        $('#catsAssistantModel').text(status.enabled ? `${status.provider || 'SLM/LLM'} · ${status.model || ''}` : 'Disabled');
        $('#catsAssistantLauncher').toggleClass('d-none', !status.enabled);
        if (!status.enabled) $('#catsAssistantPanel').addClass('d-none');
    }

    function appendAssistantMessage(text, type) {
        const cls = type === 'user' ? 'user' : type === 'error' ? 'error' : 'assistant';
        $('#catsAssistantMessages').append(`<div class="cats-chat-message ${cls}">${esc(text)}</div>`);
        const host = document.getElementById('catsAssistantMessages');
        host.scrollTop = host.scrollHeight;
    }

    $('#catsAssistantLauncher').on('click', () => {
        $('#catsAssistantPanel').toggleClass('d-none');
        if (!$('#catsAssistantPanel').hasClass('d-none')) setTimeout(() => $('#catsAssistantInput').trigger('focus'), 80);
    });
    $('#catsAssistantClose').on('click', () => $('#catsAssistantPanel').addClass('d-none'));
    $('#catsAssistantForm').on('submit', async e => {
        e.preventDefault();
        const input = $('#catsAssistantInput');
        const message = String(input.val() || '').trim();
        if (!message) return;
        appendAssistantMessage(message, 'user');
        input.val('');
        const button = $('#catsAssistantSend').prop('disabled', true).text('Thinking…');
        try {
            const result = await api('/api/assistant/chat', { method: 'POST', body: { message } });
            appendAssistantMessage(result.answer || 'No answer was returned.', 'assistant');
            $('#catsAssistantModel').text(`${result.provider || 'SLM/LLM'} · ${result.model || ''}${result.usedMcpTools ? ' · MCP' : ''}`);
        } catch (x) {
            appendAssistantMessage(x.message || 'Assistant request failed.', 'error');
        } finally {
            button.prop('disabled', false).text('Send');
        }
    });

    const piiGridObserver = new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => { if (node.nodeType === Node.ELEMENT_NODE) { enhancePiiGrids(node); removeWorkflowDefinitionJson(node); hideAssignmentRulesJson(node); } })));
    piiGridObserver.observe(document.getElementById('viewHost'), { childList: true, subtree: true });
})();
