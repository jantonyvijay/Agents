using System.Text;
using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.App.Controllers;

[Authorize]
[ApiController]
[Route("api/alerts")]
public sealed class AlertsController(ICatsRepository repo,IPlatformRepository platform,AlertApplicationService service,IDataProtectorService protector,IPasswordHasher hasher) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery]AlertListFilter filter,CancellationToken ct)
    {
        var user=User.ToCurrentUser();
        if(string.IsNullOrWhiteSpace(filter.DashboardId))
            return Ok(await repo.GetAlertsAsync(filter,user,protector.Unprotect,value=>protector.Mask(value),ct));

        Dictionary<string,string> groupFilters;
        try{groupFilters=JsonSerializer.Deserialize<Dictionary<string,string>>(filter.DashboardGroupFiltersJson??"{}",JsonDefaults.Options)??new(StringComparer.OrdinalIgnoreCase);}
        catch(JsonException){return BadRequest("Dashboard drill-down filters are invalid.");}
        if(!string.IsNullOrWhiteSpace(filter.BranchCode))groupFilters["BranchCode"]=filter.BranchCode;
        if(!string.IsNullOrWhiteSpace(filter.Status))groupFilters["Status"]=filter.Status;
        var data=await platform.GetTemplateDashboardDataAsync(filter.DashboardId,new TemplateDashboardQuery
        {
            Search=filter.Search??"",
            AlertNo=filter.AlertNo??"",
            AccountId=filter.AccountId??"",
            CustomerId=filter.CustomerId??"",
            GroupFiltersJson=JsonSerializer.Serialize(groupFilters,JsonDefaults.Options),
            MetricCode=filter.DashboardMetricCode??"",
            Page=filter.Page,
            PageSize=filter.PageSize
        },user,protector.Unprotect,value=>protector.Mask(value),ct);
        var templateName=await repo.GetTemplateNameAsync(data.Dashboard.TemplateId,ct);
        var now=DateTime.UtcNow;
        string Text(Dictionary<string,object?> row,string key)=>Convert.ToString(row.GetValueOrDefault(key))??"";
        int Age(Dictionary<string,object?> row,string key)=>row.GetValueOrDefault(key) is DateTime date?Math.Max(0,(int)(now-date).TotalDays):0;
        return Ok(new PagedResult<AlertListItem>
        {
            Page=data.Page,
            PageSize=data.PageSize,
            TotalRecords=data.TotalRecords,
            Data=data.Rows.Select(row=>new AlertListItem
            {
                Id=Text(row,"Id"),AlertNo=Text(row,"AlertNo"),TemplateName=templateName,AlertType=Text(row,"AlertType"),
                BranchCode=Text(row,"BranchCode"),CustomerId=Text(row,"CustomerId"),AccountId=Text(row,"AccountId"),
                CurrentStageName=Text(row,"CurrentStageName"),Status=Text(row,"Status"),Priority=Text(row,"Priority"),
                OverallAgingDays=Age(row,"CreatedAtUtc"),StageAgingDays=Age(row,"StageEnteredAtUtc")
            }).ToList()
        });
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Detail(string id,CancellationToken ct) => Ok(await service.DetailAsync(id,User.ToCurrentUser(),Ip(),ct));

    [HttpPost("{id}/unmask-pii")]
    public async Task<IActionResult> UnmaskPii(string id,UnmaskPiiRequest request,CancellationToken ct)
    {
        var current=User.ToCurrentUser();
        if(!current.HasPermission(CatsPermissions.PiiUnmask))
            throw new UnauthorizedAccessException("PII unmask permission is required.");
        var field=request.Field.Trim();
        if(!field.Equals("customerId",StringComparison.OrdinalIgnoreCase) && !field.Equals("accountId",StringComparison.OrdinalIgnoreCase))
            return BadRequest(new{message="Invalid PII field."});
        var user=await repo.GetUserByUserNameAsync(current.UserName,ct);
        if(user==null || !user.IsActive || string.IsNullOrEmpty(request.Password) || !hasher.Verify(request.Password,user.PasswordHash))
            return BadRequest(new{message="Password verification failed."});
        var alert=await repo.GetAlertAsync(id,ct) ?? throw new KeyNotFoundException("Alert not found.");
        await service.EnsureViewAsync(alert,current,ct);
        var value=field.Equals("customerId",StringComparison.OrdinalIgnoreCase)
            ? protector.Unprotect(alert.CustomerIdEncrypted)
            : protector.Unprotect(alert.AccountIdEncrypted);
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id=Guid.NewGuid().ToString("N"),AlertId=alert.Id,UserId=current.Id,UserName=current.UserName,RoleCode=current.RoleCode,
            Action="PII_UNMASK_VIEW",EntityType="Alert",EntityId=alert.Id,StageId=alert.CurrentStageId,
            Remarks=$"{(field.Equals("customerId",StringComparison.OrdinalIgnoreCase)?"Customer ID":"Account ID")} revealed after password verification",
            IpAddress=Ip(),CreatedAtUtc=DateTime.UtcNow
        },ct);
        return Ok(new{field,value});
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateAlertRequest request,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(request.TemplateId)||string.IsNullOrWhiteSpace(request.AlertType))return BadRequest(new{message="Template and Alert Type are required."});
        var template=await repo.GetTemplateAsync(request.TemplateId,ct);
        if(template==null)return BadRequest(new{message="Selected Alert Type was not found."});
        if(!template.AllowsBaseDataMode("ManualSingle"))return BadRequest(new{message="Manual Single Entry is disabled for this Alert Type."});
        return Ok(await service.CreateAsync(request,User.ToCurrentUser(),Ip(),ct));
    }

    [HttpPost("{id}/ai-query-suggestion")]
    public async Task<IActionResult> AiQuerySuggestion(string id,AiQuerySuggestionRequest request,CancellationToken ct)
        => Ok(await service.SuggestQueryAsync(id,request,User.ToCurrentUser(),Ip(),ct));

    [HttpPost("{id}/action")]
    public async Task<IActionResult> Action(string id,WorkflowActionRequest request,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(request.Action))return BadRequest(new{message="Action is required."});
        await service.ApplyActionAsync(id,request,User.ToCurrentUser(),Ip(),ct);
        return Ok(await service.DetailAsync(id,User.ToCurrentUser(),Ip(),ct));
    }

    [HttpPost("upload-csv")]
    [RequestSizeLimit(30_000_000)]
    public async Task<IActionResult> UploadCsv(IFormFile file,[FromForm]string? templateId,CancellationToken ct)
    {
        if(file==null||file.Length==0)return BadRequest(new{message="CSV file is required."});
        using var sr=new StreamReader(file.OpenReadStream(),Encoding.UTF8,true);
        var rows=CsvParser.Parse(await sr.ReadToEndAsync(ct));
        TemplateRecord? selectedTemplate=null; List<TemplateField> selectedFields=[];
        if(!string.IsNullOrWhiteSpace(templateId))
        {
            selectedTemplate=await repo.GetTemplateAsync(templateId,ct);
            if(selectedTemplate==null)return BadRequest(new{message="Selected Alert Type was not found."});
            if(selectedTemplate.Status!=TemplateStatus.Published)return BadRequest(new{message="Selected Alert Type is not published."});
            if(!selectedTemplate.AllowsBaseDataMode("BulkFileUpload"))return BadRequest(new{message="Bulk File Upload is disabled for this Alert Type."});
            selectedFields=JsonSerializer.Deserialize<List<TemplateField>>(selectedTemplate.FieldsJson,JsonDefaults.Options)??[];
        }
        var results=new List<object>(); var success=0; var failed=0; var line=1;
        foreach(var row in rows)
        {
            line++;
            try
            {
                JsonElement data;
                if(selectedTemplate!=null)
                {
                    var configuredData=selectedFields.ToDictionary(x=>x.Name,x=>row.GetValueOrDefault(x.Name,"")!,StringComparer.OrdinalIgnoreCase);
                    data=JsonSerializer.SerializeToElement(configuredData,JsonDefaults.Options);
                }
                else
                {
                    var dj=row.GetValueOrDefault("DataJson","{}"); using var doc=JsonDocument.Parse(string.IsNullOrWhiteSpace(dj)?"{}":dj); data=doc.RootElement.Clone();
                }
                string ConfiguredValue(string name)=>selectedFields.FirstOrDefault(x=>x.Name.Equals(name,StringComparison.OrdinalIgnoreCase)) is { } field?row.GetValueOrDefault(field.Name,"")!:row.GetValueOrDefault(name,"")!;
                var req=new CreateAlertRequest{TemplateId=selectedTemplate?.Id??row.GetValueOrDefault("TemplateId","")!,AlertType=selectedTemplate?.Code??row.GetValueOrDefault("AlertType","")!,BranchCode=ConfiguredValue("BranchCode"),CustomerId=ConfiguredValue("CustomerId"),AccountId=ConfiguredValue("AccountId"),Priority=row.GetValueOrDefault("Priority","Normal")!,Data=data};
                var effectiveTemplate=selectedTemplate??await repo.GetTemplateAsync(req.TemplateId,ct);
                if(effectiveTemplate==null)throw new InvalidOperationException("Selected Alert Type was not found.");
                if(!effectiveTemplate.AllowsBaseDataMode("BulkFileUpload"))throw new InvalidOperationException("Bulk File Upload is disabled for this Alert Type.");
                var a=await service.CreateAsync(req,User.ToCurrentUser(),Ip(),ct); success++; results.Add(new{line,status="Success",alertNo=a.AlertNo});
            }
            catch(Exception ex){failed++;results.Add(new{line,status="Failed",error=ex.Message});}
        }
        return Ok(new{success,failed,results});
    }

    [HttpGet("sample-csv/{templateId}")]
    public async Task<IActionResult> DownloadSampleCsv(string templateId,CancellationToken ct)
    {
        var user=User.ToCurrentUser();
        if(!user.HasPermission(CatsPermissions.AlertUpload))throw new UnauthorizedAccessException("Alert upload permission is required.");
        var template=await repo.GetTemplateAsync(templateId,ct);
        if(template==null)return NotFound(new{message="Alert Type was not found."});
        if(template.Status!=TemplateStatus.Published)return BadRequest(new{message="Only published Alert Types have upload samples."});
        if(!template.AllowsBaseDataMode("BulkFileUpload"))return BadRequest(new{message="Bulk File Upload is disabled for this Alert Type."});
        var fields=JsonSerializer.Deserialize<List<TemplateField>>(template.FieldsJson,JsonDefaults.Options)??[];
        var headers=new[]{"Priority"}.Concat(fields.Select(x=>x.Name)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        static string Csv(string value)=>"\""+value.Replace("\"","\"\"")+"\"";
        string Example(TemplateField field)
        {
            if(field.Type.Equals("select",StringComparison.OrdinalIgnoreCase))return (JsonSerializer.Deserialize<List<string>>(field.OptionsJson,JsonDefaults.Options)??[]).FirstOrDefault()??"";
            if(field.Type.Equals("number",StringComparison.OrdinalIgnoreCase))return "0";
            if(field.Type.Equals("date",StringComparison.OrdinalIgnoreCase))return DateTime.UtcNow.ToString("yyyy-MM-dd");
            if(field.Type.Equals("checkbox",StringComparison.OrdinalIgnoreCase))return "false";
            return field.Required?$"Sample {field.Label}":"";
        }
        var examples=headers.Select(x=>x.Equals("Priority",StringComparison.OrdinalIgnoreCase)?"Normal":Example(fields.First(f=>f.Name.Equals(x,StringComparison.OrdinalIgnoreCase))));
        var csv=new StringBuilder().AppendLine(string.Join(',',headers.Select(Csv))).AppendLine(string.Join(',',examples.Select(Csv))).ToString();
        var safeCode=string.Concat(template.Code.Select(c=>char.IsLetterOrDigit(c)||c is '-' or '_'?c:'_'));
        return File(Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(csv)).ToArray(),"text/csv",$"{safeCode}-sample.csv");
    }


    [HttpPost("{id}/reassign")]
    public async Task<IActionResult> Reassign(string id,ReassignWorkItemRequest request,CancellationToken ct)
    {
        await service.ReassignAsync(id,request,User.ToCurrentUser(),Ip(),ct);
        return Ok(await service.DetailAsync(id,User.ToCurrentUser(),Ip(),ct));
    }

    [HttpPost("{id}/attachments")]
    [RequestSizeLimit(25_000_000)]
    public async Task<IActionResult> UploadAttachment(string id,[FromForm]string stageId,[FromForm]IFormFile file,CancellationToken ct)
        => Ok(await service.UploadAttachmentAsync(id,stageId,file,User.ToCurrentUser(),Ip(),ct));

    [HttpGet("attachments/{attachmentId}")]
    public async Task<IActionResult> DownloadAttachment(string attachmentId,CancellationToken ct)
    {
        var x=await service.GetAttachmentForDownloadAsync(attachmentId,User.ToCurrentUser(),Ip(),ct);
        return PhysicalFile(x.Path,x.Record.ContentType,x.Record.FileName,enableRangeProcessing:true);
    }

    private string? Ip()=>HttpContext.Connection.RemoteIpAddress?.ToString();
}
