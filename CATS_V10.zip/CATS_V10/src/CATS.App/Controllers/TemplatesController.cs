using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;
using CATS.Workflow;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.App.Controllers;

[Authorize]
[ApiController]
[Route("api/templates")]
public sealed class TemplatesController(ICatsRepository repo,MafWorkflowGraphService maf) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct) => Ok(await repo.GetTemplatesAsync(ct));

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(string id,CancellationToken ct)
    {
        var t=await repo.GetTemplateAsync(id,ct); return t==null?NotFound():Ok(t);
    }

    [HttpPost]
    public async Task<IActionResult> Save(SaveTemplateRequest request,CancellationToken ct)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.TemplateManage);
        request.Id=string.IsNullOrWhiteSpace(request.Id)?null:request.Id.Trim();
        request.Code=request.Code.Trim(); request.Name=request.Name.Trim();
        if(string.IsNullOrWhiteSpace(request.Code)||string.IsNullOrWhiteSpace(request.Name))return BadRequest("Template code and name are required.");
        if(request.Sections.Any(x=>string.IsNullOrWhiteSpace(x.Id)||string.IsNullOrWhiteSpace(x.Name)))return BadRequest("Every section requires an ID and name.");
        if(request.Sections.Any(x=>x.ColumnSpan<2||x.ColumnSpan>12))return BadRequest("Section columns must be between 2 and 12.");
        if(request.Sections.Any(x=>x.PageNumber<1))return BadRequest("Section page must be 1 or greater.");
        if(request.Sections.Select(x=>x.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=request.Sections.Count)return BadRequest("Section IDs must be unique.");
        if(request.Fields.Any(x=>string.IsNullOrWhiteSpace(x.Id)||string.IsNullOrWhiteSpace(x.Name)||string.IsNullOrWhiteSpace(x.Label)))return BadRequest("Every field requires an ID, name and label.");
        if(request.Fields.Select(x=>x.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=request.Fields.Count)return BadRequest("Field names must be unique.");
        var sectionIds=request.Sections.Select(x=>x.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if(request.Fields.Any(x=>!sectionIds.Contains(x.SectionId)))return BadRequest("Every field must belong to an existing section.");
        request.ViewConfiguration ??= new TemplateViewConfiguration();
        var layout=(request.ViewConfiguration.LayoutMode??"Single").Trim();
        if(!new[]{"Auto","Single","Tab","Popup","Accordion","Wizard"}.Contains(layout,StringComparer.OrdinalIgnoreCase))return BadRequest("Layout mode must be Auto, Single, Tab, Popup, Accordion or Wizard.");
        request.ViewConfiguration.LayoutMode=layout;
        var requestedBaseDataModes=request.ViewConfiguration.BaseDataModes??[];
        if(requestedBaseDataModes.Count==0)return BadRequest("Select at least one Base Data option.");
        if(requestedBaseDataModes.Any(x=>!TemplateConfigurationSupport.AllBaseDataModes.Contains(x,StringComparer.OrdinalIgnoreCase)))return BadRequest("Base Data options must be Manual Single Entry, Bulk File Upload, SFTP Location or FC Query.");
        request.ViewConfiguration.BaseDataModes=TemplateConfigurationSupport.AllBaseDataModes.Where(x=>requestedBaseDataModes.Contains(x,StringComparer.OrdinalIgnoreCase)).ToList();
        if(request.Sections.Any(x=>!new[]{"Grid","List"}.Contains(x.DataViewMode??"Grid",StringComparer.OrdinalIgnoreCase)))return BadRequest("Section data view must be Grid or List.");
        foreach(var field in request.Fields)
        {
            if(field.MinLength.HasValue && field.MinLength<0)return BadRequest($"{field.Label}: Min length cannot be negative.");
            if(field.MaxLength.HasValue && field.MaxLength<0)return BadRequest($"{field.Label}: Max length cannot be negative.");
            if(field.MinLength.HasValue && field.MaxLength.HasValue && field.MinLength>field.MaxLength)return BadRequest($"{field.Label}: Min length cannot exceed Max length.");
            if(field.MinValue.HasValue && field.MaxValue.HasValue && field.MinValue>field.MaxValue)return BadRequest($"{field.Label}: Min value cannot exceed Max value.");
            if(string.Equals(field.DataSourceMode,"Api",StringComparison.OrdinalIgnoreCase) && (string.IsNullOrWhiteSpace(field.ApiUrl) || !field.ApiUrl.Trim().StartsWith("/api/",StringComparison.OrdinalIgnoreCase)))return BadRequest($"{field.Label}: API dropdown URL must be a relative /api/... Gateway route.");
            if(!string.IsNullOrWhiteSpace(field.ValidationPattern)){try{_=new System.Text.RegularExpressions.Regex(field.ValidationPattern);}catch{return BadRequest($"{field.Label}: Validation pattern is invalid.");}}
            try{_=JsonSerializer.Deserialize<List<FieldDependencyValidation>>(field.DependencyValidationsJson,JsonDefaults.Options)??[];}catch{return BadRequest($"{field.Label}: Dependency validation JSON is invalid.");}
        }
        TemplateRecord? previous=null;
        if(!string.IsNullOrWhiteSpace(request.Id))
        {
            previous=await repo.GetTemplateAsync(request.Id,ct);
            if(previous==null)return NotFound("The template to update was not found.");
            if(previous.Status==TemplateStatus.Retired)return Conflict("Retired templates cannot be modified.");
        }
        var t=await repo.SaveTemplateAsync(request,u,ct);
        await repo.InsertAuditAsync(Audit(u,previous==null?"TEMPLATE_CREATE":"TEMPLATE_UPDATE","Template",t.Id,previous==null?null:JsonSerializer.Serialize(previous),JsonSerializer.Serialize(t)),ct);
        return Ok(t);
    }

    [HttpPost("{id}/retire")]
    public async Task<IActionResult> Retire(string id,CancellationToken ct)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.TemplateManage);
        var previous=await repo.GetTemplateAsync(id,ct);
        if(previous==null)return NotFound();
        if(previous.Status==TemplateStatus.Retired)return Ok(previous);
        await repo.RetireTemplateAsync(id,ct);
        var retired=await repo.GetTemplateAsync(id,ct) ?? throw new InvalidOperationException("The retired template could not be reloaded.");
        await repo.InsertAuditAsync(Audit(u,"TEMPLATE_RETIRE","Template",id,JsonSerializer.Serialize(previous),JsonSerializer.Serialize(retired)),ct);
        return Ok(retired);
    }

    [HttpGet("{templateId}/workflow")]
    public async Task<IActionResult> GetWorkflow(string templateId,CancellationToken ct)
    {
        var w=await repo.GetPublishedWorkflowForTemplateAsync(templateId,ct);
        if(w==null)return NotFound();
        return Ok(new{record=w,definition=JsonSerializer.Deserialize<WorkflowDefinitionModel>(w.DefinitionJson, JsonDefaults.Options)});
    }

    [HttpPost("workflow")]
    public async Task<IActionResult> SaveWorkflow(SaveWorkflowRequest request,CancellationToken ct)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.WorkflowManage);
        _=maf.BuildGraph(request.Definition);
        var w=await repo.SaveWorkflowAsync(request,u,ct);
        await repo.InsertAuditAsync(Audit(u,request.Publish?"WORKFLOW_PUBLISH":"WORKFLOW_SAVE","WorkflowDefinition",w.Id,null,w.DefinitionJson),ct);
        return Ok(w);
    }

    [HttpPost("workflow/preview")]
    public IActionResult Preview(WorkflowDefinitionModel definition)
    {
        var u=User.ToCurrentUser(); Require(u,CatsPermissions.WorkflowManage);
        return Ok(new{mermaid=maf.ToMermaid(definition)});
    }

    private static void Require(CurrentUser u,string p){if(!u.HasPermission(p))throw new UnauthorizedAccessException($"Permission {p} is required.");}
    private static AuditRecord Audit(CurrentUser u,string action,string type,string id,string? previous,string? current)=>new(){Id=Guid.NewGuid().ToString("N"),UserId=u.Id,UserName=u.UserName,RoleCode=u.RoleCode,Action=action,EntityType=type,EntityId=id,PreviousValueJson=previous,NewValueJson=current,CreatedAtUtc=DateTime.UtcNow};
}
