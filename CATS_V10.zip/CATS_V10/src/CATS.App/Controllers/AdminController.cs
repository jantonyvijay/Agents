using System.Text.Json;
using CATS.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.App.Controllers;

[Authorize]
[ApiController]
[Route("api/admin")]
public sealed class AdminController(ICatsRepository repo, IPasswordHasher hasher) : ControllerBase
{
    [HttpGet("users")]
    public async Task<IActionResult> Users(CancellationToken ct)
    {
        RequireAdmin();
        var users=await repo.GetUsersAsync(ct);
        return Ok(users.Select(ToItem));
    }

    [HttpPost("users")]
    public async Task<IActionResult> SaveUser(SaveUserRequest request,CancellationToken ct)
    {
        var actor=RequireAdmin();
        if(string.IsNullOrWhiteSpace(request.UserName) || string.IsNullOrWhiteSpace(request.DisplayName) || string.IsNullOrWhiteSpace(request.RoleCode))
            return BadRequest(new{message="User name, display name and role are required."});

        var existing=string.IsNullOrWhiteSpace(request.Id)?null:await repo.GetUserByIdAsync(request.Id!,ct);
        var duplicate=await repo.GetUserByUserNameAsync(request.UserName.Trim(),ct);
        if(duplicate!=null && (existing==null || !duplicate.Id.Equals(existing.Id,StringComparison.OrdinalIgnoreCase)))
            return Conflict(new{message="User name already exists."});
        if(existing==null && string.IsNullOrWhiteSpace(request.Password))
            return BadRequest(new{message="Password is required for a new user."});
        if(!string.IsNullOrWhiteSpace(request.Password) && request.Password.Length<10)
            return BadRequest(new{message="Password must contain at least 10 characters."});

        var record=new UserRecord
        {
            Id=existing?.Id ?? Guid.NewGuid().ToString("N"),
            UserName=request.UserName.Trim(),DisplayName=request.DisplayName.Trim(),
            PasswordHash=string.IsNullOrWhiteSpace(request.Password)?existing!.PasswordHash:hasher.Hash(request.Password),
            RoleCode=request.RoleCode.Trim().ToUpperInvariant(),
            DepartmentCode=(request.DepartmentCode??"").Trim().ToUpperInvariant(),
            BranchCode=(request.BranchCode??"").Trim().ToUpperInvariant(),
            PermissionsJson=JsonSerializer.Serialize(request.Permissions.Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x=>x)),
            IsActive=request.IsActive
        };
        await repo.UpsertUserAsync(record,existing==null,ct);
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id=Guid.NewGuid().ToString("N"),UserId=actor.Id,UserName=actor.UserName,RoleCode=actor.RoleCode,
            Action=existing==null?"USER_CREATE":"USER_UPDATE",EntityType="User",EntityId=record.Id,
            NewValueJson=JsonSerializer.Serialize(ToItem(record)),Remarks=$"User {record.UserName} saved",
            IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow
        },ct);
        return Ok(ToItem(record));
    }

    [HttpGet("aging-buckets")]
    public async Task<IActionResult> AgingBuckets(CancellationToken ct)
    {
        RequireAdmin();
        return Ok(await repo.GetAgingBucketsAsync(ct));
    }

    [HttpPost("aging-buckets")]
    public async Task<IActionResult> SaveAgingBucket(SaveAgingBucketRequest request,CancellationToken ct)
    {
        var actor=RequireAdmin();
        await repo.SaveAgingBucketAsync(request,ct);
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id=Guid.NewGuid().ToString("N"),UserId=actor.Id,UserName=actor.UserName,RoleCode=actor.RoleCode,
            Action="AGING_BUCKET_SAVE",EntityType="AgingBucket",EntityId=request.Id,
            NewValueJson=JsonSerializer.Serialize(request),Remarks="Aging bucket configuration saved",
            IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow
        },ct);
        return Ok(await repo.GetAgingBucketsAsync(ct));
    }

    [HttpGet("permissions")]
    public IActionResult Permissions()
    {
        RequireAdmin();
        return Ok(new[]{CatsPermissions.TemplateManage,CatsPermissions.WorkflowManage,CatsPermissions.AlertUpload,CatsPermissions.AlertViewAll,CatsPermissions.AlertReassign,CatsPermissions.PiiUnmask,CatsPermissions.AuditView,PlatformPermissions.DashboardView,PlatformPermissions.DashboardConfigure,PlatformPermissions.IngestionView,PlatformPermissions.IngestionManage,PlatformPermissions.ReportsMis,PlatformPermissions.ReportsAlertWise,PlatformPermissions.ReportsAll,PlatformPermissions.MailManage,PlatformPermissions.SecurityManage,PlatformPermissions.AssistantUse,PlatformPermissions.McpManage});
    }

    private CurrentUser RequireAdmin()
    {
        var u=User.ToCurrentUser();
        if(!u.HasPermission(PlatformPermissions.SecurityManage)) throw new UnauthorizedAccessException("Security management permission is required.");
        return u;
    }

    private static UserAdminItem ToItem(UserRecord u)=>new()
    {
        Id=u.Id,UserName=u.UserName,DisplayName=u.DisplayName,RoleCode=u.RoleCode,
        DepartmentCode=u.DepartmentCode,BranchCode=u.BranchCode,Permissions=u.Permissions().ToList(),IsActive=u.IsActive
    };
}
