/* CATS V3 - Template / Alert-Type Dashboard SQL Server Upgrade - FIXED
   Works with existing V2/V3 DBs where TemplateDashboardMaster may already
   exist with an older/partial column set. Preserves existing data.
   Take a database backup before applying.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID('dbo.TemplateDashboardMaster','U') IS NULL
BEGIN
    CREATE TABLE dbo.TemplateDashboardMaster
    (
        Id varchar(32) NOT NULL CONSTRAINT PK_TemplateDashboardMaster PRIMARY KEY,
        Code varchar(80) NOT NULL,
        Name nvarchar(150) NOT NULL,
        Title nvarchar(250) NOT NULL,
        Description nvarchar(1000) NOT NULL CONSTRAINT DF_TemplateDashboard_Description DEFAULT N'',
        TemplateId varchar(32) NOT NULL,
        AlertType nvarchar(150) NOT NULL CONSTRAINT DF_TemplateDashboard_AlertType DEFAULT N'',
        GroupByFieldsJson nvarchar(max) NOT NULL CONSTRAINT DF_TemplateDashboard_GroupBy DEFAULT N'["BranchCode"]',
        MetricsJson nvarchar(max) NOT NULL CONSTRAINT DF_TemplateDashboard_Metrics DEFAULT N'[]',
        GridColumnsJson nvarchar(max) NOT NULL CONSTRAINT DF_TemplateDashboard_Grid DEFAULT N'[]',
        SearchFieldsJson nvarchar(max) NOT NULL CONSTRAINT DF_TemplateDashboard_Search DEFAULT N'["AlertNo","AccountId","CustomerId"]',
        PageSize int NOT NULL CONSTRAINT DF_TemplateDashboard_PageSize DEFAULT 20,
        DisplayOrder int NOT NULL CONSTRAINT DF_TemplateDashboard_DisplayOrder DEFAULT 1,
        IsDefault bit NOT NULL CONSTRAINT DF_TemplateDashboard_IsDefault DEFAULT 0,
        IsActive bit NOT NULL CONSTRAINT DF_TemplateDashboard_IsActive DEFAULT 1,
        CreatedAtUtc datetime2 NOT NULL CONSTRAINT DF_TemplateDashboard_Created DEFAULT SYSUTCDATETIME(),
        UpdatedAtUtc datetime2 NOT NULL CONSTRAINT DF_TemplateDashboard_Updated DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_TemplateDashboard_Code UNIQUE(Code),
        CONSTRAINT FK_TemplateDashboard_Template FOREIGN KEY(TemplateId) REFERENCES dbo.Templates(Id)
    );
END
GO

/* Add any missing columns to an older/partial table. */
IF COL_LENGTH('dbo.TemplateDashboardMaster','Code') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD Code varchar(80) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','Name') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD Name nvarchar(150) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','Title') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD Title nvarchar(250) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','Description') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD Description nvarchar(1000) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','TemplateId') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD TemplateId varchar(32) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','AlertType') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD AlertType nvarchar(150) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','GroupByFieldsJson') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD GroupByFieldsJson nvarchar(max) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','MetricsJson') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD MetricsJson nvarchar(max) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','GridColumnsJson') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD GridColumnsJson nvarchar(max) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','SearchFieldsJson') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD SearchFieldsJson nvarchar(max) NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','PageSize') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD PageSize int NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','DisplayOrder') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD DisplayOrder int NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','IsDefault') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD IsDefault bit NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','IsActive') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD IsActive bit NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','CreatedAtUtc') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD CreatedAtUtc datetime2 NULL;
IF COL_LENGTH('dbo.TemplateDashboardMaster','UpdatedAtUtc') IS NULL ALTER TABLE dbo.TemplateDashboardMaster ADD UpdatedAtUtc datetime2 NULL;
GO

/* Copy values from legacy V3 column names when those columns exist. */
IF COL_LENGTH('dbo.TemplateDashboardMaster','AlertTypeFilter') IS NOT NULL
    EXEC(N'UPDATE dbo.TemplateDashboardMaster SET AlertType=COALESCE(NULLIF(AlertType,N''''),AlertTypeFilter,N'''') WHERE AlertType IS NULL OR AlertType=N'''';');
IF COL_LENGTH('dbo.TemplateDashboardMaster','GroupFieldsJson') IS NOT NULL
    EXEC(N'UPDATE dbo.TemplateDashboardMaster SET GroupByFieldsJson=COALESCE(NULLIF(GroupByFieldsJson,N''''),GroupFieldsJson,N''["BranchCode"]'') WHERE GroupByFieldsJson IS NULL OR GroupByFieldsJson=N'''';');
GO

DECLARE @FallbackTemplateId varchar(32)=
(
    SELECT TOP(1) Id FROM dbo.Templates
    ORDER BY CASE WHEN Status='Published' THEN 0 ELSE 1 END, CreatedAtUtc, Id
);

UPDATE dbo.TemplateDashboardMaster
SET Code=COALESCE(NULLIF(Code,''),LEFT('DASH_'+REPLACE(Id,'-','_'),80)),
    Name=COALESCE(NULLIF(Name,N''),N'Dashboard '+CONVERT(nvarchar(32),Id)),
    Title=COALESCE(NULLIF(Title,N''),NULLIF(Name,N''),N'Template Dashboard'),
    Description=COALESCE(Description,N''),
    TemplateId=COALESCE(NULLIF(TemplateId,''),@FallbackTemplateId),
    AlertType=COALESCE(AlertType,N''),
    GroupByFieldsJson=CASE WHEN ISJSON(GroupByFieldsJson)=1 THEN GroupByFieldsJson ELSE N'["BranchCode"]' END,
    MetricsJson=CASE WHEN ISJSON(MetricsJson)=1 THEN MetricsJson ELSE N'[]' END,
    GridColumnsJson=CASE WHEN ISJSON(GridColumnsJson)=1 THEN GridColumnsJson ELSE N'[]' END,
    SearchFieldsJson=CASE WHEN ISJSON(SearchFieldsJson)=1 THEN SearchFieldsJson ELSE N'["AlertNo","AccountId","CustomerId"]' END,
    PageSize=CASE WHEN ISNULL(PageSize,0)<=0 THEN 20 ELSE PageSize END,
    DisplayOrder=ISNULL(DisplayOrder,1),
    IsDefault=ISNULL(IsDefault,0),
    IsActive=ISNULL(IsActive,1),
    CreatedAtUtc=ISNULL(CreatedAtUtc,SYSUTCDATETIME()),
    UpdatedAtUtc=ISNULL(UpdatedAtUtc,SYSUTCDATETIME());
GO

IF EXISTS(SELECT 1 FROM dbo.TemplateDashboardMaster WHERE TemplateId IS NULL OR TemplateId='')
    THROW 50001,'TemplateDashboardMaster has row(s) without TemplateId and no template was available for migration.',1;
GO

ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN Code varchar(80) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN Name nvarchar(150) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN Title nvarchar(250) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN Description nvarchar(1000) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN TemplateId varchar(32) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN AlertType nvarchar(150) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN GroupByFieldsJson nvarchar(max) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN MetricsJson nvarchar(max) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN GridColumnsJson nvarchar(max) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN SearchFieldsJson nvarchar(max) NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN PageSize int NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN DisplayOrder int NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN IsDefault bit NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN IsActive bit NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN CreatedAtUtc datetime2 NOT NULL;
ALTER TABLE dbo.TemplateDashboardMaster ALTER COLUMN UpdatedAtUtc datetime2 NOT NULL;
GO

/* Ensure defaults needed by the current SaveTemplateDashboard INSERT. */
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='Description') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_Description DEFAULT N'' FOR Description;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='AlertType') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_AlertType DEFAULT N'' FOR AlertType;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='GroupByFieldsJson') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_GroupBy DEFAULT N'["BranchCode"]' FOR GroupByFieldsJson;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='MetricsJson') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_Metrics DEFAULT N'[]' FOR MetricsJson;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='GridColumnsJson') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_Grid DEFAULT N'[]' FOR GridColumnsJson;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='SearchFieldsJson') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_Search DEFAULT N'["AlertNo","AccountId","CustomerId"]' FOR SearchFieldsJson;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='PageSize') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_PageSize DEFAULT 20 FOR PageSize;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='DisplayOrder') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_DisplayOrder DEFAULT 1 FOR DisplayOrder;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='IsDefault') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_IsDefault DEFAULT 0 FOR IsDefault;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='IsActive') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_IsActive DEFAULT 1 FOR IsActive;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='CreatedAtUtc') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_Created DEFAULT SYSUTCDATETIME() FOR CreatedAtUtc;
IF NOT EXISTS(SELECT 1 FROM sys.default_constraints dc JOIN sys.columns c ON c.default_object_id=dc.object_id WHERE c.object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND c.name='UpdatedAtUtc') ALTER TABLE dbo.TemplateDashboardMaster ADD CONSTRAINT DF_TemplateDashboard_Updated DEFAULT SYSUTCDATETIME() FOR UpdatedAtUtc;
GO

IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND is_unique=1 AND name='UX_TemplateDashboard_Code')
    CREATE UNIQUE INDEX UX_TemplateDashboard_Code ON dbo.TemplateDashboardMaster(Code);
GO

IF EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.TemplateDashboardMaster') AND name='IX_TemplateDashboard_Template')
    DROP INDEX IX_TemplateDashboard_Template ON dbo.TemplateDashboardMaster;
GO
CREATE INDEX IX_TemplateDashboard_Template ON dbo.TemplateDashboardMaster(TemplateId,AlertType,IsActive,DisplayOrder);
GO

IF OBJECT_ID('dbo.TemplateDashboardRoleMapping','U') IS NULL
BEGIN
    CREATE TABLE dbo.TemplateDashboardRoleMapping
    (
        DashboardId varchar(32) NOT NULL,
        RoleCode varchar(60) NOT NULL,
        IsVisible bit NOT NULL CONSTRAINT DF_TemplateDashboardRole_Visible DEFAULT 1,
        CONSTRAINT PK_TemplateDashboardRoleMapping PRIMARY KEY(DashboardId,RoleCode)
    );
END
ELSE IF COL_LENGTH('dbo.TemplateDashboardRoleMapping','IsVisible') IS NULL
    ALTER TABLE dbo.TemplateDashboardRoleMapping ADD IsVisible bit NOT NULL CONSTRAINT DF_TemplateDashboardRole_Visible DEFAULT 1 WITH VALUES;
GO

CREATE OR ALTER PROCEDURE dbo.usp_PlatformRepository
 @Operation nvarchar(100), @JsonInput nvarchar(max)=N'{}'
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF ISJSON(@JsonInput)<>1
 BEGIN
  ;THROW 50000,'JsonInput must be valid JSON.',1;
 END;
 DECLARE @UserId varchar(32)=JSON_VALUE(@JsonInput,'$.userId'),@RoleCode varchar(60)=JSON_VALUE(@JsonInput,'$.roleCode'),@BranchCode varchar(60)=JSON_VALUE(@JsonInput,'$.branchCode');

 IF @Operation='GetEffectivePermissions' BEGIN
  SELECT DISTINCT rp.PermissionCode FROM dbo.CatsUsers u JOIN dbo.RolePermissionMapping rp ON rp.RoleCode=u.RoleCode AND rp.IsActive=1 JOIN dbo.PermissionMaster p ON p.Code=rp.PermissionCode AND p.IsActive=1 WHERE u.Id=@UserId AND u.IsActive=1
  UNION SELECT DISTINCT up.PermissionCode FROM dbo.UserPermissionMapping up JOIN dbo.PermissionMaster p ON p.Code=up.PermissionCode AND p.IsActive=1 WHERE up.UserId=@UserId AND up.IsActive=1; RETURN;
 END
 IF @Operation='GetDataScopes' BEGIN SELECT s.Id,s.RoleCode,s.ScopeType,s.ScopeValue,s.Priority,s.IsActive FROM dbo.DataScopeMaster s JOIN dbo.CatsUsers u ON u.RoleCode=s.RoleCode WHERE u.Id=@UserId AND s.IsActive=1 ORDER BY s.Priority; RETURN; END
 IF @Operation='GetDashboardWidgets' BEGIN
  ;WITH P AS(SELECT [value] Code FROM OPENJSON(@JsonInput,'$.permissions')), W AS(
   SELECT w.Code,w.Title,w.WidgetType,w.DrillDownUrl,m.DisplayOrder,m.Width,
    CASE UPPER(w.Code)
     WHEN 'TEMPLATES' THEN (SELECT COUNT_BIG(*) FROM dbo.Templates WHERE Status='Published')
     WHEN 'INGESTION_FAILED' THEN (SELECT COUNT_BIG(*) FROM dbo.IngestionRun WHERE Status='Failed' AND StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()))
     WHEN 'ACTIVE_ALERTS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE a.Status NOT IN('Closed','Rejected','Cancelled') AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     WHEN 'AGING_31_PLUS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=31 AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     ELSE CONVERT(bigint,0) END Value
   FROM dbo.DashboardWidgetMaster w JOIN dbo.DashboardWidgetRoleMapping m ON m.WidgetId=w.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1
   WHERE w.IsActive=1 AND (w.PermissionCode='' OR EXISTS(SELECT 1 FROM P WHERE Code=w.PermissionCode)))
  SELECT * FROM W ORDER BY DisplayOrder; RETURN;
 END
 IF @Operation='GetDashboardWidgetConfiguration' BEGIN SELECT Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive FROM dbo.DashboardWidgetMaster ORDER BY DisplayOrder; RETURN; END
 IF @Operation='SaveDashboardWidget' BEGIN
  BEGIN TRAN;
  MERGE dbo.DashboardWidgetMaster t USING(SELECT * FROM OPENJSON(@JsonInput,'$.widget') WITH(Id varchar(32),Code varchar(80),Title nvarchar(150),WidgetType varchar(30),PermissionCode varchar(100),FilterJson nvarchar(max),DrillDownUrl nvarchar(500),DisplayOrder int,Width int,IsActive int))s ON t.Id=s.Id
  WHEN MATCHED THEN UPDATE SET Code=s.Code,Title=s.Title,WidgetType=s.WidgetType,PermissionCode=s.PermissionCode,FilterJson=s.FilterJson,DrillDownUrl=s.DrillDownUrl,DisplayOrder=s.DisplayOrder,Width=s.Width,IsActive=s.IsActive
  WHEN NOT MATCHED THEN INSERT(Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive)VALUES(s.Id,s.Code,s.Title,s.WidgetType,s.PermissionCode,s.FilterJson,s.DrillDownUrl,s.DisplayOrder,s.Width,s.IsActive);
  MERGE dbo.DashboardWidgetRoleMapping t USING(SELECT JSON_VALUE(@JsonInput,'$.widget.id') WidgetId,JSON_VALUE(@JsonInput,'$.roleCode') RoleCode,CONVERT(int,JSON_VALUE(@JsonInput,'$.widget.displayOrder')) DisplayOrder,CONVERT(int,JSON_VALUE(@JsonInput,'$.widget.width')) Width)s ON t.WidgetId=s.WidgetId AND t.RoleCode=s.RoleCode
  WHEN MATCHED THEN UPDATE SET DisplayOrder=s.DisplayOrder,Width=s.Width,IsVisible=1 WHEN NOT MATCHED THEN INSERT(WidgetId,RoleCode,DisplayOrder,Width,IsVisible)VALUES(s.WidgetId,s.RoleCode,s.DisplayOrder,s.Width,1); COMMIT; RETURN;
 END
 IF @Operation='GetTemplateDashboards' BEGIN
  DECLARE @TDIncludeInactive bit=TRY_CONVERT(bit,JSON_VALUE(@JsonInput,'$.includeInactive'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d
  WHERE (@TDIncludeInactive=1 OR d.IsActive=1) AND (@TDIncludeInactive=1 OR EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))
  ORDER BY d.DisplayOrder,d.Name; RETURN;
 END
 IF @Operation='GetTemplateDashboard' BEGIN
  DECLARE @TDId varchar(32)=JSON_VALUE(@JsonInput,'$.id'),@TDRequireManage bit=TRY_CONVERT(bit,JSON_VALUE(@JsonInput,'$.requireManage'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d WHERE d.Id=@TDId AND (@TDRequireManage=1 OR (d.IsActive=1 AND EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))); RETURN;
 END
 IF @Operation='SaveTemplateDashboard' BEGIN
  BEGIN TRAN;
  MERGE dbo.TemplateDashboardMaster t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32) '$.id',Code varchar(80) '$.code',Name nvarchar(150) '$.name',Title nvarchar(250) '$.title',Description nvarchar(1000) '$.description',TemplateId varchar(32) '$.templateId',AlertType nvarchar(150) '$.alertType',GroupByFieldsJson nvarchar(max) '$.groupByFieldsJson',MetricsJson nvarchar(max) '$.metricsJson',GridColumnsJson nvarchar(max) '$.gridColumnsJson',SearchFieldsJson nvarchar(max) '$.searchFieldsJson',PageSize int '$.pageSize',DisplayOrder int '$.displayOrder',IsDefault bit '$.isDefault',IsActive bit '$.isActive'))q ON t.Id=q.Id
  WHEN MATCHED THEN UPDATE SET Code=q.Code,Name=q.Name,Title=q.Title,Description=COALESCE(q.Description,''),TemplateId=q.TemplateId,AlertType=COALESCE(q.AlertType,''),GroupByFieldsJson=q.GroupByFieldsJson,MetricsJson=q.MetricsJson,GridColumnsJson=q.GridColumnsJson,SearchFieldsJson=q.SearchFieldsJson,PageSize=q.PageSize,DisplayOrder=q.DisplayOrder,IsDefault=q.IsDefault,IsActive=q.IsActive,UpdatedAtUtc=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT(Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive) VALUES(q.Id,q.Code,q.Name,q.Title,COALESCE(q.Description,''),q.TemplateId,COALESCE(q.AlertType,''),q.GroupByFieldsJson,q.MetricsJson,q.GridColumnsJson,q.SearchFieldsJson,q.PageSize,q.DisplayOrder,q.IsDefault,q.IsActive);
  DECLARE @SavedDashboardId varchar(32)=JSON_VALUE(@JsonInput,'$.id'); DELETE FROM dbo.TemplateDashboardRoleMapping WHERE DashboardId=@SavedDashboardId;
  INSERT dbo.TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) SELECT @SavedDashboardId,[value],1 FROM OPENJSON(@JsonInput,'$.roleCodes') WHERE NULLIF([value],'') IS NOT NULL;
  COMMIT; RETURN;
 END
 IF @Operation='GetTemplateDashboardAlerts' BEGIN
  DECLARE @DTTemplateId varchar(32)=JSON_VALUE(@JsonInput,'$.templateId'),@DTAlertType nvarchar(150)=JSON_VALUE(@JsonInput,'$.alertType'),@DTUserBranch varchar(60)=JSON_VALUE(@JsonInput,'$.userBranchCode'),@DTRoleCode varchar(60)=JSON_VALUE(@JsonInput,'$.roleCode'),@DTCanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@JsonInput,'$.canViewAll'));
  SELECT TOP(5000) a.Id,a.AlertNo,a.TemplateId,a.AlertType,a.BranchCode,a.CustomerIdEncrypted,a.AccountIdEncrypted,a.Status,a.CurrentStageName,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc,a.DynamicDataJson
  FROM dbo.Alerts a WHERE a.TemplateId=@DTTemplateId AND (NULLIF(@DTAlertType,'') IS NULL OR a.AlertType=@DTAlertType) AND (@DTCanViewAll=1 OR a.BranchCode=@DTUserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND (wi.AssignedUserId=@UserId OR (wi.AssignedRoleCode=@DTRoleCode AND (wi.AssignedBranchCode='' OR wi.AssignedBranchCode=@DTUserBranch))))) ORDER BY a.CreatedAtUtc DESC; RETURN;
 END
 IF @Operation='GetConnectors' BEGIN SELECT Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive FROM dbo.IngestionConnector ORDER BY Name; RETURN; END
 IF @Operation='SaveConnector' BEGIN
  MERGE dbo.IngestionConnector t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32),Name nvarchar(150),ConnectorType varchar(30),Host nvarchar(300),Port int,DatabaseName nvarchar(200),UserName nvarchar(200),SecretEncrypted nvarchar(2000),ExtraJson nvarchar(max),IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ConnectorType=s.ConnectorType,Host=s.Host,Port=s.Port,DatabaseName=s.DatabaseName,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,ExtraJson=s.ExtraJson,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive)VALUES(s.Id,s.Name,s.ConnectorType,s.Host,s.Port,s.DatabaseName,s.UserName,s.SecretEncrypted,s.ExtraJson,s.IsActive); RETURN;
 END
 IF @Operation='GetIngestionConfigurations' BEGIN SELECT Id,Name,TemplateId,SourceType,ConnectorId,FilePattern,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive FROM dbo.IngestionConfiguration ORDER BY Name; RETURN; END
 IF @Operation='SaveIngestionConfiguration' BEGIN
  MERGE dbo.IngestionConfiguration t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32),Name nvarchar(150),TemplateId varchar(32),SourceType varchar(30),ConnectorId varchar(32),FilePattern nvarchar(260),ScheduleCron varchar(100),QueryText nvarchar(max),FieldMappingJson nvarchar(max),DuplicateKeyFields nvarchar(500),ArchivePath nvarchar(500),ErrorPath nvarchar(500),IntervalMinutes int,IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,TemplateId=s.TemplateId,SourceType=s.SourceType,ConnectorId=s.ConnectorId,FilePattern=s.FilePattern,ScheduleCron=s.ScheduleCron,QueryText=s.QueryText,FieldMappingJson=s.FieldMappingJson,DuplicateKeyFields=s.DuplicateKeyFields,ArchivePath=s.ArchivePath,ErrorPath=s.ErrorPath,IntervalMinutes=s.IntervalMinutes,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,TemplateId,SourceType,ConnectorId,FilePattern,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive)VALUES(s.Id,s.Name,s.TemplateId,s.SourceType,s.ConnectorId,s.FilePattern,s.ScheduleCron,s.QueryText,s.FieldMappingJson,s.DuplicateKeyFields,s.ArchivePath,s.ErrorPath,s.IntervalMinutes,s.IsActive); RETURN;
 END
 IF @Operation='GetIngestionDashboard' BEGIN SELECT (SELECT COUNT(*) FROM dbo.IngestionConfiguration WHERE IsActive=1)ActiveConfigurations,COUNT(*)RunsToday,COALESCE(SUM(CASE WHEN Status='Success' THEN 1 ELSE 0 END),0)SuccessfulToday,COALESCE(SUM(CASE WHEN Status='Failed' THEN 1 ELSE 0 END),0)FailedToday,COALESCE(SUM(RowsInserted),0)RowsInsertedToday FROM dbo.IngestionRun WHERE StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()); RETURN; END
 IF @Operation='GetIngestionRuns' BEGIN DECLARE @Take int=CONVERT(int,JSON_VALUE(@JsonInput,'$.take')); SELECT TOP(@Take) Id,ConfigurationId,SourceReference,StartedAtUtc,EndedAtUtc,RowsRead,RowsInserted,RowsDuplicate,RowsFailed,Status,ErrorMessage FROM dbo.IngestionRun ORDER BY StartedAtUtc DESC; RETURN; END
 IF @Operation='GetMailConfigurations' BEGIN SELECT Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive FROM dbo.MailConfiguration ORDER BY Name; RETURN; END
 IF @Operation='SaveMailConfiguration' BEGIN
  MERGE dbo.MailConfiguration t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32),Name nvarchar(150),ProviderType varchar(30),Host nvarchar(300),Port int,UserName nvarchar(200),SecretEncrypted nvarchar(2000),FromAddress nvarchar(300),UseSsl int,IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ProviderType=s.ProviderType,Host=s.Host,Port=s.Port,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,FromAddress=s.FromAddress,UseSsl=s.UseSsl,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive)VALUES(s.Id,s.Name,s.ProviderType,s.Host,s.Port,s.UserName,s.SecretEncrypted,s.FromAddress,s.UseSsl,s.IsActive); RETURN;
 END
 IF @Operation='GetMailTemplates' BEGIN SELECT Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive FROM dbo.MailTemplate ORDER BY EventCode; RETURN; END
 IF @Operation='GetMailLogs' BEGIN DECLARE @MailTake int=CONVERT(int,JSON_VALUE(@JsonInput,'$.take')); SELECT TOP(@MailTake) Id,EventCode,AlertId,ToAddress,Subject,Status,Attempts,CreatedAtUtc,SentAtUtc,ErrorMessage FROM dbo.MailQueue ORDER BY CreatedAtUtc DESC; RETURN; END
 IF @Operation='SaveMailTemplate' BEGIN
  MERGE dbo.MailTemplate t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32) '$.id',TemplateId varchar(32) '$.templateId',EventCode varchar(80) '$.eventCode',SubjectTemplate nvarchar(500) '$.subjectTemplate',BodyTemplate nvarchar(max) '$.bodyTemplate',UseMafEnrichment bit '$.useMafEnrichment',IsActive bit '$.isActive'))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET TemplateId=s.TemplateId,EventCode=s.EventCode,SubjectTemplate=s.SubjectTemplate,BodyTemplate=s.BodyTemplate,UseMafEnrichment=COALESCE(s.UseMafEnrichment,0),IsActive=COALESCE(s.IsActive,1) WHEN NOT MATCHED THEN INSERT(Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive)VALUES(s.Id,s.TemplateId,s.EventCode,s.SubjectTemplate,s.BodyTemplate,COALESCE(s.UseMafEnrichment,0),COALESCE(s.IsActive,1)); RETURN;
 END
 IF @Operation IN('GetReport','GetReportCount') BEGIN
  DECLARE @ReportType varchar(20)=JSON_VALUE(@JsonInput,'$.reportType'),@TemplateId varchar(32)=JSON_VALUE(@JsonInput,'$.templateId'),@AlertType nvarchar(150)=JSON_VALUE(@JsonInput,'$.alertType'),@FilterBranch varchar(60)=JSON_VALUE(@JsonInput,'$.branchCode'),@UserBranch varchar(60)=JSON_VALUE(@JsonInput,'$.userBranchCode'),@Status varchar(30)=JSON_VALUE(@JsonInput,'$.status'),@FromDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@JsonInput,'$.fromDate')),@ToDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@JsonInput,'$.toDate')),@Page int=CONVERT(int,JSON_VALUE(@JsonInput,'$.page')),@PageSize int=CONVERT(int,JSON_VALUE(@JsonInput,'$.pageSize')),@CanViewAll bit=CONVERT(bit,JSON_VALUE(@JsonInput,'$.canViewAll'));
  IF @Operation='GetReportCount' BEGIN SELECT COUNT(*) FROM dbo.Alerts a WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId)) AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId) AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType) AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch) AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status) AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate) AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate))); RETURN; END
  IF UPPER(@ReportType)='MIS' SELECT a.AlertType,a.Status,COUNT(*) Total FROM dbo.Alerts a WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId)) AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId) AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType) AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch) AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status) AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate) AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate))) GROUP BY a.AlertType,a.Status ORDER BY a.AlertType,a.Status;
  ELSE SELECT a.AlertNo,a.AlertType,t.Name TemplateName,a.BranchCode,a.CurrentStageName,a.Status,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc FROM dbo.Alerts a JOIN dbo.Templates t ON t.Id=a.TemplateId WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId)) AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId) AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType) AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch) AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status) AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate) AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate))) ORDER BY a.CreatedAtUtc DESC OFFSET (@Page-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY; RETURN;
 END
 ;THROW 50000,'Unsupported platform repository operation.',1;
END
GO

MERGE dbo.PermissionMaster AS t USING (VALUES
 ('TEMPLATE.MANAGE','Manage templates','Templates'),('WORKFLOW.MANAGE','Manage workflows','Workflow'),('ALERT.UPLOAD','Create/upload alerts','Alerts'),('ALERT.VIEWALL','View all scoped alerts','Alerts'),('ALERT.REASSIGN','Reassign alerts','Alerts'),('PII.UNMASK','Unmask PI data','Security'),('AUDIT.VIEW','View audit trail','Audit'),('DASHBOARD.VIEW','View dashboard','Dashboard'),('DASHBOARD.CONFIGURE','Configure dashboard','Dashboard'),('INGESTION.VIEW','View ingestion','Ingestion'),('INGESTION.MANAGE','Manage ingestion','Ingestion'),('REPORT.MIS','MIS report','Reports'),('REPORT.ALERTWISE','Alert wise report','Reports'),('REPORT.ALL','All alerts report','Reports'),('MAIL.MANAGE','Manage mail','Mail'),('SECURITY.MANAGE','Manage roles/permissions/data scopes','Security')
) s(Code,Name,Category) ON t.Code=s.Code WHEN NOT MATCHED THEN INSERT(Code,Name,Category,IsActive) VALUES(s.Code,s.Name,s.Category,1);
GO

/* Default role permissions are database configuration, not code bypasses. */
MERGE dbo.RolePermissionMapping AS t USING (VALUES
 ('ADMIN','TEMPLATE.MANAGE'),('ADMIN','WORKFLOW.MANAGE'),('ADMIN','ALERT.UPLOAD'),('ADMIN','ALERT.VIEWALL'),('ADMIN','ALERT.REASSIGN'),('ADMIN','PII.UNMASK'),('ADMIN','AUDIT.VIEW'),('ADMIN','DASHBOARD.VIEW'),('ADMIN','DASHBOARD.CONFIGURE'),('ADMIN','INGESTION.VIEW'),('ADMIN','INGESTION.MANAGE'),('ADMIN','REPORT.MIS'),('ADMIN','REPORT.ALERTWISE'),('ADMIN','REPORT.ALL'),('ADMIN','MAIL.MANAGE'),('ADMIN','SECURITY.MANAGE'),
 ('CENTRAL','TEMPLATE.MANAGE'),('CENTRAL','WORKFLOW.MANAGE'),('CENTRAL','ALERT.UPLOAD'),('CENTRAL','ALERT.VIEWALL'),('CENTRAL','ALERT.REASSIGN'),('CENTRAL','AUDIT.VIEW'),('CENTRAL','DASHBOARD.VIEW'),('CENTRAL','DASHBOARD.CONFIGURE'),('CENTRAL','INGESTION.VIEW'),('CENTRAL','INGESTION.MANAGE'),('CENTRAL','REPORT.MIS'),('CENTRAL','REPORT.ALERTWISE'),('CENTRAL','REPORT.ALL'),('CENTRAL','MAIL.MANAGE'),
 ('DT_USER','DASHBOARD.VIEW'),('DT_CHECKER','AUDIT.VIEW'),('DT_CHECKER','DASHBOARD.VIEW'),('DT_VERIFIER','AUDIT.VIEW'),('DT_VERIFIER','DASHBOARD.VIEW'),('AUDITOR','ALERT.VIEWALL'),('AUDITOR','AUDIT.VIEW'),('AUDITOR','DASHBOARD.VIEW'),('AUDITOR','REPORT.MIS'),('AUDITOR','REPORT.ALERTWISE'),('AUDITOR','REPORT.ALL')
) s(RoleCode,PermissionCode) ON t.RoleCode=s.RoleCode AND t.PermissionCode=s.PermissionCode
WHEN NOT MATCHED THEN INSERT(RoleCode,PermissionCode,IsActive) VALUES(s.RoleCode,s.PermissionCode,1);
GO
/* Preserve existing per-user permissions by migrating CatsUsers.PermissionsJson into the DB mapping. */
INSERT dbo.UserPermissionMapping(UserId,PermissionCode,IsActive)
SELECT u.Id,j.[value],1 FROM dbo.CatsUsers u CROSS APPLY OPENJSON(COALESCE(u.PermissionsJson,N'[]')) j
JOIN dbo.PermissionMaster p ON p.Code=j.[value] AND p.IsActive=1
WHERE NOT EXISTS(SELECT 1 FROM dbo.UserPermissionMapping x WHERE x.UserId=u.Id AND x.PermissionCode=j.[value]);
GO
MERGE dbo.DataScopeMaster AS t USING (VALUES
 ('scope-admin-all','ADMIN','ALL','',1),('scope-central-all','CENTRAL','ALL','',1),('scope-dtuser-branch','DT_USER','BRANCH','',10),('scope-checker-branch','DT_CHECKER','BRANCH','',10),('scope-verifier-branch','DT_VERIFIER','BRANCH','',10),('scope-auditor-all','AUDITOR','ALL','',10)
) s(Id,RoleCode,ScopeType,ScopeValue,Priority) ON t.Id=s.Id
WHEN NOT MATCHED THEN INSERT(Id,RoleCode,ScopeType,ScopeValue,Priority,IsActive) VALUES(s.Id,s.RoleCode,s.ScopeType,s.ScopeValue,s.Priority,1);
GO



IF NOT EXISTS(SELECT 1 FROM dbo.TemplateDashboardMaster)
   AND EXISTS(SELECT 1 FROM dbo.Templates WHERE Status='Published')
BEGIN
    DECLARE @SeedTemplateId varchar(32)=(SELECT TOP(1) Id FROM dbo.Templates WHERE Status='Published' ORDER BY CreatedAtUtc,Id);
    INSERT dbo.TemplateDashboardMaster(Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive)
    VALUES('tpldash-default','TEMPLATE_DEFAULT','Template Operations','Template Alert Dashboard',N'Template-specific operational dashboard. Users with DASHBOARD.CONFIGURE can modify it without code changes.',@SeedTemplateId,N'',N'["BranchCode"]',N'[{"key":"TOTAL","label":"Total","type":"Total"},{"key":"CLOSED","label":"Closed","type":"StatusEquals","value":"Closed"},{"key":"PENDING","label":"Pending","type":"StatusNotIn","values":["Closed","Rejected","Cancelled"]},{"key":"AGING31","label":"31+ Days","type":"StageAgeFrom","number":31}]',N'["AlertNo","AccountId","CustomerId","AlertType","BranchCode","Status","CurrentStageName","StageAgingDays"]',N'["AlertNo","AccountId","CustomerId","AlertType","BranchCode"]',20,1,1,1);
    IF EXISTS(SELECT 1 FROM dbo.RoleMaster WHERE Code='ADMIN') AND NOT EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping WHERE DashboardId='tpldash-default' AND RoleCode='ADMIN') INSERT dbo.TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) VALUES('tpldash-default','ADMIN',1);
    IF EXISTS(SELECT 1 FROM dbo.RoleMaster WHERE Code='CENTRAL') AND NOT EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping WHERE DashboardId='tpldash-default' AND RoleCode='CENTRAL') INSERT dbo.TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) VALUES('tpldash-default','CENTRAL',1);
END
GO
PRINT 'CATS V3 Template Dashboard FIXED upgrade completed successfully.';
GO


/* ================= CATS V4 modular repository architecture ================= */

/* CATS V4 - Common ADO repository dispatcher and modular stored procedures
   Prerequisite: existing CATS V3 database. Safe to rerun.
   New application code calls dbo.usp_CommonRepository only.
   Existing dbo.usp_CatsRepository / dbo.usp_PlatformRepository are retained as compatibility routers.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* CATS V4 - Common dispatcher and core repository modules */

/* =====================================================================================
   CATS V4 - Common repository dispatcher
   ADO.NET calls only this procedure. It resolves:
       USP_<ModuleCode>_<MethodCode>
   Every leaf procedure accepts exactly one input parameter:
       @strJson nvarchar(max)
   ===================================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_CommonRepository
    @ModuleCode nvarchar(60) = NULL,
    @MethodCode nvarchar(80),
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @ModuleCode = LTRIM(RTRIM(COALESCE(@ModuleCode,N'')));
    SET @MethodCode = LTRIM(RTRIM(COALESCE(@MethodCode,N'')));
    SET @strJson = COALESCE(@strJson,N'{}');

    IF @MethodCode = N''
        THROW 50000, 'Invalid method.', 1;

    IF ISJSON(@strJson) <> 1
        THROW 50001, 'strJson must be valid JSON.', 1;

    -- Only simple identifier characters are allowed. This protects the dynamic EXEC.
    IF (@ModuleCode <> N'' AND PATINDEX(N'%[^A-Za-z0-9_]%', @ModuleCode COLLATE Latin1_General_100_BIN2) > 0)
       OR PATINDEX(N'%[^A-Za-z0-9_]%', @MethodCode COLLATE Latin1_General_100_BIN2) > 0
        THROW 50002, 'Invalid module or method code.', 1;

    DECLARE @procName sysname =
        CASE WHEN @ModuleCode = N''
             THEN N'USP_' + @MethodCode
             ELSE N'USP_' + @ModuleCode + N'_' + @MethodCode
        END;

    IF OBJECT_ID(N'dbo.' + @procName, N'P') IS NULL
        THROW 50003, 'Unsupported repository operation.', 1;

    DECLARE @sql nvarchar(max) =
        N'EXEC dbo.' + QUOTENAME(@procName) + N' @strJson = @JSON;';

    EXEC sys.sp_executesql
        @sql,
        N'@JSON nvarchar(max)',
        @JSON = @strJson;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_User_GetByUserName
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive
        FROM dbo.CatsUsers
        WHERE UPPER(UserName)=UPPER(@UserName);
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_User_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive
        FROM dbo.CatsUsers
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_User_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive
        FROM dbo.CatsUsers
        ORDER BY UserName;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_User_Upsert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        IF COALESCE(@IsNew,0)=1
        BEGIN
            INSERT INTO dbo.CatsUsers(Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive)
            VALUES(@Id,@UserName,@DisplayName,@PasswordHash,@RoleCode,@DepartmentCode,@BranchCode,@PermissionsJson,CASE WHEN @IsActive=1 THEN 1 ELSE 0 END);
            SET @AffectedRows=@@ROWCOUNT;
        END
        ELSE
        BEGIN
            UPDATE dbo.CatsUsers
            SET UserName=@UserName,DisplayName=@DisplayName,PasswordHash=@PasswordHash,RoleCode=@RoleCode,
                DepartmentCode=@DepartmentCode,BranchCode=@BranchCode,PermissionsJson=@PermissionsJson,
                IsActive=CASE WHEN @IsActive=1 THEN 1 ELSE 0 END
            WHERE Id=@Id;
            SET @AffectedRows=@@ROWCOUNT;
        END;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
               PublishedWorkflowId,CreatedAtUtc,CreatedBy
        FROM dbo.Templates
        ORDER BY Name,Version DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
               PublishedWorkflowId,CreatedAtUtc,CreatedBy
        FROM dbo.Templates
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        IF NULLIF(LTRIM(RTRIM(@Id)), '') IS NOT NULL
           AND EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id AND Status='Draft')
        BEGIN
            UPDATE dbo.Templates
            SET Code=@Code,Name=@Name,ExecutionMode=@ExecutionMode,SectionsJson=@SectionsJson,
                FieldsJson=@FieldsJson,AssignmentRulesJson=COALESCE(@AssignmentRulesJson,N'[]')
            WHERE Id=@Id AND Status='Draft';
            SET @NewId=CONVERT(varchar(32),@Id);
        END
        ELSE
        BEGIN
            SELECT @NextVersion=COALESCE(MAX(Version),0)+1
            FROM dbo.Templates
            WHERE UPPER(Code)=UPPER(@Code);

            SET @NewId=LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-',''));
            INSERT INTO dbo.Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,
                                      AssignmentRulesJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy)
            VALUES(@NewId,@Code,@Name,@NextVersion,'Draft',@ExecutionMode,@SectionsJson,@FieldsJson,
                   COALESCE(@AssignmentRulesJson,N'[]'),NULL,@NowUtc,@CreatedBy);
        END;

        SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
               PublishedWorkflowId,CreatedAtUtc,CreatedBy
        FROM dbo.Templates
        WHERE Id=@NewId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Workflow_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy
        FROM dbo.WorkflowDefinitions
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Workflow_GetPublishedByTemplate
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT TOP (1) Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy
        FROM dbo.WorkflowDefinitions
        WHERE TemplateId=@TemplateId AND IsPublished=1
        ORDER BY Version DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Workflow_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        BEGIN TRY
            BEGIN TRANSACTION;

            SELECT @NextVersion=COALESCE(MAX(Version),0)+1
            FROM dbo.WorkflowDefinitions
            WHERE TemplateId=@TemplateId;

            SET @NewId=LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-',''));

            IF COALESCE(@Publish,0)=1
                UPDATE dbo.WorkflowDefinitions SET IsPublished=0 WHERE TemplateId=@TemplateId;

            INSERT INTO dbo.WorkflowDefinitions(Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy)
            VALUES(@NewId,@TemplateId,@NextVersion,@Name,@DefinitionJson,CASE WHEN @Publish=1 THEN 1 ELSE 0 END,@NowUtc,@CreatedBy);

            IF COALESCE(@Publish,0)=1
            BEGIN
                UPDATE dbo.Templates
                SET Status='Retired'
                WHERE Id<>@TemplateId
                  AND UPPER(Code)=(SELECT UPPER(Code) FROM dbo.Templates WHERE Id=@TemplateId)
                  AND Status='Published';

                UPDATE dbo.Templates
                SET PublishedWorkflowId=@NewId,Status='Published'
                WHERE Id=@TemplateId;
            END;

            COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
            THROW;
        END CATCH;

        SELECT Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy
        FROM dbo.WorkflowDefinitions
        WHERE Id=@NewId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.Alerts(Id,AlertNo,TemplateId,TemplateVersion,AlertType,BranchCode,CustomerIdEncrypted,
                               AccountIdEncrypted,DynamicDataJson,Status,CurrentStageId,CurrentStageName,
                               CreatedAtUtc,StageEnteredAtUtc,CreatedBy,Priority)
        VALUES(@Id,@AlertNo,@TemplateId,@TemplateVersion,@AlertType,@BranchCode,@CustomerIdEncrypted,
               @AccountIdEncrypted,@DynamicDataJson,@Status,@CurrentStageId,@CurrentStageName,
               @CreatedAtUtc,@StageEnteredAtUtc,@CreatedBy,@Priority);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.WorkflowInstances(Id,AlertId,WorkflowDefinitionId,WorkflowVersion,Status,CurrentStageId,StartedAtUtc,UpdatedAtUtc)
        VALUES(@Id,@AlertId,@WorkflowDefinitionId,@WorkflowVersion,@Status,@CurrentStageId,@StartedAtUtc,@UpdatedAtUtc);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_Update
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkflowInstances
        SET Status=@Status,CurrentStageId=@CurrentStageId,UpdatedAtUtc=@UpdatedAtUtc
        WHERE Id=@Id;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_TryClaimStageTransition
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkflowInstances
        SET Status='Transitioning',UpdatedAtUtc=@NowUtc
        WHERE Id=@InstanceId AND Status='Running' AND CurrentStageId=@ExpectedStageId;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT CAST(CASE WHEN @AffectedRows=1 THEN 1 ELSE 0 END AS bit) AS Claimed,
               @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_ReleaseStageTransitionClaim
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkflowInstances
        SET Status='Running',UpdatedAtUtc=@NowUtc
        WHERE Id=@InstanceId AND Status='Transitioning' AND CurrentStageId=@ExpectedStageId;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_UpdateStage
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.Alerts
        SET CurrentStageId=@StageId,CurrentStageName=@StageName,Status=@Status,StageEnteredAtUtc=@EnteredAtUtc
        WHERE Id=@AlertId;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_UpdateDynamicData
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.Alerts SET DynamicDataJson=@DynamicDataJson WHERE Id=@AlertId;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertNo,TemplateId,TemplateVersion,AlertType,BranchCode,CustomerIdEncrypted,
               AccountIdEncrypted,DynamicDataJson,Status,CurrentStageId,CurrentStageName,
               CreatedAtUtc,StageEnteredAtUtc,CreatedBy,Priority
        FROM dbo.Alerts
        WHERE Id=@AlertId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_GetByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowDefinitionId,WorkflowVersion,Status,CurrentStageId,StartedAtUtc,UpdatedAtUtc
        FROM dbo.WorkflowInstances
        WHERE AlertId=@AlertId AND Status='Running';
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.WorkItems(Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,
                                  AssignedBranchCode,AssignedUserId,Status,ParallelGroupId,CompletedAction,
                                  CompletedBy,CreatedAtUtc,DueAtUtc,CompletedAtUtc,Remarks)
        SELECT w.Id,w.AlertId,w.WorkflowInstanceId,w.StageId,w.StageName,w.AssignedRoleCode,
               COALESCE(w.AssignedBranchCode,''),w.AssignedUserId,w.Status,w.ParallelGroupId,
               NULL,NULL,w.CreatedAtUtc,w.DueAtUtc,NULL,NULL
        FROM OPENJSON(@strJson,'$.items')
        WITH
        (
            Id varchar(32) '$.id',
            AlertId varchar(32) '$.alertId',
            WorkflowInstanceId varchar(32) '$.workflowInstanceId',
            StageId varchar(100) '$.stageId',
            StageName nvarchar(200) '$.stageName',
            AssignedRoleCode varchar(60) '$.assignedRoleCode',
            AssignedBranchCode varchar(60) '$.assignedBranchCode',
            AssignedUserId varchar(32) '$.assignedUserId',
            Status varchar(30) '$.status',
            ParallelGroupId varchar(32) '$.parallelGroupId',
            CreatedAtUtc datetime2(7) '$.createdAtUtc',
            DueAtUtc datetime2(7) '$.dueAtUtc'
        ) AS w;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_GetPending
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,
               AssignedUserId,Status,ParallelGroupId,CompletedAction,CompletedBy,CreatedAtUtc,DueAtUtc,
               CompletedAtUtc,Remarks
        FROM dbo.WorkItems
        WHERE AlertId=@AlertId AND Status='Pending'
        ORDER BY CreatedAtUtc;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,
               AssignedUserId,Status,ParallelGroupId,CompletedAction,CompletedBy,CreatedAtUtc,DueAtUtc,
               CompletedAtUtc,Remarks
        FROM dbo.WorkItems
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_GetAllByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,
               AssignedUserId,Status,ParallelGroupId,CompletedAction,CompletedBy,CreatedAtUtc,DueAtUtc,
               CompletedAtUtc,Remarks
        FROM dbo.WorkItems
        WHERE AlertId=@AlertId
        ORDER BY CreatedAtUtc;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_Complete
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkItems
        SET Status='Completed',CompletedAction=@Action,CompletedBy=@CompletedBy,
            CompletedAtUtc=@NowUtc,Remarks=@Remarks
        WHERE Id=@Id AND Status='Pending';
        SET @AffectedRows=@@ROWCOUNT;
        IF @AffectedRows<>1
            THROW 50001, 'Work item has already been completed by another user.', 1;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_ReassignPending
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        IF NULLIF(LTRIM(RTRIM(COALESCE(@RoleCode,''))), '') IS NULL
           AND NULLIF(LTRIM(RTRIM(COALESCE(@UserId,''))), '') IS NULL
            THROW 50002, 'RoleCode or UserId is required for reassignment.', 1;

        UPDATE dbo.WorkItems
        SET AssignedRoleCode=COALESCE(@RoleCode,''),AssignedBranchCode=COALESCE(@BranchCode,''),AssignedUserId=@UserId
        WHERE AlertId=@AlertId AND StageId=@StageId AND Status='Pending';
        SET @AffectedRows=@@ROWCOUNT;
        IF @AffectedRows=0
            THROW 50003, 'No pending work item was found for the selected stage.', 1;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_CancelPending
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkItems
        SET Status='Cancelled'
        WHERE AlertId=@AlertId
          AND Status='Pending'
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@GroupId,''))), '') IS NULL OR ParallelGroupId=@GroupId);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_GetParallel
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,
               AssignedUserId,Status,ParallelGroupId,CompletedAction,CompletedBy,CreatedAtUtc,DueAtUtc,
               CompletedAtUtc,Remarks
        FROM dbo.WorkItems
        WHERE AlertId=@AlertId AND ParallelGroupId=@ParallelGroupId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Query_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.AlertQueries(Id,AlertId,RaisedBy,RaisedToRole,QueryText,ResponseText,Status,RaisedAtUtc,RespondedAtUtc)
        VALUES(@Id,@AlertId,@RaisedBy,@RaisedToRole,@QueryText,NULL,@Status,@RaisedAtUtc,NULL);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Query_RespondLatestOpen
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT TOP (1) @QueryId=Id
        FROM dbo.AlertQueries
        WHERE AlertId=@AlertId AND Status='Open'
        ORDER BY RaisedAtUtc DESC;

        IF @QueryId IS NOT NULL
        BEGIN
            UPDATE dbo.AlertQueries
            SET ResponseText=@ResponseText,Status='Responded',RespondedAtUtc=@NowUtc
            WHERE Id=@QueryId;
            SET @AffectedRows=@@ROWCOUNT;
        END;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Query_GetAllByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,RaisedBy,RaisedToRole,QueryText,ResponseText,Status,RaisedAtUtc,RespondedAtUtc
        FROM dbo.AlertQueries
        WHERE AlertId=@AlertId
        ORDER BY RaisedAtUtc DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Attachment_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.Attachments(Id,AlertId,StageId,FileName,StoredName,ContentType,FileSize,Sha256,Version,UploadedBy,UploadedAtUtc)
        VALUES(@Id,@AlertId,@StageId,@FileName,@StoredName,@ContentType,@FileSize,@Sha256,@Version,@UploadedBy,@UploadedAtUtc);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Attachment_GetAllByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,StageId,FileName,StoredName,ContentType,FileSize,Sha256,Version,UploadedBy,UploadedAtUtc
        FROM dbo.Attachments
        WHERE AlertId=@AlertId
        ORDER BY UploadedAtUtc DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Attachment_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,StageId,FileName,StoredName,ContentType,FileSize,Sha256,Version,UploadedBy,UploadedAtUtc
        FROM dbo.Attachments
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Audit_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.AuditLog(Id,AlertId,UserId,UserName,RoleCode,Action,EntityType,EntityId,StageId,
                                 PreviousValueJson,NewValueJson,Remarks,IpAddress,CreatedAtUtc)
        VALUES(@Id,@AlertId,@UserId,@UserName,@RoleCode,@Action,@EntityType,@EntityId,@StageId,
               @PreviousValueJson,@NewValueJson,@Remarks,@IpAddress,@CreatedAtUtc);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Audit_GetByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SET @Take=COALESCE(@Take,100);
        IF @Take<1 SET @Take=1;
        IF @Take>500 SET @Take=500;

        SELECT TOP (@Take) Id,AlertId,UserId,UserName,RoleCode,Action,EntityType,EntityId,StageId,
                           PreviousValueJson,NewValueJson,Remarks,IpAddress,CreatedAtUtc
        FROM dbo.AuditLog
        WHERE AlertId=@AlertId
        ORDER BY CreatedAtUtc DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Aging_GetBuckets
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,Name,FromDays,ToDays,DisplayOrder
        FROM dbo.AgingBuckets
        WHERE IsActive=1
        ORDER BY DisplayOrder;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Aging_SaveBucket
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        IF NULLIF(LTRIM(RTRIM(COALESCE(@Name,N''))), N'') IS NULL
            THROW 50004, 'Aging bucket name is required.', 1;
        IF COALESCE(@FromDays,-1)<0 OR (@ToDays IS NOT NULL AND @ToDays<@FromDays)
            THROW 50005, 'Invalid aging range.', 1;

        IF COALESCE(@IsNew,0)=1
        BEGIN
            INSERT INTO dbo.AgingBuckets(Id,Name,FromDays,ToDays,DisplayOrder,IsActive)
            VALUES(@Id,LTRIM(RTRIM(@Name)),@FromDays,@ToDays,@DisplayOrder,CASE WHEN @IsActive=1 THEN 1 ELSE 0 END);
        END
        ELSE
        BEGIN
            UPDATE dbo.AgingBuckets
            SET Name=LTRIM(RTRIM(@Name)),FromDays=@FromDays,ToDays=@ToDays,DisplayOrder=@DisplayOrder,
                IsActive=CASE WHEN @IsActive=1 THEN 1 ELSE 0 END
            WHERE Id=@Id;
        END;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetAging
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT a.TemplateId,t.Name AS TemplateName,a.AlertType,a.StageEnteredAtUtc
        FROM dbo.Alerts AS a
        INNER JOIN dbo.Templates AS t ON t.Id=a.TemplateId
        WHERE a.Status NOT IN ('Closed','Cancelled','Rejected')
          AND
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId
                    )
              )
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status);
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_GetCount
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT COUNT(1) AS TotalRecords
        FROM dbo.Alerts AS a
        WHERE
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId
                    )
              )
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status)
          AND (@AgingFrom IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=@AgingFrom)
          AND (@AgingTo IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())<=@AgingTo)
          AND
          (
              NULLIF(LTRIM(RTRIM(COALESCE(@Search,N''))),N'') IS NULL
              OR UPPER(a.AlertNo) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.AlertType) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.BranchCode) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
          );
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_GetPaged
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SET @Page=COALESCE(@Page,1);
        IF @Page<1 SET @Page=1;
        SET @PageSize=COALESCE(@PageSize,20);
        IF @PageSize<10 SET @PageSize=10;
        IF @PageSize>100 SET @PageSize=100;

        SELECT a.Id,a.AlertNo,t.Name AS TemplateName,a.AlertType,a.BranchCode,
               a.CustomerIdEncrypted,a.AccountIdEncrypted,a.CurrentStageName,a.Status,a.Priority,
               DATEDIFF(day,a.CreatedAtUtc,SYSUTCDATETIME()) AS OverallAge,
               DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME()) AS StageAge
        FROM dbo.Alerts AS a
        INNER JOIN dbo.Templates AS t ON t.Id=a.TemplateId
        WHERE
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId
                    )
              )
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status)
          AND (@AgingFrom IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=@AgingFrom)
          AND (@AgingTo IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())<=@AgingTo)
          AND
          (
              NULLIF(LTRIM(RTRIM(COALESCE(@Search,N''))),N'') IS NULL
              OR UPPER(a.AlertNo) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.AlertType) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.BranchCode) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
          )
        ORDER BY a.StageEnteredAtUtc DESC
        OFFSET ((@Page-1)*@PageSize) ROWS FETCH NEXT @PageSize ROWS ONLY;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetName
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Name FROM dbo.Templates WHERE Id=@TemplateId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetRoleCodes
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT DISTINCT RoleCode
        FROM dbo.CatsUsers
        WHERE IsActive=1
        ORDER BY RoleCode;
        RETURN;
END
GO

/* Backward-compatible wrapper. New C# code does not call this procedure directly. */
CREATE OR ALTER PROCEDURE dbo.usp_CatsRepository
    @Operation nvarchar(100),
    @JsonInput nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ModuleCode nvarchar(60), @MethodCode nvarchar(80);

    SELECT @ModuleCode=v.ModuleCode,@MethodCode=v.MethodCode
    FROM (VALUES
        (N'GetUserByUserName',N'User',N'GetByUserName'),
        (N'GetUserById',N'User',N'GetById'),
        (N'GetUsers',N'User',N'GetAll'),
        (N'UpsertUser',N'User',N'Upsert'),
        (N'GetTemplates',N'Template',N'GetAll'),
        (N'GetTemplate',N'Template',N'GetById'),
        (N'SaveTemplate',N'Template',N'Save'),
        (N'GetWorkflow',N'Workflow',N'GetById'),
        (N'GetPublishedWorkflowForTemplate',N'Workflow',N'GetPublishedByTemplate'),
        (N'SaveWorkflow',N'Workflow',N'Save'),
        (N'InsertAlert',N'Alert',N'Insert'),
        (N'InsertWorkflowInstance',N'WorkflowInstance',N'Insert'),
        (N'UpdateWorkflowInstance',N'WorkflowInstance',N'Update'),
        (N'TryClaimStageTransition',N'WorkflowInstance',N'TryClaimStageTransition'),
        (N'ReleaseStageTransitionClaim',N'WorkflowInstance',N'ReleaseStageTransitionClaim'),
        (N'UpdateAlertStage',N'Alert',N'UpdateStage'),
        (N'UpdateAlertDynamicData',N'Alert',N'UpdateDynamicData'),
        (N'GetAlert',N'Alert',N'GetById'),
        (N'GetWorkflowInstanceByAlert',N'WorkflowInstance',N'GetByAlert'),
        (N'InsertWorkItems',N'WorkItem',N'Insert'),
        (N'GetPendingWorkItems',N'WorkItem',N'GetPending'),
        (N'GetWorkItem',N'WorkItem',N'GetById'),
        (N'GetWorkItems',N'WorkItem',N'GetAllByAlert'),
        (N'CompleteWorkItem',N'WorkItem',N'Complete'),
        (N'ReassignPendingWorkItems',N'WorkItem',N'ReassignPending'),
        (N'CancelPendingWorkItems',N'WorkItem',N'CancelPending'),
        (N'GetParallelWorkItems',N'WorkItem',N'GetParallel'),
        (N'InsertQuery',N'Query',N'Insert'),
        (N'RespondLatestOpenQuery',N'Query',N'RespondLatestOpen'),
        (N'GetQueries',N'Query',N'GetAllByAlert'),
        (N'InsertAttachment',N'Attachment',N'Insert'),
        (N'GetAttachments',N'Attachment',N'GetAllByAlert'),
        (N'GetAttachment',N'Attachment',N'GetById'),
        (N'InsertAudit',N'Audit',N'Insert'),
        (N'GetAudit',N'Audit',N'GetByAlert'),
        (N'GetAgingBuckets',N'Aging',N'GetBuckets'),
        (N'SaveAgingBucket',N'Aging',N'SaveBucket'),
        (N'GetDashboardAging',N'Dashboard',N'GetAging'),
        (N'GetAlertsCount',N'Alert',N'GetCount'),
        (N'GetAlerts',N'Alert',N'GetPaged'),
        (N'GetTemplateName',N'Template',N'GetName'),
        (N'GetRoleCodes',N'Security',N'GetRoleCodes')
    ) v(OperationCode,ModuleCode,MethodCode)
    WHERE v.OperationCode=@Operation;

    IF @MethodCode IS NULL
        THROW 50000, 'Unsupported legacy repository operation.', 1;

    EXEC dbo.usp_CommonRepository
        @ModuleCode=@ModuleCode,
        @MethodCode=@MethodCode,
        @strJson=@JsonInput;
END
GO

/* CATS V4 - Platform repository modules */

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetEffectivePermissions
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT DISTINCT rp.PermissionCode FROM dbo.CatsUsers u JOIN dbo.RolePermissionMapping rp ON rp.RoleCode=u.RoleCode AND rp.IsActive=1 JOIN dbo.PermissionMaster p ON p.Code=rp.PermissionCode AND p.IsActive=1 WHERE u.Id=@UserId AND u.IsActive=1
  UNION SELECT DISTINCT up.PermissionCode FROM dbo.UserPermissionMapping up JOIN dbo.PermissionMaster p ON p.Code=up.PermissionCode AND p.IsActive=1 WHERE up.UserId=@UserId AND up.IsActive=1; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetDataScopes
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT s.Id,s.RoleCode,s.ScopeType,s.ScopeValue,s.Priority,s.IsActive FROM dbo.DataScopeMaster s JOIN dbo.CatsUsers u ON u.RoleCode=s.RoleCode WHERE u.Id=@UserId AND s.IsActive=1 ORDER BY s.Priority; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetWidgets
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
;WITH P AS(SELECT [value] Code FROM OPENJSON(@strJson,'$.permissions')), W AS(
   SELECT w.Code,w.Title,w.WidgetType,w.DrillDownUrl,m.DisplayOrder,m.Width,
    CASE UPPER(w.Code)
     WHEN 'TEMPLATES' THEN (SELECT COUNT_BIG(*) FROM dbo.Templates WHERE Status='Published')
     WHEN 'INGESTION_FAILED' THEN (SELECT COUNT_BIG(*) FROM dbo.IngestionRun WHERE Status='Failed' AND StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()))
     WHEN 'ACTIVE_ALERTS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE a.Status NOT IN('Closed','Rejected','Cancelled') AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     WHEN 'AGING_31_PLUS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=31 AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     ELSE CONVERT(bigint,0) END Value
   FROM dbo.DashboardWidgetMaster w JOIN dbo.DashboardWidgetRoleMapping m ON m.WidgetId=w.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1
   WHERE w.IsActive=1 AND (w.PermissionCode='' OR EXISTS(SELECT 1 FROM P WHERE Code=w.PermissionCode)))
  SELECT * FROM W ORDER BY DisplayOrder; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetWidgetConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive FROM dbo.DashboardWidgetMaster ORDER BY DisplayOrder; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_SaveWidget
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
BEGIN TRAN;
  MERGE dbo.DashboardWidgetMaster t USING(SELECT * FROM OPENJSON(@strJson,'$.widget') WITH(Id varchar(32),Code varchar(80),Title nvarchar(150),WidgetType varchar(30),PermissionCode varchar(100),FilterJson nvarchar(max),DrillDownUrl nvarchar(500),DisplayOrder int,Width int,IsActive int))s ON t.Id=s.Id
  WHEN MATCHED THEN UPDATE SET Code=s.Code,Title=s.Title,WidgetType=s.WidgetType,PermissionCode=s.PermissionCode,FilterJson=s.FilterJson,DrillDownUrl=s.DrillDownUrl,DisplayOrder=s.DisplayOrder,Width=s.Width,IsActive=s.IsActive
  WHEN NOT MATCHED THEN INSERT(Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive)VALUES(s.Id,s.Code,s.Title,s.WidgetType,s.PermissionCode,s.FilterJson,s.DrillDownUrl,s.DisplayOrder,s.Width,s.IsActive);
  MERGE dbo.DashboardWidgetRoleMapping t USING(SELECT JSON_VALUE(@strJson,'$.widget.id') WidgetId,JSON_VALUE(@strJson,'$.roleCode') RoleCode,CONVERT(int,JSON_VALUE(@strJson,'$.widget.displayOrder')) DisplayOrder,CONVERT(int,JSON_VALUE(@strJson,'$.widget.width')) Width)s ON t.WidgetId=s.WidgetId AND t.RoleCode=s.RoleCode
  WHEN MATCHED THEN UPDATE SET DisplayOrder=s.DisplayOrder,Width=s.Width,IsVisible=1 WHEN NOT MATCHED THEN INSERT(WidgetId,RoleCode,DisplayOrder,Width,IsVisible)VALUES(s.WidgetId,s.RoleCode,s.DisplayOrder,s.Width,1); COMMIT; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @TDIncludeInactive bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.includeInactive'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d
  WHERE (@TDIncludeInactive=1 OR d.IsActive=1) AND (@TDIncludeInactive=1 OR EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))
  ORDER BY d.DisplayOrder,d.Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @TDId varchar(32)=JSON_VALUE(@strJson,'$.id'),@TDRequireManage bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.requireManage'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d WHERE d.Id=@TDId AND (@TDRequireManage=1 OR (d.IsActive=1 AND EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
BEGIN TRAN;
  MERGE dbo.TemplateDashboardMaster t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32) '$.id',Code varchar(80) '$.code',Name nvarchar(150) '$.name',Title nvarchar(250) '$.title',Description nvarchar(1000) '$.description',TemplateId varchar(32) '$.templateId',AlertType nvarchar(150) '$.alertType',GroupByFieldsJson nvarchar(max) '$.groupByFieldsJson',MetricsJson nvarchar(max) '$.metricsJson',GridColumnsJson nvarchar(max) '$.gridColumnsJson',SearchFieldsJson nvarchar(max) '$.searchFieldsJson',PageSize int '$.pageSize',DisplayOrder int '$.displayOrder',IsDefault bit '$.isDefault',IsActive bit '$.isActive'))q ON t.Id=q.Id
  WHEN MATCHED THEN UPDATE SET Code=q.Code,Name=q.Name,Title=q.Title,Description=COALESCE(q.Description,''),TemplateId=q.TemplateId,AlertType=COALESCE(q.AlertType,''),GroupByFieldsJson=q.GroupByFieldsJson,MetricsJson=q.MetricsJson,GridColumnsJson=q.GridColumnsJson,SearchFieldsJson=q.SearchFieldsJson,PageSize=q.PageSize,DisplayOrder=q.DisplayOrder,IsDefault=q.IsDefault,IsActive=q.IsActive,UpdatedAtUtc=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT(Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive) VALUES(q.Id,q.Code,q.Name,q.Title,COALESCE(q.Description,''),q.TemplateId,COALESCE(q.AlertType,''),q.GroupByFieldsJson,q.MetricsJson,q.GridColumnsJson,q.SearchFieldsJson,q.PageSize,q.DisplayOrder,q.IsDefault,q.IsActive);
  DECLARE @SavedDashboardId varchar(32)=JSON_VALUE(@strJson,'$.id'); DELETE FROM dbo.TemplateDashboardRoleMapping WHERE DashboardId=@SavedDashboardId;
  INSERT dbo.TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) SELECT @SavedDashboardId,[value],1 FROM OPENJSON(@strJson,'$.roleCodes') WHERE NULLIF([value],'') IS NOT NULL;
  COMMIT; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetAlerts
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @DTTemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),@DTAlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),@DTUserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),@DTRoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),@DTCanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));
  SELECT TOP(5000) a.Id,a.AlertNo,a.TemplateId,a.AlertType,a.BranchCode,a.CustomerIdEncrypted,a.AccountIdEncrypted,a.Status,a.CurrentStageName,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc,a.DynamicDataJson
  FROM dbo.Alerts a WHERE a.TemplateId=@DTTemplateId AND (NULLIF(@DTAlertType,'') IS NULL OR a.AlertType=@DTAlertType) AND (@DTCanViewAll=1 OR a.BranchCode=@DTUserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND (wi.AssignedUserId=@UserId OR (wi.AssignedRoleCode=@DTRoleCode AND (wi.AssignedBranchCode='' OR wi.AssignedBranchCode=@DTUserBranch))))) ORDER BY a.CreatedAtUtc DESC; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Connector_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive FROM dbo.IngestionConnector ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Connector_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.IngestionConnector t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32),Name nvarchar(150),ConnectorType varchar(30),Host nvarchar(300),Port int,DatabaseName nvarchar(200),UserName nvarchar(200),SecretEncrypted nvarchar(2000),ExtraJson nvarchar(max),IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ConnectorType=s.ConnectorType,Host=s.Host,Port=s.Port,DatabaseName=s.DatabaseName,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,ExtraJson=s.ExtraJson,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive)VALUES(s.Id,s.Name,s.ConnectorType,s.Host,s.Port,s.DatabaseName,s.UserName,s.SecretEncrypted,s.ExtraJson,s.IsActive); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetConfigurations
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,TemplateId,SourceType,ConnectorId,FilePattern,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive FROM dbo.IngestionConfiguration ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_SaveConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.IngestionConfiguration t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32),Name nvarchar(150),TemplateId varchar(32),SourceType varchar(30),ConnectorId varchar(32),FilePattern nvarchar(260),ScheduleCron varchar(100),QueryText nvarchar(max),FieldMappingJson nvarchar(max),DuplicateKeyFields nvarchar(500),ArchivePath nvarchar(500),ErrorPath nvarchar(500),IntervalMinutes int,IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,TemplateId=s.TemplateId,SourceType=s.SourceType,ConnectorId=s.ConnectorId,FilePattern=s.FilePattern,ScheduleCron=s.ScheduleCron,QueryText=s.QueryText,FieldMappingJson=s.FieldMappingJson,DuplicateKeyFields=s.DuplicateKeyFields,ArchivePath=s.ArchivePath,ErrorPath=s.ErrorPath,IntervalMinutes=s.IntervalMinutes,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,TemplateId,SourceType,ConnectorId,FilePattern,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive)VALUES(s.Id,s.Name,s.TemplateId,s.SourceType,s.ConnectorId,s.FilePattern,s.ScheduleCron,s.QueryText,s.FieldMappingJson,s.DuplicateKeyFields,s.ArchivePath,s.ErrorPath,s.IntervalMinutes,s.IsActive); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetDashboard
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT (SELECT COUNT(*) FROM dbo.IngestionConfiguration WHERE IsActive=1)ActiveConfigurations,COUNT(*)RunsToday,COALESCE(SUM(CASE WHEN Status='Success' THEN 1 ELSE 0 END),0)SuccessfulToday,COALESCE(SUM(CASE WHEN Status='Failed' THEN 1 ELSE 0 END),0)FailedToday,COALESCE(SUM(RowsInserted),0)RowsInsertedToday FROM dbo.IngestionRun WHERE StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetRuns
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @Take int=CONVERT(int,JSON_VALUE(@strJson,'$.take')); SELECT TOP(@Take) Id,ConfigurationId,SourceReference,StartedAtUtc,EndedAtUtc,RowsRead,RowsInserted,RowsDuplicate,RowsFailed,Status,ErrorMessage FROM dbo.IngestionRun ORDER BY StartedAtUtc DESC; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetConfigurations
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive FROM dbo.MailConfiguration ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_SaveConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.MailConfiguration t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32),Name nvarchar(150),ProviderType varchar(30),Host nvarchar(300),Port int,UserName nvarchar(200),SecretEncrypted nvarchar(2000),FromAddress nvarchar(300),UseSsl int,IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ProviderType=s.ProviderType,Host=s.Host,Port=s.Port,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,FromAddress=s.FromAddress,UseSsl=s.UseSsl,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive)VALUES(s.Id,s.Name,s.ProviderType,s.Host,s.Port,s.UserName,s.SecretEncrypted,s.FromAddress,s.UseSsl,s.IsActive); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetTemplates
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive FROM dbo.MailTemplate ORDER BY EventCode; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetLogs
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @MailTake int=CONVERT(int,JSON_VALUE(@strJson,'$.take')); SELECT TOP(@MailTake) Id,EventCode,AlertId,ToAddress,Subject,Status,Attempts,CreatedAtUtc,SentAtUtc,ErrorMessage FROM dbo.MailQueue ORDER BY CreatedAtUtc DESC; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_SaveTemplate
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.MailTemplate t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32) '$.id',TemplateId varchar(32) '$.templateId',EventCode varchar(80) '$.eventCode',SubjectTemplate nvarchar(500) '$.subjectTemplate',BodyTemplate nvarchar(max) '$.bodyTemplate',UseMafEnrichment bit '$.useMafEnrichment',IsActive bit '$.isActive'))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET TemplateId=s.TemplateId,EventCode=s.EventCode,SubjectTemplate=s.SubjectTemplate,BodyTemplate=s.BodyTemplate,UseMafEnrichment=COALESCE(s.UseMafEnrichment,0),IsActive=COALESCE(s.IsActive,1) WHEN NOT MATCHED THEN INSERT(Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive)VALUES(s.Id,s.TemplateId,s.EventCode,s.SubjectTemplate,s.BodyTemplate,COALESCE(s.UseMafEnrichment,0),COALESCE(s.IsActive,1)); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Report_GetCount
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE
        @TemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),
        @AlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),
        @FilterBranch varchar(60)=JSON_VALUE(@strJson,'$.branchCode'),
        @UserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),
        @Status varchar(30)=JSON_VALUE(@strJson,'$.status'),
        @FromDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.fromDate')),
        @ToDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.toDate')),
        @CanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));

    SELECT COUNT(*)
    FROM dbo.Alerts a
    WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
           OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
      AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
      AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
      AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
      AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
      AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
      AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)));
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Report_GetData
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE
        @ReportType varchar(20)=JSON_VALUE(@strJson,'$.reportType'),
        @TemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),
        @AlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),
        @FilterBranch varchar(60)=JSON_VALUE(@strJson,'$.branchCode'),
        @UserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),
        @Status varchar(30)=JSON_VALUE(@strJson,'$.status'),
        @FromDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.fromDate')),
        @ToDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.toDate')),
        @Page int=COALESCE(TRY_CONVERT(int,JSON_VALUE(@strJson,'$.page')),1),
        @PageSize int=COALESCE(TRY_CONVERT(int,JSON_VALUE(@strJson,'$.pageSize')),20),
        @CanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));

    IF UPPER(COALESCE(@ReportType,''))='MIS'
    BEGIN
        SELECT a.AlertType,a.Status,COUNT(*) Total
        FROM dbo.Alerts a
        WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
               OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
          AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
          AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
          AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
          AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)))
        GROUP BY a.AlertType,a.Status
        ORDER BY a.AlertType,a.Status;
        RETURN;
    END;

    SELECT a.AlertNo,a.AlertType,t.Name TemplateName,a.BranchCode,a.CurrentStageName,
           a.Status,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc
    FROM dbo.Alerts a
    JOIN dbo.Templates t ON t.Id=a.TemplateId
    WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
           OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
      AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
      AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
      AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
      AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
      AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
      AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)))
    ORDER BY a.CreatedAtUtc DESC
    OFFSET (@Page-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END
GO

/* Backward-compatible wrapper. New C# code does not call this procedure directly. */
CREATE OR ALTER PROCEDURE dbo.usp_PlatformRepository
    @Operation nvarchar(100),
    @JsonInput nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ModuleCode nvarchar(60), @MethodCode nvarchar(80);

    SELECT @ModuleCode=v.ModuleCode,@MethodCode=v.MethodCode
    FROM (VALUES
        (N'GetEffectivePermissions',N'Security',N'GetEffectivePermissions'),
        (N'GetDataScopes',N'Security',N'GetDataScopes'),
        (N'GetDashboardWidgets',N'Dashboard',N'GetWidgets'),
        (N'GetDashboardWidgetConfiguration',N'Dashboard',N'GetWidgetConfiguration'),
        (N'SaveDashboardWidget',N'Dashboard',N'SaveWidget'),
        (N'GetTemplateDashboards',N'TemplateDashboard',N'GetAll'),
        (N'GetTemplateDashboard',N'TemplateDashboard',N'GetById'),
        (N'SaveTemplateDashboard',N'TemplateDashboard',N'Save'),
        (N'GetTemplateDashboardAlerts',N'TemplateDashboard',N'GetAlerts'),
        (N'GetConnectors',N'Connector',N'GetAll'),
        (N'SaveConnector',N'Connector',N'Save'),
        (N'GetIngestionConfigurations',N'Ingestion',N'GetConfigurations'),
        (N'SaveIngestionConfiguration',N'Ingestion',N'SaveConfiguration'),
        (N'GetIngestionDashboard',N'Ingestion',N'GetDashboard'),
        (N'GetIngestionRuns',N'Ingestion',N'GetRuns'),
        (N'GetMailConfigurations',N'Mail',N'GetConfigurations'),
        (N'SaveMailConfiguration',N'Mail',N'SaveConfiguration'),
        (N'GetMailTemplates',N'Mail',N'GetTemplates'),
        (N'GetMailLogs',N'Mail',N'GetLogs'),
        (N'SaveMailTemplate',N'Mail',N'SaveTemplate'),
        (N'GetReportCount',N'Report',N'GetCount'),
        (N'GetReport',N'Report',N'GetData')
    ) v(OperationCode,ModuleCode,MethodCode)
    WHERE v.OperationCode=@Operation;

    IF @MethodCode IS NULL
        THROW 50000, 'Unsupported legacy repository operation.', 1;

    EXEC dbo.usp_CommonRepository
        @ModuleCode=@ModuleCode,
        @MethodCode=@MethodCode,
        @strJson=@JsonInput;
END
GO

/* ===== CATS V6 Gateway / Assistant / MCP permissions ===== */
MERGE dbo.PermissionMaster AS t
USING (VALUES
 ('ASSISTANT.USE','Use read-only CATS AI assistant','AI'),
 ('MCP.MANAGE','Discover and manage MCP servers','AI')
) s(Code,Name,Category)
ON t.Code=s.Code
WHEN NOT MATCHED THEN INSERT(Code,Name,Category,IsActive) VALUES(s.Code,s.Name,s.Category,1)
WHEN MATCHED THEN UPDATE SET Name=s.Name,Category=s.Category,IsActive=1;
GO

MERGE dbo.RolePermissionMapping AS t
USING (VALUES
 ('ADMIN','ASSISTANT.USE'),('ADMIN','MCP.MANAGE'),('CENTRAL','ASSISTANT.USE')
) s(RoleCode,PermissionCode)
ON t.RoleCode=s.RoleCode AND t.PermissionCode=s.PermissionCode
WHEN NOT MATCHED THEN INSERT(RoleCode,PermissionCode,IsActive) VALUES(s.RoleCode,s.PermissionCode,1)
WHEN MATCHED THEN UPDATE SET IsActive=1;
GO

PRINT 'CATS V6 consolidated SQL Server upgrade completed.';
GO
