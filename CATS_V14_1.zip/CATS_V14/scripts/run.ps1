$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$app = Join-Path $root 'src\CATS.App\CATS.App.csproj'
$gateway = Join-Path $root 'src\CATS.Gateway\CATS.Gateway.csproj'
$mcpServer = Join-Path $root 'src\CATS.McpServer\CATS.McpServer.csproj'

Write-Host 'Starting CATS application on http://localhost:7001 ...'
$appProc = Start-Process dotnet -ArgumentList @('run','--project',$app,'--urls','http://127.0.0.1:7001') -PassThru
Start-Sleep -Seconds 3
Write-Host 'Starting CATS gateway on http://localhost:7000 ...'
$gatewayProc = Start-Process dotnet -ArgumentList @('run','--project',$gateway,'--urls','http://127.0.0.1:7000') -PassThru
Write-Host 'Starting CATS MCP server on http://localhost:9000/mcp ...'
$mcpProc = Start-Process dotnet -ArgumentList @('run','--project',$mcpServer,'--urls','http://127.0.0.1:9000') -PassThru
Write-Host "App PID: $($appProc.Id), Gateway PID: $($gatewayProc.Id), MCP PID: $($mcpProc.Id)" -ForegroundColor Cyan
Write-Host 'Open http://localhost:7000' -ForegroundColor Green
Write-Host 'Use scripts/stop.ps1 to stop the processes.'
@($appProc.Id,$gatewayProc.Id,$mcpProc.Id) | Set-Content (Join-Path $PSScriptRoot '.cats-pids')
