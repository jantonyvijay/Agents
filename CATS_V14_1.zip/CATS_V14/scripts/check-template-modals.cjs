const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('src/CATS.App/wwwroot/js/app.js','utf8');
for(const selector of ['#sectionModal','#fieldModal']) {
 const events=[];
 function element(name,shown=false){return {name,shown,listeners:{},classList:{contains:()=>shown},addEventListener(type,fn){this.listeners[type]=fn;},emit(type){const fn=this.listeners[type];delete this.listeners[type];fn?.();},querySelector(){return fallback;}};}
 const fallback={focus:()=>events.push('fallback-focus')};
 const parent=element('parent',true),child=element('child');
 const opener={isConnected:true,focus:()=>events.push('opener-focus')};
 const context={document:{getElementById:()=>parent,querySelector:()=>child,activeElement:opener},bootstrap:{Modal:{getOrCreateInstance:el=>({show:()=>events.push(el.name+'-show'),hide:()=>events.push(el.name+'-hide')})}}};
 vm.createContext(context);vm.runInContext(source.slice(source.indexOf('    function showTemplateChildModal'),source.indexOf('    function enableMovableModals')),context);
 vm.runInContext(`showTemplateChildModal('${selector}')`,context);
 assert.deepEqual(events,['parent-hide']);
 parent.emit('hidden.bs.modal');assert.deepEqual(events,['parent-hide','child-show']);
 child.emit('hidden.bs.modal');assert.equal(events.at(-1),'parent-show');
 parent.emit('shown.bs.modal');assert.equal(events.at(-1),'opener-focus');
 assert.equal(Object.keys(child.listeners).length,0);
 events.length=0;vm.runInContext(`showTemplateChildModal('${selector}')`,context);
 parent.emit('hidden.bs.modal');opener.isConnected=false;child.emit('hidden.bs.modal');parent.emit('shown.bs.modal');
 assert.equal(events.at(-1),'fallback-focus');
}
console.log('PASS: section/field modal transitions wait for parent closure, restore parent and focus after save/cancel, and clear one-time handlers.');
