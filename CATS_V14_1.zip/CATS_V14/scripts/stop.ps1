$pidFile = Join-Path $PSScriptRoot '.cats-pids'
if(Test-Path $pidFile) {
  Get-Content $pidFile | ForEach-Object {
    $id = 0
    if([int]::TryParse($_,[ref]$id)) { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue }
  }
  Remove-Item $pidFile -Force
  Write-Host 'CATS processes stopped.'
} else { Write-Host 'No CATS PID file found.' }
