$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    dotnet --info
    dotnet restore .\CATS.sln
    dotnet build .\CATS.sln -c Release --no-restore
    Write-Host "CATS build completed successfully." -ForegroundColor Green
}
finally { Pop-Location }
