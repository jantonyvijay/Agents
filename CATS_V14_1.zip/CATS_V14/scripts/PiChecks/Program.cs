using System.Reflection;
using System.Security.Claims;
using System.Text.Json;
using CATS.App;
using CATS.App.Controllers;
using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

var repo=DispatchProxy.Create<ICatsRepository,RepoFake>();
var fake=(RepoFake)(object)repo;
var hasher=new Pbkdf2PasswordHasher();
fake.User.PasswordHash=hasher.Hash("test-password");
var protector=new Protector();
var service=new AlertApplicationService(repo,null!,protector,null!,null!,null!,null!);
var controller=new AlertsController(repo,null!,service,protector,hasher);
void Login(bool permitted=true,string branch="B1") {
 var claims=new List<Claim>{new(ClaimTypes.NameIdentifier,"u1"),new(ClaimTypes.Name,"tester"),new("branch",branch)};
 if(permitted)claims.Add(new("permission",CatsPermissions.PiUnmask));
 controller.ControllerContext=new(){HttpContext=new DefaultHttpContext{User=new ClaimsPrincipal(new ClaimsIdentity(claims,"test"))}};
}
async Task<IActionResult> Reveal(string name="taxId",string password="test-password")=>await controller.UnmaskPi("a1",new(){Field=name,Password=password},default);
void Check(bool ok,string message){if(!ok)throw new Exception(message);}
Login();
var result=(OkObjectResult)await Reveal("TAXID");
var payload=JsonSerializer.SerializeToElement(result.Value);
Check(payload.GetProperty("field").GetString()=="taxId" && payload.GetProperty("value").GetString()=="PRIVATE-1234","Authorised reveal failed");
Check(fake.Audits.Count==1 && fake.Audits[0].Action=="PI_UNMASK_VIEW" && !JsonSerializer.Serialize(fake.Audits[0]).Contains("PRIVATE-1234"),"Audit must not contain the private value");
Check(await Reveal(password:"wrong") is BadRequestObjectResult,"Wrong password accepted");
fake.Field.AllowUnmask=false;
Check(await Reveal() is BadRequestObjectResult,"Disabled reveal accepted");
fake.Field.AllowUnmask=true;fake.Field.Sensitive=false;
Check(await Reveal() is BadRequestObjectResult,"Non-PI field accepted");
fake.Field.Sensitive=true;
Check(await Reveal("unknown") is BadRequestObjectResult,"Unknown field accepted");
Login(false);
try {await Reveal();throw new Exception("Missing permission accepted");}catch(UnauthorizedAccessException){}
Login(true,"OTHER");
try {await Reveal();throw new Exception("Out-of-scope alert accepted");}catch(UnauthorizedAccessException){}
Check(fake.Audits.Count==1,"Failed reveals were recorded as successes");
Login();
Check(await Reveal("customerId") is OkObjectResult,"Customer ID reveal regressed");
Check(JsonSerializer.Deserialize<TemplateField>("{\"Sensitive\":true}")!.AllowUnmask,"Existing template compatibility failed");
Console.WriteLine("PASS: PI permission, password, field configuration, alert scope, audit privacy and legacy field defaults.");

var platform=DispatchProxy.Create<IPlatformRepository,DashboardFake>();
var gridController=new AlertsController(repo,platform,service,protector,hasher){ControllerContext=controller.ControllerContext};
var gridResult=(OkObjectResult)await gridController.List(new(){DashboardId="d1",DashboardMetricCode="PENDING"},default);
Check(await gridController.List(new(){DashboardId="d1"},default) is BadRequestObjectResult,"Missing metric returned unfiltered alerts");
var grid=(PagedResult<AlertListItem>)gridResult.Value!;
Check(grid.Data.Single().DynamicFields["CUSTOMERNAME"]=="Test Customer","Dashboard customer name was dropped");
Check(grid.Data.Single().DynamicFields["taxId"]=="***","Dashboard masked value changed");
Check(!grid.Data.Single().DynamicFields.ContainsKey("Unconfigured"),"Unconfigured field exposed");
Check(!grid.Data.Single().DynamicFields.ContainsKey("__CustomerIdRaw"),"Internal field exposed");
Console.WriteLine("PASS: Dashboard grid dynamic fields and masked values preserved; unconfigured/internal fields excluded.");

var validate=typeof(AlertApplicationService).GetMethod("ValidateDynamicData",BindingFlags.NonPublic|BindingFlags.Static)!;
var responseTemplate=new TemplateRecord{FieldsJson="[{\"name\":\"CDFinalRecommendation\",\"label\":\"CD Final recommendations\",\"type\":\"text\",\"required\":true}]"};
void ValidateResponse(string json,bool stored)=>validate.Invoke(null,[responseTemplate,JsonDocument.Parse(json).RootElement,new[]{"CDFinalRecommendation"},stored]);
ValidateResponse("{\"ACCOUNTNO\":\"legacy-import\",\"CDFinalRecommendation\":\"Central Due Diligence Review Positive\"}",true);
try{ValidateResponse("{\"ACCOUNTNO\":\"new-unknown\"}",false);throw new Exception("Unknown submitted field accepted");}catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){}
try{ValidateResponse("{\"ACCOUNTNO\":\"legacy-import\"}",true);throw new Exception("Required recommendation not validated");}catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){}
var matches=typeof(PlatformRepository).GetMethod("MatchesMetric",BindingFlags.NonPublic|BindingFlags.Static)!;
bool Matches(string recommendation,string metricValue,string stage="DT Verifier Review")=>(bool)matches.Invoke(null,[new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["CDFinalRecommendation"]=recommendation,["CurrentStageName"]=stage},new TemplateDashboardMetric{Type="FieldEquals",Field="CDFinalRecommendation",Value=metricValue}])!;
Check(Matches("Central Due Diligence Review Positive","Remove Txn Restriction"),"Positive review not counted as remove");
Check(Matches("Central Due Diligence Review Negative","Continue Txn Restriction"),"Negative review not counted as continue");
Check(!Matches("Central Due Diligence Review Positive","Continue Txn Restriction"),"Positive review counted as continue");
Check(Matches("Remove Txn Restriction","Remove Txn Restriction"),"Existing recommendation compatibility failed");
Check(!Matches("Central Due Diligence Review Positive","Remove Txn Restriction","DT User Review"),"Unsubmitted DT user recommendation was counted as remove");
var dtUserPendingMetric=new TemplateDashboardMetric{Code="PENDING",Title="Pending",Type="FieldEquals",Field="CurrentStageName",Value="DT User Review"};
Check((bool)matches.Invoke(null,[new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["CurrentStageName"]="DT User Review"},dtUserPendingMetric])!,"DT user review was not counted as pending");
Check(!(bool)matches.Invoke(null,[new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["CurrentStageName"]="DT Verifier Review"},dtUserPendingMetric])!,"Submitted DT user review remained pending");
var pendingMetric=new TemplateDashboardMetric{Code="PENDING",Title="Pending",Type="StatusCount",Value="Pending"};
var metricValueMethod=typeof(PlatformRepository).GetMethod("MetricValue",BindingFlags.NonPublic|BindingFlags.Static)!;
foreach(var expected in new[]{13,50}) {
 var fixture=Enumerable.Range(0,50).Select(i=>new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase){["Status"]=i<expected?"Pending":"Closed"}).ToList();
 var count=(long)metricValueMethod.Invoke(null,[fixture,pendingMetric])!;
 var drill=fixture.Where(row=>(bool)matches.Invoke(null,[row,pendingMetric])!).ToList();
 Check(count==expected&&drill.Count==expected,"Pending summary/drill-down count mismatch");
}
Console.WriteLine("PASS: Legacy import validation, required response validation, recommendation mapping, and exact 13/50 pending drill-down counts.");

public class RepoFake:DispatchProxy {
 public UserRecord User=new(){Id="u1",UserName="tester",IsActive=true};
 public TemplateField Field=new(){Name="taxId",Sensitive=true};
 public List<AuditRecord> Audits=[];
 protected override object? Invoke(MethodInfo? method,object?[]? args)=>method!.Name switch {
  "GetUserByUserNameAsync"=>Task.FromResult<UserRecord?>(User),
  "GetAlertAsync"=>Task.FromResult<AlertRecord?>(new(){Id="a1",TemplateId="t1",BranchCode="B1",CustomerIdEncrypted="customer",DynamicDataJson="{\"taxId\":\"PRIVATE-1234\"}"}),
  "GetTemplateAsync"=>Task.FromResult<TemplateRecord?>(new(){Id="t1",FieldsJson=JsonSerializer.Serialize(new[]{Field}),ViewConfigurationJson="{\"alertListFields\":[{\"field\":\"CUSTOMERNAME\",\"showInGrid\":true},{\"field\":\"taxId\",\"showInGrid\":true},{\"field\":\"__CustomerIdRaw\",\"showInGrid\":true}]}"}),
  "GetTemplateNameAsync"=>Task.FromResult("Test Template"),
  "GetWorkItemsAsync"=>Task.FromResult<IReadOnlyList<WorkItemRecord>>([]),
  "InsertAuditAsync"=>Audit((AuditRecord)args![0]!),
  _=>throw new NotSupportedException(method.Name)
 };
 Task Audit(AuditRecord record){Audits.Add(record);return Task.CompletedTask;}
}
public class Protector:IDataProtectorService {
 public string Protect(string value)=>value;
 public string Unprotect(string value)=>value;
 public string Mask(string value,int visibleTail=4)=>"***";
}

public class DashboardFake:DispatchProxy {
 protected override object? Invoke(MethodInfo? method,object?[]? args)=>method!.Name switch {
  "GetTemplateDashboardDataAsync"=>Task.FromResult(new TemplateDashboardDataResponse {
   Dashboard=new(){TemplateId="t1"},Page=1,PageSize=20,TotalRecords=1,
   Rows=[new(StringComparer.OrdinalIgnoreCase){["Id"]="a1",["CustomerName"]="Test Customer",["taxId"]="***",["Unconfigured"]="omit",["__CustomerIdRaw"]="omit"}]
  }),
  _=>throw new NotSupportedException(method.Name)
 };
}
