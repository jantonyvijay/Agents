const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync('src/CATS.App/wwwroot/js/app.js','utf8');
const storage = new Map(), attrs = {}, state = {user:{id:'alice'}, detail:{alert:{id:'alert-1'}}};
const elements = new Map();
function $(key) {
 if (!elements.has(key)) elements.set(key, {text(){return this;},each(){return this;},val(v){this.value=v;return this;},toggleClass(name,active){this[name]=active;return this;}});
 return elements.get(key);
}
const context = vm.createContext({state, $, Object, encodeURIComponent,
 window:{matchMedia:()=>({matches:true})}, document:{querySelector:()=>null,documentElement:{setAttribute:(k,v)=>attrs[k]=v,style:{setProperty:(k,v)=>attrs[k]=v},dataset:{}}},
 localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v)},
 esc:s=>String(s??'').replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;'),
 has:p=>p==='PI.UNMASK', fieldValue:v=>String(v), json:JSON.parse});
vm.runInContext(source.slice(source.indexOf('    const themeMedia'),source.indexOf('    function userInitials')),context);
for(const theme of ['light','dark','system','ocean','forest','violet','white','blue','custom']) {
 vm.runInContext(`applyTheme('${theme}')`,context);
 assert.equal(attrs['data-cats-theme'],theme);
 assert.equal(attrs['data-bs-theme'],['dark','system'].includes(theme)?'dark':'light');
}
storage.set('cats_theme_color_alice','#287A57'); vm.runInContext("applyTheme('custom')",context);
assert.equal(attrs['--cats-accent'],'#287A57'); assert.equal(attrs['--cats-topbar-bg'],'#287A57'); assert.equal(attrs['data-bs-theme'],'light');
vm.runInContext("applyTheme('forest'); applyLayout('compact')",context);
state.user={id:'bob'}; vm.runInContext('restoreAppearance()',context);
assert.equal(attrs['data-cats-theme'],'system'); assert.equal(context.document.documentElement.dataset.catsLayout,'standard');
vm.runInContext("applyTheme('ocean'); applyLayout('wide')",context);
assert.equal(elements.get('body')['sidebar-collapsed'],true);
state.user={id:'alice'}; vm.runInContext('restoreAppearance()',context);
assert.equal(attrs['data-cats-theme'],'forest');assert.equal(context.document.documentElement.dataset.catsLayout,'compact');
vm.runInContext("applyTheme('invalid'); applyLayout('invalid')",context);
assert.equal(attrs['data-cats-theme'],'system'); assert.equal(context.document.documentElement.dataset.catsLayout,'standard');
vm.runInContext(source.slice(source.indexOf('    const piEye'),source.indexOf('    const makePiCell')),context);
vm.runInContext(source.slice(source.indexOf('    function templateFieldControlHtml'),source.indexOf('    function sectionContentHtml')),context);
context.field={name:'tax"<id',sensitive:true,allowUnmask:true,type:'text'};
let html=vm.runInContext("templateFieldControlHtml(field, '***123', 'detail-dynamic-field', true)",context);
assert.match(html,/pi-reveal/); assert.match(html,/data-pi-edit="%7B/);assert.match(html,/tax&amp;quot;|tax&quot;/);assert.doesNotMatch(html,/<input/);
context.field.allowUnmask=false; html=vm.runInContext("templateFieldControlHtml(field, '***123', 'detail-dynamic-field', false)",context);
assert.doesNotMatch(html,/pi-reveal/);assert.match(html,/\*\*\*123/);
context.has=()=>false;context.field.allowUnmask=true;
assert.doesNotMatch(vm.runInContext("templateFieldControlHtml(field, '***123', 'detail-dynamic-field', false)",context),/pi-reveal/);
console.log('PASS: eight themes, per-user persistence, layouts, invalid defaults and PI field rendering.');
context.sectionContentHtml = section => '<span>' + section.name + '</span>';
vm.runInContext(source.slice(source.indexOf('    function configuredSectionsHtml'),source.indexOf('    function getConfiguredFieldValue')),context);
context.sections=[{id:'s1',name:'First',order:1},{id:'s2',name:'Second',order:2}];
context.cfg={layoutMode:'Accordion',showSectionNumbers:true};
for(const [mode,marker] of [['template','accordion-item'],['single','data-section-page'],['tab','nav-tabs'],['accordion','accordion-item'],['popup','cats-template-popup'],['wizard','cats-wizard-pane']]) {
 vm.runInContext(`applySectionLayout('${mode}')`,context);
 const rendered=vm.runInContext("configuredSectionsHtml(sections, [], {}, null, 'dynamic-field', cfg)",context);
 assert.ok(rendered.includes(marker),mode+' did not render');
 assert.ok(rendered.includes('First') && rendered.includes('Second'),mode+' dropped a section');
 assert.equal(context.cfg.layoutMode,'Accordion','User preference modified template');
}
state.user={id:'bob'};assert.equal(vm.runInContext('getSectionLayout()',context),'template');
state.user={id:'alice'};assert.equal(vm.runInContext('getSectionLayout()',context),'wizard');
vm.runInContext("applySectionLayout('invalid')",context);assert.equal(vm.runInContext('getSectionLayout()',context),'template');
console.log('PASS: six section layouts, account isolation, fallback and unchanged template configuration.');
