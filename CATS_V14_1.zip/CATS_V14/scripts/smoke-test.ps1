param([string]$BaseUrl='http://localhost:7000')
$ErrorActionPreference='Stop'

function Login([string]$user) {
  return Invoke-RestMethod -Method Post -Uri "$BaseUrl/api/auth/login" -ContentType 'application/json' -Body (@{userName=$user;password='Cats@1234'} | ConvertTo-Json)
}
function Headers($login) { return @{Authorization="Bearer $($login.token)"} }
function Action([string]$alertId,$login,[string]$action,[string]$remarks,$data=@{}) {
  $body=@{action=$action;remarks=$remarks;data=$data}|ConvertTo-Json -Depth 12
  return Invoke-RestMethod -Method Post -Headers (Headers $login) -Uri "$BaseUrl/api/alerts/$alertId/action" -ContentType 'application/json' -Body $body
}

$admin=Login 'admin'; $adminHeaders=Headers $admin
$templates=Invoke-RestMethod -Headers $adminHeaders -Uri "$BaseUrl/api/templates"
if(-not $templates -or $templates.Count -lt 1){throw 'No templates returned.'}
$published=$templates | Where-Object {$_.status -eq 'Published'} | Select-Object -First 1
if(-not $published){throw 'No published template returned.'}
$dashboard=Invoke-RestMethod -Headers $adminHeaders -Uri "$BaseUrl/api/dashboard/aging"

$body=@{
  templateId=$published.id;alertType='Smoke Test';branchCode='B001';customerId='CUST0001';accountId='ACC0001';priority='Normal';
  data=@{riskCategory='Low';alertAmount=100;customerContacted='No';remarks='Created by automated smoke test'}
}|ConvertTo-Json -Depth 12
$alert=Invoke-RestMethod -Method Post -Headers $adminHeaders -Uri "$BaseUrl/api/alerts" -ContentType 'application/json' -Body $body
Write-Host "Created $($alert.alertNo)" -ForegroundColor Cyan

$dt=Login 'dtuser'
$dtDetail=Invoke-RestMethod -Headers (Headers $dt) -Uri "$BaseUrl/api/alerts/$($alert.id)"
if(-not ($dtDetail.allowedActions -contains 'Submit')){throw 'DT_USER did not receive Submit action.'}
Action $alert.id $dt 'Submit' 'Questionnaire completed' @{customerContacted='Yes';remarks='DT user response'} | Out-Null

$checker=Login 'checker'
$checkerDetail=Invoke-RestMethod -Headers (Headers $checker) -Uri "$BaseUrl/api/alerts/$($alert.id)"
if(-not ($checkerDetail.allowedActions -contains 'Approve')){throw 'DT_CHECKER did not receive Approve action.'}
Action $alert.id $checker 'Approve' 'Checker approved' | Out-Null

$verifier=Login 'verifier'
$verifierDetail=Invoke-RestMethod -Headers (Headers $verifier) -Uri "$BaseUrl/api/alerts/$($alert.id)"
if(-not ($verifierDetail.allowedActions -contains 'Approve')){throw 'DT_VERIFIER did not receive Approve action.'}
Action $alert.id $verifier 'Approve' 'Verifier approved' | Out-Null

$final=Invoke-RestMethod -Headers $adminHeaders -Uri "$BaseUrl/api/alerts/$($alert.id)"
if($final.alert.status -ne 'Closed'){throw "Expected Closed but got $($final.alert.status)."}
if(-not $final.audit -or $final.audit.Count -lt 5){throw 'Expected audit history was not returned.'}

Invoke-RestMethod -Method Post -Headers (Headers $dt) -Uri "$BaseUrl/api/auth/logout" | Out-Null
Invoke-RestMethod -Method Post -Headers (Headers $checker) -Uri "$BaseUrl/api/auth/logout" | Out-Null
Invoke-RestMethod -Method Post -Headers (Headers $verifier) -Uri "$BaseUrl/api/auth/logout" | Out-Null
Invoke-RestMethod -Method Post -Headers $adminHeaders -Uri "$BaseUrl/api/auth/logout" | Out-Null

Write-Host "End-to-end smoke test completed. Alert $($alert.alertNo) reached Closed through DT User -> parallel Checker + Verifier." -ForegroundColor Green
Write-Host "Dashboard rows before test: $($dashboard.rows.Count)"
