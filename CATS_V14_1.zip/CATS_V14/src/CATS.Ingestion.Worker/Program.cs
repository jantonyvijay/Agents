using CATS.Core;
using CATS.Infrastructure;
using System.Text.Json;

var builder=Host.CreateApplicationBuilder(args);
builder.Services.AddWindowsService(o=>o.ServiceName="CATS Ingestion Worker");
var database=builder.Configuration.GetSection("Database").Get<DatabaseOptions>()??new();
builder.Services.AddSingleton(database);
builder.Services.AddSingleton<DbConnectionFactory>();
builder.Services.AddSingleton<AdoHelper>();
builder.Services.AddScoped<IPlatformRepository,PlatformRepository>();
builder.Services.AddHostedService<Worker>();
await builder.Build().RunAsync();

sealed class Worker(IServiceProvider services,ILogger<Worker> log):BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while(!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope=services.CreateScope();
                var repo=scope.ServiceProvider.GetRequiredService<IPlatformRepository>();
                var configs=await repo.GetIngestionConfigurationsAsync(stoppingToken);
                foreach(var c in configs.Where(x=>x.IsActive && x.SourceType is "SFTP" or "QUERY" or "FC_QUERY"))
                {
                    var triggers=ReadTriggers(c.ScheduleTriggersJson);
                    log.LogInformation("Ingestion task {Name} ({Type}) has {TriggerCount} configured trigger(s).",c.Name,c.SourceType,triggers.Count);
                }
            }
            catch(Exception ex){log.LogError(ex,"Ingestion scheduler iteration failed.");}
            await Task.Delay(TimeSpan.FromMinutes(1),stoppingToken);
        }
    }

    private static List<IngestionScheduleTrigger> ReadTriggers(string json)
    {
        try{return JsonSerializer.Deserialize<List<IngestionScheduleTrigger>>(json,JsonDefaults.Options)??[];}
        catch(JsonException){return[];}
    }
}
