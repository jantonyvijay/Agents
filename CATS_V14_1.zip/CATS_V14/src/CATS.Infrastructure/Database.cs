using System.Data;
using System.Data.Common;
using CATS.Core;
using Microsoft.Data.SqlClient;
using Npgsql;
using Oracle.ManagedDataAccess.Client;

namespace CATS.Infrastructure;

public sealed class DatabaseOptions
{
    public string Provider { get; set; } = "SqlServer";
    public string ConnectionString { get; set; } = "";
}

public interface IDbDialect
{
    string Name { get; }
    string P(string name);
    string StageAgeDays(string alias = "a");
    string OverallAgeDays(string alias = "a");
    string ApplyPagination(string sql, int page, int pageSize);
}

public sealed class SqlServerDialect : IDbDialect
{
    public string Name => "SqlServer";
    public string P(string n) => "@" + n;
    public string StageAgeDays(string a = "a") => $"DATEDIFF(day, {a}.StageEnteredAtUtc, SYSUTCDATETIME())";
    public string OverallAgeDays(string a = "a") => $"DATEDIFF(day, {a}.CreatedAtUtc, SYSUTCDATETIME())";
    public string ApplyPagination(string sql, int page, int pageSize) => $"{sql} OFFSET {(Math.Max(1,page)-1)*pageSize} ROWS FETCH NEXT {pageSize} ROWS ONLY";
}

public sealed class PostgreSqlDialect : IDbDialect
{
    public string Name => "PostgreSql";
    public string P(string n) => "@" + n;
    public string StageAgeDays(string a = "a") => $"FLOOR(EXTRACT(EPOCH FROM ((CURRENT_TIMESTAMP AT TIME ZONE 'UTC') - {a}.StageEnteredAtUtc))/86400)";
    public string OverallAgeDays(string a = "a") => $"FLOOR(EXTRACT(EPOCH FROM ((CURRENT_TIMESTAMP AT TIME ZONE 'UTC') - {a}.CreatedAtUtc))/86400)";
    public string ApplyPagination(string sql, int page, int pageSize) => $"{sql} LIMIT {pageSize} OFFSET {(Math.Max(1,page)-1)*pageSize}";
}

public sealed class OracleDialect : IDbDialect
{
    public string Name => "Oracle";
    public string P(string n) => ":" + n;
    public string StageAgeDays(string a = "a") => $"TRUNC(CAST(SYS_EXTRACT_UTC(SYSTIMESTAMP) AS DATE)) - TRUNC(CAST({a}.StageEnteredAtUtc AS DATE))";
    public string OverallAgeDays(string a = "a") => $"TRUNC(CAST(SYS_EXTRACT_UTC(SYSTIMESTAMP) AS DATE)) - TRUNC(CAST({a}.CreatedAtUtc AS DATE))";
    public string ApplyPagination(string sql, int page, int pageSize) => $"{sql} OFFSET {(Math.Max(1,page)-1)*pageSize} ROWS FETCH NEXT {pageSize} ROWS ONLY";
}

public sealed class DbConnectionFactory(DatabaseOptions options)
{
    public DatabaseOptions Options { get; } = options;
    public IDbDialect Dialect { get; } = options.Provider.Trim().ToLowerInvariant() switch
    {
        "sqlserver" or "mssql" => new SqlServerDialect(),
        "postgres" or "postgresql" or "npgsql" => new PostgreSqlDialect(),
        "oracle" => new OracleDialect(),
        _ => throw new InvalidOperationException($"Unsupported database provider '{options.Provider}'. Use SqlServer, PostgreSql or Oracle.")
    };

    public DbConnection Create()
    {
        return Dialect.Name switch
        {
            "PostgreSql" => new NpgsqlConnection(Options.ConnectionString),
            "Oracle" => new OracleConnection(Options.ConnectionString),
            _ => new SqlConnection(Options.ConnectionString)
        };
    }
}

public sealed record DbArg(string Name, object? Value, DbType? Type = null);

public sealed class AdoHelper(DbConnectionFactory factory)
{
    private const string CommonRepositoryProcedure = "dbo.usp_CommonRepository";

    public IDbDialect Dialect => factory.Dialect;

    private static IReadOnlyList<DbArg> RepositoryArguments(string moduleCode, string methodCode, string json) =>
    [
        new("ModuleCode", moduleCode),
        new("MethodCode", methodCode),
        new("strJson", string.IsNullOrWhiteSpace(json) ? "{}" : json)
    ];

    public Task<List<T>> QueryRepositoryAsync<T>(
        string moduleCode,
        string methodCode,
        string json,
        Func<DbDataReader,T> map,
        CancellationToken ct = default) =>
        QueryStoredProcedureAsync(CommonRepositoryProcedure, map, RepositoryArguments(moduleCode, methodCode, json), ct);

    public Task<T?> QuerySingleRepositoryAsync<T>(
        string moduleCode,
        string methodCode,
        string json,
        Func<DbDataReader,T> map,
        CancellationToken ct = default) =>
        QuerySingleStoredProcedureAsync(CommonRepositoryProcedure, map, RepositoryArguments(moduleCode, methodCode, json), ct);

    public Task<int> ExecuteRepositoryAsync(
        string moduleCode,
        string methodCode,
        string json,
        CancellationToken ct = default) =>
        ExecuteStoredProcedureAsync(CommonRepositoryProcedure, RepositoryArguments(moduleCode, methodCode, json), ct);

    public Task<T?> ScalarRepositoryAsync<T>(
        string moduleCode,
        string methodCode,
        string json,
        CancellationToken ct = default) =>
        ScalarStoredProcedureAsync<T>(CommonRepositoryProcedure, RepositoryArguments(moduleCode, methodCode, json), ct);

    public async Task<List<T>> QueryAsync<T>(string sql, Func<DbDataReader,T> map, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await QueryCommandAsync(sql, CommandType.Text, map, args, ct);

    public async Task<List<T>> QueryStoredProcedureAsync<T>(string procedureName, Func<DbDataReader,T> map, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await QueryCommandAsync(procedureName, CommandType.StoredProcedure, map, args, ct);

    private async Task<List<T>> QueryCommandAsync<T>(string commandText, CommandType commandType, Func<DbDataReader,T> map, IEnumerable<DbArg>? args, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var cmd = CreateCommand(cn, null, commandText, args, commandType);
        await using var rd = await cmd.ExecuteReaderAsync(ct);
        var list = new List<T>();
        while (await rd.ReadAsync(ct)) list.Add(map(rd));
        return list;
    }

    public async Task<T?> QuerySingleAsync<T>(string sql, Func<DbDataReader,T> map, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
    {
        var rows = await QueryAsync(sql, map, args, ct);
        return rows.Count == 0 ? default : rows[0];
    }

    public async Task<T?> QuerySingleStoredProcedureAsync<T>(string procedureName, Func<DbDataReader,T> map, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
    {
        var rows = await QueryStoredProcedureAsync(procedureName, map, args, ct);
        return rows.Count == 0 ? default : rows[0];
    }

    public async Task<int> ExecuteAsync(string sql, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await ExecuteCommandAsync(sql, CommandType.Text, args, ct);

    public async Task<int> ExecuteStoredProcedureAsync(string procedureName, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await ExecuteCommandAsync(procedureName, CommandType.StoredProcedure, args, ct);

    private async Task<int> ExecuteCommandAsync(string commandText, CommandType commandType, IEnumerable<DbArg>? args, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var cmd = CreateCommand(cn, null, commandText, args, commandType);
        return await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<T?> ScalarAsync<T>(string sql, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await ScalarCommandAsync<T>(sql, CommandType.Text, args, ct);

    public async Task<T?> ScalarStoredProcedureAsync<T>(string procedureName, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await ScalarCommandAsync<T>(procedureName, CommandType.StoredProcedure, args, ct);

    private async Task<T?> ScalarCommandAsync<T>(string commandText, CommandType commandType, IEnumerable<DbArg>? args, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var cmd = CreateCommand(cn, null, commandText, args, commandType);
        var value = await cmd.ExecuteScalarAsync(ct);
        if (value is null or DBNull) return default;
        var targetType = Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T);
        return (T)Convert.ChangeType(value, targetType);
    }

    public async Task<T> InTransactionAsync<T>(Func<AdoTransaction,Task<T>> action, CancellationToken ct = default)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(IsolationLevel.ReadCommitted, ct);
        var wrapper = new AdoTransaction(cn, tx, Dialect);
        try
        {
            var result = await action(wrapper);
            await tx.CommitAsync(ct);
            return result;
        }
        catch
        {
            await tx.RollbackAsync(ct);
            throw;
        }
    }

    internal static DbCommand CreateCommand(DbConnection cn, DbTransaction? tx, string commandText, IEnumerable<DbArg>? args, CommandType commandType = CommandType.Text)
    {
        var cmd = cn.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = commandText;
        cmd.CommandType = commandType;
        cmd.CommandTimeout = 120;
        if (cmd is OracleCommand oracleCommand) oracleCommand.BindByName = true;
        if (args != null)
        {
            foreach (var arg in args)
            {
                var p = cmd.CreateParameter();
                p.ParameterName = arg.Name;
                p.Value = arg.Value ?? DBNull.Value;
                if (arg.Type.HasValue) p.DbType = arg.Type.Value;
                cmd.Parameters.Add(p);
            }
        }
        return cmd;
    }
}

public sealed class AdoTransaction(DbConnection cn, DbTransaction tx, IDbDialect dialect)
{
    public IDbDialect Dialect { get; } = dialect;

    public async Task<int> ExecuteAsync(string sql, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await ExecuteCommandAsync(sql, CommandType.Text, args, ct);

    public async Task<int> ExecuteStoredProcedureAsync(string procedureName, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await ExecuteCommandAsync(procedureName, CommandType.StoredProcedure, args, ct);

    private async Task<int> ExecuteCommandAsync(string commandText, CommandType commandType, IEnumerable<DbArg>? args, CancellationToken ct)
    {
        await using var cmd = AdoHelper.CreateCommand(cn, tx, commandText, args, commandType);
        return await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<List<T>> QueryAsync<T>(string sql, Func<DbDataReader,T> map, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await QueryCommandAsync(sql, CommandType.Text, map, args, ct);

    public async Task<List<T>> QueryStoredProcedureAsync<T>(string procedureName, Func<DbDataReader,T> map, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
        => await QueryCommandAsync(procedureName, CommandType.StoredProcedure, map, args, ct);

    private async Task<List<T>> QueryCommandAsync<T>(string commandText, CommandType commandType, Func<DbDataReader,T> map, IEnumerable<DbArg>? args, CancellationToken ct)
    {
        await using var cmd = AdoHelper.CreateCommand(cn, tx, commandText, args, commandType);
        await using var rd = await cmd.ExecuteReaderAsync(ct);
        var list = new List<T>();
        while (await rd.ReadAsync(ct)) list.Add(map(rd));
        return list;
    }

    public async Task<T?> QuerySingleStoredProcedureAsync<T>(string procedureName, Func<DbDataReader,T> map, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
    {
        var rows = await QueryStoredProcedureAsync(procedureName, map, args, ct);
        return rows.Count == 0 ? default : rows[0];
    }

    public async Task<T?> ScalarStoredProcedureAsync<T>(string procedureName, IEnumerable<DbArg>? args = null, CancellationToken ct = default)
    {
        await using var cmd = AdoHelper.CreateCommand(cn, tx, procedureName, args, CommandType.StoredProcedure);
        var value = await cmd.ExecuteScalarAsync(ct);
        if (value is null or DBNull) return default;
        var targetType = Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T);
        return (T)Convert.ChangeType(value, targetType);
    }
}

public static class ReaderExtensions
{
    public static bool HasColumn(this DbDataReader r, string n)
    {
        for (var i = 0; i < r.FieldCount; i++) if (r.GetName(i).Equals(n, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }
    public static string Str(this DbDataReader r, string n) => r[n] is DBNull ? "" : Convert.ToString(r[n]) ?? "";
    public static string? NStr(this DbDataReader r, string n) => r[n] is DBNull ? null : Convert.ToString(r[n]);
    public static int Int(this DbDataReader r, string n) => r[n] is DBNull ? 0 : Convert.ToInt32(r[n]);
    public static long Lng(this DbDataReader r, string n) => r[n] is DBNull ? 0 : Convert.ToInt64(r[n]);
    public static bool Bool(this DbDataReader r, string n) => !(r[n] is DBNull) && Convert.ToInt32(r[n]) != 0;
    public static DateTime Dt(this DbDataReader r, string n) => r[n] is DBNull ? DateTime.MinValue : DateTime.SpecifyKind(Convert.ToDateTime(r[n]), DateTimeKind.Utc);
    public static DateTime? NDt(this DbDataReader r, string n) => r[n] is DBNull ? null : DateTime.SpecifyKind(Convert.ToDateTime(r[n]), DateTimeKind.Utc);
}
