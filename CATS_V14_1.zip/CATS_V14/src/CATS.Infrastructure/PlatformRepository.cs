using System.Data.Common;
using System.Text.Json;
using CATS.Core;

namespace CATS.Infrastructure;

public sealed class PlatformRepository(AdoHelper db, ICatsRepository templates) : IPlatformRepository
{
    private sealed record RepositoryRoute(string ModuleCode, string MethodCode);

    private static readonly IReadOnlyDictionary<string,RepositoryRoute> Routes =
        new Dictionary<string,RepositoryRoute>(StringComparer.OrdinalIgnoreCase)
    {
        ["GetEffectivePermissions"] = new("Security", "GetEffectivePermissions"),
        ["GetDataScopes"] = new("Security", "GetDataScopes"),
        ["GetDashboardWidgets"] = new("Dashboard", "GetWidgets"),
        ["GetDashboardWidgetConfiguration"] = new("Dashboard", "GetWidgetConfiguration"),
        ["SaveDashboardWidget"] = new("Dashboard", "SaveWidget"),
        ["GetTemplateDashboards"] = new("TemplateDashboard", "GetAll"),
        ["GetTemplateDashboard"] = new("TemplateDashboard", "GetById"),
        ["SaveTemplateDashboard"] = new("TemplateDashboard", "Save"),
        ["GetTemplateDashboardAlerts"] = new("TemplateDashboard", "GetAlerts"),
        ["GetConnectors"] = new("Connector", "GetAll"),
        ["SaveConnector"] = new("Connector", "Save"),
        ["GetIngestionConfigurations"] = new("Ingestion", "GetConfigurations"),
        ["SaveIngestionConfiguration"] = new("Ingestion", "SaveConfiguration"),
        ["GetIngestionDashboard"] = new("Ingestion", "GetDashboard"),
        ["GetIngestionRuns"] = new("Ingestion", "GetRuns"),
        ["GetMailConfigurations"] = new("Mail", "GetConfigurations"),
        ["SaveMailConfiguration"] = new("Mail", "SaveConfiguration"),
        ["GetMailTemplates"] = new("Mail", "GetTemplates"),
        ["GetMailLogs"] = new("Mail", "GetLogs"),
        ["SaveMailTemplate"] = new("Mail", "SaveTemplate"),
        ["GetReportCount"] = new("Report", "GetCount"),
        ["GetReport"] = new("Report", "GetData")
    };

    private static string NewId() => Guid.NewGuid().ToString("N");

    public Task<IReadOnlyList<string>> GetEffectivePermissionsAsync(string userId, CancellationToken ct = default) =>
        QueryAsync("GetEffectivePermissions", r => r.Str("PermissionCode"), new { userId }, ct);
    public Task<IReadOnlyList<DataScopeRecord>> GetDataScopesAsync(string userId, CancellationToken ct = default) =>
        QueryAsync("GetDataScopes", r => new DataScopeRecord { Id=r.Str("Id"), RoleCode=r.Str("RoleCode"), ScopeType=r.Str("ScopeType"), ScopeValue=r.Str("ScopeValue"), Priority=r.Int("Priority"), IsActive=r.Bool("IsActive") }, new { userId }, ct);

    public async Task<IReadOnlyList<DashboardWidgetValue>> GetDashboardWidgetsAsync(CurrentUser user, CancellationToken ct = default)
    {
        var permissions = await GetEffectivePermissionsAsync(user.Id, ct);
        return await QueryAsync("GetDashboardWidgets", r => new DashboardWidgetValue { Code=r.Str("Code"), Title=r.Str("Title"), WidgetType=r.Str("WidgetType"), Value=r.Lng("Value"), DrillDownUrl=r.Str("DrillDownUrl"), DisplayOrder=r.Int("DisplayOrder"), Width=r.Int("Width") }, new { userId=user.Id, user.RoleCode, user.BranchCode, permissions }, ct);
    }

    public Task<IReadOnlyList<DashboardWidgetRecord>> GetDashboardWidgetConfigurationAsync(CancellationToken ct = default) => QueryAsync("GetDashboardWidgetConfiguration", MapWidget, null, ct);
    public Task SaveDashboardWidgetAsync(DashboardWidgetRecord widget, string roleCode, CancellationToken ct = default) { if(string.IsNullOrWhiteSpace(widget.Id))widget.Id=NewId(); return ExecuteAsync("SaveDashboardWidget",new { widget,roleCode },ct); }

    public Task<IReadOnlyList<TemplateDashboardRecord>> GetTemplateDashboardsAsync(CurrentUser user, bool includeInactive=false, CancellationToken ct=default) =>
        QueryAsync("GetTemplateDashboards", MapTemplateDashboard, new { userId=user.Id, user.RoleCode, includeInactive }, ct);

    public async Task<TemplateDashboardRecord?> GetTemplateDashboardAsync(string id, CurrentUser user, bool requireManage=false, CancellationToken ct=default)
    {
        var rows=await QueryAsync("GetTemplateDashboard",MapTemplateDashboard,new { id,userId=user.Id,user.RoleCode,requireManage },ct);
        return rows.FirstOrDefault();
    }

    public Task SaveTemplateDashboardAsync(TemplateDashboardRecord dashboard,CancellationToken ct=default)
    {
        if(string.IsNullOrWhiteSpace(dashboard.Id)) dashboard.Id=NewId();
        dashboard.Code=string.IsNullOrWhiteSpace(dashboard.Code)?dashboard.Name.Trim().ToUpperInvariant().Replace(' ','_'):dashboard.Code.Trim();
        dashboard.PageSize=Math.Clamp(dashboard.PageSize,10,200);
        dashboard.RoleCodes=dashboard.RoleCodes.Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        return ExecuteAsync("SaveTemplateDashboard",dashboard,ct);
    }

    public async Task<TemplateDashboardDataResponse> GetTemplateDashboardDataAsync(string id,TemplateDashboardQuery query,CurrentUser user,Func<string,string> decrypt,Func<string,string> mask,CancellationToken ct=default)
    {
        var dashboard=await GetTemplateDashboardAsync(id,user,false,ct) ?? throw new UnauthorizedAccessException("Dashboard was not found or is not available for this role.");
        query.Page=Math.Max(1,query.Page); query.PageSize=Math.Clamp(query.PageSize<=0?dashboard.PageSize:query.PageSize,10,200);
        var scopes=await GetDataScopesAsync(user.Id,ct);
        var canViewAll=user.HasPermission(CatsPermissions.AlertViewAll)||scopes.Any(x=>x.ScopeType.Equals("ALL",StringComparison.OrdinalIgnoreCase));
        var source=await QueryAsync("GetTemplateDashboardAlerts",r=>
        {
            var customer=decrypt(r.Str("CustomerIdEncrypted")); var account=decrypt(r.Str("AccountIdEncrypted"));
            return new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase)
            {
                ["Id"]=r.Str("Id"),["AlertNo"]=r.Str("AlertNo"),["TemplateId"]=r.Str("TemplateId"),["AlertType"]=r.Str("AlertType"),["BranchCode"]=r.Str("BranchCode"),
                ["CustomerId"]=mask(customer),["AccountId"]=mask(account),["__CustomerIdRaw"]=customer,["__AccountIdRaw"]=account,["Status"]=r.Str("Status"),
                ["CurrentStageName"]=r.Str("CurrentStageName"),["Priority"]=r.Str("Priority"),["CreatedAtUtc"]=r.Dt("CreatedAtUtc"),["StageEnteredAtUtc"]=r.Dt("StageEnteredAtUtc"),["DynamicDataJson"]=r.Str("DynamicDataJson")
            };
        },new { dashboard.TemplateId,dashboard.AlertType,userId=user.Id,roleCode=user.RoleCode,userBranchCode=user.BranchCode,canViewAll },ct);

        var sensitiveFields=new Dictionary<string,List<TemplateField>>(StringComparer.OrdinalIgnoreCase);
        foreach(var templateId in source.Select(row=>Convert.ToString(row["TemplateId"])??"").Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var template=await templates.GetTemplateAsync(templateId,ct) ?? throw new InvalidOperationException("Dashboard alert template not found.");
            sensitiveFields[templateId]= (JsonSerializer.Deserialize<List<TemplateField>>(template.FieldsJson,JsonDefaults.Options) ?? []).Where(f=>f.Sensitive).ToList();
        }
        var rows=new List<Dictionary<string,object?>>();
        foreach(var raw in source)
        {
            var row=new Dictionary<string,object?>(raw,StringComparer.OrdinalIgnoreCase);
            var json=Convert.ToString(row["DynamicDataJson"])??"{}"; row.Remove("DynamicDataJson");
            try { using var doc=JsonDocument.Parse(json); if(doc.RootElement.ValueKind==JsonValueKind.Object) foreach(var prop in doc.RootElement.EnumerateObject()) if(!row.ContainsKey(prop.Name)) row[prop.Name]=JsonElementValue(prop.Value); } catch { }
            row.Remove("_assignments");
            foreach(var field in sensitiveFields.GetValueOrDefault(Convert.ToString(row["TemplateId"])??"") ?? [])
                if(row.TryGetValue(field.Name,out var value)) row[field.Name]=mask(Convert.ToString(value)??"");
            rows.Add(row);
        }
        bool contains(object? value,string search)=>Convert.ToString(value)?.Contains(search,StringComparison.OrdinalIgnoreCase)==true;
        if(!string.IsNullOrWhiteSpace(query.AlertNo)) rows=rows.Where(x=>contains(x.GetValueOrDefault("AlertNo"),query.AlertNo)).ToList();
        if(!string.IsNullOrWhiteSpace(query.AccountId)) rows=rows.Where(x=>contains(x.GetValueOrDefault("__AccountIdRaw"),query.AccountId)).ToList();
        if(!string.IsNullOrWhiteSpace(query.CustomerId)) rows=rows.Where(x=>contains(x.GetValueOrDefault("__CustomerIdRaw"),query.CustomerId)).ToList();
        if(!string.IsNullOrWhiteSpace(query.Search)) rows=rows.Where(x=>x.Where(kv=>!kv.Key.StartsWith("__",StringComparison.Ordinal)).Any(kv=>contains(kv.Value,query.Search))).ToList();
        foreach(var row in rows){row.Remove("__CustomerIdRaw");row.Remove("__AccountIdRaw");}

        var groups=ReadStringList(dashboard.GroupByFieldsJson); if(groups.Count==0)groups=["BranchCode"];
        var metrics=ReadMetrics(dashboard.MetricsJson); if(metrics.Count==0)metrics=[new(){Code="TOTAL",Title="Total Record",Type="Count"},new(){Code="PENDING",Title="Pending",Type="StatusCount",Value="Pending"}];
        dashboard.MetricsJson=JsonSerializer.Serialize(metrics,JsonDefaults.Options);
        var groupFilters=ReadStringDictionary(query.GroupFiltersJson);
        if(groupFilters.Count>0)
            rows=rows.Where(row=>groupFilters.All(filter=>ValueEquals(row.GetValueOrDefault(filter.Key),filter.Value))).ToList();
        if(!string.IsNullOrWhiteSpace(query.MetricCode))
        {
            var metric=metrics.FirstOrDefault(x=>x.Code.Equals(query.MetricCode,StringComparison.OrdinalIgnoreCase))
                ?? throw new ArgumentException("The selected dashboard metric is not configured.");
            rows=rows.Where(row=>MatchesMetric(row,metric)).ToList();
        }
        var summary=rows.GroupBy(x=>string.Join("\\u001f",groups.Select(g=>Convert.ToString(x.GetValueOrDefault(g))??"")),StringComparer.OrdinalIgnoreCase).Select(g=>
        {
            var first=g.First(); var d=new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase); foreach(var field in groups)d[field]=first.GetValueOrDefault(field);
            foreach(var m in metrics)d[m.Title]=MetricValue(g,m); return d;
        }).ToList();
        var total=rows.Count; var pageRows=rows.Skip((query.Page-1)*query.PageSize).Take(query.PageSize).ToList();
        return new(){Dashboard=dashboard,SummaryRows=summary,Rows=pageRows,TotalRecords=total,Page=query.Page,PageSize=query.PageSize};
    }

    private static object? JsonElementValue(JsonElement e)=>e.ValueKind switch { JsonValueKind.String=>e.GetString(),JsonValueKind.Number when e.TryGetInt64(out var n)=>n,JsonValueKind.Number when e.TryGetDecimal(out var d)=>d,JsonValueKind.True=>true,JsonValueKind.False=>false,JsonValueKind.Null=>null,_=>e.GetRawText() };
    private static List<string> ReadStringList(string json){try{return JsonSerializer.Deserialize<List<string>>(json,JsonDefaults.Options)??[];}catch{return[];}}
    private static Dictionary<string,string> ReadStringDictionary(string json){try{return JsonSerializer.Deserialize<Dictionary<string,string>>(json,JsonDefaults.Options)??new(StringComparer.OrdinalIgnoreCase);}catch{return new(StringComparer.OrdinalIgnoreCase);}}
    private static List<TemplateDashboardMetric> ReadMetrics(string json){try{return JsonSerializer.Deserialize<List<TemplateDashboardMetric>>(json,JsonDefaults.Options)??[];}catch{return[];}}
    private static bool ValueEquals(object? actual,string expected)=>string.Equals(Convert.ToString(actual),expected,StringComparison.OrdinalIgnoreCase);
    private static string NormalizeRecommendation(object? value)=>Convert.ToString(value)?.Trim().ToUpperInvariant() switch
    {
        "CENTRAL DUE DILIGENCE REVIEW POSITIVE"=>"REMOVE TXN RESTRICTION",
        "CENTRAL DUE DILIGENCE REVIEW NEGATIVE"=>"CONTINUE TXN RESTRICTION",
        var text=>text??""
    };
    private static bool IsCurrentDtUserReview(Dictionary<string,object?> row)=>
        ValueEquals(row.GetValueOrDefault("CurrentStageName"),"DT User Review");
    private static bool MatchesMetric(Dictionary<string,object?> row,TemplateDashboardMetric metric)=>metric.Type.ToUpperInvariant() switch
    {
        "STATUSCOUNT"=>ValueEquals(row.GetValueOrDefault("Status"),metric.Value),
        "FIELDEQUALS"=>string.Equals(metric.Field,"CDFinalRecommendation",StringComparison.OrdinalIgnoreCase)
            ? !IsCurrentDtUserReview(row) && ValueEquals(NormalizeRecommendation(row.GetValueOrDefault(metric.Field)),NormalizeRecommendation(metric.Value))
            : ValueEquals(row.GetValueOrDefault(metric.Field),metric.Value),
        "FIELDNOTEMPTY"=>!string.IsNullOrWhiteSpace(Convert.ToString(row.GetValueOrDefault(metric.Field))),
        _=>true
    };
    private static long MetricValue(IEnumerable<Dictionary<string,object?>> rows,TemplateDashboardMetric m)
    {
        return m.Type.ToUpperInvariant() switch {
            "STATUSCOUNT" or "FIELDEQUALS" or "FIELDNOTEMPTY"=>rows.LongCount(x=>MatchesMetric(x,m)),
            _=>rows.LongCount()
        };
    }
    public Task<IReadOnlyList<ConnectorRecord>> GetConnectorsAsync(CancellationToken ct = default) => QueryAsync("GetConnectors",MapConnector,null,ct);
    public Task SaveConnectorAsync(ConnectorRecord connector,CancellationToken ct=default) { if(string.IsNullOrWhiteSpace(connector.Id))connector.Id=NewId(); return ExecuteAsync("SaveConnector",connector,ct); }
    public Task<IReadOnlyList<IngestionConfigurationRecord>> GetIngestionConfigurationsAsync(CancellationToken ct=default) => QueryAsync("GetIngestionConfigurations",MapConfig,null,ct);
    public Task SaveIngestionConfigurationAsync(IngestionConfigurationRecord config,CancellationToken ct=default) { if(string.IsNullOrWhiteSpace(config.Id))config.Id=NewId(); return ExecuteAsync("SaveIngestionConfiguration",config,ct); }

    public async Task<IngestionDashboard> GetIngestionDashboardAsync(CancellationToken ct=default)
    {
        var result=await QuerySingleAsync("GetIngestionDashboard",r=>new IngestionDashboard { ActiveConfigurations=r.Int("ActiveConfigurations"),RunsToday=r.Int("RunsToday"),SuccessfulToday=r.Int("SuccessfulToday"),FailedToday=r.Int("FailedToday"),RowsInsertedToday=r.Int("RowsInsertedToday") },null,ct)??new IngestionDashboard();
        result.RecentRuns=(await GetIngestionRunsAsync(20,ct)).ToList(); return result;
    }
    public Task<IReadOnlyList<IngestionRunRecord>> GetIngestionRunsAsync(int take=100,CancellationToken ct=default) => QueryAsync("GetIngestionRuns",MapRun,new { take=Math.Clamp(take,1,500) },ct);
    public Task<IReadOnlyList<MailConfigurationRecord>> GetMailConfigurationsAsync(CancellationToken ct=default) => QueryAsync("GetMailConfigurations",r=>new MailConfigurationRecord{Id=r.Str("Id"),Name=r.Str("Name"),ProviderType=r.Str("ProviderType"),Host=r.Str("Host"),Port=r.Int("Port"),UserName=r.Str("UserName"),SecretEncrypted=r.Str("SecretEncrypted"),FromAddress=r.Str("FromAddress"),UseSsl=r.Bool("UseSsl"),IsActive=r.Bool("IsActive")},null,ct);
    public Task SaveMailConfigurationAsync(MailConfigurationRecord config,CancellationToken ct=default) { if(string.IsNullOrWhiteSpace(config.Id))config.Id=NewId(); return ExecuteAsync("SaveMailConfiguration",config,ct); }
    public Task<IReadOnlyList<MailTemplateRecord>> GetMailTemplatesAsync(CancellationToken ct=default) => QueryAsync("GetMailTemplates",r=>new MailTemplateRecord{Id=r.Str("Id"),TemplateId=r.NStr("TemplateId"),EventCode=r.Str("EventCode"),SubjectTemplate=r.Str("SubjectTemplate"),BodyTemplate=r.Str("BodyTemplate"),UseMafEnrichment=r.Bool("UseMafEnrichment"),IsActive=r.Bool("IsActive")},null,ct);
    public Task SaveMailTemplateAsync(MailTemplateRecord template,CancellationToken ct=default) { if(string.IsNullOrWhiteSpace(template.Id))template.Id=NewId(); return ExecuteAsync("SaveMailTemplate",template,ct); }
    public Task<IReadOnlyList<MailQueueRecord>> GetMailLogsAsync(int take=100,CancellationToken ct=default) => QueryAsync("GetMailLogs",r=>new MailQueueRecord{Id=r.Str("Id"),EventCode=r.Str("EventCode"),AlertId=r.NStr("AlertId"),ToAddress=r.Str("ToAddress"),Subject=r.Str("Subject"),Status=r.Str("Status"),Attempts=r.Int("Attempts"),CreatedAtUtc=r.Dt("CreatedAtUtc"),SentAtUtc=r.NDt("SentAtUtc"),ErrorMessage=r.NStr("ErrorMessage")},new{take=Math.Clamp(take,1,500)},ct);

    public async Task<PagedResult<ReportRow>> GetReportAsync(string reportType,ReportFilter filter,CurrentUser user,CancellationToken ct=default)
    {
        filter.Page=Math.Max(1,filter.Page); filter.PageSize=Math.Clamp(filter.PageSize,10,200);
        var scopes=await GetDataScopesAsync(user.Id,ct); var canViewAll=user.HasPermission(CatsPermissions.AlertViewAll)||scopes.Any(s=>s.ScopeType.Equals("ALL",StringComparison.OrdinalIgnoreCase));
        var input=new { reportType,filter.TemplateId,filter.AlertType,filter.BranchCode,filter.Status,filter.FromDate,filter.ToDate,filter.Page,filter.PageSize,userId=user.Id,userBranchCode=user.BranchCode,canViewAll };
        var total=await ScalarAsync<int>("GetReportCount",input,ct);
        var rows=await QueryAsync("GetReport",r=>{var values=new Dictionary<string,object?>();for(var i=0;i<r.FieldCount;i++)values[r.GetName(i)]=r.IsDBNull(i)?null:r.GetValue(i);return new ReportRow{Values=values};},input,ct);
        return new(){Page=filter.Page,PageSize=filter.PageSize,TotalRecords=total,Data=rows.ToList()};
    }

    private static RepositoryRoute ResolveRoute(string operation) =>
        Routes.TryGetValue(operation, out var route)
            ? route
            : throw new InvalidOperationException($"No repository route is configured for platform operation '{operation}'.");

    private static string JsonInput(object? input) =>
        JsonSerializer.Serialize(input ?? new { }, JsonDefaults.Options);

    private async Task<IReadOnlyList<T>> QueryAsync<T>(string operation,Func<DbDataReader,T> map,object? input,CancellationToken ct)
    {
        var route=ResolveRoute(operation);
        return await db.QueryRepositoryAsync(route.ModuleCode,route.MethodCode,JsonInput(input),map,ct);
    }

    private Task<T?> QuerySingleAsync<T>(string operation,Func<DbDataReader,T> map,object? input,CancellationToken ct)
    {
        var route=ResolveRoute(operation);
        return db.QuerySingleRepositoryAsync(route.ModuleCode,route.MethodCode,JsonInput(input),map,ct);
    }

    private async Task<int> ScalarAsync<T>(string operation,object? input,CancellationToken ct)
    {
        var route=ResolveRoute(operation);
        return Convert.ToInt32(await db.ScalarRepositoryAsync<T>(route.ModuleCode,route.MethodCode,JsonInput(input),ct));
    }

    private async Task ExecuteAsync(string operation,object? input,CancellationToken ct)
    {
        var route=ResolveRoute(operation);
        _=await db.ExecuteRepositoryAsync(route.ModuleCode,route.MethodCode,JsonInput(input),ct);
    }

    private static TemplateDashboardRecord MapTemplateDashboard(DbDataReader r)=>new(){Id=r.Str("Id"),Code=r.Str("Code"),Name=r.Str("Name"),Title=r.Str("Title"),Description=r.Str("Description"),TemplateId=r.Str("TemplateId"),AlertType=r.Str("AlertType"),GroupByFieldsJson=r.Str("GroupByFieldsJson"),MetricsJson=r.Str("MetricsJson"),GridColumnsJson=r.Str("GridColumnsJson"),SearchFieldsJson=r.Str("SearchFieldsJson"),PageSize=r.Int("PageSize"),DisplayOrder=r.Int("DisplayOrder"),IsDefault=r.Bool("IsDefault"),IsActive=r.Bool("IsActive"),RoleCodes=r.Str("RoleCodes").Split(',',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries).ToList()};
    private static DashboardWidgetRecord MapWidget(DbDataReader r)=>new(){Id=r.Str("Id"),Code=r.Str("Code"),Title=r.Str("Title"),WidgetType=r.Str("WidgetType"),PermissionCode=r.Str("PermissionCode"),FilterJson=r.Str("FilterJson"),DrillDownUrl=r.Str("DrillDownUrl"),DisplayOrder=r.Int("DisplayOrder"),Width=r.Int("Width"),IsActive=r.Bool("IsActive")};
    private static ConnectorRecord MapConnector(DbDataReader r)=>new(){Id=r.Str("Id"),Name=r.Str("Name"),ConnectorType=r.Str("ConnectorType"),Host=r.Str("Host"),Port=r.Int("Port"),DatabaseName=r.Str("DatabaseName"),UserName=r.Str("UserName"),SecretEncrypted=r.Str("SecretEncrypted"),ExtraJson=r.Str("ExtraJson"),IsActive=r.Bool("IsActive")};
    private static IngestionConfigurationRecord MapConfig(DbDataReader r)=>new(){Id=r.Str("Id"),Name=r.Str("Name"),TemplateId=r.Str("TemplateId"),SourceType=r.Str("SourceType"),ConnectorId=r.NStr("ConnectorId"),FilePath=r.Str("FilePath"),FileName=r.Str("FileName"),FilePattern=r.Str("FilePattern"),ScheduleTriggersJson=r.Str("ScheduleTriggersJson"),ScheduleCron=r.Str("ScheduleCron"),QueryText=r.Str("QueryText"),FieldMappingJson=r.Str("FieldMappingJson"),DuplicateKeyFields=r.Str("DuplicateKeyFields"),ArchivePath=r.Str("ArchivePath"),ErrorPath=r.Str("ErrorPath"),IntervalMinutes=r.Int("IntervalMinutes"),IsActive=r.Bool("IsActive")};
    private static IngestionRunRecord MapRun(DbDataReader r)=>new(){Id=r.Str("Id"),ConfigurationId=r.Str("ConfigurationId"),SourceReference=r.Str("SourceReference"),StartedAtUtc=r.Dt("StartedAtUtc"),EndedAtUtc=r.NDt("EndedAtUtc"),RowsRead=r.Int("RowsRead"),RowsInserted=r.Int("RowsInserted"),RowsDuplicate=r.Int("RowsDuplicate"),RowsFailed=r.Int("RowsFailed"),Status=r.Str("Status"),ErrorMessage=r.NStr("ErrorMessage")};
}
