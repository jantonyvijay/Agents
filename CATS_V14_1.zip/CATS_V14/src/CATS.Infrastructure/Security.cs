using System.Security.Cryptography;
using System.Text;
using CATS.Core;

namespace CATS.Infrastructure;

public sealed class SecurityOptions
{
    public string DataEncryptionKeyBase64 { get; set; } = "";
}

public sealed class AesDataProtector(SecurityOptions options) : IDataProtectorService
{
    private readonly byte[] _key = Convert.FromBase64String(options.DataEncryptionKeyBase64);

    public string Protect(string plainText)
    {
        if (string.IsNullOrEmpty(plainText)) return "";
        var nonce = RandomNumberGenerator.GetBytes(12);
        var tag = new byte[16];
        var input = Encoding.UTF8.GetBytes(plainText);
        var cipher = new byte[input.Length];
        using var aes = new AesGcm(_key, 16);
        aes.Encrypt(nonce, input, cipher, tag);
        var payload = new byte[nonce.Length + tag.Length + cipher.Length];
        Buffer.BlockCopy(nonce, 0, payload, 0, nonce.Length);
        Buffer.BlockCopy(tag, 0, payload, nonce.Length, tag.Length);
        Buffer.BlockCopy(cipher, 0, payload, nonce.Length + tag.Length, cipher.Length);
        return Convert.ToBase64String(payload);
    }

    public string Unprotect(string cipherText)
    {
        if (string.IsNullOrEmpty(cipherText)) return "";
        var payload = Convert.FromBase64String(cipherText);
        var nonce = payload[..12];
        var tag = payload[12..28];
        var cipher = payload[28..];
        var plain = new byte[cipher.Length];
        using var aes = new AesGcm(_key, 16);
        aes.Decrypt(nonce, cipher, tag, plain);
        return Encoding.UTF8.GetString(plain);
    }

    public string Mask(string value, int visibleTail = 4)
    {
        if (string.IsNullOrWhiteSpace(value)) return "";
        if (value.Length <= visibleTail) return new string('X', value.Length);
        return new string('X', value.Length - visibleTail) + value[^visibleTail..];
    }
}

public sealed class Pbkdf2PasswordHasher : IPasswordHasher
{
    private const int Iterations = 210000;
    public string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);
        return $"{Iterations}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }

    public bool Verify(string password, string storedHash)
    {
        try
        {
            var parts = storedHash.Split('.');
            var iterations = int.Parse(parts[0]);
            var salt = Convert.FromBase64String(parts[1]);
            var expected = Convert.FromBase64String(parts[2]);
            var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, HashAlgorithmName.SHA256, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch { return false; }
    }
}
