namespace CATS.AI;

public sealed class CatsAssistantOptions
{
    public bool Enabled { get; set; }
    public string Provider { get; set; } = "OpenAICompatible";
    public string Endpoint { get; set; } = "https://generativelanguage.googleapis.com/v1beta/openai/";
    public string Model { get; set; } = "gemini-2.5-flash";
    public string ApiKey { get; set; } = "";
    public bool MaskPiData { get; set; } = true;
    public bool EnableApprovedMcpTools { get; set; } = false;
    public int MaxContextCharacters { get; set; } = 24000;
    public string SystemInstructions { get; set; } = "You are the read-only CATS enterprise assistant. Answer only from the authorised CATS context and approved read-only tools available to you. Never approve, reject, verify, close, reassign, create, delete or mutate CATS data. Never bypass permissions or data scope. If the data is not available, say so. Keep PI data masked unless the supplied context is already authorised and unmasked.";
}

public sealed class McpOptions
{
    public bool Enabled { get; set; }
    public List<McpServerOptions> Servers { get; set; } = [];
}

public sealed class McpServerOptions
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Endpoint { get; set; } = "";
    public bool Enabled { get; set; }
    public int TimeoutSeconds { get; set; } = 30;
    public Dictionary<string,string> Headers { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public List<string> ApprovedReadOnlyTools { get; set; } = [];
}

public sealed class CatsAssistantRequest
{
    public string Message { get; set; } = "";
}

public sealed class CatsAssistantResponse
{
    public string Answer { get; set; } = "";
    public string Provider { get; set; } = "";
    public string Model { get; set; } = "";
    public bool UsedMcpTools { get; set; }
}

public sealed class McpServerSummary
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Endpoint { get; set; } = "";
    public bool Enabled { get; set; }
    public int ApprovedToolCount { get; set; }
}

public sealed class McpToolInfo
{
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public bool ApprovedReadOnly { get; set; }
}

public sealed class McpDiscoveryResult
{
    public string ServerCode { get; set; } = "";
    public string ServerName { get; set; } = "";
    public List<McpToolInfo> Tools { get; set; } = [];
}

public sealed class McpEndpointDiscoveryRequest
{
    public string Name { get; set; } = "";
    public string Endpoint { get; set; } = "";
    public int TimeoutSeconds { get; set; } = 30;
}
