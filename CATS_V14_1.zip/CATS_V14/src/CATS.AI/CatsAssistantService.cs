using System.ClientModel;
using System.Text.Json;
using System.Text.RegularExpressions;
using CATS.Core;
using Microsoft.Agents.AI;
using OpenAI;
using OpenAI.Chat;

namespace CATS.AI;

public interface ICatsAssistantService
{
    bool IsEnabled { get; }
    string Provider { get; }
    string Model { get; }
    Task<CatsAssistantResponse> AskAsync(CatsAssistantRequest request, CurrentUser user, CancellationToken ct = default);
}

public sealed class CatsAssistantService(
    CatsAssistantOptions options,
    ICatsRepository cats,
    IPlatformRepository platform,
    IDataProtectorService protector,
    IMcpDiscoveryService mcp) : ICatsAssistantService
{
    public bool IsEnabled => options.Enabled && !string.IsNullOrWhiteSpace(options.Endpoint) && !string.IsNullOrWhiteSpace(options.Model) && !string.IsNullOrWhiteSpace(options.ApiKey);
    public string Provider => options.Provider;
    public string Model => options.Model;

    public async Task<CatsAssistantResponse> AskAsync(CatsAssistantRequest request, CurrentUser user, CancellationToken ct = default)
    {
        if (!user.HasPermission(PlatformPermissions.AssistantUse))
            throw new UnauthorizedAccessException("CATS Assistant permission is required.");
        if (!IsEnabled)
            throw new InvalidOperationException("CATS Assistant is disabled or its SLM/LLM configuration is incomplete.");
        if (string.IsNullOrWhiteSpace(request.Message))
            throw new ArgumentException("A question is required.", nameof(request));

        var context = await BuildAuthorizedContextAsync(request.Message, user, ct);
        var question = options.MaskPiData ? MaskLongIdentifiers(request.Message) : request.Message.Trim();
        if (context.Length > Math.Max(4000, options.MaxContextCharacters))
            context = context[..Math.Max(4000, options.MaxContextCharacters)];

        var clientOptions = new OpenAIClientOptions { Endpoint = new Uri(options.Endpoint, UriKind.Absolute) };
        var chatClient = new ChatClient(options.Model, new ApiKeyCredential(options.ApiKey), clientOptions);

        await using var toolLease = options.EnableApprovedMcpTools
            ? await mcp.GetApprovedReadOnlyToolsAsync(ct)
            : new McpApprovedToolLease([], []);

        AIAgent agent = chatClient.AsAIAgent(
            instructions: options.SystemInstructions,
            name: "CATSAssistant",
            tools: [.. toolLease.Tools]);

        var prompt = $"""
        Logged-in user role: {user.RoleCode}
        Logged-in branch: {user.BranchCode}

        USER QUESTION
        {question}

        AUTHORISED CATS CONTEXT
        {context}

        Answer the question using only the authorised context above and, if enabled, approved read-only MCP tools. Do not perform or propose an unapproved write action.
        """;

        var response = await agent.RunAsync(prompt, cancellationToken: ct);
        return new CatsAssistantResponse
        {
            Answer = string.IsNullOrWhiteSpace(response.Text) ? "No answer was returned by the configured model." : response.Text.Trim(),
            Provider = options.Provider,
            Model = options.Model,
            UsedMcpTools = toolLease.Tools.Count > 0
        };
    }

    private async Task<string> BuildAuthorizedContextAsync(string question, CurrentUser user, CancellationToken ct)
    {
        var payload = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase)
        {
            ["generatedAtUtc"] = DateTime.UtcNow,
            ["roleCode"] = user.RoleCode,
            ["departmentCode"] = user.DepartmentCode,
            ["branchCode"] = user.BranchCode,
            ["permissions"] = user.Permissions,
            ["dataScopes"] = await platform.GetDataScopesAsync(user.Id, ct)
        };

        var alerts = await cats.GetAlertsAsync(new AlertListFilter
        {
            Search = question.Length <= 120 ? question.Trim() : null,
            Page = 1,
            PageSize = 25
        }, user, protector.Unprotect, value => protector.Mask(value), ct);

        if (alerts.TotalRecords == 0)
        {
            alerts = await cats.GetAlertsAsync(new AlertListFilter { Page = 1, PageSize = 25 }, user, protector.Unprotect, value => protector.Mask(value), ct);
        }

        if (options.MaskPiData)
        {
            foreach (var item in alerts.Data)
            {
                item.CustomerId = string.IsNullOrWhiteSpace(item.CustomerId) ? "" : "[MASKED]";
                item.AccountId = string.IsNullOrWhiteSpace(item.AccountId) ? "" : "[MASKED]";
            }
        }
        payload["alerts"] = new { alerts.TotalRecords, alerts.Data };

        if (user.HasPermission(PlatformPermissions.DashboardView))
        {
            payload["agingDashboard"] = await cats.GetDashboardAgingAsync(user, null, ct);
            payload["dashboardWidgets"] = await platform.GetDashboardWidgetsAsync(user, ct);
            payload["templateDashboards"] = await platform.GetTemplateDashboardsAsync(user, false, ct);
        }

        if (user.HasPermission(CatsPermissions.TemplateManage) || user.HasPermission(PlatformPermissions.DashboardView))
        {
            var templates = await cats.GetTemplatesAsync(ct);
            payload["templates"] = templates.Select(x => new { x.Id, x.Code, x.Name, x.Status, x.Version, x.ExecutionMode }).Take(100).ToList();
        }

        if (ContainsAny(question, "ingestion", "sftp", "file", "fc query", "connector") && user.HasPermission(PlatformPermissions.IngestionView))
            payload["ingestion"] = await platform.GetIngestionDashboardAsync(ct);

        if (ContainsAny(question, "mis", "report", "all alert", "alert wise"))
        {
            var reportType = ContainsAny(question, "mis") ? "MIS" : ContainsAny(question, "alert wise") ? "ALERTWISE" : "ALL";
            var required = reportType switch
            {
                "MIS" => PlatformPermissions.ReportsMis,
                "ALERTWISE" => PlatformPermissions.ReportsAlertWise,
                _ => PlatformPermissions.ReportsAll
            };
            if (user.HasPermission(required))
                payload["report"] = await platform.GetReportAsync(reportType, new ReportFilter { Page = 1, PageSize = 25 }, user, ct);
        }

        if (ContainsAny(question, "mail", "email", "notification") && user.HasPermission(PlatformPermissions.MailManage))
        {
            var configs = await platform.GetMailConfigurationsAsync(ct);
            var templates = await platform.GetMailTemplatesAsync(ct);
            payload["mail"] = new
            {
                configurations = configs.Select(x => new { x.Id, x.Name, x.ProviderType, x.Host, x.Port, x.FromAddress, x.UseSsl, x.IsActive }).ToList(),
                templates = templates.Select(x => new { x.Id, x.TemplateId, x.EventCode, x.SubjectTemplate, x.UseMafEnrichment, x.IsActive }).ToList()
            };
        }

        if (ContainsAny(question, "query", "clarification") && alerts.Data.Count > 0)
        {
            var queryContext = new List<object>();
            foreach (var alert in alerts.Data.Take(5))
                queryContext.Add(new { alert.AlertNo, queries = await cats.GetQueriesAsync(alert.Id, ct) });
            payload["queryHistory"] = queryContext;
        }

        return JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = false });
    }

    private static bool ContainsAny(string value, params string[] terms) => terms.Any(t => value.Contains(t, StringComparison.OrdinalIgnoreCase));

    private static string MaskLongIdentifiers(string value) => Regex.Replace(value, @"\b\d{8,20}\b", m =>
    {
        if (m.Value.Length <= 4) return m.Value;
        return new string('X', m.Value.Length - 4) + m.Value[^4..];
    });
}
