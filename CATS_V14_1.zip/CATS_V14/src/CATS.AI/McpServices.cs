using Microsoft.Extensions.AI;
using ModelContextProtocol.Client;

namespace CATS.AI;

public interface IMcpDiscoveryService
{
    IReadOnlyList<McpServerSummary> GetConfiguredServers();
    Task<McpDiscoveryResult> DiscoverAsync(string serverCode, CancellationToken ct = default);
    Task<McpDiscoveryResult> DiscoverEndpointAsync(McpEndpointDiscoveryRequest request, CancellationToken ct = default);
    Task<McpApprovedToolLease> GetApprovedReadOnlyToolsAsync(CancellationToken ct = default);
}

public sealed class McpApprovedToolLease(IReadOnlyList<AITool> tools, IReadOnlyList<IAsyncDisposable> clients) : IAsyncDisposable
{
    public IReadOnlyList<AITool> Tools { get; } = tools;

    public async ValueTask DisposeAsync()
    {
        foreach (var client in clients.Reverse())
        {
            try { await client.DisposeAsync(); } catch { /* connection cleanup must not mask the assistant response */ }
        }
    }
}

public sealed class McpDiscoveryService(McpOptions options) : IMcpDiscoveryService
{
    public IReadOnlyList<McpServerSummary> GetConfiguredServers() => options.Servers
        .Select(x => new McpServerSummary
        {
            Code = x.Code,
            Name = x.Name,
            Endpoint = x.Endpoint,
            Enabled = options.Enabled && x.Enabled,
            ApprovedToolCount = x.ApprovedReadOnlyTools.Distinct(StringComparer.OrdinalIgnoreCase).Count()
        })
        .OrderBy(x => x.Name)
        .ToList();

    public async Task<McpDiscoveryResult> DiscoverAsync(string serverCode, CancellationToken ct = default)
    {
        var server = Resolve(serverCode, requireEnabled: false);
        await using var client = await CreateClientAsync(server, ct);
        var tools = await client.ListToolsAsync(cancellationToken: ct);
        return new McpDiscoveryResult
        {
            ServerCode = server.Code,
            ServerName = server.Name,
            Tools = tools.Select(t => new McpToolInfo
            {
                Name = t.Name,
                Description = t.Description ?? "",
                ApprovedReadOnly = server.ApprovedReadOnlyTools.Contains(t.Name, StringComparer.OrdinalIgnoreCase)
            }).OrderBy(x => x.Name).ToList()
        };
    }

    public async Task<McpDiscoveryResult> DiscoverEndpointAsync(McpEndpointDiscoveryRequest request, CancellationToken ct = default)
    {
        if (!Uri.TryCreate(request.Endpoint?.Trim(), UriKind.Absolute, out var endpoint) ||
            (endpoint.Scheme != Uri.UriSchemeHttp && endpoint.Scheme != Uri.UriSchemeHttps))
            throw new InvalidOperationException("A valid HTTP or HTTPS MCP endpoint is required.");

        var name = string.IsNullOrWhiteSpace(request.Name) ? endpoint.Host : request.Name.Trim();
        var server = new McpServerOptions
        {
            Code = $"temporary-{Guid.NewGuid():N}",
            Name = name,
            Endpoint = endpoint.AbsoluteUri,
            Enabled = true,
            TimeoutSeconds = Math.Clamp(request.TimeoutSeconds, 5, 120)
        };
        await using var client = await CreateClientAsync(server, ct);
        var tools = await client.ListToolsAsync(cancellationToken: ct);
        return new McpDiscoveryResult
        {
            ServerCode = server.Code,
            ServerName = server.Name,
            Tools = tools.Select(t => new McpToolInfo
            {
                Name = t.Name,
                Description = t.Description ?? "",
                ApprovedReadOnly = false
            }).OrderBy(x => x.Name).ToList()
        };
    }

    public async Task<McpApprovedToolLease> GetApprovedReadOnlyToolsAsync(CancellationToken ct = default)
    {
        if (!options.Enabled) return new McpApprovedToolLease([], []);

        var tools = new List<AITool>();
        var clients = new List<IAsyncDisposable>();
        try
        {
            foreach (var server in options.Servers.Where(x => x.Enabled && x.ApprovedReadOnlyTools.Count > 0))
            {
                var client = await CreateClientAsync(server, ct);
                clients.Add(client);
                var discovered = await client.ListToolsAsync(cancellationToken: ct);
                foreach (var tool in discovered.Where(t => server.ApprovedReadOnlyTools.Contains(t.Name, StringComparer.OrdinalIgnoreCase)))
                    tools.Add(tool);
            }
            return new McpApprovedToolLease(tools, clients);
        }
        catch
        {
            foreach (var client in clients.AsEnumerable().Reverse())
            {
                try { await client.DisposeAsync(); } catch { }
            }
            throw;
        }
    }

    private McpServerOptions Resolve(string serverCode, bool requireEnabled)
    {
        var server = options.Servers.FirstOrDefault(x => x.Code.Equals(serverCode, StringComparison.OrdinalIgnoreCase))
            ?? throw new KeyNotFoundException($"MCP server '{serverCode}' is not configured.");
        if (requireEnabled && (!options.Enabled || !server.Enabled))
            throw new InvalidOperationException($"MCP server '{serverCode}' is disabled.");
        if (string.IsNullOrWhiteSpace(server.Endpoint))
            throw new InvalidOperationException($"MCP server '{serverCode}' endpoint is not configured.");
        return server;
    }

    private static async Task<McpClient> CreateClientAsync(McpServerOptions server, CancellationToken ct)
    {
        var transport = new HttpClientTransport(new HttpClientTransportOptions
        {
            Name = string.IsNullOrWhiteSpace(server.Name) ? server.Code : server.Name,
            Endpoint = new Uri(server.Endpoint, UriKind.Absolute),
            TransportMode = HttpTransportMode.AutoDetect,
            ConnectionTimeout = TimeSpan.FromSeconds(Math.Clamp(server.TimeoutSeconds, 5, 120)),
            AdditionalHeaders = server.Headers.Count == 0 ? null : new Dictionary<string,string>(server.Headers, StringComparer.OrdinalIgnoreCase)
        });
        return await McpClient.CreateAsync(transport, cancellationToken: ct);
    }
}
