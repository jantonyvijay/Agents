using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;

namespace CATS.McpServer;

[McpServerToolType]
public sealed class CatsReadOnlyTools(CatsApiClient api)
{
    [McpServerTool, Description("Search authorised CATS alerts. Results keep protected customer and account data masked.")]
    public Task<string> SearchAlerts(
        [Description("Free-text search value.")] string? search = null,
        [Description("Alert type filter.")] string? alertType = null,
        [Description("Branch code filter.")] string? branchCode = null,
        [Description("Status filter.")] string? status = null,
        [Description("Template identifier filter.")] string? templateId = null,
        [Description("Page number starting at 1.")] int page = 1,
        [Description("Rows per page, maximum 100.")] int pageSize = 20,
        CancellationToken ct = default) => api.GetAsync(Query("/api/alerts", new()
        {
            ["search"] = search, ["alertType"] = alertType, ["branchCode"] = branchCode,
            ["status"] = status, ["templateId"] = templateId, ["page"] = Math.Max(1, page),
            ["pageSize"] = Math.Clamp(pageSize, 1, 100)
        }), ct);

    [McpServerTool, Description("Get an authorised CATS alert with its workflow and masked data.")]
    public Task<string> GetAlert([Description("Alert identifier.")] string alertId, CancellationToken ct = default) =>
        api.GetAsync($"/api/alerts/{Uri.EscapeDataString(alertId)}", ct);

    [McpServerTool, Description("Get the audit history for an authorised CATS alert.")]
    public async Task<string> GetAlertAudit([Description("Alert identifier.")] string alertId, CancellationToken ct = default)
    {
        var detail = await api.GetAsync($"/api/alerts/{Uri.EscapeDataString(alertId)}", ct);
        using var document = JsonDocument.Parse(detail);
        return document.RootElement.TryGetProperty("audit", out var audit) ? audit.GetRawText() : "[]";
    }

    [McpServerTool, Description("Get the authorised CATS alert-aging dashboard.")]
    public Task<string> GetDashboard(
        string? templateId = null, string? alertType = null, string? branchCode = null,
        string? status = null, CancellationToken ct = default) => api.GetAsync(Query("/api/dashboard/aging", new()
        {
            ["templateId"] = templateId, ["alertType"] = alertType, ["branchCode"] = branchCode, ["status"] = status
        }), ct);

    [McpServerTool, Description("List CATS alert templates.")]
    public Task<string> ListTemplates(CancellationToken ct = default) => api.GetAsync("/api/templates", ct);

    [McpServerTool, Description("Get one CATS alert template by identifier.")]
    public Task<string> GetTemplate([Description("Template identifier.")] string templateId, CancellationToken ct = default) =>
        api.GetAsync($"/api/templates/{Uri.EscapeDataString(templateId)}", ct);

    [McpServerTool, Description("Run an authorised read-only CATS report.")]
    public Task<string> GetReport(
        [Description("Report type: MIS, ALERTWISE, or ALL.")] string reportType = "MIS",
        [Description("Page number starting at 1.")] int page = 1,
        [Description("Rows per page, maximum 100.")] int pageSize = 20,
        CancellationToken ct = default) => api.GetAsync(Query($"/api/platform/reports/{Uri.EscapeDataString(reportType)}", new()
        {
            ["page"] = Math.Max(1, page), ["pageSize"] = Math.Clamp(pageSize, 1, 100)
        }), ct);

    private static string Query(string path, Dictionary<string, object?> values)
    {
        var query = string.Join('&', values.Where(x => x.Value is not null && !string.IsNullOrWhiteSpace(Convert.ToString(x.Value)))
            .Select(x => $"{Uri.EscapeDataString(x.Key)}={Uri.EscapeDataString(Convert.ToString(x.Value)!)}"));
        return string.IsNullOrEmpty(query) ? path : $"{path}?{query}";
    }
}
