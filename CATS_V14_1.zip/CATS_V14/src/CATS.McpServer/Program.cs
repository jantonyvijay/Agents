using CATS.McpServer;

var builder = WebApplication.CreateBuilder(args);
var serverOptions = builder.Configuration.GetSection("McpServer").Get<McpServerOptions>() ?? new McpServerOptions();
var apiOptions = builder.Configuration.GetSection("CatsApi").Get<CatsApiOptions>() ?? new CatsApiOptions();

builder.Services.AddSingleton(serverOptions);
builder.Services.AddSingleton(apiOptions);
builder.Services.AddHttpClient<CatsApiClient>(client =>
{
    var baseUrl = apiOptions.UseGateway ? apiOptions.GatewayBaseUrl : apiOptions.DirectApiBaseUrl;
    client.BaseAddress = new Uri(baseUrl.TrimEnd('/') + "/", UriKind.Absolute);
    client.Timeout = TimeSpan.FromSeconds(Math.Clamp(apiOptions.TimeoutSeconds, 5, 120));
    if (!apiOptions.UseGateway && !string.IsNullOrWhiteSpace(apiOptions.GatewaySharedKey))
        client.DefaultRequestHeaders.TryAddWithoutValidation(apiOptions.GatewayHeaderName, apiOptions.GatewaySharedKey);
});
builder.Services.AddMcpServer()
    .WithHttpTransport(options => options.Stateless = true)
    .WithTools<CatsReadOnlyTools>();

var app = builder.Build();
app.MapGet("/health", () => Results.Ok(new { status = "Healthy", mcpEnabled = serverOptions.Enabled, apiMode = apiOptions.UseGateway ? "Gateway" : "Direct" }));
if (serverOptions.Enabled) app.MapMcp("/mcp");
app.Run();
