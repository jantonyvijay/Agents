namespace CATS.McpServer;

public sealed class McpServerOptions
{
    public bool Enabled { get; set; } = true;
}

public sealed class CatsApiOptions
{
    public bool UseGateway { get; set; } = true;
    public string GatewayBaseUrl { get; set; } = "http://127.0.0.1:7000";
    public string DirectApiBaseUrl { get; set; } = "http://127.0.0.1:7001";
    public string GatewayHeaderName { get; set; } = "X-CATS-Gateway-Key";
    public string GatewaySharedKey { get; set; } = "";
    public string UserName { get; set; } = "";
    public string Password { get; set; } = "";
    public int TimeoutSeconds { get; set; } = 30;
}
