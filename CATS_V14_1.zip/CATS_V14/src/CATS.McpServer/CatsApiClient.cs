using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace CATS.McpServer;

public sealed class CatsApiClient(HttpClient http, CatsApiOptions options)
{
    private readonly SemaphoreSlim loginLock = new(1, 1);
    private string token = "";
    private DateTime tokenExpiresAtUtc;

    public async Task<string> GetAsync(string path, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, path);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await GetTokenAsync(ct));
        using var response = await http.SendAsync(request, ct);
        var content = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"CATS API returned {(int)response.StatusCode}: {ProblemDetail(content)}");
        return content;
    }

    private async Task<string> GetTokenAsync(CancellationToken ct)
    {
        if (!string.IsNullOrWhiteSpace(token) && tokenExpiresAtUtc > DateTime.UtcNow.AddMinutes(1)) return token;
        await loginLock.WaitAsync(ct);
        try
        {
            if (!string.IsNullOrWhiteSpace(token) && tokenExpiresAtUtc > DateTime.UtcNow.AddMinutes(1)) return token;
            if (string.IsNullOrWhiteSpace(options.UserName) || string.IsNullOrWhiteSpace(options.Password))
                throw new InvalidOperationException("CatsApi credentials are not configured.");
            using var response = await http.PostAsJsonAsync("/api/auth/login", new { options.UserName, options.Password }, ct);
            var content = await response.Content.ReadAsStringAsync(ct);
            if (!response.IsSuccessStatusCode)
                throw new InvalidOperationException($"CATS API login returned {(int)response.StatusCode}: {ProblemDetail(content)}");
            using var document = JsonDocument.Parse(content);
            token = document.RootElement.GetProperty("token").GetString() ?? throw new InvalidOperationException("CATS API login did not return a token.");
            tokenExpiresAtUtc = document.RootElement.TryGetProperty("expiresAtUtc", out var expiry) && expiry.TryGetDateTime(out var value)
                ? value : DateTime.UtcNow.AddMinutes(5);
            return token;
        }
        finally { loginLock.Release(); }
    }

    private static string ProblemDetail(string content)
    {
        try
        {
            using var document = JsonDocument.Parse(content);
            if (document.RootElement.TryGetProperty("detail", out var detail)) return detail.GetString() ?? content;
            if (document.RootElement.TryGetProperty("message", out var message)) return message.GetString() ?? content;
        }
        catch (JsonException) { }
        return content.Length <= 500 ? content : content[..500];
    }
}
