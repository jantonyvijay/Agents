using System.Security.Cryptography;
using System.Text;

namespace CATS.App;

public sealed class GatewayAccessMiddleware(RequestDelegate next, GatewayAccessOptions options)
{
    public async Task InvokeAsync(HttpContext context)
    {
        if (options.RequireForApi && context.Request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase))
        {
            var supplied = context.Request.Headers[options.HeaderName].ToString();
            if (string.IsNullOrWhiteSpace(supplied) || !FixedEquals(supplied, options.SharedKey))
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                context.Response.ContentType = "application/problem+json";
                await context.Response.WriteAsJsonAsync(new
                {
                    title = "Gateway access required",
                    status = 403,
                    detail = "CATS API requests must be routed through the configured gateway."
                });
                return;
            }
        }
        await next(context);
    }

    private static bool FixedEquals(string left, string right)
    {
        var a = Encoding.UTF8.GetBytes(left ?? "");
        var b = Encoding.UTF8.GetBytes(right ?? "");
        return a.Length == b.Length && CryptographicOperations.FixedTimeEquals(a, b);
    }
}
