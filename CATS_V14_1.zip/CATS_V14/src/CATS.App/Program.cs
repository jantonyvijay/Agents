using System.Text;
using System.Text.Json.Serialization;
using CATS.App;
using CATS.AI;
using CATS.Core;
using CATS.Infrastructure;
using CATS.Workflow;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

var database = builder.Configuration.GetSection("Database").Get<DatabaseOptions>() ?? new DatabaseOptions();
var startup = builder.Configuration.GetSection("DatabaseStartup").Get<DatabaseStartupOptions>() ?? new DatabaseStartupOptions();
var security = builder.Configuration.GetSection("Security").Get<SecurityOptions>() ?? new SecurityOptions();
var jwt = builder.Configuration.GetSection("Jwt").Get<JwtOptions>() ?? new JwtOptions();
var storage = builder.Configuration.GetSection("Storage").Get<StorageOptions>() ?? new StorageOptions();
var agent = builder.Configuration.GetSection("Agent").Get<AgentOptions>() ?? new AgentOptions();
var aiQuery = builder.Configuration.GetSection("AIQuery").Get<AiQueryOptions>() ?? new AiQueryOptions();
var assistant = builder.Configuration.GetSection("Assistant").Get<CatsAssistantOptions>() ?? new CatsAssistantOptions();
var mcp = builder.Configuration.GetSection("Mcp").Get<McpOptions>() ?? new McpOptions();
var gatewayAccess = builder.Configuration.GetSection("GatewayAccess").Get<GatewayAccessOptions>() ?? new GatewayAccessOptions();

if(string.IsNullOrWhiteSpace(database.ConnectionString)) throw new InvalidOperationException("Database:ConnectionString is required.");
if(Convert.FromBase64String(security.DataEncryptionKeyBase64).Length != 32) throw new InvalidOperationException("Security:DataEncryptionKeyBase64 must decode to exactly 32 bytes.");
if(Encoding.UTF8.GetByteCount(jwt.SigningKey) < 32) throw new InvalidOperationException("Jwt:SigningKey must be at least 32 bytes.");

builder.Services.AddSingleton(database);
builder.Services.AddSingleton(startup);
builder.Services.AddSingleton(security);
builder.Services.AddSingleton(jwt);
builder.Services.AddSingleton(storage);
builder.Services.AddSingleton(agent);
builder.Services.AddSingleton(aiQuery);
builder.Services.AddSingleton(assistant);
builder.Services.AddSingleton(mcp);
builder.Services.AddSingleton(gatewayAccess);
builder.Services.AddSingleton<DbConnectionFactory>();
builder.Services.AddSingleton<AdoHelper>();
builder.Services.AddSingleton<Pbkdf2PasswordHasher>();
builder.Services.AddSingleton<IPasswordHasher>(sp=>sp.GetRequiredService<Pbkdf2PasswordHasher>());
builder.Services.AddSingleton<IDataProtectorService,AesDataProtector>();
builder.Services.AddSingleton<DatabaseBootstrapper>();
builder.Services.AddScoped<ICatsRepository,CatsRepository>();
builder.Services.AddScoped<IPlatformRepository,PlatformRepository>();
builder.Services.AddScoped<AssignmentRuleEngine>();
builder.Services.AddScoped<MafWorkflowGraphService>();
builder.Services.AddScoped<IAgentDecisionService,MafAgentDecisionService>();
builder.Services.AddScoped<IAiQueryAssistantService,MafAiQueryAssistantService>();
builder.Services.AddScoped<IMcpDiscoveryService,McpDiscoveryService>();
builder.Services.AddScoped<ICatsAssistantService,CatsAssistantService>();
builder.Services.AddScoped<IWorkflowEngine,CatsWorkflowEngine>();
builder.Services.AddScoped<AlertApplicationService>();
builder.Services.AddSingleton<JwtTokenService>();

builder.Services.AddControllersWithViews().AddJsonOptions(o=>o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o=>
{
    o.RequireHttpsMetadata=false;
    o.SaveToken=false;
    o.TokenValidationParameters=new TokenValidationParameters
    {
        ValidateIssuer=true,ValidIssuer=jwt.Issuer,ValidateAudience=true,ValidAudience=jwt.Audience,
        ValidateIssuerSigningKey=true,IssuerSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.SigningKey)),
        ValidateLifetime=true,ClockSkew=TimeSpan.FromMinutes(1),NameClaimType=System.Security.Claims.ClaimTypes.Name,RoleClaimType=System.Security.Claims.ClaimTypes.Role
    };
});
builder.Services.AddAuthorization();
builder.Services.Configure<ForwardedHeadersOptions>(o=>
{
    o.ForwardedHeaders=ForwardedHeaders.XForwardedFor|ForwardedHeaders.XForwardedProto;
    o.KnownNetworks.Clear(); o.KnownProxies.Clear();
});

var app=builder.Build();
app.UseForwardedHeaders();
if(!app.Environment.IsDevelopment()){app.UseHsts();}
app.UseMiddleware<ApiExceptionMiddleware>();
app.UseMiddleware<GatewayAccessMiddleware>();
app.UseStaticFiles(new StaticFileOptions{OnPrepareResponse=ctx=>ctx.Context.Response.Headers["Cache-Control"]="public,max-age=3600"});
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapControllerRoute(name:"default",pattern:"{controller=Home}/{action=Index}/{id?}");

if(startup.AutoInitialize)
{
    using var scope=app.Services.CreateScope();
    var bootstrap=scope.ServiceProvider.GetRequiredService<DatabaseBootstrapper>();
    await bootstrap.InitializeAsync(Path.Combine(AppContext.BaseDirectory,"db"));
}

app.Run();
