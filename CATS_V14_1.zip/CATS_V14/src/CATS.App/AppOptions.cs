namespace CATS.App;

public sealed class JwtOptions
{
    public string Issuer { get; set; } = "CATS";
    public string Audience { get; set; } = "CATS.Web";
    public string SigningKey { get; set; } = "";
    public int ExpiryMinutes { get; set; } = 60;
}

public sealed class StorageOptions
{
    public string AttachmentRoot { get; set; } = "App_Data/attachments";
    public long MaxFileSizeBytes { get; set; } = 20 * 1024 * 1024;
    public string[] AllowedExtensions { get; set; } = [".pdf",".png",".jpg",".jpeg",".doc",".docx",".xls",".xlsx",".csv",".txt"];
}

public sealed class DatabaseStartupOptions
{
    public bool AutoInitialize { get; set; } = true;
}

public sealed class GatewayAccessOptions
{
    public bool RequireForApi { get; set; } = true;
    public string HeaderName { get; set; } = "X-CATS-Gateway-Key";
    public string SharedKey { get; set; } = "cats-dev-gateway-key-change-me";
}
