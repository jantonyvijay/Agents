using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using CATS.Core;
using Microsoft.IdentityModel.Tokens;

namespace CATS.App;

public sealed class JwtTokenService(JwtOptions options)
{
    public LoginResponse Create(UserRecord user)
    {
        var expiry=DateTime.UtcNow.AddMinutes(Math.Clamp(options.ExpiryMinutes,5,1440));
        var claims=new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub,user.Id),
            new(JwtRegisteredClaimNames.UniqueName,user.UserName),
            new(ClaimTypes.NameIdentifier,user.Id),
            new(ClaimTypes.Name,user.UserName),
            new(ClaimTypes.Role,user.RoleCode),
            new("displayName",user.DisplayName),
            new("department",user.DepartmentCode),
            new("branch",user.BranchCode)
        };
        foreach(var p in user.Permissions()) claims.Add(new("permission",p));
        var key=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(options.SigningKey));
        var token=new JwtSecurityToken(options.Issuer,options.Audience,claims,expires:expiry,signingCredentials:new SigningCredentials(key,SecurityAlgorithms.HmacSha256));
        return new LoginResponse
        {
            Token=new JwtSecurityTokenHandler().WriteToken(token),ExpiresAtUtc=expiry,
            User=new CurrentUser{Id=user.Id,UserName=user.UserName,DisplayName=user.DisplayName,RoleCode=user.RoleCode,DepartmentCode=user.DepartmentCode,BranchCode=user.BranchCode,Permissions=user.Permissions()}
        };
    }
}

public static class PrincipalExtensions
{
    public static CurrentUser ToCurrentUser(this ClaimsPrincipal p)
    {
        if(p.Identity?.IsAuthenticated!=true) throw new UnauthorizedAccessException("Authentication required.");
        return new CurrentUser
        {
            Id=p.FindFirstValue(ClaimTypes.NameIdentifier) ?? "",
            UserName=p.FindFirstValue(ClaimTypes.Name) ?? "",
            DisplayName=p.FindFirstValue("displayName") ?? p.Identity.Name ?? "",
            RoleCode=p.FindFirstValue(ClaimTypes.Role) ?? "",
            DepartmentCode=p.FindFirstValue("department") ?? "",
            BranchCode=p.FindFirstValue("branch") ?? "",
            Permissions=p.FindAll("permission").Select(x=>x.Value).ToList()
        };
    }
}
