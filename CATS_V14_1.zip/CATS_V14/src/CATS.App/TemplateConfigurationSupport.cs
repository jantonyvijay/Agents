using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;

namespace CATS.App.Controllers;

internal static class TemplateConfigurationSupport
{
    internal static readonly string[] AllBaseDataModes = ["ManualSingle", "BulkFileUpload", "Sftp", "FcQuery"];

    internal static TemplateViewConfiguration GetViewConfiguration(this TemplateRecord template)
    {
        try
        {
            return JsonSerializer.Deserialize<TemplateViewConfiguration>(template.ViewConfigurationJson, JsonDefaults.Options)
                ?? new TemplateViewConfiguration();
        }
        catch (JsonException)
        {
            return new TemplateViewConfiguration();
        }
    }

    internal static bool AllowsBaseDataMode(this TemplateRecord template, string mode)
        => template.GetViewConfiguration().BaseDataModes.Contains(mode, StringComparer.OrdinalIgnoreCase);
}
