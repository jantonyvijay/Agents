using CATS.Core;
using CATS.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using System.Text;
using System.Text.Json;

namespace CATS.App.Controllers;

[Authorize,ApiController,Route("api/platform")]
public sealed class PlatformController(IPlatformRepository platform, ICatsRepository repo, IDataProtectorService protector):ControllerBase
{
    private CurrentUser U()=>User.ToCurrentUser();
    private CurrentUser Require(string permission){var u=U();if(!u.HasPermission(permission))throw new UnauthorizedAccessException($"Permission {permission} is required.");return u;}

    [HttpGet("dashboard/widgets")]
    public async Task<IActionResult> Widgets(CancellationToken ct){var u=Require(PlatformPermissions.DashboardView);return Ok(await platform.GetDashboardWidgetsAsync(u,ct));}
    [HttpGet("dashboard/config")]
    public async Task<IActionResult> WidgetConfig(CancellationToken ct){Require(PlatformPermissions.DashboardConfigure);return Ok(await platform.GetDashboardWidgetConfigurationAsync(ct));}
    [HttpPost("dashboard/config/{roleCode}")]
    public async Task<IActionResult> SaveWidget(string roleCode,DashboardWidgetRecord item,CancellationToken ct){Require(PlatformPermissions.DashboardConfigure);await platform.SaveDashboardWidgetAsync(item,roleCode,ct);return Ok();}

    [HttpGet("dashboard/templates")]
    public async Task<IActionResult> TemplateDashboards([FromQuery]bool includeInactive=false,CancellationToken ct=default){var u=Require(PlatformPermissions.DashboardView);if(includeInactive)Require(PlatformPermissions.DashboardConfigure);return Ok(await platform.GetTemplateDashboardsAsync(u,includeInactive,ct));}
    [HttpGet("dashboard/templates/{id}")]
    public async Task<IActionResult> TemplateDashboard(string id,CancellationToken ct){var u=Require(PlatformPermissions.DashboardView);var d=await platform.GetTemplateDashboardAsync(id,u,false,ct);return d is null?NotFound():Ok(d);}
    [HttpGet("dashboard/templates/{id}/data")]
    public async Task<IActionResult> TemplateDashboardData(string id,[FromQuery]TemplateDashboardQuery query,CancellationToken ct){var u=Require(PlatformPermissions.DashboardView);return Ok(await platform.GetTemplateDashboardDataAsync(id,query,u,protector.Unprotect,value => protector.Mask(value),ct));}
    [HttpPost("dashboard/templates")]
    public async Task<IActionResult> SaveTemplateDashboard(TemplateDashboardRecord item,CancellationToken ct){Require(PlatformPermissions.DashboardConfigure);if(string.IsNullOrWhiteSpace(item.Name)||string.IsNullOrWhiteSpace(item.Title)||string.IsNullOrWhiteSpace(item.TemplateId))return BadRequest("Dashboard name, title and template are required.");await platform.SaveTemplateDashboardAsync(item,ct);return Ok(item);}

    [HttpGet("ingestion/dashboard")]
    public async Task<IActionResult> IngestionDashboard(CancellationToken ct){Require(PlatformPermissions.IngestionView);return Ok(await platform.GetIngestionDashboardAsync(ct));}
    [HttpGet("ingestion/configurations")]
    public async Task<IActionResult> Configs(CancellationToken ct){Require(PlatformPermissions.IngestionView);return Ok(await platform.GetIngestionConfigurationsAsync(ct));}
    [HttpPost("ingestion/configurations")]
    public async Task<IActionResult> SaveConfig(IngestionConfigurationRecord item,CancellationToken ct)
    {
        Require(PlatformPermissions.IngestionManage);
        item.Name=(item.Name??"").Trim();
        item.TemplateId=(item.TemplateId??"").Trim();
        item.SourceType=(item.SourceType??"").Trim().ToUpperInvariant();
        if(string.IsNullOrWhiteSpace(item.Name)||string.IsNullOrWhiteSpace(item.TemplateId))return BadRequest("Task name and alert type are required.");
        if(item.SourceType is not ("SFTP" or "QUERY"))return BadRequest("Data source must be SFTP or Query.");
        var template=await repo.GetTemplateAsync(item.TemplateId,ct);
        if(template==null)return BadRequest("Selected Alert Type was not found.");
        var requiredMode=item.SourceType=="SFTP"?"Sftp":"FcQuery";
        if(!template.AllowsBaseDataMode(requiredMode))return BadRequest(item.SourceType=="SFTP"?"SFTP Location is disabled for this Alert Type.":"FC Query is disabled for this Alert Type.");

        item.FilePath=(item.FilePath??"").Trim();
        item.FileName=(item.FileName??"").Trim();
        item.QueryText=(item.QueryText??"").Trim();
        if(item.SourceType=="SFTP")
        {
            if(string.IsNullOrWhiteSpace(item.FilePath)||string.IsNullOrWhiteSpace(item.FileName))return BadRequest("File path and file name are required for SFTP.");
            item.FilePattern=item.FileName;
            item.QueryText="";
        }
        else
        {
            if(string.IsNullOrWhiteSpace(item.QueryText))return BadRequest("Query text is required for a Query source.");
            item.FilePath="";
            item.FileName="";
            item.FilePattern="";
        }

        List<IngestionScheduleTrigger>? triggers;
        try { triggers=JsonSerializer.Deserialize<List<IngestionScheduleTrigger>>(item.ScheduleTriggersJson??"[]",JsonDefaults.Options); }
        catch(JsonException) { return BadRequest("Task triggers are invalid."); }
        if(triggers is null||triggers.Count==0)return BadRequest("Add at least one task trigger.");
        if(triggers.Count>20)return BadRequest("A task can contain up to 20 triggers.");
        foreach(var trigger in triggers)
        {
            trigger.Id=string.IsNullOrWhiteSpace(trigger.Id)?Guid.NewGuid().ToString("N"):trigger.Id.Trim();
            trigger.Frequency=(trigger.Frequency??"").Trim().ToUpperInvariant();
            if(!DateOnly.TryParseExact(trigger.StartDate,"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out var startDate))return BadRequest("Every trigger requires a valid start date.");
            if(!TimeOnly.TryParseExact(trigger.StartTime,"HH:mm",CultureInfo.InvariantCulture,DateTimeStyles.None,out var startTime))return BadRequest("Every trigger requires a valid start time.");
            trigger.StartDate=startDate.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
            trigger.StartTime=startTime.ToString("HH:mm",CultureInfo.InvariantCulture);
            trigger.Cron=trigger.Frequency switch
            {
                "ONCE"=>$"ONCE:{trigger.StartDate}T{trigger.StartTime}",
                "DAILY"=>$"{startTime.Minute} {startTime.Hour} * * *",
                "WEEKLY" when trigger.DayOfWeek is >=0 and <=6=>$"{startTime.Minute} {startTime.Hour} * * {trigger.DayOfWeek}",
                "MONTHLY" when trigger.DayOfMonth is >=1 and <=31=>$"{startTime.Minute} {startTime.Hour} {trigger.DayOfMonth} * *",
                _=>""
            };
            if(string.IsNullOrWhiteSpace(trigger.Cron))return BadRequest($"Trigger frequency or day is invalid: {trigger.Frequency}.");
        }
        item.ScheduleTriggersJson=JsonSerializer.Serialize(triggers,JsonDefaults.Options);
        item.ScheduleCron=triggers[0].Cron;
        item.IntervalMinutes=Math.Max(1,item.IntervalMinutes);
        item.FieldMappingJson=string.IsNullOrWhiteSpace(item.FieldMappingJson)?"{}":item.FieldMappingJson;
        await platform.SaveIngestionConfigurationAsync(item,ct);
        return Ok(item);
    }
    [HttpGet("ingestion/connectors")]
    public async Task<IActionResult> Connectors(CancellationToken ct){Require(PlatformPermissions.IngestionView);return Ok(await platform.GetConnectorsAsync(ct));}
    [HttpPost("ingestion/connectors")]
    public async Task<IActionResult> SaveConnector(ConnectorRecord item,CancellationToken ct){Require(PlatformPermissions.IngestionManage);await platform.SaveConnectorAsync(item,ct);return Ok(item);}
    [HttpGet("ingestion/runs")]
    public async Task<IActionResult> Runs([FromQuery]int take=100,CancellationToken ct=default){Require(PlatformPermissions.IngestionView);return Ok(await platform.GetIngestionRunsAsync(take,ct));}

    [HttpGet("reports/{type}")]
    public async Task<IActionResult> Report(string type,[FromQuery]ReportFilter filter,CancellationToken ct)
    {
        var permission=type.ToUpperInvariant() switch{"MIS"=>PlatformPermissions.ReportsMis,"ALERTWISE"=>PlatformPermissions.ReportsAlertWise,_=>PlatformPermissions.ReportsAll};var u=Require(permission);var report=await platform.GetReportAsync(type,filter,u,ct);RemoveTemplateColumns(report.Data);return Ok(report);
    }
    [HttpGet("reports/{type}/export")]
    public async Task<IActionResult> ExportReport(string type,[FromQuery]ReportFilter filter,CancellationToken ct)
    {
        var permission=type.ToUpperInvariant() switch{"MIS"=>PlatformPermissions.ReportsMis,"ALERTWISE"=>PlatformPermissions.ReportsAlertWise,_=>PlatformPermissions.ReportsAll};
        var user=Require(permission); filter.Page=1; filter.PageSize=200;
        var report=await platform.GetReportAsync(type,filter,user,ct); var rows=report.Data; RemoveTemplateColumns(rows);
        var columns=rows.SelectMany(x=>x.Values.Keys).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        static string Csv(object? value)=>"\""+(Convert.ToString(value)?.Replace("\"","\"\"")??"")+"\"";
        var csv=new StringBuilder().AppendLine(string.Join(',',columns.Select(Csv)));
        foreach(var row in rows)csv.AppendLine(string.Join(',',columns.Select(x=>Csv(row.Values.GetValueOrDefault(x)))));
        return File(Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(csv.ToString())).ToArray(),"text/csv",$"CATS-{type}-{DateTime.UtcNow:yyyyMMdd-HHmmss}.csv");
    }

    private static void RemoveTemplateColumns(IEnumerable<ReportRow> rows)
    {
        foreach(var row in rows)
            foreach(var key in row.Values.Keys.Where(x=>x.Equals("Template",StringComparison.OrdinalIgnoreCase)||x.Equals("TemplateName",StringComparison.OrdinalIgnoreCase)||x.Equals("TemplateId",StringComparison.OrdinalIgnoreCase)).ToList())
                row.Values.Remove(key);
    }

    [HttpGet("mail/configurations")]
    public async Task<IActionResult> MailConfigs(CancellationToken ct){Require(PlatformPermissions.MailManage);return Ok(await platform.GetMailConfigurationsAsync(ct));}
    [HttpPost("mail/configurations")]
    public async Task<IActionResult> SaveMailConfig(MailConfigurationRecord item,CancellationToken ct){Require(PlatformPermissions.MailManage);if(!string.IsNullOrWhiteSpace(item.SecretEncrypted)&&!item.SecretEncrypted.StartsWith("v1:"))item.SecretEncrypted=protector.Protect(item.SecretEncrypted);await platform.SaveMailConfigurationAsync(item,ct);item.SecretEncrypted="";return Ok(item);}
    [HttpGet("mail/templates")]
    public async Task<IActionResult> MailTemplates(CancellationToken ct){Require(PlatformPermissions.MailManage);return Ok(await platform.GetMailTemplatesAsync(ct));}
    [HttpPost("mail/templates")]
    public async Task<IActionResult> SaveMailTemplate(MailTemplateRecord item,CancellationToken ct){Require(PlatformPermissions.MailManage);if(string.IsNullOrWhiteSpace(item.TemplateId)||string.IsNullOrWhiteSpace(item.EventCode)||string.IsNullOrWhiteSpace(item.SubjectTemplate)||string.IsNullOrWhiteSpace(item.BodyTemplate))return BadRequest("Alert template, event, subject and email body are required.");await platform.SaveMailTemplateAsync(item,ct);return Ok(item);}
    [HttpGet("mail/logs")]
    public async Task<IActionResult> MailLogs([FromQuery]int take=100,CancellationToken ct=default){Require(PlatformPermissions.MailManage);return Ok(await platform.GetMailLogsAsync(take,ct));}
}
