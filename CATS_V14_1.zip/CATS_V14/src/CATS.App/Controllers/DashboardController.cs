using CATS.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.App.Controllers;

[Authorize]
[ApiController]
[Route("api/dashboard")]
public sealed class DashboardController(ICatsRepository repo) : ControllerBase
{
    [HttpGet("aging")]
    public async Task<ActionResult<DashboardAgingResponse>> Aging([FromQuery]AlertListFilter filter,CancellationToken ct) => Ok(await repo.GetDashboardAgingAsync(User.ToCurrentUser(),filter,ct));
}
