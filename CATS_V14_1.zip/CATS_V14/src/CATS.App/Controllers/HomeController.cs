using Microsoft.AspNetCore.Mvc;
namespace CATS.App.Controllers;
public sealed class HomeController : Controller
{
    public IActionResult Index()=>View();
}
