using CATS.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace CATS.App.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(ICatsRepository repo,IPlatformRepository platform,IPasswordHasher hasher,JwtTokenService tokens) : ControllerBase
{
    [HttpPost("login")]
    public async Task<ActionResult<LoginResponse>> Login(LoginRequest request,CancellationToken ct)
    {
        var user=await repo.GetUserByUserNameAsync(request.UserName.Trim(),ct);
        if(user==null || !user.IsActive || !hasher.Verify(request.Password,user.PasswordHash))
        {
            await repo.InsertAuditAsync(new AuditRecord{Id=Guid.NewGuid().ToString("N"),UserId=user?.Id??"",UserName=request.UserName,RoleCode=user?.RoleCode??"",Action="LOGIN_FAILED",EntityType="Authentication",Remarks="Invalid credentials",IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow},ct);
            return Unauthorized(new{message="Invalid user name or password."});
        }
        user.PermissionsJson=System.Text.Json.JsonSerializer.Serialize(await platform.GetEffectivePermissionsAsync(user.Id,ct));
        await repo.InsertAuditAsync(new AuditRecord{Id=Guid.NewGuid().ToString("N"),UserId=user.Id,UserName=user.UserName,RoleCode=user.RoleCode,Action="LOGIN",EntityType="Authentication",Remarks="Login successful",IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow},ct);
        return Ok(tokens.Create(user));
    }
    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout(CancellationToken ct)
    {
        var current=User.ToCurrentUser();
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id=Guid.NewGuid().ToString("N"),UserId=current.Id,UserName=current.UserName,RoleCode=current.RoleCode,
            Action="LOGOUT",EntityType="Authentication",Remarks="User signed out",
            IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString(),CreatedAtUtc=DateTime.UtcNow
        },ct);
        return NoContent();
    }

}
