using CATS.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.App.Controllers;

[Authorize]
[ApiController]
[Route("api/meta")]
public sealed class MetaController(ICatsRepository repo) : ControllerBase
{
    [HttpGet("roles")]
    public async Task<IActionResult> Roles(CancellationToken ct) => Ok(await repo.GetRoleCodesAsync(ct));
}
