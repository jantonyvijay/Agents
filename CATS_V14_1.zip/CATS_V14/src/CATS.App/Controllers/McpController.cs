using CATS.AI;
using CATS.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.App.Controllers;

[Authorize, ApiController, Route("api/mcp")]
public sealed class McpController(IMcpDiscoveryService mcp, ILogger<McpController> log) : ControllerBase
{
    private CurrentUser RequireManage()
    {
        var user = User.ToCurrentUser();
        if (!user.HasPermission(PlatformPermissions.McpManage))
            throw new UnauthorizedAccessException("MCP management permission is required.");
        return user;
    }

    [HttpGet("servers")]
    public IActionResult Servers()
    {
        RequireManage();
        return Ok(mcp.GetConfiguredServers());
    }

    [HttpPost("servers/{serverCode}/discover")]
    public async Task<IActionResult> Discover(string serverCode, CancellationToken ct)
    {
        RequireManage();
        try
        {
            return Ok(await mcp.DiscoverAsync(serverCode, ct));
        }
        catch (Exception ex) when (ex is not KeyNotFoundException and not InvalidOperationException and not OperationCanceledException)
        {
            log.LogWarning(ex, "MCP discovery connection failed for server {ServerCode}", serverCode);
            return Problem(
                statusCode: StatusCodes.Status502BadGateway,
                title: "MCP server connection failed",
                detail: $"Could not connect to MCP server '{serverCode}'. Verify that the server is running, its endpoint is reachable from the CATS API host, and any configured headers are valid. Correlation ID: {HttpContext.TraceIdentifier}");
        }
    }

    [HttpPost("discover")]
    public async Task<IActionResult> DiscoverEndpoint(McpEndpointDiscoveryRequest request, CancellationToken ct)
    {
        RequireManage();
        try
        {
            return Ok(await mcp.DiscoverEndpointAsync(request, ct));
        }
        catch (InvalidOperationException) { throw; }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            log.LogWarning(ex, "Temporary MCP endpoint discovery failed for {Endpoint}", request.Endpoint);
            return Problem(
                statusCode: StatusCodes.Status502BadGateway,
                title: "MCP server connection failed",
                detail: $"Could not connect to the supplied MCP endpoint. Verify that it is reachable from the CATS API host and supports Streamable HTTP or SSE. Correlation ID: {HttpContext.TraceIdentifier}");
        }
    }
}
