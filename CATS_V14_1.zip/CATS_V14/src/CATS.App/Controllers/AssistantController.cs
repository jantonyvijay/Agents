using System.Security.Cryptography;
using System.Text;
using CATS.AI;
using CATS.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CATS.App.Controllers;

[Authorize, ApiController, Route("api/assistant")]
public sealed class AssistantController(ICatsAssistantService assistant, ICatsRepository repo) : ControllerBase
{
    [HttpGet("status")]
    public IActionResult Status()
    {
        var user = User.ToCurrentUser();
        return Ok(new
        {
            enabled = assistant.IsEnabled && user.HasPermission(PlatformPermissions.AssistantUse),
            permissionGranted = user.HasPermission(PlatformPermissions.AssistantUse),
            provider = assistant.Provider,
            model = assistant.Model
        });
    }

    [HttpPost("chat")]
    public async Task<IActionResult> Chat(CatsAssistantRequest request, CancellationToken ct)
    {
        var user = User.ToCurrentUser();
        if (!user.HasPermission(PlatformPermissions.AssistantUse))
            throw new UnauthorizedAccessException("CATS Assistant permission is required.");
        if (string.IsNullOrWhiteSpace(request.Message) || request.Message.Length > 4000)
            return BadRequest(new { message = "Question is required and must not exceed 4000 characters." });

        var result = await assistant.AskAsync(request, user, ct);
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(request.Message.Trim())));
        await repo.InsertAuditAsync(new AuditRecord
        {
            Id = Guid.NewGuid().ToString("N"), UserId = user.Id, UserName = user.UserName, RoleCode = user.RoleCode,
            Action = "ASSISTANT_QUERY", EntityType = "Assistant", EntityId = null,
            Remarks = $"Read-only CATS Assistant question submitted. SHA256={hash}",
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), CreatedAtUtc = DateTime.UtcNow
        }, ct);
        return Ok(result);
    }
}
