using System.Net;
using System.Text.Json;

namespace CATS.App;

public sealed class ApiExceptionMiddleware(RequestDelegate next,ILogger<ApiExceptionMiddleware> log)
{
    public async Task Invoke(HttpContext ctx)
    {
        try{await next(ctx);}
        catch(Exception ex) when(ctx.Request.Path.StartsWithSegments("/api"))
        {
            log.LogError(ex,"CATS API failure on {Path}",ctx.Request.Path);
            ctx.Response.ContentType="application/problem+json";
            ctx.Response.StatusCode=ex switch{UnauthorizedAccessException=>StatusCodes.Status403Forbidden,KeyNotFoundException=>StatusCodes.Status404NotFound,InvalidOperationException=>StatusCodes.Status409Conflict,_=>StatusCodes.Status500InternalServerError};
            await ctx.Response.WriteAsync(JsonSerializer.Serialize(new{type="about:blank",title=ex.GetType().Name,status=ctx.Response.StatusCode,detail=ctx.Response.StatusCode==500?"Unexpected server error. Check logs for the correlation ID.":ex.Message,traceId=ctx.TraceIdentifier}));
        }
    }
}
