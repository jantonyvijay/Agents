using System.ClientModel;
using System.Text.Json;
using CATS.Core;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using OpenAI;
using OpenAI.Chat;

namespace CATS.Workflow;

public sealed class AgentOptions
{
    public bool Enabled { get; set; }
    public string Provider { get; set; } = "OpenAICompatible";
    public string Endpoint { get; set; } = "https://generativelanguage.googleapis.com/v1beta/openai/";
    public string Model { get; set; } = "gemini-2.5-flash";
    public string ApiKey { get; set; } = "";
}

/// <summary>
/// Microsoft Agent Framework-backed decision service. The endpoint is configurable and can target
/// an OpenAI-compatible model endpoint. Agent output is constrained to the AgentDecision DTO.
/// </summary>
public sealed class MafAgentDecisionService(AgentOptions options) : IAgentDecisionService
{
    public bool IsEnabled => options.Enabled && !string.IsNullOrWhiteSpace(options.ApiKey);

    public async Task<AgentDecision> DecideAsync(WorkflowStage stage, AlertRecord alert, string dynamicDataJson, CancellationToken ct = default)
    {
        if (!IsEnabled) throw new InvalidOperationException("MAF agent execution is disabled or the API key is not configured.");
        if (string.IsNullOrWhiteSpace(options.Endpoint)) throw new InvalidOperationException("Agent endpoint is required.");

        var clientOptions = new OpenAIClientOptions { Endpoint = new Uri(options.Endpoint, UriKind.Absolute) };
        var chatClient = new ChatClient(options.Model, new ApiKeyCredential(options.ApiKey), clientOptions);
        AIAgent agent = chatClient.AsAIAgent(
            instructions: stage.AgentInstructions ?? "You are a controlled enterprise workflow decision agent. Return only a valid action defined by the workflow and a short reason.",
            name: "CATSWorkflowDecision");

        var allowed = stage.Transitions.Select(t => t.Action).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        var prompt = (stage.AgentPromptTemplate ?? "Evaluate the alert and select the next workflow action.") + "\n" +
                     $"Allowed actions: {string.Join(", ", allowed)}\n" +
                     $"AlertNo: {alert.AlertNo}\nAlertType: {alert.AlertType}\nPriority: {alert.Priority}\nBranch: {alert.BranchCode}\n" +
                     $"Dynamic data JSON: {dynamicDataJson}\n" +
                     "Return a structured AgentDecision with Action and Reason.";

        AgentResponse<AgentDecision> response = await agent.RunAsync<AgentDecision>(prompt, cancellationToken: ct);
        var result = response.Result ?? throw new InvalidOperationException("Agent returned no structured decision.");
        if (!allowed.Contains(result.Action, StringComparer.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Agent returned disallowed action '{result.Action}'.");
        return result;
    }
}

/// <summary>
/// Builds a Microsoft Agent Framework graph from the stored CATS workflow definition.
/// CATS persists human work-items itself; this graph is used for structural validation/visualization
/// and deterministic/agent composition without coupling the UI to hard-coded stages.
/// </summary>
public sealed class MafWorkflowGraphService
{
    public Microsoft.Agents.AI.Workflows.Workflow BuildGraph(WorkflowDefinitionModel definition)
    {
        if (definition.Stages.Count == 0) throw new InvalidOperationException("Workflow has no stages.");
        var bindings = new Dictionary<string, ExecutorBinding>(StringComparer.OrdinalIgnoreCase);
        foreach (var stage in definition.Stages)
        {
            Func<string, IWorkflowContext, ValueTask> passThrough =
                (message, context) => context.SendMessageAsync(message);
            bindings[stage.Id] = passThrough.BindAsExecutor(stage.Id);
        }

        var builder = new WorkflowBuilder(bindings[definition.StartStageId]).WithName("CATS Dynamic Workflow");
        var edges = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var stage in definition.Stages)
        {
            var targets = stage.Transitions.Where(t => !string.IsNullOrWhiteSpace(t.ToStageId)).Select(t => t.ToStageId!)
                .Concat(stage.Conditions.Select(c => c.ToStageId))
                .Concat(string.IsNullOrWhiteSpace(stage.DefaultNextStageId) ? [] : new[] { stage.DefaultNextStageId! })
                .Distinct(StringComparer.OrdinalIgnoreCase);
            foreach (var target in targets)
            {
                if (!bindings.ContainsKey(target)) throw new InvalidOperationException($"Unknown stage target '{target}'.");
                var key = stage.Id + "->" + target;
                if (edges.Add(key)) builder.AddEdge(bindings[stage.Id], bindings[target]);
            }
        }
        return builder.Build();
    }

    public string ToMermaid(WorkflowDefinitionModel definition) => BuildGraph(definition).ToMermaidString();
}

/// <summary>
/// Optional AI-assisted query drafting. This never raises a query or changes workflow state;
/// it only returns draft text for the logged-in user to review/edit before using the existing RaiseQuery action.
/// OpenAI-compatible endpoints can point to an approved hosted LLM or an internal/local SLM.
/// </summary>
public sealed class AiQueryOptions
{
    public bool Enabled { get; set; }
    public string Provider { get; set; } = "OpenAICompatible";
    public string Endpoint { get; set; } = "https://generativelanguage.googleapis.com/v1beta/openai/";
    public string Model { get; set; } = "gemini-2.5-flash";
    public string ApiKey { get; set; } = "";
    public bool MaskPiData { get; set; } = true;
    public int MaxContextCharacters { get; set; } = 12000;
    public string SystemInstructions { get; set; } = "You are the CATS enterprise query drafting assistant. Draft only a concise clarification query based on the supplied authorised alert context. Do not approve, reject, verify, close, reassign, or execute any workflow action. Do not invent facts. If information is insufficient, ask for the missing information.";
    public List<AiQueryRule> Rules { get; set; } = [];
}

public sealed class AiQueryRule
{
    public bool Enabled { get; set; } = true;
    public string TemplateId { get; set; } = "*";
    public string AlertType { get; set; } = "*";
    public string StageId { get; set; } = "*";
    public string RoleCode { get; set; } = "*";
    public string? Provider { get; set; }
    public string? Endpoint { get; set; }
    public string? Model { get; set; }
    public string? ApiKey { get; set; }
    public string? PromptTemplate { get; set; }
}

public sealed record AiQueryAvailability(bool Enabled, string Provider, string Model)
{
    public static readonly AiQueryAvailability Disabled = new(false, "", "");
}

public sealed class AiQueryContext
{
    public string TemplateId { get; set; } = "";
    public string TemplateName { get; set; } = "";
    public string AlertType { get; set; } = "";
    public string StageId { get; set; } = "";
    public string StageName { get; set; } = "";
    public string RoleCode { get; set; } = "";
    public string AlertNo { get; set; } = "";
    public string Status { get; set; } = "";
    public string Priority { get; set; } = "";
    public string BranchCode { get; set; } = "";
    public string CustomerId { get; set; } = "";
    public string AccountId { get; set; } = "";
    public string DynamicDataJson { get; set; } = "{}";
    public string PreviousQueriesJson { get; set; } = "[]";
    public string? UserInstruction { get; set; }
}

public sealed class AiQuerySuggestion
{
    public string QueryText { get; set; } = "";
    public string Reason { get; set; } = "";
    public string Provider { get; set; } = "";
    public string Model { get; set; } = "";
}

public sealed class AiQueryModelResult
{
    public string QueryText { get; set; } = "";
    public string Reason { get; set; } = "";
}

public interface IAiQueryAssistantService
{
    bool MaskPiData { get; }
    AiQueryAvailability GetAvailability(string templateId, string alertType, string stageId, string roleCode);
    Task<AiQuerySuggestion> SuggestAsync(AiQueryContext context, CancellationToken ct = default);
}

public sealed class MafAiQueryAssistantService(AiQueryOptions options) : IAiQueryAssistantService
{
    public bool MaskPiData => options.MaskPiData;

    public AiQueryAvailability GetAvailability(string templateId, string alertType, string stageId, string roleCode)
    {
        var resolved = Resolve(templateId, alertType, stageId, roleCode);
        return resolved.Enabled
            ? new AiQueryAvailability(true, resolved.Provider, resolved.Model)
            : AiQueryAvailability.Disabled;
    }

    public async Task<AiQuerySuggestion> SuggestAsync(AiQueryContext context, CancellationToken ct = default)
    {
        var resolved = Resolve(context.TemplateId, context.AlertType, context.StageId, context.RoleCode);
        if (!resolved.Enabled) throw new InvalidOperationException("AI Query is disabled for this template, alert type, workflow stage, or role.");
        if (string.IsNullOrWhiteSpace(resolved.Endpoint)) throw new InvalidOperationException("AI Query endpoint is not configured.");
        if (string.IsNullOrWhiteSpace(resolved.Model)) throw new InvalidOperationException("AI Query model is not configured.");
        if (string.IsNullOrWhiteSpace(resolved.ApiKey)) throw new InvalidOperationException("AI Query API key is not configured. For a local OpenAI-compatible SLM, configure the key value expected by that endpoint.");

        var clientOptions = new OpenAIClientOptions { Endpoint = new Uri(resolved.Endpoint, UriKind.Absolute) };
        var chatClient = new ChatClient(resolved.Model, new ApiKeyCredential(resolved.ApiKey), clientOptions);
        AIAgent agent = chatClient.AsAIAgent(
            instructions: options.SystemInstructions,
            name: "CATSQueryAssistant");

        var promptTemplate = string.IsNullOrWhiteSpace(resolved.PromptTemplate)
            ? "Review the authorised CATS alert context and draft one clear business clarification query for the current workflow user. The draft will be reviewed and edited by a human before the existing Raise Query action is submitted."
            : resolved.PromptTemplate;

        var contextJson = JsonSerializer.Serialize(new
        {
            context.TemplateName,
            context.AlertType,
            context.StageName,
            context.AlertNo,
            context.Status,
            context.Priority,
            context.BranchCode,
            context.CustomerId,
            context.AccountId,
            dynamicData = SafeJson(context.DynamicDataJson),
            previousQueries = SafeJson(context.PreviousQueriesJson),
            userInstruction = context.UserInstruction
        });
        if (contextJson.Length > Math.Max(2000, options.MaxContextCharacters))
            contextJson = contextJson[..Math.Max(2000, options.MaxContextCharacters)];

        var prompt = $"{promptTemplate}\n\nAuthorised alert context:\n{contextJson}\n\nReturn a structured result with QueryText and Reason. QueryText must contain only the proposed query to the business user, not workflow instructions.";
        AgentResponse<AiQueryModelResult> response = await agent.RunAsync<AiQueryModelResult>(prompt, cancellationToken: ct);
        var result = response.Result ?? throw new InvalidOperationException("AI Query returned no structured suggestion.");
        var text = (result.QueryText ?? "").Trim();
        if (string.IsNullOrWhiteSpace(text)) throw new InvalidOperationException("AI Query returned an empty suggestion.");
        if (text.Length > 3000) text = text[..3000];
        return new AiQuerySuggestion
        {
            QueryText = text,
            Reason = (result.Reason ?? "").Trim(),
            Provider = resolved.Provider,
            Model = resolved.Model
        };
    }

    private EffectiveAiQueryConfiguration Resolve(string templateId, string alertType, string stageId, string roleCode)
    {
        if (!options.Enabled) return EffectiveAiQueryConfiguration.Disabled;
        var candidates = options.Rules
            .Select((rule, index) => new { rule, index, score = Score(rule, templateId, alertType, stageId, roleCode) })
            .Where(x => x.score >= 0)
            .OrderByDescending(x => x.score)
            .ThenByDescending(x => x.index)
            .ToList();
        var selected = candidates.FirstOrDefault()?.rule;
        if (selected is { Enabled: false }) return EffectiveAiQueryConfiguration.Disabled;
        return new EffectiveAiQueryConfiguration(
            true,
            First(selected?.Provider, options.Provider),
            First(selected?.Endpoint, options.Endpoint),
            First(selected?.Model, options.Model),
            First(selected?.ApiKey, options.ApiKey),
            selected?.PromptTemplate);
    }

    private static int Score(AiQueryRule rule, string templateId, string alertType, string stageId, string roleCode)
    {
        var score = 0;
        if (!Match(rule.TemplateId, templateId, ref score)) return -1;
        if (!Match(rule.AlertType, alertType, ref score)) return -1;
        if (!Match(rule.StageId, stageId, ref score)) return -1;
        if (!Match(rule.RoleCode, roleCode, ref score)) return -1;
        return score;
    }

    private static bool Match(string? configured, string actual, ref int score)
    {
        if (string.IsNullOrWhiteSpace(configured) || configured == "*") return true;
        if (!configured.Equals(actual, StringComparison.OrdinalIgnoreCase)) return false;
        score++;
        return true;
    }

    private static string First(string? preferred, string fallback) => string.IsNullOrWhiteSpace(preferred) ? fallback : preferred.Trim();
    private static object SafeJson(string json)
    {
        try { return JsonSerializer.Deserialize<JsonElement>(json); }
        catch { return json; }
    }

    private sealed record EffectiveAiQueryConfiguration(bool Enabled, string Provider, string Endpoint, string Model, string ApiKey, string? PromptTemplate)
    {
        public static readonly EffectiveAiQueryConfiguration Disabled = new(false, "", "", "", "", null);
    }
}

