using System.Text.Json;
using System.Text.Json.Nodes;
using CATS.Core;

namespace CATS.Workflow;

public sealed class AssignmentRuleEngine
{
    /// <summary>
    /// Applies template assignment rules to incoming data. Rules are evaluated in order.
    /// Supported rule shape:
    /// { "field":"riskCategory", "operator":"eq", "value":"High", "stageId":"input",
    ///   "targetRoleCode":"DT_USER", "targetUserId":"", "targetBranchCode":"B001", "stop":true }
    /// Resolved assignments are stored inside reserved _assignments JSON for the workflow engine.
    /// </summary>
    public (string BranchCode, string DynamicDataJson) Apply(TemplateRecord template, CreateAlertRequest request)
    {
        var root = request.Data.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null
            ? new JsonObject()
            : JsonNode.Parse(request.Data.GetRawText())?.AsObject() ?? new JsonObject();
        // _assignments is a server-owned reserved key. Never trust a caller-supplied value.
        root.Remove("_assignments");
        var assignments = new JsonObject();
        root["_assignments"] = assignments;
        var branch = request.BranchCode;

        JsonArray? rules;
        try { rules = JsonNode.Parse(string.IsNullOrWhiteSpace(template.AssignmentRulesJson)?"[]":template.AssignmentRulesJson) as JsonArray; }
        catch { rules = null; }
        if (rules == null) return (branch, root.ToJsonString());

        foreach (var node in rules.OfType<JsonObject>())
        {
            var field=node["field"]?.GetValue<string>() ?? "";
            var op=node["operator"]?.GetValue<string>() ?? "eq";
            var expected=node["value"]?.ToString() ?? "";
            var actual = ResolveField(field, request, root);
            if (!Compare(actual,op,expected)) continue;

            var targetBranch=node["targetBranchCode"]?.GetValue<string>();
            if(!string.IsNullOrWhiteSpace(targetBranch)) branch=targetBranch!;
            var stageId=node["stageId"]?.GetValue<string>();
            if(!string.IsNullOrWhiteSpace(stageId))
            {
                assignments[stageId!] = new JsonObject
                {
                    ["roleCode"] = node["targetRoleCode"]?.GetValue<string>(),
                    ["branchCode"] = node["targetBranchCode"]?.GetValue<string>(),
                    ["userId"] = node["targetUserId"]?.GetValue<string>()
                };
            }
            if(node["stop"]?.GetValue<bool>()==true) break;
        }
        return (branch,root.ToJsonString());
    }

    private static string ResolveField(string field,CreateAlertRequest request,JsonObject root)
    {
        if(field.Equals("AlertType",StringComparison.OrdinalIgnoreCase)) return request.AlertType;
        if(field.Equals("BranchCode",StringComparison.OrdinalIgnoreCase)) return request.BranchCode;
        if(field.Equals("Priority",StringComparison.OrdinalIgnoreCase)) return request.Priority;
        var hit=root.FirstOrDefault(p=>p.Key.Equals(field,StringComparison.OrdinalIgnoreCase));
        return hit.Value?.ToString() ?? "";
    }

    private static bool Compare(string actual,string op,string expected)
    {
        op=op.ToLowerInvariant();
        if(decimal.TryParse(actual,out var a)&&decimal.TryParse(expected,out var b)) return op switch{"gt" or ">"=>a>b,"gte" or ">="=>a>=b,"lt" or "<"=>a<b,"lte" or "<="=>a<=b,"neq" or "!="=>a!=b,_=>a==b};
        return op switch{"neq" or "!="=>!actual.Equals(expected,StringComparison.OrdinalIgnoreCase),"contains"=>actual.Contains(expected,StringComparison.OrdinalIgnoreCase),_=>actual.Equals(expected,StringComparison.OrdinalIgnoreCase)};
    }
}
