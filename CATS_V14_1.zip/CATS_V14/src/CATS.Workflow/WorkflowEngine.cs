using System.Globalization;
using System.Text.Json;
using CATS.Core;
using CATS.Infrastructure;

namespace CATS.Workflow;

public sealed class CatsWorkflowEngine(ICatsRepository repo, IAgentDecisionService agent, MafWorkflowGraphService mafGraph) : IWorkflowEngine
{
    public async Task StartAsync(string alertId, CurrentUser user, CancellationToken ct = default)
    {
        var alert = await repo.GetAlertAsync(alertId, ct) ?? throw new KeyNotFoundException("Alert not found.");
        var existing = await repo.GetWorkflowInstanceByAlertAsync(alertId, ct);
        if (existing != null) return;
        var workflow = await repo.GetPublishedWorkflowForTemplateAsync(alert.TemplateId, ct)
            ?? throw new InvalidOperationException("No published workflow is configured for this template.");
        var definition = Parse(workflow.DefinitionJson);
        _ = mafGraph.BuildGraph(definition); // structural validation through Microsoft Agent Framework.

        var now = DateTime.UtcNow;
        var instance = new WorkflowInstanceRecord
        {
            Id = Guid.NewGuid().ToString("N"), AlertId = alertId, WorkflowDefinitionId = workflow.Id,
            WorkflowVersion = workflow.Version, Status = "Running", CurrentStageId = definition.StartStageId,
            StartedAtUtc = now, UpdatedAtUtc = now
        };
        await repo.InsertWorkflowInstanceAsync(instance, ct);
        await EnterStageAsync(alert, instance, definition, definition.StartStageId, user, "Workflow started", null, 0, ct);
    }

    public async Task<IReadOnlyList<string>> GetAllowedActionsAsync(string alertId, CurrentUser user, CancellationToken ct = default)
    {
        var instance = await repo.GetWorkflowInstanceByAlertAsync(alertId, ct);
        if (instance == null) return [];
        var workflow = await repo.GetWorkflowAsync(instance.WorkflowDefinitionId, ct) ?? throw new InvalidOperationException("Workflow definition not found.");
        var def = Parse(workflow.DefinitionJson);
        var items = await repo.GetPendingWorkItemsAsync(alertId, ct);
        var mine = items.Where(w => IsAssignedTo(w,user)).ToList();
        var actions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in mine)
        {
            var stage = def.GetStage(item.StageId);
            foreach (var action in stage.AllowedActions) actions.Add(action);
        }
        return actions.ToList();
    }

    public async Task ApplyActionAsync(string alertId, WorkflowActionRequest request, CurrentUser user, string? ipAddress, CancellationToken ct = default)
    {
        var alert = await repo.GetAlertAsync(alertId, ct) ?? throw new KeyNotFoundException("Alert not found.");
        var instance = await repo.GetWorkflowInstanceByAlertAsync(alertId, ct) ?? throw new InvalidOperationException("No active workflow instance.");
        var workflow = await repo.GetWorkflowAsync(instance.WorkflowDefinitionId, ct) ?? throw new InvalidOperationException("Workflow definition not found.");
        var def = Parse(workflow.DefinitionJson);
        var pending = await repo.GetPendingWorkItemsAsync(alertId, ct);
        var item = pending.FirstOrDefault(w =>
            IsAssignedTo(w,user) &&
            string.Equals(w.StageId,instance.CurrentStageId,StringComparison.OrdinalIgnoreCase));
        if (item == null) throw new UnauthorizedAccessException("No pending work item is assigned to your role/user at the current stage.");
        var stage = def.GetStage(item.StageId);
        if (!stage.AllowedActions.Contains(request.Action,StringComparer.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Action '{request.Action}' is not allowed at stage '{stage.Name}'.");
        if ((request.Action.Equals("RaiseQuery",StringComparison.OrdinalIgnoreCase) || request.Action.Equals("Query",StringComparison.OrdinalIgnoreCase) ||
             request.Action.Equals("RespondQuery",StringComparison.OrdinalIgnoreCase) || request.Action.Equals("Respond",StringComparison.OrdinalIgnoreCase)) &&
            string.IsNullOrWhiteSpace(request.Remarks))
            throw new InvalidOperationException($"Remarks are required for action '{request.Action}'.");

        await repo.CompleteWorkItemAsync(item.Id, request.Action, user, request.Remarks, ct);
        await AuditAsync(alertId,user,request.Action,"WorkItem",item.Id,stage.Id,null,JsonSerializer.Serialize(new{request.Action,request.Remarks}),request.Remarks,ipAddress,ct);

        if (stage.Type == StageType.ParallelApproval && !string.IsNullOrWhiteSpace(item.ParallelGroupId))
        {
            var decision = await ResolveParallelDecisionAsync(alertId,item.ParallelGroupId!,stage,ct);
            if (decision == null) return; // wait for remaining parallel approvers.
            // Only one concurrent approver may advance the parallel stage. Work-item completion is already optimistic;
            // this second compare-and-set protects the group-to-next-stage transition itself.
            if(!await repo.TryClaimStageTransitionAsync(instance.Id,stage.Id,ct)) return;
            try
            {
                await repo.CancelPendingWorkItemsAsync(alertId,item.ParallelGroupId,ct);
                await ContinueByActionAsync(alert,instance,def,stage,decision,user,request.Remarks,ipAddress,ct);
            }
            catch
            {
                await repo.ReleaseStageTransitionClaimAsync(instance.Id,stage.Id,ct);
                throw;
            }
            return;
        }

        await ContinueByActionAsync(alert,instance,def,stage,request.Action,user,request.Remarks,ipAddress,ct);
    }

    private async Task<string?> ResolveParallelDecisionAsync(string alertId,string groupId,WorkflowStage stage,CancellationToken ct)
    {
        var all = await repo.GetParallelWorkItemsAsync(alertId,groupId,ct);
        var approvals = all.Count(w => IsPositive(w.CompletedAction));
        var negatives = all.Count(w => IsNegative(w.CompletedAction));
        var pending = all.Count(w => w.Status==WorkItemStatus.Pending);
        var positiveAction = PositiveTransitionAction(stage);
        var negativeAction = NegativeTransitionAction(stage);

        return stage.ApprovalRule switch
        {
            ApprovalRule.Any when approvals > 0 => positiveAction,
            ApprovalRule.Any when pending == 0 && approvals == 0 => negativeAction,
            ApprovalRule.Minimum when approvals >= Math.Max(1,stage.MinimumApprovals) => positiveAction,
            ApprovalRule.Minimum when approvals + pending < Math.Max(1,stage.MinimumApprovals) => negativeAction,
            ApprovalRule.All when negatives > 0 => negativeAction,
            ApprovalRule.All when pending == 0 && approvals == all.Count => positiveAction,
            ApprovalRule.Single when approvals > 0 => positiveAction,
            ApprovalRule.Single when negatives > 0 => negativeAction,
            _ => null
        };
    }

    private static string PositiveTransitionAction(WorkflowStage stage)
    {
        var positive = stage.Transitions.FirstOrDefault(t => IsPositive(t.Action));
        return positive?.Action ?? stage.Transitions.FirstOrDefault()?.Action
            ?? throw new InvalidOperationException($"Parallel stage '{stage.Name}' has no transitions.");
    }

    private static string NegativeTransitionAction(WorkflowStage stage)
    {
        var negative = stage.Transitions.FirstOrDefault(t => IsNegative(t.Action));
        return negative?.Action ?? stage.Transitions.FirstOrDefault(t => !IsPositive(t.Action))?.Action
            ?? throw new InvalidOperationException($"Parallel stage '{stage.Name}' has no negative transition.");
    }

    private static bool IsPositive(string? action) => action != null &&
        (action.Equals("Approve",StringComparison.OrdinalIgnoreCase) || action.Equals("Verify",StringComparison.OrdinalIgnoreCase) || action.Equals("Verified",StringComparison.OrdinalIgnoreCase) || action.Equals("Accept",StringComparison.OrdinalIgnoreCase) || action.Equals("Recommend",StringComparison.OrdinalIgnoreCase));

    private static bool IsNegative(string? action) => action != null &&
        (action.Equals("Reject",StringComparison.OrdinalIgnoreCase) || action.Equals("Decline",StringComparison.OrdinalIgnoreCase) || action.Equals("Return",StringComparison.OrdinalIgnoreCase));

    private async Task ContinueByActionAsync(AlertRecord alert,WorkflowInstanceRecord instance,WorkflowDefinitionModel def,WorkflowStage stage,string action,CurrentUser user,string? remarks,string? ipAddress,CancellationToken ct)
    {
        var transition = stage.Transitions.FirstOrDefault(t => string.Equals(t.Action,action,StringComparison.OrdinalIgnoreCase));
        if (transition == null)
        {
            if (stage.Type == StageType.End) return;
            throw new InvalidOperationException($"No transition is configured for action '{action}' from stage '{stage.Name}'.");
        }
        if (action.Equals("RespondQuery",StringComparison.OrdinalIgnoreCase) || action.Equals("Respond",StringComparison.OrdinalIgnoreCase))
            await repo.RespondLatestOpenQueryAsync(alert.Id,user,remarks ?? "",ct);

        if (string.IsNullOrWhiteSpace(transition.ToStageId))
        {
            var status = ParseStatus(transition.ResultStatus, AlertStatus.Closed);
            await repo.UpdateAlertStageAsync(alert.Id,stage.Id,stage.Name,status,DateTime.UtcNow,ct);
            instance.Status="Completed"; instance.UpdatedAtUtc=DateTime.UtcNow;
            await repo.UpdateWorkflowInstanceAsync(instance,ct);
            return;
        }
        if (action.Equals("RaiseQuery",StringComparison.OrdinalIgnoreCase) || action.Equals("Query",StringComparison.OrdinalIgnoreCase))
        {
            var target=def.GetStage(transition.ToStageId!);
            await repo.InsertQueryAsync(new QueryRecord{Id=Guid.NewGuid().ToString("N"),AlertId=alert.Id,RaisedBy=user.UserName,RaisedToRole=target.RoleCode,QueryText=remarks ?? "Query raised",Status="Open",RaisedAtUtc=DateTime.UtcNow},ct);
        }
        await EnterStageAsync(alert,instance,def,transition.ToStageId!,user,$"Action {action}",ipAddress,0,ct);
    }

    private async Task EnterStageAsync(AlertRecord alert,WorkflowInstanceRecord instance,WorkflowDefinitionModel def,string stageId,CurrentUser user,string reason,string? ipAddress,int depth,CancellationToken ct)
    {
        if (depth > 50) throw new InvalidOperationException("Workflow routing exceeded 50 automatic stages. Check for a routing loop.");
        var stage = def.GetStage(stageId);
        var now=DateTime.UtcNow;
        instance.CurrentStageId=stage.Id; instance.UpdatedAtUtc=now;
        await repo.UpdateWorkflowInstanceAsync(instance,ct);
        await repo.UpdateAlertStageAsync(alert.Id,stage.Id,stage.Name,stage.Type==StageType.End?ParseStatus(stage.EndStatus,AlertStatus.Closed):AlertStatus.Pending,now,ct);
        await AuditAsync(alert.Id,user,"STAGE_ENTER","WorkflowStage",stage.Id,stage.Id,null,JsonSerializer.Serialize(new{stage.Name,stage.Type,reason}),reason,ipAddress,ct);

        if(stage.Type==StageType.End)
        {
            instance.Status="Completed"; instance.UpdatedAtUtc=now; await repo.UpdateWorkflowInstanceAsync(instance,ct);
            return;
        }
        if(stage.Type==StageType.Human)
        {
            await repo.InsertWorkItemsAsync([NewWorkItem(alert,instance,stage,stage.RoleCode,null)],ct);
            return;
        }
        if(stage.Type==StageType.ParallelApproval)
        {
            var group=Guid.NewGuid().ToString("N");
            var items=stage.Approvers.Select(a=>NewWorkItem(alert,instance,stage,a.RoleCode,group)).ToList();
            await repo.InsertWorkItemsAsync(items,ct);
            return;
        }
        if(stage.Type==StageType.Condition)
        {
            var next=EvaluateCondition(stage,alert);
            if(string.IsNullOrWhiteSpace(next)) throw new InvalidOperationException($"No condition matched and no default route exists for '{stage.Name}'.");
            await EnterStageAsync(alert,instance,def,next!,user,"Conditional route",ipAddress,depth+1,ct);
            return;
        }
        if(stage.Type==StageType.Agent)
        {
            var template=await repo.GetTemplateAsync(alert.TemplateId,ct) ?? throw new InvalidOperationException("Template not found.");
            AgentDecision decision;
            if(template.ExecutionMode==ExecutionMode.Deterministic || !agent.IsEnabled)
            {
                var fallback=stage.AgentFallbackAction ?? stage.Transitions.FirstOrDefault()?.Action ?? throw new InvalidOperationException("Agent stage requires an agent or deterministic fallback action.");
                decision=new AgentDecision{Action=fallback,Reason=agent.IsEnabled?"Deterministic execution mode":"Agent disabled; configured fallback used"};
            }
            else
            {
                decision=await agent.DecideAsync(stage,alert,alert.DynamicDataJson,ct);
            }
            await AuditAsync(alert.Id,user,"AGENT_DECISION","WorkflowStage",stage.Id,stage.Id,null,JsonSerializer.Serialize(decision),decision.Reason,ipAddress,ct);
            await ContinueByActionAsync(alert,instance,def,stage,decision.Action,user,decision.Reason,ipAddress,ct);
        }
    }

    private static WorkItemRecord NewWorkItem(AlertRecord alert,WorkflowInstanceRecord instance,WorkflowStage stage,string role,string? group)
    {
        string? userId=null;
        var assignedBranch=alert.BranchCode;
        try
        {
            using var doc=JsonDocument.Parse(string.IsNullOrWhiteSpace(alert.DynamicDataJson)?"{}":alert.DynamicDataJson);
            if(doc.RootElement.TryGetProperty("_assignments",out var assignments) && assignments.ValueKind==JsonValueKind.Object && assignments.TryGetProperty(stage.Id,out var a))
            {
                if(a.TryGetProperty("roleCode",out var r) && !string.IsNullOrWhiteSpace(r.GetString())) role=r.GetString()!;
                if(a.TryGetProperty("branchCode",out var b) && !string.IsNullOrWhiteSpace(b.GetString())) assignedBranch=b.GetString()!;
                if(a.TryGetProperty("userId",out var u) && !string.IsNullOrWhiteSpace(u.GetString())) userId=u.GetString();
            }
        }
        catch { }
        return new WorkItemRecord
        {
            Id=Guid.NewGuid().ToString("N"),AlertId=alert.Id,WorkflowInstanceId=instance.Id,StageId=stage.Id,StageName=stage.Name,
            AssignedRoleCode=role,AssignedBranchCode=assignedBranch,AssignedUserId=userId,Status=WorkItemStatus.Pending,ParallelGroupId=group,CreatedAtUtc=DateTime.UtcNow,
            DueAtUtc=DateTime.UtcNow.AddHours(Math.Max(1,stage.SlaHours))
        };
    }

    private static bool IsAssignedTo(WorkItemRecord item, CurrentUser user)
    {
        if(!string.IsNullOrWhiteSpace(item.AssignedUserId) && item.AssignedUserId.Equals(user.Id,StringComparison.OrdinalIgnoreCase)) return true;
        if(!item.AssignedRoleCode.Equals(user.RoleCode,StringComparison.OrdinalIgnoreCase)) return false;
        return string.IsNullOrWhiteSpace(item.AssignedBranchCode) || item.AssignedBranchCode.Equals(user.BranchCode,StringComparison.OrdinalIgnoreCase);
    }

    private static string? EvaluateCondition(WorkflowStage stage,AlertRecord alert)
    {
        using var doc=JsonDocument.Parse(string.IsNullOrWhiteSpace(alert.DynamicDataJson)?"{}":alert.DynamicDataJson);
        foreach(var c in stage.Conditions)
        {
            var actual = GetValue(c.Field,alert,doc.RootElement);
            if(Compare(actual,c.Operator,c.Value)) return c.ToStageId;
        }
        return stage.DefaultNextStageId;
    }

    private static string GetValue(string field,AlertRecord alert,JsonElement data)
    {
        if(field.Equals("AlertType",StringComparison.OrdinalIgnoreCase)) return alert.AlertType;
        if(field.Equals("BranchCode",StringComparison.OrdinalIgnoreCase)) return alert.BranchCode;
        if(field.Equals("Priority",StringComparison.OrdinalIgnoreCase)) return alert.Priority;
        if(data.ValueKind==JsonValueKind.Object)
        {
            foreach(var p in data.EnumerateObject()) if(p.Name.Equals(field,StringComparison.OrdinalIgnoreCase)) return p.Value.ToString();
        }
        return "";
    }

    private static bool Compare(string actual,string op,string expected)
    {
        op=op.Trim().ToLowerInvariant();
        if(decimal.TryParse(actual,NumberStyles.Any,CultureInfo.InvariantCulture,out var a) && decimal.TryParse(expected,NumberStyles.Any,CultureInfo.InvariantCulture,out var b))
            return op switch {"gt" or ">"=>a>b,"gte" or ">="=>a>=b,"lt" or "<"=>a<b,"lte" or "<="=>a<=b,"neq" or "!="=>a!=b,_=>a==b};
        return op switch
        {
            "neq" or "!=" => !actual.Equals(expected,StringComparison.OrdinalIgnoreCase),
            "contains" => actual.Contains(expected,StringComparison.OrdinalIgnoreCase),
            "startswith" => actual.StartsWith(expected,StringComparison.OrdinalIgnoreCase),
            _ => actual.Equals(expected,StringComparison.OrdinalIgnoreCase)
        };
    }

    private static WorkflowDefinitionModel Parse(string json) => JsonSerializer.Deserialize<WorkflowDefinitionModel>(json,JsonDefaults.Options) ?? throw new InvalidOperationException("Invalid workflow JSON.");
    private static AlertStatus ParseStatus(string? status,AlertStatus fallback) => Enum.TryParse<AlertStatus>(status,true,out var s)?s:fallback;

    private Task AuditAsync(string? alertId,CurrentUser user,string action,string entityType,string? entityId,string? stageId,string? previous,string? current,string? remarks,string? ip,CancellationToken ct) => repo.InsertAuditAsync(new AuditRecord
    {
        Id=Guid.NewGuid().ToString("N"),AlertId=alertId,UserId=user.Id,UserName=user.UserName,RoleCode=user.RoleCode,Action=action,
        EntityType=entityType,EntityId=entityId,StageId=stageId,PreviousValueJson=previous,NewValueJson=current,Remarks=remarks,IpAddress=ip,CreatedAtUtc=DateTime.UtcNow
    },ct);
}
