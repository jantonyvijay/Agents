namespace CATS.Core;

public interface ICatsRepository
{
    Task<UserRecord?> GetUserByUserNameAsync(string userName, CancellationToken ct = default);
    Task<UserRecord?> GetUserByIdAsync(string id, CancellationToken ct = default);
    Task<IReadOnlyList<UserRecord>> GetUsersAsync(CancellationToken ct = default);
    Task UpsertUserAsync(UserRecord user, bool isNew, CancellationToken ct = default);
    Task<IReadOnlyList<TemplateRecord>> GetTemplatesAsync(CancellationToken ct = default);
    Task<TemplateRecord?> GetTemplateAsync(string id, CancellationToken ct = default);
    Task<TemplateRecord> SaveTemplateAsync(SaveTemplateRequest request, CurrentUser user, CancellationToken ct = default);
    Task RetireTemplateAsync(string id, CancellationToken ct = default);
    Task<WorkflowDefinitionRecord?> GetWorkflowAsync(string id, CancellationToken ct = default);
    Task<WorkflowDefinitionRecord?> GetPublishedWorkflowForTemplateAsync(string templateId, CancellationToken ct = default);
    Task<WorkflowDefinitionRecord> SaveWorkflowAsync(SaveWorkflowRequest request, CurrentUser user, CancellationToken ct = default);
    Task<AlertRecord> InsertAlertAsync(AlertRecord alert, CancellationToken ct = default);
    Task<WorkflowInstanceRecord> InsertWorkflowInstanceAsync(WorkflowInstanceRecord instance, CancellationToken ct = default);
    Task UpdateWorkflowInstanceAsync(WorkflowInstanceRecord instance, CancellationToken ct = default);
    Task<bool> TryClaimStageTransitionAsync(string instanceId, string expectedStageId, CancellationToken ct = default);
    Task ReleaseStageTransitionClaimAsync(string instanceId, string expectedStageId, CancellationToken ct = default);
    Task UpdateAlertStageAsync(string alertId, string stageId, string stageName, AlertStatus status, DateTime enteredAtUtc, CancellationToken ct = default);
    Task UpdateAlertDynamicDataAsync(string alertId, string dynamicDataJson, CancellationToken ct = default);
    Task<AlertRecord?> GetAlertAsync(string alertId, CancellationToken ct = default);
    Task<WorkflowInstanceRecord?> GetWorkflowInstanceByAlertAsync(string alertId, CancellationToken ct = default);
    Task InsertWorkItemsAsync(IEnumerable<WorkItemRecord> items, CancellationToken ct = default);
    Task<IReadOnlyList<WorkItemRecord>> GetPendingWorkItemsAsync(string alertId, CancellationToken ct = default);
    Task<IReadOnlyList<WorkItemRecord>> GetWorkItemsAsync(string alertId, CancellationToken ct = default);
    Task<WorkItemRecord?> GetWorkItemAsync(string id, CancellationToken ct = default);
    Task CompleteWorkItemAsync(string id, string action, CurrentUser user, string? remarks, CancellationToken ct = default);
    Task ReassignPendingWorkItemsAsync(string alertId, string stageId, string? roleCode, string? branchCode, string? userId, CancellationToken ct = default);
    Task CancelPendingWorkItemsAsync(string alertId, string? parallelGroupId, CancellationToken ct = default);
    Task<IReadOnlyList<WorkItemRecord>> GetParallelWorkItemsAsync(string alertId, string parallelGroupId, CancellationToken ct = default);
    Task InsertQueryAsync(QueryRecord query, CancellationToken ct = default);
    Task RespondLatestOpenQueryAsync(string alertId, CurrentUser user, string responseText, CancellationToken ct = default);
    Task<IReadOnlyList<QueryRecord>> GetQueriesAsync(string alertId, CancellationToken ct = default);
    Task InsertAttachmentAsync(AttachmentRecord attachment, CancellationToken ct = default);
    Task<IReadOnlyList<AttachmentRecord>> GetAttachmentsAsync(string alertId, CancellationToken ct = default);
    Task<AttachmentRecord?> GetAttachmentAsync(string id, CancellationToken ct = default);
    Task InsertAuditAsync(AuditRecord audit, CancellationToken ct = default);
    Task<IReadOnlyList<AuditRecord>> GetAuditAsync(string alertId, int take = 100, CancellationToken ct = default);
    Task<IReadOnlyList<AgingBucket>> GetAgingBucketsAsync(CancellationToken ct = default);
    Task SaveAgingBucketAsync(SaveAgingBucketRequest request, CancellationToken ct = default);
    Task<DashboardAgingResponse> GetDashboardAgingAsync(CurrentUser user, AlertListFilter? filter = null, CancellationToken ct = default);
    Task<PagedResult<AlertListItem>> GetAlertsAsync(AlertListFilter filter, CurrentUser user, Func<string,string> decrypt, Func<string,string> mask, CancellationToken ct = default);
    Task<string> GetTemplateNameAsync(string templateId, CancellationToken ct = default);
    Task<IReadOnlyList<string>> GetRoleCodesAsync(CancellationToken ct = default);
}

public interface IWorkflowEngine
{
    Task StartAsync(string alertId, CurrentUser user, CancellationToken ct = default);
    Task ApplyActionAsync(string alertId, WorkflowActionRequest request, CurrentUser user, string? ipAddress, CancellationToken ct = default);
    Task<IReadOnlyList<string>> GetAllowedActionsAsync(string alertId, CurrentUser user, CancellationToken ct = default);
}

public interface IAgentDecisionService
{
    bool IsEnabled { get; }
    Task<AgentDecision> DecideAsync(WorkflowStage stage, AlertRecord alert, string dynamicDataJson, CancellationToken ct = default);
}

public interface IDataProtectorService
{
    string Protect(string plainText);
    string Unprotect(string cipherText);
    string Mask(string value, int visibleTail = 4);
}

public interface IPasswordHasher
{
    string Hash(string password);
    bool Verify(string password, string storedHash);
}

public interface IPlatformRepository
{
    Task<IReadOnlyList<string>> GetEffectivePermissionsAsync(string userId, CancellationToken ct=default);
    Task<IReadOnlyList<DataScopeRecord>> GetDataScopesAsync(string userId, CancellationToken ct=default);
    Task<IReadOnlyList<DashboardWidgetValue>> GetDashboardWidgetsAsync(CurrentUser user, CancellationToken ct=default);
    Task<IReadOnlyList<DashboardWidgetRecord>> GetDashboardWidgetConfigurationAsync(CancellationToken ct=default);
    Task SaveDashboardWidgetAsync(DashboardWidgetRecord widget, string roleCode, CancellationToken ct=default);
    Task<IReadOnlyList<TemplateDashboardRecord>> GetTemplateDashboardsAsync(CurrentUser user, bool includeInactive=false, CancellationToken ct=default);
    Task<TemplateDashboardRecord?> GetTemplateDashboardAsync(string id, CurrentUser user, bool requireManage=false, CancellationToken ct=default);
    Task SaveTemplateDashboardAsync(TemplateDashboardRecord dashboard, CancellationToken ct=default);
    Task<TemplateDashboardDataResponse> GetTemplateDashboardDataAsync(string id, TemplateDashboardQuery query, CurrentUser user, Func<string,string> decrypt, Func<string,string> mask, CancellationToken ct=default);
    Task<IReadOnlyList<ConnectorRecord>> GetConnectorsAsync(CancellationToken ct=default);
    Task SaveConnectorAsync(ConnectorRecord connector, CancellationToken ct=default);
    Task<IReadOnlyList<IngestionConfigurationRecord>> GetIngestionConfigurationsAsync(CancellationToken ct=default);
    Task SaveIngestionConfigurationAsync(IngestionConfigurationRecord config, CancellationToken ct=default);
    Task<IngestionDashboard> GetIngestionDashboardAsync(CancellationToken ct=default);
    Task<IReadOnlyList<IngestionRunRecord>> GetIngestionRunsAsync(int take=100, CancellationToken ct=default);
    Task<IReadOnlyList<MailConfigurationRecord>> GetMailConfigurationsAsync(CancellationToken ct=default);
    Task SaveMailConfigurationAsync(MailConfigurationRecord config, CancellationToken ct=default);
    Task<IReadOnlyList<MailTemplateRecord>> GetMailTemplatesAsync(CancellationToken ct=default);
    Task SaveMailTemplateAsync(MailTemplateRecord template, CancellationToken ct=default);
    Task<IReadOnlyList<MailQueueRecord>> GetMailLogsAsync(int take=100, CancellationToken ct=default);
    Task<PagedResult<ReportRow>> GetReportAsync(string reportType, ReportFilter filter, CurrentUser user, CancellationToken ct=default);
}
