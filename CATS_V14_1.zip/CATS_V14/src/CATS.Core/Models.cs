using System.Text.Json;

namespace CATS.Core;

public static class CatsRoles
{
    public const string Central = "CENTRAL";
    public const string DtUser = "DT_USER";
    public const string DtChecker = "DT_CHECKER";
    public const string DtVerifier = "DT_VERIFIER";
    public const string Auditor = "AUDITOR";
    public const string Admin = "ADMIN";
}

public static class CatsPermissions
{
    public const string TemplateManage = "TEMPLATE.MANAGE";
    public const string WorkflowManage = "WORKFLOW.MANAGE";
    public const string AlertUpload = "ALERT.UPLOAD";
    public const string AlertViewAll = "ALERT.VIEWALL";
    public const string AlertReassign = "ALERT.REASSIGN";
    public const string PiUnmask = "PI.UNMASK";
    public const string AuditView = "AUDIT.VIEW";
    public const string Admin = "ADMIN";
}

public enum ExecutionMode { Deterministic, Hybrid, Agentic }
public enum TemplateStatus { Draft, Published, Retired }
public enum AlertStatus { New, InProgress, Pending, Query, Approved, Rejected, Closed, Cancelled }
public enum WorkItemStatus { Pending, Completed, Cancelled }
public enum StageType { Human, ParallelApproval, Condition, Agent, End }
public enum ApprovalRule { Single, All, Any, Minimum }

public sealed class UserRecord
{
    public string Id { get; set; } = "";
    public string UserName { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string RoleCode { get; set; } = "";
    public string DepartmentCode { get; set; } = "";
    public string BranchCode { get; set; } = "";
    public string PermissionsJson { get; set; } = "[]";
    public bool IsActive { get; set; }

    public IReadOnlyList<string> Permissions()
    {
        try { return JsonSerializer.Deserialize<List<string>>(PermissionsJson) ?? []; }
        catch { return []; }
    }
}

public sealed class TemplateRecord
{
    public string Id { get; set; } = "";
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public int Version { get; set; }
    public TemplateStatus Status { get; set; }
    public ExecutionMode ExecutionMode { get; set; }
    public string SectionsJson { get; set; } = "[]";
    public string FieldsJson { get; set; } = "[]";
    public string AssignmentRulesJson { get; set; } = "[]";
    public string ViewConfigurationJson { get; set; } = "{}";
    public string? PublishedWorkflowId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public string CreatedBy { get; set; } = "";
}

public sealed class TemplateSection
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "";
    public int Order { get; set; }
    public int ColumnSpan { get; set; } = 6;
    public int PageNumber { get; set; } = 1;
    /// <summary>Grid = responsive columns; List = label/value rows inside the section.</summary>
    public string DataViewMode { get; set; } = "Grid";
}

public sealed class TemplateField
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string SectionId { get; set; } = "";
    public string Name { get; set; } = "";
    public string Label { get; set; } = "";
    public string Type { get; set; } = "text";
    public bool Required { get; set; }
    public bool Sensitive { get; set; }
    public bool AllowUnmask { get; set; } = true;
    public int Order { get; set; }
    public string OptionsJson { get; set; } = "[]";
    public string Placeholder { get; set; } = "";
    public string HelpText { get; set; } = "";
    public int? MinLength { get; set; }
    public int? MaxLength { get; set; }
    public decimal? MinValue { get; set; }
    public decimal? MaxValue { get; set; }
    public string ValidationPattern { get; set; } = "";
    public string CustomErrorMessage { get; set; } = "";
    /// <summary>Static or Api. Api endpoints must be relative /api/... routes and are called through the CATS gateway.</summary>
    public string DataSourceMode { get; set; } = "Static";
    public string ApiUrl { get; set; } = "";
    public string ApiValueField { get; set; } = "value";
    public string ApiTextField { get; set; } = "text";
    /// <summary>Comma-separated field names whose values can be substituted into ApiUrl as {FieldName}.</summary>
    public string DependsOnFields { get; set; } = "";
    /// <summary>JSON array of dependency validation rules.</summary>
    public string DependencyValidationsJson { get; set; } = "[]";
    public bool ReadOnly { get; set; }
    public string DefaultValue { get; set; } = "";
}

public sealed class TemplateViewConfiguration
{
    /// <summary>Auto, Single, Tab, Popup, Accordion or Wizard.</summary>
    public string LayoutMode { get; set; } = "Single";
    /// <summary>Allowed alert creation/ingestion paths for this template.</summary>
    public List<string> BaseDataModes { get; set; } = ["ManualSingle", "BulkFileUpload", "Sftp", "FcQuery"];
    public bool RememberLastSection { get; set; } = true;
    public bool ShowSectionNumbers { get; set; } = true;
    public bool AllowWizardStepClick { get; set; }
    public string PopupSize { get; set; } = "xl";
    public List<AlertListFieldConfiguration> AlertListFields { get; set; } = [];
}

public sealed class AlertListFieldConfiguration
{
    public string Field { get; set; } = "";
    public string Label { get; set; } = "";
    public bool ShowInGrid { get; set; }
    public bool ShowAsFilter { get; set; }
    public int Order { get; set; }
    /// <summary>Filter UI hint: text, select, multiselect, date, datetime, checkboxlist, etc.</summary>
    public string ControlType { get; set; } = "text";
    /// <summary>Static filter choices when ControlType is a choice control.</summary>
    public string OptionsJson { get; set; } = "[]";
}

public sealed class FieldDependencyValidation
{
    public List<FieldDependencyCondition> Conditions { get; set; } = [];
    public bool Required { get; set; }
    public string MustEqualField { get; set; } = "";
    public string ErrorMessage { get; set; } = "";
}

public sealed class FieldDependencyCondition
{
    public string Field { get; set; } = "";
    public string Operator { get; set; } = "eq";
    public string Value { get; set; } = "";
}

public sealed class WorkflowDefinitionRecord
{
    public string Id { get; set; } = "";
    public string TemplateId { get; set; } = "";
    public int Version { get; set; }
    public string Name { get; set; } = "";
    public string DefinitionJson { get; set; } = "{}";
    public bool IsPublished { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public string CreatedBy { get; set; } = "";
}

public sealed class WorkflowDefinitionModel
{
    public string StartStageId { get; set; } = "";
    public List<WorkflowStage> Stages { get; set; } = [];

    public WorkflowStage GetStage(string id) => Stages.FirstOrDefault(x => x.Id == id)
        ?? throw new InvalidOperationException($"Workflow stage '{id}' was not found.");
}

public sealed class WorkflowStage
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public StageType Type { get; set; } = StageType.Human;
    public string RoleCode { get; set; } = "";
    public List<string> AllowedActions { get; set; } = [];
    /// <summary>Dynamic template field names editable at this stage. "*" means all non-sensitive fields; empty means read-only.</summary>
    public List<string> EditableFields { get; set; } = [];
    /// <summary>Roles allowed to upload attachments at this stage. Empty preserves the standard work-item/ALERT.UPLOAD rule.</summary>
    public List<string> AttachmentUploadRoles { get; set; } = [];
    /// <summary>Roles allowed to view attachments uploaded at this stage. Empty allows any user who can view the alert.</summary>
    public List<string> AttachmentViewRoles { get; set; } = [];
    public List<WorkflowTransition> Transitions { get; set; } = [];
    public ApprovalRule ApprovalRule { get; set; } = ApprovalRule.Single;
    public int MinimumApprovals { get; set; } = 1;
    public List<ParallelApprover> Approvers { get; set; } = [];
    public int SlaHours { get; set; } = 24;
    public List<ConditionalRoute> Conditions { get; set; } = [];
    public string? DefaultNextStageId { get; set; }
    public string? AgentInstructions { get; set; }
    public string? AgentPromptTemplate { get; set; }
    public string? AgentFallbackAction { get; set; }
    public string? EndStatus { get; set; }
}

public sealed class ParallelApprover
{
    public string RoleCode { get; set; } = "";
    public string Label { get; set; } = "";
}

public sealed class WorkflowTransition
{
    public string Action { get; set; } = "";
    public string? ToStageId { get; set; }
    public string? ResultStatus { get; set; }
}

public sealed class ConditionalRoute
{
    public string Field { get; set; } = "";
    public string Operator { get; set; } = "eq";
    public string Value { get; set; } = "";
    public string ToStageId { get; set; } = "";
}

public sealed class AlertRecord
{
    public string Id { get; set; } = "";
    public string AlertNo { get; set; } = "";
    public string TemplateId { get; set; } = "";
    public int TemplateVersion { get; set; }
    public string AlertType { get; set; } = "";
    public string BranchCode { get; set; } = "";
    public string CustomerIdEncrypted { get; set; } = "";
    public string AccountIdEncrypted { get; set; } = "";
    public string DynamicDataJson { get; set; } = "{}";
    public AlertStatus Status { get; set; }
    public string CurrentStageId { get; set; } = "";
    public string CurrentStageName { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
    public DateTime StageEnteredAtUtc { get; set; }
    public string CreatedBy { get; set; } = "";
    public string Priority { get; set; } = "Normal";
}

public sealed class WorkflowInstanceRecord
{
    public string Id { get; set; } = "";
    public string AlertId { get; set; } = "";
    public string WorkflowDefinitionId { get; set; } = "";
    public int WorkflowVersion { get; set; }
    public string Status { get; set; } = "Running";
    public string CurrentStageId { get; set; } = "";
    public DateTime StartedAtUtc { get; set; }
    public DateTime UpdatedAtUtc { get; set; }
}

public sealed class WorkItemRecord
{
    public string Id { get; set; } = "";
    public string AlertId { get; set; } = "";
    public string WorkflowInstanceId { get; set; } = "";
    public string StageId { get; set; } = "";
    public string StageName { get; set; } = "";
    public string AssignedRoleCode { get; set; } = "";
    public string AssignedBranchCode { get; set; } = "";
    public string? AssignedUserId { get; set; }
    public WorkItemStatus Status { get; set; }
    public string? ParallelGroupId { get; set; }
    public string? CompletedAction { get; set; }
    public string? CompletedBy { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime DueAtUtc { get; set; }
    public DateTime? CompletedAtUtc { get; set; }
    public string? Remarks { get; set; }
}

public sealed class QueryRecord
{
    public string Id { get; set; } = "";
    public string AlertId { get; set; } = "";
    public string RaisedBy { get; set; } = "";
    public string RaisedToRole { get; set; } = "";
    public string QueryText { get; set; } = "";
    public string? ResponseText { get; set; }
    public string Status { get; set; } = "Open";
    public DateTime RaisedAtUtc { get; set; }
    public DateTime? RespondedAtUtc { get; set; }
}

public sealed class AttachmentRecord
{
    public string Id { get; set; } = "";
    public string AlertId { get; set; } = "";
    public string StageId { get; set; } = "";
    public string FileName { get; set; } = "";
    public string StoredName { get; set; } = "";
    public string ContentType { get; set; } = "application/octet-stream";
    public long FileSize { get; set; }
    public string Sha256 { get; set; } = "";
    public int Version { get; set; } = 1;
    public string UploadedBy { get; set; } = "";
    public DateTime UploadedAtUtc { get; set; }
}

public sealed class AuditRecord
{
    public string Id { get; set; } = "";
    public string? AlertId { get; set; }
    public string UserId { get; set; } = "";
    public string UserName { get; set; } = "";
    public string RoleCode { get; set; } = "";
    public string Action { get; set; } = "";
    public string EntityType { get; set; } = "";
    public string? EntityId { get; set; }
    public string? StageId { get; set; }
    public string? PreviousValueJson { get; set; }
    public string? NewValueJson { get; set; }
    public string? Remarks { get; set; }
    public string? IpAddress { get; set; }
    public DateTime CreatedAtUtc { get; set; }
}

public sealed class AgingBucket
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public int FromDays { get; set; }
    public int? ToDays { get; set; }
    public int DisplayOrder { get; set; }
}

public sealed class DashboardAgingRow
{
    public string TemplateId { get; set; } = "";
    public string TemplateName { get; set; } = "";
    public string AlertType { get; set; } = "";
    public Dictionary<string, int> Counts { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public int Total { get; set; }
}

public sealed class DashboardAgingResponse
{
    public List<AgingBucket> Buckets { get; set; } = [];
    public List<DashboardAgingRow> Rows { get; set; } = [];
}

public sealed class AlertListItem
{
    public string Id { get; set; } = "";
    [System.Text.Json.Serialization.JsonIgnore]
    public string TemplateId { get; set; } = "";
    public string AlertNo { get; set; } = "";
    public string TemplateName { get; set; } = "";
    public string AlertType { get; set; } = "";
    public string BranchCode { get; set; } = "";
    public string CustomerId { get; set; } = "";
    public string AccountId { get; set; } = "";
    public string CurrentStageName { get; set; } = "";
    public string Status { get; set; } = "";
    public int OverallAgingDays { get; set; }
    public int StageAgingDays { get; set; }
    public string Priority { get; set; } = "Normal";
    public Dictionary<string,string> DynamicFields { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    [System.Text.Json.Serialization.JsonIgnore]
    public string DynamicDataJson { get; set; } = "{}";
}

public sealed class PagedResult<T>
{
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalRecords { get; set; }
    public int TotalPages => PageSize <= 0 ? 0 : (int)Math.Ceiling(TotalRecords / (double)PageSize);
    public List<T> Data { get; set; } = [];
}

public sealed class AlertListFilter
{
    public string? TemplateId { get; set; }
    public string? AlertType { get; set; }
    public string? BranchCode { get; set; }
    public string? Status { get; set; }
    public string? Search { get; set; }
    public string? AlertNo { get; set; }
    public string? AccountId { get; set; }
    public string? CustomerId { get; set; }
    public string? DashboardId { get; set; }
    public string? DashboardGroupFiltersJson { get; set; }
    public string? DashboardMetricCode { get; set; }
    public int? AgingFrom { get; set; }
    public int? AgingTo { get; set; }
    public string? DynamicFiltersJson { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}

public sealed class AlertDetailResponse
{
    public AlertRecord Alert { get; set; } = new();
    public string TemplateName { get; set; } = "";
    public string CustomerId { get; set; } = "";
    public string AccountId { get; set; } = "";
    public bool CanUnmaskPi { get; set; }
    public List<TemplateSection> Sections { get; set; } = [];
    public List<TemplateField> Fields { get; set; } = [];
    public TemplateViewConfiguration ViewConfiguration { get; set; } = new();
    public JsonElement DynamicData { get; set; }
    public List<string> AllowedActions { get; set; } = [];
    public List<string> EditableFields { get; set; } = [];
    public List<WorkItemRecord> PendingWorkItems { get; set; } = [];
    public List<QueryRecord> Queries { get; set; } = [];
    public List<AttachmentRecord> Attachments { get; set; } = [];
    public bool CanUploadAttachments { get; set; }
    /// <summary>Optional additive AI query drafting. Existing manual Query/RaiseQuery remains unchanged.</summary>
    public bool AiQueryEnabled { get; set; }
    public string AiQueryProvider { get; set; } = "";
    public string AiQueryModel { get; set; } = "";
    public List<AuditRecord> Audit { get; set; } = [];
}

public sealed class AiQuerySuggestionRequest
{
    /// <summary>Optional user instruction such as "focus on source of funds". It never triggers a workflow action.</summary>
    public string? Instruction { get; set; }
}

public sealed class UnmaskPiRequest
{
    public string Field { get; set; } = "";
    public string Password { get; set; } = "";
}

public sealed class CurrentUser
{
    public string Id { get; set; } = "";
    public string UserName { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string RoleCode { get; set; } = "";
    public string DepartmentCode { get; set; } = "";
    public string BranchCode { get; set; } = "";
    public IReadOnlyList<string> Permissions { get; set; } = [];
    public bool HasPermission(string permission) => Permissions.Contains(permission, StringComparer.OrdinalIgnoreCase);
}


public sealed class UserAdminItem
{
    public string Id { get; set; } = "";
    public string UserName { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string RoleCode { get; set; } = "";
    public string DepartmentCode { get; set; } = "";
    public string BranchCode { get; set; } = "";
    public List<string> Permissions { get; set; } = [];
    public bool IsActive { get; set; }
}

public sealed class SaveUserRequest
{
    public string? Id { get; set; }
    public string UserName { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string? Password { get; set; }
    public string RoleCode { get; set; } = "";
    public string DepartmentCode { get; set; } = "";
    public string BranchCode { get; set; } = "";
    public List<string> Permissions { get; set; } = [];
    public bool IsActive { get; set; } = true;
}

public sealed class SaveAgingBucketRequest
{
    public string? Id { get; set; }
    public string Name { get; set; } = "";
    public int FromDays { get; set; }
    public int? ToDays { get; set; }
    public int DisplayOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class CreateAlertRequest
{
    public string TemplateId { get; set; } = "";
    public string AlertType { get; set; } = "";
    public string BranchCode { get; set; } = "";
    public string CustomerId { get; set; } = "";
    public string AccountId { get; set; } = "";
    public string Priority { get; set; } = "Normal";
    public JsonElement Data { get; set; }
}

public sealed class WorkflowActionRequest
{
    public string Action { get; set; } = "";
    public string? Remarks { get; set; }
    /// <summary>Optional dynamic questionnaire/response values validated and saved before the workflow action.</summary>
    public JsonElement Data { get; set; }
}

public sealed class ReassignWorkItemRequest
{
    public string StageId { get; set; } = "";
    public string? RoleCode { get; set; }
    public string? BranchCode { get; set; }
    public string? UserId { get; set; }
    public string? Remarks { get; set; }
}

public sealed class LoginRequest
{
    public string UserName { get; set; } = "";
    public string Password { get; set; } = "";
}

public sealed class LoginResponse
{
    public string Token { get; set; } = "";
    public DateTime ExpiresAtUtc { get; set; }
    public CurrentUser User { get; set; } = new();
}

public sealed class SaveTemplateRequest
{
    public string? Id { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public ExecutionMode ExecutionMode { get; set; } = ExecutionMode.Deterministic;
    public List<TemplateSection> Sections { get; set; } = [];
    public List<TemplateField> Fields { get; set; } = [];
    public JsonElement AssignmentRules { get; set; }
    public TemplateViewConfiguration ViewConfiguration { get; set; } = new();
}

public sealed class SaveWorkflowRequest
{
    public string TemplateId { get; set; } = "";
    public string Name { get; set; } = "";
    public WorkflowDefinitionModel Definition { get; set; } = new();
    public bool Publish { get; set; }
}

public sealed class AgentDecision
{
    public string Action { get; set; } = "";
    public string Reason { get; set; } = "";
}
