namespace CATS.Core;

public static class PlatformPermissions
{
    public const string DashboardView = "DASHBOARD.VIEW";
    public const string DashboardConfigure = "DASHBOARD.CONFIGURE";
    public const string IngestionView = "INGESTION.VIEW";
    public const string IngestionManage = "INGESTION.MANAGE";
    public const string ReportsMis = "REPORT.MIS";
    public const string ReportsAlertWise = "REPORT.ALERTWISE";
    public const string ReportsAll = "REPORT.ALL";
    public const string MailManage = "MAIL.MANAGE";
    public const string SecurityManage = "SECURITY.MANAGE";
    public const string AssistantUse = "ASSISTANT.USE";
    public const string McpManage = "MCP.MANAGE";
}

public sealed class RoleRecord { public string Code { get; set; }=""; public string Name { get; set; }=""; public bool IsActive { get; set; }=true; }
public sealed class PermissionRecord { public string Code { get; set; }=""; public string Name { get; set; }=""; public string Category { get; set; }=""; public bool IsActive { get; set; }=true; }
public sealed class DataScopeRecord { public string Id { get; set; }=""; public string RoleCode { get; set; }=""; public string ScopeType { get; set; }="OWN"; public string ScopeValue { get; set; }=""; public int Priority { get; set; }=100; public bool IsActive { get; set; }=true; }
public sealed class DashboardWidgetRecord { public string Id { get; set; }=""; public string Code { get; set; }=""; public string Title { get; set; }=""; public string WidgetType { get; set; }="Card"; public string PermissionCode { get; set; }=""; public string FilterJson { get; set; }="{}"; public string DrillDownUrl { get; set; }=""; public int DisplayOrder { get; set; }=1; public int Width { get; set; }=3; public bool IsActive { get; set; }=true; }
public sealed class DashboardWidgetValue { public string Code { get; set; }=""; public string Title { get; set; }=""; public string WidgetType { get; set; }="Card"; public long Value { get; set; } public string DrillDownUrl { get; set; }=""; public int DisplayOrder { get; set; } public int Width { get; set; } }

public sealed class ConnectorRecord { public string Id { get; set; }=""; public string Name { get; set; }=""; public string ConnectorType { get; set; }="SqlServer"; public string Host { get; set; }=""; public int Port { get; set; } public string DatabaseName { get; set; }=""; public string UserName { get; set; }=""; public string SecretEncrypted { get; set; }=""; public string ExtraJson { get; set; }="{}"; public bool IsActive { get; set; }=true; }
public sealed class IngestionConfigurationRecord
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string TemplateId { get; set; } = "";
    public string SourceType { get; set; } = "SFTP";
    public string? ConnectorId { get; set; }
    public string FilePath { get; set; } = "";
    public string FileName { get; set; } = "";
    public string FilePattern { get; set; } = "";
    public string QueryText { get; set; } = "";
    public string ScheduleTriggersJson { get; set; } = "[]";
    public string ScheduleCron { get; set; } = "";
    public string FieldMappingJson { get; set; } = "{}";
    public string DuplicateKeyFields { get; set; } = "";
    public string ArchivePath { get; set; } = "";
    public string ErrorPath { get; set; } = "";
    public int IntervalMinutes { get; set; } = 1;
    public bool IsActive { get; set; } = true;
}

public sealed class IngestionScheduleTrigger
{
    public string Id { get; set; } = "";
    public string Frequency { get; set; } = "DAILY";
    public string StartDate { get; set; } = "";
    public string StartTime { get; set; } = "09:00";
    public int? DayOfWeek { get; set; }
    public int? DayOfMonth { get; set; }
    public string Cron { get; set; } = "";
}
public sealed class IngestionRunRecord { public string Id { get; set; }=""; public string ConfigurationId { get; set; }=""; public string SourceReference { get; set; }=""; public DateTime StartedAtUtc { get; set; } public DateTime? EndedAtUtc { get; set; } public int RowsRead { get; set; } public int RowsInserted { get; set; } public int RowsDuplicate { get; set; } public int RowsFailed { get; set; } public string Status { get; set; }="Running"; public string? ErrorMessage { get; set; } }
public sealed class IngestionDashboard { public int ActiveConfigurations { get; set; } public int RunsToday { get; set; } public int SuccessfulToday { get; set; } public int FailedToday { get; set; } public int RowsInsertedToday { get; set; } public List<IngestionRunRecord> RecentRuns { get; set; }=[]; }

public sealed class MailConfigurationRecord { public string Id { get; set; }=""; public string Name { get; set; }=""; public string ProviderType { get; set; }="SMTP"; public string Host { get; set; }=""; public int Port { get; set; }=587; public string UserName { get; set; }=""; public string SecretEncrypted { get; set; }=""; public string FromAddress { get; set; }=""; public bool UseSsl { get; set; }=true; public bool IsActive { get; set; }=true; }
public sealed class MailTemplateRecord { public string Id { get; set; }=""; public string? TemplateId { get; set; } public string EventCode { get; set; }=""; public string SubjectTemplate { get; set; }=""; public string BodyTemplate { get; set; }=""; public bool UseMafEnrichment { get; set; } public bool IsActive { get; set; }=true; }
public sealed class MailQueueRecord { public string Id { get; set; }=""; public string EventCode { get; set; }=""; public string? AlertId { get; set; } public string ToAddress { get; set; }=""; public string Subject { get; set; }=""; public string Status { get; set; }=""; public int Attempts { get; set; } public DateTime CreatedAtUtc { get; set; } public DateTime? SentAtUtc { get; set; } public string? ErrorMessage { get; set; } }
public sealed class ReportFilter { public string? TemplateId { get; set; } public string? AlertType { get; set; } public string? BranchCode { get; set; } public string? Status { get; set; } public DateTime? FromDate { get; set; } public DateTime? ToDate { get; set; } public int Page { get; set; }=1; public int PageSize { get; set; }=50; }
public sealed class ReportRow { public Dictionary<string,object?> Values { get; set; }=new(StringComparer.OrdinalIgnoreCase); }


public sealed class TemplateDashboardRecord
{
    public string Id { get; set; } = "";
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string TemplateId { get; set; } = "";
    public string AlertType { get; set; } = "";
    public string GroupByFieldsJson { get; set; } = "[\"BranchCode\"]";
    public string MetricsJson { get; set; } = "[]";
    public string GridColumnsJson { get; set; } = "[]";
    public string SearchFieldsJson { get; set; } = "[\"AlertNo\",\"AccountId\",\"CustomerId\"]";
    public int PageSize { get; set; } = 20;
    public int DisplayOrder { get; set; } = 1;
    public bool IsDefault { get; set; }
    public bool IsActive { get; set; } = true;
    public List<string> RoleCodes { get; set; } = [];
}

public sealed class TemplateDashboardMetric
{
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public string Type { get; set; } = "Count"; // Count, StatusCount, FieldEquals, FieldNotEmpty
    public string Field { get; set; } = "";
    public string Value { get; set; } = "";
}

public sealed class TemplateDashboardQuery
{
    public string Search { get; set; } = "";
    public string AlertNo { get; set; } = "";
    public string AccountId { get; set; } = "";
    public string CustomerId { get; set; } = "";
    public string GroupFiltersJson { get; set; } = "{}";
    public string MetricCode { get; set; } = "";
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}

public sealed class TemplateDashboardDataResponse
{
    public TemplateDashboardRecord Dashboard { get; set; } = new();
    public List<Dictionary<string, object?>> SummaryRows { get; set; } = [];
    public List<Dictionary<string, object?>> Rows { get; set; } = [];
    public int TotalRecords { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}
