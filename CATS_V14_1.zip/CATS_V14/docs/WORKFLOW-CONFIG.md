# Dynamic workflow configuration

A workflow is stored as a versioned JSON graph. The UI Workflow Designer writes this model and the server validates all referenced stage IDs before publishing.

## Stage types

- `Human` - creates a pending work item for the configured role/user.
- `ParallelApproval` - creates one work item per configured parallel approver.
- `Condition` - automatically evaluates field rules and routes to a target.
- `Agent` - in Hybrid/Agentic mode can use Microsoft Agent Framework; in Deterministic/disabled mode uses the explicit fallback action.
- `End` - completes the workflow using the configured end status.

## Example JSON

```json
{
  "startStageId": "input",
  "stages": [
    {
      "id": "input",
      "name": "DT Input",
      "type": "Human",
      "roleCode": "DT_USER",
      "allowedActions": ["Submit"],
      "editableFields": ["*"],
      "transitions": [
        { "action": "Submit", "toStageId": "review" }
      ],
      "slaHours": 24
    },
    {
      "id": "review",
      "name": "Parallel Review",
      "type": "ParallelApproval",
      "approvalRule": "Minimum",
      "minimumApprovals": 2,
      "approvers": [
        { "roleCode": "DT_CHECKER", "label": "Checker" },
        { "roleCode": "DT_VERIFIER", "label": "Verifier" },
        { "roleCode": "RISK_APPROVER", "label": "Risk" }
      ],
      "allowedActions": ["Approve", "Reject"],
      "editableFields": [],
      "transitions": [
        { "action": "Approve", "toStageId": "closed" },
        { "action": "Reject", "toStageId": "rejected" }
      ],
      "slaHours": 48
    },
    {
      "id": "closed",
      "name": "Closed",
      "type": "End",
      "endStatus": "Closed"
    },
    {
      "id": "rejected",
      "name": "Rejected",
      "type": "End",
      "endStatus": "Rejected"
    }
  ]
}
```

## Assignment rule JSON

Template assignment rules are evaluated in order. Example:

```json
[
  {
    "field": "riskCategory",
    "operator": "eq",
    "value": "High",
    "stageId": "review",
    "targetRoleCode": "DT_CHECKER",
    "targetUserId": "",
    "targetBranchCode": "B001",
    "stop": true
  }
]
```

Supported comparison operators include `eq`, `neq`, `contains`, `gt`, `gte`, `lt` and `lte`.

Resolved stage assignments are written under a reserved `_assignments` object in alert dynamic JSON; ordinary form rendering does not need to expose this object.


## Stage editable fields

`editableFields` controls which dynamic template fields the assigned user can modify while the alert is at that stage.

- `["*"]` - all non-sensitive template fields are editable.
- `["fieldA", "fieldB"]` - only the listed field keys are editable.
- `[]` or omitted - the stage is read-only.
- Sensitive fields also require the caller to have the server-side PI/unmask permission; the editable list alone never grants sensitive-data access.
- Reserved internal keys such as `_assignments` cannot be updated from the browser.

Workflow actions can submit the current stage response and action together. The API validates and stores allowed response fields before advancing the workflow.

## Reassignment

Pending current-stage work items may be reassigned by an authorized Admin/Central user to another role code and/or user ID. Reassignment changes the pending work-item assignment only; it does not rewrite the published workflow definition or workflow version. Every reassignment is audited.
