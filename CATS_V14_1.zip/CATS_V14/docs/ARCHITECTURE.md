# CATS architecture

```text
Browser: Bootstrap + jQuery
             |
             v
      YARP API Gateway
     rate limit / headers
             |
             v
 ASP.NET Core MVC + REST API
             |
      +------+-------+
      |              |
Application      JWT/Authorization
Services              |
      |                |
      +-------+--------+
              |
       Dynamic Workflow Engine
       |      |       |
   Human   Condition  Agent(MAF)
       |      |       |
       +------+-------+
              |
        Repository contracts
              |
       Shared ADO.NET helper
       /       |        \
SQL Server  PostgreSQL  Oracle
```

## Persistence approach

Relational tables hold operational keys/status/stage/assignment/audit data. Template-specific questionnaire values are held as JSON in `Alerts.DynamicDataJson`. Template fields and sections are metadata JSON in the versioned `Templates` row. Workflow graph configuration is versioned JSON in `WorkflowDefinitions`.

This avoids dynamic DDL per template and keeps all three database providers supportable.

## Authorization

A JWT contains user/role/branch/permission claims. Server-side authorization has two layers:

1. **Visibility** - global permission, same branch, or pending work-item role/user assignment.
2. **Action authorization** - a pending work item must match the current user/role and the requested action must exist in the current stage's allowed actions.

The UI merely reflects these decisions; it is not the security boundary.

## Workflow durability

CATS persists workflow instances and human work items in its own database so ERP-style transactions remain resumable across HTTP requests/process restarts. MAF is used as a .NET agent/workflow integration layer for graph validation/visualisation and agent stages without making an LLM mandatory for ordinary approval processing.

## Parallel approval

Each parallel approver receives a work item in a shared group. Completion is atomic (`UPDATE ... WHERE Status='Pending'`). The engine evaluates the group after each action using All/Any/Minimum/Single policy, cancels unneeded pending items when the group resolves, then follows the configured Approve/Reject transition.

## Audit

`AuditLog` is insert-oriented and records user, role, action, entity, stage, previous/new JSON, remarks, IP and UTC time. Application DB accounts should not receive delete/update access to audit records in production where regulatory policy requires immutability.
