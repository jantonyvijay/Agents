# Desktop Due Diligence Money Mule – Configuration Seed

This package now includes a new configuration-based sample implementation for the **Desktop Due Diligence Money Mule** flow without changing existing template flows.

## What was added

- **Template code:** `DT_DD_MONEY_MULE`
- **Template name:** `Desktop Due Diligence Money Mule`
- **Layout mode:** `Single`
- **Sections:**
  1. Customer Alert Profile
  2. Questionary Response
  3. Remarks & Recommendations
- **Workflow:**
  - `DT User Review` → action `Submit`
  - `DT Verifier Review` → actions `Send Back` / `Verified`
  - `Closed`
- **Dashboards:**
  - `Desktop Due Diligence - DT User` â€” visible only to `DT_USER`; metrics are Total Record, Continue Txn Restriction, Remove Txn Restriction, and Pending.
  - `Desktop Due Diligence - DT Verifier` â€” visible only to `DT_VERIFIER`; metrics are Total, Continue Txn Restriction, Remove Txn Restriction, Closed, and Pending.
  - Both dashboards group records by Location and Analyst Name. Clicking a count opens the Alerts screen with the selected row, metric, and search criteria preserved.
- **Sample upload file:** `samples/DesktopDueDiligence_MoneyMule_Sample.csv`

## Users

Default seeded demo users remain unchanged:

- `admin / Cats@1234`
- `central / Cats@1234`
- `dtuser / Cats@1234`
- `verifier / Cats@1234`

## Why it does not impact other flows

- The feature is seeded as a **new template and new workflow definition**.
- Existing templates and workflows are not altered.
- The two released dashboards are role-mapped only to their intended DT role. Admin/Central users can still maintain them through dashboard configuration.

## Deployment

- With `DatabaseStartup:AutoInitialize=true`, deploy and restart the application; the released dashboard configuration is upserted automatically.
- With automatic initialization disabled, run `db/sqlserver/CATS_V10_DT_MoneyMule_Dashboard_Release.sql` before deploying the application.

## How to test

1. Start the application normally.
2. Login as `central` or `admin`.
3. Open **New Alert / Upload**.
4. Select alert type **Desktop Due Diligence Money Mule**.
5. Use the included CSV sample or download the generated sample CSV from the UI.
6. Login as `dtuser` and open the DT User dashboard.
7. Open a record, update questionnaire/remarks, and click **Submit**.
8. Login as `verifier`, open the DT Verifier dashboard, then choose **Send Back** or **Verified**.
