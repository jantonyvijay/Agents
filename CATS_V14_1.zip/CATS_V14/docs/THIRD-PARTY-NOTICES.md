# Third-party browser assets

CATS bundles browser assets locally so the application UI can run without a public CDN.

- **jQuery 3.7.1** — Copyright OpenJS Foundation and contributors — MIT license — https://jquery.org/license/
- **Bootstrap 5.3.6** — Copyright Bootstrap Authors and Twitter, Inc. — MIT license — https://github.com/twbs/bootstrap/blob/main/LICENSE

The minified files retain their upstream copyright/license headers.
