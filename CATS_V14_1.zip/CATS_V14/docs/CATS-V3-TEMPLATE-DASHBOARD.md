# CATS V3 - Template / Alert-Type Configurable Dashboards

This update is additive and preserves the existing Aging Matrix, Alerts, dynamic workflow, ingestion, reports, mail, audit, and role-based actions.

## Added
- TemplateDashboardMaster and TemplateDashboardRoleMapping.
- Database-permission-controlled dashboard management (`DASHBOARD.CONFIGURE`).
- Role-specific visibility of dashboards.
- Dashboard selector keeps the existing Overview / Aging Matrix as the first option.
- Configurable search fields, group-by fields, summary metrics, grid columns, page size, title and description.
- Dynamic fields are read from existing `Alerts.DynamicDataJson`; no new alert table per template.
- Customer/Account search works against decrypted server-side values; display remains masked unless the user has `PI.UNMASK`.
- Row click opens the existing Alert Detail page, so existing Maker/Checker/Verifier workflow actions are unchanged.
- Removed hard-coded ADMIN/CENTRAL data-access bypasses from source SQL and UI admin check; permissions/data scopes are database-driven.

See `docs/TEMPLATE-DASHBOARD.md` for a Money Mule-style configuration example.
