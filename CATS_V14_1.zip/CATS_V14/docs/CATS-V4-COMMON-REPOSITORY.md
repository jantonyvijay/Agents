# CATS V4 – Common ADO Repository + Module Stored Procedures

## New call flow

```text
CatsRepository / PlatformRepository
        |
        v
AdoHelper.QueryRepositoryAsync / ExecuteRepositoryAsync
        |
        v
dbo.usp_CommonRepository
  @ModuleCode
  @MethodCode
  @strJson
        |
        v
dbo.USP_<ModuleCode>_<MethodCode>
```

Examples:

- `USP_User_GetByUserName`
- `USP_User_Upsert`
- `USP_Template_GetAll`
- `USP_Template_Save`
- `USP_Alert_Insert`
- `USP_Alert_GetPaged`
- `USP_WorkItem_Complete`
- `USP_TemplateDashboard_GetAll`
- `USP_TemplateDashboard_Save`
- `USP_Ingestion_GetDashboard`
- `USP_Report_GetData`

Every leaf procedure accepts the same JSON parameter:

```sql
@strJson nvarchar(max)
```

`usp_CommonRepository` validates the requested module/method, checks that the resolved
procedure exists, quotes the procedure name, and executes it using `sp_executesql`.

## Backward compatibility

`dbo.usp_CatsRepository` and `dbo.usp_PlatformRepository` are retained only as small
routing wrappers. Existing callers using the old `@Operation/@JsonInput` contract can
continue working. The CATS .NET repositories no longer call those procedures.

## Deployment

For a database that previously encountered the V3 TemplateDashboard column mismatch,
run:

`db/sqlserver/CATS_V4_SQLServer_Consolidated_Upgrade.sql`

For a clean V3 database that already has the correct dashboard schema, you may run only:

`db/sqlserver/CATS_V4_CommonRepository_Upgrade.sql`

The full `db/sqlserver/schema.sql` already contains the V4 modular repository design.
