# CATS V9 - Configurable Template Presentation & Field Behaviour

## Additive design
This update does not replace workflow, dashboard, ingestion, reports, AI Query, MCP, Gateway, audit, masking, or existing alert actions. It extends the existing template metadata.

## Template View / Layout Configuration
Central Team users with TEMPLATE.MANAGE can choose per template:
- Single
- Tab
- Popup
- Accordion
- Wizard / Step

Each section can independently choose Grid View or List View. The same configured fields are reused in New Alert and Alert Detail; no template-specific HTML is required.

## Field configuration
Fields support:
- Static dropdown options
- API dropdown options through a relative `/api/...` Gateway route
- API value/text property mapping
- Dependency fields for API URL placeholders, e.g. `/api/meta/products?branch={BranchCode}`
- Required / Sensitive / Read Only
- Placeholder / Help text / Default value
- Min length / Max length
- Min number / Max number
- Regex validation
- Custom validation error message
- Character counter such as `2/10` when Max Length is configured
- Multiple-control dependency validation through JSON rules

### Dependency rule example
```json
[
  {
    "conditions": [
      { "field": "CustomerType", "operator": "eq", "value": "Corporate" },
      { "field": "Risk", "operator": "eq", "value": "High" }
    ],
    "required": true,
    "errorMessage": "This field is required for high-risk corporate customers."
  }
]
```
Operators: `eq`, `neq`, `contains`, `empty`, `notempty`.
`mustEqualField` can be used for matching controls.

## Validation layers
1. Browser validation gives immediate feedback.
2. API validates template configuration when Central Team saves a template.
3. Server validates submitted dynamic values during alert/workflow actions.

## API dropdown security
API-backed dropdowns must use a relative `/api/...` URL. The browser uses the existing CATS `api()` helper, so JWT and Gateway routing are preserved. External systems should be exposed through a controlled CATS integration API/connector rather than putting external credentials in template JSON.

## Database
`Templates.ViewConfigurationJson` stores layout configuration. Advanced field settings remain inside the existing `FieldsJson`, preserving the generic metadata model.

Run `db/sqlserver/CATS_V9_TemplatePresentation_Upgrade.sql` for an existing SQL Server database.
