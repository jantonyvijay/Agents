# CATS consolidated requirements

## Objective

CATS shall allow a Central Team to create and operate reusable dynamic templates, sections, questionnaires, assignments and workflows. Uploaded alerts are assigned to Branch/RM/other users and progress according to the published workflow. The system tracks responses, queries, dependencies/artifacts, aging and closure.

## Functional requirements

1. Create/version/publish dynamic templates.
2. Create/reorder template sections and questionnaire fields.
3. Configure workflow per template without code deployment.
4. Configure dynamic required fields and field types.
5. Store stable operational fields relationally and template-specific values in standard JSON metadata/data, not per-template physical tables.
6. Upload/create alerts under a published template; support CSV batch upload.
7. Assign alerts/work stages using configurable rules to Branch/RM/role/user.
8. Execute the exact workflow version selected when the alert starts.
9. Allow assigned users to view records and perform only workflow actions authorized for their current role/user assignment.
10. Provide an easy visual workflow designer.
11. Use reusable components and common coding standards.
12. Mask Customer ID, Account ID and template fields marked sensitive; unmask only for explicitly permitted roles.
13. Maintain complete business audit history.
14. Support fully configurable roles/stages/actions; Maker, Inputter, Checker, Verifier and Approver are labels/roles, not hard-coded sequence positions.
15. Support sequential, conditional and parallel workflow paths.
16. Parallel approvals support All, Any and N-of-M minimum approvals.
17. Support Query/Respond/Return and other configured transitions.
18. Support attachments/artifacts with version, hash, upload/download audit.
19. Support template/workflow versioning so existing transactions are not changed by later configuration.
20. Support deterministic, hybrid and agentic template execution; LLM usage is optional.
21. Dashboard shall show multiple templates/alert types on one aging matrix, with aging buckets as columns.
22. Every count in the aging matrix shall drill down to the corresponding list.
23. List page shall provide filters, server-side pagination and row drill-down.
24. Detail page shall render from the template definition and expose actions from the live workflow/role assignment.
25. Data visibility and permission to act shall be separately enforced on server APIs.
26. Show current-stage aging and overall alert aging.
27. Aging bucket definitions are stored in `AgingBuckets` and defaults are 0-1, 2-3, 4-7, 8-15, 16-30 and 31+ days.
28. Every workflow stage can define SLA hours; generated work items receive a due time.
29. Every material action is audit logged, including login/logout, failed login, create, view/unmask, template/workflow changes, stage entry, workflow actions, agent decisions, file upload/download and closure transitions.
30. Each workflow stage may configure which dynamic questionnaire fields are editable. The server shall reject changes to unknown, reserved, non-editable or unauthorized sensitive fields.
31. Authorized Central/Admin users may reassign a current pending work item to another role/user; reassignment is server-authorized and audited.
32. Workflow action submission may carry the stage response data and shall validate/store the permitted data before advancing the workflow.

## Technical requirements

- ASP.NET Core/.NET 8 + C# only for server/application code.
- jQuery + Bootstrap responsive front end; no React.
- No Python application component.
- REST API with JWT bearer authentication.
- YARP API gateway.
- No Entity Framework Core; use common ADO.NET helper/repository layer.
- SQL Server/PostgreSQL/Oracle selected by configuration.
- Microsoft Agent Framework .NET packages for MAF capability.
- Responsive tables/grids with server-side pagination.

## V9 configurable template presentation and field behaviour
- Template-level Single / Tab / Popup / Accordion / Wizard layout.
- Section-level Grid / List presentation.
- API-backed dropdown configuration through Gateway-relative API routes.
- Min/max length and numeric validation, regex, custom messages, counters, default/read-only/help text.
- Multi-control dependency validation configured as metadata.
- Same renderer/validation used for New Alert and Alert Detail without changing existing workflow actions.
