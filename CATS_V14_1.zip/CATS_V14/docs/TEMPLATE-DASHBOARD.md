# CATS Template / Alert-Type Configurable Dashboards

CATS V3 adds dashboards configured by Central Team/Admin users who have `DASHBOARD.CONFIGURE`. Existing Aging Matrix and alert workflows are unchanged.

## Money Mule example
- Template: Money Mule template
- Alert Type: Money Mule
- Group By Fields: `BranchCode,AnalystName`
- Search Fields: `AlertNo,AccountId,CustomerId`
- Grid Columns: `AlertNo,AccountId,CustomerId,Product_name,UNIT,total_live_loan_amount,customer_permanent_state,Customer_date_of_birth,Customer_country,Status`
- Metrics JSON:
```json
[
  {"code":"TOTAL","title":"Total Record","type":"Count"},
  {"code":"CONTINUE","title":"Continue Txn Restriction","type":"FieldEquals","field":"ContinueTxnRestriction","value":"1"},
  {"code":"REMOVE","title":"Remove Txn Restriction","type":"FieldEquals","field":"RemoveTxnRestriction","value":"1"},
  {"code":"CLOSED","title":"Closed","type":"StatusCount","value":"Closed"},
  {"code":"PENDING","title":"Pending","type":"StatusCount","value":"Pending"}
]
```

Role visibility comes from `TemplateDashboardRoleMapping`. No Admin/Central hard-coded bypass is used. Row click opens the existing alert detail page, so existing role/workflow actions remain unchanged.

## Deployment
1. Back up database.
2. Apply table upgrade from `db/sqlserver/CATS_V3_TemplateDashboard_Upgrade.sql`.
3. Deploy the updated application. The full `db/sqlserver/schema.sql` contains the updated `dbo.usp_PlatformRepository` procedure operations required by V3.
