# CATS V12 Template Fields Enhancement

Implemented for the Template Fields / Alert List configuration screen.

1. Choice option panel is shown only for choice controls (Dropdown List, Multi Select, Checkbox List, Radio Button List).
2. Sections can be reordered using native drag-and-drop; `order` is recalculated automatically.
3. Alert List Configuration supports drag-and-drop ordering and a numeric Order field.
4. Dynamic template controls no longer rely on browser-native hidden `required` validation. The portal uses CATS validation and `novalidate`, avoiding `An invalid form control with name='' is not focusable`.
5. Validation Regex and Custom Error Message are visible only when Required is enabled.
6. Validation now opens the containing Tab / Accordion / Wizard step / Popup and scrolls/focuses the first invalid control.
7. Added runtime/designer control support: Textbox, Text Area, Number, Amount, Date, DateTime, Time, Email, Phone, Dropdown List, Multi Select, Checkbox, Checkbox List, Radio Button List, File Upload.
8. Alert-list filters retain control metadata. Dropdown fields render dropdown filters; built-in Status is a dropdown. API-backed dropdown fields can also load their options through the configured CATS `/api/...` route.

## Files changed

- `src/CATS.App/Views/Home/Index.cshtml`
- `src/CATS.App/wwwroot/js/app.js`
- `src/CATS.App/wwwroot/css/site.css`
- `src/CATS.Core/Models.cs`

No database schema change is required. The extra Alert List filter metadata is stored inside the existing `ViewConfigurationJson`.
