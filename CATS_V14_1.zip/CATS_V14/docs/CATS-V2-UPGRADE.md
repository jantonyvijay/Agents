# CATS V2 Upgrade

This build adds database-driven authorization, configurable dashboard widgets, generic ingestion configuration/monitoring, MIS/Alert Wise/All Alert reports, and deterministic mail configuration with optional MAF enrichment.

## Security
Role and permission data is stored in RoleMaster, PermissionMaster, RolePermissionMapping, UserPermissionMapping and DataScopeMaster. Authentication resolves effective permissions from the database. Hard-coded ADMIN/CENTRAL view/upload bypasses were removed from application services and repository filters.

## Dashboard
DashboardWidgetMaster and DashboardWidgetRoleMapping control which cards/sections each role sees. Included widget codes: ACTIVE_ALERTS, TEMPLATES, AGING_31_PLUS, INGESTION_FAILED.

## Ingestion
Supported source configuration types: MANUAL_SINGLE, MANUAL_CSV, SFTP, SHARED_FOLDER and FC_QUERY. CATS.Ingestion.Worker is a .NET 9 Windows Service host for scheduled sources. Data is staged in IngestionStaging and SQL Server processing is centralized in dbo.usp_CATS_ProcessIngestion.

For FC Query, use a read-only technical account and approved SELECT/stored-procedure logic only. Do not grant DML/DDL rights to source connectors.

## Reports
API: /api/platform/reports/MIS, /ALERTWISE, /ALL. All reports apply effective permission/data-scope filtering.

## Mail
MailConfiguration, MailTemplate and MailQueue are deterministic. UseMafEnrichment can enrich wording/summaries, but recipient selection and send/no-send decisions remain rule based.

## Oracle
The Oracle schema file contains migration guidance for the added V2 objects. Implement equivalent tables using VARCHAR2/CLOB/NUMBER/TIMESTAMP and a sequence/identity strategy for IngestionStaging.Id before enabling Oracle configuration writes.
