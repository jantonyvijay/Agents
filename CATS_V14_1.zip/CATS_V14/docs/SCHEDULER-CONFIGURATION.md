# CATS external scheduler configuration

Ingestion schedules are configured in the portal under **Ingestion Tasks & Logs**. Keep the portal and the job runner separate: the portal stores settings; `CATS.Ingestion.Worker.exe` reads active settings and records execution results.

## Sample portal configuration

- Task name: `Daily branch alerts`
- Source type: `File Download from SFTP`
- File path: `/incoming/alerts`
- File name: `alerts.csv`
- Triggers: daily at 09:00 and weekly on Saturday at 18:00

The other available source is **Records returned by Query**, which replaces the file fields with a query text area. One ingestion task can contain up to 20 one-time, daily, weekly, or monthly triggers. The first trigger is also saved to the legacy `ScheduleCron` field for compatibility; the complete trigger collection is stored in `ScheduleTriggersJson`.

For an existing SQL Server deployment, run `db/sqlserver/CATS_V9_IngestionScheduler_Upgrade.sql` before deploying the updated application. New or automatically initialized databases receive the columns and procedures from `db/sqlserver/schema.sql`.

## Windows Task Scheduler example

Run PowerShell as Administrator and adjust the executable path and service account:

```powershell
schtasks /Create /TN "CATS Ingestion Worker" /SC ONSTART /RU "DOMAIN\cats-service" /RP "*" /TR "D:\Apps\CATS\CATS.Ingestion.Worker.exe" /F
schtasks /Run /TN "CATS Ingestion Worker"
```

For production, the preferred installation is the built-in Windows Service mode:

```powershell
sc.exe create CATSIngestionWorker binPath= "D:\Apps\CATS\CATS.Ingestion.Worker.exe" start= auto
sc.exe start CATSIngestionWorker
```

Use the same `Database` connection in the worker's `appsettings.json` as the portal. Do not store SMTP, SFTP, or database passwords in scheduler arguments; enter secrets in the portal, where they are protected before storage.
