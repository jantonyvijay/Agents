# CATS Optional AI Query Assistant

This feature is **additive only**. It does not replace or change the existing manual Query/RaiseQuery workflow.

## Behaviour

- The existing Query/`RaiseQuery` workflow action remains authoritative.
- AI only drafts text into the existing Remarks/Query textbox.
- The user can edit or ignore the draft.
- The query is raised only when the user clicks the existing **Confirm** button.
- Existing role/work-item/allowed-action checks are performed before AI drafting is available.
- If `AIQuery:Enabled=false`, the UI and existing manual behaviour remain unchanged.
- AI generation failure does not block manual query entry.

## Configuration

`src/CATS.App/appsettings.json` contains a separate `AIQuery` section so workflow Agent configuration and Query Assistant configuration are independent.

```json
"AIQuery": {
  "Enabled": true,
  "Provider": "OpenAICompatible",
  "Endpoint": "https://generativelanguage.googleapis.com/v1beta/openai/",
  "Model": "gemini-2.5-flash",
  "ApiKey": "USE_A_SECRET_STORE_IN_PRODUCTION",
  "MaskPiData": true,
  "MaxContextCharacters": 12000,
  "Rules": [
    {
      "TemplateId": "*",
      "AlertType": "*",
      "StageId": "*",
      "RoleCode": "DT_CHECKER",
      "Enabled": true
    }
  ]
}
```

Rules use `*` as a wildcard. More specific matching rules take precedence. A rule can override `Provider`, `Endpoint`, `Model`, `ApiKey`, and `PromptTemplate`, allowing an internal SLM for one template/stage and an approved hosted LLM for another.

For production, prefer injecting secrets with environment variables / your approved secret store instead of committing API keys. ASP.NET Core environment variable example: `AIQuery__ApiKey=...`.

Example local SLM rule:

```json
{
  "TemplateId": "tpl-money-mule",
  "AlertType": "Money Mule",
  "StageId": "checker",
  "RoleCode": "DT_CHECKER",
  "Enabled": true,
  "Provider": "LocalSLM",
  "Endpoint": "http://localhost:11434/v1/",
  "Model": "your-openai-compatible-local-model",
  "ApiKey": "local"
}
```

## PI handling

`MaskPiData` defaults to `true`. Customer ID, Account ID and template fields marked `Sensitive` are masked before being sent to the model.

## API

`POST /api/alerts/{id}/ai-query-suggestion`

```json
{ "instruction": "Focus on source of funds" }
```

The endpoint checks that the user can view the alert and currently has `RaiseQuery` or `Query` as an allowed workflow action. It does **not** execute a workflow action.

## Audit

Each successful suggestion writes `AI_QUERY_SUGGESTED` to the existing audit log. The existing `QUERY_RAISED` / workflow audit continues to be produced by the normal action path.
