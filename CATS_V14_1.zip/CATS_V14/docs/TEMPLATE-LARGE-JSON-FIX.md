# CATS V11 Template Fields / View Configuration Save Fix

## Symptom

A template saves successfully, but the database row contains:

```json
"fieldsJson": "[]",
"viewConfigurationJson": "{}"
```

while `sectionsJson` and smaller configuration values are saved correctly.

## Root cause

The repository used to serialize `Fields` and `ViewConfiguration` first, then put those serialized values inside another JSON request. That made them escaped JSON **strings**.

The SQL template save procedure used `JSON_VALUE` as the string fallback. SQL Server `JSON_VALUE` without `RETURNING` is limited to `nvarchar(4000)`. Larger field definitions therefore became `NULL`, and `COALESCE` replaced them with `[]` or `{}`.

The Desktop Due Diligence Money Mule field definition is large enough to trigger this condition.

## Fix

V11 now:

1. Sends `sectionsJson`, `fieldsJson`, `assignmentRulesJson`, and `viewConfigurationJson` as nested JSON arrays/objects from C#.
2. Uses a SQL save procedure that accepts both the new nested format and the legacy escaped-string format.
3. Uses `OPENJSON ... nvarchar(max)` for legacy strings, avoiding the 4,000-character limit.
4. Verifies the persisted field count and view configuration before returning a successful API response.
5. Repairs the SYSTEM Money Mule seed in place when its `FieldsJson=[]` or `ViewConfigurationJson={}` is still empty and automatic database initialization is enabled.

## Existing SQL Server database

Run once:

```text
db/sqlserver/CATS_V11_TemplateLargeJsonFix_Upgrade.sql
```

Then restart CATS and edit/save the template again.

If automatic database initialization is enabled, restarting also repairs an incomplete SYSTEM `DT_DD_MONEY_MULE` seed record without overwriting non-empty user configuration.
