# PI and user appearance

Account menu offers Light, Dark, Match browser, Ocean, Forest and Violet. Layout choices are Standard, Compact and Wide. Each choice is saved per account in the current browser; preferences do not sync across devices. Wide collapses desktop navigation and retains the mobile navigation toggle.

Template Add/Edit Field: PI / Sensitive data masks saved alert values by default. Allow PI reveal controls whether an authorised user can reveal that field after password verification. Existing sensitive fields default to allowing authorised reveal. Every successful reveal writes PI_UNMASK_VIEW without recording the value. Visibility rules are separate.

Permission is now PI.UNMASK and the endpoint is POST /api/alerts/{id}/unmask-pi. Deploy the SQL Server permission upgrade in db/sqlserver/CATS_V10_PI_Permission_Upgrade.sql before restarting the application. The migration preserves assignments and can be rerun. Users must sign in again to refresh permission claims. Existing audit history is retained with its original event names. The old permission text appears only in the migration for identifying legacy records.

Validation: `node scripts/check-user-appearance.cjs` and `dotnet run --project scripts/PiChecks/PiChecks.csproj -c Release`. The backend checks use an in-memory repository; the SQL migration requires verification against the deployment database.

Users can also choose an alert section layout: Template default, Single page, Tabs, Accordion, Popup sections or Step-by-step wizard. This preference applies when an alert or creation form is next opened, preserving any current unsaved form. It is stored per account in the browser and does not modify the template definition.

White and Blue themes are also available. White uses a clean white backdrop without the decorative grid or watermark. Colour themes now tint the header, sidebar, cards, forms, and section surfaces, with matching primary and outline buttons.

Theme surfaces use distinct complementary shades: dark navigation, pale card and form headings, white (or dark-mode slate) content cards, softly tinted inputs, and a darker popup title bar with white text. White keeps its white content background with charcoal navigation.
