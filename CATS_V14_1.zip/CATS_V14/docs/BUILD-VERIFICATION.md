# Build and verification

## Verification performed while generating this package

The package was checked for:

- JavaScript syntax (`node --check` on `wwwroot/js/app.js`).
- JSON parsing for all JSON configuration/launch-settings files.
- XML parsing for all project files.
- C# lexical delimiter balance across source files.
- Absence of Entity Framework Core, React and Python application dependencies.
- ZIP integrity after packaging.

The generation environment used for this package does **not** contain the .NET SDK, so a real `dotnet restore/build` could not be executed here. Run the following on a machine with the .NET 8 SDK.

## Build

From the CATS solution folder:

```powershell
dotnet restore .\CATS.sln
dotnet build .\CATS.sln -c Release --no-restore
```

Or:

```powershell
.\scripts\build.ps1
```

## Run

```powershell
.\scripts\run.ps1
```

Open:

```text
http://localhost:7000
```

The gateway is on port 7000 and the application is on port 7001.

## End-to-end smoke test

With both processes running:

```powershell
.\scripts\smoke-test.ps1
```

The smoke test exercises the seeded workflow end to end:

1. Admin logs in and creates an alert.
2. DT User opens the assigned work, submits stage response data and `Submit`.
3. Parallel Checker approves.
4. Parallel Verifier approves.
5. The workflow reaches `Closed`.
6. Audit records are checked.

## Database notes

- SQL Server LocalDB is the default development configuration and the database can be auto-created.
- PostgreSQL requires the target database to exist before startup; CATS can initialize its schema.
- Oracle requires the target user/schema to exist before startup; CATS can initialize its tables.
- Change seeded credentials, JWT signing key and data-encryption key before production deployment.
