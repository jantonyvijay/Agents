# CATS V6 - Common Repository, Gateway, MCP Discovery and CATS Assistant

## Goals

V6 adds reusable infrastructure without replacing existing CATS business features. Existing templates, configurable dashboards, manual/CSV ingestion, workflow, parallel approval, Alert Detail Query, optional AI Query, reports, audit, masking and attachments remain in place.

## 1. Reusable database repository pattern

For SQL Server, application repositories now use one ADO.NET dispatcher entry point:

```text
Controller / Service
      -> ICatsRepository / IPlatformRepository
      -> AdoHelper.QueryRepositoryAsync / ExecuteRepositoryAsync
      -> dbo.usp_CommonRepository
      -> USP_<ModuleCode>_<MethodCode>
      -> CATS tables
```

Examples:

```text
User + GetAll        -> dbo.USP_User_GetAll
Alert + GetPaged     -> dbo.USP_Alert_GetPaged
Template + Save      -> dbo.USP_Template_Save
Report + GetData     -> dbo.USP_Report_GetData
```

`usp_CommonRepository` validates module/method identifiers, verifies that the leaf stored procedure exists, quotes the identifier and passes one JSON payload (`@strJson`). The C# layer uses a route registry instead of large `if/else` blocks.

Legacy `usp_CatsRepository` and `usp_PlatformRepository` remain only as compatibility routers for older callers.

SQL modules are separated under `db/sqlserver/modules/` so they can be deployed/tested independently.

> The modular stored-procedure dispatcher is the SQL Server reference implementation. PostgreSQL and Oracle DDL remain in the repository, but equivalent module-dispatcher procedures must be implemented for those providers before switching a production V6 deployment away from SQL Server.

## 2. Gateway-first API access

The browser uses same-origin URLs such as `/api/alerts`. YARP listens on port 7000 and routes all API/UI traffic to the internal ASP.NET Core application on port 7001.

```text
Browser -> YARP :7000 -> CATS.App :7001 -> Application/Workflow -> ADO.NET -> Database
```

The API route adds `X-CATS-Gateway-Key`. `GatewayAccessMiddleware` can reject direct `/api/*` calls that do not contain the expected gateway key.

Development values are in configuration only as examples. In production, inject the gateway shared key from a secret store/environment and do not expose port 7001 externally.

## 3. MCP discovery

MCP connections are created by the trusted CATS backend, not by the browser:

```text
Administration UI -> YARP -> /api/mcp/... -> CATS API -> remote MCP server
```

Configuration is under `Mcp` in `appsettings.json`.

- MCP is disabled by default.
- Individual servers are disabled by default.
- Discovery lists tools but does not automatically approve them.
- Only names explicitly listed in `ApprovedReadOnlyTools` can be supplied to the CATS Assistant.
- `MCP.MANAGE` permission is required to view/discover configured servers.

The Administration screen contains an MCP Discovery panel for users who have both access to Administration and `MCP.MANAGE`.

## 4. CATS Assistant ChatBox

The floating CATS Assistant is independent of the existing Alert Detail Query feature.

```text
Browser ChatBox -> YARP -> /api/assistant/chat -> CATS Assistant
                                            -> authorised CATS repositories
                                            -> optional approved read-only MCP tools
                                            -> configured SLM/LLM
```

Rules:

- `ASSISTANT.USE` permission is required.
- Disabled by default.
- Uses current user permissions and data scopes before building context.
- PI identifiers are masked by default.
- Assistant is read-only; it does not approve/reject/verify/reassign/close/create alerts.
- Optional MCP tools are exposed only if `Assistant:EnableApprovedMcpTools=true` and they are explicitly approved in MCP configuration.
- Assistant queries are audited using a SHA-256 hash of the user question rather than storing the full prompt in the ordinary audit remarks.

## 5. Existing Alert Detail AI Query

No existing Query functionality is removed.

```text
Manual Query -> existing Raise Query action -> existing workflow
AI Suggest Query (optional) -> fills draft -> human review/edit -> existing Raise Query action
```

AI Query cannot submit a workflow action itself.

## Configuration example

```json
{
  "GatewayAccess": {
    "RequireForApi": true,
    "HeaderName": "X-CATS-Gateway-Key",
    "SharedKey": "inject-from-secret-store"
  },
  "Assistant": {
    "Enabled": false,
    "Provider": "OpenAICompatible",
    "Endpoint": "https://your-approved-endpoint/v1/",
    "Model": "your-model",
    "ApiKey": "inject-from-secret-store",
    "MaskPiData": true,
    "EnableApprovedMcpTools": false,
    "MaxContextCharacters": 24000
  },
  "Mcp": {
    "Enabled": false,
    "Servers": [
      {
        "Code": "internal-cats-tools",
        "Name": "Internal CATS MCP",
        "Endpoint": "https://internal-mcp.example/mcp",
        "Enabled": false,
        "TimeoutSeconds": 30,
        "Headers": {},
        "ApprovedReadOnlyTools": []
      }
    ]
  }
}
```

## SQL deployment

For an existing SQL Server CATS database, run:

`db/sqlserver/CATS_V6_SQLServer_Consolidated_Upgrade.sql`

For a database that already has the V4 common repository schema and only needs the new V6 permissions, run:

`db/sqlserver/CATS_V6_Assistant_MCP_Permissions.sql`

Take a database backup before upgrade.
