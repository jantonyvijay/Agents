# CATS - Configurable Alert & Tracking System

> **V11 template persistence hotfix:** Large Template `FieldsJson` / `ViewConfigurationJson` payloads are now saved without SQL Server's `JSON_VALUE` 4,000-character truncation/fallback problem. The repository sends nested JSON, the SQL save procedure accepts both new and legacy payload shapes, template reads always return `ViewConfigurationJson`, and the SYSTEM Money Mule seed repairs empty field/view configuration placeholders on startup. For an existing SQL Server deployment with automatic initialization disabled, run `db/sqlserver/CATS_V11_TemplateLargeJsonFix_Upgrade.sql` once. See `docs/TEMPLATE-LARGE-JSON-FIX.md`.

> **V10 update:** Adding or modifying template fields and sections now updates the selected Draft or Published template in place. Role-specific DT User and DT Verifier Money Mule dashboards and exact count drill-down are also included. For an existing SQL Server deployment with automatic initialization disabled, run `db/sqlserver/CATS_V10_TemplateInPlaceUpdate_Upgrade.sql`, `db/sqlserver/CATS_V10_DT_MoneyMule_Dashboard_Release.sql`, and `db/sqlserver/CATS_V10_AlertNumber_Upgrade.sql` once.

> **V6 update:** Common ADO.NET dispatcher (`usp_CommonRepository` -> module-wise stored procedures), gateway-first API access, backend MCP discovery, and an optional read-only SLM/LLM CATS Assistant are added without replacing existing CATS workflow/query functionality. See `docs/CATS-V6-GATEWAY-MCP-ASSISTANT.md`.

> **V3 update:** Template / Alert-Type configurable dashboards are available under Dashboard. Central/Admin access is controlled by database permission `DASHBOARD.CONFIGURE`. Existing overview/aging functionality remains available. See `docs/CATS-V3-TEMPLATE-DASHBOARD.md`.


CATS is a configurable enterprise alert, questionnaire, workflow, approval, aging and audit platform built with Microsoft .NET only on the server and jQuery/Bootstrap in the browser.

## Technology

- .NET 9 / ASP.NET Core MVC + REST API
- C# / .NET 9
- jQuery + Bootstrap 5 responsive UI
- JWT bearer authentication
- YARP reverse-proxy/API gateway
- ADO.NET repository/helper layer (**no Entity Framework Core**)
- SQL Server, PostgreSQL or Oracle selected by configuration
- Microsoft Agent Framework (MAF) for workflow graph validation/visualisation and optional AI-agent stages
- Metadata + JSON dynamic template data model

There is no React and no Python application component.

## Implemented CATS capabilities

- Dynamic templates, sections and questionnaire fields
- In-place template field/section maintenance and published workflow versioning
- Dynamic workflow stages; Maker/Inputter/Checker/Verifier/Approver names are not hard-coded
- Roles loaded from active CATS users; stage role codes can also be entered as new external role codes
- Human stages, condition stages, agent stages and end stages
- Sequential workflows and parallel approval
- Parallel approval rules: All, Any, Minimum (N-of-M) and Single
- Configurable actions and transitions (Submit, Approve, Reject, Verify, Query, Return, etc.)
- Stage-configured editable questionnaire fields; workflow stages decide which dynamic fields the assigned user may update before acting
- Authorized reassignment of pending work items to another role/user, with audit
- Assignment rules based on alert or dynamic-template fields
- Per-stage SLA due date on work items
- Branch/role/user based visibility and separate workflow-action authorization
- Dashboard aging matrix: templates/alert types as rows; aging buckets as columns
- Click dashboard count -> filtered server-paginated list -> record detail -> role-allowed action
- Overall aging and current-stage aging
- Dynamic list filters and server-side pagination
- Customer ID / Account ID encryption at rest and masking; sensitive template fields are masked by default, with configurable password-verified reveal
- Bulk CSV alert upload
- Versioned attachments with SHA-256 hash and audited download/upload
- Query/clarification workflow support
- Append-oriented audit trail for authentication, alert creation/view, PI unmask view, workflow stage/action, agent decision, template/workflow changes and attachments
- Optional deterministic, hybrid or agentic execution mode per template
- Existing ERP/workflow UI remains primary; an optional permission-controlled read-only CATS Assistant ChatBox can be enabled independently

## Quick start - SQL Server LocalDB

Prerequisites:

1. .NET 9 SDK
2. SQL Server LocalDB (Visual Studio/SQL Server Express LocalDB) or change the connection string to a SQL Server instance
3. Internet access for first NuGet restore, unless the required NuGet packages are already available in your package cache/internal feed. Bootstrap and jQuery are bundled locally in `wwwroot/lib`.

From the solution folder:

```powershell
./scripts/build.ps1
./scripts/run.ps1
```

Then open:

```text
http://localhost:7000
```

The gateway listens on `7000`; the application listens on `7001`.

The read-only MCP server listens on `9000` and exposes Streamable HTTP at
`http://127.0.0.1:9000/mcp`. `scripts/run.ps1` starts CATS App, Gateway, and
MCP Server together; `scripts/stop.ps1` stops all three. Visual Studio also
includes the shared `CATS with MCP` multi-project launch profile.

Routing is selected in `src/CATS.McpServer/appsettings.json`:

- `CatsApi:UseGateway=true` sends tool requests through the gateway on port `7000`.
- `CatsApi:UseGateway=false` sends tool requests directly to the API on port `7001` and requires `GatewaySharedKey` when gateway-only API access is enabled.
- `McpServer:Enabled` controls whether the `/mcp` endpoint is exposed.
- `Assistant:EnableApprovedMcpTools` in `CATS.App` controls whether the Assistant can call tools listed in `ApprovedReadOnlyTools`.

Supply `CatsApi:UserName`, `CatsApi:Password`, and `CatsApi:GatewaySharedKey` through environment variables or a secret store in production; do not place production credentials in source control.

The application automatically creates the CATS database when using SQL Server and `DatabaseStartup:AutoInitialize=true`. For PostgreSQL/Oracle, create the database/schema first and CATS will create its tables.

### Initial local users

All initial users use password `Cats@1234`:

| User | Role | Purpose |
|---|---|---|
| `admin` | ADMIN | administration/full access |
| `central` | CENTRAL | template/workflow/upload/global monitoring |
| `dtuser` | DT_USER | input/submit role |
| `checker` | DT_CHECKER | checking/approval role |
| `verifier` | DT_VERIFIER | verification role |
| `auditor` | AUDITOR | global read/audit |

**Change/remove the seeded users and rotate all keys before production deployment.**

## Database provider selection

Edit `src/CATS.App/appsettings.json` or use environment variables/secrets.

### SQL Server

```json
"Database": {
  "Provider": "SqlServer",
  "ConnectionString": "Server=.;Database=CATS;Trusted_Connection=True;TrustServerCertificate=True;Encrypt=True"
}
```

### PostgreSQL

```json
"Database": {
  "Provider": "PostgreSql",
  "ConnectionString": "Host=localhost;Port=5432;Database=cats;Username=cats;Password=CHANGE_ME"
}
```

Create the `cats` database first. CATS executes `db/postgresql/schema.sql` at startup.

### Oracle

```json
"Database": {
  "Provider": "Oracle",
  "ConnectionString": "User Id=CATS;Password=CHANGE_ME;Data Source=localhost:1521/FREEPDB1"
}
```

Create/provision the Oracle user/schema first. CATS executes `db/oracle/schema.sql` at startup. Oracle commands use `BindByName=true` in the shared ADO helper.

## Security configuration

Do not use the sample keys in production.

Recommended environment variables:

```text
Security__DataEncryptionKeyBase64=<32-byte random key encoded as base64>
Jwt__SigningKey=<minimum 32-byte high-entropy signing secret>
Database__ConnectionString=<secret connection string>
```

Generate a 32-byte encryption key in PowerShell:

```powershell
[Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
```

The API performs masking/authorization; the browser is not trusted to enforce PI security.

## Microsoft Agent Framework / Gemini

Agent stages are optional. CATS works with `Agent:Enabled=false` in deterministic mode.

For a Gemini OpenAI-compatible endpoint:

```json
"Agent": {
  "Enabled": true,
  "Provider": "OpenAICompatible",
  "Endpoint": "https://generativelanguage.googleapis.com/v1beta/openai/",
  "Model": "gemini-2.5-flash",
  "ApiKey": "YOUR_KEY"
}
```

In `Deterministic` template mode, an Agent stage uses its configured fallback action. In `Hybrid`/`Agentic` mode with the agent enabled, MAF executes the constrained agent stage and validates that the returned action is one of the stage transitions.

## Dynamic workflow model

The workflow is stored as JSON, not compiled into fixed Maker/Checker code. A stage specifies:

- ID/name/type
- role code
- allowed actions
- action transitions
- SLA hours
- parallel approvers and approval rule
- condition routes/default route
- optional agent instructions/fallback
- optional end status
- editable field list (`["*"]` for all non-sensitive template fields, or explicit field keys; empty means read-only)

Example:

```text
DT User (Submit)
        |
        v
Parallel Review
  +-----+------+
  |            |
Checker      Verifier
  +-----+------+
        |
      ALL approve
        |
        v
      Closed
```

See `docs/WORKFLOW-CONFIG.md`.

## Dashboard pattern

CATS uses the required operating model:

```text
Dashboard Aging Matrix
        |
        | click count
        v
Filtered Alert List
        |
        | click row
        v
Dynamic Alert Detail
        |
        v
Allowed actions for logged-in role/user
        |
        v
Workflow engine -> Audit -> Next stage
```

The aging matrix uses current-stage aging so it highlights where work is stuck. The list also returns overall aging.

## Bulk upload

Use `samples/alerts.csv` as the format. `DataJson` contains template-specific values.

## Solution layout

```text
CATS.sln
src/
  CATS.Core/            domain models/interfaces
  CATS.Infrastructure/  ADO.NET, provider dialects, repository, bootstrap, security
  CATS.Workflow/        dynamic engine, assignment rules, MAF integration
  CATS.App/             MVC/REST/JWT/jQuery/Bootstrap application
  CATS.Gateway/         YARP API gateway + rate limit/security headers
db/
  sqlserver/
  postgresql/
  oracle/
docs/
samples/
scripts/
```

## Build and verification

```powershell
dotnet restore CATS.sln
dotnet build CATS.sln -c Release
```

After starting both processes, run:

```powershell
./scripts/smoke-test.ps1
```

The smoke test performs an end-to-end seeded workflow: create alert as Admin, submit stage data as DT User, approve as Checker, approve as Verifier, assert the alert is Closed, and confirm audit records exist.

See `docs/BUILD-VERIFICATION.md` for verification commands and environment notes.

## Production deployment checklist

Before a production rollout:

- Replace development JWT/encryption secrets and seeded credentials.
- Configure HTTPS/TLS at gateway/load balancer and set `RequireHttpsMetadata` as appropriate for your identity architecture.
- Integrate enterprise identity/SSO if required instead of local seeded users.
- Restrict forwarded proxies/networks to your actual proxy topology.
- Host jQuery/Bootstrap internally for air-gapped deployments.
- Configure centralized structured logs, SIEM forwarding and retention.
- Set database backup/HA, connection pooling and least-privilege DB account policies.
- Put attachment storage on approved durable/object storage if local disk is not suitable.
- Add antivirus/content scanning for uploaded files according to organizational policy.
- Review PI masking and authorization rules with information-security/compliance teams.
- Run load, concurrency, penetration, DR and UAT testing for your production transaction volumes.


## CATS V2 additions
- Database-driven role permissions and data scopes; removed hard-coded ADMIN/CENTRAL business bypasses.
- Role-configurable dashboard widgets including Active Alerts, Templates/Alert Types, 31+ Days and Ingestion Failure.
- Generic ingestion configuration, connectors, staging, run/error monitoring and common SQL Server ingestion procedure.
- Existing manual CSV/single-entry retained; .NET 9 Windows Service host added for SFTP/file-area/FC Query scheduling.
- Reports menu backend for MIS, Alert Wise and All Alerts.
- Deterministic mail configuration/templates/queue with optional MAF enrichment flag.


## Optional AI Query Assistant

CATS includes an additive MAF-backed AI query drafting option for the existing Alert Detail Query workflow. It is disabled by default and does not alter manual query behaviour. See `docs/AI-QUERY-ASSISTANT.md`.

See [PI and user appearance](docs/PI-and-user-appearance.md) for field configuration, themes, layouts, and the permission upgrade.
