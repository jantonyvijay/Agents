CREATE TABLE IF NOT EXISTS CatsUsers(
 Id varchar(32) PRIMARY KEY, UserName varchar(100) NOT NULL UNIQUE, DisplayName varchar(200) NOT NULL,
 PasswordHash varchar(500) NOT NULL, RoleCode varchar(60) NOT NULL, DepartmentCode varchar(60) NOT NULL,
 BranchCode varchar(60) NOT NULL, PermissionsJson text NOT NULL, IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS Templates(
 Id varchar(32) PRIMARY KEY, Code varchar(80) NOT NULL, Name varchar(250) NOT NULL, Version integer NOT NULL,
 Status varchar(30) NOT NULL, ExecutionMode varchar(30) NOT NULL, SectionsJson text NOT NULL, FieldsJson text NOT NULL,
 AssignmentRulesJson text NOT NULL, ViewConfigurationJson text NOT NULL DEFAULT '{}', PublishedWorkflowId varchar(32), CreatedAtUtc timestamp NOT NULL, CreatedBy varchar(100) NOT NULL,
 UNIQUE(Code,Version));
CREATE TABLE IF NOT EXISTS WorkflowDefinitions(
 Id varchar(32) PRIMARY KEY, TemplateId varchar(32) NOT NULL REFERENCES Templates(Id), Version integer NOT NULL, Name varchar(250) NOT NULL,
 DefinitionJson text NOT NULL, IsPublished integer NOT NULL DEFAULT 0, CreatedAtUtc timestamp NOT NULL, CreatedBy varchar(100) NOT NULL,
 UNIQUE(TemplateId,Version));
CREATE TABLE IF NOT EXISTS Alerts(
 Id varchar(32) PRIMARY KEY, AlertNo varchar(60) NOT NULL UNIQUE, TemplateId varchar(32) NOT NULL REFERENCES Templates(Id), TemplateVersion integer NOT NULL,
 AlertType varchar(150) NOT NULL, BranchCode varchar(60) NOT NULL, CustomerIdEncrypted text NOT NULL, AccountIdEncrypted text NOT NULL,
 DynamicDataJson text NOT NULL, Status varchar(30) NOT NULL, CurrentStageId varchar(100) NOT NULL, CurrentStageName varchar(200) NOT NULL,
 CreatedAtUtc timestamp NOT NULL, StageEnteredAtUtc timestamp NOT NULL, CreatedBy varchar(100) NOT NULL, Priority varchar(30) NOT NULL);
CREATE TABLE IF NOT EXISTS WorkflowInstances(
 Id varchar(32) PRIMARY KEY, AlertId varchar(32) NOT NULL REFERENCES Alerts(Id), WorkflowDefinitionId varchar(32) NOT NULL REFERENCES WorkflowDefinitions(Id),
 WorkflowVersion integer NOT NULL, Status varchar(30) NOT NULL, CurrentStageId varchar(100) NOT NULL, StartedAtUtc timestamp NOT NULL, UpdatedAtUtc timestamp NOT NULL);
CREATE TABLE IF NOT EXISTS WorkItems(
 Id varchar(32) PRIMARY KEY, AlertId varchar(32) NOT NULL REFERENCES Alerts(Id), WorkflowInstanceId varchar(32) NOT NULL REFERENCES WorkflowInstances(Id),
 StageId varchar(100) NOT NULL, StageName varchar(200) NOT NULL, AssignedRoleCode varchar(60) NOT NULL, AssignedBranchCode varchar(60) NOT NULL DEFAULT '', AssignedUserId varchar(32), Status varchar(30) NOT NULL,
 ParallelGroupId varchar(32), CompletedAction varchar(60), CompletedBy varchar(100), CreatedAtUtc timestamp NOT NULL, DueAtUtc timestamp NOT NULL,
 CompletedAtUtc timestamp, Remarks text);
CREATE TABLE IF NOT EXISTS AlertQueries(
 Id varchar(32) PRIMARY KEY, AlertId varchar(32) NOT NULL REFERENCES Alerts(Id), RaisedBy varchar(100) NOT NULL, RaisedToRole varchar(60) NOT NULL,
 QueryText text NOT NULL, ResponseText text, Status varchar(30) NOT NULL, RaisedAtUtc timestamp NOT NULL, RespondedAtUtc timestamp);
CREATE TABLE IF NOT EXISTS Attachments(
 Id varchar(32) PRIMARY KEY, AlertId varchar(32) NOT NULL REFERENCES Alerts(Id), StageId varchar(100) NOT NULL, FileName varchar(260) NOT NULL,
 StoredName varchar(100) NOT NULL, ContentType varchar(150) NOT NULL, FileSize bigint NOT NULL, Sha256 varchar(64) NOT NULL,
 Version integer NOT NULL, UploadedBy varchar(100) NOT NULL, UploadedAtUtc timestamp NOT NULL);
CREATE TABLE IF NOT EXISTS AuditLog(
 Id varchar(32) PRIMARY KEY, AlertId varchar(32), UserId varchar(32) NOT NULL, UserName varchar(100) NOT NULL, RoleCode varchar(60) NOT NULL,
 Action varchar(80) NOT NULL, EntityType varchar(80) NOT NULL, EntityId varchar(32), StageId varchar(100), PreviousValueJson text, NewValueJson text,
 Remarks text, IpAddress varchar(100), CreatedAtUtc timestamp NOT NULL);
CREATE TABLE IF NOT EXISTS AgingBuckets(
 Id varchar(32) PRIMARY KEY, Name varchar(60) NOT NULL UNIQUE, FromDays integer NOT NULL, ToDays integer, DisplayOrder integer NOT NULL, IsActive integer NOT NULL DEFAULT 1);
CREATE INDEX IF NOT EXISTS IX_Alerts_StageEntered ON Alerts(StageEnteredAtUtc,Status,TemplateId);
CREATE INDEX IF NOT EXISTS IX_WorkItems_Assignment ON WorkItems(Status,AssignedRoleCode,AssignedBranchCode,AssignedUserId,AlertId);
CREATE INDEX IF NOT EXISTS IX_Audit_Alert ON AuditLog(AlertId,CreatedAtUtc DESC);
CREATE UNIQUE INDEX IF NOT EXISTS UX_WorkflowInstances_Alert ON WorkflowInstances(AlertId);

-- CATS V2 platform tables
CREATE TABLE IF NOT EXISTS RoleMaster(Code varchar(60) PRIMARY KEY,Name varchar(150) NOT NULL,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS PermissionMaster(Code varchar(100) PRIMARY KEY,Name varchar(200) NOT NULL,Category varchar(60) NOT NULL,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS RolePermissionMapping(RoleCode varchar(60) NOT NULL,PermissionCode varchar(100) NOT NULL,IsActive integer NOT NULL DEFAULT 1,PRIMARY KEY(RoleCode,PermissionCode));
CREATE TABLE IF NOT EXISTS UserPermissionMapping(UserId varchar(32) NOT NULL,PermissionCode varchar(100) NOT NULL,IsActive integer NOT NULL DEFAULT 1,PRIMARY KEY(UserId,PermissionCode));
CREATE TABLE IF NOT EXISTS DataScopeMaster(Id varchar(32) PRIMARY KEY,RoleCode varchar(60) NOT NULL,ScopeType varchar(30) NOT NULL,ScopeValue varchar(150) NOT NULL DEFAULT '',Priority integer NOT NULL DEFAULT 100,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS DashboardWidgetMaster(Id varchar(32) PRIMARY KEY,Code varchar(80) UNIQUE NOT NULL,Title varchar(150) NOT NULL,WidgetType varchar(30) NOT NULL,PermissionCode varchar(100) NOT NULL DEFAULT '',FilterJson text NOT NULL DEFAULT '{}',DrillDownUrl varchar(500) NOT NULL DEFAULT '',DisplayOrder integer NOT NULL DEFAULT 1,Width integer NOT NULL DEFAULT 3,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS DashboardWidgetRoleMapping(WidgetId varchar(32) NOT NULL,RoleCode varchar(60) NOT NULL,DisplayOrder integer NOT NULL DEFAULT 1,Width integer NOT NULL DEFAULT 3,IsVisible integer NOT NULL DEFAULT 1,PRIMARY KEY(WidgetId,RoleCode));
CREATE TABLE IF NOT EXISTS IngestionConnector(Id varchar(32) PRIMARY KEY,Name varchar(150) NOT NULL,ConnectorType varchar(30) NOT NULL,Host varchar(300) NOT NULL DEFAULT '',Port integer NOT NULL DEFAULT 0,DatabaseName varchar(200) NOT NULL DEFAULT '',UserName varchar(200) NOT NULL DEFAULT '',SecretEncrypted text NOT NULL DEFAULT '',ExtraJson text NOT NULL DEFAULT '{}',IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS IngestionConfiguration(Id varchar(32) PRIMARY KEY,Name varchar(150) NOT NULL,TemplateId varchar(32) NOT NULL,SourceType varchar(30) NOT NULL,ConnectorId varchar(32),FilePath varchar(500) NOT NULL DEFAULT '',FileName varchar(260) NOT NULL DEFAULT '',FilePattern varchar(260) NOT NULL DEFAULT '',ScheduleTriggersJson text NOT NULL DEFAULT '[]',ScheduleCron varchar(100) NOT NULL DEFAULT '',QueryText text NOT NULL DEFAULT '',FieldMappingJson text NOT NULL DEFAULT '{}',DuplicateKeyFields varchar(500) NOT NULL DEFAULT '',ArchivePath varchar(500) NOT NULL DEFAULT '',ErrorPath varchar(500) NOT NULL DEFAULT '',IntervalMinutes integer NOT NULL DEFAULT 1,IsActive integer NOT NULL DEFAULT 1);
ALTER TABLE IngestionConfiguration ADD COLUMN IF NOT EXISTS FilePath varchar(500) NOT NULL DEFAULT '';
ALTER TABLE IngestionConfiguration ADD COLUMN IF NOT EXISTS FileName varchar(260) NOT NULL DEFAULT '';
ALTER TABLE IngestionConfiguration ADD COLUMN IF NOT EXISTS ScheduleTriggersJson text NOT NULL DEFAULT '[]';
CREATE TABLE IF NOT EXISTS IngestionRun(Id varchar(32) PRIMARY KEY,ConfigurationId varchar(32) NOT NULL,SourceReference varchar(500) NOT NULL DEFAULT '',StartedAtUtc timestamp NOT NULL,EndedAtUtc timestamp,RowsRead integer NOT NULL DEFAULT 0,RowsInserted integer NOT NULL DEFAULT 0,RowsDuplicate integer NOT NULL DEFAULT 0,RowsFailed integer NOT NULL DEFAULT 0,Status varchar(30) NOT NULL,ErrorMessage text);
CREATE TABLE IF NOT EXISTS IngestionStaging(Id bigserial PRIMARY KEY,RunId varchar(32) NOT NULL,RowNo integer NOT NULL,TemplateId varchar(32) NOT NULL,AlertType varchar(150) NOT NULL,BranchCode varchar(60) NOT NULL,CustomerIdEncrypted text NOT NULL,AccountIdEncrypted text NOT NULL,Priority varchar(30) NOT NULL,DynamicDataJson text NOT NULL,DedupKey varchar(500) NOT NULL DEFAULT '',ProcessStatus varchar(30) NOT NULL DEFAULT 'Pending',ErrorMessage text);
CREATE TABLE IF NOT EXISTS MailConfiguration(Id varchar(32) PRIMARY KEY,Name varchar(150) NOT NULL,ProviderType varchar(30) NOT NULL,Host varchar(300) NOT NULL,Port integer NOT NULL,UserName varchar(200) NOT NULL DEFAULT '',SecretEncrypted text NOT NULL DEFAULT '',FromAddress varchar(300) NOT NULL,UseSsl integer NOT NULL DEFAULT 1,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS MailTemplate(Id varchar(32) PRIMARY KEY,EventCode varchar(80) UNIQUE NOT NULL,SubjectTemplate varchar(500) NOT NULL,BodyTemplate text NOT NULL,UseMafEnrichment integer NOT NULL DEFAULT 0,IsActive integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS MailQueue(Id varchar(32) PRIMARY KEY,EventCode varchar(80) NOT NULL,AlertId varchar(32),ToAddress text NOT NULL,CcAddress text,Subject varchar(500) NOT NULL,Body text NOT NULL,Status varchar(30) NOT NULL DEFAULT 'Pending',Attempts integer NOT NULL DEFAULT 0,NextAttemptAtUtc timestamp NOT NULL,CreatedAtUtc timestamp NOT NULL,SentAtUtc timestamp,ErrorMessage text);

CREATE TABLE IF NOT EXISTS TemplateDashboardMaster(Id varchar(32) PRIMARY KEY,Code varchar(80) UNIQUE NOT NULL,Name varchar(150) NOT NULL,Title varchar(250) NOT NULL,Description varchar(1000) NOT NULL DEFAULT '',TemplateId varchar(32) NOT NULL,AlertType varchar(150) NOT NULL DEFAULT '',GroupByFieldsJson text NOT NULL DEFAULT '["BranchCode"]',MetricsJson text NOT NULL DEFAULT '[]',GridColumnsJson text NOT NULL DEFAULT '[]',SearchFieldsJson text NOT NULL DEFAULT '["AlertNo","AccountId","CustomerId"]',PageSize integer NOT NULL DEFAULT 20,DisplayOrder integer NOT NULL DEFAULT 1,IsDefault integer NOT NULL DEFAULT 0,IsActive integer NOT NULL DEFAULT 1,CreatedAtUtc timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,UpdatedAtUtc timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS TemplateDashboardRoleMapping(DashboardId varchar(32) NOT NULL,RoleCode varchar(60) NOT NULL,IsVisible integer NOT NULL DEFAULT 1,PRIMARY KEY(DashboardId,RoleCode));

ALTER TABLE Templates ADD COLUMN IF NOT EXISTS ViewConfigurationJson text NOT NULL DEFAULT '{}';
