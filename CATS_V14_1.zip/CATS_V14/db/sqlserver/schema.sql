IF OBJECT_ID('dbo.CatsUsers','U') IS NULL
CREATE TABLE dbo.CatsUsers(
 Id varchar(32) NOT NULL PRIMARY KEY, UserName varchar(100) NOT NULL UNIQUE, DisplayName nvarchar(200) NOT NULL,
 PasswordHash varchar(500) NOT NULL, RoleCode varchar(60) NOT NULL, DepartmentCode varchar(60) NOT NULL,
 BranchCode varchar(60) NOT NULL, PermissionsJson nvarchar(max) NOT NULL, IsActive int NOT NULL DEFAULT 1
);
GO
IF OBJECT_ID('dbo.Templates','U') IS NULL
CREATE TABLE dbo.Templates(
 Id varchar(32) NOT NULL PRIMARY KEY, Code varchar(80) NOT NULL, Name nvarchar(250) NOT NULL, Version int NOT NULL,
 Status varchar(30) NOT NULL, ExecutionMode varchar(30) NOT NULL, SectionsJson nvarchar(max) NOT NULL,
 FieldsJson nvarchar(max) NOT NULL, AssignmentRulesJson nvarchar(max) NOT NULL, ViewConfigurationJson nvarchar(max) NOT NULL CONSTRAINT DF_Templates_ViewConfigurationJson DEFAULT N'{}', PublishedWorkflowId varchar(32) NULL,
 CreatedAtUtc datetime2 NOT NULL, CreatedBy varchar(100) NOT NULL,
 CONSTRAINT UQ_Templates_CodeVersion UNIQUE(Code,Version)
);
GO
IF COL_LENGTH('dbo.Templates','ViewConfigurationJson') IS NULL
    ALTER TABLE dbo.Templates ADD ViewConfigurationJson nvarchar(max) NOT NULL CONSTRAINT DF_Templates_ViewConfigurationJson_V9 DEFAULT N'{}' WITH VALUES;
GO
IF OBJECT_ID('dbo.WorkflowDefinitions','U') IS NULL
CREATE TABLE dbo.WorkflowDefinitions(
 Id varchar(32) NOT NULL PRIMARY KEY, TemplateId varchar(32) NOT NULL, Version int NOT NULL, Name nvarchar(250) NOT NULL,
 DefinitionJson nvarchar(max) NOT NULL, IsPublished int NOT NULL DEFAULT 0, CreatedAtUtc datetime2 NOT NULL, CreatedBy varchar(100) NOT NULL,
 CONSTRAINT FK_Workflow_Template FOREIGN KEY(TemplateId) REFERENCES dbo.Templates(Id),
 CONSTRAINT UQ_Workflow_TemplateVersion UNIQUE(TemplateId,Version)
);
GO
IF OBJECT_ID('dbo.Alerts','U') IS NULL
CREATE TABLE dbo.Alerts(
 Id varchar(32) NOT NULL PRIMARY KEY, AlertNo varchar(60) NOT NULL UNIQUE, TemplateId varchar(32) NOT NULL, TemplateVersion int NOT NULL,
 AlertType nvarchar(150) NOT NULL, BranchCode varchar(60) NOT NULL, CustomerIdEncrypted nvarchar(1000) NOT NULL,
 AccountIdEncrypted nvarchar(1000) NOT NULL, DynamicDataJson nvarchar(max) NOT NULL, Status varchar(30) NOT NULL,
 CurrentStageId varchar(100) NOT NULL, CurrentStageName nvarchar(200) NOT NULL, CreatedAtUtc datetime2 NOT NULL,
 StageEnteredAtUtc datetime2 NOT NULL, CreatedBy varchar(100) NOT NULL, Priority varchar(30) NOT NULL,
 CONSTRAINT FK_Alerts_Template FOREIGN KEY(TemplateId) REFERENCES dbo.Templates(Id)
);
GO
IF OBJECT_ID('dbo.WorkflowInstances','U') IS NULL
CREATE TABLE dbo.WorkflowInstances(
 Id varchar(32) NOT NULL PRIMARY KEY, AlertId varchar(32) NOT NULL, WorkflowDefinitionId varchar(32) NOT NULL,
 WorkflowVersion int NOT NULL, Status varchar(30) NOT NULL, CurrentStageId varchar(100) NOT NULL,
 StartedAtUtc datetime2 NOT NULL, UpdatedAtUtc datetime2 NOT NULL,
 CONSTRAINT FK_Instance_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id),
 CONSTRAINT FK_Instance_Workflow FOREIGN KEY(WorkflowDefinitionId) REFERENCES dbo.WorkflowDefinitions(Id)
);
GO
IF OBJECT_ID('dbo.WorkItems','U') IS NULL
CREATE TABLE dbo.WorkItems(
 Id varchar(32) NOT NULL PRIMARY KEY, AlertId varchar(32) NOT NULL, WorkflowInstanceId varchar(32) NOT NULL,
 StageId varchar(100) NOT NULL, StageName nvarchar(200) NOT NULL, AssignedRoleCode varchar(60) NOT NULL,
 AssignedBranchCode varchar(60) NOT NULL DEFAULT '', AssignedUserId varchar(32) NULL, Status varchar(30) NOT NULL, ParallelGroupId varchar(32) NULL,
 CompletedAction varchar(60) NULL, CompletedBy varchar(100) NULL, CreatedAtUtc datetime2 NOT NULL,
 DueAtUtc datetime2 NOT NULL, CompletedAtUtc datetime2 NULL, Remarks nvarchar(2000) NULL,
 CONSTRAINT FK_WorkItem_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id),
 CONSTRAINT FK_WorkItem_Instance FOREIGN KEY(WorkflowInstanceId) REFERENCES dbo.WorkflowInstances(Id)
);
GO
IF OBJECT_ID('dbo.AlertQueries','U') IS NULL
CREATE TABLE dbo.AlertQueries(
 Id varchar(32) NOT NULL PRIMARY KEY, AlertId varchar(32) NOT NULL, RaisedBy varchar(100) NOT NULL,
 RaisedToRole varchar(60) NOT NULL, QueryText nvarchar(3000) NOT NULL, ResponseText nvarchar(3000) NULL,
 Status varchar(30) NOT NULL, RaisedAtUtc datetime2 NOT NULL, RespondedAtUtc datetime2 NULL,
 CONSTRAINT FK_Query_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id)
);
GO
IF OBJECT_ID('dbo.Attachments','U') IS NULL
CREATE TABLE dbo.Attachments(
 Id varchar(32) NOT NULL PRIMARY KEY, AlertId varchar(32) NOT NULL, StageId varchar(100) NOT NULL,
 FileName nvarchar(260) NOT NULL, StoredName varchar(100) NOT NULL, ContentType varchar(150) NOT NULL,
 FileSize bigint NOT NULL, Sha256 varchar(64) NOT NULL, Version int NOT NULL, UploadedBy varchar(100) NOT NULL,
 UploadedAtUtc datetime2 NOT NULL, CONSTRAINT FK_Attachment_Alert FOREIGN KEY(AlertId) REFERENCES dbo.Alerts(Id)
);
GO
IF OBJECT_ID('dbo.AuditLog','U') IS NULL
CREATE TABLE dbo.AuditLog(
 Id varchar(32) NOT NULL PRIMARY KEY, AlertId varchar(32) NULL, UserId varchar(32) NOT NULL, UserName varchar(100) NOT NULL,
 RoleCode varchar(60) NOT NULL, Action varchar(80) NOT NULL, EntityType varchar(80) NOT NULL, EntityId varchar(32) NULL,
 StageId varchar(100) NULL, PreviousValueJson nvarchar(max) NULL, NewValueJson nvarchar(max) NULL, Remarks nvarchar(2000) NULL,
 IpAddress varchar(100) NULL, CreatedAtUtc datetime2 NOT NULL
);
GO
IF OBJECT_ID('dbo.AgingBuckets','U') IS NULL
CREATE TABLE dbo.AgingBuckets(
 Id varchar(32) NOT NULL PRIMARY KEY, Name varchar(60) NOT NULL UNIQUE, FromDays int NOT NULL, ToDays int NULL,
 DisplayOrder int NOT NULL, IsActive int NOT NULL DEFAULT 1
);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name='IX_Alerts_StageEntered') CREATE INDEX IX_Alerts_StageEntered ON dbo.Alerts(StageEnteredAtUtc,Status,TemplateId);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name='IX_WorkItems_Assignment') CREATE INDEX IX_WorkItems_Assignment ON dbo.WorkItems(Status,AssignedRoleCode,AssignedBranchCode,AssignedUserId,AlertId);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name='IX_Audit_Alert') CREATE INDEX IX_Audit_Alert ON dbo.AuditLog(AlertId,CreatedAtUtc DESC);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name='UX_WorkflowInstances_Alert') CREATE UNIQUE INDEX UX_WorkflowInstances_Alert ON dbo.WorkflowInstances(AlertId);
GO

/*
  Common repository entry point for SQL Server.

  Contract:
    - @Operation is an ICatsRepository method name without the Async suffix.
    - @JsonInput is a JSON object whose properties use camelCase.
    - Read operations preserve the column names consumed by CatsRepository.
    - Write operations return one row with AffectedRows, except SaveTemplate and
      SaveWorkflow, which return the saved record. TryClaimStageTransition also
      returns Claimed. SQL validation/concurrency failures are raised with THROW.
*/
/* CATS V4 - Common dispatcher and core repository modules */

/* =====================================================================================
   CATS V4 - Common repository dispatcher
   ADO.NET calls only this procedure. It resolves:
       USP_<ModuleCode>_<MethodCode>
   Every leaf procedure accepts exactly one input parameter:
       @strJson nvarchar(max)
   ===================================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_CommonRepository
    @ModuleCode nvarchar(60) = NULL,
    @MethodCode nvarchar(80),
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @ModuleCode = LTRIM(RTRIM(COALESCE(@ModuleCode,N'')));
    SET @MethodCode = LTRIM(RTRIM(COALESCE(@MethodCode,N'')));
    SET @strJson = COALESCE(@strJson,N'{}');

    IF @MethodCode = N''
        THROW 50000, 'Invalid method.', 1;

    IF ISJSON(@strJson) <> 1
        THROW 50001, 'strJson must be valid JSON.', 1;

    -- Only simple identifier characters are allowed. This protects the dynamic EXEC.
    IF (@ModuleCode <> N'' AND PATINDEX(N'%[^A-Za-z0-9_]%', @ModuleCode COLLATE Latin1_General_100_BIN2) > 0)
       OR PATINDEX(N'%[^A-Za-z0-9_]%', @MethodCode COLLATE Latin1_General_100_BIN2) > 0
        THROW 50002, 'Invalid module or method code.', 1;

    DECLARE @procName sysname =
        CASE WHEN @ModuleCode = N''
             THEN N'USP_' + @MethodCode
             ELSE N'USP_' + @ModuleCode + N'_' + @MethodCode
        END;

    IF OBJECT_ID(N'dbo.' + @procName, N'P') IS NULL
        THROW 50003, 'Unsupported repository operation.', 1;

    DECLARE @sql nvarchar(max) =
        N'EXEC dbo.' + QUOTENAME(@procName) + N' @strJson = @JSON;';

    EXEC sys.sp_executesql
        @sql,
        N'@JSON nvarchar(max)',
        @JSON = @strJson;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_User_GetByUserName
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive
        FROM dbo.CatsUsers
        WHERE UPPER(UserName)=UPPER(@UserName);
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_User_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive
        FROM dbo.CatsUsers
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_User_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive
        FROM dbo.CatsUsers
        ORDER BY UserName;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_User_Upsert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        IF COALESCE(@IsNew,0)=1
        BEGIN
            INSERT INTO dbo.CatsUsers(Id,UserName,DisplayName,PasswordHash,RoleCode,DepartmentCode,BranchCode,PermissionsJson,IsActive)
            VALUES(@Id,@UserName,@DisplayName,@PasswordHash,@RoleCode,@DepartmentCode,@BranchCode,@PermissionsJson,CASE WHEN @IsActive=1 THEN 1 ELSE 0 END);
            SET @AffectedRows=@@ROWCOUNT;
        END
        ELSE
        BEGIN
            UPDATE dbo.CatsUsers
            SET UserName=@UserName,DisplayName=@DisplayName,PasswordHash=@PasswordHash,RoleCode=@RoleCode,
                DepartmentCode=@DepartmentCode,BranchCode=@BranchCode,PermissionsJson=@PermissionsJson,
                IsActive=CASE WHEN @IsActive=1 THEN 1 ELSE 0 END
            WHERE Id=@Id;
            SET @AffectedRows=@@ROWCOUNT;
        END;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
               PublishedWorkflowId,CreatedAtUtc,CreatedBy
        FROM dbo.Templates
        ORDER BY Name,Version DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
               PublishedWorkflowId,CreatedAtUtc,CreatedBy
        FROM dbo.Templates
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        IF NULLIF(LTRIM(RTRIM(@Id)), '') IS NOT NULL
        BEGIN
            IF NOT EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id)
                THROW 50003, 'The template to update was not found.', 1;
            IF EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id AND Status='Retired')
                THROW 50004, 'Retired templates cannot be modified.', 1;

            UPDATE dbo.Templates
            SET Code=@Code,Name=@Name,ExecutionMode=@ExecutionMode,SectionsJson=@SectionsJson,
                FieldsJson=@FieldsJson,AssignmentRulesJson=COALESCE(@AssignmentRulesJson,N'[]')
            WHERE Id=@Id;
            SET @NewId=CONVERT(varchar(32),@Id);
        END
        ELSE
        BEGIN
            SELECT @NextVersion=COALESCE(MAX(Version),0)+1
            FROM dbo.Templates
            WHERE UPPER(Code)=UPPER(@Code);

            SET @NewId=LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-',''));
            INSERT INTO dbo.Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,
                                      AssignmentRulesJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy)
            VALUES(@NewId,@Code,@Name,@NextVersion,'Draft',@ExecutionMode,@SectionsJson,@FieldsJson,
                   COALESCE(@AssignmentRulesJson,N'[]'),NULL,@NowUtc,@CreatedBy);
        END;

        SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
               PublishedWorkflowId,CreatedAtUtc,CreatedBy
        FROM dbo.Templates
        WHERE Id=@NewId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Workflow_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy
        FROM dbo.WorkflowDefinitions
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Workflow_GetPublishedByTemplate
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT TOP (1) Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy
        FROM dbo.WorkflowDefinitions
        WHERE TemplateId=@TemplateId AND IsPublished=1
        ORDER BY Version DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Workflow_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        BEGIN TRY
            BEGIN TRANSACTION;

            SELECT @NextVersion=COALESCE(MAX(Version),0)+1
            FROM dbo.WorkflowDefinitions
            WHERE TemplateId=@TemplateId;

            SET @NewId=LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-',''));

            IF COALESCE(@Publish,0)=1
                UPDATE dbo.WorkflowDefinitions SET IsPublished=0 WHERE TemplateId=@TemplateId;

            INSERT INTO dbo.WorkflowDefinitions(Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy)
            VALUES(@NewId,@TemplateId,@NextVersion,@Name,@DefinitionJson,CASE WHEN @Publish=1 THEN 1 ELSE 0 END,@NowUtc,@CreatedBy);

            IF COALESCE(@Publish,0)=1
            BEGIN
                UPDATE dbo.Templates
                SET Status='Retired'
                WHERE Id<>@TemplateId
                  AND UPPER(Code)=(SELECT UPPER(Code) FROM dbo.Templates WHERE Id=@TemplateId)
                  AND Status='Published';

                UPDATE dbo.Templates
                SET PublishedWorkflowId=@NewId,Status='Published'
                WHERE Id=@TemplateId;
            END;

            COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
            THROW;
        END CATCH;

        SELECT Id,TemplateId,Version,Name,DefinitionJson,IsPublished,CreatedAtUtc,CreatedBy
        FROM dbo.WorkflowDefinitions
        WHERE Id=@NewId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.Alerts(Id,AlertNo,TemplateId,TemplateVersion,AlertType,BranchCode,CustomerIdEncrypted,
                               AccountIdEncrypted,DynamicDataJson,Status,CurrentStageId,CurrentStageName,
                               CreatedAtUtc,StageEnteredAtUtc,CreatedBy,Priority)
        VALUES(@Id,@AlertNo,@TemplateId,@TemplateVersion,@AlertType,@BranchCode,@CustomerIdEncrypted,
               @AccountIdEncrypted,@DynamicDataJson,@Status,@CurrentStageId,@CurrentStageName,
               @CreatedAtUtc,@StageEnteredAtUtc,@CreatedBy,@Priority);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.WorkflowInstances(Id,AlertId,WorkflowDefinitionId,WorkflowVersion,Status,CurrentStageId,StartedAtUtc,UpdatedAtUtc)
        VALUES(@Id,@AlertId,@WorkflowDefinitionId,@WorkflowVersion,@Status,@CurrentStageId,@StartedAtUtc,@UpdatedAtUtc);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_Update
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkflowInstances
        SET Status=@Status,CurrentStageId=@CurrentStageId,UpdatedAtUtc=@UpdatedAtUtc
        WHERE Id=@Id;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_TryClaimStageTransition
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkflowInstances
        SET Status='Transitioning',UpdatedAtUtc=@NowUtc
        WHERE Id=@InstanceId AND Status='Running' AND CurrentStageId=@ExpectedStageId;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT CAST(CASE WHEN @AffectedRows=1 THEN 1 ELSE 0 END AS bit) AS Claimed,
               @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_ReleaseStageTransitionClaim
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkflowInstances
        SET Status='Running',UpdatedAtUtc=@NowUtc
        WHERE Id=@InstanceId AND Status='Transitioning' AND CurrentStageId=@ExpectedStageId;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_UpdateStage
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.Alerts
        SET CurrentStageId=@StageId,CurrentStageName=@StageName,Status=@Status,StageEnteredAtUtc=@EnteredAtUtc
        WHERE Id=@AlertId;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_UpdateDynamicData
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.Alerts SET DynamicDataJson=@DynamicDataJson WHERE Id=@AlertId;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertNo,TemplateId,TemplateVersion,AlertType,BranchCode,CustomerIdEncrypted,
               AccountIdEncrypted,DynamicDataJson,Status,CurrentStageId,CurrentStageName,
               CreatedAtUtc,StageEnteredAtUtc,CreatedBy,Priority
        FROM dbo.Alerts
        WHERE Id=@AlertId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkflowInstance_GetByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowDefinitionId,WorkflowVersion,Status,CurrentStageId,StartedAtUtc,UpdatedAtUtc
        FROM dbo.WorkflowInstances
        WHERE AlertId=@AlertId AND Status='Running';
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.WorkItems(Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,
                                  AssignedBranchCode,AssignedUserId,Status,ParallelGroupId,CompletedAction,
                                  CompletedBy,CreatedAtUtc,DueAtUtc,CompletedAtUtc,Remarks)
        SELECT w.Id,w.AlertId,w.WorkflowInstanceId,w.StageId,w.StageName,w.AssignedRoleCode,
               COALESCE(w.AssignedBranchCode,''),w.AssignedUserId,w.Status,w.ParallelGroupId,
               NULL,NULL,w.CreatedAtUtc,w.DueAtUtc,NULL,NULL
        FROM OPENJSON(@strJson,'$.items')
        WITH
        (
            Id varchar(32) '$.id',
            AlertId varchar(32) '$.alertId',
            WorkflowInstanceId varchar(32) '$.workflowInstanceId',
            StageId varchar(100) '$.stageId',
            StageName nvarchar(200) '$.stageName',
            AssignedRoleCode varchar(60) '$.assignedRoleCode',
            AssignedBranchCode varchar(60) '$.assignedBranchCode',
            AssignedUserId varchar(32) '$.assignedUserId',
            Status varchar(30) '$.status',
            ParallelGroupId varchar(32) '$.parallelGroupId',
            CreatedAtUtc datetime2(7) '$.createdAtUtc',
            DueAtUtc datetime2(7) '$.dueAtUtc'
        ) AS w;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_GetPending
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,
               AssignedUserId,Status,ParallelGroupId,CompletedAction,CompletedBy,CreatedAtUtc,DueAtUtc,
               CompletedAtUtc,Remarks
        FROM dbo.WorkItems
        WHERE AlertId=@AlertId AND Status='Pending'
        ORDER BY CreatedAtUtc;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,
               AssignedUserId,Status,ParallelGroupId,CompletedAction,CompletedBy,CreatedAtUtc,DueAtUtc,
               CompletedAtUtc,Remarks
        FROM dbo.WorkItems
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_GetAllByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,
               AssignedUserId,Status,ParallelGroupId,CompletedAction,CompletedBy,CreatedAtUtc,DueAtUtc,
               CompletedAtUtc,Remarks
        FROM dbo.WorkItems
        WHERE AlertId=@AlertId
        ORDER BY CreatedAtUtc;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_Complete
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkItems
        SET Status='Completed',CompletedAction=@Action,CompletedBy=@CompletedBy,
            CompletedAtUtc=@NowUtc,Remarks=@Remarks
        WHERE Id=@Id AND Status='Pending';
        SET @AffectedRows=@@ROWCOUNT;
        IF @AffectedRows<>1
            THROW 50001, 'Work item has already been completed by another user.', 1;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_ReassignPending
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        IF NULLIF(LTRIM(RTRIM(COALESCE(@RoleCode,''))), '') IS NULL
           AND NULLIF(LTRIM(RTRIM(COALESCE(@UserId,''))), '') IS NULL
            THROW 50002, 'RoleCode or UserId is required for reassignment.', 1;

        UPDATE dbo.WorkItems
        SET AssignedRoleCode=COALESCE(@RoleCode,''),AssignedBranchCode=COALESCE(@BranchCode,''),AssignedUserId=@UserId
        WHERE AlertId=@AlertId AND StageId=@StageId AND Status='Pending';
        SET @AffectedRows=@@ROWCOUNT;
        IF @AffectedRows=0
            THROW 50003, 'No pending work item was found for the selected stage.', 1;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_CancelPending
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        UPDATE dbo.WorkItems
        SET Status='Cancelled'
        WHERE AlertId=@AlertId
          AND Status='Pending'
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@GroupId,''))), '') IS NULL OR ParallelGroupId=@GroupId);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_WorkItem_GetParallel
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,WorkflowInstanceId,StageId,StageName,AssignedRoleCode,AssignedBranchCode,
               AssignedUserId,Status,ParallelGroupId,CompletedAction,CompletedBy,CreatedAtUtc,DueAtUtc,
               CompletedAtUtc,Remarks
        FROM dbo.WorkItems
        WHERE AlertId=@AlertId AND ParallelGroupId=@ParallelGroupId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Query_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.AlertQueries(Id,AlertId,RaisedBy,RaisedToRole,QueryText,ResponseText,Status,RaisedAtUtc,RespondedAtUtc)
        VALUES(@Id,@AlertId,@RaisedBy,@RaisedToRole,@QueryText,NULL,@Status,@RaisedAtUtc,NULL);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Query_RespondLatestOpen
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT TOP (1) @QueryId=Id
        FROM dbo.AlertQueries
        WHERE AlertId=@AlertId AND Status='Open'
        ORDER BY RaisedAtUtc DESC;

        IF @QueryId IS NOT NULL
        BEGIN
            UPDATE dbo.AlertQueries
            SET ResponseText=@ResponseText,Status='Responded',RespondedAtUtc=@NowUtc
            WHERE Id=@QueryId;
            SET @AffectedRows=@@ROWCOUNT;
        END;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Query_GetAllByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,RaisedBy,RaisedToRole,QueryText,ResponseText,Status,RaisedAtUtc,RespondedAtUtc
        FROM dbo.AlertQueries
        WHERE AlertId=@AlertId
        ORDER BY RaisedAtUtc DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Attachment_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.Attachments(Id,AlertId,StageId,FileName,StoredName,ContentType,FileSize,Sha256,Version,UploadedBy,UploadedAtUtc)
        VALUES(@Id,@AlertId,@StageId,@FileName,@StoredName,@ContentType,@FileSize,@Sha256,@Version,@UploadedBy,@UploadedAtUtc);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Attachment_GetAllByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,StageId,FileName,StoredName,ContentType,FileSize,Sha256,Version,UploadedBy,UploadedAtUtc
        FROM dbo.Attachments
        WHERE AlertId=@AlertId
        ORDER BY UploadedAtUtc DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Attachment_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,AlertId,StageId,FileName,StoredName,ContentType,FileSize,Sha256,Version,UploadedBy,UploadedAtUtc
        FROM dbo.Attachments
        WHERE Id=@Id;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Audit_Insert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        INSERT INTO dbo.AuditLog(Id,AlertId,UserId,UserName,RoleCode,Action,EntityType,EntityId,StageId,
                                 PreviousValueJson,NewValueJson,Remarks,IpAddress,CreatedAtUtc)
        VALUES(@Id,@AlertId,@UserId,@UserName,@RoleCode,@Action,@EntityType,@EntityId,@StageId,
               @PreviousValueJson,@NewValueJson,@Remarks,@IpAddress,@CreatedAtUtc);
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Audit_GetByAlert
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SET @Take=COALESCE(@Take,100);
        IF @Take<1 SET @Take=1;
        IF @Take>500 SET @Take=500;

        SELECT TOP (@Take) Id,AlertId,UserId,UserName,RoleCode,Action,EntityType,EntityId,StageId,
                           PreviousValueJson,NewValueJson,Remarks,IpAddress,CreatedAtUtc
        FROM dbo.AuditLog
        WHERE AlertId=@AlertId
        ORDER BY CreatedAtUtc DESC;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Aging_GetBuckets
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Id,Name,FromDays,ToDays,DisplayOrder
        FROM dbo.AgingBuckets
        WHERE IsActive=1
        ORDER BY DisplayOrder;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Aging_SaveBucket
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        IF NULLIF(LTRIM(RTRIM(COALESCE(@Name,N''))), N'') IS NULL
            THROW 50004, 'Aging bucket name is required.', 1;
        IF COALESCE(@FromDays,-1)<0 OR (@ToDays IS NOT NULL AND @ToDays<@FromDays)
            THROW 50005, 'Invalid aging range.', 1;

        IF COALESCE(@IsNew,0)=1
        BEGIN
            INSERT INTO dbo.AgingBuckets(Id,Name,FromDays,ToDays,DisplayOrder,IsActive)
            VALUES(@Id,LTRIM(RTRIM(@Name)),@FromDays,@ToDays,@DisplayOrder,CASE WHEN @IsActive=1 THEN 1 ELSE 0 END);
        END
        ELSE
        BEGIN
            UPDATE dbo.AgingBuckets
            SET Name=LTRIM(RTRIM(@Name)),FromDays=@FromDays,ToDays=@ToDays,DisplayOrder=@DisplayOrder,
                IsActive=CASE WHEN @IsActive=1 THEN 1 ELSE 0 END
            WHERE Id=@Id;
        END;
        SET @AffectedRows=@@ROWCOUNT;
        SELECT @AffectedRows AS AffectedRows;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetAging
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT a.TemplateId,t.Name AS TemplateName,a.AlertType,a.StageEnteredAtUtc
        FROM dbo.Alerts AS a
        INNER JOIN dbo.Templates AS t ON t.Id=a.TemplateId
        WHERE a.Status NOT IN ('Closed','Cancelled','Rejected')
          AND
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId
                    )
              )
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status);
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_GetCount
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT COUNT(1) AS TotalRecords
        FROM dbo.Alerts AS a
        WHERE
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId
                    )
              )
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status)
          AND (@AgingFrom IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=@AgingFrom)
          AND (@AgingTo IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())<=@AgingTo)
          AND
          (
              NULLIF(LTRIM(RTRIM(COALESCE(@Search,N''))),N'') IS NULL
              OR UPPER(a.AlertNo) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.AlertType) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.BranchCode) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
          );
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Alert_GetPaged
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SET @Page=COALESCE(@Page,1);
        IF @Page<1 SET @Page=1;
        SET @PageSize=COALESCE(@PageSize,20);
        IF @PageSize<10 SET @PageSize=10;
        IF @PageSize>100 SET @PageSize=100;

        SELECT a.Id,a.AlertNo,t.Name AS TemplateName,a.AlertType,a.BranchCode,
               a.CustomerIdEncrypted,a.AccountIdEncrypted,a.CurrentStageName,a.Status,a.Priority,
               DATEDIFF(day,a.CreatedAtUtc,SYSUTCDATETIME()) AS OverallAge,
               DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME()) AS StageAge
        FROM dbo.Alerts AS a
        INNER JOIN dbo.Templates AS t ON t.Id=a.TemplateId
        WHERE
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId
                    )
              )
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status)
          AND (@AgingFrom IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=@AgingFrom)
          AND (@AgingTo IS NULL OR DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())<=@AgingTo)
          AND
          (
              NULLIF(LTRIM(RTRIM(COALESCE(@Search,N''))),N'') IS NULL
              OR UPPER(a.AlertNo) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.AlertType) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
              OR UPPER(a.BranchCode) LIKE N'%'+UPPER(LTRIM(RTRIM(@Search)))+N'%'
          )
        ORDER BY a.StageEnteredAtUtc DESC
        OFFSET ((@Page-1)*@PageSize) ROWS FETCH NEXT @PageSize ROWS ONLY;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetName
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT Name FROM dbo.Templates WHERE Id=@TemplateId;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetRoleCodes
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT DISTINCT RoleCode
        FROM dbo.CatsUsers
        WHERE IsActive=1
        ORDER BY RoleCode;
        RETURN;
END
GO

/* Backward-compatible wrapper. New C# code does not call this procedure directly. */
CREATE OR ALTER PROCEDURE dbo.usp_CatsRepository
    @Operation nvarchar(100),
    @JsonInput nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ModuleCode nvarchar(60), @MethodCode nvarchar(80);

    SELECT @ModuleCode=v.ModuleCode,@MethodCode=v.MethodCode
    FROM (VALUES
        (N'GetUserByUserName',N'User',N'GetByUserName'),
        (N'GetUserById',N'User',N'GetById'),
        (N'GetUsers',N'User',N'GetAll'),
        (N'UpsertUser',N'User',N'Upsert'),
        (N'GetTemplates',N'Template',N'GetAll'),
        (N'GetTemplate',N'Template',N'GetById'),
        (N'SaveTemplate',N'Template',N'Save'),
        (N'GetWorkflow',N'Workflow',N'GetById'),
        (N'GetPublishedWorkflowForTemplate',N'Workflow',N'GetPublishedByTemplate'),
        (N'SaveWorkflow',N'Workflow',N'Save'),
        (N'InsertAlert',N'Alert',N'Insert'),
        (N'InsertWorkflowInstance',N'WorkflowInstance',N'Insert'),
        (N'UpdateWorkflowInstance',N'WorkflowInstance',N'Update'),
        (N'TryClaimStageTransition',N'WorkflowInstance',N'TryClaimStageTransition'),
        (N'ReleaseStageTransitionClaim',N'WorkflowInstance',N'ReleaseStageTransitionClaim'),
        (N'UpdateAlertStage',N'Alert',N'UpdateStage'),
        (N'UpdateAlertDynamicData',N'Alert',N'UpdateDynamicData'),
        (N'GetAlert',N'Alert',N'GetById'),
        (N'GetWorkflowInstanceByAlert',N'WorkflowInstance',N'GetByAlert'),
        (N'InsertWorkItems',N'WorkItem',N'Insert'),
        (N'GetPendingWorkItems',N'WorkItem',N'GetPending'),
        (N'GetWorkItem',N'WorkItem',N'GetById'),
        (N'GetWorkItems',N'WorkItem',N'GetAllByAlert'),
        (N'CompleteWorkItem',N'WorkItem',N'Complete'),
        (N'ReassignPendingWorkItems',N'WorkItem',N'ReassignPending'),
        (N'CancelPendingWorkItems',N'WorkItem',N'CancelPending'),
        (N'GetParallelWorkItems',N'WorkItem',N'GetParallel'),
        (N'InsertQuery',N'Query',N'Insert'),
        (N'RespondLatestOpenQuery',N'Query',N'RespondLatestOpen'),
        (N'GetQueries',N'Query',N'GetAllByAlert'),
        (N'InsertAttachment',N'Attachment',N'Insert'),
        (N'GetAttachments',N'Attachment',N'GetAllByAlert'),
        (N'GetAttachment',N'Attachment',N'GetById'),
        (N'InsertAudit',N'Audit',N'Insert'),
        (N'GetAudit',N'Audit',N'GetByAlert'),
        (N'GetAgingBuckets',N'Aging',N'GetBuckets'),
        (N'SaveAgingBucket',N'Aging',N'SaveBucket'),
        (N'GetDashboardAging',N'Dashboard',N'GetAging'),
        (N'GetAlertsCount',N'Alert',N'GetCount'),
        (N'GetAlerts',N'Alert',N'GetPaged'),
        (N'GetTemplateName',N'Template',N'GetName'),
        (N'GetRoleCodes',N'Security',N'GetRoleCodes')
    ) v(OperationCode,ModuleCode,MethodCode)
    WHERE v.OperationCode=@Operation;

    IF @MethodCode IS NULL
        THROW 50000, 'Unsupported legacy repository operation.', 1;

    EXEC dbo.usp_CommonRepository
        @ModuleCode=@ModuleCode,
        @MethodCode=@MethodCode,
        @strJson=@JsonInput;
END
GO

/* ===== CATS V2 platform security, widgets, ingestion, reports, mail ===== */
IF OBJECT_ID('dbo.RoleMaster','U') IS NULL CREATE TABLE dbo.RoleMaster(Code varchar(60) PRIMARY KEY,Name nvarchar(150) NOT NULL,IsActive int NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.PermissionMaster','U') IS NULL CREATE TABLE dbo.PermissionMaster(Code varchar(100) PRIMARY KEY,Name nvarchar(200) NOT NULL,Category varchar(60) NOT NULL,IsActive int NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.RolePermissionMapping','U') IS NULL CREATE TABLE dbo.RolePermissionMapping(RoleCode varchar(60) NOT NULL,PermissionCode varchar(100) NOT NULL,IsActive int NOT NULL DEFAULT 1,PRIMARY KEY(RoleCode,PermissionCode));
IF OBJECT_ID('dbo.UserPermissionMapping','U') IS NULL CREATE TABLE dbo.UserPermissionMapping(UserId varchar(32) NOT NULL,PermissionCode varchar(100) NOT NULL,IsActive int NOT NULL DEFAULT 1,PRIMARY KEY(UserId,PermissionCode));
IF OBJECT_ID('dbo.DataScopeMaster','U') IS NULL CREATE TABLE dbo.DataScopeMaster(Id varchar(32) PRIMARY KEY,RoleCode varchar(60) NOT NULL,ScopeType varchar(30) NOT NULL,ScopeValue varchar(150) NOT NULL DEFAULT '',Priority int NOT NULL DEFAULT 100,IsActive int NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.DashboardWidgetMaster','U') IS NULL CREATE TABLE dbo.DashboardWidgetMaster(Id varchar(32) PRIMARY KEY,Code varchar(80) NOT NULL UNIQUE,Title nvarchar(150) NOT NULL,WidgetType varchar(30) NOT NULL,PermissionCode varchar(100) NOT NULL DEFAULT '',FilterJson nvarchar(max) NOT NULL DEFAULT '{}',DrillDownUrl nvarchar(500) NOT NULL DEFAULT '',DisplayOrder int NOT NULL DEFAULT 1,Width int NOT NULL DEFAULT 3,IsActive int NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.DashboardWidgetRoleMapping','U') IS NULL CREATE TABLE dbo.DashboardWidgetRoleMapping(WidgetId varchar(32) NOT NULL,RoleCode varchar(60) NOT NULL,DisplayOrder int NOT NULL DEFAULT 1,Width int NOT NULL DEFAULT 3,IsVisible int NOT NULL DEFAULT 1,PRIMARY KEY(WidgetId,RoleCode));
IF OBJECT_ID('dbo.IngestionConnector','U') IS NULL CREATE TABLE dbo.IngestionConnector(Id varchar(32) PRIMARY KEY,Name nvarchar(150) NOT NULL,ConnectorType varchar(30) NOT NULL,Host nvarchar(300) NOT NULL DEFAULT '',Port int NOT NULL DEFAULT 0,DatabaseName nvarchar(200) NOT NULL DEFAULT '',UserName nvarchar(200) NOT NULL DEFAULT '',SecretEncrypted nvarchar(2000) NOT NULL DEFAULT '',ExtraJson nvarchar(max) NOT NULL DEFAULT '{}',IsActive int NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.IngestionConfiguration','U') IS NULL CREATE TABLE dbo.IngestionConfiguration(Id varchar(32) PRIMARY KEY,Name nvarchar(150) NOT NULL,TemplateId varchar(32) NOT NULL,SourceType varchar(30) NOT NULL,ConnectorId varchar(32) NULL,FilePath nvarchar(500) NOT NULL DEFAULT '',FileName nvarchar(260) NOT NULL DEFAULT '',FilePattern nvarchar(260) NOT NULL DEFAULT '',ScheduleTriggersJson nvarchar(max) NOT NULL DEFAULT '[]',ScheduleCron varchar(100) NOT NULL DEFAULT '',QueryText nvarchar(max) NOT NULL DEFAULT '',FieldMappingJson nvarchar(max) NOT NULL DEFAULT '{}',DuplicateKeyFields nvarchar(500) NOT NULL DEFAULT '',ArchivePath nvarchar(500) NOT NULL DEFAULT '',ErrorPath nvarchar(500) NOT NULL DEFAULT '',IntervalMinutes int NOT NULL DEFAULT 1,IsActive int NOT NULL DEFAULT 1);
IF COL_LENGTH('dbo.IngestionConfiguration','FilePath') IS NULL ALTER TABLE dbo.IngestionConfiguration ADD FilePath nvarchar(500) NOT NULL CONSTRAINT DF_IngestionConfiguration_FilePath_V9 DEFAULT N'' WITH VALUES;
IF COL_LENGTH('dbo.IngestionConfiguration','FileName') IS NULL ALTER TABLE dbo.IngestionConfiguration ADD FileName nvarchar(260) NOT NULL CONSTRAINT DF_IngestionConfiguration_FileName_V9 DEFAULT N'' WITH VALUES;
IF COL_LENGTH('dbo.IngestionConfiguration','ScheduleTriggersJson') IS NULL ALTER TABLE dbo.IngestionConfiguration ADD ScheduleTriggersJson nvarchar(max) NOT NULL CONSTRAINT DF_IngestionConfiguration_ScheduleTriggersJson_V9 DEFAULT N'[]' WITH VALUES;
IF OBJECT_ID('dbo.IngestionRun','U') IS NULL CREATE TABLE dbo.IngestionRun(Id varchar(32) PRIMARY KEY,ConfigurationId varchar(32) NOT NULL,SourceReference nvarchar(500) NOT NULL DEFAULT '',StartedAtUtc datetime2 NOT NULL,EndedAtUtc datetime2 NULL,RowsRead int NOT NULL DEFAULT 0,RowsInserted int NOT NULL DEFAULT 0,RowsDuplicate int NOT NULL DEFAULT 0,RowsFailed int NOT NULL DEFAULT 0,Status varchar(30) NOT NULL,ErrorMessage nvarchar(max) NULL);
IF OBJECT_ID('dbo.IngestionStaging','U') IS NULL CREATE TABLE dbo.IngestionStaging(Id bigint IDENTITY(1,1) PRIMARY KEY,RunId varchar(32) NOT NULL,RowNo int NOT NULL,TemplateId varchar(32) NOT NULL,AlertType nvarchar(150) NOT NULL,BranchCode varchar(60) NOT NULL,CustomerIdEncrypted nvarchar(1000) NOT NULL,AccountIdEncrypted nvarchar(1000) NOT NULL,Priority varchar(30) NOT NULL,DynamicDataJson nvarchar(max) NOT NULL,DedupKey varchar(500) NOT NULL DEFAULT '',ProcessStatus varchar(30) NOT NULL DEFAULT 'Pending',ErrorMessage nvarchar(2000) NULL);
IF OBJECT_ID('dbo.MailConfiguration','U') IS NULL CREATE TABLE dbo.MailConfiguration(Id varchar(32) PRIMARY KEY,Name nvarchar(150) NOT NULL,ProviderType varchar(30) NOT NULL,Host nvarchar(300) NOT NULL,Port int NOT NULL,UserName nvarchar(200) NOT NULL DEFAULT '',SecretEncrypted nvarchar(2000) NOT NULL DEFAULT '',FromAddress nvarchar(300) NOT NULL,UseSsl int NOT NULL DEFAULT 1,IsActive int NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.MailTemplate','U') IS NULL CREATE TABLE dbo.MailTemplate(Id varchar(32) PRIMARY KEY,EventCode varchar(80) NOT NULL UNIQUE,SubjectTemplate nvarchar(500) NOT NULL,BodyTemplate nvarchar(max) NOT NULL,UseMafEnrichment int NOT NULL DEFAULT 0,IsActive int NOT NULL DEFAULT 1);
IF COL_LENGTH('dbo.MailTemplate','TemplateId') IS NULL ALTER TABLE dbo.MailTemplate ADD TemplateId varchar(32) NULL;
DECLARE @MailTemplateEventUq sysname;
SELECT TOP(1) @MailTemplateEventUq=kc.name FROM sys.key_constraints kc JOIN sys.index_columns ic ON ic.object_id=kc.parent_object_id AND ic.index_id=kc.unique_index_id JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id WHERE kc.parent_object_id=OBJECT_ID('dbo.MailTemplate') AND kc.type='UQ' GROUP BY kc.name HAVING COUNT(*)=1 AND MAX(c.name)='EventCode';
IF @MailTemplateEventUq IS NOT NULL
BEGIN
 DECLARE @DropMailTemplateEventUq nvarchar(500)=N'ALTER TABLE dbo.MailTemplate DROP CONSTRAINT '+QUOTENAME(@MailTemplateEventUq)+N';';
 EXEC sys.sp_executesql @DropMailTemplateEventUq;
END;
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MailTemplate') AND name='UX_MailTemplate_TemplateEvent') CREATE UNIQUE INDEX UX_MailTemplate_TemplateEvent ON dbo.MailTemplate(TemplateId,EventCode);
IF OBJECT_ID('dbo.MailQueue','U') IS NULL CREATE TABLE dbo.MailQueue(Id varchar(32) PRIMARY KEY,EventCode varchar(80) NOT NULL,AlertId varchar(32) NULL,ToAddress nvarchar(max) NOT NULL,CcAddress nvarchar(max) NULL,Subject nvarchar(500) NOT NULL,Body nvarchar(max) NOT NULL,Status varchar(30) NOT NULL DEFAULT 'Pending',Attempts int NOT NULL DEFAULT 0,NextAttemptAtUtc datetime2 NOT NULL,CreatedAtUtc datetime2 NOT NULL,SentAtUtc datetime2 NULL,ErrorMessage nvarchar(max) NULL);
GO

CREATE OR ALTER PROCEDURE dbo.usp_CATS_ProcessIngestion @RunId varchar(32)
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 DECLARE @Inserted int=0,@Duplicate int=0,@Failed int=0;
 BEGIN TRAN;
 UPDATE s SET ProcessStatus='Duplicate' FROM dbo.IngestionStaging s WHERE s.RunId=@RunId AND s.ProcessStatus='Pending' AND s.DedupKey<>'' AND EXISTS(SELECT 1 FROM dbo.Alerts a WHERE JSON_VALUE(a.DynamicDataJson,'$._ingestionDedupKey')=s.DedupKey);
 SET @Duplicate=@@ROWCOUNT;
 ;WITH src AS(SELECT * FROM dbo.IngestionStaging WHERE RunId=@RunId AND ProcessStatus='Pending')
 INSERT dbo.Alerts(Id,AlertNo,TemplateId,TemplateVersion,AlertType,BranchCode,CustomerIdEncrypted,AccountIdEncrypted,DynamicDataJson,Status,CurrentStageId,CurrentStageName,CreatedAtUtc,StageEnteredAtUtc,CreatedBy,Priority)
 SELECT LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-','')),'ALT-'+CONVERT(varchar(8),SYSUTCDATETIME(),112)+'-'+RIGHT(REPLACE(CONVERT(varchar(36),NEWID()),'-',''),12),s.TemplateId,t.Version,s.AlertType,s.BranchCode,s.CustomerIdEncrypted,s.AccountIdEncrypted,
        CASE WHEN ISJSON(s.DynamicDataJson)=1 THEN JSON_MODIFY(s.DynamicDataJson,'$._ingestionDedupKey',NULLIF(s.DedupKey,'')) ELSE '{}' END,
        'New','INIT','Initialising',SYSUTCDATETIME(),SYSUTCDATETIME(),'INGESTION',s.Priority
 FROM src s JOIN dbo.Templates t ON t.Id=s.TemplateId AND t.Status='Published';
 SET @Inserted=@@ROWCOUNT;
 UPDATE dbo.IngestionStaging SET ProcessStatus='Processed' WHERE RunId=@RunId AND ProcessStatus='Pending';
 UPDATE dbo.IngestionRun SET RowsInserted=@Inserted,RowsDuplicate=@Duplicate,RowsFailed=@Failed,Status=CASE WHEN @Failed>0 THEN 'CompletedWithErrors' ELSE 'Success' END,EndedAtUtc=SYSUTCDATETIME() WHERE Id=@RunId;
 COMMIT;
 SELECT @Inserted RowsInserted,@Duplicate RowsDuplicate,@Failed RowsFailed;
END
GO

/* All PlatformRepository data access is routed through this procedure. */

/* ===== Template / Alert-Type configurable dashboards (V3) ===== */
IF OBJECT_ID('dbo.TemplateDashboardMaster','U') IS NULL
CREATE TABLE dbo.TemplateDashboardMaster(
 Id varchar(32) NOT NULL PRIMARY KEY, Code varchar(80) NOT NULL UNIQUE, Name nvarchar(150) NOT NULL, Title nvarchar(250) NOT NULL, Description nvarchar(1000) NOT NULL DEFAULT '',
 TemplateId varchar(32) NOT NULL, AlertType nvarchar(150) NOT NULL DEFAULT '', GroupByFieldsJson nvarchar(max) NOT NULL DEFAULT '["BranchCode"]', MetricsJson nvarchar(max) NOT NULL DEFAULT '[]',
 GridColumnsJson nvarchar(max) NOT NULL DEFAULT '[]', SearchFieldsJson nvarchar(max) NOT NULL DEFAULT '["AlertNo","AccountId","CustomerId"]', PageSize int NOT NULL DEFAULT 20, DisplayOrder int NOT NULL DEFAULT 1,
 IsDefault bit NOT NULL DEFAULT 0, IsActive bit NOT NULL DEFAULT 1, CreatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), UpdatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_TemplateDashboard_Template FOREIGN KEY(TemplateId) REFERENCES dbo.Templates(Id));
GO
IF OBJECT_ID('dbo.TemplateDashboardRoleMapping','U') IS NULL
CREATE TABLE dbo.TemplateDashboardRoleMapping(DashboardId varchar(32) NOT NULL,RoleCode varchar(60) NOT NULL,IsVisible bit NOT NULL DEFAULT 1,PRIMARY KEY(DashboardId,RoleCode));
GO
/* CATS V4 - Platform repository modules */

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetEffectivePermissions
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT DISTINCT rp.PermissionCode FROM dbo.CatsUsers u JOIN dbo.RolePermissionMapping rp ON rp.RoleCode=u.RoleCode AND rp.IsActive=1 JOIN dbo.PermissionMaster p ON p.Code=rp.PermissionCode AND p.IsActive=1 WHERE u.Id=@UserId AND u.IsActive=1
  UNION SELECT DISTINCT up.PermissionCode FROM dbo.UserPermissionMapping up JOIN dbo.PermissionMaster p ON p.Code=up.PermissionCode AND p.IsActive=1 WHERE up.UserId=@UserId AND up.IsActive=1; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetDataScopes
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT s.Id,s.RoleCode,s.ScopeType,s.ScopeValue,s.Priority,s.IsActive FROM dbo.DataScopeMaster s JOIN dbo.CatsUsers u ON u.RoleCode=s.RoleCode WHERE u.Id=@UserId AND s.IsActive=1 ORDER BY s.Priority; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetWidgets
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
;WITH P AS(SELECT [value] Code FROM OPENJSON(@strJson,'$.permissions')), W AS(
   SELECT w.Code,w.Title,w.WidgetType,w.DrillDownUrl,m.DisplayOrder,m.Width,
    CASE UPPER(w.Code)
     WHEN 'TEMPLATES' THEN (SELECT COUNT_BIG(*) FROM dbo.Templates WHERE Status='Published')
     WHEN 'INGESTION_FAILED' THEN (SELECT COUNT_BIG(*) FROM dbo.IngestionRun WHERE Status='Failed' AND StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()))
     WHEN 'ACTIVE_ALERTS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE a.Status NOT IN('Closed','Rejected','Cancelled') AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     WHEN 'AGING_31_PLUS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=31 AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     ELSE CONVERT(bigint,0) END Value
   FROM dbo.DashboardWidgetMaster w JOIN dbo.DashboardWidgetRoleMapping m ON m.WidgetId=w.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1
   WHERE w.IsActive=1 AND (w.PermissionCode='' OR EXISTS(SELECT 1 FROM P WHERE Code=w.PermissionCode)))
  SELECT * FROM W ORDER BY DisplayOrder; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetWidgetConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive FROM dbo.DashboardWidgetMaster ORDER BY DisplayOrder; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_SaveWidget
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
BEGIN TRAN;
  MERGE dbo.DashboardWidgetMaster t USING(SELECT * FROM OPENJSON(@strJson,'$.widget') WITH(Id varchar(32),Code varchar(80),Title nvarchar(150),WidgetType varchar(30),PermissionCode varchar(100),FilterJson nvarchar(max),DrillDownUrl nvarchar(500),DisplayOrder int,Width int,IsActive int))s ON t.Id=s.Id
  WHEN MATCHED THEN UPDATE SET Code=s.Code,Title=s.Title,WidgetType=s.WidgetType,PermissionCode=s.PermissionCode,FilterJson=s.FilterJson,DrillDownUrl=s.DrillDownUrl,DisplayOrder=s.DisplayOrder,Width=s.Width,IsActive=s.IsActive
  WHEN NOT MATCHED THEN INSERT(Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive)VALUES(s.Id,s.Code,s.Title,s.WidgetType,s.PermissionCode,s.FilterJson,s.DrillDownUrl,s.DisplayOrder,s.Width,s.IsActive);
  MERGE dbo.DashboardWidgetRoleMapping t USING(SELECT JSON_VALUE(@strJson,'$.widget.id') WidgetId,JSON_VALUE(@strJson,'$.roleCode') RoleCode,CONVERT(int,JSON_VALUE(@strJson,'$.widget.displayOrder')) DisplayOrder,CONVERT(int,JSON_VALUE(@strJson,'$.widget.width')) Width)s ON t.WidgetId=s.WidgetId AND t.RoleCode=s.RoleCode
  WHEN MATCHED THEN UPDATE SET DisplayOrder=s.DisplayOrder,Width=s.Width,IsVisible=1 WHEN NOT MATCHED THEN INSERT(WidgetId,RoleCode,DisplayOrder,Width,IsVisible)VALUES(s.WidgetId,s.RoleCode,s.DisplayOrder,s.Width,1); COMMIT; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @TDIncludeInactive bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.includeInactive'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d
  WHERE (@TDIncludeInactive=1 OR d.IsActive=1) AND (@TDIncludeInactive=1 OR EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))
  ORDER BY d.DisplayOrder,d.Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @TDId varchar(32)=JSON_VALUE(@strJson,'$.id'),@TDRequireManage bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.requireManage'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d WHERE d.Id=@TDId AND (@TDRequireManage=1 OR (d.IsActive=1 AND EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
BEGIN TRAN;
  MERGE dbo.TemplateDashboardMaster t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32) '$.id',Code varchar(80) '$.code',Name nvarchar(150) '$.name',Title nvarchar(250) '$.title',Description nvarchar(1000) '$.description',TemplateId varchar(32) '$.templateId',AlertType nvarchar(150) '$.alertType',GroupByFieldsJson nvarchar(max) '$.groupByFieldsJson',MetricsJson nvarchar(max) '$.metricsJson',GridColumnsJson nvarchar(max) '$.gridColumnsJson',SearchFieldsJson nvarchar(max) '$.searchFieldsJson',PageSize int '$.pageSize',DisplayOrder int '$.displayOrder',IsDefault bit '$.isDefault',IsActive bit '$.isActive'))q ON t.Id=q.Id
  WHEN MATCHED THEN UPDATE SET Code=q.Code,Name=q.Name,Title=q.Title,Description=COALESCE(q.Description,''),TemplateId=q.TemplateId,AlertType=COALESCE(q.AlertType,''),GroupByFieldsJson=q.GroupByFieldsJson,MetricsJson=q.MetricsJson,GridColumnsJson=q.GridColumnsJson,SearchFieldsJson=q.SearchFieldsJson,PageSize=q.PageSize,DisplayOrder=q.DisplayOrder,IsDefault=q.IsDefault,IsActive=q.IsActive,UpdatedAtUtc=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT(Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive) VALUES(q.Id,q.Code,q.Name,q.Title,COALESCE(q.Description,''),q.TemplateId,COALESCE(q.AlertType,''),q.GroupByFieldsJson,q.MetricsJson,q.GridColumnsJson,q.SearchFieldsJson,q.PageSize,q.DisplayOrder,q.IsDefault,q.IsActive);
  DECLARE @SavedDashboardId varchar(32)=JSON_VALUE(@strJson,'$.id'); DELETE FROM dbo.TemplateDashboardRoleMapping WHERE DashboardId=@SavedDashboardId;
  INSERT dbo.TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) SELECT @SavedDashboardId,[value],1 FROM OPENJSON(@strJson,'$.roleCodes') WHERE NULLIF([value],'') IS NOT NULL;
  COMMIT; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetAlerts
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @DTTemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),@DTAlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),@DTUserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),@DTRoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),@DTCanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));
  SELECT TOP(5000) a.Id,a.AlertNo,a.TemplateId,a.AlertType,a.BranchCode,a.CustomerIdEncrypted,a.AccountIdEncrypted,a.Status,a.CurrentStageName,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc,a.DynamicDataJson
  FROM dbo.Alerts a WHERE a.TemplateId=@DTTemplateId AND (NULLIF(@DTAlertType,'') IS NULL OR a.AlertType=@DTAlertType) AND (@DTCanViewAll=1 OR a.BranchCode=@DTUserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND (wi.AssignedUserId=@UserId OR (wi.AssignedRoleCode=@DTRoleCode AND (wi.AssignedBranchCode='' OR wi.AssignedBranchCode=@DTUserBranch))))) ORDER BY a.CreatedAtUtc DESC; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Connector_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive FROM dbo.IngestionConnector ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Connector_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.IngestionConnector t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32),Name nvarchar(150),ConnectorType varchar(30),Host nvarchar(300),Port int,DatabaseName nvarchar(200),UserName nvarchar(200),SecretEncrypted nvarchar(2000),ExtraJson nvarchar(max),IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ConnectorType=s.ConnectorType,Host=s.Host,Port=s.Port,DatabaseName=s.DatabaseName,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,ExtraJson=s.ExtraJson,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive)VALUES(s.Id,s.Name,s.ConnectorType,s.Host,s.Port,s.DatabaseName,s.UserName,s.SecretEncrypted,s.ExtraJson,s.IsActive); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetConfigurations
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,TemplateId,SourceType,ConnectorId,FilePath,FileName,FilePattern,ScheduleTriggersJson,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive FROM dbo.IngestionConfiguration ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_SaveConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.IngestionConfiguration t
USING(SELECT * FROM OPENJSON(@strJson) WITH(
 Id varchar(32) '$.id',Name nvarchar(150) '$.name',TemplateId varchar(32) '$.templateId',SourceType varchar(30) '$.sourceType',ConnectorId varchar(32) '$.connectorId',
 FilePath nvarchar(500) '$.filePath',FileName nvarchar(260) '$.fileName',FilePattern nvarchar(260) '$.filePattern',ScheduleTriggersJson nvarchar(max) '$.scheduleTriggersJson',
 ScheduleCron varchar(100) '$.scheduleCron',QueryText nvarchar(max) '$.queryText',FieldMappingJson nvarchar(max) '$.fieldMappingJson',DuplicateKeyFields nvarchar(500) '$.duplicateKeyFields',
 ArchivePath nvarchar(500) '$.archivePath',ErrorPath nvarchar(500) '$.errorPath',IntervalMinutes int '$.intervalMinutes',IsActive int '$.isActive'
))s ON t.Id=s.Id
WHEN MATCHED THEN UPDATE SET Name=s.Name,TemplateId=s.TemplateId,SourceType=s.SourceType,ConnectorId=s.ConnectorId,FilePath=COALESCE(s.FilePath,N''),FileName=COALESCE(s.FileName,N''),FilePattern=COALESCE(s.FilePattern,N''),ScheduleTriggersJson=COALESCE(s.ScheduleTriggersJson,N'[]'),ScheduleCron=COALESCE(s.ScheduleCron,''),QueryText=COALESCE(s.QueryText,N''),FieldMappingJson=COALESCE(s.FieldMappingJson,N'{}'),DuplicateKeyFields=COALESCE(s.DuplicateKeyFields,N''),ArchivePath=COALESCE(s.ArchivePath,N''),ErrorPath=COALESCE(s.ErrorPath,N''),IntervalMinutes=COALESCE(s.IntervalMinutes,1),IsActive=COALESCE(s.IsActive,1)
WHEN NOT MATCHED THEN INSERT(Id,Name,TemplateId,SourceType,ConnectorId,FilePath,FileName,FilePattern,ScheduleTriggersJson,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive)
VALUES(s.Id,s.Name,s.TemplateId,s.SourceType,s.ConnectorId,COALESCE(s.FilePath,N''),COALESCE(s.FileName,N''),COALESCE(s.FilePattern,N''),COALESCE(s.ScheduleTriggersJson,N'[]'),COALESCE(s.ScheduleCron,''),COALESCE(s.QueryText,N''),COALESCE(s.FieldMappingJson,N'{}'),COALESCE(s.DuplicateKeyFields,N''),COALESCE(s.ArchivePath,N''),COALESCE(s.ErrorPath,N''),COALESCE(s.IntervalMinutes,1),COALESCE(s.IsActive,1)); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetDashboard
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT (SELECT COUNT(*) FROM dbo.IngestionConfiguration WHERE IsActive=1)ActiveConfigurations,COUNT(*)RunsToday,COALESCE(SUM(CASE WHEN Status='Success' THEN 1 ELSE 0 END),0)SuccessfulToday,COALESCE(SUM(CASE WHEN Status='Failed' THEN 1 ELSE 0 END),0)FailedToday,COALESCE(SUM(RowsInserted),0)RowsInsertedToday FROM dbo.IngestionRun WHERE StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetRuns
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @Take int=CONVERT(int,JSON_VALUE(@strJson,'$.take')); SELECT TOP(@Take) Id,ConfigurationId,SourceReference,StartedAtUtc,EndedAtUtc,RowsRead,RowsInserted,RowsDuplicate,RowsFailed,Status,ErrorMessage FROM dbo.IngestionRun ORDER BY StartedAtUtc DESC; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetConfigurations
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive FROM dbo.MailConfiguration ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_SaveConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.MailConfiguration t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32),Name nvarchar(150),ProviderType varchar(30),Host nvarchar(300),Port int,UserName nvarchar(200),SecretEncrypted nvarchar(2000),FromAddress nvarchar(300),UseSsl int,IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ProviderType=s.ProviderType,Host=s.Host,Port=s.Port,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,FromAddress=s.FromAddress,UseSsl=s.UseSsl,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive)VALUES(s.Id,s.Name,s.ProviderType,s.Host,s.Port,s.UserName,s.SecretEncrypted,s.FromAddress,s.UseSsl,s.IsActive); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetTemplates
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive FROM dbo.MailTemplate ORDER BY EventCode; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetLogs
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @MailTake int=CONVERT(int,JSON_VALUE(@strJson,'$.take')); SELECT TOP(@MailTake) Id,EventCode,AlertId,ToAddress,Subject,Status,Attempts,CreatedAtUtc,SentAtUtc,ErrorMessage FROM dbo.MailQueue ORDER BY CreatedAtUtc DESC; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_SaveTemplate
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.MailTemplate t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32) '$.id',TemplateId varchar(32) '$.templateId',EventCode varchar(80) '$.eventCode',SubjectTemplate nvarchar(500) '$.subjectTemplate',BodyTemplate nvarchar(max) '$.bodyTemplate',UseMafEnrichment bit '$.useMafEnrichment',IsActive bit '$.isActive'))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET TemplateId=s.TemplateId,EventCode=s.EventCode,SubjectTemplate=s.SubjectTemplate,BodyTemplate=s.BodyTemplate,UseMafEnrichment=COALESCE(s.UseMafEnrichment,0),IsActive=COALESCE(s.IsActive,1) WHEN NOT MATCHED THEN INSERT(Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive)VALUES(s.Id,s.TemplateId,s.EventCode,s.SubjectTemplate,s.BodyTemplate,COALESCE(s.UseMafEnrichment,0),COALESCE(s.IsActive,1)); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Report_GetCount
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE
        @TemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),
        @AlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),
        @FilterBranch varchar(60)=JSON_VALUE(@strJson,'$.branchCode'),
        @UserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),
        @Status varchar(30)=JSON_VALUE(@strJson,'$.status'),
        @FromDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.fromDate')),
        @ToDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.toDate')),
        @CanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));

    SELECT COUNT(*)
    FROM dbo.Alerts a
    WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
           OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
      AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
      AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
      AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
      AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
      AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
      AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)));
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Report_GetData
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE
        @ReportType varchar(20)=JSON_VALUE(@strJson,'$.reportType'),
        @TemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),
        @AlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),
        @FilterBranch varchar(60)=JSON_VALUE(@strJson,'$.branchCode'),
        @UserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),
        @Status varchar(30)=JSON_VALUE(@strJson,'$.status'),
        @FromDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.fromDate')),
        @ToDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.toDate')),
        @Page int=COALESCE(TRY_CONVERT(int,JSON_VALUE(@strJson,'$.page')),1),
        @PageSize int=COALESCE(TRY_CONVERT(int,JSON_VALUE(@strJson,'$.pageSize')),20),
        @CanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));

    IF UPPER(COALESCE(@ReportType,''))='MIS'
    BEGIN
        SELECT a.AlertType,a.Status,COUNT(*) Total
        FROM dbo.Alerts a
        WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
               OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
          AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
          AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
          AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
          AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)))
        GROUP BY a.AlertType,a.Status
        ORDER BY a.AlertType,a.Status;
        RETURN;
    END;

    SELECT a.AlertNo,a.AlertType,t.Name TemplateName,a.BranchCode,a.CurrentStageName,
           a.Status,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc
    FROM dbo.Alerts a
    JOIN dbo.Templates t ON t.Id=a.TemplateId
    WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
           OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
      AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
      AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
      AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
      AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
      AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
      AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)))
    ORDER BY a.CreatedAtUtc DESC
    OFFSET (@Page-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END
GO

/* Backward-compatible wrapper. New C# code does not call this procedure directly. */
CREATE OR ALTER PROCEDURE dbo.usp_PlatformRepository
    @Operation nvarchar(100),
    @JsonInput nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ModuleCode nvarchar(60), @MethodCode nvarchar(80);

    SELECT @ModuleCode=v.ModuleCode,@MethodCode=v.MethodCode
    FROM (VALUES
        (N'GetEffectivePermissions',N'Security',N'GetEffectivePermissions'),
        (N'GetDataScopes',N'Security',N'GetDataScopes'),
        (N'GetDashboardWidgets',N'Dashboard',N'GetWidgets'),
        (N'GetDashboardWidgetConfiguration',N'Dashboard',N'GetWidgetConfiguration'),
        (N'SaveDashboardWidget',N'Dashboard',N'SaveWidget'),
        (N'GetTemplateDashboards',N'TemplateDashboard',N'GetAll'),
        (N'GetTemplateDashboard',N'TemplateDashboard',N'GetById'),
        (N'SaveTemplateDashboard',N'TemplateDashboard',N'Save'),
        (N'GetTemplateDashboardAlerts',N'TemplateDashboard',N'GetAlerts'),
        (N'GetConnectors',N'Connector',N'GetAll'),
        (N'SaveConnector',N'Connector',N'Save'),
        (N'GetIngestionConfigurations',N'Ingestion',N'GetConfigurations'),
        (N'SaveIngestionConfiguration',N'Ingestion',N'SaveConfiguration'),
        (N'GetIngestionDashboard',N'Ingestion',N'GetDashboard'),
        (N'GetIngestionRuns',N'Ingestion',N'GetRuns'),
        (N'GetMailConfigurations',N'Mail',N'GetConfigurations'),
        (N'SaveMailConfiguration',N'Mail',N'SaveConfiguration'),
        (N'GetMailTemplates',N'Mail',N'GetTemplates'),
        (N'GetMailLogs',N'Mail',N'GetLogs'),
        (N'SaveMailTemplate',N'Mail',N'SaveTemplate'),
        (N'GetReportCount',N'Report',N'GetCount'),
        (N'GetReport',N'Report',N'GetData')
    ) v(OperationCode,ModuleCode,MethodCode)
    WHERE v.OperationCode=@Operation;

    IF @MethodCode IS NULL
        THROW 50000, 'Unsupported legacy repository operation.', 1;

    EXEC dbo.usp_CommonRepository
        @ModuleCode=@ModuleCode,
        @MethodCode=@MethodCode,
        @strJson=@JsonInput;
END
GO


MERGE dbo.PermissionMaster AS t USING (VALUES
 ('TEMPLATE.MANAGE','Manage templates','Templates'),('WORKFLOW.MANAGE','Manage workflows','Workflow'),('ALERT.UPLOAD','Create/upload alerts','Alerts'),('ALERT.VIEWALL','View all scoped alerts','Alerts'),('ALERT.REASSIGN','Reassign alerts','Alerts'),('PI.UNMASK','Unmask PI data','Security'),('AUDIT.VIEW','View audit trail','Audit'),('DASHBOARD.VIEW','View dashboard','Dashboard'),('DASHBOARD.CONFIGURE','Configure dashboard','Dashboard'),('INGESTION.VIEW','View ingestion','Ingestion'),('INGESTION.MANAGE','Manage ingestion','Ingestion'),('REPORT.MIS','MIS report','Reports'),('REPORT.ALERTWISE','Alert wise report','Reports'),('REPORT.ALL','All alerts report','Reports'),('MAIL.MANAGE','Manage mail','Mail'),('SECURITY.MANAGE','Manage roles/permissions/data scopes','Security'),('ASSISTANT.USE','Use read-only CATS AI assistant','AI'),('MCP.MANAGE','Discover and manage MCP servers','AI')
) s(Code,Name,Category) ON t.Code=s.Code WHEN NOT MATCHED THEN INSERT(Code,Name,Category,IsActive) VALUES(s.Code,s.Name,s.Category,1);
GO

/* Default role permissions are database configuration, not code bypasses. */
MERGE dbo.RolePermissionMapping AS t USING (VALUES
 ('ADMIN','TEMPLATE.MANAGE'),('ADMIN','WORKFLOW.MANAGE'),('ADMIN','ALERT.UPLOAD'),('ADMIN','ALERT.VIEWALL'),('ADMIN','ALERT.REASSIGN'),('ADMIN','PI.UNMASK'),('ADMIN','AUDIT.VIEW'),('ADMIN','DASHBOARD.VIEW'),('ADMIN','DASHBOARD.CONFIGURE'),('ADMIN','INGESTION.VIEW'),('ADMIN','INGESTION.MANAGE'),('ADMIN','REPORT.MIS'),('ADMIN','REPORT.ALERTWISE'),('ADMIN','REPORT.ALL'),('ADMIN','MAIL.MANAGE'),('ADMIN','SECURITY.MANAGE'),('ADMIN','ASSISTANT.USE'),('ADMIN','MCP.MANAGE'),
 ('CENTRAL','TEMPLATE.MANAGE'),('CENTRAL','WORKFLOW.MANAGE'),('CENTRAL','ALERT.UPLOAD'),('CENTRAL','ALERT.VIEWALL'),('CENTRAL','ALERT.REASSIGN'),('CENTRAL','AUDIT.VIEW'),('CENTRAL','DASHBOARD.VIEW'),('CENTRAL','DASHBOARD.CONFIGURE'),('CENTRAL','INGESTION.VIEW'),('CENTRAL','INGESTION.MANAGE'),('CENTRAL','REPORT.MIS'),('CENTRAL','REPORT.ALERTWISE'),('CENTRAL','REPORT.ALL'),('CENTRAL','MAIL.MANAGE'),('CENTRAL','ASSISTANT.USE'),
 ('DT_USER','DASHBOARD.VIEW'),('DT_CHECKER','AUDIT.VIEW'),('DT_CHECKER','DASHBOARD.VIEW'),('DT_VERIFIER','AUDIT.VIEW'),('DT_VERIFIER','DASHBOARD.VIEW'),('AUDITOR','ALERT.VIEWALL'),('AUDITOR','AUDIT.VIEW'),('AUDITOR','DASHBOARD.VIEW'),('AUDITOR','REPORT.MIS'),('AUDITOR','REPORT.ALERTWISE'),('AUDITOR','REPORT.ALL')
) s(RoleCode,PermissionCode) ON t.RoleCode=s.RoleCode AND t.PermissionCode=s.PermissionCode
WHEN NOT MATCHED THEN INSERT(RoleCode,PermissionCode,IsActive) VALUES(s.RoleCode,s.PermissionCode,1);
GO
/* Preserve existing per-user permissions by migrating CatsUsers.PermissionsJson into the DB mapping. */
INSERT dbo.UserPermissionMapping(UserId,PermissionCode,IsActive)
SELECT u.Id,j.[value],1 FROM dbo.CatsUsers u CROSS APPLY OPENJSON(COALESCE(u.PermissionsJson,N'[]')) j
JOIN dbo.PermissionMaster p ON p.Code=j.[value] AND p.IsActive=1
WHERE NOT EXISTS(SELECT 1 FROM dbo.UserPermissionMapping x WHERE x.UserId=u.Id AND x.PermissionCode=j.[value]);
GO
MERGE dbo.DataScopeMaster AS t USING (VALUES
 ('scope-admin-all','ADMIN','ALL','',1),('scope-central-all','CENTRAL','ALL','',1),('scope-dtuser-branch','DT_USER','BRANCH','',10),('scope-checker-branch','DT_CHECKER','BRANCH','',10),('scope-verifier-branch','DT_VERIFIER','BRANCH','',10),('scope-auditor-all','AUDITOR','ALL','',10)
) s(Id,RoleCode,ScopeType,ScopeValue,Priority) ON t.Id=s.Id
WHEN NOT MATCHED THEN INSERT(Id,RoleCode,ScopeType,ScopeValue,Priority,IsActive) VALUES(s.Id,s.RoleCode,s.ScopeType,s.ScopeValue,s.Priority,1);
GO
MERGE dbo.DashboardWidgetMaster AS t USING (VALUES
 ('wdgactive','ACTIVE_ALERTS','Active Alerts','Card','DASHBOARD.VIEW','{}','/alerts?active=true',1,3),
 ('wdgtemplates','TEMPLATES','Templates / Alert Types','Card','DASHBOARD.VIEW','{}','/templates',2,3),
 ('wdg31','AGING_31_PLUS','31+ Day Alerts','Card','DASHBOARD.VIEW','{}','/alerts?agingFrom=31',3,3),
 ('wdgingfail','INGESTION_FAILED','Ingestion Failed Today','Card','INGESTION.VIEW','{}','/ingestion',4,3)
) s(Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width) ON t.Id=s.Id WHEN NOT MATCHED THEN INSERT(Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive) VALUES(s.Id,s.Code,s.Title,s.WidgetType,s.PermissionCode,s.FilterJson,s.DrillDownUrl,s.DisplayOrder,s.Width,1);
GO

/* Safe, disabled examples administrators can copy and enable after supplying real endpoints/paths. */
IF NOT EXISTS(SELECT 1 FROM dbo.IngestionConfiguration WHERE Id='sample-scheduled-folder') AND EXISTS(SELECT 1 FROM dbo.Templates)
 INSERT dbo.IngestionConfiguration(Id,Name,TemplateId,SourceType,ConnectorId,FilePattern,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive)
 SELECT 'sample-scheduled-folder','Sample scheduled CSV import',Id,'SHARED_FOLDER',NULL,'*.csv','*/15 * * * *','',N'{"AlertType":"AlertType","BranchCode":"BranchCode","CustomerId":"CustomerId","AccountId":"AccountId","Priority":"Priority"}','CustomerId,AccountId',N'C:\CATS\archive',N'C:\CATS\error',15,0 FROM dbo.Templates ORDER BY CreatedAtUtc OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;
GO
MERGE dbo.MailConfiguration t USING(VALUES('sample-smtp','Sample SMTP (disabled)','SMTP','smtp.example.com',587,'cats-service','', 'cats@example.com',1,0))s(Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive) ON t.Id=s.Id WHEN NOT MATCHED THEN INSERT VALUES(s.Id,s.Name,s.ProviderType,s.Host,s.Port,s.UserName,s.SecretEncrypted,s.FromAddress,s.UseSsl,s.IsActive);
MERGE dbo.MailTemplate t USING(VALUES('sample-alert-created',NULL,'ALERT_CREATED',N'CATS alert {{AlertNo}} created',N'<p>Hello {{DisplayName}},</p><p>Alert <strong>{{AlertNo}}</strong> was created with status {{Status}}.</p>',0,1))s(Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive) ON t.Id=s.Id WHEN NOT MATCHED THEN INSERT(Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive) VALUES(s.Id,s.TemplateId,s.EventCode,s.SubjectTemplate,s.BodyTemplate,s.UseMafEnrichment,s.IsActive);
GO


/* ===== CATS V9 Template presentation / advanced field configuration ===== */
IF COL_LENGTH('dbo.Templates','ViewConfigurationJson') IS NULL
    ALTER TABLE dbo.Templates ADD ViewConfigurationJson nvarchar(max) NOT NULL CONSTRAINT DF_Templates_ViewConfigurationJson_V9B DEFAULT N'{}' WITH VALUES;
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetAll
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates
    ORDER BY Name,Version DESC;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetById
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Id varchar(32)=JSON_VALUE(COALESCE(@strJson,N'{}'),'$.id');
    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates WHERE Id=@Id;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_Save
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson=COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson)<>1 THROW 50000,'strJson must be valid JSON.',1;

    DECLARE
        @Id varchar(32)=JSON_VALUE(@strJson,'$.id'),
        @Code varchar(80)=JSON_VALUE(@strJson,'$.code'),
        @Name nvarchar(250)=JSON_VALUE(@strJson,'$.name'),
        @ExecutionMode varchar(30)=COALESCE(JSON_VALUE(@strJson,'$.executionMode'),'Deterministic'),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @ViewConfigurationJson nvarchar(max),
        @CreatedBy varchar(100)=COALESCE(JSON_VALUE(@strJson,'$.createdBy'),'SYSTEM'),
        @NowUtc datetime2(7)=TRY_CONVERT(datetime2(7),JSON_VALUE(@strJson,'$.nowUtc')),
        @NewId varchar(32),
        @NextVersion int;

    /*
       JSON_QUERY handles the new nested JSON shape.
       OPENJSON/nvarchar(max) handles the legacy escaped-string shape without JSON_VALUE's 4K cap.
    */
    SELECT
        @SectionsJson=COALESCE(JSON_QUERY(@strJson,'$.sectionsJson'),j.sectionsText,N'[]'),
        @FieldsJson=COALESCE(JSON_QUERY(@strJson,'$.fieldsJson'),j.fieldsText,N'[]'),
        @AssignmentRulesJson=COALESCE(JSON_QUERY(@strJson,'$.assignmentRulesJson'),j.assignmentRulesText,N'[]'),
        @ViewConfigurationJson=COALESCE(JSON_QUERY(@strJson,'$.viewConfigurationJson'),j.viewConfigurationText,N'{}')
    FROM OPENJSON(@strJson)
    WITH
    (
        sectionsText nvarchar(max) '$.sectionsJson',
        fieldsText nvarchar(max) '$.fieldsJson',
        assignmentRulesText nvarchar(max) '$.assignmentRulesJson',
        viewConfigurationText nvarchar(max) '$.viewConfigurationJson'
    ) j;

    SET @NowUtc=COALESCE(@NowUtc,SYSUTCDATETIME());

    IF NULLIF(LTRIM(RTRIM(@Code)),'') IS NULL OR NULLIF(LTRIM(RTRIM(@Name)),'') IS NULL
        THROW 50001,'Template code and name are required.',1;

    IF ISJSON(@SectionsJson)<>1 OR ISJSON(@FieldsJson)<>1 OR ISJSON(@AssignmentRulesJson)<>1 OR ISJSON(@ViewConfigurationJson)<>1
        THROW 50002,'Template configuration JSON is invalid.',1;

    IF NULLIF(LTRIM(RTRIM(@Id)),'') IS NOT NULL
    BEGIN
        IF NOT EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id)
            THROW 50003,'The template to update was not found.',1;
        IF EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id AND Status='Retired')
            THROW 50004,'Retired templates cannot be modified.',1;

        UPDATE dbo.Templates
        SET Code=@Code,
            Name=@Name,
            ExecutionMode=@ExecutionMode,
            SectionsJson=@SectionsJson,
            FieldsJson=@FieldsJson,
            AssignmentRulesJson=@AssignmentRulesJson,
            ViewConfigurationJson=@ViewConfigurationJson
        WHERE Id=@Id;
        SET @NewId=@Id;
    END
    ELSE
    BEGIN
        SELECT @NextVersion=COALESCE(MAX(Version),0)+1
        FROM dbo.Templates
        WHERE UPPER(Code)=UPPER(@Code);

        SET @NewId=LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-',''));

        INSERT dbo.Templates
            (Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,
             AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy)
        VALUES
            (@NewId,@Code,@Name,@NextVersion,'Draft',@ExecutionMode,@SectionsJson,@FieldsJson,
             @AssignmentRulesJson,@ViewConfigurationJson,NULL,@NowUtc,@CreatedBy);
    END;

    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates
    WHERE Id=@NewId;
END
GO

-- Rename the legacy permission while preserving active and inactive assignments.
-- Run once against an existing SQL Server CATS database before starting the new app.
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF NOT EXISTS(SELECT 1 FROM dbo.PermissionMaster WHERE Code='PI.UNMASK')
 INSERT dbo.PermissionMaster(Code,Name,Category,IsActive)
 SELECT 'PI.UNMASK','Unmask PI data',Category,IsActive FROM dbo.PermissionMaster WHERE Code='PII.UNMASK';
UPDATE n SET IsActive=CASE WHEN n.IsActive=1 OR o.IsActive=1 THEN 1 ELSE 0 END
 FROM dbo.RolePermissionMapping n JOIN dbo.RolePermissionMapping o ON o.RoleCode=n.RoleCode
 WHERE n.PermissionCode='PI.UNMASK' AND o.PermissionCode='PII.UNMASK';
INSERT dbo.RolePermissionMapping(RoleCode,PermissionCode,IsActive)
 SELECT o.RoleCode,'PI.UNMASK',o.IsActive FROM dbo.RolePermissionMapping o
 WHERE o.PermissionCode='PII.UNMASK' AND NOT EXISTS(SELECT 1 FROM dbo.RolePermissionMapping n WHERE n.RoleCode=o.RoleCode AND n.PermissionCode='PI.UNMASK');
DELETE FROM dbo.RolePermissionMapping WHERE PermissionCode='PII.UNMASK';
UPDATE n SET IsActive=CASE WHEN n.IsActive=1 OR o.IsActive=1 THEN 1 ELSE 0 END
 FROM dbo.UserPermissionMapping n JOIN dbo.UserPermissionMapping o ON o.UserId=n.UserId
 WHERE n.PermissionCode='PI.UNMASK' AND o.PermissionCode='PII.UNMASK';
INSERT dbo.UserPermissionMapping(UserId,PermissionCode,IsActive)
 SELECT o.UserId,'PI.UNMASK',o.IsActive FROM dbo.UserPermissionMapping o
 WHERE o.PermissionCode='PII.UNMASK' AND NOT EXISTS(SELECT 1 FROM dbo.UserPermissionMapping n WHERE n.UserId=o.UserId AND n.PermissionCode='PI.UNMASK');
DELETE FROM dbo.UserPermissionMapping WHERE PermissionCode='PII.UNMASK';
UPDATE dbo.CatsUsers SET PermissionsJson=REPLACE(PermissionsJson,'"PII.UNMASK"','"PI.UNMASK"') WHERE PermissionsJson LIKE '%PII.UNMASK%';
UPDATE dbo.DashboardWidgetMaster SET PermissionCode='PI.UNMASK' WHERE PermissionCode='PII.UNMASK';
DELETE FROM dbo.PermissionMaster WHERE Code='PII.UNMASK';
COMMIT TRANSACTION;
GO
