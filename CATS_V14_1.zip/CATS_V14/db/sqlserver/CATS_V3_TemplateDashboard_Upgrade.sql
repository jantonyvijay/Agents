/* CATS V3 - Template / Alert-Type Dashboard SQL Server Upgrade
   Existing CATS V2 database: take backup, then execute this script.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
/* ===== Template / Alert-Type configurable dashboards (V3) ===== */
IF OBJECT_ID('dbo.TemplateDashboardMaster','U') IS NULL
CREATE TABLE dbo.TemplateDashboardMaster(
 Id varchar(32) NOT NULL PRIMARY KEY, Code varchar(80) NOT NULL UNIQUE, Name nvarchar(150) NOT NULL, Title nvarchar(250) NOT NULL, Description nvarchar(1000) NOT NULL DEFAULT '',
 TemplateId varchar(32) NOT NULL, AlertType nvarchar(150) NOT NULL DEFAULT '', GroupByFieldsJson nvarchar(max) NOT NULL DEFAULT '["BranchCode"]', MetricsJson nvarchar(max) NOT NULL DEFAULT '[]',
 GridColumnsJson nvarchar(max) NOT NULL DEFAULT '[]', SearchFieldsJson nvarchar(max) NOT NULL DEFAULT '["AlertNo","AccountId","CustomerId"]', PageSize int NOT NULL DEFAULT 20, DisplayOrder int NOT NULL DEFAULT 1,
 IsDefault bit NOT NULL DEFAULT 0, IsActive bit NOT NULL DEFAULT 1, CreatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), UpdatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_TemplateDashboard_Template FOREIGN KEY(TemplateId) REFERENCES dbo.Templates(Id));
GO
IF OBJECT_ID('dbo.TemplateDashboardRoleMapping','U') IS NULL
CREATE TABLE dbo.TemplateDashboardRoleMapping(DashboardId varchar(32) NOT NULL,RoleCode varchar(60) NOT NULL,IsVisible bit NOT NULL DEFAULT 1,PRIMARY KEY(DashboardId,RoleCode));
GO

CREATE OR ALTER PROCEDURE dbo.usp_PlatformRepository
 @Operation nvarchar(100), @JsonInput nvarchar(max)=N'{}'
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF ISJSON(@JsonInput)<>1
 BEGIN
  ;THROW 50000,'JsonInput must be valid JSON.',1;
 END;
 DECLARE @UserId varchar(32)=JSON_VALUE(@JsonInput,'$.userId'),@RoleCode varchar(60)=JSON_VALUE(@JsonInput,'$.roleCode'),@BranchCode varchar(60)=JSON_VALUE(@JsonInput,'$.branchCode');

 IF @Operation='GetEffectivePermissions' BEGIN
  SELECT DISTINCT rp.PermissionCode FROM dbo.CatsUsers u JOIN dbo.RolePermissionMapping rp ON rp.RoleCode=u.RoleCode AND rp.IsActive=1 JOIN dbo.PermissionMaster p ON p.Code=rp.PermissionCode AND p.IsActive=1 WHERE u.Id=@UserId AND u.IsActive=1
  UNION SELECT DISTINCT up.PermissionCode FROM dbo.UserPermissionMapping up JOIN dbo.PermissionMaster p ON p.Code=up.PermissionCode AND p.IsActive=1 WHERE up.UserId=@UserId AND up.IsActive=1; RETURN;
 END
 IF @Operation='GetDataScopes' BEGIN SELECT s.Id,s.RoleCode,s.ScopeType,s.ScopeValue,s.Priority,s.IsActive FROM dbo.DataScopeMaster s JOIN dbo.CatsUsers u ON u.RoleCode=s.RoleCode WHERE u.Id=@UserId AND s.IsActive=1 ORDER BY s.Priority; RETURN; END
 IF @Operation='GetDashboardWidgets' BEGIN
  ;WITH P AS(SELECT [value] Code FROM OPENJSON(@JsonInput,'$.permissions')), W AS(
   SELECT w.Code,w.Title,w.WidgetType,w.DrillDownUrl,m.DisplayOrder,m.Width,
    CASE UPPER(w.Code)
     WHEN 'TEMPLATES' THEN (SELECT COUNT_BIG(*) FROM dbo.Templates WHERE Status='Published')
     WHEN 'INGESTION_FAILED' THEN (SELECT COUNT_BIG(*) FROM dbo.IngestionRun WHERE Status='Failed' AND StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()))
     WHEN 'ACTIVE_ALERTS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE a.Status NOT IN('Closed','Rejected','Cancelled') AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     WHEN 'AGING_31_PLUS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=31 AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     ELSE CONVERT(bigint,0) END Value
   FROM dbo.DashboardWidgetMaster w JOIN dbo.DashboardWidgetRoleMapping m ON m.WidgetId=w.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1
   WHERE w.IsActive=1 AND (w.PermissionCode='' OR EXISTS(SELECT 1 FROM P WHERE Code=w.PermissionCode)))
  SELECT * FROM W ORDER BY DisplayOrder; RETURN;
 END
 IF @Operation='GetDashboardWidgetConfiguration' BEGIN SELECT Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive FROM dbo.DashboardWidgetMaster ORDER BY DisplayOrder; RETURN; END
 IF @Operation='SaveDashboardWidget' BEGIN
  BEGIN TRAN;
  MERGE dbo.DashboardWidgetMaster t USING(SELECT * FROM OPENJSON(@JsonInput,'$.widget') WITH(Id varchar(32),Code varchar(80),Title nvarchar(150),WidgetType varchar(30),PermissionCode varchar(100),FilterJson nvarchar(max),DrillDownUrl nvarchar(500),DisplayOrder int,Width int,IsActive int))s ON t.Id=s.Id
  WHEN MATCHED THEN UPDATE SET Code=s.Code,Title=s.Title,WidgetType=s.WidgetType,PermissionCode=s.PermissionCode,FilterJson=s.FilterJson,DrillDownUrl=s.DrillDownUrl,DisplayOrder=s.DisplayOrder,Width=s.Width,IsActive=s.IsActive
  WHEN NOT MATCHED THEN INSERT(Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive)VALUES(s.Id,s.Code,s.Title,s.WidgetType,s.PermissionCode,s.FilterJson,s.DrillDownUrl,s.DisplayOrder,s.Width,s.IsActive);
  MERGE dbo.DashboardWidgetRoleMapping t USING(SELECT JSON_VALUE(@JsonInput,'$.widget.id') WidgetId,JSON_VALUE(@JsonInput,'$.roleCode') RoleCode,CONVERT(int,JSON_VALUE(@JsonInput,'$.widget.displayOrder')) DisplayOrder,CONVERT(int,JSON_VALUE(@JsonInput,'$.widget.width')) Width)s ON t.WidgetId=s.WidgetId AND t.RoleCode=s.RoleCode
  WHEN MATCHED THEN UPDATE SET DisplayOrder=s.DisplayOrder,Width=s.Width,IsVisible=1 WHEN NOT MATCHED THEN INSERT(WidgetId,RoleCode,DisplayOrder,Width,IsVisible)VALUES(s.WidgetId,s.RoleCode,s.DisplayOrder,s.Width,1); COMMIT; RETURN;
 END
 IF @Operation='GetTemplateDashboards' BEGIN
  DECLARE @TDIncludeInactive bit=TRY_CONVERT(bit,JSON_VALUE(@JsonInput,'$.includeInactive'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d
  WHERE (@TDIncludeInactive=1 OR d.IsActive=1) AND (@TDIncludeInactive=1 OR EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))
  ORDER BY d.DisplayOrder,d.Name; RETURN;
 END
 IF @Operation='GetTemplateDashboard' BEGIN
  DECLARE @TDId varchar(32)=JSON_VALUE(@JsonInput,'$.id'),@TDRequireManage bit=TRY_CONVERT(bit,JSON_VALUE(@JsonInput,'$.requireManage'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d WHERE d.Id=@TDId AND (@TDRequireManage=1 OR (d.IsActive=1 AND EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))); RETURN;
 END
 IF @Operation='SaveTemplateDashboard' BEGIN
  BEGIN TRAN;
  MERGE dbo.TemplateDashboardMaster t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32) '$.id',Code varchar(80) '$.code',Name nvarchar(150) '$.name',Title nvarchar(250) '$.title',Description nvarchar(1000) '$.description',TemplateId varchar(32) '$.templateId',AlertType nvarchar(150) '$.alertType',GroupByFieldsJson nvarchar(max) '$.groupByFieldsJson',MetricsJson nvarchar(max) '$.metricsJson',GridColumnsJson nvarchar(max) '$.gridColumnsJson',SearchFieldsJson nvarchar(max) '$.searchFieldsJson',PageSize int '$.pageSize',DisplayOrder int '$.displayOrder',IsDefault bit '$.isDefault',IsActive bit '$.isActive'))q ON t.Id=q.Id
  WHEN MATCHED THEN UPDATE SET Code=q.Code,Name=q.Name,Title=q.Title,Description=COALESCE(q.Description,''),TemplateId=q.TemplateId,AlertType=COALESCE(q.AlertType,''),GroupByFieldsJson=q.GroupByFieldsJson,MetricsJson=q.MetricsJson,GridColumnsJson=q.GridColumnsJson,SearchFieldsJson=q.SearchFieldsJson,PageSize=q.PageSize,DisplayOrder=q.DisplayOrder,IsDefault=q.IsDefault,IsActive=q.IsActive,UpdatedAtUtc=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT(Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive) VALUES(q.Id,q.Code,q.Name,q.Title,COALESCE(q.Description,''),q.TemplateId,COALESCE(q.AlertType,''),q.GroupByFieldsJson,q.MetricsJson,q.GridColumnsJson,q.SearchFieldsJson,q.PageSize,q.DisplayOrder,q.IsDefault,q.IsActive);
  DECLARE @SavedDashboardId varchar(32)=JSON_VALUE(@JsonInput,'$.id'); DELETE FROM dbo.TemplateDashboardRoleMapping WHERE DashboardId=@SavedDashboardId;
  INSERT dbo.TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) SELECT @SavedDashboardId,[value],1 FROM OPENJSON(@JsonInput,'$.roleCodes') WHERE NULLIF([value],'') IS NOT NULL;
  COMMIT; RETURN;
 END
 IF @Operation='GetTemplateDashboardAlerts' BEGIN
  DECLARE @DTTemplateId varchar(32)=JSON_VALUE(@JsonInput,'$.templateId'),@DTAlertType nvarchar(150)=JSON_VALUE(@JsonInput,'$.alertType'),@DTUserBranch varchar(60)=JSON_VALUE(@JsonInput,'$.userBranchCode'),@DTRoleCode varchar(60)=JSON_VALUE(@JsonInput,'$.roleCode'),@DTCanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@JsonInput,'$.canViewAll'));
  SELECT TOP(5000) a.Id,a.AlertNo,a.TemplateId,a.AlertType,a.BranchCode,a.CustomerIdEncrypted,a.AccountIdEncrypted,a.Status,a.CurrentStageName,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc,a.DynamicDataJson
  FROM dbo.Alerts a WHERE a.TemplateId=@DTTemplateId AND (NULLIF(@DTAlertType,'') IS NULL OR a.AlertType=@DTAlertType) AND (@DTCanViewAll=1 OR a.BranchCode=@DTUserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND (wi.AssignedUserId=@UserId OR (wi.AssignedRoleCode=@DTRoleCode AND (wi.AssignedBranchCode='' OR wi.AssignedBranchCode=@DTUserBranch))))) ORDER BY a.CreatedAtUtc DESC; RETURN;
 END
 IF @Operation='GetConnectors' BEGIN SELECT Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive FROM dbo.IngestionConnector ORDER BY Name; RETURN; END
 IF @Operation='SaveConnector' BEGIN
  MERGE dbo.IngestionConnector t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32),Name nvarchar(150),ConnectorType varchar(30),Host nvarchar(300),Port int,DatabaseName nvarchar(200),UserName nvarchar(200),SecretEncrypted nvarchar(2000),ExtraJson nvarchar(max),IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ConnectorType=s.ConnectorType,Host=s.Host,Port=s.Port,DatabaseName=s.DatabaseName,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,ExtraJson=s.ExtraJson,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive)VALUES(s.Id,s.Name,s.ConnectorType,s.Host,s.Port,s.DatabaseName,s.UserName,s.SecretEncrypted,s.ExtraJson,s.IsActive); RETURN;
 END
 IF @Operation='GetIngestionConfigurations' BEGIN SELECT Id,Name,TemplateId,SourceType,ConnectorId,FilePattern,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive FROM dbo.IngestionConfiguration ORDER BY Name; RETURN; END
 IF @Operation='SaveIngestionConfiguration' BEGIN
  MERGE dbo.IngestionConfiguration t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32),Name nvarchar(150),TemplateId varchar(32),SourceType varchar(30),ConnectorId varchar(32),FilePattern nvarchar(260),ScheduleCron varchar(100),QueryText nvarchar(max),FieldMappingJson nvarchar(max),DuplicateKeyFields nvarchar(500),ArchivePath nvarchar(500),ErrorPath nvarchar(500),IntervalMinutes int,IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,TemplateId=s.TemplateId,SourceType=s.SourceType,ConnectorId=s.ConnectorId,FilePattern=s.FilePattern,ScheduleCron=s.ScheduleCron,QueryText=s.QueryText,FieldMappingJson=s.FieldMappingJson,DuplicateKeyFields=s.DuplicateKeyFields,ArchivePath=s.ArchivePath,ErrorPath=s.ErrorPath,IntervalMinutes=s.IntervalMinutes,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,TemplateId,SourceType,ConnectorId,FilePattern,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive)VALUES(s.Id,s.Name,s.TemplateId,s.SourceType,s.ConnectorId,s.FilePattern,s.ScheduleCron,s.QueryText,s.FieldMappingJson,s.DuplicateKeyFields,s.ArchivePath,s.ErrorPath,s.IntervalMinutes,s.IsActive); RETURN;
 END
 IF @Operation='GetIngestionDashboard' BEGIN SELECT (SELECT COUNT(*) FROM dbo.IngestionConfiguration WHERE IsActive=1)ActiveConfigurations,COUNT(*)RunsToday,COALESCE(SUM(CASE WHEN Status='Success' THEN 1 ELSE 0 END),0)SuccessfulToday,COALESCE(SUM(CASE WHEN Status='Failed' THEN 1 ELSE 0 END),0)FailedToday,COALESCE(SUM(RowsInserted),0)RowsInsertedToday FROM dbo.IngestionRun WHERE StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()); RETURN; END
 IF @Operation='GetIngestionRuns' BEGIN DECLARE @Take int=CONVERT(int,JSON_VALUE(@JsonInput,'$.take')); SELECT TOP(@Take) Id,ConfigurationId,SourceReference,StartedAtUtc,EndedAtUtc,RowsRead,RowsInserted,RowsDuplicate,RowsFailed,Status,ErrorMessage FROM dbo.IngestionRun ORDER BY StartedAtUtc DESC; RETURN; END
 IF @Operation='GetMailConfigurations' BEGIN SELECT Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive FROM dbo.MailConfiguration ORDER BY Name; RETURN; END
 IF @Operation='SaveMailConfiguration' BEGIN
  MERGE dbo.MailConfiguration t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32),Name nvarchar(150),ProviderType varchar(30),Host nvarchar(300),Port int,UserName nvarchar(200),SecretEncrypted nvarchar(2000),FromAddress nvarchar(300),UseSsl int,IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ProviderType=s.ProviderType,Host=s.Host,Port=s.Port,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,FromAddress=s.FromAddress,UseSsl=s.UseSsl,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive)VALUES(s.Id,s.Name,s.ProviderType,s.Host,s.Port,s.UserName,s.SecretEncrypted,s.FromAddress,s.UseSsl,s.IsActive); RETURN;
 END
 IF @Operation='GetMailTemplates' BEGIN SELECT Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive FROM dbo.MailTemplate ORDER BY EventCode; RETURN; END
 IF @Operation='GetMailLogs' BEGIN DECLARE @MailTake int=CONVERT(int,JSON_VALUE(@JsonInput,'$.take')); SELECT TOP(@MailTake) Id,EventCode,AlertId,ToAddress,Subject,Status,Attempts,CreatedAtUtc,SentAtUtc,ErrorMessage FROM dbo.MailQueue ORDER BY CreatedAtUtc DESC; RETURN; END
 IF @Operation='SaveMailTemplate' BEGIN
  MERGE dbo.MailTemplate t USING(SELECT * FROM OPENJSON(@JsonInput) WITH(Id varchar(32) '$.id',TemplateId varchar(32) '$.templateId',EventCode varchar(80) '$.eventCode',SubjectTemplate nvarchar(500) '$.subjectTemplate',BodyTemplate nvarchar(max) '$.bodyTemplate',UseMafEnrichment bit '$.useMafEnrichment',IsActive bit '$.isActive'))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET TemplateId=s.TemplateId,EventCode=s.EventCode,SubjectTemplate=s.SubjectTemplate,BodyTemplate=s.BodyTemplate,UseMafEnrichment=COALESCE(s.UseMafEnrichment,0),IsActive=COALESCE(s.IsActive,1) WHEN NOT MATCHED THEN INSERT(Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive)VALUES(s.Id,s.TemplateId,s.EventCode,s.SubjectTemplate,s.BodyTemplate,COALESCE(s.UseMafEnrichment,0),COALESCE(s.IsActive,1)); RETURN;
 END
 IF @Operation IN('GetReport','GetReportCount') BEGIN
  DECLARE @ReportType varchar(20)=JSON_VALUE(@JsonInput,'$.reportType'),@TemplateId varchar(32)=JSON_VALUE(@JsonInput,'$.templateId'),@AlertType nvarchar(150)=JSON_VALUE(@JsonInput,'$.alertType'),@FilterBranch varchar(60)=JSON_VALUE(@JsonInput,'$.branchCode'),@UserBranch varchar(60)=JSON_VALUE(@JsonInput,'$.userBranchCode'),@Status varchar(30)=JSON_VALUE(@JsonInput,'$.status'),@FromDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@JsonInput,'$.fromDate')),@ToDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@JsonInput,'$.toDate')),@Page int=CONVERT(int,JSON_VALUE(@JsonInput,'$.page')),@PageSize int=CONVERT(int,JSON_VALUE(@JsonInput,'$.pageSize')),@CanViewAll bit=CONVERT(bit,JSON_VALUE(@JsonInput,'$.canViewAll'));
  IF @Operation='GetReportCount' BEGIN SELECT COUNT(*) FROM dbo.Alerts a WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId)) AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId) AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType) AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch) AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status) AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate) AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate))); RETURN; END
  IF UPPER(@ReportType)='MIS' SELECT a.AlertType,a.Status,COUNT(*) Total FROM dbo.Alerts a WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId)) AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId) AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType) AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch) AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status) AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate) AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate))) GROUP BY a.AlertType,a.Status ORDER BY a.AlertType,a.Status;
  ELSE SELECT a.AlertNo,a.AlertType,t.Name TemplateName,a.BranchCode,a.CurrentStageName,a.Status,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc FROM dbo.Alerts a JOIN dbo.Templates t ON t.Id=a.TemplateId WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId)) AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId) AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType) AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch) AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status) AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate) AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate))) ORDER BY a.CreatedAtUtc DESC OFFSET (@Page-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY; RETURN;
 END
 ;THROW 50000,'Unsupported platform repository operation.',1;
END
GO

MERGE dbo.PermissionMaster AS t USING (VALUES
 ('TEMPLATE.MANAGE','Manage templates','Templates'),('WORKFLOW.MANAGE','Manage workflows','Workflow'),('ALERT.UPLOAD','Create/upload alerts','Alerts'),('ALERT.VIEWALL','View all scoped alerts','Alerts'),('ALERT.REASSIGN','Reassign alerts','Alerts'),('PI.UNMASK','Unmask PI data','Security'),('AUDIT.VIEW','View audit trail','Audit'),('DASHBOARD.VIEW','View dashboard','Dashboard'),('DASHBOARD.CONFIGURE','Configure dashboard','Dashboard'),('INGESTION.VIEW','View ingestion','Ingestion'),('INGESTION.MANAGE','Manage ingestion','Ingestion'),('REPORT.MIS','MIS report','Reports'),('REPORT.ALERTWISE','Alert wise report','Reports'),('REPORT.ALL','All alerts report','Reports'),('MAIL.MANAGE','Manage mail','Mail'),('SECURITY.MANAGE','Manage roles/permissions/data scopes','Security')
) s(Code,Name,Category) ON t.Code=s.Code WHEN NOT MATCHED THEN INSERT(Code,Name,Category,IsActive) VALUES(s.Code,s.Name,s.Category,1);
GO

/* Default role permissions are database configuration, not code bypasses. */
MERGE dbo.RolePermissionMapping AS t USING (VALUES
 ('ADMIN','TEMPLATE.MANAGE'),('ADMIN','WORKFLOW.MANAGE'),('ADMIN','ALERT.UPLOAD'),('ADMIN','ALERT.VIEWALL'),('ADMIN','ALERT.REASSIGN'),('ADMIN','PI.UNMASK'),('ADMIN','AUDIT.VIEW'),('ADMIN','DASHBOARD.VIEW'),('ADMIN','DASHBOARD.CONFIGURE'),('ADMIN','INGESTION.VIEW'),('ADMIN','INGESTION.MANAGE'),('ADMIN','REPORT.MIS'),('ADMIN','REPORT.ALERTWISE'),('ADMIN','REPORT.ALL'),('ADMIN','MAIL.MANAGE'),('ADMIN','SECURITY.MANAGE'),
 ('CENTRAL','TEMPLATE.MANAGE'),('CENTRAL','WORKFLOW.MANAGE'),('CENTRAL','ALERT.UPLOAD'),('CENTRAL','ALERT.VIEWALL'),('CENTRAL','ALERT.REASSIGN'),('CENTRAL','AUDIT.VIEW'),('CENTRAL','DASHBOARD.VIEW'),('CENTRAL','DASHBOARD.CONFIGURE'),('CENTRAL','INGESTION.VIEW'),('CENTRAL','INGESTION.MANAGE'),('CENTRAL','REPORT.MIS'),('CENTRAL','REPORT.ALERTWISE'),('CENTRAL','REPORT.ALL'),('CENTRAL','MAIL.MANAGE'),
 ('DT_USER','DASHBOARD.VIEW'),('DT_CHECKER','AUDIT.VIEW'),('DT_CHECKER','DASHBOARD.VIEW'),('DT_VERIFIER','AUDIT.VIEW'),('DT_VERIFIER','DASHBOARD.VIEW'),('AUDITOR','ALERT.VIEWALL'),('AUDITOR','AUDIT.VIEW'),('AUDITOR','DASHBOARD.VIEW'),('AUDITOR','REPORT.MIS'),('AUDITOR','REPORT.ALERTWISE'),('AUDITOR','REPORT.ALL')
) s(RoleCode,PermissionCode) ON t.RoleCode=s.RoleCode AND t.PermissionCode=s.PermissionCode
WHEN NOT MATCHED THEN INSERT(RoleCode,PermissionCode,IsActive) VALUES(s.RoleCode,s.PermissionCode,1);
GO
/* Preserve existing per-user permissions by migrating CatsUsers.PermissionsJson into the DB mapping. */
INSERT dbo.UserPermissionMapping(UserId,PermissionCode,IsActive)
SELECT u.Id,j.[value],1 FROM dbo.CatsUsers u CROSS APPLY OPENJSON(COALESCE(u.PermissionsJson,N'[]')) j
JOIN dbo.PermissionMaster p ON p.Code=j.[value] AND p.IsActive=1
WHERE NOT EXISTS(SELECT 1 FROM dbo.UserPermissionMapping x WHERE x.UserId=u.Id AND x.PermissionCode=j.[value]);
GO
MERGE dbo.DataScopeMaster AS t USING (VALUES
 ('scope-admin-all','ADMIN','ALL','',1),('scope-central-all','CENTRAL','ALL','',1),('scope-dtuser-branch','DT_USER','BRANCH','',10),('scope-checker-branch','DT_CHECKER','BRANCH','',10),('scope-verifier-branch','DT_VERIFIER','BRANCH','',10),('scope-auditor-all','AUDITOR','ALL','',10)
) s(Id,RoleCode,ScopeType,ScopeValue,Priority) ON t.Id=s.Id
WHEN NOT MATCHED THEN INSERT(Id,RoleCode,ScopeType,ScopeValue,Priority,IsActive) VALUES(s.Id,s.RoleCode,s.ScopeType,s.ScopeValue,s.Priority,1);
GO

