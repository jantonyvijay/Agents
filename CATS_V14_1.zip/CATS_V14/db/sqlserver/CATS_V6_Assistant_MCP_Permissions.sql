SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
MERGE dbo.PermissionMaster AS t
USING (VALUES
 ('ASSISTANT.USE','Use read-only CATS AI assistant','AI'),
 ('MCP.MANAGE','Discover and manage MCP servers','AI')
) s(Code,Name,Category)
ON t.Code=s.Code
WHEN NOT MATCHED THEN INSERT(Code,Name,Category,IsActive) VALUES(s.Code,s.Name,s.Category,1)
WHEN MATCHED THEN UPDATE SET Name=s.Name,Category=s.Category,IsActive=1;
GO
MERGE dbo.RolePermissionMapping AS t
USING (VALUES
 ('ADMIN','ASSISTANT.USE'),('ADMIN','MCP.MANAGE'),('CENTRAL','ASSISTANT.USE')
) s(RoleCode,PermissionCode)
ON t.RoleCode=s.RoleCode AND t.PermissionCode=s.PermissionCode
WHEN NOT MATCHED THEN INSERT(RoleCode,PermissionCode,IsActive) VALUES(s.RoleCode,s.PermissionCode,1)
WHEN MATCHED THEN UPDATE SET IsActive=1;
GO
