-- Persist the existing Template ViewConfigurationJson payload on template updates.
-- Run once against existing SQL Server deployments that use module 12_Template.sql.
CREATE OR ALTER PROCEDURE dbo.USP_Template_Save
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF ISJSON(COALESCE(@strJson,N''))<>1 THROW 50000,'strJson must be valid JSON.',1;
    DECLARE @Id varchar(32)=JSON_VALUE(@strJson,'$.id'), @Code varchar(80)=JSON_VALUE(@strJson,'$.code'), @Name nvarchar(250)=JSON_VALUE(@strJson,'$.name'), @ExecutionMode varchar(30)=COALESCE(JSON_VALUE(@strJson,'$.executionMode'),'Deterministic'), @SectionsJson nvarchar(max)=COALESCE(JSON_QUERY(@strJson,'$.sectionsJson'),JSON_VALUE(@strJson,'$.sectionsJson'),N'[]'), @FieldsJson nvarchar(max)=COALESCE(JSON_QUERY(@strJson,'$.fieldsJson'),JSON_VALUE(@strJson,'$.fieldsJson'),N'[]'), @AssignmentRulesJson nvarchar(max)=COALESCE(JSON_QUERY(@strJson,'$.assignmentRulesJson'),JSON_VALUE(@strJson,'$.assignmentRulesJson'),N'[]'), @ViewConfigurationJson nvarchar(max)=COALESCE(JSON_QUERY(@strJson,'$.viewConfigurationJson'),JSON_VALUE(@strJson,'$.viewConfigurationJson'),N'{}'), @CreatedBy varchar(100)=COALESCE(JSON_VALUE(@strJson,'$.createdBy'),'SYSTEM'), @NowUtc datetime2(7)=COALESCE(TRY_CONVERT(datetime2(7),JSON_VALUE(@strJson,'$.nowUtc')),SYSUTCDATETIME()), @NewId varchar(32), @NextVersion int;
    IF ISJSON(@SectionsJson)<>1 OR ISJSON(@FieldsJson)<>1 OR ISJSON(@AssignmentRulesJson)<>1 OR ISJSON(@ViewConfigurationJson)<>1 THROW 50002,'Template configuration JSON is invalid.',1;
    IF NULLIF(LTRIM(RTRIM(@Id)),'') IS NOT NULL BEGIN UPDATE dbo.Templates SET Code=@Code,Name=@Name,ExecutionMode=@ExecutionMode,SectionsJson=@SectionsJson,FieldsJson=CASE WHEN @FieldsJson=N'[]' AND FieldsJson<>N'[]' THEN FieldsJson ELSE @FieldsJson END,AssignmentRulesJson=@AssignmentRulesJson,ViewConfigurationJson=CASE WHEN @ViewConfigurationJson=N'{}' AND ViewConfigurationJson<>N'{}' THEN ViewConfigurationJson ELSE @ViewConfigurationJson END WHERE Id=@Id; SET @NewId=@Id; END
    ELSE BEGIN SELECT @NextVersion=COALESCE(MAX(Version),0)+1 FROM dbo.Templates WHERE UPPER(Code)=UPPER(@Code); SET @NewId=LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-','')); INSERT dbo.Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy) VALUES(@NewId,@Code,@Name,@NextVersion,'Draft',@ExecutionMode,@SectionsJson,@FieldsJson,@AssignmentRulesJson,@ViewConfigurationJson,NULL,@NowUtc,@CreatedBy); END;
    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy FROM dbo.Templates WHERE Id=@NewId;
END
GO