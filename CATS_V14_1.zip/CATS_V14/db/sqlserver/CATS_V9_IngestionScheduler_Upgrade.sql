/* CATS V9 - SFTP/query ingestion sources and multiple scheduler triggers per task. */
SET XACT_ABORT ON;
GO

IF OBJECT_ID('dbo.IngestionConfiguration','U') IS NULL
    THROW 50000, 'dbo.IngestionConfiguration must exist before running this upgrade.', 1;
GO

IF COL_LENGTH('dbo.IngestionConfiguration','FilePath') IS NULL
    ALTER TABLE dbo.IngestionConfiguration ADD FilePath nvarchar(500) NOT NULL CONSTRAINT DF_IngestionConfiguration_FilePath_V9 DEFAULT N'' WITH VALUES;
IF COL_LENGTH('dbo.IngestionConfiguration','FileName') IS NULL
    ALTER TABLE dbo.IngestionConfiguration ADD FileName nvarchar(260) NOT NULL CONSTRAINT DF_IngestionConfiguration_FileName_V9 DEFAULT N'' WITH VALUES;
IF COL_LENGTH('dbo.IngestionConfiguration','ScheduleTriggersJson') IS NULL
    ALTER TABLE dbo.IngestionConfiguration ADD ScheduleTriggersJson nvarchar(max) NOT NULL CONSTRAINT DF_IngestionConfiguration_ScheduleTriggersJson_V9 DEFAULT N'[]' WITH VALUES;
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetConfigurations
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id,Name,TemplateId,SourceType,ConnectorId,FilePath,FileName,FilePattern,ScheduleTriggersJson,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive
    FROM dbo.IngestionConfiguration
    ORDER BY Name;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_SaveConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson=COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson)<>1 THROW 50000,'strJson must be valid JSON.',1;

    MERGE dbo.IngestionConfiguration t
    USING(SELECT * FROM OPENJSON(@strJson) WITH(
      Id varchar(32) '$.id',Name nvarchar(150) '$.name',TemplateId varchar(32) '$.templateId',SourceType varchar(30) '$.sourceType',ConnectorId varchar(32) '$.connectorId',
      FilePath nvarchar(500) '$.filePath',FileName nvarchar(260) '$.fileName',FilePattern nvarchar(260) '$.filePattern',ScheduleTriggersJson nvarchar(max) '$.scheduleTriggersJson',
      ScheduleCron varchar(100) '$.scheduleCron',QueryText nvarchar(max) '$.queryText',FieldMappingJson nvarchar(max) '$.fieldMappingJson',DuplicateKeyFields nvarchar(500) '$.duplicateKeyFields',
      ArchivePath nvarchar(500) '$.archivePath',ErrorPath nvarchar(500) '$.errorPath',IntervalMinutes int '$.intervalMinutes',IsActive int '$.isActive'
    ))s ON t.Id=s.Id
    WHEN MATCHED THEN UPDATE SET Name=s.Name,TemplateId=s.TemplateId,SourceType=s.SourceType,ConnectorId=s.ConnectorId,FilePath=COALESCE(s.FilePath,N''),FileName=COALESCE(s.FileName,N''),FilePattern=COALESCE(s.FilePattern,N''),ScheduleTriggersJson=COALESCE(s.ScheduleTriggersJson,N'[]'),ScheduleCron=COALESCE(s.ScheduleCron,''),QueryText=COALESCE(s.QueryText,N''),FieldMappingJson=COALESCE(s.FieldMappingJson,N'{}'),DuplicateKeyFields=COALESCE(s.DuplicateKeyFields,N''),ArchivePath=COALESCE(s.ArchivePath,N''),ErrorPath=COALESCE(s.ErrorPath,N''),IntervalMinutes=COALESCE(s.IntervalMinutes,1),IsActive=COALESCE(s.IsActive,1)
    WHEN NOT MATCHED THEN INSERT(Id,Name,TemplateId,SourceType,ConnectorId,FilePath,FileName,FilePattern,ScheduleTriggersJson,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive)
    VALUES(s.Id,s.Name,s.TemplateId,s.SourceType,s.ConnectorId,COALESCE(s.FilePath,N''),COALESCE(s.FileName,N''),COALESCE(s.FilePattern,N''),COALESCE(s.ScheduleTriggersJson,N'[]'),COALESCE(s.ScheduleCron,''),COALESCE(s.QueryText,N''),COALESCE(s.FieldMappingJson,N'{}'),COALESCE(s.DuplicateKeyFields,N''),COALESCE(s.ArchivePath,N''),COALESCE(s.ErrorPath,N''),COALESCE(s.IntervalMinutes,1),COALESCE(s.IsActive,1));
END
GO
