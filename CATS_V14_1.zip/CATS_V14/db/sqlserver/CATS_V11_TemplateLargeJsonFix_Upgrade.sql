SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
    CATS V11 hotfix - Template large JSON persistence.

    Root cause:
      The application previously passed FieldsJson / ViewConfigurationJson as JSON strings
      embedded inside the repository request JSON. SQL Server JSON_VALUE returns nvarchar(4000),
      so a payload larger than 4,000 characters became NULL in lax mode and the save procedure
      fell back to [] / {}.

    This procedure accepts BOTH formats:
      1. New format: fieldsJson is a real JSON array, viewConfigurationJson is a JSON object.
      2. Legacy format: those values are escaped JSON strings, including values > 4,000 chars.

    OPENJSON with nvarchar(max) is used for the legacy scalar fallback so there is no 4K limit.
*/

IF COL_LENGTH('dbo.Templates','ViewConfigurationJson') IS NULL
    ALTER TABLE dbo.Templates ADD ViewConfigurationJson nvarchar(max) NOT NULL
        CONSTRAINT DF_Templates_ViewConfigurationJson_V11 DEFAULT N'{}' WITH VALUES;
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetAll
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates
    ORDER BY Name,Version DESC;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetById
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Id varchar(32)=JSON_VALUE(COALESCE(@strJson,N'{}'),'$.id');
    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates
    WHERE Id=@Id;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_Save
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson=COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson)<>1 THROW 50000,'strJson must be valid JSON.',1;

    DECLARE
        @Id varchar(32)=JSON_VALUE(@strJson,'$.id'),
        @Code varchar(80)=JSON_VALUE(@strJson,'$.code'),
        @Name nvarchar(250)=JSON_VALUE(@strJson,'$.name'),
        @ExecutionMode varchar(30)=COALESCE(JSON_VALUE(@strJson,'$.executionMode'),'Deterministic'),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @ViewConfigurationJson nvarchar(max),
        @CreatedBy varchar(100)=COALESCE(JSON_VALUE(@strJson,'$.createdBy'),'SYSTEM'),
        @NowUtc datetime2(7)=TRY_CONVERT(datetime2(7),JSON_VALUE(@strJson,'$.nowUtc')),
        @NewId varchar(32),
        @NextVersion int;

    /*
       JSON_QUERY handles the new nested JSON shape.
       OPENJSON/nvarchar(max) handles the legacy escaped-string shape without JSON_VALUE's 4K cap.
    */
    SELECT
        @SectionsJson=COALESCE(JSON_QUERY(@strJson,'$.sectionsJson'),j.sectionsText,N'[]'),
        @FieldsJson=COALESCE(JSON_QUERY(@strJson,'$.fieldsJson'),j.fieldsText,N'[]'),
        @AssignmentRulesJson=COALESCE(JSON_QUERY(@strJson,'$.assignmentRulesJson'),j.assignmentRulesText,N'[]'),
        @ViewConfigurationJson=COALESCE(JSON_QUERY(@strJson,'$.viewConfigurationJson'),j.viewConfigurationText,N'{}')
    FROM OPENJSON(@strJson)
    WITH
    (
        sectionsText nvarchar(max) '$.sectionsJson',
        fieldsText nvarchar(max) '$.fieldsJson',
        assignmentRulesText nvarchar(max) '$.assignmentRulesJson',
        viewConfigurationText nvarchar(max) '$.viewConfigurationJson'
    ) j;

    SET @NowUtc=COALESCE(@NowUtc,SYSUTCDATETIME());

    IF NULLIF(LTRIM(RTRIM(@Code)),'') IS NULL OR NULLIF(LTRIM(RTRIM(@Name)),'') IS NULL
        THROW 50001,'Template code and name are required.',1;

    IF ISJSON(@SectionsJson)<>1 OR ISJSON(@FieldsJson)<>1 OR ISJSON(@AssignmentRulesJson)<>1 OR ISJSON(@ViewConfigurationJson)<>1
        THROW 50002,'Template configuration JSON is invalid.',1;

    IF NULLIF(LTRIM(RTRIM(@Id)),'') IS NOT NULL
    BEGIN
        IF NOT EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id)
            THROW 50003,'The template to update was not found.',1;
        IF EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id AND Status='Retired')
            THROW 50004,'Retired templates cannot be modified.',1;

        UPDATE dbo.Templates
        SET Code=@Code,
            Name=@Name,
            ExecutionMode=@ExecutionMode,
            SectionsJson=@SectionsJson,
            FieldsJson=@FieldsJson,
            AssignmentRulesJson=@AssignmentRulesJson,
            ViewConfigurationJson=@ViewConfigurationJson
        WHERE Id=@Id;
        SET @NewId=@Id;
    END
    ELSE
    BEGIN
        SELECT @NextVersion=COALESCE(MAX(Version),0)+1
        FROM dbo.Templates
        WHERE UPPER(Code)=UPPER(@Code);

        SET @NewId=LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-',''));

        INSERT dbo.Templates
            (Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,
             AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy)
        VALUES
            (@NewId,@Code,@Name,@NextVersion,'Draft',@ExecutionMode,@SectionsJson,@FieldsJson,
             @AssignmentRulesJson,@ViewConfigurationJson,NULL,@NowUtc,@CreatedBy);
    END;

    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates
    WHERE Id=@NewId;
END
GO

/* Optional check after deployment:
SELECT Id,Code,LEN(FieldsJson) FieldsLength,LEN(ViewConfigurationJson) ViewConfigurationLength,
       CASE WHEN ISJSON(FieldsJson)=1 THEN 1 ELSE 0 END FieldsJsonValid,
       CASE WHEN ISJSON(ViewConfigurationJson)=1 THEN 1 ELSE 0 END ViewConfigurationJsonValid
FROM dbo.Templates
WHERE Code='DT_DD_MONEY_MULE';
*/
