-- Rename the legacy permission while preserving active and inactive assignments.
-- Run once against an existing SQL Server CATS database before starting the new app.
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF NOT EXISTS(SELECT 1 FROM dbo.PermissionMaster WHERE Code='PI.UNMASK')
 INSERT dbo.PermissionMaster(Code,Name,Category,IsActive)
 SELECT 'PI.UNMASK','Unmask PI data',Category,IsActive FROM dbo.PermissionMaster WHERE Code='PII.UNMASK';
UPDATE n SET IsActive=CASE WHEN n.IsActive=1 OR o.IsActive=1 THEN 1 ELSE 0 END
 FROM dbo.RolePermissionMapping n JOIN dbo.RolePermissionMapping o ON o.RoleCode=n.RoleCode
 WHERE n.PermissionCode='PI.UNMASK' AND o.PermissionCode='PII.UNMASK';
INSERT dbo.RolePermissionMapping(RoleCode,PermissionCode,IsActive)
 SELECT o.RoleCode,'PI.UNMASK',o.IsActive FROM dbo.RolePermissionMapping o
 WHERE o.PermissionCode='PII.UNMASK' AND NOT EXISTS(SELECT 1 FROM dbo.RolePermissionMapping n WHERE n.RoleCode=o.RoleCode AND n.PermissionCode='PI.UNMASK');
DELETE FROM dbo.RolePermissionMapping WHERE PermissionCode='PII.UNMASK';
UPDATE n SET IsActive=CASE WHEN n.IsActive=1 OR o.IsActive=1 THEN 1 ELSE 0 END
 FROM dbo.UserPermissionMapping n JOIN dbo.UserPermissionMapping o ON o.UserId=n.UserId
 WHERE n.PermissionCode='PI.UNMASK' AND o.PermissionCode='PII.UNMASK';
INSERT dbo.UserPermissionMapping(UserId,PermissionCode,IsActive)
 SELECT o.UserId,'PI.UNMASK',o.IsActive FROM dbo.UserPermissionMapping o
 WHERE o.PermissionCode='PII.UNMASK' AND NOT EXISTS(SELECT 1 FROM dbo.UserPermissionMapping n WHERE n.UserId=o.UserId AND n.PermissionCode='PI.UNMASK');
DELETE FROM dbo.UserPermissionMapping WHERE PermissionCode='PII.UNMASK';
UPDATE dbo.CatsUsers SET PermissionsJson=REPLACE(PermissionsJson,'"PII.UNMASK"','"PI.UNMASK"') WHERE PermissionsJson LIKE '%PII.UNMASK%';
UPDATE dbo.DashboardWidgetMaster SET PermissionCode='PI.UNMASK' WHERE PermissionCode='PII.UNMASK';
DELETE FROM dbo.PermissionMaster WHERE Code='PII.UNMASK';
COMMIT TRANSACTION;
GO
