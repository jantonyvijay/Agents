SET NOCOUNT ON;
SET XACT_ABORT ON;
GO


/* ===== CATS V9 Template presentation / advanced field configuration ===== */
IF COL_LENGTH('dbo.Templates','ViewConfigurationJson') IS NULL
    ALTER TABLE dbo.Templates ADD ViewConfigurationJson nvarchar(max) NOT NULL CONSTRAINT DF_Templates_ViewConfigurationJson_V9B DEFAULT N'{}' WITH VALUES;
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetAll
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates
    ORDER BY Name,Version DESC;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_GetById
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Id varchar(32)=JSON_VALUE(COALESCE(@strJson,N'{}'),'$.id');
    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates WHERE Id=@Id;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Template_Save
    @strJson nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF ISJSON(COALESCE(@strJson,N''))<>1 THROW 50000,'strJson must be valid JSON.',1;
    DECLARE @Id varchar(32)=JSON_VALUE(@strJson,'$.id'),
            @Code varchar(80)=JSON_VALUE(@strJson,'$.code'),
            @Name nvarchar(250)=JSON_VALUE(@strJson,'$.name'),
            @ExecutionMode varchar(30)=COALESCE(JSON_VALUE(@strJson,'$.executionMode'),'Deterministic'),
            @SectionsJson nvarchar(max)=COALESCE(JSON_QUERY(@strJson,'$.sectionsJson'),JSON_VALUE(@strJson,'$.sectionsJson'),N'[]'),
            @FieldsJson nvarchar(max)=COALESCE(JSON_QUERY(@strJson,'$.fieldsJson'),JSON_VALUE(@strJson,'$.fieldsJson'),N'[]'),
            @AssignmentRulesJson nvarchar(max)=COALESCE(JSON_QUERY(@strJson,'$.assignmentRulesJson'),JSON_VALUE(@strJson,'$.assignmentRulesJson'),N'[]'),
            @ViewConfigurationJson nvarchar(max)=COALESCE(JSON_QUERY(@strJson,'$.viewConfigurationJson'),JSON_VALUE(@strJson,'$.viewConfigurationJson'),N'{}'),
            @CreatedBy varchar(100)=COALESCE(JSON_VALUE(@strJson,'$.createdBy'),'SYSTEM'),
            @NowUtc datetime2(7)=TRY_CONVERT(datetime2(7),JSON_VALUE(@strJson,'$.nowUtc')),
            @NewId varchar(32), @NextVersion int;
    SET @NowUtc=COALESCE(@NowUtc,SYSUTCDATETIME());
    IF NULLIF(LTRIM(RTRIM(@Code)),'') IS NULL OR NULLIF(LTRIM(RTRIM(@Name)),'') IS NULL THROW 50001,'Template code and name are required.',1;
    IF ISJSON(@SectionsJson)<>1 OR ISJSON(@FieldsJson)<>1 OR ISJSON(@AssignmentRulesJson)<>1 OR ISJSON(@ViewConfigurationJson)<>1 THROW 50002,'Template configuration JSON is invalid.',1;

    IF NULLIF(LTRIM(RTRIM(@Id)),'') IS NOT NULL
    BEGIN
        IF NOT EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id)
            THROW 50003,'The template to update was not found.',1;
        IF EXISTS(SELECT 1 FROM dbo.Templates WHERE Id=@Id AND Status='Retired')
            THROW 50004,'Retired templates cannot be modified.',1;

        UPDATE dbo.Templates SET Code=@Code,Name=@Name,ExecutionMode=@ExecutionMode,SectionsJson=@SectionsJson,
            FieldsJson=@FieldsJson,AssignmentRulesJson=@AssignmentRulesJson,ViewConfigurationJson=@ViewConfigurationJson
        WHERE Id=@Id;
        SET @NewId=@Id;
    END
    ELSE
    BEGIN
        SELECT @NextVersion=COALESCE(MAX(Version),0)+1 FROM dbo.Templates WHERE UPPER(Code)=UPPER(@Code);
        SET @NewId=LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-',''));
        INSERT dbo.Templates(Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy)
        VALUES(@NewId,@Code,@Name,@NextVersion,'Draft',@ExecutionMode,@SectionsJson,@FieldsJson,@AssignmentRulesJson,@ViewConfigurationJson,NULL,@NowUtc,@CreatedBy);
    END;
    SELECT Id,Code,Name,Version,Status,ExecutionMode,SectionsJson,FieldsJson,AssignmentRulesJson,
           ViewConfigurationJson,PublishedWorkflowId,CreatedAtUtc,CreatedBy
    FROM dbo.Templates WHERE Id=@NewId;
END
GO
