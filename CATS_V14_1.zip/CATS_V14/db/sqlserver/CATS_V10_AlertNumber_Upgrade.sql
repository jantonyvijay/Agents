-- Compact legacy alert numbers to a deterministic 20-character format.
-- Run once against an existing SQL Server CATS database before deploying the new alert-number format.
SET XACT_ABORT ON;
BEGIN TRANSACTION;

;WITH LegacyAlerts AS
(
    SELECT Id,
           ROW_NUMBER() OVER (ORDER BY Id) AS SequenceNumber
    FROM dbo.Alerts
    WHERE LEN(AlertNo) > 20
)
UPDATE alerts
SET AlertNo = 'ALT-E' + RIGHT(REPLICATE('0', 15) + CONVERT(varchar(15), legacy.SequenceNumber), 15)
FROM dbo.Alerts alerts
JOIN LegacyAlerts legacy ON legacy.Id = alerts.Id;

COMMIT TRANSACTION;
GO