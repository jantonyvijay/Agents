/* CATS V10 / SQL Server: clear alert transactions, optionally template definitions.
   Select the intended CATS database in SSMS before running.
   Stop application/ingestion/mail workers while running this maintenance script.
   This file is standalone maintenance SQL: do not add it to schema/bootstrap scripts.

   @DeleteTemplates = 0: transactions only; all templates/configuration retained.
   @DeleteTemplates = 1: additionally removes Templates, WorkflowDefinitions,
     TemplateDashboardMaster, TemplateDashboardRoleMapping and IngestionConfiguration.
     These are template-specific configuration, NOT user/security masters.

   Retained: CatsUsers, RoleMaster, PermissionMaster, RolePermissionMapping,
   UserPermissionMapping, DataScopeMaster, AgingBuckets, DashboardWidgetMaster,
   DashboardWidgetRoleMapping, IngestionConnector, MailConfiguration, MailTemplate.
   User/security/login audit records are retained. Attachment files on disk are not deleted.
   DELETE is required because SQL Server foreign keys prevent TRUNCATE of parent tables.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @DeleteTemplates bit = 0;
DECLARE @CommitChanges bit = 0; -- 0 = preview counts only; 1 = perform deletion

IF DB_NAME() IN ('master','model','msdb','tempdb')
    THROW 50001, 'Select the intended CATS application database first.', 1;
IF OBJECT_ID('dbo.Alerts','U') IS NULL OR OBJECT_ID('dbo.Templates','U') IS NULL
    THROW 50002, 'Required CATS tables were not found.', 1;

SELECT DB_NAME() AS TargetDatabase, @DeleteTemplates AS DeleteTemplates,
       @CommitChanges AS CommitChanges;
SELECT 'WorkItems' AS TableName, COUNT_BIG(*) AS RowsToDelete FROM dbo.WorkItems
UNION ALL SELECT 'AlertQueries', COUNT_BIG(*) FROM dbo.AlertQueries
UNION ALL SELECT 'Attachments (metadata only)', COUNT_BIG(*) FROM dbo.Attachments
UNION ALL SELECT 'WorkflowInstances', COUNT_BIG(*) FROM dbo.WorkflowInstances
UNION ALL SELECT 'Alerts', COUNT_BIG(*) FROM dbo.Alerts
UNION ALL SELECT 'IngestionStaging', COUNT_BIG(*) FROM dbo.IngestionStaging
UNION ALL SELECT 'IngestionRun', COUNT_BIG(*) FROM dbo.IngestionRun
UNION ALL SELECT 'MailQueue (alert-linked only)', COUNT_BIG(*) FROM dbo.MailQueue WHERE AlertId IS NOT NULL
UNION ALL SELECT 'AuditLog (alert/template-linked only)', COUNT_BIG(*) FROM dbo.AuditLog
 WHERE AlertId IS NOT NULL
    OR (@DeleteTemplates=1 AND EntityType IN ('Template','Workflow','WorkflowDefinition','TemplateDashboard','IngestionConfiguration'))
UNION ALL SELECT 'TemplateDashboardRoleMapping', COUNT_BIG(*) FROM dbo.TemplateDashboardRoleMapping WHERE @DeleteTemplates=1
UNION ALL SELECT 'TemplateDashboardMaster', COUNT_BIG(*) FROM dbo.TemplateDashboardMaster WHERE @DeleteTemplates=1
UNION ALL SELECT 'IngestionConfiguration', COUNT_BIG(*) FROM dbo.IngestionConfiguration WHERE @DeleteTemplates=1
UNION ALL SELECT 'WorkflowDefinitions', COUNT_BIG(*) FROM dbo.WorkflowDefinitions WHERE @DeleteTemplates=1
UNION ALL SELECT 'Templates', COUNT_BIG(*) FROM dbo.Templates WHERE @DeleteTemplates=1;

IF @CommitChanges=0
BEGIN
    PRINT 'Preview only: no rows changed. Set @CommitChanges=1 to execute the selected cleanup.';
    RETURN;
END;

BEGIN TRY
    BEGIN TRANSACTION;

    DELETE FROM dbo.MailQueue WHERE AlertId IS NOT NULL;
    DELETE FROM dbo.AuditLog
     WHERE AlertId IS NOT NULL
        OR (@DeleteTemplates=1 AND EntityType IN ('Template','Workflow','WorkflowDefinition','TemplateDashboard','IngestionConfiguration'));
    DELETE FROM dbo.IngestionStaging;
    DELETE FROM dbo.IngestionRun;
    DELETE FROM dbo.AlertQueries;
    DELETE FROM dbo.Attachments;
    DELETE FROM dbo.WorkItems;
    DELETE FROM dbo.WorkflowInstances;
    DELETE FROM dbo.Alerts;

    IF @DeleteTemplates=1
    BEGIN
        DELETE FROM dbo.TemplateDashboardRoleMapping;
        DELETE FROM dbo.TemplateDashboardMaster;
        DELETE FROM dbo.IngestionConfiguration;
        UPDATE dbo.Templates SET PublishedWorkflowId=NULL;
        DELETE FROM dbo.WorkflowDefinitions;
        DELETE FROM dbo.Templates;
    END;

    COMMIT TRANSACTION;
    PRINT 'Cleanup committed. User/security masters and unrelated configuration were retained.';
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
