SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
    CATS V10 - Desktop Due Diligence Money Mule role dashboards.

    DT_USER receives only the DT User dashboard.
    DT_VERIFIER receives only the DT Verifier dashboard.
*/
BEGIN TRAN;

DECLARE @TemplateId varchar(32)=
(
    SELECT TOP(1) Id
    FROM dbo.Templates
    WHERE UPPER(Code)='DT_DD_MONEY_MULE'
    ORDER BY CASE WHEN Status='Published' THEN 0 ELSE 1 END,Version DESC
);

IF @TemplateId IS NULL
    THROW 50010,'Template DT_DD_MONEY_MULE must exist before dashboard configuration is deployed.',1;

DECLARE @NowUtc datetime2(7)=SYSUTCDATETIME();
DECLARE @DtUserDashboardId varchar(32)=
    (SELECT Id FROM dbo.TemplateDashboardMaster WHERE Code='DT_DD_MONEY_MULE_DT_USER');
DECLARE @DtVerifierDashboardId varchar(32)=
    (SELECT Id FROM dbo.TemplateDashboardMaster WHERE Code='DT_DD_MONEY_MULE_DT_VERIFIER');

SET @DtUserDashboardId=COALESCE(@DtUserDashboardId,LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-','')));
SET @DtVerifierDashboardId=COALESCE(@DtVerifierDashboardId,LOWER(REPLACE(CONVERT(varchar(36),NEWID()),'-','')));

MERGE dbo.TemplateDashboardMaster AS target
USING
(
    VALUES
    (
        @DtUserDashboardId,
        'DT_DD_MONEY_MULE_DT_USER',
        N'Desktop Due Diligence - DT User',
        N'Desktop Due Diligence Money Mule',
        N'DT User dashboard for Desktop Due Diligence Money Mule alerts.',
        N'["BranchCode","AnalystName"]',
        N'[{"code":"TOTAL","title":"Total Record","type":"Count","field":"","value":""},{"code":"CONTINUE","title":"Continue Txn Restriction","type":"FieldEquals","field":"CDFinalRecommendation","value":"Continue Txn Restriction"},{"code":"REMOVE","title":"Remove Txn Restriction","type":"FieldEquals","field":"CDFinalRecommendation","value":"Remove Txn Restriction"},{"code":"PENDING","title":"Pending","type":"StatusCount","field":"","value":"Pending"}]',
        N'["AlertNo","AccountId","CustomerId","RuleId","ProductName","Unit","TotalLiveLoanAmount","CustomerPermanentState","CustomerDateOfBirth","CustomerCountry","Status"]',
        N'["AlertNo","AccountId","CustomerId"]',
        20,
        10
    ),
    (
        @DtVerifierDashboardId,
        'DT_DD_MONEY_MULE_DT_VERIFIER',
        N'Desktop Due Diligence - DT Verifier',
        N'Desktop Due Diligence Money Mule',
        N'DT Verifier dashboard for Desktop Due Diligence Money Mule alerts.',
        N'["BranchCode","AnalystName"]',
        N'[{"code":"TOTAL","title":"Total","type":"Count","field":"","value":""},{"code":"CONTINUE","title":"Continue Txn Restriction","type":"FieldEquals","field":"CDFinalRecommendation","value":"Continue Txn Restriction"},{"code":"REMOVE","title":"Remove Txn Restriction","type":"FieldEquals","field":"CDFinalRecommendation","value":"Remove Txn Restriction"},{"code":"CLOSED","title":"Closed","type":"StatusCount","field":"","value":"Closed"},{"code":"PENDING","title":"Pending","type":"StatusCount","field":"","value":"Pending"}]',
        N'["AlertNo","AccountId","CustomerId","RuleId","ProductName","Unit","TotalLiveLoanAmount","CustomerPermanentState","CustomerDateOfBirth","CustomerCountry","Status","CurrentStageName"]',
        N'["AlertNo","AccountId","CustomerId"]',
        20,
        11
    )
) AS source(Id,Code,Name,Title,Description,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder)
ON target.Code=source.Code
WHEN MATCHED THEN UPDATE SET
    target.Name=source.Name,
    target.Title=source.Title,
    target.Description=source.Description,
    target.TemplateId=@TemplateId,
    target.AlertType='',
    target.GroupByFieldsJson=source.GroupByFieldsJson,
    target.MetricsJson=source.MetricsJson,
    target.GridColumnsJson=source.GridColumnsJson,
    target.SearchFieldsJson=source.SearchFieldsJson,
    target.PageSize=source.PageSize,
    target.DisplayOrder=source.DisplayOrder,
    target.IsDefault=1,
    target.IsActive=1,
    target.UpdatedAtUtc=@NowUtc
WHEN NOT MATCHED THEN INSERT
    (Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive,CreatedAtUtc,UpdatedAtUtc)
VALUES
    (source.Id,source.Code,source.Name,source.Title,source.Description,@TemplateId,'',source.GroupByFieldsJson,source.MetricsJson,source.GridColumnsJson,source.SearchFieldsJson,source.PageSize,source.DisplayOrder,1,1,@NowUtc,@NowUtc);

DELETE FROM dbo.TemplateDashboardRoleMapping
WHERE DashboardId IN(@DtUserDashboardId,@DtVerifierDashboardId);

INSERT dbo.TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible)
VALUES
    (@DtUserDashboardId,'DT_USER',1),
    (@DtVerifierDashboardId,'DT_VERIFIER',1);

COMMIT;
GO
