/* =====================================================================================
   CATS V4 - Common repository dispatcher
   ADO.NET calls only this procedure. It resolves:
       USP_<ModuleCode>_<MethodCode>
   Every leaf procedure accepts exactly one input parameter:
       @strJson nvarchar(max)
   ===================================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_CommonRepository
    @ModuleCode nvarchar(60) = NULL,
    @MethodCode nvarchar(80),
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @ModuleCode = LTRIM(RTRIM(COALESCE(@ModuleCode,N'')));
    SET @MethodCode = LTRIM(RTRIM(COALESCE(@MethodCode,N'')));
    SET @strJson = COALESCE(@strJson,N'{}');

    IF @MethodCode = N''
        THROW 50000, 'Invalid method.', 1;

    IF ISJSON(@strJson) <> 1
        THROW 50001, 'strJson must be valid JSON.', 1;

    -- Only simple identifier characters are allowed. This protects the dynamic EXEC.
    IF (@ModuleCode <> N'' AND PATINDEX(N'%[^A-Za-z0-9_]%', @ModuleCode COLLATE Latin1_General_100_BIN2) > 0)
       OR PATINDEX(N'%[^A-Za-z0-9_]%', @MethodCode COLLATE Latin1_General_100_BIN2) > 0
        THROW 50002, 'Invalid module or method code.', 1;

    DECLARE @procName sysname =
        CASE WHEN @ModuleCode = N''
             THEN N'USP_' + @MethodCode
             ELSE N'USP_' + @ModuleCode + N'_' + @MethodCode
        END;

    IF OBJECT_ID(N'dbo.' + @procName, N'P') IS NULL
        THROW 50003, 'Unsupported repository operation.', 1;

    DECLARE @sql nvarchar(max) =
        N'EXEC dbo.' + QUOTENAME(@procName) + N' @strJson = @JSON;';

    EXEC sys.sp_executesql
        @sql,
        N'@JSON nvarchar(max)',
        @JSON = @strJson;
END
GO
