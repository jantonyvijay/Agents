/* CATS V4 module: Mail */

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetConfigurations
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive FROM dbo.MailConfiguration ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_SaveConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.MailConfiguration t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32),Name nvarchar(150),ProviderType varchar(30),Host nvarchar(300),Port int,UserName nvarchar(200),SecretEncrypted nvarchar(2000),FromAddress nvarchar(300),UseSsl int,IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ProviderType=s.ProviderType,Host=s.Host,Port=s.Port,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,FromAddress=s.FromAddress,UseSsl=s.UseSsl,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ProviderType,Host,Port,UserName,SecretEncrypted,FromAddress,UseSsl,IsActive)VALUES(s.Id,s.Name,s.ProviderType,s.Host,s.Port,s.UserName,s.SecretEncrypted,s.FromAddress,s.UseSsl,s.IsActive); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetTemplates
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive FROM dbo.MailTemplate ORDER BY EventCode; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_GetLogs
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @MailTake int=CONVERT(int,JSON_VALUE(@strJson,'$.take')); SELECT TOP(@MailTake) Id,EventCode,AlertId,ToAddress,Subject,Status,Attempts,CreatedAtUtc,SentAtUtc,ErrorMessage FROM dbo.MailQueue ORDER BY CreatedAtUtc DESC; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Mail_SaveTemplate
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.MailTemplate t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32) '$.id',TemplateId varchar(32) '$.templateId',EventCode varchar(80) '$.eventCode',SubjectTemplate nvarchar(500) '$.subjectTemplate',BodyTemplate nvarchar(max) '$.bodyTemplate',UseMafEnrichment bit '$.useMafEnrichment',IsActive bit '$.isActive'))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET TemplateId=s.TemplateId,EventCode=s.EventCode,SubjectTemplate=s.SubjectTemplate,BodyTemplate=s.BodyTemplate,UseMafEnrichment=COALESCE(s.UseMafEnrichment,0),IsActive=COALESCE(s.IsActive,1) WHEN NOT MATCHED THEN INSERT(Id,TemplateId,EventCode,SubjectTemplate,BodyTemplate,UseMafEnrichment,IsActive)VALUES(s.Id,s.TemplateId,s.EventCode,s.SubjectTemplate,s.BodyTemplate,COALESCE(s.UseMafEnrichment,0),COALESCE(s.IsActive,1)); RETURN;
END
GO
