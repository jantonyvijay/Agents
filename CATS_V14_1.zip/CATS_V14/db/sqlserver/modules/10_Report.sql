/* CATS V4 module: Report */

CREATE OR ALTER PROCEDURE dbo.USP_Report_GetCount
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE
        @TemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),
        @AlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),
        @FilterBranch varchar(60)=JSON_VALUE(@strJson,'$.branchCode'),
        @UserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),
        @Status varchar(30)=JSON_VALUE(@strJson,'$.status'),
        @FromDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.fromDate')),
        @ToDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.toDate')),
        @CanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));

    SELECT COUNT(*)
    FROM dbo.Alerts a
    WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
           OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
      AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
      AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
      AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
      AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
      AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
      AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)));
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Report_GetData
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE
        @ReportType varchar(20)=JSON_VALUE(@strJson,'$.reportType'),
        @TemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),
        @AlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),
        @FilterBranch varchar(60)=JSON_VALUE(@strJson,'$.branchCode'),
        @UserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),
        @Status varchar(30)=JSON_VALUE(@strJson,'$.status'),
        @FromDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.fromDate')),
        @ToDate datetime2=TRY_CONVERT(datetime2,JSON_VALUE(@strJson,'$.toDate')),
        @Page int=COALESCE(TRY_CONVERT(int,JSON_VALUE(@strJson,'$.page')),1),
        @PageSize int=COALESCE(TRY_CONVERT(int,JSON_VALUE(@strJson,'$.pageSize')),20),
        @CanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));

    IF UPPER(COALESCE(@ReportType,''))='MIS'
    BEGIN
        SELECT a.AlertType,a.Status,COUNT(*) Total
        FROM dbo.Alerts a
        WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
               OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
          AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
          AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
          AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
          AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)))
        GROUP BY a.AlertType,a.Status
        ORDER BY a.AlertType,a.Status;
        RETURN;
    END;

    SELECT a.AlertNo,a.AlertType,t.Name TemplateName,a.BranchCode,a.CurrentStageName,
           a.Status,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc
    FROM dbo.Alerts a
    JOIN dbo.Templates t ON t.Id=a.TemplateId
    WHERE (@CanViewAll=1 OR a.BranchCode=@UserBranch
           OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId))
      AND (NULLIF(@TemplateId,'') IS NULL OR a.TemplateId=@TemplateId)
      AND (NULLIF(@AlertType,'') IS NULL OR a.AlertType=@AlertType)
      AND (NULLIF(@FilterBranch,'') IS NULL OR a.BranchCode=@FilterBranch)
      AND (NULLIF(@Status,'') IS NULL OR a.Status=@Status)
      AND (@FromDate IS NULL OR a.CreatedAtUtc>=@FromDate)
      AND (@ToDate IS NULL OR a.CreatedAtUtc<DATEADD(day,1,CONVERT(date,@ToDate)))
    ORDER BY a.CreatedAtUtc DESC
    OFFSET (@Page-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END
GO
