/* CATS V4 module: Ingestion */

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetConfigurations
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,TemplateId,SourceType,ConnectorId,FilePath,FileName,FilePattern,ScheduleTriggersJson,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive FROM dbo.IngestionConfiguration ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_SaveConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.IngestionConfiguration t
USING(SELECT * FROM OPENJSON(@strJson) WITH(
 Id varchar(32) '$.id',Name nvarchar(150) '$.name',TemplateId varchar(32) '$.templateId',SourceType varchar(30) '$.sourceType',ConnectorId varchar(32) '$.connectorId',
 FilePath nvarchar(500) '$.filePath',FileName nvarchar(260) '$.fileName',FilePattern nvarchar(260) '$.filePattern',ScheduleTriggersJson nvarchar(max) '$.scheduleTriggersJson',
 ScheduleCron varchar(100) '$.scheduleCron',QueryText nvarchar(max) '$.queryText',FieldMappingJson nvarchar(max) '$.fieldMappingJson',DuplicateKeyFields nvarchar(500) '$.duplicateKeyFields',
 ArchivePath nvarchar(500) '$.archivePath',ErrorPath nvarchar(500) '$.errorPath',IntervalMinutes int '$.intervalMinutes',IsActive int '$.isActive'
))s ON t.Id=s.Id
WHEN MATCHED THEN UPDATE SET Name=s.Name,TemplateId=s.TemplateId,SourceType=s.SourceType,ConnectorId=s.ConnectorId,FilePath=COALESCE(s.FilePath,N''),FileName=COALESCE(s.FileName,N''),FilePattern=COALESCE(s.FilePattern,N''),ScheduleTriggersJson=COALESCE(s.ScheduleTriggersJson,N'[]'),ScheduleCron=COALESCE(s.ScheduleCron,''),QueryText=COALESCE(s.QueryText,N''),FieldMappingJson=COALESCE(s.FieldMappingJson,N'{}'),DuplicateKeyFields=COALESCE(s.DuplicateKeyFields,N''),ArchivePath=COALESCE(s.ArchivePath,N''),ErrorPath=COALESCE(s.ErrorPath,N''),IntervalMinutes=COALESCE(s.IntervalMinutes,1),IsActive=COALESCE(s.IsActive,1)
WHEN NOT MATCHED THEN INSERT(Id,Name,TemplateId,SourceType,ConnectorId,FilePath,FileName,FilePattern,ScheduleTriggersJson,ScheduleCron,QueryText,FieldMappingJson,DuplicateKeyFields,ArchivePath,ErrorPath,IntervalMinutes,IsActive)
VALUES(s.Id,s.Name,s.TemplateId,s.SourceType,s.ConnectorId,COALESCE(s.FilePath,N''),COALESCE(s.FileName,N''),COALESCE(s.FilePattern,N''),COALESCE(s.ScheduleTriggersJson,N'[]'),COALESCE(s.ScheduleCron,''),COALESCE(s.QueryText,N''),COALESCE(s.FieldMappingJson,N'{}'),COALESCE(s.DuplicateKeyFields,N''),COALESCE(s.ArchivePath,N''),COALESCE(s.ErrorPath,N''),COALESCE(s.IntervalMinutes,1),COALESCE(s.IsActive,1)); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetDashboard
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT (SELECT COUNT(*) FROM dbo.IngestionConfiguration WHERE IsActive=1)ActiveConfigurations,COUNT(*)RunsToday,COALESCE(SUM(CASE WHEN Status='Success' THEN 1 ELSE 0 END),0)SuccessfulToday,COALESCE(SUM(CASE WHEN Status='Failed' THEN 1 ELSE 0 END),0)FailedToday,COALESCE(SUM(RowsInserted),0)RowsInsertedToday FROM dbo.IngestionRun WHERE StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Ingestion_GetRuns
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @Take int=CONVERT(int,JSON_VALUE(@strJson,'$.take')); SELECT TOP(@Take) Id,ConfigurationId,SourceReference,StartedAtUtc,EndedAtUtc,RowsRead,RowsInserted,RowsDuplicate,RowsFailed,Status,ErrorMessage FROM dbo.IngestionRun ORDER BY StartedAtUtc DESC; RETURN;
END
GO
