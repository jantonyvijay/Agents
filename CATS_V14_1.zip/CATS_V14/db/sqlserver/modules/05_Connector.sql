/* CATS V4 module: Connector */

CREATE OR ALTER PROCEDURE dbo.USP_Connector_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive FROM dbo.IngestionConnector ORDER BY Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Connector_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
MERGE dbo.IngestionConnector t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32),Name nvarchar(150),ConnectorType varchar(30),Host nvarchar(300),Port int,DatabaseName nvarchar(200),UserName nvarchar(200),SecretEncrypted nvarchar(2000),ExtraJson nvarchar(max),IsActive int))s ON t.Id=s.Id WHEN MATCHED THEN UPDATE SET Name=s.Name,ConnectorType=s.ConnectorType,Host=s.Host,Port=s.Port,DatabaseName=s.DatabaseName,UserName=s.UserName,SecretEncrypted=s.SecretEncrypted,ExtraJson=s.ExtraJson,IsActive=s.IsActive WHEN NOT MATCHED THEN INSERT(Id,Name,ConnectorType,Host,Port,DatabaseName,UserName,SecretEncrypted,ExtraJson,IsActive)VALUES(s.Id,s.Name,s.ConnectorType,s.Host,s.Port,s.DatabaseName,s.UserName,s.SecretEncrypted,s.ExtraJson,s.IsActive); RETURN;
END
GO
