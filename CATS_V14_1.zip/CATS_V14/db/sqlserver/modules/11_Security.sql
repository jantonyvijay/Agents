/* CATS V4 module: Security */

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetRoleCodes
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT DISTINCT RoleCode
        FROM dbo.CatsUsers
        WHERE IsActive=1
        ORDER BY RoleCode;
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetEffectivePermissions
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT DISTINCT rp.PermissionCode FROM dbo.CatsUsers u JOIN dbo.RolePermissionMapping rp ON rp.RoleCode=u.RoleCode AND rp.IsActive=1 JOIN dbo.PermissionMaster p ON p.Code=rp.PermissionCode AND p.IsActive=1 WHERE u.Id=@UserId AND u.IsActive=1
  UNION SELECT DISTINCT up.PermissionCode FROM dbo.UserPermissionMapping up JOIN dbo.PermissionMaster p ON p.Code=up.PermissionCode AND p.IsActive=1 WHERE up.UserId=@UserId AND up.IsActive=1; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Security_GetDataScopes
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT s.Id,s.RoleCode,s.ScopeType,s.ScopeValue,s.Priority,s.IsActive FROM dbo.DataScopeMaster s JOIN dbo.CatsUsers u ON u.RoleCode=s.RoleCode WHERE u.Id=@UserId AND s.IsActive=1 ORDER BY s.Priority; RETURN;
END
GO
