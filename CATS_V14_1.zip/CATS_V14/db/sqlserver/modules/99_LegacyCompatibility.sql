/* Backward-compatible wrapper. New C# code does not call this procedure directly. */
CREATE OR ALTER PROCEDURE dbo.usp_CatsRepository
    @Operation nvarchar(100),
    @JsonInput nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ModuleCode nvarchar(60), @MethodCode nvarchar(80);

    SELECT @ModuleCode=v.ModuleCode,@MethodCode=v.MethodCode
    FROM (VALUES
        (N'GetUserByUserName',N'User',N'GetByUserName'),
        (N'GetUserById',N'User',N'GetById'),
        (N'GetUsers',N'User',N'GetAll'),
        (N'UpsertUser',N'User',N'Upsert'),
        (N'GetTemplates',N'Template',N'GetAll'),
        (N'GetTemplate',N'Template',N'GetById'),
        (N'SaveTemplate',N'Template',N'Save'),
        (N'GetWorkflow',N'Workflow',N'GetById'),
        (N'GetPublishedWorkflowForTemplate',N'Workflow',N'GetPublishedByTemplate'),
        (N'SaveWorkflow',N'Workflow',N'Save'),
        (N'InsertAlert',N'Alert',N'Insert'),
        (N'InsertWorkflowInstance',N'WorkflowInstance',N'Insert'),
        (N'UpdateWorkflowInstance',N'WorkflowInstance',N'Update'),
        (N'TryClaimStageTransition',N'WorkflowInstance',N'TryClaimStageTransition'),
        (N'ReleaseStageTransitionClaim',N'WorkflowInstance',N'ReleaseStageTransitionClaim'),
        (N'UpdateAlertStage',N'Alert',N'UpdateStage'),
        (N'UpdateAlertDynamicData',N'Alert',N'UpdateDynamicData'),
        (N'GetAlert',N'Alert',N'GetById'),
        (N'GetWorkflowInstanceByAlert',N'WorkflowInstance',N'GetByAlert'),
        (N'InsertWorkItems',N'WorkItem',N'Insert'),
        (N'GetPendingWorkItems',N'WorkItem',N'GetPending'),
        (N'GetWorkItem',N'WorkItem',N'GetById'),
        (N'GetWorkItems',N'WorkItem',N'GetAllByAlert'),
        (N'CompleteWorkItem',N'WorkItem',N'Complete'),
        (N'ReassignPendingWorkItems',N'WorkItem',N'ReassignPending'),
        (N'CancelPendingWorkItems',N'WorkItem',N'CancelPending'),
        (N'GetParallelWorkItems',N'WorkItem',N'GetParallel'),
        (N'InsertQuery',N'Query',N'Insert'),
        (N'RespondLatestOpenQuery',N'Query',N'RespondLatestOpen'),
        (N'GetQueries',N'Query',N'GetAllByAlert'),
        (N'InsertAttachment',N'Attachment',N'Insert'),
        (N'GetAttachments',N'Attachment',N'GetAllByAlert'),
        (N'GetAttachment',N'Attachment',N'GetById'),
        (N'InsertAudit',N'Audit',N'Insert'),
        (N'GetAudit',N'Audit',N'GetByAlert'),
        (N'GetAgingBuckets',N'Aging',N'GetBuckets'),
        (N'SaveAgingBucket',N'Aging',N'SaveBucket'),
        (N'GetDashboardAging',N'Dashboard',N'GetAging'),
        (N'GetAlertsCount',N'Alert',N'GetCount'),
        (N'GetAlerts',N'Alert',N'GetPaged'),
        (N'GetTemplateName',N'Template',N'GetName'),
        (N'GetRoleCodes',N'Security',N'GetRoleCodes')
    ) v(OperationCode,ModuleCode,MethodCode)
    WHERE v.OperationCode=@Operation;

    IF @MethodCode IS NULL
        THROW 50000, 'Unsupported legacy repository operation.', 1;

    EXEC dbo.usp_CommonRepository
        @ModuleCode=@ModuleCode,
        @MethodCode=@MethodCode,
        @strJson=@JsonInput;
END
GO

/* Backward-compatible wrapper. New C# code does not call this procedure directly. */
CREATE OR ALTER PROCEDURE dbo.usp_PlatformRepository
    @Operation nvarchar(100),
    @JsonInput nvarchar(max)=N'{}'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ModuleCode nvarchar(60), @MethodCode nvarchar(80);

    SELECT @ModuleCode=v.ModuleCode,@MethodCode=v.MethodCode
    FROM (VALUES
        (N'GetEffectivePermissions',N'Security',N'GetEffectivePermissions'),
        (N'GetDataScopes',N'Security',N'GetDataScopes'),
        (N'GetDashboardWidgets',N'Dashboard',N'GetWidgets'),
        (N'GetDashboardWidgetConfiguration',N'Dashboard',N'GetWidgetConfiguration'),
        (N'SaveDashboardWidget',N'Dashboard',N'SaveWidget'),
        (N'GetTemplateDashboards',N'TemplateDashboard',N'GetAll'),
        (N'GetTemplateDashboard',N'TemplateDashboard',N'GetById'),
        (N'SaveTemplateDashboard',N'TemplateDashboard',N'Save'),
        (N'GetTemplateDashboardAlerts',N'TemplateDashboard',N'GetAlerts'),
        (N'GetConnectors',N'Connector',N'GetAll'),
        (N'SaveConnector',N'Connector',N'Save'),
        (N'GetIngestionConfigurations',N'Ingestion',N'GetConfigurations'),
        (N'SaveIngestionConfiguration',N'Ingestion',N'SaveConfiguration'),
        (N'GetIngestionDashboard',N'Ingestion',N'GetDashboard'),
        (N'GetIngestionRuns',N'Ingestion',N'GetRuns'),
        (N'GetMailConfigurations',N'Mail',N'GetConfigurations'),
        (N'SaveMailConfiguration',N'Mail',N'SaveConfiguration'),
        (N'GetMailTemplates',N'Mail',N'GetTemplates'),
        (N'GetMailLogs',N'Mail',N'GetLogs'),
        (N'SaveMailTemplate',N'Mail',N'SaveTemplate'),
        (N'GetReportCount',N'Report',N'GetCount'),
        (N'GetReport',N'Report',N'GetData')
    ) v(OperationCode,ModuleCode,MethodCode)
    WHERE v.OperationCode=@Operation;

    IF @MethodCode IS NULL
        THROW 50000, 'Unsupported legacy repository operation.', 1;

    EXEC dbo.usp_CommonRepository
        @ModuleCode=@ModuleCode,
        @MethodCode=@MethodCode,
        @strJson=@JsonInput;
END
GO
