/* CATS V4 module: TemplateDashboard */

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetAll
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @TDIncludeInactive bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.includeInactive'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d
  WHERE (@TDIncludeInactive=1 OR d.IsActive=1) AND (@TDIncludeInactive=1 OR EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))
  ORDER BY d.DisplayOrder,d.Name; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetById
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @TDId varchar(32)=JSON_VALUE(@strJson,'$.id'),@TDRequireManage bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.requireManage'));
  SELECT d.Id,d.Code,d.Name,d.Title,d.Description,d.TemplateId,d.AlertType,d.GroupByFieldsJson,d.MetricsJson,d.GridColumnsJson,d.SearchFieldsJson,d.PageSize,d.DisplayOrder,d.IsDefault,d.IsActive,
   STUFF((SELECT ','+m.RoleCode FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.IsVisible=1 ORDER BY m.RoleCode FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,'') RoleCodes
  FROM dbo.TemplateDashboardMaster d WHERE d.Id=@TDId AND (@TDRequireManage=1 OR (d.IsActive=1 AND EXISTS(SELECT 1 FROM dbo.TemplateDashboardRoleMapping m WHERE m.DashboardId=d.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1))); RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_Save
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
BEGIN TRAN;
  MERGE dbo.TemplateDashboardMaster t USING(SELECT * FROM OPENJSON(@strJson) WITH(Id varchar(32) '$.id',Code varchar(80) '$.code',Name nvarchar(150) '$.name',Title nvarchar(250) '$.title',Description nvarchar(1000) '$.description',TemplateId varchar(32) '$.templateId',AlertType nvarchar(150) '$.alertType',GroupByFieldsJson nvarchar(max) '$.groupByFieldsJson',MetricsJson nvarchar(max) '$.metricsJson',GridColumnsJson nvarchar(max) '$.gridColumnsJson',SearchFieldsJson nvarchar(max) '$.searchFieldsJson',PageSize int '$.pageSize',DisplayOrder int '$.displayOrder',IsDefault bit '$.isDefault',IsActive bit '$.isActive'))q ON t.Id=q.Id
  WHEN MATCHED THEN UPDATE SET Code=q.Code,Name=q.Name,Title=q.Title,Description=COALESCE(q.Description,''),TemplateId=q.TemplateId,AlertType=COALESCE(q.AlertType,''),GroupByFieldsJson=q.GroupByFieldsJson,MetricsJson=q.MetricsJson,GridColumnsJson=q.GridColumnsJson,SearchFieldsJson=q.SearchFieldsJson,PageSize=q.PageSize,DisplayOrder=q.DisplayOrder,IsDefault=q.IsDefault,IsActive=q.IsActive,UpdatedAtUtc=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT(Id,Code,Name,Title,Description,TemplateId,AlertType,GroupByFieldsJson,MetricsJson,GridColumnsJson,SearchFieldsJson,PageSize,DisplayOrder,IsDefault,IsActive) VALUES(q.Id,q.Code,q.Name,q.Title,COALESCE(q.Description,''),q.TemplateId,COALESCE(q.AlertType,''),q.GroupByFieldsJson,q.MetricsJson,q.GridColumnsJson,q.SearchFieldsJson,q.PageSize,q.DisplayOrder,q.IsDefault,q.IsActive);
  DECLARE @SavedDashboardId varchar(32)=JSON_VALUE(@strJson,'$.id'); DELETE FROM dbo.TemplateDashboardRoleMapping WHERE DashboardId=@SavedDashboardId;
  INSERT dbo.TemplateDashboardRoleMapping(DashboardId,RoleCode,IsVisible) SELECT @SavedDashboardId,[value],1 FROM OPENJSON(@strJson,'$.roleCodes') WHERE NULLIF([value],'') IS NOT NULL;
  COMMIT; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_TemplateDashboard_GetAlerts
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
DECLARE @DTTemplateId varchar(32)=JSON_VALUE(@strJson,'$.templateId'),@DTAlertType nvarchar(150)=JSON_VALUE(@strJson,'$.alertType'),@DTUserBranch varchar(60)=JSON_VALUE(@strJson,'$.userBranchCode'),@DTRoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),@DTCanViewAll bit=TRY_CONVERT(bit,JSON_VALUE(@strJson,'$.canViewAll'));
  SELECT TOP(5000) a.Id,a.AlertNo,a.TemplateId,a.AlertType,a.BranchCode,a.CustomerIdEncrypted,a.AccountIdEncrypted,a.Status,a.CurrentStageName,a.Priority,a.CreatedAtUtc,a.StageEnteredAtUtc,a.DynamicDataJson
  FROM dbo.Alerts a WHERE a.TemplateId=@DTTemplateId AND (NULLIF(@DTAlertType,'') IS NULL OR a.AlertType=@DTAlertType) AND (@DTCanViewAll=1 OR a.BranchCode=@DTUserBranch OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND (wi.AssignedUserId=@UserId OR (wi.AssignedRoleCode=@DTRoleCode AND (wi.AssignedBranchCode='' OR wi.AssignedBranchCode=@DTUserBranch))))) ORDER BY a.CreatedAtUtc DESC; RETURN;
END
GO
