/* CATS V4 module: Dashboard */

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetAging
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @strJson = COALESCE(@strJson, N'{}');

    IF ISJSON(@strJson) <> 1
        THROW 50000, 'JsonInput must be a valid JSON object.', 1;

    DECLARE
        @Id varchar(100),
        @IsNew bit,
        @UserName varchar(100),
        @DisplayName nvarchar(200),
        @PasswordHash varchar(500),
        @RoleCode varchar(60),
        @DepartmentCode varchar(60),
        @BranchCode varchar(60),
        @PermissionsJson nvarchar(max),
        @IsActive bit,
        @TemplateId varchar(32),
        @Code varchar(80),
        @Name nvarchar(250),
        @ExecutionMode varchar(30),
        @SectionsJson nvarchar(max),
        @FieldsJson nvarchar(max),
        @AssignmentRulesJson nvarchar(max),
        @DefinitionJson nvarchar(max),
        @Publish bit,
        @CreatedBy varchar(100),
        @NowUtc datetime2(7),
        @AlertId varchar(32),
        @AlertNo varchar(60),
        @TemplateVersion int,
        @AlertType nvarchar(150),
        @CustomerIdEncrypted nvarchar(1000),
        @AccountIdEncrypted nvarchar(1000),
        @DynamicDataJson nvarchar(max),
        @Status varchar(30),
        @CurrentStageId varchar(100),
        @CurrentStageName nvarchar(200),
        @CreatedAtUtc datetime2(7),
        @StageEnteredAtUtc datetime2(7),
        @Priority varchar(30),
        @WorkflowDefinitionId varchar(32),
        @WorkflowVersion int,
        @StartedAtUtc datetime2(7),
        @UpdatedAtUtc datetime2(7),
        @InstanceId varchar(32),
        @ExpectedStageId varchar(100),
        @StageId varchar(100),
        @StageName nvarchar(200),
        @EnteredAtUtc datetime2(7),
        @Action varchar(80),
        @CompletedBy varchar(100),
        @Remarks nvarchar(2000),
        @GroupId varchar(32),
        @ParallelGroupId varchar(32),
        @RaisedBy varchar(100),
        @RaisedToRole varchar(60),
        @QueryText nvarchar(3000),
        @ResponseText nvarchar(3000),
        @RaisedAtUtc datetime2(7),
        @FileName nvarchar(260),
        @StoredName varchar(100),
        @ContentType varchar(150),
        @FileSize bigint,
        @Sha256 varchar(64),
        @Version int,
        @UploadedBy varchar(100),
        @UploadedAtUtc datetime2(7),
        @UserId varchar(32),
        @EntityType varchar(80),
        @EntityId varchar(32),
        @PreviousValueJson nvarchar(max),
        @NewValueJson nvarchar(max),
        @IpAddress varchar(100),
        @Take int,
        @FromDays int,
        @ToDays int,
        @DisplayOrder int,
        @UserBranchCode varchar(60),
        @CanViewAll bit,
        @FilterBranchCode varchar(60),
        @Search nvarchar(500),
        @AgingFrom int,
        @AgingTo int,
        @Page int,
        @PageSize int;

    SELECT
        @Id = j.id,
        @IsNew = j.isNew,
        @UserName = j.userName,
        @DisplayName = j.displayName,
        @PasswordHash = j.passwordHash,
        @RoleCode = j.roleCode,
        @DepartmentCode = j.departmentCode,
        @BranchCode = j.branchCode,
        @PermissionsJson = j.permissionsJson,
        @IsActive = j.isActive,
        @TemplateId = j.templateId,
        @Code = j.code,
        @Name = j.name,
        @ExecutionMode = j.executionMode,
        @SectionsJson = j.sectionsJson,
        @FieldsJson = j.fieldsJson,
        @AssignmentRulesJson = j.assignmentRulesJson,
        @DefinitionJson = j.definitionJson,
        @Publish = j.publish,
        @CreatedBy = j.createdBy,
        @NowUtc = j.nowUtc,
        @AlertId = j.alertId,
        @AlertNo = j.alertNo,
        @TemplateVersion = j.templateVersion,
        @AlertType = j.alertType,
        @CustomerIdEncrypted = j.customerIdEncrypted,
        @AccountIdEncrypted = j.accountIdEncrypted,
        @DynamicDataJson = j.dynamicDataJson,
        @Status = j.status,
        @CurrentStageId = j.currentStageId,
        @CurrentStageName = j.currentStageName,
        @CreatedAtUtc = j.createdAtUtc,
        @StageEnteredAtUtc = j.stageEnteredAtUtc,
        @Priority = j.priority,
        @WorkflowDefinitionId = j.workflowDefinitionId,
        @WorkflowVersion = j.workflowVersion,
        @StartedAtUtc = j.startedAtUtc,
        @UpdatedAtUtc = j.updatedAtUtc,
        @InstanceId = j.instanceId,
        @ExpectedStageId = j.expectedStageId,
        @StageId = j.stageId,
        @StageName = j.stageName,
        @EnteredAtUtc = j.enteredAtUtc,
        @Action = j.action,
        @CompletedBy = j.completedBy,
        @Remarks = j.remarks,
        @GroupId = j.groupId,
        @ParallelGroupId = j.parallelGroupId,
        @RaisedBy = j.raisedBy,
        @RaisedToRole = j.raisedToRole,
        @QueryText = j.queryText,
        @ResponseText = j.responseText,
        @RaisedAtUtc = j.raisedAtUtc,
        @FileName = j.fileName,
        @StoredName = j.storedName,
        @ContentType = j.contentType,
        @FileSize = j.fileSize,
        @Sha256 = j.sha256,
        @Version = j.version,
        @UploadedBy = j.uploadedBy,
        @UploadedAtUtc = j.uploadedAtUtc,
        @UserId = j.userId,
        @EntityType = j.entityType,
        @EntityId = j.entityId,
        @PreviousValueJson = j.previousValueJson,
        @NewValueJson = j.newValueJson,
        @IpAddress = j.ipAddress,
        @Take = j.take,
        @FromDays = j.fromDays,
        @ToDays = j.toDays,
        @DisplayOrder = j.displayOrder,
        @UserBranchCode = j.userBranchCode,
        @CanViewAll = j.canViewAll,
        @FilterBranchCode = j.filterBranchCode,
        @Search = j.search,
        @AgingFrom = j.agingFrom,
        @AgingTo = j.agingTo,
        @Page = j.page,
        @PageSize = j.pageSize
    FROM OPENJSON(@strJson)
    WITH
    (
        id varchar(100) '$.id',
        isNew bit '$.isNew',
        userName varchar(100) '$.userName',
        displayName nvarchar(200) '$.displayName',
        passwordHash varchar(500) '$.passwordHash',
        roleCode varchar(60) '$.roleCode',
        departmentCode varchar(60) '$.departmentCode',
        branchCode varchar(60) '$.branchCode',
        permissionsJson nvarchar(max) '$.permissionsJson',
        isActive bit '$.isActive',
        templateId varchar(32) '$.templateId',
        code varchar(80) '$.code',
        name nvarchar(250) '$.name',
        executionMode varchar(30) '$.executionMode',
        sectionsJson nvarchar(max) '$.sectionsJson',
        fieldsJson nvarchar(max) '$.fieldsJson',
        assignmentRulesJson nvarchar(max) '$.assignmentRulesJson',
        definitionJson nvarchar(max) '$.definitionJson',
        publish bit '$.publish',
        createdBy varchar(100) '$.createdBy',
        nowUtc datetime2(7) '$.nowUtc',
        alertId varchar(32) '$.alertId',
        alertNo varchar(60) '$.alertNo',
        templateVersion int '$.templateVersion',
        alertType nvarchar(150) '$.alertType',
        customerIdEncrypted nvarchar(1000) '$.customerIdEncrypted',
        accountIdEncrypted nvarchar(1000) '$.accountIdEncrypted',
        dynamicDataJson nvarchar(max) '$.dynamicDataJson',
        status varchar(30) '$.status',
        currentStageId varchar(100) '$.currentStageId',
        currentStageName nvarchar(200) '$.currentStageName',
        createdAtUtc datetime2(7) '$.createdAtUtc',
        stageEnteredAtUtc datetime2(7) '$.stageEnteredAtUtc',
        priority varchar(30) '$.priority',
        workflowDefinitionId varchar(32) '$.workflowDefinitionId',
        workflowVersion int '$.workflowVersion',
        startedAtUtc datetime2(7) '$.startedAtUtc',
        updatedAtUtc datetime2(7) '$.updatedAtUtc',
        instanceId varchar(32) '$.instanceId',
        expectedStageId varchar(100) '$.expectedStageId',
        stageId varchar(100) '$.stageId',
        stageName nvarchar(200) '$.stageName',
        enteredAtUtc datetime2(7) '$.enteredAtUtc',
        action varchar(60) '$.action',
        completedBy varchar(100) '$.completedBy',
        remarks nvarchar(2000) '$.remarks',
        groupId varchar(32) '$.groupId',
        parallelGroupId varchar(32) '$.parallelGroupId',
        raisedBy varchar(100) '$.raisedBy',
        raisedToRole varchar(60) '$.raisedToRole',
        queryText nvarchar(3000) '$.queryText',
        responseText nvarchar(3000) '$.responseText',
        raisedAtUtc datetime2(7) '$.raisedAtUtc',
        fileName nvarchar(260) '$.fileName',
        storedName varchar(100) '$.storedName',
        contentType varchar(150) '$.contentType',
        fileSize bigint '$.fileSize',
        sha256 varchar(64) '$.sha256',
        version int '$.version',
        uploadedBy varchar(100) '$.uploadedBy',
        uploadedAtUtc datetime2(7) '$.uploadedAtUtc',
        userId varchar(32) '$.userId',
        entityType varchar(80) '$.entityType',
        entityId varchar(32) '$.entityId',
        previousValueJson nvarchar(max) '$.previousValueJson',
        newValueJson nvarchar(max) '$.newValueJson',
        ipAddress varchar(100) '$.ipAddress',
        take int '$.take',
        fromDays int '$.fromDays',
        toDays int '$.toDays',
        displayOrder int '$.displayOrder',
        userBranchCode varchar(60) '$.userBranchCode',
        canViewAll bit '$.canViewAll',
        filterBranchCode varchar(60) '$.filterBranchCode',
        search nvarchar(500) '$.search',
        agingFrom int '$.agingFrom',
        agingTo int '$.agingTo',
        page int '$.page',
        pageSize int '$.pageSize'
    ) AS j;

    SET @NowUtc = COALESCE(@NowUtc, SYSUTCDATETIME());

    DECLARE @AffectedRows int = 0;
    DECLARE @NewId varchar(32);
    DECLARE @NextVersion int;
    DECLARE @QueryId varchar(32);

        SELECT a.TemplateId,t.Name AS TemplateName,a.AlertType,a.StageEnteredAtUtc
        FROM dbo.Alerts AS a
        INNER JOIN dbo.Templates AS t ON t.Id=a.TemplateId
        WHERE a.Status NOT IN ('Closed','Cancelled','Rejected')
          AND
          (
              COALESCE(@CanViewAll,0)=1
              OR a.BranchCode=@UserBranchCode
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.WorkItems AS vw
                  WHERE vw.AlertId=a.Id
                    AND
                    (
                        (vw.AssignedRoleCode=@RoleCode AND
                         (vw.AssignedBranchCode IS NULL OR vw.AssignedBranchCode='' OR vw.AssignedBranchCode=@UserBranchCode))
                        OR vw.AssignedUserId=@UserId
                    )
              )
          )
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@TemplateId,''))), '') IS NULL OR a.TemplateId=@TemplateId)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@AlertType,N''))), N'') IS NULL OR a.AlertType=@AlertType)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@FilterBranchCode,''))), '') IS NULL OR a.BranchCode=@FilterBranchCode)
          AND (NULLIF(LTRIM(RTRIM(COALESCE(@Status,''))), '') IS NULL OR a.Status=@Status);
        RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetWidgets
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
;WITH P AS(SELECT [value] Code FROM OPENJSON(@strJson,'$.permissions')), W AS(
   SELECT w.Code,w.Title,w.WidgetType,w.DrillDownUrl,m.DisplayOrder,m.Width,
    CASE UPPER(w.Code)
     WHEN 'TEMPLATES' THEN (SELECT COUNT_BIG(*) FROM dbo.Templates WHERE Status='Published')
     WHEN 'INGESTION_FAILED' THEN (SELECT COUNT_BIG(*) FROM dbo.IngestionRun WHERE Status='Failed' AND StartedAtUtc>=CONVERT(date,SYSUTCDATETIME()))
     WHEN 'ACTIVE_ALERTS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE a.Status NOT IN('Closed','Rejected','Cancelled') AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     WHEN 'AGING_31_PLUS' THEN (SELECT COUNT_BIG(*) FROM dbo.Alerts a WHERE DATEDIFF(day,a.StageEnteredAtUtc,SYSUTCDATETIME())>=31 AND (EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='ALL') OR a.BranchCode=@BranchCode AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='BRANCH') OR EXISTS(SELECT 1 FROM dbo.WorkItems wi WHERE wi.AlertId=a.Id AND wi.AssignedUserId=@UserId) AND EXISTS(SELECT 1 FROM dbo.DataScopeMaster s WHERE s.RoleCode=@RoleCode AND s.IsActive=1 AND s.ScopeType='OWN')))
     ELSE CONVERT(bigint,0) END Value
   FROM dbo.DashboardWidgetMaster w JOIN dbo.DashboardWidgetRoleMapping m ON m.WidgetId=w.Id AND m.RoleCode=@RoleCode AND m.IsVisible=1
   WHERE w.IsActive=1 AND (w.PermissionCode='' OR EXISTS(SELECT 1 FROM P WHERE Code=w.PermissionCode)))
  SELECT * FROM W ORDER BY DisplayOrder; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_GetWidgetConfiguration
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
SELECT Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive FROM dbo.DashboardWidgetMaster ORDER BY DisplayOrder; RETURN;
END
GO

CREATE OR ALTER PROCEDURE dbo.USP_Dashboard_SaveWidget
    @strJson nvarchar(max) = N'{}'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @strJson = COALESCE(@strJson,N'{}');
    IF ISJSON(@strJson) <> 1
        THROW 50000, 'strJson must be valid JSON.', 1;

    DECLARE
        @UserId varchar(32)=JSON_VALUE(@strJson,'$.userId'),
        @RoleCode varchar(60)=JSON_VALUE(@strJson,'$.roleCode'),
        @BranchCode varchar(60)=JSON_VALUE(@strJson,'$.branchCode');
BEGIN TRAN;
  MERGE dbo.DashboardWidgetMaster t USING(SELECT * FROM OPENJSON(@strJson,'$.widget') WITH(Id varchar(32),Code varchar(80),Title nvarchar(150),WidgetType varchar(30),PermissionCode varchar(100),FilterJson nvarchar(max),DrillDownUrl nvarchar(500),DisplayOrder int,Width int,IsActive int))s ON t.Id=s.Id
  WHEN MATCHED THEN UPDATE SET Code=s.Code,Title=s.Title,WidgetType=s.WidgetType,PermissionCode=s.PermissionCode,FilterJson=s.FilterJson,DrillDownUrl=s.DrillDownUrl,DisplayOrder=s.DisplayOrder,Width=s.Width,IsActive=s.IsActive
  WHEN NOT MATCHED THEN INSERT(Id,Code,Title,WidgetType,PermissionCode,FilterJson,DrillDownUrl,DisplayOrder,Width,IsActive)VALUES(s.Id,s.Code,s.Title,s.WidgetType,s.PermissionCode,s.FilterJson,s.DrillDownUrl,s.DisplayOrder,s.Width,s.IsActive);
  MERGE dbo.DashboardWidgetRoleMapping t USING(SELECT JSON_VALUE(@strJson,'$.widget.id') WidgetId,JSON_VALUE(@strJson,'$.roleCode') RoleCode,CONVERT(int,JSON_VALUE(@strJson,'$.widget.displayOrder')) DisplayOrder,CONVERT(int,JSON_VALUE(@strJson,'$.widget.width')) Width)s ON t.WidgetId=s.WidgetId AND t.RoleCode=s.RoleCode
  WHEN MATCHED THEN UPDATE SET DisplayOrder=s.DisplayOrder,Width=s.Width,IsVisible=1 WHEN NOT MATCHED THEN INSERT(WidgetId,RoleCode,DisplayOrder,Width,IsVisible)VALUES(s.WidgetId,s.RoleCode,s.DisplayOrder,s.Width,1); COMMIT; RETURN;
END
GO
