@echo off
set ROOT=%~dp0
start "Enterprise MCP Server" cmd /k "cd /d %ROOT%mcp\EnterpriseMcp.Server && dotnet run"
timeout /t 2 /nobreak >nul
start "Agent Platform API" cmd /k "cd /d %ROOT%backend\AgentPlatform.Api && dotnet run"
timeout /t 2 /nobreak >nul
start "Agent Platform Gateway" cmd /k "cd /d %ROOT%gateway\AgentPlatform.Gateway && dotnet run"
echo.
echo V7 services are starting.
echo Open http://localhost:8080
