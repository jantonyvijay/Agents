# Enterprise Agent Platform V7 — API Gateway + MCP Client/Server + Discovery

V7 is the complete enterprise starter built from the earlier rich SPA version. It keeps the browser UI simple (HTML/CSS/jQuery in `wwwroot`) but adds a real edge gateway and a real MCP integration layer.

## What is included

### Agent Platform API + SPA
- ASP.NET Core 8 Web API
- `wwwroot/index.html` single-page application
- HTML/CSS/jQuery only — no React, Vite, Node or npm
- Workflow designer with drag/drop, animated connectors, node inspector and JSON persistence
- User-created connections: drag output port → input port
- User-removable connections: select a line and press Delete/Backspace, or remove from Inspector
- Agent, Tool and Model registries
- Workflow create/save/test/publish
- Human approval
- DEV/UAT/PROD context
- Audit trail and governance dashboard
- Execution history
- MCP Servers page
- API Gateway page

### Real MCP client
The Agent Platform uses the official MCP C# SDK (`ModelContextProtocol` 1.4.0).

Implemented:
- Streamable HTTP / auto-detect client transport
- MCP server registry (`Data/mcpservers.json`)
- Test connection / ping
- `tools/list` discovery
- `resources/list` discovery when supported by the remote server
- `prompts/list` discovery when supported by the remote server
- Import discovered MCP tools into `Data/tools.json`
- MCP tools become visible in normal Agent Platform discovery
- Drag imported MCP tools into workflows
- Workflow execution calls MCP `tools/call`
- MCP trust status (`Pending`, `Approved`, `Blocked`)
- MCP server enable/disable model
- Environment restriction on imported tools
- Optional MCP server API-key header from an environment variable

### Real MCP server
`mcp/EnterpriseMcp.Server` is a standalone ASP.NET Core Streamable HTTP MCP server using `ModelContextProtocol.AspNetCore`.

Endpoint:

```text
http://localhost:5100/mcp
```

Reference tools:

```text
enterprise_echo
classify_request
customer_lookup
calculate_risk
```

These are safe deterministic demo tools. Replace their internals with approved enterprise APIs/services.

### API Gateway
`gateway/AgentPlatform.Gateway` is a standalone YARP gateway.

Public URL:

```text
http://localhost:8080
```

Routes:

```text
/api/*  -> AgentPlatform.Api
/mcp/*  -> EnterpriseMcp.Server
/*      -> AgentPlatform.Api / wwwroot SPA
```

Gateway controls included:
- YARP reverse proxy
- Fixed-window rate limiting per tenant/IP
- Correlation ID generation/propagation
- Security response headers
- Optional API gateway key for `/api` and `/mcp`
- Dedicated `/gateway/health`
- Dedicated `/gateway/routes`
- Different upstream config for local and Docker environments

## Recommended runtime architecture

```text
Browser
  |
  v
API Gateway (YARP :8080)
  |------------------------------|
  |                              |
  v                              v
Agent Platform API :5000      MCP Server :5100
  |                              ^
  |                              |
  +--> Workflow Runtime          |
       |                         |
       +--> Agent / Model        |
       +--> Tool Gateway --------+
             |
             +--> HTTP tools
             +--> MCP Client
                    |
                    +--> tools/list
                    +--> resources/list
                    +--> prompts/list
                    +--> tools/call
```

## Project structure

```text
EnterpriseAgentPlatform/
|
|-- EnterpriseAgentPlatform.sln
|-- docker-compose.yml
|-- run-local.cmd
|-- run-local.sh
|
|-- gateway/
|   `-- AgentPlatform.Gateway/
|       |-- Program.cs
|       |-- appsettings.json
|       |-- appsettings.Docker.json
|       `-- AgentPlatform.Gateway.csproj
|
|-- mcp/
|   `-- EnterpriseMcp.Server/
|       |-- Program.cs
|       |-- appsettings.json
|       `-- EnterpriseMcp.Server.csproj
|
`-- backend/
    `-- AgentPlatform.Api/
        |-- Program.cs
        |-- Models/
        |-- Services/
        |   |-- McpClientService.cs
        |   |-- DiscoveryService.cs
        |   |-- ToolGateway.cs
        |   |-- WorkflowRuntime.cs
        |   `-- ...
        |-- Data/
        |   |-- mcpservers.json
        |   |-- tools.json
        |   |-- agents.json
        |   |-- workflows.json
        |   |-- executions.json
        |   `-- audit.json
        `-- wwwroot/
            |-- index.html
            |-- css/app.css
            `-- js/
                |-- app.js
                |-- common.js
                `-- designer.js
```

## Run — easiest option: Docker

Requires Docker Desktop / Docker Engine.

```bash
docker compose up --build
```

Open:

```text
http://localhost:8080
```

Direct service URLs are also exposed for development:

```text
Agent Platform API : http://localhost:5000
MCP Server         : http://localhost:5100/mcp
API Gateway        : http://localhost:8080
```

## Run — local .NET 8

### Windows

Double-click or run:

```bat
run-local.cmd
```

### Manual terminals

Terminal 1 — MCP Server:

```bash
cd mcp/EnterpriseMcp.Server
dotnet run
```

Terminal 2 — Agent Platform API:

```bash
cd backend/AgentPlatform.Api
dotnet run
```

Terminal 3 — API Gateway:

```bash
cd gateway/AgentPlatform.Gateway
dotnet run
```

Open:

```text
http://localhost:8080
```

## MCP discovery flow in the UI

1. Open **MCP Servers**.
2. The included `Enterprise Sample MCP` points to `http://localhost:5100/mcp`.
3. Click **Test**.
4. Click **Discover** to inspect tools.
5. Click **Discover + Import** to add the tools to the Tool Registry.
6. Open **Discover** or a Workflow Designer.
7. Search for `MCP`, `customer_lookup`, `calculate_risk`, etc.
8. Drag the imported tool to the workflow canvas.
9. Connect it to other nodes.
10. Save and Test the workflow.

An imported tool is persisted like this:

```json
{
  "id": "mcp-enterprise-sample-mcp-enterprise-echo",
  "name": "enterprise_echo",
  "type": "mcp",
  "config": {
    "mcpServerId": "enterprise-sample-mcp",
    "toolName": "enterprise_echo",
    "inputArgument": "input",
    "allowedEnvironments": "DEV"
  }
}
```

## MCP runtime path

```text
Workflow tool node
  -> ToolGateway
  -> trust/environment policy
  -> McpClientService
  -> MCP server registry lookup
  -> Streamable HTTP client
  -> tools/call
  -> result returned to workflow
```

If workflow input is valid JSON object text, its properties are sent as MCP tool arguments. Otherwise the value is sent under the configurable `inputArgument` (default: `input`).

## MCP APIs

```http
GET  /api/mcp/servers
POST /api/mcp/servers
PUT  /api/mcp/servers/{id}
POST /api/mcp/servers/{id}/test
POST /api/mcp/servers/{id}/discover?import=false
POST /api/mcp/servers/{id}/discover?import=true
POST /api/mcp/tools/{toolId}/call
```

## Existing platform APIs

```http
GET  /health
GET  /api/platform/overview
GET  /api/governance
GET  /api/audit

GET  /api/discovery
GET  /api/agents
GET  /api/tools
GET  /api/models

GET  /api/workflows
POST /api/workflows/create
PUT  /api/workflows/{id}
POST /api/workflows/{id}/publish
POST /api/workflows/{id}/execute

GET  /api/executions
POST /api/executions/{id}/approve
```

## Gateway endpoints

```http
GET /gateway/health
GET /gateway/routes
```

The Agent Platform also exposes:

```http
GET /api/gateway/info
```

for the SPA's API Gateway dashboard.

## API-key options

Agent Platform API:

```text
AGENT_PLATFORM_API_KEY
```

Gateway:

```text
AGENT_GATEWAY_API_KEY
```

When the gateway key is configured, `/api/*` and `/mcp/*` requests must include:

```http
X-API-Key: <key>
```

The static SPA itself stays readable so the browser can load the UI.

## MCP server credentials

A server definition can use:

```json
{
  "apiKeyHeader": "X-API-Key",
  "apiKeyEnvVar": "MY_MCP_API_KEY"
}
```

The secret itself is never stored in `mcpservers.json`; it is read from the environment at runtime.

## Demo persistence

The starter still uses JSON for easy demonstration:

```text
Data/workflows.json
Data/agents.json
Data/tools.json
Data/models.json
Data/mcpservers.json
Data/executions.json
Data/audit.json
```

For production, replace the registry repository with SQL Server without changing the SPA contracts.

## Production hardening next

V7 provides working implementation seams, but production deployment should additionally use:
- Microsoft Entra ID / OIDC and policy-based RBAC
- Azure API Management or hardened YARP deployment at the edge
- managed secrets such as Azure Key Vault
- SQL Server repositories with migrations and optimistic concurrency
- distributed cache and durable queue-backed workflow execution
- OpenTelemetry traces, metrics and centralized logs
- egress allow-listing for HTTP/MCP destinations
- formal MCP server onboarding/trust approval
- per-agent/per-tool authorization policies
- DEV → UAT → PROD promotion controls
- WAF/load balancer/TLS termination

## Package versions used

```text
Yarp.ReverseProxy                2.3.0
ModelContextProtocol             1.4.0
ModelContextProtocol.AspNetCore  1.4.0
Target framework                 net8.0
```
## V8 connection editing fix

V8 fixes connector hit-testing in the workflow designer. The full canvas stage previously sat above the SVG edge layer, which prevented connection paths from receiving click events.

Connection editing now supports:

- Click a connector line to select it.
- A wide invisible hit-area makes thin curved lines easy to select.
- The selected line is highlighted in red.
- A floating **Remove** control appears near the selected connection.
- The Inspector shows the selected connection, From/To nodes and condition.
- Delete from the Inspector.
- Press `Delete` or `Backspace` to remove the selected connection.
- Right-click a connection and confirm removal.
- Removed edges are deleted from the workflow `edges` array and persisted to `Data/workflows.json` when **Save** is clicked.


