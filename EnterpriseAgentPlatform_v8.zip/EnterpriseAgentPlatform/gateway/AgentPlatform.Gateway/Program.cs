using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddReverseProxy()
    .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));

builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy("platform", http =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: http.Request.Headers["X-Tenant-Id"].FirstOrDefault() ?? http.Connection.RemoteIpAddress?.ToString() ?? "anonymous",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 300,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 20,
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                AutoReplenishment = true
            }));
});

var app = builder.Build();

app.Use(async (context, next) =>
{
    var configuredKey = Environment.GetEnvironmentVariable("AGENT_GATEWAY_API_KEY");
    if (!string.IsNullOrWhiteSpace(configuredKey) && (context.Request.Path.StartsWithSegments("/api") || context.Request.Path.StartsWithSegments("/mcp")))
    {
        var supplied = context.Request.Headers["X-API-Key"].FirstOrDefault();
        if (!string.Equals(configuredKey, supplied, StringComparison.Ordinal))
        {
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            await context.Response.WriteAsJsonAsync(new { error = "API gateway key is missing or invalid." });
            return;
        }
    }

    var correlationId = context.Request.Headers["X-Correlation-Id"].FirstOrDefault();
    if (string.IsNullOrWhiteSpace(correlationId)) correlationId = Guid.NewGuid().ToString("N");
    context.Request.Headers["X-Correlation-Id"] = correlationId;
    context.Response.Headers["X-Correlation-Id"] = correlationId;
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["X-Frame-Options"] = "DENY";
    context.Response.Headers["Referrer-Policy"] = "no-referrer";
    await next();
});

app.UseRateLimiter();

app.MapGet("/gateway/health", () => Results.Ok(new
{
    status = "ok",
    service = "Agent Platform API Gateway",
    implementation = "YARP",
    utc = DateTimeOffset.UtcNow
}));

app.MapGet("/gateway/routes", (IConfiguration config) => Results.Ok(new
{
    api = config["ReverseProxy:Clusters:agent-api:Destinations:api:Address"],
    mcp = config["ReverseProxy:Clusters:enterprise-mcp:Destinations:mcp:Address"],
    policies = new[] { "fixed-window-rate-limit", "correlation-id", "security-headers", "reverse-proxy" }
}));

app.MapReverseProxy().RequireRateLimiting("platform");
app.Run();
