using System.ComponentModel;
using ModelContextProtocol.Server;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMcpServer()
    .WithHttpTransport(options => options.Stateless = true)
    .WithToolsFromAssembly();

var app = builder.Build();

app.MapGet("/health", () => Results.Ok(new
{
    status = "ok",
    service = "Enterprise Sample MCP Server",
    transport = "streamable-http",
    endpoint = "/mcp",
    utc = DateTimeOffset.UtcNow
}));

app.MapMcp("/mcp");
app.Run();

[McpServerToolType]
public static class EnterpriseTools
{
    [McpServerTool(Name = "enterprise_echo"), Description("Echoes an enterprise workflow input. Useful for validating MCP connectivity and execution.")]
    public static string Echo([Description("Input text from the workflow")] string input)
        => $"MCP echo: {input}";

    [McpServerTool(Name = "classify_request"), Description("Classifies a request into Data, Integration, Knowledge, Governance, or General categories.")]
    public static string ClassifyRequest([Description("Request text to classify")] string input)
    {
        var v = input.ToLowerInvariant();
        var category = v.Contains("sql") || v.Contains("database") ? "Data"
            : v.Contains("api") || v.Contains("integration") ? "Integration"
            : v.Contains("rag") || v.Contains("document") || v.Contains("knowledge") ? "Knowledge"
            : v.Contains("approve") || v.Contains("risk") || v.Contains("audit") ? "Governance"
            : "General";
        return $"{category}: {input}";
    }

    [McpServerTool(Name = "customer_lookup"), Description("Returns deterministic demo customer data for a supplied customer reference. Replace with an approved enterprise API implementation.")]
    public static string CustomerLookup([Description("Customer reference or search text")] string input)
        => $$"""{"customerRef":"{{input}}","status":"Active","segment":"Enterprise Demo","source":"MCP Sample Server"}""";

    [McpServerTool(Name = "calculate_risk"), Description("Calculates a deterministic demo risk classification from input text. No external data is used.")]
    public static string CalculateRisk([Description("Text to assess")] string input)
    {
        var score = (int)(Math.Abs((long)input.GetHashCode(StringComparison.Ordinal)) % 100);
        var level = score >= 70 ? "High" : score >= 40 ? "Medium" : "Low";
        return $$"""{"score":{{score}},"level":"{{level}}","note":"Demo-only deterministic risk result"}""";
    }
}
