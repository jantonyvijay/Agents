#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
(dotnet run --project "$ROOT/mcp/EnterpriseMcp.Server/EnterpriseMcp.Server.csproj" --urls http://localhost:5100) &
MCP_PID=$!
(dotnet run --project "$ROOT/backend/AgentPlatform.Api/AgentPlatform.Api.csproj" --urls http://localhost:5000) &
API_PID=$!
(dotnet run --project "$ROOT/gateway/AgentPlatform.Gateway/AgentPlatform.Gateway.csproj" --urls http://localhost:8080) &
GW_PID=$!
trap 'kill $MCP_PID $API_PID $GW_PID 2>/dev/null || true' EXIT
printf 'Enterprise Agent Platform V7: http://localhost:8080\n'
wait
