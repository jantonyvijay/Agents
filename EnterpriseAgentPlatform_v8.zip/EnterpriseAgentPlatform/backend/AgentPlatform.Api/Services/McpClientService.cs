using System.Text.Json;
using AgentPlatform.Api.Models;
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;

namespace AgentPlatform.Api.Services;

public sealed class McpClientService(RegistryService registry)
{
    public async Task<McpDiscoveryResult> DiscoverAsync(McpServerDefinition server, bool import, CancellationToken ct)
    {
        var result = new McpDiscoveryResult { ServerId = server.Id, ServerName = server.Name };
        try
        {
            await using var client = await CreateClientAsync(server, ct);
            var tools = await client.ListToolsAsync(cancellationToken: ct);
            var registered = await registry.Tools.GetAllAsync();
            result.Tools = tools.Select(t => new McpDiscoveredTool
            {
                Name = t.Name,
                Description = t.Description ?? "",
                ServerId = server.Id,
                ServerName = server.Name,
                Imported = registered.Any(x => x.Type.Equals("mcp", StringComparison.OrdinalIgnoreCase)
                    && x.Config.GetValueOrDefault("mcpServerId") == server.Id
                    && x.Config.GetValueOrDefault("toolName") == t.Name)
            }).ToList();

            try { result.Resources = (await client.ListResourcesAsync(cancellationToken: ct)).Select(x => x.Uri).ToList(); } catch { }
            try { result.Prompts = (await client.ListPromptsAsync(cancellationToken: ct)).Select(x => x.Name).ToList(); } catch { }

            result.Connected = true;
            server.LastDiscoveredAtUtc = DateTimeOffset.UtcNow;
            server.ToolCount = result.Tools.Count;
            server.ResourceCount = result.Resources.Count;
            server.PromptCount = result.Prompts.Count;
            await registry.McpServers.UpsertAsync(server);

            if (import)
            {
                foreach (var t in result.Tools)
                {
                    var id = $"mcp-{SafeId(server.Id)}-{SafeId(t.Name)}";
                    await registry.Tools.UpsertAsync(new ToolDefinition
                    {
                        Id = id,
                        Name = t.Name,
                        Description = string.IsNullOrWhiteSpace(t.Description) ? $"MCP tool from {server.Name}" : t.Description,
                        Category = "MCP",
                        Tags = ["mcp", server.Name, server.Environment.ToLowerInvariant()],
                        Type = "mcp",
                        Config = new(StringComparer.OrdinalIgnoreCase)
                        {
                            ["mcpServerId"] = server.Id,
                            ["toolName"] = t.Name,
                            ["inputArgument"] = "input",
                            ["allowedEnvironments"] = server.Environment
                        },
                        Enabled = server.Enabled && server.TrustStatus.Equals("Approved", StringComparison.OrdinalIgnoreCase)
                    });
                    t.Imported = true;
                }
            }
        }
        catch (Exception ex)
        {
            result.Connected = false;
            result.Error = ex.Message;
        }
        return result;
    }

    public async Task<string> CallAsync(ToolDefinition tool, string input, CancellationToken ct)
    {
        if (!tool.Config.TryGetValue("mcpServerId", out var serverId)) throw new InvalidOperationException("MCP tool requires config.mcpServerId.");
        if (!tool.Config.TryGetValue("toolName", out var toolName)) throw new InvalidOperationException("MCP tool requires config.toolName.");
        var server = await registry.McpServers.GetAsync(serverId) ?? throw new KeyNotFoundException($"MCP server '{serverId}' not found.");
        if (!server.Enabled) throw new InvalidOperationException($"MCP server '{server.Name}' is disabled.");
        if (!server.TrustStatus.Equals("Approved", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException($"MCP server '{server.Name}' is not approved.");

        Dictionary<string, object?> args;
        try
        {
            using var doc = JsonDocument.Parse(input);
            if (doc.RootElement.ValueKind == JsonValueKind.Object)
                args = doc.RootElement.EnumerateObject().ToDictionary(p => p.Name, p => (object?)JsonSerializer.Deserialize<object>(p.Value.GetRawText()));
            else throw new JsonException();
        }
        catch
        {
            args = new(StringComparer.OrdinalIgnoreCase)
            {
                [tool.Config.GetValueOrDefault("inputArgument", "input")] = input
            };
        }

        await using var client = await CreateClientAsync(server, ct);
        var response = await client.CallToolAsync(toolName, args, cancellationToken: ct);
        var text = response.Content.OfType<TextContentBlock>().Select(x => x.Text).Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
        return text.Count > 0 ? string.Join(Environment.NewLine, text) : JsonSerializer.Serialize(response);
    }

    public async Task<bool> PingAsync(McpServerDefinition server, CancellationToken ct)
    {
        await using var client = await CreateClientAsync(server, ct);
        await client.PingAsync(cancellationToken: ct);
        return true;
    }

    private static async Task<McpClient> CreateClientAsync(McpServerDefinition server, CancellationToken ct)
    {
        var endpointValue = !string.IsNullOrWhiteSpace(server.EndpointEnvVar) ? Environment.GetEnvironmentVariable(server.EndpointEnvVar) ?? server.Endpoint : server.Endpoint;
        if (!Uri.TryCreate(endpointValue, UriKind.Absolute, out var endpoint)) throw new InvalidOperationException("MCP endpoint is invalid.");
        var headers = new Dictionary<string, string>();
        if (!string.IsNullOrWhiteSpace(server.ApiKeyHeader) && !string.IsNullOrWhiteSpace(server.ApiKeyEnvVar))
        {
            var secret = Environment.GetEnvironmentVariable(server.ApiKeyEnvVar);
            if (!string.IsNullOrWhiteSpace(secret)) headers[server.ApiKeyHeader] = secret;
        }
        var transport = new HttpClientTransport(new HttpClientTransportOptions
        {
            Endpoint = endpoint,
            TransportMode = HttpTransportMode.AutoDetect,
            ConnectionTimeout = TimeSpan.FromSeconds(20),
            AdditionalHeaders = headers
        });
        return await McpClient.CreateAsync(transport, cancellationToken: ct);
    }

    private static string SafeId(string value) => new(value.ToLowerInvariant().Select(c => char.IsLetterOrDigit(c) ? c : '-').ToArray());
}
