using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class AuditService
{
    private readonly RegistryService _registry;

    public AuditService(RegistryService registry) => _registry = registry;

    public Task WriteAsync(HttpContext http, string action, string resourceType, string resourceId, string detail, string outcome = "Success")
    {
        var record = new AuditRecord
        {
            TenantId = http.Request.Headers["X-Tenant-Id"].FirstOrDefault() ?? "default",
            Environment = http.Request.Headers["X-Environment"].FirstOrDefault() ?? "DEV",
            UserId = http.Request.Headers["X-User-Id"].FirstOrDefault() ?? "anonymous",
            Action = action,
            ResourceType = resourceType,
            ResourceId = resourceId,
            Detail = detail,
            Outcome = outcome
        };
        return _registry.Audit.UpsertAsync(record);
    }
}
