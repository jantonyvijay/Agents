using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class DiscoveryService(RegistryService registry)
{
    public async Task<DiscoveryResponse> SearchAsync(string? query, string? kind = "all")
    {
        var q = (query ?? "").Trim();
        var normalizedKind = (kind ?? "all").Trim().ToLowerInvariant();
        var response = new DiscoveryResponse { Query = q };

        if (normalizedKind is "all" or "agent" or "agents")
        {
            var agents = (await registry.Agents.GetAllAsync()).Where(x => x.Enabled);
            response.Agents = agents
                .Select(x => new { Item = x, Score = ScoreAgent(x, q) })
                .Where(x => string.IsNullOrWhiteSpace(q) || x.Score > 0)
                .OrderByDescending(x => x.Score)
                .ThenBy(x => x.Item.Name)
                .Select(x => x.Item)
                .ToList();
        }

        if (normalizedKind is "all" or "tool" or "tools")
        {
            var tools = (await registry.Tools.GetAllAsync()).Where(x => x.Enabled);
            response.Tools = tools
                .Select(x => new { Item = x, Score = ScoreTool(x, q) })
                .Where(x => string.IsNullOrWhiteSpace(q) || x.Score > 0)
                .OrderByDescending(x => x.Score)
                .ThenBy(x => x.Item.Name)
                .Select(x => x.Item)
                .ToList();
        }

        return response;
    }

    private static int ScoreAgent(AgentDefinition x, string q)
    {
        if (string.IsNullOrWhiteSpace(q)) return 1;
        return Score(q, x.Name, 10) + Score(q, x.Description, 6) + Score(q, x.Category, 5)
             + x.Capabilities.Sum(v => Score(q, v, 8)) + x.Tags.Sum(v => Score(q, v, 4));
    }

    private static int ScoreTool(ToolDefinition x, string q)
    {
        if (string.IsNullOrWhiteSpace(q)) return 1;
        return Score(q, x.Name, 10) + Score(q, x.Description, 6) + Score(q, x.Category, 5)
             + Score(q, x.Type, 5) + x.Tags.Sum(v => Score(q, v, 4));
    }

    private static int Score(string q, string? value, int weight)
    {
        if (string.IsNullOrWhiteSpace(value)) return 0;
        if (value.Equals(q, StringComparison.OrdinalIgnoreCase)) return weight * 3;
        if (value.StartsWith(q, StringComparison.OrdinalIgnoreCase)) return weight * 2;
        return value.Contains(q, StringComparison.OrdinalIgnoreCase) ? weight : 0;
    }
}
