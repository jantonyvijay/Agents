using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class RegistryService
{
    public JsonRegistry<AgentDefinition> Agents { get; }
    public JsonRegistry<ModelDefinition> Models { get; }
    public JsonRegistry<ToolDefinition> Tools { get; }
    public JsonRegistry<WorkflowDefinition> Workflows { get; }
    public JsonRegistry<ExecutionRecord> Executions { get; }
    public JsonRegistry<AuditRecord> Audit { get; }
    public JsonRegistry<McpServerDefinition> McpServers { get; }

    public RegistryService(IWebHostEnvironment env)
    {
        var root = Path.Combine(env.ContentRootPath, "Data");
        Agents = new(Path.Combine(root, "agents.json"), x => x.Id);
        Models = new(Path.Combine(root, "models.json"), x => x.Id);
        Tools = new(Path.Combine(root, "tools.json"), x => x.Id);
        Workflows = new(Path.Combine(root, "workflows.json"), x => x.Id);
        Executions = new(Path.Combine(root, "executions.json"), x => x.Id);
        Audit = new(Path.Combine(root, "audit.json"), x => x.Id);
        McpServers = new(Path.Combine(root, "mcpservers.json"), x => x.Id);
    }
}
