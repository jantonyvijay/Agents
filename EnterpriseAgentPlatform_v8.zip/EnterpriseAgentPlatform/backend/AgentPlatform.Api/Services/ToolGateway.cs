using System.Text;
using System.Text.Json;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class ToolGateway(HttpClient http, McpClientService mcp)
{
    public async Task<string> ExecuteAsync(ToolDefinition tool, string input, string environment, CancellationToken ct)
    {
        if (!tool.Enabled) throw new InvalidOperationException($"Tool '{tool.Name}' is disabled.");

        if (tool.Config.TryGetValue("allowedEnvironments", out var allowed) && !string.IsNullOrWhiteSpace(allowed))
        {
            var environments = allowed.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
            if (!environments.Contains(environment, StringComparer.OrdinalIgnoreCase))
                throw new InvalidOperationException($"Tool '{tool.Name}' is not approved for environment '{environment}'.");
        }

        if (tool.Type.Equals("mock", StringComparison.OrdinalIgnoreCase))
            return tool.Config.TryGetValue("response", out var response) ? response.Replace("{{input}}", input) : $"Mock tool result for: {input}";

        if (tool.Type.Equals("mcp", StringComparison.OrdinalIgnoreCase))
            return await mcp.CallAsync(tool, input, ct);

        if (!tool.Type.Equals("http", StringComparison.OrdinalIgnoreCase))
            throw new NotSupportedException($"Tool type '{tool.Type}' is not supported.");

        if (!tool.Config.TryGetValue("url", out var url) || string.IsNullOrWhiteSpace(url))
            throw new InvalidOperationException("HTTP tool requires config.url.");

        var method = tool.Config.GetValueOrDefault("method", "GET").ToUpperInvariant();
        var resolvedUrl = url.Replace("{{input}}", Uri.EscapeDataString(input));
        using var req = new HttpRequestMessage(new HttpMethod(method), resolvedUrl);

        if (method is "POST" or "PUT" or "PATCH")
        {
            var bodyTemplate = tool.Config.GetValueOrDefault("body", "{\"input\":\"{{input}}\"}");
            var body = bodyTemplate.Replace("{{input}}", JsonEncodedText.Encode(input).ToString());
            req.Content = new StringContent(body, Encoding.UTF8, tool.Config.GetValueOrDefault("contentType", "application/json"));
        }

        if (tool.Config.TryGetValue("bearerTokenEnvVar", out var envName) && !string.IsNullOrWhiteSpace(envName))
        {
            var token = Environment.GetEnvironmentVariable(envName);
            if (!string.IsNullOrWhiteSpace(token)) req.Headers.Authorization = new("Bearer", token);
        }

        using var res = await http.SendAsync(req, ct);
        var result = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
            throw new InvalidOperationException($"Tool call failed ({(int)res.StatusCode}): {result}");
        return result;
    }
}
