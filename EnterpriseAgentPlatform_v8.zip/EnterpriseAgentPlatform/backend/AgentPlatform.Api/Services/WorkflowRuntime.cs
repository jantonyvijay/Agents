using System.Text.Json.Nodes;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class WorkflowRuntime(RegistryService registry, ModelGateway modelGateway, ToolGateway toolGateway, ILogger<WorkflowRuntime> logger)
{
    public async Task<ExecutionRecord> StartAsync(WorkflowDefinition workflow, string input, string tenantId, string environment, string userId, Dictionary<string,string>? context, CancellationToken ct)
    {
        var start = workflow.Nodes.FirstOrDefault(n => n.Type.Equals("start", StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("Workflow requires a start node.");

        var execution = new ExecutionRecord
        {
            WorkflowId = workflow.Id,
            WorkflowVersion = workflow.Version,
            TenantId = tenantId,
            Environment = environment,
            UserId = userId,
            Input = input,
            CurrentNodeId = start.Id,
            LastOutput = input,
            Status = "Running"
        };

        if (context is not null)
            foreach (var pair in context) execution.State[$"context:{pair.Key}"] = pair.Value;

        await registry.Executions.UpsertAsync(execution);
        return await RunAsync(workflow, execution, ct);
    }

    public async Task<ExecutionRecord> ApproveAsync(string executionId, bool approved, string? comment, CancellationToken ct)
    {
        var execution = await registry.Executions.GetAsync(executionId)
            ?? throw new KeyNotFoundException("Execution not found.");
        var workflow = await registry.Workflows.GetAsync(execution.WorkflowId)
            ?? throw new KeyNotFoundException("Workflow not found.");

        if (!string.Equals(execution.Status, "AwaitingApproval", StringComparison.OrdinalIgnoreCase) || execution.CurrentNodeId is null)
            throw new InvalidOperationException("Execution is not awaiting approval.");

        execution.State[$"approval:{execution.CurrentNodeId}"] = approved;
        execution.State[$"approvalComment:{execution.CurrentNodeId}"] = comment ?? "";
        execution.Status = approved ? "Running" : "Rejected";
        execution.Logs.Add(new() { NodeId = execution.CurrentNodeId, NodeType = "approval", Message = approved ? "Approved by human." : "Rejected by human." });

        if (!approved)
        {
            execution.CompletedAtUtc = DateTimeOffset.UtcNow;
            await registry.Executions.UpsertAsync(execution);
            return execution;
        }

        await registry.Executions.UpsertAsync(execution);
        return await RunAsync(workflow, execution, ct);
    }

    private async Task<ExecutionRecord> RunAsync(WorkflowDefinition workflow, ExecutionRecord execution, CancellationToken ct)
    {
        var safetyCounter = 0;
        while (execution.CurrentNodeId is not null && safetyCounter++ < 200)
        {
            ct.ThrowIfCancellationRequested();
            var node = workflow.Nodes.FirstOrDefault(n => n.Id == execution.CurrentNodeId)
                ?? throw new InvalidOperationException($"Node '{execution.CurrentNodeId}' not found.");

            try
            {
                Log(execution, node, $"Executing {node.Label}.");
                switch (node.Type.ToLowerInvariant())
                {
                    case "start":
                        break;

                    case "agent":
                    {
                        var agentId = node.Config.GetValueOrDefault("agentId") ?? throw new InvalidOperationException("Agent node requires config.agentId.");
                        var agent = await registry.Agents.GetAsync(agentId) ?? throw new InvalidOperationException($"Agent '{agentId}' not found.");
                        var context = BuildContext(execution);
                        execution.LastOutput = await modelGateway.GenerateAsync(agent, execution.LastOutput, context, ct);
                        execution.State["lastAgentResponse"] = execution.LastOutput;
                        break;
                    }

                    case "tool":
                    {
                        var toolId = node.Config.GetValueOrDefault("toolId") ?? throw new InvalidOperationException("Tool node requires config.toolId.");
                        var tool = await registry.Tools.GetAsync(toolId) ?? throw new InvalidOperationException($"Tool '{toolId}' not found.");
                        execution.LastOutput = await toolGateway.ExecuteAsync(tool, execution.LastOutput, execution.Environment, ct);
                        execution.State["lastToolResult"] = execution.LastOutput;
                        break;
                    }

                    case "decision":
                        execution.CurrentNodeId = SelectDecisionTarget(workflow, node, execution.LastOutput);
                        await registry.Executions.UpsertAsync(execution);
                        continue;

                    case "approval":
                    {
                        var key = $"approval:{node.Id}";
                        var isApproved = execution.State[key] is JsonValue approvalValue && approvalValue.TryGetValue<bool>(out var approvedValue) && approvedValue;
                        if (!isApproved)
                        {
                            execution.Status = "AwaitingApproval";
                            Log(execution, node, "Workflow paused for human approval.");
                            await registry.Executions.UpsertAsync(execution);
                            return execution;
                        }
                        break;
                    }

                    case "end":
                        execution.Status = "Completed";
                        execution.CompletedAtUtc = DateTimeOffset.UtcNow;
                        execution.CurrentNodeId = null;
                        Log(execution, node, "Workflow completed.");
                        await registry.Executions.UpsertAsync(execution);
                        return execution;

                    default:
                        throw new NotSupportedException($"Node type '{node.Type}' is not supported.");
                }

                execution.CurrentNodeId = SelectDefaultTarget(workflow, node.Id);
                if (execution.CurrentNodeId is null && !node.Type.Equals("end", StringComparison.OrdinalIgnoreCase))
                {
                    execution.Status = "Completed";
                    execution.CompletedAtUtc = DateTimeOffset.UtcNow;
                }
                await registry.Executions.UpsertAsync(execution);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Workflow {WorkflowId} execution {ExecutionId} failed at node {NodeId}", workflow.Id, execution.Id, node.Id);
                Log(execution, node, ex.Message, "Error");
                execution.Status = "Failed";
                execution.CompletedAtUtc = DateTimeOffset.UtcNow;
                await registry.Executions.UpsertAsync(execution);
                return execution;
            }
        }

        if (safetyCounter >= 200)
        {
            execution.Status = "Failed";
            execution.Logs.Add(new() { NodeId = execution.CurrentNodeId ?? "", NodeType = "runtime", Level = "Error", Message = "Execution stopped by cycle safety limit." });
            execution.CompletedAtUtc = DateTimeOffset.UtcNow;
            await registry.Executions.UpsertAsync(execution);
        }
        return execution;
    }

    private static string BuildContext(ExecutionRecord execution)
    {
        var pairs = execution.State.Select(x => $"{x.Key}: {x.Value?.ToJsonString()}");
        return string.Join(Environment.NewLine, pairs);
    }

    private static string? SelectDefaultTarget(WorkflowDefinition workflow, string nodeId) =>
        workflow.Edges.FirstOrDefault(e => e.Source == nodeId && (string.IsNullOrWhiteSpace(e.Condition) || e.Condition.Equals("always", StringComparison.OrdinalIgnoreCase)))?.Target
        ?? workflow.Edges.FirstOrDefault(e => e.Source == nodeId)?.Target;

    private static string? SelectDecisionTarget(WorkflowDefinition workflow, WorkflowNode node, string lastOutput)
    {
        var edges = workflow.Edges.Where(e => e.Source == node.Id).ToList();
        foreach (var edge in edges)
        {
            var c = edge.Condition?.Trim() ?? "always";
            if (c.Equals("always", StringComparison.OrdinalIgnoreCase)) continue;
            if (c.StartsWith("contains:", StringComparison.OrdinalIgnoreCase) && lastOutput.Contains(c[9..], StringComparison.OrdinalIgnoreCase)) return edge.Target;
            if (c.StartsWith("equals:", StringComparison.OrdinalIgnoreCase) && lastOutput.Equals(c[7..], StringComparison.OrdinalIgnoreCase)) return edge.Target;
        }
        return edges.FirstOrDefault(e => string.IsNullOrWhiteSpace(e.Condition) || e.Condition.Equals("always", StringComparison.OrdinalIgnoreCase))?.Target;
    }

    private static void Log(ExecutionRecord execution, WorkflowNode node, string message, string level = "Information") =>
        execution.Logs.Add(new() { NodeId = node.Id, NodeType = node.Type, Level = level, Message = message });
}
