using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using AgentPlatform.Api.Models;

namespace AgentPlatform.Api.Services;

public sealed class ModelGateway(HttpClient http, RegistryService registry)
{
    public async Task<string> GenerateAsync(AgentDefinition agent, string input, string context, CancellationToken ct)
    {
        var model = await registry.Models.GetAsync(agent.ModelId)
            ?? throw new InvalidOperationException($"Model '{agent.ModelId}' was not found.");

        if (!model.Enabled) throw new InvalidOperationException($"Model '{model.Name}' is disabled.");

        if (model.Provider.Equals("mock", StringComparison.OrdinalIgnoreCase))
            return $"[{agent.Name}] Processed: {input}" + (string.IsNullOrWhiteSpace(context) ? "" : $" | Context: {context}");

        if (!model.Provider.Equals("openai-compatible", StringComparison.OrdinalIgnoreCase))
            throw new NotSupportedException($"Provider '{model.Provider}' is not supported by this starter.");

        var apiKey = Environment.GetEnvironmentVariable(model.ApiKeyEnvVar);
        if (string.IsNullOrWhiteSpace(apiKey))
            throw new InvalidOperationException($"Environment variable '{model.ApiKeyEnvVar}' is not configured.");

        var baseUrl = model.BaseUrl.TrimEnd('/');
        var requestUrl = $"{baseUrl}/v1/chat/completions";
        var payload = new
        {
            model = model.Model,
            temperature = model.Temperature,
            max_tokens = model.MaxTokens,
            messages = new object[]
            {
                new { role = "system", content = agent.SystemPrompt },
                new { role = "user", content = $"{input}\n\nWorkflow context:\n{context}" }
            }
        };

        using var req = new HttpRequestMessage(HttpMethod.Post, requestUrl);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
        req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

        using var res = await http.SendAsync(req, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
            throw new InvalidOperationException($"Model request failed ({(int)res.StatusCode}): {body}");

        using var doc = JsonDocument.Parse(body);
        return doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString() ?? "";
    }
}
