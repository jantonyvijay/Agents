using System.Text.Json;

namespace AgentPlatform.Api.Services;

public sealed class JsonRegistry<T> where T : class
{
    private readonly string _path;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    private readonly Func<T, string> _idSelector;

    public JsonRegistry(string path, Func<T, string> idSelector)
    {
        _path = path;
        _idSelector = idSelector;
        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
        if (!File.Exists(_path)) File.WriteAllText(_path, "[]");
    }

    public async Task<List<T>> GetAllAsync()
    {
        await _gate.WaitAsync();
        try
        {
            await using var stream = File.OpenRead(_path);
            return await JsonSerializer.DeserializeAsync<List<T>>(stream, _json) ?? [];
        }
        finally { _gate.Release(); }
    }

    public async Task<T?> GetAsync(string id) => (await GetAllAsync()).FirstOrDefault(x => _idSelector(x) == id);

    public async Task<T> UpsertAsync(T item)
    {
        await _gate.WaitAsync();
        try
        {
            List<T> items;
            await using (var read = File.OpenRead(_path))
                items = await JsonSerializer.DeserializeAsync<List<T>>(read, _json) ?? [];

            var index = items.FindIndex(x => _idSelector(x) == _idSelector(item));
            if (index >= 0) items[index] = item; else items.Add(item);

            var temp = _path + ".tmp";
            await File.WriteAllTextAsync(temp, JsonSerializer.Serialize(items, _json));
            File.Move(temp, _path, true);
            return item;
        }
        finally { _gate.Release(); }
    }
}
