using System.Text.Json.Nodes;

namespace AgentPlatform.Api.Models;

public sealed class AgentDefinition
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "New Agent";
    public string Description { get; set; } = "";
    public string Category { get; set; } = "General";
    public List<string> Capabilities { get; set; } = [];
    public List<string> Tags { get; set; } = [];
    public string SystemPrompt { get; set; } = "You are a helpful enterprise agent.";
    public string ModelId { get; set; } = "mock-model";
    public List<string> ToolIds { get; set; } = [];
    public bool Enabled { get; set; } = true;
}

public sealed class ModelDefinition
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Model";
    public string Provider { get; set; } = "mock"; // mock | openai-compatible
    public string BaseUrl { get; set; } = "";
    public string Model { get; set; } = "";
    public string ApiKeyEnvVar { get; set; } = "OPENAI_API_KEY";
    public double Temperature { get; set; } = 0.2;
    public int MaxTokens { get; set; } = 800;
    public bool Enabled { get; set; } = true;
}

public sealed class ToolDefinition
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Tool";
    public string Description { get; set; } = "";
    public string Category { get; set; } = "General";
    public List<string> Tags { get; set; } = [];
    public string Type { get; set; } = "mock"; // mock | http | mcp
    public Dictionary<string, string> Config { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public bool Enabled { get; set; } = true;
}

public sealed class WorkflowDefinition
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "New Workflow";
    public string Description { get; set; } = "";
    public int Version { get; set; } = 1;
    public string Status { get; set; } = "Draft";
    public string Owner { get; set; } = "Agent Platform Team";
    public string Environment { get; set; } = "DEV";
    public string RiskLevel { get; set; } = "Low";
    public bool RequiresApproval { get; set; }
    public List<string> Tags { get; set; } = [];
    public DateTimeOffset UpdatedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public string UpdatedBy { get; set; } = "system";
    public List<WorkflowNode> Nodes { get; set; } = [];
    public List<WorkflowEdge> Edges { get; set; } = [];
}

public sealed class WorkflowNode
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Type { get; set; } = "agent"; // start|agent|tool|decision|approval|end
    public string Label { get; set; } = "Node";
    public double X { get; set; }
    public double Y { get; set; }
    public Dictionary<string, string> Config { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class WorkflowEdge
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Source { get; set; } = "";
    public string Target { get; set; } = "";
    public string Condition { get; set; } = "always";
}

public sealed class DiscoveryResponse
{
    public string Query { get; set; } = "";
    public List<AgentDefinition> Agents { get; set; } = [];
    public List<ToolDefinition> Tools { get; set; } = [];
}

public sealed class ExecutionRecord
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string WorkflowId { get; set; } = "";
    public int WorkflowVersion { get; set; } = 1;
    public string TenantId { get; set; } = "default";
    public string Environment { get; set; } = "DEV";
    public string UserId { get; set; } = "anonymous";
    public string CorrelationId { get; set; } = Guid.NewGuid().ToString("N");
    public string Input { get; set; } = "";
    public string Status { get; set; } = "Running";
    public string? CurrentNodeId { get; set; }
    public string LastOutput { get; set; } = "";
    public JsonObject State { get; set; } = new();
    public List<ExecutionLogEntry> Logs { get; set; } = [];
    public DateTimeOffset StartedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? CompletedAtUtc { get; set; }
}

public sealed class ExecutionLogEntry
{
    public DateTimeOffset AtUtc { get; set; } = DateTimeOffset.UtcNow;
    public string NodeId { get; set; } = "";
    public string NodeType { get; set; } = "";
    public string Level { get; set; } = "Information";
    public string Message { get; set; } = "";
}

public sealed class AuditRecord
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public DateTimeOffset AtUtc { get; set; } = DateTimeOffset.UtcNow;
    public string TenantId { get; set; } = "default";
    public string Environment { get; set; } = "DEV";
    public string UserId { get; set; } = "anonymous";
    public string Action { get; set; } = "Read";
    public string ResourceType { get; set; } = "Platform";
    public string ResourceId { get; set; } = "";
    public string Detail { get; set; } = "";
    public string Outcome { get; set; } = "Success";
}


public sealed class McpServerDefinition
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "MCP Server";
    public string Description { get; set; } = "";
    public string Transport { get; set; } = "streamable-http";
    public string Endpoint { get; set; } = "";
    public string? EndpointEnvVar { get; set; }
    public string Environment { get; set; } = "DEV";
    public string TrustStatus { get; set; } = "Pending"; // Pending | Approved | Blocked
    public string? ApiKeyHeader { get; set; }
    public string? ApiKeyEnvVar { get; set; }
    public bool Enabled { get; set; } = true;
    public DateTimeOffset? LastDiscoveredAtUtc { get; set; }
    public int ToolCount { get; set; }
    public int ResourceCount { get; set; }
    public int PromptCount { get; set; }
}

public sealed class McpDiscoveredTool
{
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string ServerId { get; set; } = "";
    public string ServerName { get; set; } = "";
    public bool Imported { get; set; }
}

public sealed class McpDiscoveryResult
{
    public string ServerId { get; set; } = "";
    public string ServerName { get; set; } = "";
    public bool Connected { get; set; }
    public string? Error { get; set; }
    public DateTimeOffset AtUtc { get; set; } = DateTimeOffset.UtcNow;
    public List<McpDiscoveredTool> Tools { get; set; } = [];
    public List<string> Resources { get; set; } = [];
    public List<string> Prompts { get; set; } = [];
}

public sealed class McpCallRequest
{
    public Dictionary<string, object?> Arguments { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}
