namespace AgentPlatform.Api.Contracts;

public sealed record ExecuteWorkflowRequest(string Input, Dictionary<string, string>? Context = null);
public sealed record ApprovalRequest(bool Approved, string? Comment = null);
public sealed record CreateWorkflowRequest(
    string Name,
    string? Description = null,
    string Template = "blank",
    string? Owner = null,
    string? Environment = null,
    string? RiskLevel = null,
    bool RequiresApproval = false);
