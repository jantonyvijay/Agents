namespace AgentPlatform.Api.Middleware;

public sealed class ApiKeyMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var configured = Environment.GetEnvironmentVariable("AGENT_PLATFORM_API_KEY");
        var protectedRequest = context.Request.Path.StartsWithSegments("/api") || context.Request.Path.StartsWithSegments("/health");

        if (protectedRequest && !string.IsNullOrWhiteSpace(configured))
        {
            if (!context.Request.Headers.TryGetValue("X-API-Key", out var supplied) || supplied != configured)
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsJsonAsync(new { error = "Invalid or missing X-API-Key." });
                return;
            }
        }

        await next(context);
    }
}
