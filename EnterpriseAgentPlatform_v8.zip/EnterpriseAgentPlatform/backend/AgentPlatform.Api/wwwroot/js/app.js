(function ($, AP) {
    "use strict";

    var cache = { workflows: [], agents: [], tools: [], models: [], executions: [], mcpServers: [], discovery: { agents: [], tools: [] } };
    var currentRoute = "";
    var discoverKind = "all";

    function parseRoute() {
        var hash = (location.hash || "#/dashboard").replace(/^#\/?/, "");
        var parts = hash.split("/").filter(Boolean);
        return { name: parts[0] || "dashboard", id: parts[1] ? decodeURIComponent(parts[1]) : null };
    }

    function routeTitle(name) {
        return ({ dashboard: "Dashboard", workflows: "Workflows", discover: "Discover", agents: "Agents", tools: "Tools", models: "Models", mcp: "MCP Servers", gateway: "API Gateway", executions: "Executions", governance: "Governance", settings: "Settings", designer: "Workflow Designer" })[name] || "Dashboard";
    }

    function navigate() {
        var route = parseRoute();
        if (currentRoute === "designer" && route.name !== "designer" && window.AgentDesigner) AgentDesigner.destroy();
        currentRoute = route.name;
        $(".spa-page").addClass("hidden");
        var $page = $("#page-" + route.name);
        if (!$page.length) { location.hash = "#/dashboard"; return; }
        $page.removeClass("hidden");
        $(".nav-item[data-route]").removeClass("active"); $(".nav-item[data-route='" + route.name + "']").addClass("active");
        if (route.name === "designer") $(".nav-item[data-route='workflows']").addClass("active");
        $("#breadcrumb").html("<span>Workspace</span>" + AP.icon("chevron") + "<strong>" + AP.escapeHtml(routeTitle(route.name)) + "</strong>");
        document.title = routeTitle(route.name) + " · Enterprise Agent Platform";
        $("#sidebar").removeClass("mobile-open");
        window.scrollTo(0, 0);

        if (route.name === "dashboard") loadDashboard();
        if (route.name === "workflows") loadWorkflows();
        if (route.name === "discover") loadDiscovery($("#discoverSearch").val() || "");
        if (route.name === "agents") loadAgents();
        if (route.name === "tools") loadTools();
        if (route.name === "models") loadModels();
        if (route.name === "mcp") loadMcpServers();
        if (route.name === "gateway") loadGateway();
        if (route.name === "executions") loadExecutions();
        if (route.name === "governance") loadGovernance();
        if (route.name === "settings") loadSettings();
        if (route.name === "designer") {
            if (!route.id) { location.hash = "#/workflows"; return; }
            AgentDesigner.init(route.id);
        }
    }

    function loadDashboard() {
        $.when(
            AP.ajax({ url: "/api/workflows", dataType: "json" }),
            AP.ajax({ url: "/api/agents", dataType: "json" }),
            AP.ajax({ url: "/api/tools", dataType: "json" }),
            AP.ajax({ url: "/api/executions", dataType: "json" })
        ).done(function (w, a, t, e) {
            cache.workflows = w[0] || []; cache.agents = a[0] || []; cache.tools = t[0] || []; cache.executions = e[0] || [];
            animateNumber("#statWorkflows", cache.workflows.length); animateNumber("#statAgents", cache.agents.length); animateNumber("#statTools", cache.tools.length); animateNumber("#statExecutions", cache.executions.length);
            $("#navWorkflowCount").text(cache.workflows.length);
            var recent = cache.workflows.slice().sort(function (x, y) { return String(y.id).localeCompare(String(x.id)); }).slice(0, 4);
            $("#dashboardRecent").html(recent.length ? recent.map(function (x) {
                return "<a class='recent-item' href='#/designer/" + encodeURIComponent(x.id) + "'><span class='recent-icon'>" + AP.icon("workflow") + "</span><span class='recent-copy'><strong>" + AP.escapeHtml(x.name) + "</strong><small>" + AP.escapeHtml(x.status || "Draft") + " · " + (x.nodes || []).length + " nodes</small></span><span class='status-pill " + AP.statusClass(x.status) + "'>" + AP.escapeHtml(x.status || "Draft") + "</span></a>";
            }).join("") : emptyMini("No workflows yet", "Create your first workflow to see it here."));
        }).fail(function () { $("#dashboardRecent").html(emptyMini("Could not load dashboard", "Check that the API is running.")); });
    }

    function animateNumber(selector, target) {
        var el = $(selector), start = 0, duration = 420, started = performance.now();
        function tick(now) { var p = Math.min(1, (now - started) / duration); el.text(Math.round(start + (target - start) * (1 - Math.pow(1 - p, 3)))); if (p < 1) requestAnimationFrame(tick); }
        requestAnimationFrame(tick);
    }

    function emptyMini(title, text) { return "<div class='empty-catalog'><strong>" + AP.escapeHtml(title) + "</strong><br>" + AP.escapeHtml(text) + "</div>"; }

    function loadWorkflows() {
        $("#workflowGrid").html("<div class='skeleton-cards'></div>");
        AP.ajax({ url: "/api/workflows", dataType: "json" }).done(function (data) { cache.workflows = data || []; $("#navWorkflowCount").text(cache.workflows.length); renderWorkflows(); }).fail(function () { $("#workflowGrid").html(emptyState("workflow", "Unable to load workflows", "Check the API or security key.")); });
    }
    function renderWorkflows() {
        var q = ($("#workflowSearch").val() || "").toLowerCase().trim(), status = $("#workflowStatusFilter").val() || "";
        var items = cache.workflows.filter(function (w) { var text = ((w.name || "") + " " + (w.description || "") + " " + (w.status || "")).toLowerCase(); return (!q || text.indexOf(q) >= 0) && (!status || w.status === status); });
        if (!items.length) { $("#workflowGrid").html(emptyState("workflow", "No workflows found", q || status ? "Try a different search or status filter." : "Create your first reusable workflow.")); return; }
        $("#workflowGrid").html(items.map(workflowCard).join(""));
    }
    function workflowCard(w) {
        return "<article class='workflow-card' data-workflow-id='" + AP.escapeHtml(w.id) + "' tabindex='0'><div class='workflow-top'><span class='workflow-icon'>" + AP.icon("workflow") + "</span><div class='workflow-badges'><span class='env-pill'>" + AP.escapeHtml(w.environment || "DEV") + "</span><span class='risk-pill risk-" + AP.escapeHtml(String(w.riskLevel || "low").toLowerCase()) + "'>" + AP.escapeHtml(w.riskLevel || "Low") + "</span><span class='status-pill " + AP.statusClass(w.status) + "'>" + AP.escapeHtml(w.status || "Draft") + "</span></div></div><h3>" + AP.escapeHtml(w.name || "Workflow") + "</h3><p>" + AP.escapeHtml(w.description || "Reusable enterprise agent workflow.") + "</p><div class='workflow-owner'>" + AP.icon("shield") + "<span>" + AP.escapeHtml(w.owner || "Agent Platform Team") + (w.requiresApproval ? " · approval controlled" : "") + "</span></div><div class='workflow-meta'><span>" + AP.icon("model") + "v" + AP.escapeHtml(w.version || 1) + "</span><span>" + AP.icon("workflow") + (w.nodes || []).length + " nodes</span><span class='workflow-open'>Open designer →</span></div></article>";
    }

    function loadDiscovery(query) {
        $("#discoverGrid").html("<div class='skeleton-cards'></div>");
        AP.ajax({ url: "/api/discovery", dataType: "json", data: { query: query || "", kind: discoverKind } }).done(function (data) { cache.discovery = data || { agents: [], tools: [] }; renderDiscovery(); }).fail(function () { $("#discoverGrid").html(emptyState("compass", "Discovery unavailable", "The registry search could not be loaded.")); });
    }
    function renderDiscovery() {
        var agents = cache.discovery.agents || [], tools = cache.discovery.tools || [], cards = [];
        agents.forEach(function (x) { cards.push(catalogCard(x, "agent")); }); tools.forEach(function (x) { cards.push(catalogCard(x, "tool")); });
        $("#discoverSummary").text(cards.length + " reusable component" + (cards.length === 1 ? "" : "s") + " found" + (($("#discoverSearch").val() || "").trim() ? " for ‘" + $("#discoverSearch").val().trim() + "’" : ""));
        $("#discoverGrid").html(cards.length ? cards.join("") : emptyState("search", "No matching components", "Try SQL, RAG, API, MCP, routing, review or knowledge."));
    }
    function catalogCard(item, kind) {
        var tags = kind === "agent" ? (item.capabilities || []).concat(item.tags || []).slice(0, 4) : (item.tags || []).slice(0, 4);
        return "<article class='catalog-card-rich'><div class='catalog-rich-head'><span class='catalog-kind-icon " + (kind === "tool" ? "tool" : "") + "'>" + AP.icon(kind === "agent" ? "bot" : "tool") + "</span><div class='catalog-rich-copy'><h3>" + AP.escapeHtml(item.name) + "</h3><span class='category'>" + AP.escapeHtml(item.category || "General") + " · " + AP.escapeHtml(kind === "tool" ? (item.type || "tool") : "agent") + "</span></div><span class='status-pill status-published'>Ready</span></div><p>" + AP.escapeHtml(item.description || "Reusable enterprise component.") + "</p><div class='tag-row'>" + tags.map(function (t) { return "<span class='tag'>" + AP.escapeHtml(t) + "</span>"; }).join("") + "</div><div class='catalog-footer'><span class='enabled-dot'></span>Enabled in registry<span style='margin-left:auto'>Use from Workflow Designer</span></div></article>";
    }

    function loadAgents() { AP.ajax({ url: "/api/agents", dataType: "json" }).done(function (d) { cache.agents = d || []; renderAgentPage(); }); }
    function renderAgentPage() { var q = ($("#agentPageSearch").val() || "").toLowerCase().trim(), items = cache.agents.filter(function (x) { return !q || JSON.stringify(x).toLowerCase().indexOf(q) >= 0; }); $("#agentPageGrid").html(items.length ? items.map(function (x) { return catalogCard(x, "agent"); }).join("") : emptyState("bot", "No agents found", "Adjust your search.")); }
    function loadTools() { AP.ajax({ url: "/api/tools", dataType: "json" }).done(function (d) { cache.tools = d || []; renderToolPage(); }); }
    function renderToolPage() { var q = ($("#toolPageSearch").val() || "").toLowerCase().trim(), items = cache.tools.filter(function (x) { return !q || JSON.stringify(x).toLowerCase().indexOf(q) >= 0; }); $("#toolPageGrid").html(items.length ? items.map(function (x) { return catalogCard(x, "tool"); }).join("") : emptyState("tool", "No tools found", "Adjust your search.")); }
    function loadMcpServers() {
        $("#mcpServerGrid").html("<div class='skeleton-cards'></div>");
        AP.ajax({ url: "/api/mcp/servers", dataType: "json" }).done(function (d) {
            cache.mcpServers = d || [];
            renderMcpServers();
        }).fail(function () { $("#mcpServerGrid").html(emptyState("globe", "MCP registry unavailable", "Check the Agent Platform API.")); });
    }
    function renderMcpServers() {
        if (!cache.mcpServers.length) { $("#mcpServerGrid").html(emptyState("globe", "No MCP servers", "Register an approved Streamable HTTP MCP server above.")); return; }
        $("#mcpServerGrid").html(cache.mcpServers.map(function (s) {
            var approved = String(s.trustStatus || "Pending").toLowerCase() === "approved";
            return "<article class='catalog-card-rich'><div class='catalog-rich-head'><span class='catalog-kind-icon tool'>" + AP.icon("globe") + "</span><div class='catalog-rich-copy'><h3>" + AP.escapeHtml(s.name) + "</h3><span class='category'>" + AP.escapeHtml(s.transport || "streamable-http") + " · " + AP.escapeHtml(s.environment || "DEV") + "</span></div><span class='status-pill " + (approved ? "status-published" : "status-draft") + "'>" + AP.escapeHtml(s.trustStatus || "Pending") + "</span></div><p>" + AP.escapeHtml(s.description || s.endpoint) + "</p><div class='tag-row'><span class='tag'>" + AP.escapeHtml(s.toolCount || 0) + " tools</span><span class='tag'>" + AP.escapeHtml(s.resourceCount || 0) + " resources</span><span class='tag'>" + AP.escapeHtml(s.promptCount || 0) + " prompts</span></div><div class='catalog-footer' style='gap:8px;flex-wrap:wrap'><button class='btn btn-secondary mcp-test' data-id='" + AP.escapeHtml(s.id) + "'>Test</button><button class='btn btn-secondary mcp-discover' data-id='" + AP.escapeHtml(s.id) + "'>Discover</button><button class='btn btn-primary mcp-import' data-id='" + AP.escapeHtml(s.id) + "'>Discover + Import</button></div></article>";
        }).join(""));
    }
    function mcpAction(id, action, importTools) {
        var url = "/api/mcp/servers/" + encodeURIComponent(id) + "/" + action + (action === "discover" ? "?import=" + (importTools ? "true" : "false") : "");
        AP.ajax({ url: url, method: "POST", dataType: "json" }).done(function (r) {
            if (action === "test") { AP.toast("MCP connection successful.", "success", "Connected"); return; }
            var tools = r.tools || [], resources = r.resources || [], prompts = r.prompts || [];
            $("#mcpDiscoveryResult").removeClass("hidden").html("<div class='section-heading compact'><div><span class='section-kicker'>DISCOVERY RESULT</span><h2>" + AP.escapeHtml(r.serverName || "MCP Server") + "</h2></div><span class='status-pill status-published'>Connected</span></div><p>Discovered <strong>" + tools.length + " tools</strong>, " + resources.length + " resources and " + prompts.length + " prompts.</p><div class='tag-row'>" + tools.map(function(t){return "<span class='tag'>" + AP.escapeHtml(t.name) + (t.imported ? " ✓" : "") + "</span>";}).join("") + "</div>");
            AP.toast(importTools ? tools.length + " MCP tools imported into Tool Registry." : tools.length + " MCP tools discovered.", "success", importTools ? "Imported" : "Discovery complete");
            loadMcpServers();
        }).fail(function (xhr) { AP.toast(xhr.responseJSON?.error || xhr.responseJSON?.error?.message || "MCP request failed.", "error", "MCP"); });
    }
    function addMcpServer() {
        var payload = { name: ($("#mcpName").val() || "Enterprise MCP").trim(), endpoint: ($("#mcpEndpoint").val() || "").trim(), transport: "streamable-http", environment: AP.context().environment, trustStatus: $("#mcpTrust").val() || "Pending", enabled: true, description: "Enterprise MCP connection" };
        if (!payload.endpoint) { AP.toast("Enter the MCP Streamable HTTP endpoint.", "warning"); return; }
        AP.ajax({ url: "/api/mcp/servers", method: "POST", contentType: "application/json", dataType: "json", data: JSON.stringify(payload) }).done(function () { AP.toast("MCP server registered.", "success"); $("#mcpEndpoint").val(""); loadMcpServers(); }).fail(function (xhr) { AP.toast(xhr.responseJSON?.error || "Could not register MCP server.", "error"); });
    }

    function loadGateway() {
        AP.ajax({ url: "/api/gateway/info", dataType: "json" }).done(function (g) {
            $("#gatewaySummary").html([governanceMetric("shield", "Implementation", g.implementation || "YARP", "Reverse proxy"), governanceMetric("globe", "Public URL", g.publicUrl || "http://localhost:8080", "Single enterprise entry point"), governanceMetric("workflow", "API upstream", g.agentPlatformDestination || "", "Agent Platform"), governanceMetric("tool", "MCP upstream", g.mcpDestination || "", "MCP server")].join(""));
            var routes = ["/api/* → Agent Platform API", "/mcp/* → Enterprise MCP Server", "/* → wwwroot SPA"];
            $("#gatewayRoutes").html(routes.map(function(x){return "<div class='control-item'><span class='control-state active'>" + AP.icon("check") + "</span><div><strong>" + AP.escapeHtml(x) + "</strong><small>Configured by YARP route/cluster settings.</small></div><span class='status-pill status-published'>Active</span></div>";}).join(""));
            var policies = g.capabilities || [];
            $("#gatewayPolicies").html(policies.map(function(x){return "<div class='control-item'><span class='control-state active'>" + AP.icon("shield") + "</span><div><strong>" + AP.escapeHtml(x) + "</strong><small>Central edge policy.</small></div><span class='status-pill status-published'>On</span></div>";}).join(""));
        }).fail(function () { $("#gatewaySummary").html(emptyState("shield", "Gateway information unavailable", "Start the Agent Platform API.")); });
    }

    function loadModels() {
        AP.ajax({ url: "/api/models", dataType: "json" }).done(function (d) {
            cache.models = d || [];
            $("#modelPageGrid").html(cache.models.length ? cache.models.map(function (m) {
                return "<article class='catalog-card-rich'><div class='catalog-rich-head'><span class='catalog-kind-icon'>" + AP.icon("model") + "</span><div class='catalog-rich-copy'><h3>" + AP.escapeHtml(m.name) + "</h3><span class='category'>" + AP.escapeHtml(m.provider || "provider") + "</span></div><span class='status-pill " + (m.enabled ? "status-published" : "status-archived") + "'>" + (m.enabled ? "Enabled" : "Disabled") + "</span></div><p>Model: " + AP.escapeHtml(m.model || "mock") + " · Temperature " + AP.escapeHtml(m.temperature) + " · Max " + AP.escapeHtml(m.maxTokens) + " tokens.</p><div class='tag-row'><span class='tag'>" + AP.escapeHtml(m.provider || "mock") + "</span><span class='tag'>" + AP.escapeHtml(m.apiKeyEnvVar || "No key") + "</span></div><div class='catalog-footer'><span class='enabled-dot'></span>Reusable model definition</div></article>";
            }).join("") : emptyState("model", "No models configured", "Add a model definition to models.json."));
        });
    }

    function loadExecutions() {
        $("#executionList").html("<div class='skeleton-list'></div>");
        AP.ajax({ url: "/api/executions", dataType: "json" }).done(function (d) { cache.executions = d || []; renderExecutions(); }).fail(function () { $("#executionList").html(emptyState("activity", "Execution history unavailable", "Check the API connection.")); });
    }
    function renderExecutions() {
        if (!cache.executions.length) { $("#executionList").html(emptyState("activity", "No executions yet", "Test a workflow from the visual designer.")); return; }
        $("#executionList").html(cache.executions.map(function (e) {
            var lower = String(e.status || "").toLowerCase(), icon = lower === "completed" ? "check" : lower === "failed" ? "warning" : lower === "awaitingapproval" ? "approval" : "activity";
            var cls = lower === "completed" ? "" : lower === "failed" ? "failed" : "running";
            var action = lower === "awaitingapproval" ? "<button class='btn btn-primary approve-execution' data-id='" + AP.escapeHtml(e.id) + "'>" + AP.icon("approval") + "Approve</button>" : "<span class='status-pill " + (lower === "completed" ? "status-published" : lower === "failed" ? "status-archived" : "status-draft") + "'>" + AP.escapeHtml(e.status) + "</span>";
            return "<article class='execution-item'><span class='execution-status-icon " + cls + "'>" + AP.icon(icon) + "</span><div class='execution-copy'><strong>" + AP.escapeHtml(e.workflowId) + " <span class='execution-version'>v" + AP.escapeHtml(e.workflowVersion || 1) + "</span></strong><small>Execution " + AP.escapeHtml(e.id) + "</small></div><div class='execution-cell'>" + AP.escapeHtml(e.environment || "DEV") + "<small>Environment</small></div><div class='execution-cell'>" + AP.escapeHtml(e.userId || "anonymous") + "<small>User</small></div><div class='execution-cell'>" + AP.escapeHtml(e.currentNodeId || "—") + "<small>Current node</small></div><div class='execution-cell'>" + AP.escapeHtml(AP.formatDate(e.startedAtUtc)) + "<small>Started</small></div><div>" + action + "</div></article>";
        }).join(""));
    }

    function approveExecution(id) {
        AP.ajax({ url: "/api/executions/" + encodeURIComponent(id) + "/approve", method: "POST", contentType: "application/json", dataType: "json", data: JSON.stringify({ approved: true, comment: "Approved from SPA execution history" }) }).done(function (x) { AP.toast("Execution is now " + x.status + ".", "success", "Approved"); loadExecutions(); }).fail(function (xhr) { AP.toast(xhr.responseJSON?.error || "Approval failed.", "error"); });
    }

    function loadGovernance() {
        $("#governanceControls").html("<div class='skeleton-list'></div>");
        $("#auditList").html("<div class='skeleton-list'></div>");
        $.when(
            AP.ajax({ url: "/api/platform/overview", dataType: "json" }),
            AP.ajax({ url: "/api/governance", dataType: "json" }),
            AP.ajax({ url: "/api/audit", dataType: "json", data: { top: 20 } })
        ).done(function (overview, governance, audit) {
            var o = overview[0] || {}, g = governance[0] || {}, rows = audit[0] || [];
            $(".governance-posture").text(g.posture || "Enterprise starter");
            $("#governanceSummary").html([
                governanceMetric("shield", "Published", o.publishedWorkflows || 0, "Governed workflows"),
                governanceMetric("approval", "Awaiting approval", o.awaitingApproval || 0, "Human decisions"),
                governanceMetric("activity", "Audit events", o.auditEvents || 0, "Traceable actions"),
                governanceMetric("model", "Active models", o.models || 0, "Approved definitions")
            ].join(""));
            var controls = g.controls || [];
            $("#governanceControls").html(controls.length ? controls.map(function (c) {
                var active = String(c.status).toLowerCase() === "active";
                return "<div class='control-item'><span class='control-state " + (active ? "active" : "extension") + "'>" + AP.icon(active ? "check" : "settings") + "</span><div><strong>" + AP.escapeHtml(c.name) + "</strong><small>" + AP.escapeHtml(c.detail) + "</small></div><span class='status-pill " + (active ? "status-published" : "status-draft") + "'>" + AP.escapeHtml(c.status) + "</span></div>";
            }).join("") : emptyMini("No controls returned", "Governance API returned an empty control list."));
            renderAudit(rows);
        }).fail(function () { $("#governanceControls").html(emptyMini("Governance unavailable", "Check the API connection.")); });
    }
    function governanceMetric(icon, label, value, hint) { return "<div class='governance-metric'><span class='governance-metric-icon'>" + AP.icon(icon) + "</span><div><small>" + AP.escapeHtml(label) + "</small><strong>" + AP.escapeHtml(value) + "</strong><span>" + AP.escapeHtml(hint) + "</span></div></div>"; }
    function renderAudit(rows) {
        $("#auditList").html(rows.length ? rows.map(function (x) {
            return "<div class='audit-row'><span class='audit-icon'>" + AP.icon(x.outcome === "Success" ? "check" : "warning") + "</span><div class='audit-main'><strong>" + AP.escapeHtml(x.action) + " · " + AP.escapeHtml(x.resourceType) + "</strong><small>" + AP.escapeHtml(x.detail || x.resourceId) + "</small></div><div class='audit-context'><span>" + AP.escapeHtml(x.environment || "DEV") + "</span><small>" + AP.escapeHtml(x.userId || "anonymous") + "</small></div><time>" + AP.escapeHtml(AP.formatDate(x.atUtc)) + "</time></div>";
        }).join("") : emptyMini("No audit events yet", "Governed actions will appear here."));
    }

    function loadSettings() {
        var ctx = AP.context();
        $("#settingsApiKey").val(localStorage.getItem("agentPlatformApiKey") || "");
        $("#settingsTenant").val(ctx.tenantId);
        $("#settingsUser").val(ctx.userId);
        $("#settingsEnvironment").val(ctx.environment);
    }
    function emptyState(icon, title, text) { return "<div class='empty-state'>" + AP.icon(icon) + "<h3>" + AP.escapeHtml(title) + "</h3><p>" + AP.escapeHtml(text) + "</p></div>"; }

    function openNewWorkflow() { $("#newWorkflowEnvironment").val(AP.context().environment); AP.openModal("#newWorkflowModal"); setTimeout(function () { $("#newWorkflowName").trigger("focus").select(); }, 80); }
    function createWorkflow() {
        var payload = { name: ($("#newWorkflowName").val() || "").trim() || "New Enterprise Workflow", description: ($("#newWorkflowDescription").val() || "").trim(), template: $("input[name='workflowTemplate']:checked").val() || "blank", owner: ($("#newWorkflowOwner").val() || "").trim() || "Agent Platform Team", environment: $("#newWorkflowEnvironment").val() || AP.context().environment, riskLevel: $("#newWorkflowRisk").val() || "Low", requiresApproval: $("#newWorkflowApproval").is(":checked") };
        var $btn = $("#btnCreateWorkflow"); AP.setButtonLoading($btn, true, "Creating");
        AP.ajax({ url: "/api/workflows/create", method: "POST", contentType: "application/json", dataType: "json", data: JSON.stringify(payload) }).done(function (w) { AP.closeModal("#newWorkflowModal"); AP.toast("Workflow created. Add reusable agents and tools next.", "success", "Designer ready"); location.hash = "#/designer/" + encodeURIComponent(w.id); }).fail(function (xhr) { AP.toast(xhr.responseJSON?.error || "Workflow creation failed.", "error"); }).always(function () { AP.setButtonLoading($btn, false); });
    }

    function syncContextControls() {
        var ctx = AP.context();
        var $tenant = $("#tenantContext");
        if ($tenant.find("option[value='" + ctx.tenantId.replace(/'/g, "\'") + "']").length === 0) $tenant.append($("<option>").val(ctx.tenantId).text(ctx.tenantId));
        $tenant.val(ctx.tenantId);
        $("#environmentContext").val(ctx.environment);
        $(".environment-row .nav-text").text(ctx.environment + " environment");
        $(".environment-row .env-chip").text(ctx.environment);
    }

    function setupSidebar() {
        var collapsed = localStorage.getItem("agentSidebarCollapsed") === "1";
        if (collapsed) { $("#sidebar").addClass("collapsed"); $(".main-area").addClass("sidebar-collapsed"); }
        $("#sidebarToggle").on("click", function () { var c = $("#sidebar").toggleClass("collapsed").hasClass("collapsed"); $(".main-area").toggleClass("sidebar-collapsed", c); localStorage.setItem("agentSidebarCollapsed", c ? "1" : "0"); });
        $("#mobileMenu").on("click", function () { $("#sidebar").toggleClass("mobile-open"); });
    }

    function setupGlobalSearch() {
        function open() { $("#globalSearchOverlay").removeClass("hidden"); setTimeout(function () { $("#globalSearchInput").val("").trigger("focus"); $(".command-list a").show(); }, 30); }
        function close() { $("#globalSearchOverlay").addClass("hidden"); }
        $("#globalSearchBtn").on("click", open);
        $("#globalSearchOverlay").on("click", function (e) { if (e.target === this) close(); });
        $("#globalSearchInput").on("input", function () { var q = $(this).val().toLowerCase(); $(".command-list a").each(function () { $(this).toggle($(this).text().toLowerCase().indexOf(q) >= 0); }); });
        $(document).on("keydown", function (e) {
            var tag = (e.target.tagName || "").toLowerCase();
            if (e.key === "/" && tag !== "input" && tag !== "textarea" && tag !== "select") { e.preventDefault(); open(); }
            if (e.key === "Escape") { close(); AP.closeModal("#newWorkflowModal"); AP.closeModal("#testWorkflowModal"); }
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s" && currentRoute === "designer") { e.preventDefault(); AgentDesigner.save(); }
        });
        $(".command-list a").on("click", close);
    }

    function bindUi() {
        $(window).on("hashchange", navigate);
        $(document).on("click", "[data-new-workflow]", openNewWorkflow);
        $(document).on("click", "[data-close-modal]", function () { AP.closeModal("#newWorkflowModal"); });
        $("#newWorkflowModal").on("click", function (e) { if (e.target === this) AP.closeModal("#newWorkflowModal"); });
        $("#testWorkflowModal").on("click", function (e) { if (e.target === this) AP.closeModal("#testWorkflowModal"); });
        $("#btnCreateWorkflow").on("click", createWorkflow);
        $("#workflowSearch,#workflowStatusFilter").on("input change", renderWorkflows);
        $("#workflowRefresh").on("click", loadWorkflows);
        $(document).on("click", ".workflow-card", function () { location.hash = "#/designer/" + encodeURIComponent($(this).data("workflow-id")); });
        $(document).on("keydown", ".workflow-card", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $(this).trigger("click"); } });
        $("#discoverSearch").on("input", AP.debounce(function () { loadDiscovery($(this).val() || ""); }, 180));
        $("#discoverKind").on("click", "button", function () { discoverKind = $(this).data("kind"); $(this).addClass("active").siblings().removeClass("active"); loadDiscovery($("#discoverSearch").val() || ""); });
        $("#agentPageSearch").on("input", renderAgentPage); $("#toolPageSearch").on("input", renderToolPage);
        $("#executionRefresh").on("click", loadExecutions); $(document).on("click", ".approve-execution", function () { approveExecution($(this).data("id")); });
        $("#mcpRefresh").on("click", loadMcpServers);
        $("#mcpAddServer").on("click", addMcpServer);
        $(document).on("click", ".mcp-test", function () { mcpAction($(this).data("id"), "test", false); });
        $(document).on("click", ".mcp-discover", function () { mcpAction($(this).data("id"), "discover", false); });
        $(document).on("click", ".mcp-import", function () { mcpAction($(this).data("id"), "discover", true); });
        $("#saveApiKey").on("click", function () { localStorage.setItem("agentPlatformApiKey", $("#settingsApiKey").val() || ""); AP.toast("API key saved in this browser.", "success", "Settings saved"); });
        $("#saveEnterpriseContext").on("click", function () { AP.setContext($("#settingsTenant").val() || "enterprise-demo", $("#settingsUser").val() || "platform-admin", $("#settingsEnvironment").val() || "DEV"); syncContextControls(); AP.toast("Tenant, user and environment context updated.", "success", "Enterprise context"); });
        $("#tenantContext,#environmentContext").on("change", function () { AP.setContext($("#tenantContext").val() || "enterprise-demo", AP.context().userId, $("#environmentContext").val() || "DEV"); syncContextControls(); if (currentRoute === "governance") loadGovernance(); });
        $("#auditRefresh").on("click", loadGovernance);

        // Protect unsaved designer changes when users click SPA navigation.
        $(document).on("click", "a[href^='#/']", function (e) {
            if (currentRoute === "designer" && window.AgentDesigner && AgentDesigner.isDirty()) {
                var dest = $(this).attr("href"); if (dest.indexOf("#/designer/") === 0) return;
                if (!window.confirm("You have unsaved workflow changes. Leave without saving?")) e.preventDefault();
            }
        });
        window.addEventListener("beforeunload", function (e) { if (currentRoute === "designer" && window.AgentDesigner && AgentDesigner.isDirty()) { e.preventDefault(); e.returnValue = ""; } });
    }

    $(function () {
        setupSidebar(); setupGlobalSearch(); bindUi(); syncContextControls();
        $(document).on("agentplatform:contextchanged", syncContextControls);
        if (!location.hash) location.hash = "#/dashboard"; else navigate();
    });
})(jQuery, AgentPlatform);
