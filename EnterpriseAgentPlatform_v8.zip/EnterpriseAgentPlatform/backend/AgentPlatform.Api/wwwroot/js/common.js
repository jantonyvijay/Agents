(function ($) {
    "use strict";

    var AP = window.AgentPlatform = window.AgentPlatform || {};

    AP.newId = function (prefix) {
        prefix = prefix || "id";
        return prefix + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
    };

    AP.escapeHtml = function (value) {
        return $("<div/>").text(value == null ? "" : String(value)).html();
    };

    AP.icon = function (name, cls) {
        return "<svg" + (cls ? " class='" + AP.escapeHtml(cls) + "'" : "") + "><use href='#i-" + AP.escapeHtml(name) + "'></use></svg>";
    };

    AP.context = function () {
        return {
            tenantId: localStorage.getItem("agentPlatformTenant") || "enterprise-demo",
            userId: localStorage.getItem("agentPlatformUser") || "platform-admin",
            environment: localStorage.getItem("agentPlatformEnvironment") || "DEV"
        };
    };

    AP.ajax = function (options) {
        var key = localStorage.getItem("agentPlatformApiKey") || "";
        var ctx = AP.context();
        options = $.extend(true, {}, options);
        options.headers = options.headers || {};
        options.headers["X-Tenant-Id"] = ctx.tenantId;
        options.headers["X-User-Id"] = ctx.userId;
        options.headers["X-Environment"] = ctx.environment;
        if (key) options.headers["X-API-Key"] = key;
        return $.ajax(options);
    };

    AP.setContext = function (tenantId, userId, environment) {
        if (tenantId) localStorage.setItem("agentPlatformTenant", tenantId);
        if (userId) localStorage.setItem("agentPlatformUser", userId);
        if (environment) localStorage.setItem("agentPlatformEnvironment", String(environment).toUpperCase());
        $(document).trigger("agentplatform:contextchanged", [AP.context()]);
    };

    AP.toast = function (message, type, title) {
        type = type || "success";
        title = title || ({ success: "Success", error: "Action failed", warning: "Attention", info: "Information" })[type] || "Notice";
        var icon = type === "success" ? "check" : type === "error" ? "warning" : type === "warning" ? "warning" : "info";
        var $toast = $("<div class='toast toast-" + type + "'><div class='toast-icon'>" + AP.icon(icon) + "</div><div class='toast-copy'><strong>" + AP.escapeHtml(title) + "</strong><span>" + AP.escapeHtml(message) + "</span></div></div>");
        $("#toastHost").append($toast);
        requestAnimationFrame(function () { $toast.addClass("show"); });
        setTimeout(function () {
            $toast.removeClass("show");
            setTimeout(function () { $toast.remove(); }, 260);
        }, 3300);
    };

    AP.setButtonLoading = function ($button, loading, text) {
        if (!$button || !$button.length) return;
        if (loading) {
            $button.data("original-html", $button.html()).addClass("loading").prop("disabled", true);
            $button.html(AP.icon("refresh") + "<span>" + AP.escapeHtml(text || "Working…") + "</span>");
        } else {
            $button.removeClass("loading").prop("disabled", false);
            if ($button.data("original-html")) $button.html($button.data("original-html"));
        }
    };

    AP.formatDate = function (value) {
        if (!value) return "—";
        var d = new Date(value);
        if (isNaN(d.getTime())) return value;
        return d.toLocaleString([], { year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" });
    };

    AP.debounce = function (fn, wait) {
        var timer;
        return function () {
            var args = arguments, ctx = this;
            clearTimeout(timer);
            timer = setTimeout(function () { fn.apply(ctx, args); }, wait || 180);
        };
    };

    AP.openModal = function (selector) {
        $(selector).removeClass("hidden");
        setTimeout(function () { $(selector).find("input,textarea,button").filter(":visible").first().trigger("focus"); }, 40);
    };

    AP.closeModal = function (selector) { $(selector).addClass("hidden"); };

    AP.statusClass = function (status) {
        return "status-" + String(status || "draft").toLowerCase().replace(/[^a-z0-9_-]/g, "");
    };

    $(document).on("pointerdown", ".btn", function (e) {
        var $btn = $(this), offset = $btn.offset();
        if (!offset) return;
        var size = Math.max($btn.outerWidth(), $btn.outerHeight());
        var $r = $("<span class='ripple'></span>").css({ width: size, height: size, left: e.pageX - offset.left - size / 2, top: e.pageY - offset.top - size / 2 });
        $btn.append($r);
        setTimeout(function () { $r.remove(); }, 600);
    });
})(jQuery);
