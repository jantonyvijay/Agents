using AgentPlatform.Api.Contracts;
using AgentPlatform.Api.Middleware;
using AgentPlatform.Api.Models;
using AgentPlatform.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<RegistryService>();
builder.Services.AddSingleton<DiscoveryService>();
builder.Services.AddSingleton<AuditService>();
builder.Services.AddSingleton<McpClientService>();
builder.Services.AddHttpClient<ModelGateway>();
builder.Services.AddHttpClient<ToolGateway>();
builder.Services.AddScoped<WorkflowRuntime>();
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin()));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddControllers();

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseRouting();
app.UseCors();
app.UseMiddleware<ApiKeyMiddleware>();

app.MapGet("/health", () => Results.Ok(new
{
    status = "ok",
    service = "Enterprise Agent Platform",
    version = "7.0",
    utc = DateTimeOffset.UtcNow
}));

app.MapGet("/api/platform/overview", async (RegistryService r) =>
{
    var workflows = await r.Workflows.GetAllAsync();
    var agents = await r.Agents.GetAllAsync();
    var tools = await r.Tools.GetAllAsync();
    var models = await r.Models.GetAllAsync();
    var executions = await r.Executions.GetAllAsync();
    var audit = await r.Audit.GetAllAsync();
    var mcpServers = await r.McpServers.GetAllAsync();

    return Results.Ok(new
    {
        platform = "Enterprise Agent Platform",
        runtime = ".NET 8",
        persistence = "JSON demo repository",
        workflows = workflows.Count,
        publishedWorkflows = workflows.Count(x => x.Status.Equals("Published", StringComparison.OrdinalIgnoreCase)),
        agents = agents.Count(x => x.Enabled),
        tools = tools.Count(x => x.Enabled),
        models = models.Count(x => x.Enabled),
        executions = executions.Count,
        awaitingApproval = executions.Count(x => x.Status.Equals("AwaitingApproval", StringComparison.OrdinalIgnoreCase)),
        auditEvents = audit.Count,
        mcpServers = mcpServers.Count(x => x.Enabled),
        approvedMcpServers = mcpServers.Count(x => x.Enabled && x.TrustStatus.Equals("Approved", StringComparison.OrdinalIgnoreCase)),
        lastActivityUtc = audit.OrderByDescending(x => x.AtUtc).FirstOrDefault()?.AtUtc
    });
});

app.MapGet("/api/governance", () => Results.Ok(new
{
    posture = "Enterprise starter",
    controls = new[]
    {
        new { id = "tenant", name = "Tenant context", status = "Active", detail = "X-Tenant-Id propagated to executions and audit." },
        new { id = "environment", name = "Environment context", status = "Active", detail = "DEV/UAT/PROD context is carried by the SPA and audit layer." },
        new { id = "audit", name = "Audit trail", status = "Active", detail = "Workflow create/save/publish, registry changes, executions and approvals are audited." },
        new { id = "approval", name = "Human approval", status = "Active", detail = "Approval nodes pause workflow execution until an authorized decision is recorded." },
        new { id = "api-gateway", name = "API Gateway", status = "Active", detail = "YARP gateway project provides reverse proxy routing, correlation IDs, rate limiting and security headers." },
        new { id = "mcp", name = "MCP client / server", status = "Active", detail = "Official MCP C# SDK client discovery and tool execution with a reference Streamable HTTP MCP server." },
        new { id = "api-key", name = "API key middleware", status = "Available", detail = "Optional X-API-Key middleware protects API endpoints in this starter." },
        new { id = "rbac", name = "Enterprise SSO / RBAC", status = "Extension", detail = "Production hook for Microsoft Entra ID, roles and policy authorization." },
        new { id = "secrets", name = "Managed secrets", status = "Extension", detail = "Production hook for Azure Key Vault or another managed secret provider." },
        new { id = "telemetry", name = "Distributed observability", status = "Extension", detail = "Production hook for OpenTelemetry, tracing, metrics and centralized logs." }
    }
}));

app.MapGet("/api/audit", async (int? top, RegistryService r) =>
{
    var take = Math.Clamp(top ?? 50, 1, 200);
    var rows = (await r.Audit.GetAllAsync()).OrderByDescending(x => x.AtUtc).Take(take);
    return Results.Ok(rows);
});

app.MapGet("/api/discovery", async (string? query, string? kind, DiscoveryService discovery) =>
    Results.Ok(await discovery.SearchAsync(query, kind)));



// MCP server registry, connectivity, discovery and import.
app.MapGet("/api/mcp/servers", async (RegistryService r) => Results.Ok(await r.McpServers.GetAllAsync()));
app.MapGet("/api/mcp/servers/{id}", async (string id, RegistryService r) => await r.McpServers.GetAsync(id) is { } x ? Results.Ok(x) : Results.NotFound());
app.MapPost("/api/mcp/servers", async (McpServerDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    if (string.IsNullOrWhiteSpace(x.Id)) x.Id = Guid.NewGuid().ToString("N");
    x.Environment = string.IsNullOrWhiteSpace(x.Environment) ? Header(http, "X-Environment", "DEV") : x.Environment.ToUpperInvariant();
    var saved = await r.McpServers.UpsertAsync(x);
    await audit.WriteAsync(http, "Upsert", "McpServer", x.Id, $"MCP server '{x.Name}' registered ({x.TrustStatus})");
    return Results.Ok(saved);
});
app.MapPut("/api/mcp/servers/{id}", async (string id, McpServerDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    x.Id = id;
    var saved = await r.McpServers.UpsertAsync(x);
    await audit.WriteAsync(http, "Update", "McpServer", x.Id, $"MCP server '{x.Name}' updated ({x.TrustStatus})");
    return Results.Ok(saved);
});
app.MapPost("/api/mcp/servers/{id}/test", async (string id, RegistryService r, McpClientService mcp, CancellationToken ct) =>
{
    var server = await r.McpServers.GetAsync(id);
    if (server is null) return Results.NotFound(new { error = "MCP server not found." });
    try { await mcp.PingAsync(server, ct); return Results.Ok(new { connected = true, server = server.Name, endpoint = server.Endpoint }); }
    catch (Exception ex) { return Results.BadRequest(new { connected = false, error = ex.Message }); }
});
app.MapPost("/api/mcp/servers/{id}/discover", async (string id, bool? import, HttpContext http, RegistryService r, McpClientService mcp, AuditService audit, CancellationToken ct) =>
{
    var server = await r.McpServers.GetAsync(id);
    if (server is null) return Results.NotFound(new { error = "MCP server not found." });
    if (!server.Enabled) return Results.BadRequest(new { error = "MCP server is disabled." });
    var doImport = import ?? false;
    var result = await mcp.DiscoverAsync(server, doImport, ct);
    await audit.WriteAsync(http, "Discover", "McpServer", id, $"MCP discovery: {result.Tools.Count} tools, {result.Resources.Count} resources, {result.Prompts.Count} prompts; import={doImport}", result.Connected ? "Success" : "Failed");
    return result.Connected ? Results.Ok(result) : Results.BadRequest(result);
});
app.MapPost("/api/mcp/tools/{toolId}/call", async (string toolId, McpCallRequest request, RegistryService r, McpClientService mcp, CancellationToken ct) =>
{
    var tool = await r.Tools.GetAsync(toolId);
    if (tool is null || !tool.Type.Equals("mcp", StringComparison.OrdinalIgnoreCase)) return Results.NotFound(new { error = "MCP tool not found." });
    var input = System.Text.Json.JsonSerializer.Serialize(request.Arguments);
    return Results.Ok(new { output = await mcp.CallAsync(tool, input, ct) });
});

app.MapGet("/api/gateway/info", () => Results.Ok(new
{
    implementation = "YARP",
    project = "gateway/AgentPlatform.Gateway",
    capabilities = new[] { "Reverse proxy", "Rate limiting", "Correlation ID", "Security headers", "Tenant headers", "Health endpoint" },
    publicUrl = "http://localhost:8080",
    agentPlatformDestination = "http://localhost:5000",
    mcpDestination = "http://localhost:5100"
}));

app.MapGet("/api/agents", async (RegistryService r) => Results.Ok(await r.Agents.GetAllAsync()));
app.MapGet("/api/agents/{id}", async (string id, RegistryService r) => await r.Agents.GetAsync(id) is { } x ? Results.Ok(x) : Results.NotFound());
app.MapPost("/api/agents", async (AgentDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    var result = await r.Agents.UpsertAsync(x);
    await audit.WriteAsync(http, "Upsert", "Agent", x.Id, $"Agent '{x.Name}' updated");
    return Results.Ok(result);
});
app.MapPut("/api/agents/{id}", async (string id, AgentDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    x.Id = id;
    var result = await r.Agents.UpsertAsync(x);
    await audit.WriteAsync(http, "Update", "Agent", x.Id, $"Agent '{x.Name}' updated");
    return Results.Ok(result);
});

app.MapGet("/api/models", async (RegistryService r) => Results.Ok(await r.Models.GetAllAsync()));
app.MapPost("/api/models", async (ModelDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    var result = await r.Models.UpsertAsync(x);
    await audit.WriteAsync(http, "Upsert", "Model", x.Id, $"Model '{x.Name}' updated");
    return Results.Ok(result);
});
app.MapPut("/api/models/{id}", async (string id, ModelDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    x.Id = id;
    var result = await r.Models.UpsertAsync(x);
    await audit.WriteAsync(http, "Update", "Model", x.Id, $"Model '{x.Name}' updated");
    return Results.Ok(result);
});

app.MapGet("/api/tools", async (RegistryService r) => Results.Ok(await r.Tools.GetAllAsync()));
app.MapGet("/api/tools/{id}", async (string id, RegistryService r) => await r.Tools.GetAsync(id) is { } x ? Results.Ok(x) : Results.NotFound());
app.MapPost("/api/tools", async (ToolDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    var result = await r.Tools.UpsertAsync(x);
    await audit.WriteAsync(http, "Upsert", "Tool", x.Id, $"Tool '{x.Name}' updated");
    return Results.Ok(result);
});
app.MapPut("/api/tools/{id}", async (string id, ToolDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    x.Id = id;
    var result = await r.Tools.UpsertAsync(x);
    await audit.WriteAsync(http, "Update", "Tool", x.Id, $"Tool '{x.Name}' updated");
    return Results.Ok(result);
});

app.MapGet("/api/workflows", async (RegistryService r) => Results.Ok(await r.Workflows.GetAllAsync()));
app.MapGet("/api/workflows/{id}", async (string id, RegistryService r) => await r.Workflows.GetAsync(id) is { } x ? Results.Ok(x) : Results.NotFound());
app.MapPost("/api/workflows", async (WorkflowDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    StampWorkflow(x, http);
    var result = await r.Workflows.UpsertAsync(x);
    await audit.WriteAsync(http, "Upsert", "Workflow", x.Id, $"Workflow '{x.Name}' updated");
    return Results.Ok(result);
});
app.MapPost("/api/workflows/create", async (CreateWorkflowRequest request, HttpContext http, RegistryService r, AuditService audit) =>
{
    var workflow = CreateWorkflow(request, http);
    var result = await r.Workflows.UpsertAsync(workflow);
    await audit.WriteAsync(http, "Create", "Workflow", workflow.Id, $"Created '{workflow.Name}' in {workflow.Environment}");
    return Results.Ok(result);
});
app.MapPut("/api/workflows/{id}", async (string id, WorkflowDefinition x, HttpContext http, RegistryService r, AuditService audit) =>
{
    x.Id = id;
    StampWorkflow(x, http);
    var result = await r.Workflows.UpsertAsync(x);
    await audit.WriteAsync(http, "Save", "Workflow", x.Id, $"Saved '{x.Name}' with {x.Nodes.Count} nodes and {x.Edges.Count} connections");
    return Results.Ok(result);
});
app.MapGet("/api/workflows/{id}/validate", async (string id, RegistryService r) =>
{
    var workflow = await r.Workflows.GetAsync(id);
    if (workflow is null) return Results.NotFound(new { error = "Workflow not found." });
    var issues = ValidateForPublish(workflow);
    return Results.Ok(new { valid = issues.Count == 0, issues });
});

app.MapPost("/api/workflows/{id}/publish", async (string id, HttpContext http, RegistryService r, AuditService audit) =>
{
    var workflow = await r.Workflows.GetAsync(id);
    if (workflow is null) return Results.NotFound(new { error = "Workflow not found." });
    var issues = ValidateForPublish(workflow);
    if (issues.Count > 0)
    {
        await audit.WriteAsync(http, "Publish", "Workflow", workflow.Id, $"Publish blocked: {string.Join("; ", issues)}", "Blocked");
        return Results.BadRequest(new { error = "Workflow did not pass enterprise publish validation.", issues });
    }
    workflow.Status = "Published";
    workflow.Version = Math.Max(1, workflow.Version) + 1;
    StampWorkflow(workflow, http);
    var result = await r.Workflows.UpsertAsync(workflow);
    await audit.WriteAsync(http, "Publish", "Workflow", workflow.Id, $"Published '{workflow.Name}' version {workflow.Version}");
    return Results.Ok(result);
});

app.MapPost("/api/workflows/{id}/execute", async (string id, ExecuteWorkflowRequest request, HttpContext http, RegistryService r, WorkflowRuntime runtime, AuditService audit, CancellationToken ct) =>
{
    var workflow = await r.Workflows.GetAsync(id);
    if (workflow is null) return Results.NotFound(new { error = "Workflow not found." });
    var tenant = Header(http, "X-Tenant-Id", "default");
    var environment = Header(http, "X-Environment", workflow.Environment);
    var user = Header(http, "X-User-Id", "anonymous");
    var result = await runtime.StartAsync(workflow, request.Input, tenant, environment, user, request.Context, ct);
    await audit.WriteAsync(http, "Execute", "Workflow", workflow.Id, $"Execution {result.Id} started with status {result.Status}");
    return Results.Ok(result);
});

app.MapGet("/api/executions", async (RegistryService r) => Results.Ok((await r.Executions.GetAllAsync()).OrderByDescending(x => x.StartedAtUtc)));
app.MapGet("/api/executions/{id}", async (string id, RegistryService r) => await r.Executions.GetAsync(id) is { } x ? Results.Ok(x) : Results.NotFound());
app.MapPost("/api/executions/{id}/approve", async (string id, ApprovalRequest request, HttpContext http, WorkflowRuntime runtime, AuditService audit, CancellationToken ct) =>
{
    try
    {
        var result = await runtime.ApproveAsync(id, request.Approved, request.Comment, ct);
        await audit.WriteAsync(http, request.Approved ? "Approve" : "Reject", "Execution", id, request.Comment ?? "Approval decision recorded");
        return Results.Ok(result);
    }
    catch (KeyNotFoundException ex) { return Results.NotFound(new { error = ex.Message }); }
    catch (InvalidOperationException ex) { return Results.BadRequest(new { error = ex.Message }); }
});

// Compatibility with URLs from the previous MVC version.
app.MapGet("/workflows", () => Results.Redirect("/#/workflows"));
app.MapGet("/discovery", () => Results.Redirect("/#/discover"));
app.MapGet("/workflows/{id}/designer", (string id) => Results.Redirect("/#/designer/" + Uri.EscapeDataString(id)));

app.MapControllers();
app.MapFallbackToFile("index.html");
app.Run();

static string Header(HttpContext http, string name, string fallback) =>
    http.Request.Headers[name].FirstOrDefault() ?? fallback;

static void StampWorkflow(WorkflowDefinition workflow, HttpContext http)
{
    workflow.Owner = string.IsNullOrWhiteSpace(workflow.Owner) ? "Agent Platform Team" : workflow.Owner.Trim();
    workflow.Environment = string.IsNullOrWhiteSpace(workflow.Environment) ? Header(http, "X-Environment", "DEV") : workflow.Environment.Trim().ToUpperInvariant();
    workflow.RiskLevel = string.IsNullOrWhiteSpace(workflow.RiskLevel) ? "Low" : workflow.RiskLevel.Trim();
    workflow.UpdatedAtUtc = DateTimeOffset.UtcNow;
    workflow.UpdatedBy = Header(http, "X-User-Id", "anonymous");
}

static List<string> ValidateForPublish(WorkflowDefinition workflow)
{
    var issues = new List<string>();
    if (!workflow.Nodes.Any(x => x.Type.Equals("start", StringComparison.OrdinalIgnoreCase))) issues.Add("A Start node is required.");
    if (!workflow.Nodes.Any(x => x.Type.Equals("end", StringComparison.OrdinalIgnoreCase))) issues.Add("An End node is required.");
    if (workflow.Nodes.Any(x => x.Type.Equals("agent", StringComparison.OrdinalIgnoreCase) && !x.Config.ContainsKey("agentId"))) issues.Add("Every Agent node must be bound to a registry agent.");
    if (workflow.Nodes.Any(x => x.Type.Equals("tool", StringComparison.OrdinalIgnoreCase) && !x.Config.ContainsKey("toolId"))) issues.Add("Every Tool node must be bound to a registry tool.");
    var governed = workflow.RequiresApproval || string.Equals(workflow.RiskLevel, "High", StringComparison.OrdinalIgnoreCase);
    if (governed && !workflow.Nodes.Any(x => x.Type.Equals("approval", StringComparison.OrdinalIgnoreCase))) issues.Add("Approval-controlled or High-risk workflows require a Human Approval node.");
    if (workflow.Nodes.Count > 1 && workflow.Edges.Count == 0) issues.Add("The workflow has no connections.");
    return issues;
}

static WorkflowDefinition CreateWorkflow(CreateWorkflowRequest request, HttpContext http)
{
    var id = Guid.NewGuid().ToString("N");
    var template = (request.Template ?? "blank").Trim().ToLowerInvariant();
    var workflow = new WorkflowDefinition
    {
        Id = id,
        Name = string.IsNullOrWhiteSpace(request.Name) ? "New Enterprise Workflow" : request.Name.Trim(),
        Description = request.Description?.Trim() ?? "",
        Version = 1,
        Status = "Draft",
        Owner = string.IsNullOrWhiteSpace(request.Owner) ? "Agent Platform Team" : request.Owner.Trim(),
        Environment = string.IsNullOrWhiteSpace(request.Environment) ? Header(http, "X-Environment", "DEV") : request.Environment.Trim().ToUpperInvariant(),
        RiskLevel = string.IsNullOrWhiteSpace(request.RiskLevel) ? "Low" : request.RiskLevel.Trim(),
        RequiresApproval = request.RequiresApproval,
        UpdatedBy = Header(http, "X-User-Id", "anonymous"),
        UpdatedAtUtc = DateTimeOffset.UtcNow
    };

    workflow.Nodes.Add(new WorkflowNode { Id = "start", Type = "start", Label = "Start", X = 360, Y = 70 });

    if (template == "agent")
    {
        workflow.Nodes.Add(new WorkflowNode { Id = "agent-1", Type = "agent", Label = "Select Agent", X = 350, Y = 245 });
        workflow.Nodes.Add(new WorkflowNode { Id = "end", Type = "end", Label = "End", X = 360, Y = 430 });
        workflow.Edges.Add(new WorkflowEdge { Id = Guid.NewGuid().ToString("N"), Source = "start", Target = "agent-1", Condition = "always" });
        workflow.Edges.Add(new WorkflowEdge { Id = Guid.NewGuid().ToString("N"), Source = "agent-1", Target = "end", Condition = "always" });
    }
    else
    {
        workflow.Nodes.Add(new WorkflowNode { Id = "end", Type = "end", Label = "End", X = 360, Y = 280 });
        workflow.Edges.Add(new WorkflowEdge { Id = Guid.NewGuid().ToString("N"), Source = "start", Target = "end", Condition = "always" });
    }

    return workflow;
}
